# Reproducibility guide

## Overview

This package accompanies **Few-Shot Calibration of a Vision-Based Measurement System Using Partial Trihedral Checkerboard Observations**. It provides source snapshots and links to the saved experimental evidence needed to inspect and reproduce the reported analyses.

The method estimates a camera-specific model from a small set of trihedral checkerboard images. Locally ordered partial checkerboard observations provide calibration constraints. The fitted intrinsic and distortion parameters are then frozen for pose estimation and held-out prediction on other images. The estimator is staged; it is not a full three-face rigid bundle adjustment.

MATLAB planar-calibration parameters are reference inputs for evaluation only. They are not used to train the proposed models.

## Materials

Keep the following directories together when using the distributed package:

- **10_Reproducibility_Package_TriCal5/**: this guide and the source code under `code/`.
- **11_Processed_Data_TriCal5/**: dataset split records, fitted models, per-image results, diagnostics, and experiment-specific instructions.
- **09_LaTeX_Source_TriCal5/**: manuscript sources, tables, and figures; not required for numerical execution.

Original images are not duplicated in these archives. The designated data and code repository is [3D-data](https://github.com/lwl81839-commits/3D-data). Obtain the corresponding image release and preserve its original filenames and split membership. This guide does not certify that all release assets have already been uploaded.

The **0820** collection is the primary research dataset. The **0909** collection provides additional-camera experiments with independent camera-specific calibration, not direct transfer of a fitted parameter vector.

## Environment and paths

Python 3.12 is the experiment target. Dependencies vary by analysis; numerical work uses NumPy, SciPy, and OpenCV, while plotting also uses Matplotlib. Use the environment record accompanying the selected experiment rather than assuming that all historical runs used the same library versions.

The matched radial-order rerun records Python 3.12.12, OpenCV 4.12.0, NumPy 2.4.3, and SciPy 1.17.1. Exact source hashes and environment details are supplied with that experiment.

Some historical scripts retain absolute paths from the original workstation. Configure dataset and output paths before running them. Preserve archived outputs and write new runs to a separate working directory. The package has not been validated as a one-command clean-machine installation.

## Recommended workflow

1. Choose the experiment corresponding to the manuscript result of interest.
2. Read its protocol and source-version record. Do not substitute a different snapshot merely because its filename is similar.
3. Obtain the original images and use the supplied training/test split. Where an analysis uses cached correspondences, retain those observations for a matched numerical comparison.
4. Run training when required, then evaluate the frozen camera model on the designated test images. Do not use reference parameters or test errors to select training fits.
5. Compare the resulting model status, image counts, failures, and error summaries with the archived outputs. Numerical completion and acceptance by the quality gate are different outcomes.

Two entry points illustrate the distinction between summarizing saved experiments and repeating training.

### Rebuild the information-budget summary

From this package directory:

```powershell
python code/analyze_tim_existing_data_20260926.py --source ../11_Processed_Data_TriCal5/information_20260915/information_budget_20260915 --out ../11_Processed_Data_TriCal5/information_budget_rebuilt
```

This summarizes the saved 155 subset fits and their evaluations. It does **not** retrain the camera models.

### Repeat the matched radial-order experiment

Use the isolated source snapshot under `code/radial_order_20260926/`. From that directory:

```powershell
python output/radial_order_matched_0820_20260926.py --split-root "PATH_TO_0820_SPLIT" --output-root "PATH_TO_WORKING_OUTPUT"
```

This trains both model orders and evaluates them. To evaluate existing models without retraining, add `--evaluate-only`; both model families must already be present in the working output directory.

Before running, follow the experiment README in `11_Processed_Data_TriCal5/radial_order_matched_0820_20260926/` to arrange the original images and correspondence caches. It also explains how to reuse the archived training caches in a working copy. The command alone does not supply these inputs.

## Reading the results

Saved model files contain intrinsic and distortion estimates and acceptance diagnostics. Evaluation records contain image-level errors, observation counts, and failures; summaries aggregate those records according to the experiment's stated protocol.

Check the metric definition before comparing tables. Per-image aggregation, trial-level aggregation, training residuals, and held-out errors are not interchangeable. Repeated point splits within one image are not independent acquisitions.

Historical results, corrected-solver results, and exploratory reanalyses remain separately labeled. In particular:

- Use `radial_order_matched_0820_20260926` for the current matched single-/two-coefficient comparison.
- `k1_vs_k1k2_0820_20260926` is superseded because it mixed solver versions. It is retained for audit only.
- Do not assume that a generic filename containing “final” supersedes every later experiment.

The experiments assess prediction on available, geometrically accepted observations. Cached-observation tests do not measure end-to-end corner-detection success. Five images are an evaluated acquisition budget, not a universal sufficiency guarantee. Dimensional-consistency checks depend on nominal target geometry and do not constitute an independent traceable length standard or a complete measurement-uncertainty budget.

Several later analyses reuse test images inspected during development and are reported as exploratory. Consult the manuscript and supplement for the scope and limitations of each result.
