"""Mechanical restructuring: move detailed audit prose to supplement inputs."""
from pathlib import Path
import re
T=Path('C:/Users/15808/Desktop/三维/TriCal5_Submission_20260910/09_LaTeX_Source_TriCal5')
p=T/'main.tex';s=p.read_text(encoding='utf-8')
if r'\section{Introduction}' in s:
    a=s.index(r'\section{Introduction}');b=s.index(r'\section{Materials and Methods}',a)
    s=s[:a]+'\\input{introduction.tex}\n\n\\input{related_work.tex}\n\n'+s[b:]
if r'\input{solver_scope.tex}' not in s:s=s.replace(r'\section{Materials and Methods}',r'\section{Materials and Methods}'+'\n\\input{solver_scope.tex}\n')
s=s.replace(r'\input{robustness_methods.tex}',r'\input{evaluation_scope.tex}')
s=s.replace(r'\input{robustness_results.tex}',r'\input{robustness_main_summary.tex}')
if r'\section{Discussion}' in s:
    a=s.index(r'\section{Discussion}');b=s.index(r'\section*{Declarations}',a)
    s=s[:a]+'\\input{solver_discussion.tex}\n\n'+s[b:]
if r'\subsection{Interpretation of detected-face counts}' in s:
    a=s.index(r'\subsection{Interpretation of detected-face counts}');b=s.index(r'\input{solver_discussion.tex}',a)
    (T/'coverage_interpretation_detail.tex').write_text(s[a:b],encoding='utf-8')
    s=s[:a]+s[b:]
if r'\label{fig:faces}' in s:
    k=s.index(r'\label{fig:faces}');a=s.rfind(r'\begin{figure}',0,k);b=s.index(r'\end{figure}',k)+len(r'\end{figure}')
    (T/'coverage_figure.tex').write_text(s[a:b],encoding='utf-8');s=s[:a]+s[b:]
p.write_text(s,encoding='utf-8')
for name in ['robustness_methods','robustness_results']:
    text=(T/(name+'.tex')).read_text(encoding='utf-8')
    text=text.replace(r'\subsection{',r'\paragraph{')
    text=text.replace(r'\input{tables/precision_comparison.tex}',r'The precision-comparison table is given in Section S3.')
    text=text.replace(r'\Cref{tab:precision}',r'The matched precision comparison')
    (T/(name+'_detail.tex')).write_text(text,encoding='utf-8')
p=T/'supplement.tex';s=p.read_text(encoding='utf-8')
if r'\input{supporting_frontend.tex}' not in s:s=s.replace(r'\end{document}',r'\input{supporting_frontend.tex}'+'\n'+r'\input{coverage_figure.tex}'+'\n'+r'\end{document}')
p.write_text(s,encoding='utf-8')
# Check that the manuscript cites exactly the intended 20 references.
def expand(p,visited=None):
    visited=set() if visited is None else visited
    if p in visited:return ''
    visited.add(p);s=p.read_text(encoding='utf-8')
    for ref in re.findall(r'\\input\{([^}]+)\}',s):
        f=T/ref
        if not f.suffix:f=f.with_suffix('.tex')
        s+='\n'+expand(f,visited)
    return s
s=expand(T/'main.tex');cited={k for group in re.findall(r'\\cite\{([^}]+)\}',s) for k in group.split(',')}
keys=set(re.findall(r'@\w+\{([^,]+),',(T/'references.bib').read_text(encoding='utf-8')))
assert len(cited)==20 and cited==keys,(len(cited),keys-cited,cited-keys)
print('Verified 20 unique cited bibliography entries; sections moved.')
