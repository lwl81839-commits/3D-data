from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
import sys
ROOT=Path(__file__).resolve().parents[1]/'tmp/pdfs'/ (sys.argv[1] if len(sys.argv)>1 else 'revision_20260913')
for kind in ['main','supplement']:
    pages=sorted((ROOT/kind).glob('page-*.png'))
    for start in range(0,len(pages),6):
        canvas=Image.new('RGB',(1200,1160),'#b6b6b6');draw=ImageDraw.Draw(canvas)
        for i,p in enumerate(pages[start:start+6]):
            im=Image.open(p).convert('RGB');im.thumbnail((390,540));x=(i%3)*400+(400-im.width)//2;y=(i//3)*580+25
            canvas.paste(im,(x,y));draw.text(((i%3)*400+10,(i//3)*580+5),p.stem,fill='black')
        dest=ROOT/f'{kind}_contact_{start//6+1}.jpg';canvas.save(dest);print(dest)
