# Revision scope and evidence status

## Partial-observation focus (latest)

Title: Few-Shot Camera Calibration from Partial Trihedral Checkerboard Observations. The title, abstract, contribution list and discussion now foreground local partial checker regions. A 7 x 6 contiguous patch within a 9 x 6 board explains local indexing without physical labels and the homography translation property. Absolute association is still required for rigid pose use. No new crop experiment or calibration was run; the example is analytical. A complete-versus-partial accuracy advantage is not claimed. Earlier revision headings and page counts below are historical.

## Claim/evidence alignment (latest)

Current output: 14-page manuscript and 11-page supplement. Added a question/evidence/scope table and Supplement S9. The manuscript identifies the staged local-plane solver, separates L comparisons from P32/D correction tests, and states which claims still need corrected-version confirmation. No new experiment was run. Existing equations, numerical tables and bibliography were retained. Backup: output/manuscript_alignment_20260913/before in the workspace.

## Figure orientation and English revision

The target illustration now matches the photographs: XOZ (9 x 6) on the left, YOZ (7 x 6) on the right, and XOY on top. The drawing labels a shared top vertex and illustration axes. This does not change the stored calibration coordinate frame, target offsets or fitted models. The caption makes that distinction explicit.

The abstract, introduction and discussion were rewritten in shorter sentences. Supporting prose was edited for readability. Active section inputs are introduction_readable.tex and discussion_readable.tex; earlier versions are retained for audit. A principal-point clarification and revised parameter-figure caption distinguish image-center offsets from ground-truth errors and pose effects. All 20 references remain cited. Equations and experimental tables are unchanged. PDFs remain 14 and 10 pages.

Before-edit source backup: workspace output/manuscript_language_20260913/before. Figure reproduction: redraw_target_geometry_20260913.py. The language patch script is a one-time revision script, not a calibration dependency. Compile current TeX directly for normal reproduction.

## Solver-focused manuscript and supplement revision

Title: Few-Shot Camera Calibration from Trihedral Checkerboard Correspondences.
The main research object is camera-parameter estimation given valid three-face metric correspondences. Detection, grid association and recovery are supporting prerequisites, not the principal novelty. Partial grids are admissible when their indices and metric associations are reliable; complete corner detection is not required.

The 14-page manuscript foregrounds the input contract, staged shared-intrinsic estimation, dual-radial regularization and controlled held-out evaluation. The 10-page supplement carries front-end implementation details and extended image-budget, numerical, sparse-point and historical identifiability evidence. The main text still reports the actual retained face counts and does not relabel one-/two-face validation as strict three-face evidence.

The introduction and related work were rewritten; exactly 20 distinct references are cited. Added references were checked against publisher, conference or author sources; see REFERENCE_AUDIT_20260913.md. No calibration was rerun and no numerical result was changed in this editorial revision. Five images remain an operating budget, not a universal minimum.

Rebuild the current manuscript directly from main.tex and supplement.tex. Historical asset/editing scripts preserve earlier revisions and should not be run blindly over the current editorial structure.

The main text retains the historical five-image primary comparison and all four external-camera outcomes. It now distinguishes those frozen L results from paired P32/D precision retraining and from exploratory image-budget/sparse-point diagnostics. Neither old tables nor external models were silently replaced.

Main-text emphasis: geometric formulation and five-image operating point; controlled primary/external evaluation; image-count uncertainty and matched numerical correction. Supplement emphasis: full budget tables, single-image diagnostics, OpenCV budget-control scope, sparse/inlier experiments, historical ratio-prior and profile details.

The original Chinese v5 technical PDF is preserved under processed data in the research audit. The new supplementary PDF is a versioned English evidence supplement, not a claim that the old profiles were rerun. Independent k2-identifiability statements have been restricted pending corrected-version validation.

Not completed and not claimed: corrected-solver full budget/ratio reruns, new independent measurement artefact validation, universal minimum image count, a MATLAB five-image benchmark, or corrected-version external-camera tests.

The PDF skill guided compilation and visual layout checks. Existing author/hardware/declaration fields remain to be completed by the authors; none were invented. Existing cover-letter and declaration templates must be reviewed against the revised claim scope before submission.

Rebuild: compile main.tex and supplement.tex with Tectonic or a compatible XeLaTeX workflow. All included section files, data-derived tables and figures are in this folder. Revision asset generation is archived with the reproducibility scripts; it reads the archived experimental JSON data and does not rerun calibration.
