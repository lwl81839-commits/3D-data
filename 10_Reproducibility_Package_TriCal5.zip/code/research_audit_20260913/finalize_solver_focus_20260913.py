from pathlib import Path
import shutil, zipfile, hashlib, json
ROOT=Path(__file__).resolve().parents[1]
P=Path('C:/Users/15808/Desktop/三维/TriCal5_Submission_20260910')
T=P/'09_LaTeX_Source_TriCal5'
C=P/'10_Reproducibility_Package_TriCal5/code/research_audit_20260913'
D=P/'11_Processed_Data_TriCal5/research_audit_20260913'
for name in ['refocus_manuscript_20260913.py','generate_solver_pipeline.py','qa_revision_contact_sheets.py','finalize_solver_focus_20260913.py','redraw_target_geometry_20260913.py','polish_language_20260913.py']:
    shutil.copy2(ROOT/'output'/name,C/name)
for dest in [C,D]:
    shutil.copy2(T/'REVISION_20260913.md',dest/'README.md')
    shutil.copy2(T/'REFERENCE_AUDIT_20260913.md',dest/'REFERENCE_AUDIT_20260913.md')
shutil.copy2(T/'main.pdf',P/'02_Main_Manuscript_TriCal5.pdf')
shutil.copy2(T/'supplement.pdf',P/'04_Supplementary_Appendix.pdf')
for name in ['09_LaTeX_Source_TriCal5','10_Reproducibility_Package_TriCal5','11_Processed_Data_TriCal5']:
    with zipfile.ZipFile(P/(name+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted((P/name).rglob('*')):
            if f.is_file(): z.write(f,f.relative_to(P/name))
    with zipfile.ZipFile(P/(name+'.zip')) as z: assert z.testzip() is None
    print(name+' rebuilt and CRC verified',flush=True)
files=[]
for f in sorted(P.rglob('*')):
    if f.is_file() and f.name!='file_manifest.json':
        files.append(dict(path=f.relative_to(P).as_posix(),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
(P/'file_manifest.json').write_text(json.dumps(files,ensure_ascii=False,indent=2),encoding='utf-8')
print('Manifest regenerated: '+str(len(files))+' files',flush=True)
