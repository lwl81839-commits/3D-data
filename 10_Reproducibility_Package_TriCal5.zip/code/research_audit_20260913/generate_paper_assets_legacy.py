from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch, Polygon
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(r"E:\image\data_3D_0820_split_model_3D5_Zhang2D20_each_pose_quality_gated")
EVAL = ROOT / "validation_ours_vs_zhang" / "final_test_evaluation"
MODELS = ROOT / "validation_ours_vs_zhang" / "per_pose_models"
OUT = Path(__file__).resolve().parents[1]
FIG = OUT / "figures"
TAB = OUT / "tables"
SNAP = OUT / "data_snapshot"
CODE = OUT / "code_snapshot"
POSES = ["15_0.528", "30_0.827", "45_0.827", "45_1.155", "60_1.155"]


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def setup() -> None:
    for path in (FIG, TAB, SNAP, CODE):
        path.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.labelsize": 9,
        "figure.dpi": 160,
        "savefig.dpi": 300,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })


def snapshot_inputs() -> None:
    for name in ["split_summary.json", "split_manifest.csv"]:
        shutil.copy2(ROOT / name, SNAP / name)
    for name in ["comparison_summary.json", "comparison_metrics.csv", "PLANAR_2D_CONTROLLED_SUMMARY.json"]:
        shutil.copy2(EVAL / name, SNAP / name)
    models = {}
    for pose in POSES:
        model = load_json(MODELS / pose / "trained_camera_model.json")
        models[pose] = {
            "schema": model["schema"],
            "accepted": model["accepted"],
            "cameraMatrix": model["cameraMatrix"],
            "distCoeffs": model["distCoeffs"],
            "cross_validation": model["cross_validation"],
            "diagnostics": model["diagnostics"],
            "target_geometry": model["target_geometry"],
            "constraints": model["constraints"],
            "training_images": [
                {"image": Path(x["image"]).name, "sha256": x["sha256"]}
                for x in model["training_images"]
            ],
        }
    (SNAP / "final_models_compact.json").write_text(
        json.dumps(models, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def snapshot_code() -> None:
    project = OUT.parents[1]
    files = [
        "trained_camera_model.py",
        "face_detector.py",
        "evaluate_trained_camera_model.py",
        "evaluate_planar_per_pose_controlled.py",
        "validate_per_pose_against_fixed_zhang.py",
        "summarize_final_validation.py",
        "data_3d_0820_pipeline/pipeline_config.py",
        "data_3d_0820_pipeline/finalize_reselection.py",
        "data_3d_0820_pipeline/train_all_selected_poses.py",
        "data_3d_0820_pipeline/build_all_test_caches.py",
    ]
    records = []
    import hashlib
    for rel in files:
        source = project / rel
        target = CODE / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        digest = hashlib.sha256(target.read_bytes()).hexdigest()
        records.append({"path": rel.replace("\\", "/"), "sha256": digest, "bytes": target.stat().st_size})
    (CODE / "MANIFEST.json").write_text(
        json.dumps({"schema": "paper-code-snapshot/v1", "files": records}, indent=2),
        encoding="utf-8",
    )


def read_metrics():
    planar = {row["pose"]: row for row in load_json(EVAL / "PLANAR_2D_CONTROLLED_SUMMARY.json")}
    comparison = load_json(EVAL / "comparison_summary.json")
    cube = {}
    for row in comparison["rows"]:
        cube.setdefault(row["pose"], {})[row["method"]] = row
    models = {pose: load_json(MODELS / pose / "trained_camera_model.json") for pose in POSES}
    split = load_json(ROOT / "split_summary.json")
    return planar, cube, models, split


def save_parameter_table(models) -> None:
    fields = ["pose", "fx", "fy", "cx", "cy", "k1", "k2", "k2_abs_over_k1_abs", "train_rmse_px", "loo_median_px", "loo_max_px", "radial_r95"]
    with (TAB / "camera_parameters.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for pose in POSES:
            m = models[pose]
            cand = m["candidate_comparison"]["k1_k2"]
            K, d = m["cameraMatrix"], m["distCoeffs"]
            w.writerow({
                "pose": pose, "fx": K[0][0], "fy": K[1][1], "cx": K[0][2], "cy": K[1][2],
                "k1": d[0], "k2": d[1], "k2_abs_over_k1_abs": abs(d[1]) / max(abs(d[0]), 1e-12),
                "train_rmse_px": cand["diagnostics"]["joint_reprojection_rmse_px"],
                "loo_median_px": cand["cross_validation"]["median_reprojection_rmse_px"],
                "loo_max_px": cand["cross_validation"]["max_reprojection_rmse_px"],
                "radial_r95": cand["radial_coverage"]["radius_p95"],
            })


def save_metric_tables(planar, cube) -> None:
    for name, source, metrics in [
        ("planar_2d_metrics.csv", planar, ["holdout_rmse_px", "holdout_object_rmse_mm", "length_relative_error_pct", "undistorted_line_rms_px"]),
        ("cube_3d_metrics.csv", cube, ["holdout_rmse_px_median", "object_point_rmse_mm_median", "length_rel_error_pct_median", "undistorted_line_rms_px_median"]),
    ]:
        with (TAB / name).open("w", newline="", encoding="utf-8-sig") as f:
            fieldnames = ["pose", "method", *metrics]
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            for pose in POSES:
                if name.startswith("planar"):
                    for method in ["ours_3d_5_images", "zhang_matlab_20_images"]:
                        s = source[pose]["summaries"][method]
                        w.writerow({"pose": pose, "method": method, **{k: s[k]["median"] for k in metrics}})
                else:
                    for method in ["ours_3d_5_images", "zhang_matlab_20_images"]:
                        s = source[pose][method]
                        w.writerow({"pose": pose, "method": method, **{k: s[k] for k in metrics}})


def crop_to_ratio(img: Image.Image, ratio: float = 16 / 9) -> Image.Image:
    w, h = img.size
    current = w / h
    if current > ratio:
        nw = int(h * ratio); left = (w - nw) // 2
        return img.crop((left, 0, left + nw, h))
    nh = int(w / ratio); top = (h - nh) // 2
    return img.crop((0, top, w, top + nh))


def make_sample_montage(split) -> None:
    chosen = {}
    for item in split["three_d_selection_by_pose"]:
        chosen[item["pose_name"]] = item["selected"][len(item["selected"]) // 2]
    thumb_w, thumb_h = 760, 430
    canvas = Image.new("RGB", (thumb_w * 2, thumb_h * 3), "white")
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.load_default()
    positions = [(0, 0), (thumb_w, 0), (0, thumb_h), (thumb_w, thumb_h), (thumb_w // 2, 2 * thumb_h)]
    for pose, (x, y) in zip(POSES, positions):
        image_path = ROOT / "train" / pose / "3D" / chosen[pose]
        img = crop_to_ratio(Image.open(image_path).convert("RGB")).resize((thumb_w, thumb_h), Image.Resampling.LANCZOS)
        canvas.paste(img, (x, y))
        draw.rectangle((x + 10, y + 10, x + 145, y + 40), fill=(255, 255, 255))
        draw.text((x + 18, y + 18), pose, fill=(15, 45, 75), font=font)
    canvas.save(FIG / "training_examples.jpg", quality=92)


def make_target_geometry() -> None:
    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    ax.set_aspect("equal"); ax.axis("off")
    top = np.array([[0.8, 3.0], [4.6, 4.0], [7.0, 2.8], [3.2, 1.8]])
    front = np.array([[3.2, 1.8], [7.0, 2.8], [7.0, -0.7], [3.2, -1.7]])
    side = np.array([[0.8, 3.0], [3.2, 1.8], [3.2, -1.7], [0.8, -0.3]])
    for poly, color, label in [(top, "#d9edf7", "XOY: 9 x 6"), (front, "#fce8d5", "XOZ: 9 x 6"), (side, "#e4f2df", "YOZ: 7 x 6")]:
        ax.add_patch(Polygon(poly, closed=True, facecolor=color, edgecolor="#264653", lw=1.6))
        c = poly.mean(axis=0); ax.text(c[0], c[1], label, ha="center", va="center", fontsize=10, weight="bold")
    ax.annotate("X = 320 mm", xy=(5.1, 3.7), xytext=(5.0, 4.6), ha="center", arrowprops=dict(arrowstyle="-[,widthB=5.0", lw=1.2))
    ax.annotate("Y = 220 mm", xy=(1.7, 2.5), xytext=(-0.2, 2.1), ha="center", arrowprops=dict(arrowstyle="-[,widthB=3.2", lw=1.2))
    ax.annotate("Z = 240 mm", xy=(7.0, 1.0), xytext=(8.2, 0.7), ha="center", arrowprops=dict(arrowstyle="-[,widthB=3.0", lw=1.2))
    ax.text(4.0, -2.25, "Checker square: 25 mm; corner lattices are offset from the cuboid edges", ha="center", fontsize=9)
    ax.set_xlim(-0.8, 8.8); ax.set_ylim(-2.6, 5.0)
    fig.tight_layout(); fig.savefig(FIG / "target_geometry.png", bbox_inches="tight"); plt.close(fig)


def make_pipeline() -> None:
    fig, ax = plt.subplots(figsize=(11.2, 3.0)); ax.axis("off")
    labels = [
        "Five development\nimages", "Partial-face\ncorner extraction", "Local homography\nconstraints", "Shared K and\nradial k1,k2", "Independent-image\npose + quality gates", "Frozen model on\na new image"
    ]
    colors = ["#e8f1fb", "#e8f1fb", "#fff3d6", "#dff3e4", "#fff3d6", "#dff3e4"]
    xs = np.linspace(0.02, 0.82, len(labels))
    for i, (x, label, color) in enumerate(zip(xs, labels, colors)):
        box = FancyBboxPatch((x, 0.34), 0.14, 0.34, boxstyle="round,pad=0.012,rounding_size=0.018", fc=color, ec="#315b7d", lw=1.2)
        ax.add_patch(box); ax.text(x + 0.07, 0.51, label, ha="center", va="center", fontsize=9)
        if i < len(labels) - 1:
            ax.annotate("", xy=(xs[i + 1] - 0.005, 0.51), xytext=(x + 0.145, 0.51), arrowprops=dict(arrowstyle="->", lw=1.5, color="#315b7d"))
    ax.text(0.5, 0.16, "Zhang/MATLAB parameters are excluded from training and used only after the blind split for comparison.", ha="center", fontsize=9, color="#8b2f2f")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); fig.tight_layout(); fig.savefig(FIG / "method_pipeline.png", bbox_inches="tight"); plt.close(fig)


def make_training_coverage(split) -> None:
    fig, axes = plt.subplots(1, 5, figsize=(11.5, 2.6), sharex=True, sharey=True)
    for ax, item in zip(axes, split["three_d_selection_by_pose"]):
        pts = np.asarray(item["selected_centers_normalized"])
        ax.scatter(pts[:, 0], pts[:, 1], s=40, c=np.arange(5), cmap="viridis", edgecolor="white", lw=0.6)
        for i, (x, y) in enumerate(pts, 1): ax.text(x + 0.015, y + 0.015, str(i), fontsize=7)
        ax.set_title(item["pose_name"]); ax.set_xlim(0, 1); ax.set_ylim(1, 0); ax.grid(alpha=0.2); ax.set_aspect("equal")
    axes[0].set_ylabel("normalized image y"); fig.supxlabel("normalized image x", y=0.02)
    fig.tight_layout(rect=(0, .05, 1, 1)); fig.savefig(FIG / "training_spatial_coverage.png", bbox_inches="tight"); plt.close(fig)


def paired_bar_figure(planar, cube, which: str) -> None:
    x = np.arange(len(POSES)); width = 0.36
    if which == "planar":
        keys = [("holdout_rmse_px", "Hold-out reprojection RMSE (px)"), ("length_relative_error_pct", "Length relative error (%)")]
        getter = lambda pose, method, key: planar[pose]["summaries"][method][key]["median"]
        filename = "planar_test_results.png"
    else:
        keys = [("holdout_rmse_px_median", "Hold-out reprojection RMSE (px)"), ("length_rel_error_pct_median", "Length relative error (%)")]
        getter = lambda pose, method, key: cube[pose][method][key]
        filename = "cube_test_results.png"
    fig, axes = plt.subplots(1, 2, figsize=(10.6, 3.4))
    for ax, (key, title) in zip(axes, keys):
        ours = [getter(p, "ours_3d_5_images", key) for p in POSES]
        zhang = [getter(p, "zhang_matlab_20_images", key) for p in POSES]
        ax.bar(x - width/2, ours, width, label="Proposed, 5 cuboid images", color="#2a9d8f")
        ax.bar(x + width/2, zhang, width, label="Zhang, 20 planar images", color="#e9c46a")
        ax.set_title(title); ax.set_xticks(x, POSES, rotation=25, ha="right"); ax.grid(axis="y", alpha=.22)
    axes[0].legend(frameon=False, fontsize=8); fig.tight_layout(); fig.savefig(FIG / filename, bbox_inches="tight"); plt.close(fig)


def make_evidence_distribution(cube) -> None:
    one = [cube[p]["ours_3d_5_images"]["one_face_images"] for p in POSES]
    two = [cube[p]["ours_3d_5_images"]["two_face_images"] for p in POSES]
    three = [cube[p]["ours_3d_5_images"]["three_face_images"] for p in POSES]
    x = np.arange(len(POSES)); fig, ax = plt.subplots(figsize=(7.5, 3.5))
    ax.bar(x, one, label="1 detected face", color="#8ecae6")
    ax.bar(x, two, bottom=one, label="2 detected faces", color="#219ebc")
    ax.bar(x, three, bottom=np.asarray(one)+np.asarray(two), label="3 detected faces", color="#023047")
    ax.set_xticks(x, POSES, rotation=20, ha="right"); ax.set_ylabel("independent 3-D test images")
    ax.legend(frameon=False, ncol=3, fontsize=8); ax.grid(axis="y", alpha=.2); fig.tight_layout(); fig.savefig(FIG / "detected_face_distribution.png", bbox_inches="tight"); plt.close(fig)


def make_parameter_plot(models) -> None:
    k1 = [models[p]["distCoeffs"][0] for p in POSES]; k2 = [models[p]["distCoeffs"][1] for p in POSES]
    ratio = [abs(b)/abs(a) for a,b in zip(k1,k2)]
    fx = [models[p]["cameraMatrix"][0][0] for p in POSES]; fy = [models[p]["cameraMatrix"][1][1] for p in POSES]
    cx = [models[p]["cameraMatrix"][0][2]-960 for p in POSES]; cy = [models[p]["cameraMatrix"][1][2]-540 for p in POSES]
    x=np.arange(5); fig, axes=plt.subplots(1,3,figsize=(11,3.3))
    axes[0].plot(x,fx,"o-",label="fx"); axes[0].plot(x,fy,"s--",label="fy"); axes[0].set_ylabel("focal length (px)"); axes[0].legend(frameon=False)
    axes[1].plot(x,cx,"o-",label="cx-960"); axes[1].plot(x,cy,"s--",label="cy-540"); axes[1].axhline(0,color="0.5",lw=.8); axes[1].set_ylabel("principal-point offset (px)"); axes[1].legend(frameon=False)
    axes[2].plot(x,k1,"o-",label="k1"); axes[2].plot(x,k2,"s--",label="k2"); axes[2].plot(x,ratio,"^:",label="|k2|/|k1|"); axes[2].axhline(.5,color="#b23a48",lw=1,ls="--",label="soft ratio prior"); axes[2].legend(frameon=False,fontsize=7)
    for ax in axes: ax.set_xticks(x,POSES,rotation=25,ha="right"); ax.grid(alpha=.2)
    fig.tight_layout(); fig.savefig(FIG/"estimated_parameters.png",bbox_inches="tight"); plt.close(fig)


def main() -> None:
    setup(); snapshot_inputs(); snapshot_code()
    planar, cube, models, split = read_metrics()
    save_parameter_table(models); save_metric_tables(planar, cube)
    make_sample_montage(split); make_target_geometry(); make_pipeline(); make_training_coverage(split)
    paired_bar_figure(planar, cube, "planar"); paired_bar_figure(planar, cube, "cube")
    make_evidence_distribution(cube); make_parameter_plot(models)
    print(f"Paper assets written to {OUT}")


if __name__ == "__main__":
    main()
