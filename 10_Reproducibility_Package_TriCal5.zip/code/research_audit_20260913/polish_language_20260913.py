"""Apply reviewed prose substitutions. Equations, tables and citations are preserved."""
from pathlib import Path
import re,json
P=Path('C:/Users/15808/Desktop/三维/TriCal5_Submission_20260910/09_LaTeX_Source_TriCal5')
p=P/'main.tex';s=p.read_text(encoding='utf-8')
a=s.index('\\begin{abstract}');b=s.index('\\end{abstract}',a)
s=s[:a]+r'''\begin{abstract}
We study camera calibration from a few images of a trihedral checkerboard. The method assumes reliable, metrically indexed observations and focuses on parameter estimation rather than detection. Local homographies constrain a shared intrinsic matrix without requiring the absolute location of each rectangular checker patch. A second stage fixes the intrinsics and refines two radial coefficients and local-plane poses under empirical regularization. Measured target geometry supports face association and pose estimation. Reference-calibration parameters are excluded from fitting. The primary experiment uses five selected images per configuration. Across five configurations, historical median cuboid prediction errors range from 1.008 to 3.620 pixels. They are slightly lower than those of a 20-image MATLAB calibration in four configurations. Planar results are mixed. Refitting on two additional cameras gives configuration-dependent results. Both methods use the same test correspondences, including masks with fewer than three retained faces. These tests assess conditional prediction, not universal three-face accuracy. Supplementary experiments examine numerical precision, image budget and sparse observations. The results support the workflow at the tested budgets. They do not establish a universal minimum image count, unique distortion coefficients or traceable dimensional accuracy.
'''+s[b:]
anchor='Skew, tangential distortion, and $k_3$ are fixed to zero. The model is appropriate only for the fixed resolution, focus, zoom, and imaging pipeline used during a configuration.'
s=s.replace(anchor,anchor+'\n\nThe principal point $(c_x,c_y)$ need not equal the image center. Under fixed optics and image processing, a change in camera pose changes extrinsics, not intrinsics. Different observation geometries can nevertheless change the estimated principal point through noise and parameter coupling. We use $(960,540)$ only as a reference center for the $1920\\times1080$ images.')
p.write_text(s,encoding='utf-8')
replacements={
'related_work.tex':[
("Tsai established a practical three-dimensional target calibration approach \\cite{tsai1987}; Zhang's flexible planar method uses homographies followed by nonlinear refinement \\cite{zhang2000}.","Tsai developed a practical three-dimensional target method \\cite{tsai1987}. Zhang's planar method uses homographies followed by nonlinear refinement \\cite{zhang2000}."),
('A trihedral acquisition supplies multiple faces, but the implemented radial stage gives each local plane its own pose; it should not be described as a fully joint rigid-target bundle adjustment.','A trihedral image supplies multiple faces. Our radial stage assigns each local plane its own pose, so it is not a fully joint rigid-target bundle adjustment.'),
('More flexible generic models can reduce model-induced downstream bias \\cite{schops2020}; BabelCalib instead emphasizes reliable initialization across central camera models \\cite{lochman2021}.','Flexible camera models can reduce downstream bias \\cite{schops2020}. BabelCalib addresses reliable initialization across central camera models \\cite{lochman2021}.'),
('The present study is complementary: it assumes metrically indexed target observations and evaluates a camera-specific geometric solver, without learning a cross-camera image-to-parameter mapping. None of these cited systems is presented as an experimentally beaten baseline unless it was actually run in the reported protocol.','Here, we assume metrically indexed target observations and fit a camera-specific geometric model. We do not learn a cross-camera mapping. The cited methods provide context; they are not additional experimental baselines.')],
'solver_scope.tex':[
('Validity means that local point identity, spacing and sufficient two-dimensional span have been established; it does not mean that every corner on the full printed board is visible.','Valid observations have reliable local indices, known spacing and sufficient two-dimensional span. The full printed board need not be visible.'),
('The scientific comparison conditions on the resulting correspondence sets: camera models receive the same observations and held-out splits.','Both camera models receive the same correspondence sets and held-out splits.'),
('Incorrect correspondences that survive screening remain a source of estimation error and cannot be dismissed by this scope choice.','Incorrect correspondences that survive screening can still bias the estimates.')],
'supporting_frontend.tex':[
('These procedures establish or audit the solver input; they are not the principal novelty.','These procedures construct and check the solver input. They are supporting steps.'),
('A usable face normally has at least 12 geometric inliers and spans four rows and columns; a training-only elongated-face exception accepts a $6\\times3$ span with 18 inliers.','A usable face normally has at least 12 geometric inliers and spans at least four rows and four columns. A training-only exception accepts elongated $6\\times3$ patches with 18 inliers.'),
('Cases with only one or two retained faces cannot be labeled strict three-face validation; retaining their conditional fixed-camera predictions does not repair that evidence gap.','Cases with one or two retained faces evaluate fixed-camera prediction, but not strict three-face performance.'),
('Likewise, a failure to assemble a large pool of qualified inputs prevents a clean image-count conclusion, rather than proving that the geometric estimator fails when its input conditions are satisfied.','A limited pool of qualified inputs restricts image-count conclusions. It does not establish failure of the estimator under valid input conditions.')]
}
count=0
for name,pairs in replacements.items():
    p=P/name;s=p.read_text(encoding='utf-8')
    for old,new in pairs:
        assert old in s,(name,old)
        s=s.replace(old,new);count+=1
    p.write_text(s,encoding='utf-8')
# Conservative mechanical punctuation edits in supporting prose only.
for name in ['robustness_methods_detail.tex','robustness_results_detail.tex','supplement.tex','robustness_main_summary.tex']:
    p=P/name;s=p.read_text(encoding='utf-8')
    for old,new in [('; the ','. The '),('; this ','. This '),('; it ','. It '),('; these ','. These '),('; all ','. All '),('; they ','. They ')]:
        count+=s.count(old);s=s.replace(old,new)
    p.write_text(s,encoding='utf-8')
def expand(name):
    s=(P/name).read_text(encoding='utf-8')
    return re.sub(r'\\input\{([^}]+)\}',lambda m:expand(m[1] if m[1].endswith('.tex') else m[1]+'.tex'),s)
s=expand('main.tex');refs=set()
for x in re.findall(r'\\cite\{([^}]+)\}',s):refs.update(x.split(','))
assert len(refs)==20,len(refs)
print(json.dumps({'reviewed_substitutions':count,'unique_cited_references':len(refs)}))
