"""Mechanical section relocation and data-derived tables/figures for revision."""
from pathlib import Path
import json,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
PKG=Path('C:/Users/15808/Desktop/三维/TriCal5_Submission_20260910')
TEX=PKG/'09_LaTeX_Source_TriCal5'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def esc(s):return str(s).replace('_',r'\_')
def table(name,caption,columns,header,rows,label=None):
    text=[r'\begin{table}[H]\centering\small',r'\caption{'+caption+'}']
    if label:text.append(r'\label{'+label+'}')
    text += [r'\begin{tabular}{'+columns+'}',r'\toprule',header+r'\\',r'\midrule']
    text += [' & '.join(row)+r'\\' for row in rows]
    text += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
    (TEX/'tables'/name).write_text('\n'.join(text),encoding='utf-8')
(TEX/'tables').mkdir(exist_ok=True)
# Move existing material verbatim; all new prose is authored in separate .tex files.
p=TEX/'main.tex';s=p.read_text(encoding='utf-8')
if r'\subsection{Two-layer prediction and coefficient-identifiability analysis}' in s:
    a=s.index(r'\subsection{Two-layer prediction and coefficient-identifiability analysis}');b=s.index(r'\subsection{Single-image use}',a)
    block=s[a:b];block=block[block.index('\n')+1:]
    (TEX/'legacy_profile_methods.tex').write_text(block,encoding='utf-8')
    s=s[:a]+'\\input{profile_method_summary.tex}\n\n'+s[b:]
if r'\subsection{Complete coefficient-ratio prior ablation on the primary dataset}' in s:
    a=s.index(r'\subsection{Complete coefficient-ratio prior ablation on the primary dataset}');b=s.index(r'\subsection{Independent planar test}',a)
    (TEX/'legacy_diagnostics.tex').write_text(s[a:b],encoding='utf-8')
    s=s[:a]+'\\input{historical_diagnostics_summary.tex}\n\n'+s[b:]
if r'\input{robustness_methods.tex}' not in s:s=s.replace(r'\section{Results}',r'\input{robustness_methods.tex}'+'\n\n'+r'\section{Results}')
if r'\input{robustness_results.tex}' not in s:s=s.replace(r'\subsection{Interpretation of detected-face counts}',r'\input{robustness_results.tex}'+'\n\n'+r'\subsection{Interpretation of detected-face counts}')
p.write_text(s,encoding='utf-8')
precision=read(ROOT/'output/experiment_0820_precision_test/analysis.json')
poses=list(dict.fromkeys(r['pose'] for r in precision));rows=[]
for pose in poses:
    a,b=[next(r for r in precision if r['pose']==pose and r['variant']==v) for v in ['float32','float64']]
    rows.append([esc(pose)]+[f'{r[k]:.3f}' for k in ['planar_rmse','cuboid_rmse'] for r in [a,b]])
table('precision_comparison.tex','Matched P32/D held-out RMSE medians (pixels). Same original five-image membership; all ten fits passed their development gates. This is not a replacement of the historical L tables.','lrrrr',r'Config. & Planar P32 & Planar D & Cuboid P32 & Cuboid D',rows,'tab:precision')
rows=[]
for r in precision:
    if r['variant']!='float64':continue
    rows.append([esc(r['pose']),f"{r['dist'][0]:.5f}",f"{r['dist'][1]:.5f}",f"{r['cuboid_p95']:.3f}",f"{r['length_median_pct']:.3f}",f"{r['length_p95_pct']:.3f}"])
table('precision_tails.tex','Corrected D coefficients and cuboid error tails. Lengths are target-internal constraints, not independent metrology.','lrrrrr',r'Config. & $k_1$ & $k_2$ & RMSE P95 (px) & Length med. (\%) & Length P95 (\%)',rows)
groups=[]
for directory,name in [('experiment_0820_stability_curve','budget_unfiltered.tex'),('experiment_0820_quality_curve','budget_filtered.tex')]:
    gg=read(ROOT/'output'/directory/'analysis.json')['groups']
    if not groups:groups=gg
    lines=[r'\begin{small}',r'\begin{longtable}{lrrrrll}',r'\caption{'+('Unfiltered' if 'unfiltered' in name else 'Quality-screened')+r' exploratory budgets. U: unique subsets; C/A: completed/accepted runs. RMSE medians [ranges] are in pixels.}\\',r'\toprule Config. & $n$ & U & C/3 & A/3 & Planar & Cuboid\\\midrule\endfirsthead',r'\toprule Config. & $n$ & U & C/3 & A/3 & Planar & Cuboid\\\midrule\endhead',r'\bottomrule\endfoot']
    for g in gg:
        def fmt(v):return '--' if v is None else f"{v['median']:.3f} [{v['min']:.3f}, {v['max']:.3f}]"
        lines.append(' & '.join([esc(g['pose']),str(g['n']),str(g['unique_subsets']),str(g['completed']),str(g['accepted']),fmt(g['2D']),fmt(g['3D'])])+r'\\')
    lines += [r'\end{longtable}',r'\end{small}'];(TEX/'tables'/name).write_text('\n'.join(lines),encoding='utf-8')
fig,axes=plt.subplots(3,5,figsize=(14,7.6),sharex='col')
for c,pose in enumerate(poses):
    gg=[g for g in groups if g['pose']==pose];xx=[g['n'] for g in gg]
    for row,kind in enumerate(['2D','3D']):
        ax=axes[row,c];ax.plot(xx,[g[kind]['median'] if g[kind] else np.nan for g in gg],'o-',lw=1,color='#236b8e',ms=3)
        ax.fill_between(xx,[g[kind]['min'] if g[kind] else np.nan for g in gg],[g[kind]['max'] if g[kind] else np.nan for g in gg],alpha=.18,color='#236b8e');ax.grid(alpha=.2)
        if c==0:ax.set_ylabel(kind+' RMSE (px)')
    axes[0,c].set_title(pose,fontsize=10)
    ax=axes[2,c];ax.plot(xx,[g['completed'] for g in gg],'s--',label='Completed',ms=3);ax.plot(xx,[g['accepted'] for g in gg],'o-',label='Accepted',ms=3);ax.set_ylim(-.1,3.2);ax.set_yticks([0,1,2,3]);ax.set_xticks(xx);ax.set_xlabel('Images');ax.grid(alpha=.2)
    if c==0:ax.set_ylabel('Runs / 3');ax.legend(fontsize=7)
fig.tight_layout();fig.savefig(TEX/'figures/budget_audit.png',dpi=210);plt.close(fig)
old=read(ROOT/'output/experiment_0820_stability_curve/analysis.json')['groups'];sparse=read(ROOT/'output/experiment_0820_sparse_observation_test/matched_analysis.json');rows=[]
for pose in poses[1:]:
    g=next(x for x in old if x['pose']==pose and x['n']==5);rr=[x for x in sparse if x['pose']==pose]
    rows.append([esc(pose),f"{g['completed']}/{g['accepted']}",f"{sum(x['completed'] for x in rr)}/{sum(x['accepted'] for x in rr)}",f"{g['2D']['median']:.3f}/{np.median([x['planar_rmse'] for x in rr if x['completed']]):.3f}",f"{g['3D']['median']:.3f}/{np.median([x['cuboid_rmse'] for x in rr if x['completed']]):.3f}"])
table('sparse_comparison.tex','Twelve paired sparse-observation fits on expanded five-image subsets. C/A counts are completed/accepted out of three; error pairs are original/sparse. Different completion counts induce selection effects.','lllll',r'Config. & Original C/A & Sparse C/A & Planar (px) & Cuboid (px)',rows)
inliers=read(ROOT/'output/precision_fix_20260912/inlier_transfer/analysis.json');rows=[]
for r in inliers:
    rows.append([esc(r['pose']),'all' if r['variant']=='sparse_all' else 'inliers','yes' if r['accepted'] else 'no',f"{r['train_rmse']:.3f}",f"{r['planar_rmse']:.3f}",f"{r['cuboid_rmse']:.3f}"])
table('inlier_comparison.tex','Original-pool five-image sparse fits: all accepted-face points versus mask propagation. Both variants use float64; rejected candidates remain diagnostic.','lllrrr',r'Config. & Points & Accepted & Train (px) & Planar (px) & Cuboid (px)',rows)
table('evidence_inventory.tex','Scope of archived follow-up experiments. Counts denote requested training fits, not necessarily accepted models.',r'p{.32\linewidth}rp{.49\linewidth}',r'Study & Fits & Interpretation',[
['Single-image diagnostics','9','Three k1-only and six two-coefficient candidates; different joint rigid formulation.'],
['Original four/five-image control','30','25 deletion subsets and five full sets; historical solver.'],
['OpenCV planar budgets','55','Five repeats at 5/10 images and one full 20-image fit per configuration; not MATLAB.'],
['Expanded trihedral budgets','81','Three nested orders and feasible budgets; reused-image exploration.'],
['Quality-screened budgets','69','Same validation membership; removes zero-homography training images.'],
['Sparse five-image support','12','Matched expanded subsets; no synthetic corners.'],
['P32/D precision comparison','10','Original five-image sets; only refinement precision changes.'],
['Corrected-source regression','5','Numerical agreement with D, not independent replications.'],
['Sparse mask propagation','10','Original five-image sets; separate undeployed branches.']])
shutil.copy2(ROOT/'output/precision_fix_20260912/geometry_450827/t_3_34_diagnostic.jpg',TEX/'figures/geometry_audit.jpg')
print('sections moved; data tables and audit figures generated')
