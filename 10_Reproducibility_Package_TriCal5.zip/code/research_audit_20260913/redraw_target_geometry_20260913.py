"""Redraw the illustration without changing calibration coordinates."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
P=Path('C:/Users/15808/Desktop/三维/TriCal5_Submission_20260910/09_LaTeX_Source_TriCal5/figures')
fig,ax=plt.subplots(figsize=(7.2,6.1));ax.set_aspect('equal');ax.axis('off')
O=np.array([0.,0.]);X=np.array([-3.2,1.25]);Y=np.array([2.2,1.1]);Z=np.array([0.,-2.4])
faces=[([O,X,X+Y,Y],'#d9edf7','XOY (top)\n9 x 6',(-.45,1.05)),([O,Z,X+Z,X],'#fce8d5','XOZ (front)\n9 x 6',(-1.65,-.65)),([O,Y,Y+Z,Z],'#e4f2df','YOZ (side)\n7 x 6',(1.12,-.68))]
for poly,color,label,center in faces:
    ax.add_patch(Polygon(poly,facecolor=color,edgecolor='#264653',lw=1.6))
    ax.text(*center,label,ha='center',va='center',fontsize=12,linespacing=1.6)
ax.plot(*O,'o',color='#162c3a',ms=4);ax.text(.08,.14,'O',fontsize=11)
for end,label,pos in [(X,'+X',X+[-.38,.10]),(Y,'+Y',Y+[.13,.12]),(Z,'+Z',Z+[.13,-.28])]:
    ax.annotate('',xy=end*1.08,xytext=O,arrowprops=dict(arrowstyle='->',lw=1.5,color='#264653'))
    ax.text(*pos,label,fontsize=11,color='#264653')
def dim(a,b,label,offset):
    a=np.array(a);b=np.array(b);d=np.array(offset)
    for q in [a,b]:ax.plot([q[0],q[0]+d[0]],[q[1],q[1]+d[1]],color='.5',lw=.7)
    ax.annotate('',xy=b+d,xytext=a+d,arrowprops=dict(arrowstyle='<->',lw=.9,color='.3'))
    ax.text(*((a+b)/2+d),label,ha='center',va='center',fontsize=10,bbox=dict(fc='white',ec='none',pad=2))
dim(Y,X+Y,'320 mm',(0,.45));dim(X,X+Y,'220 mm',(-.4,.45));dim(Y,Y+Z,'240 mm',(.65,0))
ax.text(-.5,-3.15,'Inner-corner counts; square pitch: 25 mm',ha='center',fontsize=11)
ax.text(-.5,-3.47,'Illustration frame; sticker offsets are not drawn to scale',ha='center',fontsize=9,color='.3')
ax.set_xlim(-4.0,3.25);ax.set_ylim(-3.7,3.05);fig.tight_layout()
fig.savefig(P/'target_geometry.png',dpi=300,bbox_inches='tight');plt.close(fig)
