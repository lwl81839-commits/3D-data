"""Copy compact evidence and rebuild the user's existing submission bundle."""
from pathlib import Path
import hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1]
PKG=Path('C:/Users/15808/Desktop/三维/TriCal5_Submission_20260910')
TEX=PKG/'09_LaTeX_Source_TriCal5'
DATA=PKG/'11_Processed_Data_TriCal5/research_audit_20260913'
CODE=PKG/'10_Reproducibility_Package_TriCal5/code/research_audit_20260913'
experiments=['single_frame_k1_experiment','single_frame_k1k2_experiment','experiment_0820_planar_budget','experiment_0820_trical_sample_count','experiment_0820_stability_curve','experiment_0820_quality_curve','experiment_0820_sparse_observation_test','experiment_0820_precision_test','precision_fix_20260912']
scripts=['run_0820_stability_curve.py','scan_0820_expanded_pool.py','evaluate_stability_curve_planar.py','summarize_0820_stability_curve.py','run_0820_quality_curve.py','run_0820_sparse_observation_test.py','run_0820_precision_test.py','audit_radial_finite_difference_precision.py','summarize_0820_followup_tests.py','verify_precision_fix_20260912.py','diagnose_450827_geometry.py','run_0820_inlier_transfer_test.py','summarize_precision_fix_20260912.py']
DATA.mkdir(parents=True,exist_ok=True);CODE.mkdir(parents=True,exist_ok=True)
copied=[]
for name in experiments:
    src=ROOT/'output'/name
    for p in src.rglob('*'):
        if not p.is_file():continue
        rel=p.relative_to(src)
        if any('cache' in part.lower() or part in {'validation','__pycache__'} for part in rel.parts):continue
        if p.suffix.lower() not in {'.json','.md','.csv','.py','.png','.jpg','.txt','.pdf'}:continue
        target=DATA/name/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);copied.append(str(target.relative_to(DATA)))
for name in scripts:
    p=ROOT/name
    if p.exists():shutil.copy2(p,CODE/name)
for p in (ROOT/'output').glob('*20260913*.py'):shutil.copy2(p,CODE/p.name)
shutil.copy2(ROOT/'trained_camera_model.py',CODE/'trained_camera_model_precision_fixed.py')
shutil.copy2(ROOT/'output/precision_fix_20260912/trained_camera_model.before.py',CODE/'trained_camera_model_before_precision_fix.py')
legacy=ROOT/'output/manuscript_revision_20260912/before/04_Supplementary_Appendix.pdf'
shutil.copy2(legacy,DATA/'historical_v5_technical_report.pdf')
shutil.copy2(TEX/'REVISION_20260913.md',DATA/'README.md')
# Shared source snapshots stay frozen; replacement names are explicit.
shutil.copy2(TEX/'REVISION_20260913.md',CODE/'README.md')
shutil.copy2(TEX/'main.pdf',PKG/'02_Main_Manuscript_TriCal5.pdf')
shutil.copy2(TEX/'supplement.pdf',PKG/'04_Supplementary_Appendix.pdf')
for name in ['09_LaTeX_Source_TriCal5','10_Reproducibility_Package_TriCal5','11_Processed_Data_TriCal5']:
    with zipfile.ZipFile(PKG/(name+'.zip'),'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted((PKG/name).rglob('*')):
            if p.is_file():z.write(p,p.relative_to(PKG/name))
files=[]
for p in sorted(PKG.rglob('*')):
    if p.is_file() and p.name!='file_manifest.json':
        files.append(dict(path=p.relative_to(PKG).as_posix(),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(PKG/'file_manifest.json').write_text(json.dumps(files,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(dict(compact_files=len(copied),manifest_files=len(files),zip_bytes={p.name:p.stat().st_size for p in PKG.glob('*.zip')}),indent=2))
