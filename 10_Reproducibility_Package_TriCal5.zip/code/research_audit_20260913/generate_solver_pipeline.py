from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
out=Path('C:/Users/15808/Desktop/三维/TriCal5_Submission_20260910/09_LaTeX_Source_TriCal5/figures/solver_pipeline.png')
fig,ax=plt.subplots(figsize=(11.5,2.3));ax.set_xlim(0,11.5);ax.set_ylim(0,2.3);ax.axis('off')
texts=['Valid indexed\nface observations\n(input prerequisite)','Shared intrinsics\nfrom local planar\nmetric constraints','Regularized k1 + k2\nwith K fixed and\nlocal-plane poses','Frozen camera\nfor new-image pose\nand held-out prediction']
for i,text in enumerate(texts):
    x=.15+i*2.88;color='#eaf2f8' if i in [1,2] else '#f0f0f0';edge='#28628d' if i in [1,2] else '#888888'
    ax.add_patch(FancyBboxPatch((x,.66),2.55,1.12,boxstyle='round,pad=0.04',fc=color,ec=edge,lw=1.3))
    ax.text(x+1.275,1.22,text,ha='center',va='center',fontsize=10,color='#1c2933',linespacing=1.45)
    if i<3:ax.annotate('',xy=(x+2.8,1.22),xytext=(x+2.61,1.22),arrowprops=dict(arrowstyle='->',lw=1.3,color='#566675'))
ax.text(5.86,2.02,'Core: camera-specific parameter estimation',ha='center',fontsize=11,color='#28628d',weight='bold')
ax.text(5.75,.22,'Same correspondence input for controlled evaluation; reference parameters excluded from fitting',ha='center',fontsize=9,color='#555555')
fig.tight_layout(pad=.1);fig.savefig(out,dpi=240,bbox_inches='tight');plt.close(fig)
