# Bibliography audit and manuscript positioning

Exactly 20 unique references are cited in the manuscript; no uncited padding was added. The nine established entries were retained, and eleven relevant works were added. The additions cover plane-calibration degeneracy, joint geometric optimization, distortion parameterizations, observation design, generic camera models, robust calibration, bias/uncertainty and recent geometric-learning calibration. No claim is made that these systems were benchmarked in our experiments.

## Primary verification sources for the added works

- Sturm and Maybank (CVPR 1999): [author-hosted paper](https://perception.inrialpes.fr/Publications/1999/SM99a/SturmMaybank-cvpr99.pdf). Supports plane-calibration constraints and singular configurations, not a trihedral-specific minimum count.
- Triggs et al. (2000): [author-hosted publication](https://thoth.inrialpes.fr/people/triggs/pubs/Triggs-hdr-papers.pdf). General robust bundle-adjustment and nuisance-variable framework; our staged solver is not described as full rigid joint BA.
- Fitzgibbon (CVPR 2001): [Oxford publication record](https://www.robots.ox.ac.uk/~vgg/publications/2001/Fitzgibbon01b/). Alternative distortion-aware geometry; not the same polynomial model used here.
- Kannala and Brandt (TPAMI 2006): [DOI](https://doi.org/10.1109/TPAMI.2006.153). Generic conventional/wide-angle/fisheye camera formulation.
- Ha et al. (ICCV 2017): [CMU publication record](https://publications.ri.cmu.edu/deltille-grids-for-geometric-camera-calibration). Supporting target/localization work, not the manuscript's main novelty.
- Peng and Sturm (ICCV 2019): [CVF proceedings](https://openaccess.thecvf.com/content_ICCV_2019/html/Peng_Calibration_Wizard_A_Guidance_System_for_Camera_Calibration_Based_on_ICCV_2019_paper.html). Geometry/corner uncertainty and informative pose selection; does not prescribe uniform target centers.
- Schoeps et al. (CVPR 2020): [CVF paper](https://openaccess.thecvf.com/content_CVPR_2020/papers/Schops_Why_Having_10000_Parameters_in_Your_Camera_Model_Is_Better_CVPR_2020_paper.pdf). Generic camera models and downstream bias. The publication year is 2020, not its 2019 preprint year.
- Lochman et al. (ICCV 2021): [CVF proceedings](https://openaccess.thecvf.com/content/ICCV2021/html/Lochman_BabelCalib_A_Universal_Approach_to_Calibrating_Central_Cameras_ICCV_2021_paper.html). Robust initialization across central camera models and downstream validation.
- Hagemann et al. (IJCV 2022): [author institution record](https://publikationen.bibliothek.kit.edu/1000139371), [DOI](https://doi.org/10.1007/s11263-021-01528-x). Bias versus variance, resampling and camera-model-independent uncertainty. Online publication precedes the 2022 journal volume.
- Veicht et al. (ECCV 2024): [official proceedings paper](https://www.ecva.net/papers/eccv_2024/papers_ECCV/papers/05636.pdf). Learning combined with geometric single-image optimization, contrasted with the present target-conditioned estimation.
- Huai et al. (Sensors 2024): [publisher record and comparative study](https://www.mdpi.com/1424-8220/24/20/6595). Model/toolchain comparison, not evidence that the current method outperforms those tools.

The retained foundation consists of Tsai (1987), Zhang (2000), Brown (1966), Heikkila and Silven (1997), Caprile and Torre (1990), Grammatikopoulos et al. (2007), Wang et al. (2005), Fischler and Bolles (1981), and Hartley and Zisserman (2004). Existing metadata and DOI fields are preserved. Missing page fields in added conference references were not guessed.
