"""0820 five-image ablation: remove only radial coefficient ratio penalty."""
from pathlib import Path
import os,sys,json,shutil,hashlib,subprocess,time,csv
from concurrent.futures import ThreadPoolExecutor,as_completed

ROOT=Path(__file__).resolve().parent
SPLIT=Path('E:/Data_image_3d/data_3D_0820_split_model_3D5_Zhang2D20_each_pose_quality_gated')
BASE=SPLIT/'validation_ours_vs_zhang'
FULL_REMOVAL=os.environ.get('ABLATION_REMOVE_ALL_RATIO')=='1'
OUT=ROOT/('output/ablation_0820_no_ratio_constraint' if FULL_REMOVAL else 'output/ablation_0820_no_ratio_prior')
POSES=['15_0.528','30_0.827','45_0.827','45_1.155','60_1.155']
OUT.mkdir(parents=True,exist_ok=True)

def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')

def prepare():
    source=(ROOT/'trained_camera_model.py').read_text(encoding='utf-8')
    old='''                max(0.0, abs(k2) - allowed_k2)
                / K2_COEFFICIENT_HINGE_SIGMA'''
    assert source.count(old)==1
    modified=source.replace(old,'                0.0  # Ablation: coefficient-ratio penalty disabled')
    if FULL_REMOVAL:
        start=modified.index('        initial_k2_limit = (')
        end=modified.index('    for rvec, tvec in zip(initial_rvecs, initial_tvecs):',start)
        modified=modified[:start]+'''        values.append(float(np.clip(initial_dist[1], -K2_OPTIMIZATION_BOUND, K2_OPTIMIZATION_BOUND)))
'''+modified[end:]
        modified=modified.replace('"k2_raw_coefficient_ratio_constraint": "soft"','"k2_raw_coefficient_ratio_constraint": "none"')
    modified=modified.replace('"method": "k2_to_k1_coefficient_ratio_soft_hinge",','"method": "ratio_penalty_disabled_monotonicity_retained",\n        "coefficient_ratio_penalty_enabled": False,')
    code=OUT/'code'; code.mkdir(exist_ok=True)
    (code/'trained_camera_model.py').write_text(modified,encoding='utf-8')
    shutil.copy2(ROOT/'trained_camera_model.py',code/'trained_camera_model_original.py')
    manifest=[]
    for pose in POSES:
        images=sorted((SPLIT/'train'/pose/'3D').glob('*.jpg')); assert len(images)==5
        model=OUT/'per_pose_models'/pose; cache=model/'.trihedral_correspondence_cache'; cache.mkdir(parents=True,exist_ok=True)
        for im in images:
            digest=hashlib.sha256(im.read_bytes()).hexdigest()
            found=list((BASE/'per_pose_models'/pose/'.trihedral_correspondence_cache').glob(digest+'_sq25_*.npz'))
            assert len(found)==1,(pose,im,found)
            shutil.copy2(found[0],cache/found[0].name)
            manifest.append(dict(pose=pose,image=str(im),sha256=digest,cache_sha256=hashlib.sha256(found[0].read_bytes()).hexdigest()))
    save(OUT/'protocol.json',dict(dataset=str(SPLIT),training_images=manifest,change='Replace coefficient-ratio hinge residual with zero in every final fit and LOO fold',preserved=['five images per configuration','train/test membership','cached corner geometry','k1 and k2 freely estimated','radial coefficient numeric bounds','radial monotonicity penalty','principal point and aspect priors','ratio-based initial clipping (initialization only)','optimizer and validation gates'],source_sha256=hashlib.sha256(source.encode()).hexdigest(),ablation_source_sha256=hashlib.sha256(modified.encode()).hexdigest(),zhang_used_in_training=False))
    shutil.copy2(BASE/'zhang_parameters.csv',OUT/'zhang_parameters.csv')
    if FULL_REMOVAL:
        protocol=json.loads((OUT/'protocol.json').read_text(encoding='utf-8'))
        protocol['change']='Remove all coefficient-ratio initialization clipping and optimization penalty in final fit and every LOO fold'
        protocol['preserved'].remove('ratio-based initial clipping (initialization only)')
        protocol['initialization_ratio_clipping_retained']=False
        save(OUT/'protocol.json',protocol)
    # Run the existing planar evaluator, adding the original model as a third comparator.
    planar=(ROOT/'evaluate_planar_per_pose_controlled.py').read_text(encoding='utf-8')
    planar=planar.replace('validation = split / "validation_ours_vs_zhang"','validation = Path('+repr(str(OUT))+')')
    needle='models = {"ours_3d_5_images": (ours_K, ours_dist), "zhang_matlab_20_images": (zhang_K, zhang_dist)}'
    assert planar.count(needle)==1
    planar=planar.replace(needle,needle+'\n        base_K, base_dist, _ = camera_from_model(Path('+repr(str(BASE))+') / "per_pose_models" / pose / "trained_camera_model.json")\n        models["with_ratio_prior"] = (base_K, base_dist)')
    (code/'evaluate_planar_ablation.py').write_text(planar,encoding='utf-8')

def train_one(pose):
    sys.path.insert(0,str(OUT/'code'))
    import trained_camera_model as tm
    assert 'ablation_0820' in tm.__file__
    images=sorted((SPLIT/'train'/pose/'3D').glob('*.jpg'))
    target=OUT/'per_pose_models'/pose/'trained_camera_model.json'
    start=time.perf_counter()
    try:
        m=tm.train_camera_model([str(p) for p in images],25,str(target),distortion_model='k1_k2',progress=lambda x:print(x,flush=True))
        m['ablation']={'coefficient_ratio_penalty_enabled':False,'initialization_ratio_clipping_retained':not FULL_REMOVAL,'monotonicity_retained':True}
        m['training_method']='partial_face_homographies_without_ratio_penalty_and_cuboid_validation'
        tm.save_camera_model(m,str(target))
        save(target.parent/'run_status.json',{'pose':pose,'completed':True,'accepted':m['accepted'],'elapsed_s':time.perf_counter()-start,'cameraMatrix':m['cameraMatrix'],'distCoeffs':m['distCoeffs']})
    except Exception as e:
        import traceback
        save(target.parent/'run_status.json',{'pose':pose,'completed':False,'error':str(e),'traceback':traceback.format_exc()})
        raise

def runjob(name,args):
    log=OUT/'logs'; log.mkdir(exist_ok=True)
    env=os.environ.copy(); env.update(PYTHONPATH=str(ROOT),PYTHONIOENCODING='utf-8',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    start=time.perf_counter()
    with (log/(name+'.log')).open('w',encoding='utf-8') as f:
        p=subprocess.run([sys.executable,*map(str,args)],cwd=str(ROOT),env=env,stdout=f,stderr=subprocess.STDOUT)
    result=dict(job=name,returncode=p.returncode,elapsed_s=time.perf_counter()-start)
    print(json.dumps(result),flush=True); return result

def main():
    prepare()
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(runjob,'train_'+p,[__file__,'train',p]) for p in POSES]
        runs=[f.result() for f in as_completed(futures)]
    save(OUT/'training_jobs.json',runs)
    if any(x['returncode'] for x in runs): raise RuntimeError('Training execution failed; inspect logs')
    jobs=[]
    for pose in POSES:
        for method,model in [('without_ratio_prior',OUT/'per_pose_models'/pose/'trained_camera_model.json'),('with_ratio_prior',BASE/'per_pose_models'/pose/'trained_camera_model.json')]:
            args=[ROOT/'evaluate_trained_camera_model.py','--model',model,'--images',SPLIT/'test'/pose/'3D','--output-dir',OUT/'final_test_evaluation'/pose/method,'--correspondence-cache-dir',BASE/'test_correspondence_cache'/pose,'--only-existing-cache','--repeats','20','--allow-unaccepted-model']
            jobs.append((pose+'_'+method,args))
    jobs.append(('all_planar',[OUT/'code/evaluate_planar_ablation.py','--split-root',SPLIT,'--repeats','20']))
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(runjob,n,a) for n,a in jobs]
        tests=[f.result() for f in as_completed(futures)]
    save(OUT/'test_jobs.json',tests)
    if any(x['returncode'] for x in tests): raise RuntimeError('Some tests failed; inspect logs')

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='train': train_one(sys.argv[2])
    else: main()
