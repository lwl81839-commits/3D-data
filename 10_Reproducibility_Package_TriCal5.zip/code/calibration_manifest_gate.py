#!/usr/bin/env python3
"""Final stability-manifest gate for production calibration entry points."""

from __future__ import annotations

import csv
import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any


# Measured physical inner-corner counts (OpenCV convention).
CANONICAL_FACE_PATTERNS = [(9, 6), (9, 6), (7, 6)]


@dataclass
class StabilityGateResult:
    matched: bool
    accepted: bool = False
    rel_path: str = ""
    final_decision: str = ""
    baseline_decision: str = ""
    stress_decision: str = ""
    reasons: str = ""
    corners_path: Path | None = None
    face_patterns: list[tuple[int, int]] | None = None
    focal_px: float | None = None
    manifest_path: Path | None = None
    audit_path: Path | None = None

    @property
    def available_for_calibration(self) -> bool:
        return self.matched and self.accepted and self.corners_path is not None


def _base_dir() -> Path:
    return Path(__file__).resolve().parent


def _path_from_env(name: str, default: Path) -> Path:
    raw = os.environ.get(name)
    return Path(raw).expanduser() if raw else default


def _default_project_path(*parts: str) -> Path:
    candidates = [
        _base_dir(),
        Path.cwd(),
        Path(sys.executable).resolve().parent,
        Path(sys.executable).resolve().parent.parent,
    ]
    for base in candidates:
        candidate = base.joinpath(*parts)
        if candidate.exists():
            return candidate
    return Path.cwd().joinpath(*parts)


def default_manifest_path() -> Path:
    return _path_from_env(
        "CALIB_STABILITY_MANIFEST",
        _default_project_path(
            "batch_results",
            "single_frame_stability_audit_v20_grid_expand_release",
            "final_stability_manifest.json",
        ),
    )


def default_audit_path() -> Path:
    return _path_from_env(
        "CALIB_STABILITY_AUDIT",
        _default_project_path(
            "batch_results",
            "single_frame_stability_audit_v10_full",
            "single_frame_stability_audit.csv",
        ),
    )


def default_corners_root() -> Path:
    return _path_from_env(
        "CALIB_STABILITY_CORNERS_ROOT",
        _default_project_path(
            "batch_results",
            "sam_three_face_hypothesis_remote_v10_full_baseline",
            "corners",
        ),
    )


def default_image_root() -> Path:
    return _path_from_env(
        "CALIB_IMAGE_ROOT",
        _default_project_path("材料_extracted", "shengkelou"),
    )


def _normalize_rel(value: Any) -> str:
    return str(value or "").replace("\\", "/").strip("/")


def _normalize_face_patterns(value: Any) -> list[tuple[int, int]] | None:
    if not isinstance(value, list):
        return None
    out: list[tuple[int, int]] = []
    try:
        for pat in value:
            if not isinstance(pat, (list, tuple)) or len(pat) != 2:
                return None
            out.append((int(pat[0]), int(pat[1])))
    except Exception:
        return None
    return out or None


def _finite_float(value: Any) -> float | None:
    try:
        out = float(value)
    except Exception:
        return None
    return out if np_isfinite(out) else None


def np_isfinite(value: float) -> bool:
    return value == value and value not in {float("inf"), float("-inf")}


def _accepted_decision(decision: str) -> bool:
    return decision in {
        "stable_pass",
        "accept",
        "partial_sparse_pass",
        "alternate_strict_pass",
        "ideal_axis_pass",
        "crop_replace_pass",
        "crop_scale_sparse_pass",
        "crop_complete_pass",
        "crop_local_k1_pass",
        "relaxed_axis_replay_pass",
        "grid_expand_pass",
        "grid_recovery_replay_pass",
    }


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _load_audit_rows(path: Path) -> dict[str, dict[str, str]]:
    if not path.exists():
        return {}
    with path.open("r", newline="", encoding="utf-8") as f:
        return {
            _normalize_rel(row.get("rel_path")): row
            for row in csv.DictReader(f)
            if _normalize_rel(row.get("rel_path"))
        }


def _image_rel_candidates(image_path: Path, image_root: Path | None) -> list[str]:
    try:
        resolved = image_path.resolve()
    except OSError:
        resolved = image_path.absolute()
    candidates: list[str] = []
    if image_root is not None:
        try:
            try:
                resolved_root = image_root.resolve()
            except OSError:
                resolved_root = image_root.absolute()
            candidates.append(_normalize_rel(resolved.relative_to(resolved_root)))
        except ValueError:
            pass
    parts = resolved.parts
    if len(parts) >= 2:
        candidates.append(_normalize_rel(Path(parts[-2]) / parts[-1]))
    if parts:
        candidates.append(_normalize_rel(parts[-1]))
    out: list[str] = []
    for candidate in candidates:
        if candidate and candidate not in out:
            out.append(candidate)
    return out


def _resolve_existing_path(value: Any, base_dirs: list[Path]) -> Path | None:
    raw_text = str(value or "")
    if not raw_text:
        return None
    raw = Path(raw_text)
    candidates = [raw]
    if not raw.is_absolute():
        candidates.extend(base / raw for base in base_dirs)
    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()
    return None


def _resolve_corners_path(
    item: dict[str, Any],
    *,
    manifest_dir: Path,
    corners_root: Path | None,
) -> Path | None:
    for key in ("local_corners_path", "corners_path"):
        found = _resolve_existing_path(item.get(key), [_base_dir(), manifest_dir])
        if found is not None:
            return found
    if corners_root is None:
        return None
    raw = str(item.get("corners_path") or "")
    if raw:
        candidate = corners_root / Path(raw.replace("\\", "/")).name
        if candidate.exists():
            return candidate.resolve()
    rel = _normalize_rel(item.get("rel_path"))
    if rel:
        stem = rel.replace("/", "__").rsplit(".", 1)[0]
        matches = sorted(corners_root.glob(f"{stem}*.npz"))
        if matches:
            return matches[0].resolve()
    return None


def default_image_root() -> Path:
    raw = os.environ.get("CALIB_IMAGE_ROOT")
    if raw:
        return Path(raw).expanduser()
    for base in [
        _base_dir(),
        Path.cwd(),
        Path(sys.executable).resolve().parent,
        Path(sys.executable).resolve().parent.parent,
    ]:
        matches = sorted(base.glob("*_extracted/shengkelou"))
        if matches:
            return matches[0]
    return Path.cwd()


def stability_gate_for_image(
    image_path: str | Path,
    *,
    manifest_path: Path | None = None,
    audit_path: Path | None = None,
    corners_root: Path | None = None,
    image_root: Path | None = None,
) -> StabilityGateResult:
    """Return the final stability decision for an image when it was audited.

    Missing manifest/audit files are treated as "not matched" so the caller can
    fall back to the regular automatic pipeline.
    """
    manifest = manifest_path or default_manifest_path()
    audit = audit_path or default_audit_path()
    corners = corners_root or default_corners_root()
    root = image_root or default_image_root()

    if not manifest.exists() and not audit.exists():
        return StabilityGateResult(matched=False)

    accepted_items: dict[str, dict[str, Any]] = {}
    if manifest.exists():
        manifest_data = _load_json(manifest)
        for item in manifest_data.get("accepted", []):
            rel = _normalize_rel(item.get("rel_path"))
            if rel:
                accepted_items[rel] = item

    audit_rows = _load_audit_rows(audit)
    for rel in _image_rel_candidates(Path(image_path), root):
        item = accepted_items.get(rel)
        row = audit_rows.get(rel, {})
        if item is not None:
            final_decision = str(item.get("decision") or row.get("final_decision") or "")
            fx = _finite_float(item.get("fx_px"))
            fy = _finite_float(item.get("fy_px"))
            focal_px = None
            if fx is not None and fy is not None:
                focal_px = 0.5 * (fx + fy)
            elif fx is not None:
                focal_px = fx
            elif fy is not None:
                focal_px = fy
            return StabilityGateResult(
                matched=True,
                accepted=_accepted_decision(final_decision),
                rel_path=rel,
                final_decision=final_decision,
                baseline_decision=str(row.get("baseline_decision") or ""),
                stress_decision=str(row.get("stress_decision") or ""),
                reasons=str(item.get("decision_reasons") or row.get("final_reasons") or ""),
                corners_path=_resolve_corners_path(
                    item,
                    manifest_dir=manifest.parent,
                    corners_root=corners if corners.exists() else None,
                ),
                face_patterns=_normalize_face_patterns(
                    item.get("face_patterns")
                ) or CANONICAL_FACE_PATTERNS,
                focal_px=focal_px,
                manifest_path=manifest if manifest.exists() else None,
                audit_path=audit if audit.exists() else None,
            )
        if row:
            return StabilityGateResult(
                matched=True,
                accepted=False,
                rel_path=rel,
                final_decision=str(row.get("final_decision") or ""),
                baseline_decision=str(row.get("baseline_decision") or ""),
                stress_decision=str(row.get("stress_decision") or ""),
                reasons=str(row.get("final_reasons") or row.get("baseline_reasons") or ""),
                manifest_path=manifest if manifest.exists() else None,
                audit_path=audit if audit.exists() else None,
            )
    return StabilityGateResult(matched=False)


def stability_hold_message(gate: StabilityGateResult) -> str:
    parts = [
        gate.rel_path or "matched image",
        f"final_decision={gate.final_decision or 'held'}",
    ]
    if gate.baseline_decision:
        parts.append(f"baseline={gate.baseline_decision}")
    if gate.stress_decision:
        parts.append(f"stress={gate.stress_decision}")
    if gate.reasons:
        parts.append(gate.reasons)
    return "Stability manifest hold: " + "; ".join(parts)
