from __future__ import annotations

import json
import shutil
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


from pipeline_config import AUDIT_ROOT, PIPELINE_DIR, POSES, PYTHON_EXE, SOURCE_ROOT, SPLIT_ROOT, VALIDATION_ROOT

SOURCE = SOURCE_ROOT
SPLIT = SPLIT_ROOT
VALIDATION = VALIDATION_ROOT
AUDIT = AUDIT_ROOT
OUTPUT = VALIDATION / "test_correspondence_cache"
PROBE = PIPELINE_DIR / "track_cache_probe.py"
PYTHON = PYTHON_EXE
LOCK = threading.Lock()


def image_index(path: Path) -> int:
    return int(path.stem.rsplit("_", 1)[1])


def cache_name(cache: Path) -> str:
    return cache.name


def load_seed_rows() -> list[dict]:
    rows: list[dict] = []
    for name in ("exact_gate_results.json", "tracking_gate_results.json"):
        path = AUDIT / name
        if path.is_file():
            rows.extend(json.loads(path.read_text(encoding="utf-8")))
    return rows


def write_progress(rows: list[dict]) -> None:
    with LOCK:
        (OUTPUT / "cache_build_results.json").write_text(
            json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8"
        )


def process_pose(pose: str, seed_rows: list[dict], all_rows: list[dict]) -> dict:
    pose_output = OUTPUT / pose
    pose_output.mkdir(parents=True, exist_ok=True)
    images = sorted((SOURCE / pose / "3D").glob("*.jpg"), key=image_index)
    test_names = {
        path.name
        for path in (SPLIT / "test" / pose / "3D").glob("*.jpg")
    }
    references: dict[int, dict[str, str]] = {}

    for row in seed_rows:
        if row.get("pose") != pose or row.get("status") != "pass":
            continue
        source = SOURCE / pose / "3D" / str(row.get("image", ""))
        cache = Path(str(row.get("cache", "")))
        if not source.is_file() or not cache.is_file():
            continue
        copied = pose_output / cache_name(cache)
        if not copied.is_file():
            shutil.copy2(cache, copied)
        references[image_index(source)] = {"source": str(source), "cache": str(copied)}

    if not references:
        raise RuntimeError(f"{pose}: no valid seed correspondence cache")

    pending = [path for path in images if path.name in test_names and image_index(path) not in references]
    pose_rows: list[dict] = []
    while pending:
        target = min(
            pending,
            key=lambda path: (
                min(abs(image_index(path) - ref_index) for ref_index in references),
                image_index(path),
            ),
        )
        target_index = image_index(target)
        nearest = sorted(
            references,
            key=lambda value: (abs(value - target_index), value),
        )[:4]
        result: dict = {"status": "fail", "error": "no reference attempted"}
        attempts: list[dict] = []
        started = time.perf_counter()
        for ref_index in nearest:
            reference = references[ref_index]
            try:
                completed = subprocess.run(
                    [
                        str(PYTHON), str(PROBE), reference["source"], reference["cache"],
                        str(target), str(pose_output),
                    ],
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    capture_output=True,
                    timeout=45,
                )
                lines = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
                candidate = json.loads(lines[-1]) if lines else {
                    "status": "error",
                    "error": completed.stderr.strip() or f"exit {completed.returncode}",
                }
            except subprocess.TimeoutExpired:
                candidate = {"status": "timeout", "error": "probe exceeded 45 seconds"}
            except Exception as exc:
                candidate = {"status": "error", "error": str(exc)}
            attempts.append(
                {
                    "reference_index": ref_index,
                    "reference_image": Path(reference["source"]).name,
                    "status": candidate.get("status"),
                    "error": candidate.get("error"),
                }
            )
            result = candidate
            if result.get("status") == "pass":
                references[target_index] = {
                    "source": str(target),
                    "cache": str(result["cache"]),
                }
                break
        result.update(
            {
                "pose": pose,
                "image": target.name,
                "image_index": target_index,
                "is_test": True,
                "attempts": attempts,
                "wall_seconds": time.perf_counter() - started,
            }
        )
        with LOCK:
            all_rows.append(result)
            pose_rows.append(result)
            (OUTPUT / "cache_build_results.json").write_text(
                json.dumps(all_rows, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            print(
                f"{pose} {target.name}: {result.get('status')} "
                f"faces={len(result.get('chosen_face_subset', []))} "
                f"refs={len(references)} dt={result['wall_seconds']:.1f}s",
                flush=True,
            )
        pending.remove(target)

    test_cached = sum(
        1 for path in images
        if path.name in test_names and image_index(path) in references
    )
    return {
        "pose": pose,
        "test_images": len(test_names),
        "test_cached": test_cached,
        "test_failed": len(test_names) - test_cached,
        "new_pass": sum(r.get("status") == "pass" for r in pose_rows),
        "new_fail": sum(r.get("status") != "pass" for r in pose_rows),
    }


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    seed_rows = load_seed_rows()
    all_rows: list[dict] = []
    summaries: list[dict] = []
    with ThreadPoolExecutor(max_workers=len(POSES)) as pool:
        futures = {
            pool.submit(process_pose, pose, seed_rows, all_rows): pose for pose in POSES
        }
        for future in as_completed(futures):
            pose = futures[future]
            try:
                summaries.append(future.result())
            except Exception as exc:
                summaries.append({"pose": pose, "error": str(exc)})
                print(f"ERROR {pose}: {exc}", flush=True)
    summaries.sort(key=lambda row: POSES.index(row["pose"]))
    (OUTPUT / "cache_build_summary.json").write_text(
        json.dumps(summaries, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("SUMMARY " + json.dumps(summaries, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
