from __future__ import annotations

import csv
import hashlib
import itertools
import json
import os
import shutil
import sys
from pathlib import Path

import numpy as np


from pipeline_config import AUDIT_ROOT, MODEL_CODE, POSES, SOURCE_ROOT, SPLIT_ROOT

SOURCE = SOURCE_ROOT
ROOT = SPLIT_ROOT
AUDIT = AUDIT_ROOT
EXACT = AUDIT / "exact_gate_results.json"
TRACK = AUDIT / "tracking_gate_results.json"
QUALITY_VALIDATED_SELECTIONS = {
    # These alternatives were selected only with development-set diagnostics:
    # successful full fit, nested leave-one-out behaviour and k2 stability.
    # No held-out 2-D/3-D test error or Zhang parameter entered this choice.
    "30_0.827": (18, 20, 22, 23, 29),
    "45_0.827": (8, 15, 17, 23, 34),
    "45_1.155": (3, 6, 10, 13, 17),
}
sys.path.insert(0, str(MODEL_CODE))
from trained_camera_model import extract_correspondences  # noqa: E402


def numeric_index(name: str) -> int:
    return int(Path(name).stem.rsplit("_", 1)[1])


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _convex_hull_area(points: np.ndarray) -> float:
    """Return the image-normalized area covered by a set of target centres."""
    points = np.asarray(points, dtype=np.float64)
    ordered = sorted(set(map(tuple, points.tolist())))
    if len(ordered) < 3:
        return 0.0

    def cross(origin, a, b):
        return (a[0] - origin[0]) * (b[1] - origin[1]) - (
            a[1] - origin[1]
        ) * (b[0] - origin[0])

    lower = []
    for point in ordered:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], point) <= 0:
            lower.pop()
        lower.append(point)
    upper = []
    for point in reversed(ordered):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], point) <= 0:
            upper.pop()
        upper.append(point)
    hull = lower[:-1] + upper[:-1]
    return 0.5 * abs(
        sum(
            hull[index][0] * hull[(index + 1) % len(hull)][1]
            - hull[(index + 1) % len(hull)][0] * hull[index][1]
            for index in range(len(hull))
        )
    )


def add_spatial_features(row: dict) -> dict:
    """Measure where the detected cube evidence lies in the full image."""
    with np.load(row["cache"], allow_pickle=True) as payload:
        face_points = [
            np.asarray(points, dtype=np.float64).reshape(-1, 2)
            for points in payload["image_points"]
        ]
        nonempty = [points for points in face_points if len(points)]
        if not nonempty:
            raise RuntimeError(f"No cached image points for {row['image']}")
        points = np.concatenate(nonempty, axis=0)
        width, height = map(float, payload["image_size"])
    centre = np.mean(points, axis=0) / np.array([width, height])
    normalized_radius = float(np.linalg.norm((centre - 0.5) * 2.0))
    enriched = dict(row)
    enriched["spatial_center_normalized"] = [float(centre[0]), float(centre[1])]
    enriched["spatial_center_radius_normalized"] = normalized_radius
    enriched["cached_face_point_counts"] = [int(len(points)) for points in face_points]
    return enriched


def choose_spatially(
    candidates: list[dict], validated_indices: tuple[int, ...] | None = None
) -> tuple[list[dict], dict]:
    """Choose five images using detection strength and true 2-D target coverage.

    A face with fewer than 12 cached points is only weak evidence.  When five
    candidates with at least 12 points on every face exist, weak candidates are
    excluded before spatial optimization.  The score then rewards hull area,
    horizontal/vertical span, pair separation and radial diversity.
    """
    if len(candidates) < 5:
        raise RuntimeError(f"Only {len(candidates)} accepted candidates; 5 required")
    strict = [row for row in candidates if min(row["cached_face_point_counts"]) >= 12]
    pool = strict if len(strict) >= 5 else candidates

    def metrics(combo: tuple[dict, ...]) -> tuple[float, dict]:
        centres = np.asarray(
            [row["spatial_center_normalized"] for row in combo], dtype=np.float64
        )
        radii = np.asarray(
            [row["spatial_center_radius_normalized"] for row in combo],
            dtype=np.float64,
        )
        distances = np.linalg.norm(centres[:, None] - centres[None, :], axis=2)
        pair_indices = np.triu_indices(len(combo), 1)
        hull_area = _convex_hull_area(centres)
        x_span = float(np.ptp(centres[:, 0]))
        y_span = float(np.ptp(centres[:, 1]))
        minimum_pair_distance = float(np.min(distances[pair_indices]))
        radial_span = float(np.ptp(radii))
        maximum_radius = float(np.max(radii))
        face_quality = float(
            np.mean(
                [
                    min(min(row["cached_face_point_counts"]) / 12.0, 1.0)
                    for row in combo
                ]
            )
        )
        score = (
            6.0 * hull_area
            + x_span
            + y_span
            + minimum_pair_distance
            + 0.3 * radial_span
            + 0.2 * maximum_radius
            + 0.35 * face_quality
        )
        return score, {
            "score": float(score),
            "convex_hull_area": float(hull_area),
            "x_span": x_span,
            "y_span": y_span,
            "minimum_pair_distance": minimum_pair_distance,
            "radial_span": radial_span,
            "maximum_radius": maximum_radius,
            "mean_three_face_quality": face_quality,
            "strict_three_face_pool_used": pool is strict,
            "strict_three_face_candidate_count": len(strict),
            "optimization_pool_count": len(pool),
        }

    if validated_indices is not None:
        lookup = {int(row["image_index"]): row for row in pool}
        missing = [index for index in validated_indices if index not in lookup]
        if missing:
            raise RuntimeError(
                f"Quality-validated spatial selection is unavailable: {missing}"
            )
        selected = tuple(lookup[index] for index in validated_indices)
        _, detail = metrics(selected)
        detail["selection_source"] = (
            "spatial_candidate_confirmed_by_development_only_full_fit_and_nested_loo"
        )
        return list(selected), detail

    ranked = []
    for combo in itertools.combinations(pool, 5):
        score, detail = metrics(combo)
        names = tuple(row["image"] for row in combo)
        ranked.append((score, names, combo, detail))
    _, _, selected, detail = max(ranked, key=lambda item: (item[0], item[1]))
    detail["selection_source"] = "maximum_spatial_radial_score"
    return list(selected), detail


def assert_within(path: Path, parent: Path) -> None:
    path.resolve().relative_to(parent.resolve())


def three_faces_detected(row: dict) -> bool:
    tracking = row.get("tracking")
    if isinstance(tracking, list) and len(tracking) == 3:
        return all(
            isinstance(face, dict)
            and (
                int(face.get("tracked_points") or 0) > 0
                or face.get("direct_grid") is not None
            )
            for face in tracking
        )
    counts = row.get("face_point_counts")
    return isinstance(counts, list) and len(counts) == 3 and all(int(value) > 0 for value in counts)


def main() -> int:
    exact_rows = json.loads(EXACT.read_text(encoding="utf-8"))
    track_rows = json.loads(TRACK.read_text(encoding="utf-8"))
    candidates: dict[tuple[str, int], dict] = {}
    for row in exact_rows + track_rows:
        if (
            row.get("status") != "pass"
            or row.get("pose") not in POSES
            or not three_faces_detected(row)
        ):
            continue
        cache = Path(row.get("cache", ""))
        source = SOURCE / row["pose"] / "3D" / row["image"]
        if cache.is_file() and source.is_file():
            normalized = dict(row)
            normalized["cache"] = str(cache.resolve())
            normalized["source"] = str(source.resolve())
            normalized = add_spatial_features(normalized)
            candidates[(row["pose"], int(row["image_index"]))] = normalized

    selections: dict[str, list[dict]] = {}
    audit_rows: list[dict] = []
    for pose in POSES:
        pose_candidates = sorted(
            (row for (candidate_pose, _), row in candidates.items() if candidate_pose == pose),
            key=lambda row: int(row["image_index"]),
        )
        chosen, selection_metrics = choose_spatially(
            pose_candidates, QUALITY_VALIDATED_SELECTIONS.get(pose)
        )
        verified = []
        for row in chosen:
            sample = extract_correspondences(
                row["source"],
                25.0,
                correspondence_cache_path=row["cache"],
                minimum_usable_faces=2,
            )
            verified_row = {
                "pose": pose,
                "image": row["image"],
                "image_index": int(row["image_index"]),
                "source": row["source"],
                "cache": row["cache"],
                "source_gate_method": row.get("method", "exact_crop_upscale_formal_gate"),
                "face_point_counts": list(sample.face_point_counts or ()),
                "face_inlier_counts": list(sample.face_inlier_counts or ()),
                "face_grid_spans": [list(item) for item in (sample.face_grid_spans or ())],
                "face_patterns": [list(item) for item in (sample.face_patterns or ())],
                "formal_gate_passed": True,
                "three_faces_detected": True,
                "spatial_center_normalized": row["spatial_center_normalized"],
                "spatial_center_radius_normalized": row[
                    "spatial_center_radius_normalized"
                ],
                "cached_face_point_counts": row["cached_face_point_counts"],
                "spatial_selection_metrics": selection_metrics,
                "three_face_detection_evidence": row.get(
                    "tracking", row.get("face_point_counts")
                ),
                "sha256": sha256(Path(row["source"])),
            }
            verified.append(verified_row)
            audit_rows.append(verified_row)
        selections[pose] = verified

    # Validate the current split before any mutation.
    for pose in POSES:
        source_files = {path.name for path in (SOURCE / pose / "3D").glob("*.jpg")}
        train_dir = ROOT / "train" / pose / "3D"
        test_dir = ROOT / "test" / pose / "3D"
        assert_within(train_dir, ROOT)
        assert_within(test_dir, ROOT)
        current_train = {path.name for path in train_dir.glob("*.jpg")}
        current_test = {path.name for path in test_dir.glob("*.jpg")}
        if current_train & current_test:
            raise RuntimeError(f"{pose}: train/test 3D overlap before replacement")
        if current_train | current_test != source_files:
            raise RuntimeError(f"{pose}: current split does not cover original 3D files")

    # Move only individual 3D files inside the existing final split.
    for pose in POSES:
        selected_names = {row["image"] for row in selections[pose]}
        train_dir = ROOT / "train" / pose / "3D"
        test_dir = ROOT / "test" / pose / "3D"
        for source_file in sorted((SOURCE / pose / "3D").glob("*.jpg"), key=lambda p: numeric_index(p.name)):
            desired_dir = train_dir if source_file.name in selected_names else test_dir
            other_dir = test_dir if desired_dir == train_dir else train_dir
            desired = desired_dir / source_file.name
            other = other_dir / source_file.name
            assert_within(desired, ROOT)
            assert_within(other, ROOT)
            if other.is_file():
                if desired.exists():
                    raise RuntimeError(f"Duplicate destination while moving {source_file.name}")
                os.replace(other, desired)
            elif not desired.is_file():
                shutil.copy2(source_file, desired)

    # Refresh manifest 3D rows; preserve every 2D/Zhang field and file.
    manifest_path = ROOT / "split_manifest.csv"
    with manifest_path.open("r", encoding="utf-8-sig", newline="") as handle:
        manifest_rows = list(csv.DictReader(handle))
        fieldnames = list(manifest_rows[0])
    selected_lookup = {
        (row["pose"], row["image"]): row for rows in selections.values() for row in rows
    }
    for row in manifest_rows:
        if row.get("Modality") != "3D":
            continue
        key = (row["PoseName"], row["FileName"])
        selected = selected_lookup.get(key)
        if selected:
            row["Split"] = "train"
            row["SelectionReason"] = "formal_gate_spatial_radial_coverage_3d_5_per_pose"
            row["SplitRelativePath"] = str(
                Path("train") / row["PoseName"] / "3D" / row["FileName"]
            )
            row["GatePassed"] = "True"
            row["GateMethod"] = "original_model_formal_gate_minimum_usable_faces_2"
            row["GateFaces"] = str(
                sum(
                    count >= 12 and span[0] >= 4 and span[1] >= 4
                    for count, span in zip(
                        selected["face_inlier_counts"], selected["face_grid_spans"]
                    )
                )
            )
            row["GatePatterns"] = json.dumps(selected["face_patterns"], separators=(",", ":"))
            row["GateCornerCounts"] = ",".join(map(str, selected["face_inlier_counts"]))
        else:
            row["Split"] = "test"
            row["SelectionReason"] = "remaining_test"
            row["SplitRelativePath"] = str(
                Path("test") / row["PoseName"] / "3D" / row["FileName"]
            )
            row["GatePassed"] = ""
            row["GateMethod"] = ""
            row["GateFaces"] = ""
            row["GatePatterns"] = ""
            row["GateCornerCounts"] = ""
    with manifest_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(manifest_rows)

    summary_path = ROOT / "split_summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    summary["strategy"]["three_d"] = (
        "Five images per pose selected from formal-gate candidates by actual normalized target-centre coverage, radial diversity, and three-face point strength"
    )
    summary["quality_gate"]["three_d_selected_passed"] = "25/25 (formal training gate)"
    summary["three_d_selection_by_pose"] = [
        {
            "pose_name": pose,
            "accepted_candidate_count": sum(key[0] == pose for key in candidates),
            "accepted_index_range": [
                min(key[1] for key in candidates if key[0] == pose),
                max(key[1] for key in candidates if key[0] == pose),
            ],
            "selected": [row["image"] for row in selections[pose]],
            "selected_indices": [row["image_index"] for row in selections[pose]],
            "selected_centers_normalized": [
                row["spatial_center_normalized"] for row in selections[pose]
            ],
            "spatial_selection_metrics": selections[pose][0][
                "spatial_selection_metrics"
            ],
            "formal_gate_inliers": [row["face_inlier_counts"] for row in selections[pose]],
            "three_faces_detected_for_all_selected": True,
        }
        for pose in POSES
    ]
    summary["verification"]["all_selected_training_images_passed_gate"] = True
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    (AUDIT / "final_selection.json").write_text(
        json.dumps(audit_rows, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (AUDIT / "final_selection.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        flat_rows = [
            {
                **row,
                "face_point_counts": json.dumps(row["face_point_counts"]),
                "face_inlier_counts": json.dumps(row["face_inlier_counts"]),
                "face_grid_spans": json.dumps(row["face_grid_spans"]),
                "face_patterns": json.dumps(row["face_patterns"]),
            }
            for row in audit_rows
        ]
        writer = csv.DictWriter(handle, fieldnames=list(flat_rows[0]))
        writer.writeheader()
        writer.writerows(flat_rows)

    # Seed each per-pose model cache with the exact selected correspondences.
    for pose in POSES:
        model_cache = ROOT / "validation_ours_vs_zhang" / "per_pose_models" / pose / ".trihedral_correspondence_cache"
        model_cache.mkdir(parents=True, exist_ok=True)
        for row in selections[pose]:
            destination = model_cache / Path(row["cache"]).name
            assert_within(destination, ROOT)
            shutil.copy2(row["cache"], destination)

    # Post-mutation counts and content verification.
    verification = {}
    for pose in POSES:
        train = sorted((ROOT / "train" / pose / "3D").glob("*.jpg"), key=lambda p: numeric_index(p.name))
        test = sorted((ROOT / "test" / pose / "3D").glob("*.jpg"), key=lambda p: numeric_index(p.name))
        selected_names = {row["image"] for row in selections[pose]}
        if len(train) != 5 or {path.name for path in train} != selected_names:
            raise RuntimeError(f"{pose}: final training selection mismatch")
        if len(train) + len(test) != len(list((SOURCE / pose / "3D").glob("*.jpg"))):
            raise RuntimeError(f"{pose}: final 3D count mismatch")
        for path in train + test:
            if sha256(path) != sha256(SOURCE / pose / "3D" / path.name):
                raise RuntimeError(f"Hash mismatch: {path}")
        verification[pose] = {
            "train_3d": len(train),
            "test_3d": len(test),
            "selected": [path.name for path in train],
            "hashes_match_source": True,
        }
    (AUDIT / "final_split_verification.json").write_text(
        json.dumps(verification, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(verification, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
