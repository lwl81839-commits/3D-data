"""Shared paths for the 2026-08-20 five-pose calibration pipeline.

Environment variables allow the dataset to be moved without editing source code:
DATA_3D_SOURCE, DATA_3D_SPLIT_ROOT, and CALIBRATION_PYTHON.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


PIPELINE_DIR = Path(__file__).resolve().parent
MODEL_CODE = PIPELINE_DIR.parent
SOURCE_ROOT = Path(os.environ.get("DATA_3D_SOURCE", r"E:\image\data_3D_0820")).resolve()
SPLIT_ROOT = Path(
    os.environ.get(
        "DATA_3D_SPLIT_ROOT",
        r"E:\image\data_3D_0820_split_model_3D5_Zhang2D20_each_pose_quality_gated",
    )
).resolve()
VALIDATION_ROOT = SPLIT_ROOT / "validation_ours_vs_zhang"
AUDIT_ROOT = VALIDATION_ROOT / "reselection_exact_gate_v2"
PYTHON_EXE = Path(os.environ.get("CALIBRATION_PYTHON", sys.executable)).resolve()
POSES = ("15_0.528", "30_0.827", "45_0.827", "45_1.155", "60_1.155")


def require_layout(*, source: bool = False, split: bool = False) -> None:
    missing = []
    if source and not SOURCE_ROOT.is_dir():
        missing.append(f"source dataset: {SOURCE_ROOT}")
    if split and not SPLIT_ROOT.is_dir():
        missing.append(f"split dataset: {SPLIT_ROOT}")
    if not (MODEL_CODE / "trained_camera_model.py").is_file():
        missing.append(f"model code: {MODEL_CODE / 'trained_camera_model.py'}")
    if missing:
        raise FileNotFoundError("Missing pipeline dependency: " + "; ".join(missing))

