from __future__ import annotations

import os
import queue
import subprocess
import sys
import threading
from pathlib import Path


from pipeline_config import PIPELINE_DIR, POSES, PYTHON_EXE

PYTHON = PYTHON_EXE
WORKER = PIPELINE_DIR / "train_selected_pose.py"


def reader(pose: str, process: subprocess.Popen[str], messages: queue.Queue[tuple[str, str | None]]) -> None:
    assert process.stdout is not None
    for line in process.stdout:
        messages.put((pose, line.rstrip()))
    messages.put((pose, None))


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
    env = os.environ.copy()
    env.update({"OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"})
    processes: dict[str, subprocess.Popen[str]] = {}
    messages: queue.Queue[tuple[str, str | None]] = queue.Queue()
    for pose in POSES:
        process = subprocess.Popen(
            [str(PYTHON), str(WORKER), pose],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=env,
        )
        processes[pose] = process
        threading.Thread(target=reader, args=(pose, process, messages), daemon=True).start()
        print(f"START {pose} pid={process.pid}", flush=True)

    closed = set()
    while len(closed) < len(processes):
        pose, line = messages.get()
        if line is None:
            closed.add(pose)
        else:
            print(line, flush=True)
    codes = {pose: process.wait() for pose, process in processes.items()}
    print("EXIT_CODES " + str(codes), flush=True)
    return 0 if all(code == 0 for code in codes.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
