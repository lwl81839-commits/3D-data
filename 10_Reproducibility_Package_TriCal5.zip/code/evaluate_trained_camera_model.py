#!/usr/bin/env python3
"""Blind, reference-independent evaluation for a frozen trihedral camera model.

The evaluator never reads Zhang calibration parameters.  It excludes training
images by SHA-256, extracts correspondences with the frozen camera model, and
reports:

* blind extraction/single-, two-, and three-face success rates;
* stratified corner holdout error (pose is estimated without held-out points);
* two-face-to-third-face prediction error;
* back-projected object-space point and checker-pitch length error;
* radial image-band reprojection error and undistorted plumb-line residuals.

The object-space values are target-internal holdout tests.  They are useful for
detecting geometric inconsistency, but are not a substitute for an independently
measured validation artefact.  ``--actual-square-mm`` can be set to the measured
mean checker pitch instead of the nominal 25 mm value.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from statistics import mean, median
from typing import Any, Iterable, Optional

import cv2
import numpy as np

from trained_camera_model import (
    CORRESPONDENCE_CACHE_TAG,
    IMAGE_SUFFIXES,
    MIN_FACE_INLIERS,
    MIN_GRID_COLS,
    MIN_GRID_ROWS,
    CorrespondenceSet,
    extract_correspondences,
    load_camera_model,
)


FACE_NAMES = ("xoy_top", "xoz_front", "yoz_side")
RADIAL_BINS = ((0.00, 0.25), (0.25, 0.50), (0.50, 0.75), (0.75, 1.01))
LENGTH_TARGETS_MM = (25.0, 50.0, 100.0, 150.0, 200.0)


@dataclass
class PoseSolution:
    rvec: np.ndarray
    tvec: np.ndarray
    R: np.ndarray
    inlier_count: int


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def iter_images(root: Path) -> list[Path]:
    if root.is_file():
        return [root.resolve()] if root.suffix.lower() in IMAGE_SUFFIXES else []
    return sorted(
        path.resolve()
        for path in root.rglob("*")
        if path.is_file()
        and path.suffix.lower() in IMAGE_SUFFIXES
        and not path.name.startswith("_")
        and "contact_sheet" not in path.stem.lower()
        and "roi_probe" not in path.stem.lower()
    )


def finite(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): finite(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [finite(v) for v in value]
    if isinstance(value, np.ndarray):
        return finite(value.tolist())
    if isinstance(value, (np.floating, float)):
        return float(value) if math.isfinite(float(value)) else None
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if isinstance(value, (np.integer, int)):
        return int(value)
    return value


def percentile(values: Iterable[float], q: float) -> Optional[float]:
    vals = np.asarray([float(v) for v in values if math.isfinite(float(v))])
    return None if vals.size == 0 else float(np.percentile(vals, 100.0 * q))


def stats(values: Iterable[float]) -> dict[str, Optional[float]]:
    vals = [float(v) for v in values if math.isfinite(float(v))]
    if not vals:
        return {"n": 0, "mean": None, "median": None, "rmse": None,
                "p95": None, "max": None}
    arr = np.asarray(vals, dtype=np.float64)
    return {
        "n": int(arr.size),
        "mean": float(np.mean(arr)),
        "median": float(np.median(arr)),
        "rmse": float(np.sqrt(np.mean(arr * arr))),
        "p95": float(np.percentile(arr, 95.0)),
        "max": float(np.max(arr)),
    }


def face_ids(object_points: np.ndarray, tolerance_mm: float = 1e-4) -> np.ndarray:
    """Infer the measured target face from its zero coordinate plane."""
    obj = np.asarray(object_points, dtype=np.float64).reshape(-1, 3)
    result = np.full(len(obj), -1, dtype=np.int32)
    result[np.abs(obj[:, 2]) <= tolerance_mm] = 0  # XOY
    result[(result < 0) & (np.abs(obj[:, 1]) <= tolerance_mm)] = 1  # XOZ
    result[(result < 0) & (np.abs(obj[:, 0]) <= tolerance_mm)] = 2  # YOZ
    if np.any(result < 0):
        bad = obj[result < 0][:3]
        raise ValueError(f"Could not assign object points to target faces: {bad}")
    return result


def usable_faces(sample: CorrespondenceSet) -> int:
    counts = sample.face_inlier_counts or (0, 0, 0)
    spans = sample.face_grid_spans or ((0, 0), (0, 0), (0, 0))
    return int(sum(
        int(counts[i]) >= MIN_FACE_INLIERS
        and int(spans[i][0]) >= MIN_GRID_COLS
        and int(spans[i][1]) >= MIN_GRID_ROWS
        for i in range(3)
    ))


def solve_pose(
    obj: np.ndarray,
    img: np.ndarray,
    indices: np.ndarray,
    K: np.ndarray,
    dist: np.ndarray,
) -> Optional[PoseSolution]:
    idx = np.asarray(indices, dtype=np.int32).reshape(-1)
    if idx.size < 6:
        return None
    object_points = np.asarray(obj, np.float64)[idx].reshape(-1, 1, 3)
    image_points = np.asarray(img, np.float64)[idx].reshape(-1, 1, 2)
    try:
        ok, rvec, tvec, inliers = cv2.solvePnPRansac(
            object_points,
            image_points,
            K,
            dist,
            iterationsCount=800,
            reprojectionError=8.0,
            confidence=0.999,
            flags=cv2.SOLVEPNP_EPNP,
        )
        if not ok or inliers is None or len(inliers) < 6:
            # EPNP-RANSAC can be numerically fragile for a valid single
            # checkerboard face.  Use a planar PnP fallback before declaring
            # the image unusable; retain the same 8 px inlier criterion.
            centered = object_points.reshape(-1, 3) - np.mean(
                object_points.reshape(-1, 3), axis=0, keepdims=True
            )
            planar = np.linalg.matrix_rank(centered, tol=1e-7) <= 2
            fallback_flag = cv2.SOLVEPNP_IPPE if planar else cv2.SOLVEPNP_ITERATIVE
            ok, rvec, tvec = cv2.solvePnP(
                object_points, image_points, K, dist, flags=fallback_flag
            )
            if not ok:
                return None
            projected, _ = cv2.projectPoints(
                object_points, rvec, tvec, K, dist
            )
            residual = np.linalg.norm(
                projected.reshape(-1, 2) - image_points.reshape(-1, 2), axis=1
            )
            inliers = np.flatnonzero(residual <= 8.0).reshape(-1, 1)
            if len(inliers) < 6:
                return None
        local = inliers.reshape(-1)
        rvec, tvec = cv2.solvePnPRefineLM(
            object_points[local], image_points[local], K, dist, rvec, tvec
        )
        R, _ = cv2.Rodrigues(rvec)
    except cv2.error:
        return None
    depth = (np.asarray(obj)[idx] @ R.T + tvec.reshape(1, 3))[:, 2]
    if float(np.mean(depth > 0.0)) < 0.99:
        return None
    return PoseSolution(
        rvec=rvec.reshape(3),
        tvec=tvec.reshape(3),
        R=R,
        inlier_count=int(len(inliers)),
    )


def project_errors(
    obj: np.ndarray,
    img: np.ndarray,
    indices: np.ndarray,
    pose: PoseSolution,
    K: np.ndarray,
    dist: np.ndarray,
) -> np.ndarray:
    idx = np.asarray(indices, dtype=np.int32).reshape(-1)
    projected, _ = cv2.projectPoints(
        np.asarray(obj, np.float64)[idx].reshape(-1, 1, 3),
        pose.rvec.reshape(3, 1),
        pose.tvec.reshape(3, 1),
        K,
        dist,
    )
    return np.linalg.norm(
        projected.reshape(-1, 2) - np.asarray(img, np.float64)[idx], axis=1
    )


def normalized_radius(points: np.ndarray, K: np.ndarray, image_size: tuple[int, int]) -> np.ndarray:
    pts = np.asarray(points, np.float64).reshape(-1, 2)
    fx, fy = float(K[0, 0]), float(K[1, 1])
    cx, cy = float(K[0, 2]), float(K[1, 2])
    radius = np.sqrt(((pts[:, 0] - cx) / fx) ** 2 + ((pts[:, 1] - cy) / fy) ** 2)
    width, height = image_size
    corners = np.array([[0, 0], [width, 0], [0, height], [width, height]], np.float64)
    max_radius = np.max(np.sqrt(
        ((corners[:, 0] - cx) / fx) ** 2 + ((corners[:, 1] - cy) / fy) ** 2
    ))
    return radius / max(float(max_radius), 1e-12)


def stratified_holdout(
    ids: np.ndarray,
    rng: np.random.Generator,
    fraction: float,
    min_per_face: int,
) -> tuple[np.ndarray, np.ndarray]:
    train: list[np.ndarray] = []
    held: list[np.ndarray] = []
    for face in sorted(set(int(v) for v in ids)):
        indices = np.flatnonzero(ids == face)
        shuffled = indices.copy()
        rng.shuffle(shuffled)
        max_hold = max(0, len(indices) - 8)
        count = min(max_hold, max(min_per_face, int(round(len(indices) * fraction))))
        if count <= 0:
            train.append(np.sort(indices))
            continue
        held.append(np.sort(shuffled[:count]))
        train.append(np.sort(shuffled[count:]))
    return (
        np.concatenate(train) if train else np.empty(0, dtype=int),
        np.concatenate(held) if held else np.empty(0, dtype=int),
    )


def ray_plane_object_points(
    image_points: np.ndarray,
    face: int,
    pose: PoseSolution,
    K: np.ndarray,
    dist: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Back-project pixels to one of the target coordinate planes."""
    pixels = np.asarray(image_points, np.float64).reshape(-1, 1, 2)
    normalized = cv2.undistortPoints(pixels, K, dist).reshape(-1, 2)
    rays_camera = np.column_stack([normalized, np.ones(len(normalized))])
    rays_object = rays_camera @ pose.R
    camera_center = -pose.R.T @ pose.tvec.reshape(3)
    axis = (2, 1, 0)[face]
    denominator = rays_object[:, axis]
    valid = np.abs(denominator) > 1e-10
    scale = np.full(len(normalized), np.nan, dtype=np.float64)
    scale[valid] = -camera_center[axis] / denominator[valid]
    valid &= scale > 0.0
    points = camera_center.reshape(1, 3) + scale[:, None] * rays_object
    return points, valid


def object_space_metrics(
    obj: np.ndarray,
    img: np.ndarray,
    indices: np.ndarray,
    ids: np.ndarray,
    pose: PoseSolution,
    K: np.ndarray,
    dist: np.ndarray,
    nominal_square_mm: float,
    actual_square_mm: float,
) -> tuple[list[float], list[dict[str, float]]]:
    point_errors: list[float] = []
    length_rows: list[dict[str, float]] = []
    idx = np.asarray(indices, dtype=int)
    for face in range(3):
        local_idx = idx[ids[idx] == face]
        if len(local_idx) == 0:
            continue
        reconstructed, valid = ray_plane_object_points(
            img[local_idx], face, pose, K, dist
        )
        local_idx = local_idx[valid]
        reconstructed = reconstructed[valid]
        truth_nominal = obj[local_idx]
        point_errors.extend(np.linalg.norm(reconstructed - truth_nominal, axis=1).tolist())

        for a in range(len(local_idx)):
            for b in range(a + 1, len(local_idx)):
                delta = truth_nominal[b] - truth_nominal[a]
                nonzero = np.flatnonzero(np.abs(delta) > 1e-5)
                if len(nonzero) != 1:  # only row/column distances, not diagonals
                    continue
                true_nominal = float(abs(delta[nonzero[0]]))
                steps = int(round(true_nominal / nominal_square_mm))
                if steps < 1 or not math.isclose(
                    true_nominal, steps * nominal_square_mm, abs_tol=0.25
                ):
                    continue
                nominal_bucket = steps * nominal_square_mm
                if nominal_bucket > max(LENGTH_TARGETS_MM) + 0.25:
                    continue
                estimated = float(np.linalg.norm(reconstructed[b] - reconstructed[a]))
                physical_truth = float(steps * actual_square_mm)
                length_rows.append({
                    "face": float(face),
                    "nominal_length_mm": float(nominal_bucket),
                    "physical_truth_mm": physical_truth,
                    "estimated_length_mm": estimated,
                    "signed_error_mm": estimated - physical_truth,
                    "absolute_error_mm": abs(estimated - physical_truth),
                    "relative_error_pct": (
                        100.0 * abs(estimated - physical_truth) / physical_truth
                    ),
                })
    return point_errors, length_rows


def line_residuals(sample: CorrespondenceSet, K: np.ndarray, dist: np.ndarray) -> list[float]:
    """RMS straight-line residual after undistortion, using object grid lines."""
    obj = np.asarray(sample.object_points, np.float64)
    undistorted = cv2.undistortPoints(
        np.asarray(sample.image_points, np.float64).reshape(-1, 1, 2), K, dist, P=K
    ).reshape(-1, 2)
    ids = face_ids(obj)
    residuals: list[float] = []
    local_axes = ((0, 1), (0, 2), (1, 2))
    for face, (axis_a, axis_b) in enumerate(local_axes):
        face_idx = np.flatnonzero(ids == face)
        if len(face_idx) < 4:
            continue
        for fixed_axis in (axis_a, axis_b):
            values = np.round(obj[face_idx, fixed_axis], 4)
            for value in np.unique(values):
                line_idx = face_idx[np.isclose(values, value, atol=1e-4)]
                if len(line_idx) < 3:
                    continue
                points = undistorted[line_idx]
                center = np.mean(points, axis=0)
                _, _, vh = np.linalg.svd(points - center, full_matrices=False)
                normal = vh[-1]
                distances = np.abs((points - center) @ normal)
                residuals.append(float(np.sqrt(np.mean(distances * distances))))
    return residuals


def evaluate_image(
    path: Path,
    model: dict,
    cache_dir: Path,
    reusable_cache_dir: Optional[Path],
    repeats: int,
    holdout_fraction: float,
    min_holdout_per_face: int,
    actual_square_mm: float,
    rng: np.random.Generator,
) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    K = np.asarray(model["cameraMatrix"], np.float64).reshape(3, 3)
    dist = np.asarray(model["distCoeffs"], np.float64).reshape(5)
    nominal_square = float(model["square_size_mm"])
    target = model.get("target_geometry", {})
    cube_hint = target.get("selected_cube_side_squares")
    cache_dir.mkdir(parents=True, exist_ok=True)
    digest = sha256_file(path)
    square_tag = f"{nominal_square:.9g}".replace(".", "p")
    existing_cache = None
    if reusable_cache_dir is not None:
        candidate = reusable_cache_dir / (
            f"{digest}_sq{square_tag}_{CORRESPONDENCE_CACHE_TAG}.npz"
        )
        if candidate.is_file():
            existing_cache = candidate
    cache_path = existing_cache or (
        cache_dir / f"{digest}_sq{square_tag}_{CORRESPONDENCE_CACHE_TAG}.npz"
    )
    # A prevalidated cache is shared by every camera-parameter method in a
    # comparison.  Re-filter it without method-specific focal/distortion hints
    # so ours and the fixed Zhang reference use identical detected faces and
    # corner correspondences.  Independent three-face recovery is only needed
    # when extracting a brand-new cache.
    use_method_hints = existing_cache is None
    sample = extract_correspondences(
        str(path),
        nominal_square,
        focal_hint_px=float(K[0, 0]) if use_method_hints else None,
        k1_hint=float(dist[0]) if use_method_hints else None,
        correspondence_cache_path=str(cache_path),
        minimum_usable_faces=1,
        cube_side_squares_hint=(
            None if (not use_method_hints or cube_hint is None) else float(cube_hint)
        ),
        allow_independent_cube_search=bool(use_method_hints and target.get("scope") in {
            "independent_rigid_cube_per_image", "measured_rectangular_cuboid_320x220x240"
        }),
    )
    if tuple(sample.image_size) != tuple(int(v) for v in model["image_size"]):
        raise ValueError(f"Image size {sample.image_size} does not match model")

    obj = np.asarray(sample.object_points, np.float64).reshape(-1, 3)
    img = np.asarray(sample.image_points, np.float64).reshape(-1, 2)
    ids = face_ids(obj)
    full_idx = np.arange(len(obj), dtype=int)
    full_pose = solve_pose(obj, img, full_idx, K, dist)
    if full_pose is None:
        raise RuntimeError("Frozen-model full-point pose solve failed")
    full_errors = project_errors(obj, img, full_idx, full_pose, K, dist)
    radii = normalized_radius(img, K, sample.image_size)
    radial_rows: list[dict[str, Any]] = []
    for low, high in RADIAL_BINS:
        selected = (radii >= low) & (radii < high)
        radial_rows.append({
            "image": str(path),
            "radius_bin": f"{low:.2f}-{min(high, 1.0):.2f}",
            "n": int(np.sum(selected)),
            "error_stats": stats(full_errors[selected]),
        })

    trial_rows: list[dict[str, Any]] = []
    all_holdout_px: list[float] = []
    all_point_mm: list[float] = []
    length_rows: list[dict[str, Any]] = []
    for repeat in range(repeats):
        train_idx, held_idx = stratified_holdout(
            ids, rng, holdout_fraction, min_holdout_per_face
        )
        pose = solve_pose(obj, img, train_idx, K, dist)
        if pose is None or len(held_idx) == 0:
            trial_rows.append({
                "image": str(path), "repeat": repeat, "success": False,
                "n_train": int(len(train_idx)), "n_holdout": int(len(held_idx)),
            })
            continue
        px = project_errors(obj, img, held_idx, pose, K, dist)
        point_mm, lengths = object_space_metrics(
            obj, img, held_idx, ids, pose, K, dist, nominal_square, actual_square_mm
        )
        all_holdout_px.extend(px.tolist())
        all_point_mm.extend(point_mm)
        for row in lengths:
            row.update({"image": str(path), "repeat": repeat})
        length_rows.extend(lengths)
        trial_rows.append({
            "image": str(path),
            "repeat": repeat,
            "success": True,
            "n_train": int(len(train_idx)),
            "n_holdout": int(len(held_idx)),
            "pose_inliers": pose.inlier_count,
            "holdout_rmse_px": float(np.sqrt(np.mean(px * px))),
            "holdout_median_px": float(np.median(px)),
            "object_point_rmse_mm": (
                float(np.sqrt(np.mean(np.square(point_mm)))) if point_mm else None
            ),
        })

    cross_rows: list[dict[str, Any]] = []
    observed_faces = sorted(set(int(v) for v in ids))
    if len(observed_faces) >= 3:
        for held_face in observed_faces:
            train_idx = np.flatnonzero(ids != held_face)
            test_idx = np.flatnonzero(ids == held_face)
            pose = solve_pose(obj, img, train_idx, K, dist)
            row: dict[str, Any] = {
                "image": str(path),
                "held_face": FACE_NAMES[held_face],
                "n_train": int(len(train_idx)),
                "n_test": int(len(test_idx)),
                "success": pose is not None,
            }
            if pose is not None:
                px = project_errors(obj, img, test_idx, pose, K, dist)
                point_mm, lengths = object_space_metrics(
                    obj, img, test_idx, ids, pose, K, dist,
                    nominal_square, actual_square_mm,
                )
                row.update({
                    "prediction_rmse_px": float(np.sqrt(np.mean(px * px))),
                    "prediction_median_px": float(np.median(px)),
                    "object_point_rmse_mm": (
                        float(np.sqrt(np.mean(np.square(point_mm)))) if point_mm else None
                    ),
                    "length_relative_error_pct": stats(
                        item["relative_error_pct"] for item in lengths
                    ),
                })
            cross_rows.append(row)

    line_values = line_residuals(sample, K, dist)
    image_row = {
        "image": str(path),
        "status": "ok",
        "n_points": int(len(obj)),
        "faces_used": usable_faces(sample),
        "face_inliers": list(sample.face_inlier_counts or (0, 0, 0)),
        "face_grid_spans": [list(v) for v in (
            sample.face_grid_spans or ((0, 0), (0, 0), (0, 0))
        )],
        "association_repaired": bool(sample.association_repaired),
        "full_reprojection_error_px": stats(full_errors),
        "holdout_error_px": stats(all_holdout_px),
        "holdout_object_point_error_mm": stats(all_point_mm),
        "holdout_length_absolute_error_mm": stats(
            row["absolute_error_mm"] for row in length_rows
        ),
        "holdout_length_relative_error_pct": stats(
            row["relative_error_pct"] for row in length_rows
        ),
        "undistorted_line_rms_px": stats(line_values),
        "radius_coverage_max": float(np.max(radii)) if len(radii) else None,
    }
    return image_row, trial_rows, cross_rows, radial_rows + length_rows


def flatten_csv_value(value: Any) -> Any:
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(finite(value), ensure_ascii=False, separators=(",", ":"))
    return value


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys: list[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows({k: flatten_csv_value(v) for k, v in row.items()} for row in rows)


def fmt(value: Any, digits: int = 3) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "-"
    return "-" if not math.isfinite(number) else f"{number:.{digits}f}"


def aggregate_report(
    model_path: Path,
    image_root: Path,
    model: dict,
    rows: list[dict[str, Any]],
    failures: list[dict[str, Any]],
    trials: list[dict[str, Any]],
    cross: list[dict[str, Any]],
    mixed: list[dict[str, Any]],
    excluded_training: list[str],
    skipped_uncached: list[str],
    actual_square_mm: float,
) -> dict[str, Any]:
    ok_trials = [r for r in trials if r.get("success")]
    cross_ok = [r for r in cross if r.get("success")]
    length_rows = [r for r in mixed if "absolute_error_mm" in r]
    radial_rows = [r for r in mixed if "radius_bin" in r]
    face_hist = {str(i): sum(int(r.get("faces_used", 0)) == i for r in rows) for i in (1, 2, 3)}
    radial_aggregate: dict[str, dict[str, Optional[float]]] = {}
    for label in sorted({str(r["radius_bin"]) for r in radial_rows}):
        group = [r["error_stats"] for r in radial_rows if r["radius_bin"] == label]
        total_n = sum(int(item.get("n") or 0) for item in group)
        if total_n:
            weighted_mean = sum(
                int(item["n"]) * float(item["mean"]) for item in group
                if item.get("mean") is not None
            ) / total_n
            pooled_rmse = math.sqrt(sum(
                int(item["n"]) * float(item["rmse"]) ** 2 for item in group
                if item.get("rmse") is not None
            ) / total_n)
        else:
            weighted_mean = None
            pooled_rmse = None
        radial_aggregate[label] = {
            "n": total_n, "mean_px": weighted_mean, "rmse_px": pooled_rmse
        }
    summary = {
        "schema": "trihedral-blind-accuracy-evaluation/v1",
        "model": str(model_path),
        "image_root": str(image_root),
        "camera_parameter_source": model.get(
            "_evaluation_camera_parameter_source", "few_shot_trained_model"
        ),
        "original_model_accepted": bool(
            model.get("_evaluation_original_model_accepted", model.get("accepted", False))
        ),
        "unaccepted_model_evaluation_override": bool(
            model.get("_evaluation_unaccepted_model_override", False)
        ),
        "zhang_reference_used_for_evaluation": bool(
            model.get("_evaluation_uses_zhang_reference", False)
        ),
        "no_zhang_reference_used_in_original_training": bool(
            model.get("no_zhang_reference_used", False)
        ),
        "training_images_excluded_by_sha256": len(excluded_training),
        "uncached_images_skipped_by_request": len(skipped_uncached),
        "blind_images_attempted": len(rows) + len(failures),
        "blind_images_extracted": len(rows),
        "blind_extraction_success_rate_pct": (
            100.0 * len(rows) / max(1, len(rows) + len(failures))
        ),
        "face_evidence_histogram": face_hist,
        "strict_three_face_success_rate_pct": (
            100.0 * face_hist["3"] / max(1, len(rows) + len(failures))
        ),
        "holdout_pose_trial_success_rate_pct": (
            100.0 * len(ok_trials) / max(1, len(trials))
        ),
        "holdout_error_px": stats(
            r["holdout_rmse_px"] for r in ok_trials if r.get("holdout_rmse_px") is not None
        ),
        "holdout_object_point_rmse_mm": stats(
            r["object_point_rmse_mm"] for r in ok_trials
            if r.get("object_point_rmse_mm") is not None
        ),
        "holdout_length_absolute_error_mm": stats(
            r["absolute_error_mm"] for r in length_rows
        ),
        "holdout_length_relative_error_pct": stats(
            r["relative_error_pct"] for r in length_rows
        ),
        "cross_face_prediction_rmse_px": stats(
            r["prediction_rmse_px"] for r in cross_ok
            if r.get("prediction_rmse_px") is not None
        ),
        "undistorted_line_rms_px": stats(
            r["undistorted_line_rms_px"]["rmse"] for r in rows
            if r.get("undistorted_line_rms_px", {}).get("rmse") is not None
        ),
        "runtime_seconds": stats(
            r["elapsed_seconds"] for r in rows if r.get("elapsed_seconds") is not None
        ),
        "radial_error_by_normalized_image_radius": radial_aggregate,
        "actual_square_mm_for_length_truth": actual_square_mm,
        "nominal_square_mm_used_by_model": float(model["square_size_mm"]),
        "radial_rows": radial_rows,
        "limitations": [
            "Object-space and checker-length results are target-internal holdout tests.",
            "They are not independent physical ground truth unless actual_square_mm was measured independently.",
            "For publication-grade absolute accuracy, repeat with a separate measured validation artefact.",
        ],
    }
    return summary


def write_markdown(path: Path, summary: dict[str, Any], failures: list[dict[str, Any]]) -> None:
    hold = summary["holdout_error_px"]
    point = summary["holdout_object_point_rmse_mm"]
    length = summary["holdout_length_relative_error_pct"]
    cross = summary["cross_face_prediction_rmse_px"]
    line = summary["undistorted_line_rms_px"]
    lines = [
        "# 冻结相机模型独立盲测报告",
        "",
        f"- 模型：`{summary['model']}`",
        f"- 图片目录：`{summary['image_root']}`",
        f"- 相机参数来源：{summary['camera_parameter_source']}",
        f"- 本次评价使用张正友参数：{'是' if summary['zhang_reference_used_for_evaluation'] else '否'}",
        "- 原少样本模型训练使用张正友参数：否",
        f"- 按 SHA-256 排除的训练图片：{summary['training_images_excluded_by_sha256']}",
        f"- 按请求跳过的无缓存图片：{summary['uncached_images_skipped_by_request']}",
        f"- 尝试盲测图片：{summary['blind_images_attempted']}",
        f"- 成功提取：{summary['blind_images_extracted']}（{fmt(summary['blind_extraction_success_rate_pct'])}%）",
        f"- 严格三面成功率：{fmt(summary['strict_three_face_success_rate_pct'])}%",
        "",
        "## 核心指标",
        "",
        "| 指标 | 样本数 | 均值 | 中位数 | RMSE | P95 |",
        "|---|---:|---:|---:|---:|---:|",
        f"| 留出角点误差（px） | {hold['n']} | {fmt(hold['mean'])} | {fmt(hold['median'])} | {fmt(hold['rmse'])} | {fmt(hold['p95'])} |",
        f"| 留出空间点误差（mm） | {point['n']} | {fmt(point['mean'])} | {fmt(point['median'])} | {fmt(point['rmse'])} | {fmt(point['p95'])} |",
        f"| 留出长度相对误差（%） | {length['n']} | {fmt(length['mean'])} | {fmt(length['median'])} | {fmt(length['rmse'])} | {fmt(length['p95'])} |",
        f"| 两面预测第三面（px） | {cross['n']} | {fmt(cross['mean'])} | {fmt(cross['median'])} | {fmt(cross['rmse'])} | {fmt(cross['p95'])} |",
        f"| 去畸变直线残差（px） | {line['n']} | {fmt(line['mean'])} | {fmt(line['median'])} | {fmt(line['rmse'])} | {fmt(line['p95'])} |",
        "",
        "## 证据等级",
        "",
        f"- 单面：{summary['face_evidence_histogram']['1']}",
        f"- 两面：{summary['face_evidence_histogram']['2']}",
        f"- 三面：{summary['face_evidence_histogram']['3']}",
        f"- 留出姿态求解成功率：{fmt(summary['holdout_pose_trial_success_rate_pct'])}%",
        f"- 单张处理时间中位数：{fmt(summary['runtime_seconds']['median'])} s",
        "",
        "## 径向分区误差",
        "",
        "| 归一化图像半径 | 角点数 | 平均误差（px） | RMSE（px） |",
        "|---|---:|---:|---:|",
    ]
    for label, item in summary["radial_error_by_normalized_image_radius"].items():
        lines.append(
            f"| {label} | {item['n']} | {fmt(item['mean_px'])} | {fmt(item['rmse_px'])} |"
        )
    lines.extend([
        "",
        "## 尺度说明",
        "",
        f"- 模型标称格距：{fmt(summary['nominal_square_mm_used_by_model'])} mm",
        f"- 本次长度真值格距：{fmt(summary['actual_square_mm_for_length_truth'])} mm",
        "- 如果两者都填写25 mm，长度结果属于内部一致性检验，不是独立绝对计量真值。",
        "- 发表级绝对精度应把实际测得的平均格距传给 `--actual-square-mm`，并增加独立验证物体。",
        "",
        "## 失败图片",
        "",
    ])
    if failures:
        for failure in failures:
            lines.append(f"- `{failure['image']}`：{failure['error']}")
    else:
        lines.append("- 无")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True, help="Frozen trained_camera_model JSON")
    parser.add_argument("--images", type=Path, required=True, help="Blind image or folder")
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument(
        "--camera-override-json", type=Path, default=None,
        help="Evaluation-only K/dist override, e.g. a frozen Zhang reference",
    )
    parser.add_argument(
        "--correspondence-cache-dir", type=Path, default=None,
        help="Existing extraction cache; defaults to MODEL_DIR/.trihedral_correspondence_cache",
    )
    parser.add_argument("--repeats", type=int, default=20)
    parser.add_argument("--holdout-fraction", type=float, default=0.20)
    parser.add_argument("--min-holdout-per-face", type=int, default=4)
    parser.add_argument("--actual-square-mm", type=float, default=None)
    parser.add_argument("--seed", type=int, default=20260806)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument(
        "--include-training", action="store_true",
        help="Diagnostic only: do not exclude model training image hashes",
    )
    parser.add_argument(
        "--only-existing-cache", action="store_true",
        help="Evaluate only images already present in the model extraction cache",
    )
    parser.add_argument(
        "--allow-unaccepted-model", action="store_true",
        help=(
            "Evaluate a successfully solved model even when an additional training "
            "release gate marked accepted=false; the status remains recorded in output"
        ),
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    model_path = args.model.resolve()
    image_root = args.images.resolve()
    model = load_camera_model(str(model_path))
    original_model_accepted = bool(model.get("accepted", False))
    if not original_model_accepted and not args.allow_unaccepted_model:
        raise RuntimeError("The model did not pass its training quality gates")
    model["_evaluation_original_model_accepted"] = original_model_accepted
    model["_evaluation_unaccepted_model_override"] = bool(
        not original_model_accepted and args.allow_unaccepted_model
    )
    model["_evaluation_camera_parameter_source"] = "few_shot_trained_model"
    model["_evaluation_uses_zhang_reference"] = False
    if args.camera_override_json is not None:
        override_path = args.camera_override_json.resolve()
        override = json.loads(override_path.read_text(encoding="utf-8"))
        override_K = np.asarray(override.get("cameraMatrix"), np.float64)
        override_dist = np.asarray(override.get("distCoeffs"), np.float64).reshape(-1)
        if override_K.shape != (3, 3) or override_dist.size != 5:
            raise ValueError("Camera override must contain a 3x3 cameraMatrix and 5 distCoeffs")
        if not np.all(np.isfinite(override_K)) or not np.all(np.isfinite(override_dist)):
            raise ValueError("Camera override contains non-finite values")
        model["cameraMatrix"] = override_K.tolist()
        model["distCoeffs"] = override_dist.tolist()
        model["_evaluation_camera_parameter_source"] = str(
            override.get("source") or override_path
        )
        model["_evaluation_uses_zhang_reference"] = bool(
            override.get("is_zhang_reference", False)
        )
    output_dir = (
        args.output_dir.resolve()
        if args.output_dir is not None
        else model_path.parent / f"blind_accuracy_{image_root.name}"
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    cache_dir = output_dir / ".evaluation_cache"
    reusable_cache_dir = (
        args.correspondence_cache_dir.resolve()
        if args.correspondence_cache_dir is not None
        else model_path.parent / ".trihedral_correspondence_cache"
    )
    nominal_square = float(model["square_size_mm"])
    actual_square = nominal_square if args.actual_square_mm is None else float(args.actual_square_mm)
    if actual_square <= 0:
        raise ValueError("--actual-square-mm must be positive")
    if not (0.01 <= args.holdout_fraction <= 0.50):
        raise ValueError("--holdout-fraction must be between 0.01 and 0.50")

    training_hashes = {
        str(item.get("sha256", "")).lower()
        for item in model.get("training_images", [])
        if item.get("sha256")
    }
    candidates = iter_images(image_root)
    selected: list[Path] = []
    excluded: list[str] = []
    skipped_uncached: list[str] = []
    for path in candidates:
        digest = sha256_file(path).lower()
        if not args.include_training and digest in training_hashes:
            excluded.append(str(path))
            continue
        if args.only_existing_cache:
            square_tag = f"{nominal_square:.9g}".replace(".", "p")
            existing = reusable_cache_dir / (
                f"{digest}_sq{square_tag}_{CORRESPONDENCE_CACHE_TAG}.npz"
            )
            if not existing.is_file():
                skipped_uncached.append(str(path))
                continue
        selected.append(path)
    if args.limit is not None:
        selected = selected[:max(0, int(args.limit))]
    if not selected:
        raise RuntimeError("No blind images remain after training-image exclusion")

    rng = np.random.default_rng(args.seed)
    image_rows: list[dict[str, Any]] = []
    trial_rows: list[dict[str, Any]] = []
    cross_rows: list[dict[str, Any]] = []
    mixed_rows: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    print(f"Model: {model_path}")
    print(f"Blind images: {len(selected)}; excluded training duplicates: {len(excluded)}")
    for index, path in enumerate(selected, start=1):
        print(f"[{index}/{len(selected)}] {path.name}", flush=True)
        started = time.perf_counter()
        try:
            row, trials, cross, mixed = evaluate_image(
                path, model, cache_dir, reusable_cache_dir, int(args.repeats),
                float(args.holdout_fraction), int(args.min_holdout_per_face),
                actual_square, rng,
            )
            row["elapsed_seconds"] = float(time.perf_counter() - started)
            image_rows.append(row)
            trial_rows.extend(trials)
            cross_rows.extend(cross)
            mixed_rows.extend(mixed)
            print(
                f"  ok: faces={row['faces_used']} points={row['n_points']} "
                f"holdout median={fmt(row['holdout_error_px']['median'])} px"
            )
        except Exception as exc:
            failures.append({
                "image": str(path), "error": str(exc),
                "elapsed_seconds": float(time.perf_counter() - started),
            })
            print(f"  failed: {exc}")

    summary = aggregate_report(
        model_path, image_root, model, image_rows, failures, trial_rows,
        cross_rows, mixed_rows, excluded, skipped_uncached, actual_square,
    )
    payload = {
        "summary": summary,
        "images": image_rows,
        "failures": failures,
        "excluded_training_images": excluded,
        "skipped_uncached_images": skipped_uncached,
    }
    (output_dir / "evaluation.json").write_text(
        json.dumps(finite(payload), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_csv(output_dir / "image_metrics.csv", image_rows + failures)
    write_csv(output_dir / "holdout_trials.csv", trial_rows)
    write_csv(output_dir / "cross_face_predictions.csv", cross_rows)
    write_csv(output_dir / "radial_and_length_details.csv", mixed_rows)
    write_markdown(output_dir / "REPORT.md", summary, failures)
    print(f"Report: {output_dir / 'REPORT.md'}")
    print(
        "Blind extraction success: "
        f"{summary['blind_images_extracted']}/{summary['blind_images_attempted']}; "
        f"strict three-face: {fmt(summary['strict_three_face_success_rate_pct'])}%"
    )
    print(
        "Holdout RMSE median: "
        f"{fmt(summary['holdout_error_px']['median'])} px; "
        "length relative error median: "
        f"{fmt(summary['holdout_length_relative_error_pct']['median'])}%"
    )
    return 0 if image_rows else 2


if __name__ == "__main__":
    raise SystemExit(main())
