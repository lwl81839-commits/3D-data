# 0820 complete ratio-prior ablation

The manuscript reports removal of BOTH ratio-dependent k2 initialization clipping and the coefficient-ratio penalty. Independent bounds and monotonicity remain. The penalty-only run is not reported as this ablation.

Use Python 3.12 with the original scientific dependencies. The driver has ROOT-relative output and an explicit SPLIT path: set SPLIT to your local copy of the frozen 0820 dataset. Keep its validation_ours_vs_zhang baseline models and correspondence caches in place. No images or Zhang calibration outputs are used to supervise the ablated fit. Zhang is only a test comparator.

PowerShell, from the code directory:

```powershell
$env:ABLATION_REMOVE_ALL_RATIO='1'
python ablate_0820_ratio_prior.py
python summarize_0820_ratio_ablation.py
```

The processed-data directory ablation_0820_no_ratio_constraint contains the frozen results, 25 training-image hashes, corresponding cache hashes, original/modified source hashes, and rejection reasons. Code snapshots are in ablation_0820_no_ratio_constraint_snapshot. Original source image files remain in the separately supplied dataset. Rejected models were evaluated diagnostically without changing accepted=False.
