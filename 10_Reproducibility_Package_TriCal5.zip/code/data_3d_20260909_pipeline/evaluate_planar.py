from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import cv2
import numpy as np


CODE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CODE_ROOT))
from evaluate_planar_blind_comparison import (
    backproject_object_errors, detect_checker, line_rms, object_points,
    project_errors, solve_pose,
)

SPLIT = Path(r"E:\Data_image_3d\data_3D_20260909\dataset_split")
OUT = SPLIT / "evaluation_ours_vs_zhang"
CONFIGS = ("Alter_1/30_0.852", "Alter_1/45_0.852", "Alter_2/30", "Alter_2/45")
METRICS = ("reprojection_rmse_px", "holdout_rmse_px", "holdout_object_rmse_mm", "line_rms_px")


def numeric(path: Path) -> int:
    return int(path.stem.rsplit("_", 1)[-1])


def load_camera(path: Path) -> tuple[np.ndarray, np.ndarray, bool]:
    data = json.loads(path.read_text(encoding="utf-8"))
    return np.asarray(data["cameraMatrix"], np.float64), np.asarray(data["distCoeffs"], np.float64).reshape(5), bool(data.get("accepted", True))


def stats(values: list[float]) -> dict:
    a = np.asarray(values, np.float64)
    return {"n": len(a), "mean": float(np.mean(a)), "median": float(np.median(a)), "std": float(np.std(a)), "p95": float(np.percentile(a, 95))} if len(a) else {"n": 0}


def finite(x):
    if isinstance(x, (float, np.floating)):
        return float(x) if math.isfinite(float(x)) else None
    if isinstance(x, dict): return {k: finite(v) for k, v in x.items()}
    if isinstance(x, list): return [finite(v) for v in x]
    return x


def evaluate(key: str) -> dict:
    camera, pose = key.split("/")
    ours_path = OUT / "models" / camera / pose / "trained_camera_model.json"
    zhang_path = OUT / "zhang_models" / camera / pose / "zhang_camera_model.json"
    ours_K, ours_d, accepted = load_camera(ours_path)
    zhang_K, zhang_d, _ = load_camera(zhang_path)
    models = {"ours_3d_5_images": (ours_K, ours_d), "zhang_2d_20_images": (zhang_K, zhang_d)}
    obj = object_points(25.0).astype(np.float64)
    paths = sorted((SPLIT / "test" / camera / pose / "2D").glob("*.jpg"), key=numeric)
    rows, failures = [], []
    for image_index, path in enumerate(paths):
        corners, detector = detect_checker(path)
        if corners is None:
            failures.append({"image": path.name, "reason": detector})
            continue
        rng = np.random.default_rng(20260909 + image_index)
        heldouts = [np.sort(rng.choice(len(obj), 11, replace=False)) for _ in range(20)]
        row = {"image": path.name, "detector": detector, "n_corners": len(corners)}
        for name, (K, dist) in models.items():
            all_idx = np.arange(len(obj))
            pose_full = solve_pose(obj, corners, all_idx, K, dist)
            if pose_full is None:
                row[name] = {"pose_success": False}
                continue
            reproj = project_errors(obj, corners, all_idx, pose_full, K, dist)
            held_px, held_mm = [], []
            for held in heldouts:
                train = np.setdiff1d(all_idx, held)
                p = solve_pose(obj, corners, train, K, dist)
                if p is None: continue
                epx = project_errors(obj, corners, held, p, K, dist)
                emm = backproject_object_errors(obj, corners, held, p, K, dist)
                held_px.append(float(np.sqrt(np.mean(epx * epx))))
                held_mm.append(float(np.sqrt(np.mean(emm * emm))))
            row[name] = {
                "pose_success": True,
                "reprojection_rmse_px": float(np.sqrt(np.mean(reproj * reproj))),
                "holdout_rmse_px": float(np.median(held_px)),
                "holdout_object_rmse_mm": float(np.median(held_mm)),
                "line_rms_px": float(line_rms(corners, K, dist)),
            }
        rows.append(row)
    summaries = {name: {m: stats([r[name][m] for r in rows if r[name].get("pose_success")]) for m in METRICS} for name in models}
    comparisons = {}
    for m in METRICS:
        pairs = [(r["ours_3d_5_images"][m], r["zhang_2d_20_images"][m]) for r in rows if r["ours_3d_5_images"].get("pose_success") and r["zhang_2d_20_images"].get("pose_success")]
        comparisons[m] = {"paired": len(pairs), "ours_wins": sum(a < b for a, b in pairs), "zhang_wins": sum(b < a for a, b in pairs), "median_ours_minus_zhang": float(np.median([a-b for a,b in pairs])) if pairs else None}
    payload = finite({"schema": "new-camera-controlled-planar-evaluation/v1", "configuration": key, "test_images": len(paths), "detected_images": len(rows), "detection_failures": failures, "same_images_same_corners_same_holdouts": True, "ours_model_accepted": accepted, "summaries": summaries, "comparisons": comparisons, "images": rows})
    target = OUT / "tests" / camera / pose / "2D"
    target.mkdir(parents=True, exist_ok=True)
    (target / "evaluation.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    flat = []
    for row in rows:
        for name in models:
            flat.append({"image": row["image"], "method": name, **row[name]})
    with (target / "per_image.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=sorted({k for r in flat for k in r}))
        writer.writeheader(); writer.writerows(flat)
    print(f"[{key}] 2D detected={len(rows)}/{len(paths)} reproj medians: ours={summaries['ours_3d_5_images']['reprojection_rmse_px'].get('median')} zhang={summaries['zhang_2d_20_images']['reprojection_rmse_px'].get('median')}", flush=True)
    return payload


def main() -> int:
    results, failures = [], []
    for key in CONFIGS:
        try: results.append(evaluate(key))
        except Exception as exc:
            failures.append({"configuration": key, "error": f"{type(exc).__name__}: {exc}"})
            print(f"[{key}] FAILED {failures[-1]['error']}", flush=True)
    (OUT / "planar_test_summary.json").write_text(json.dumps(finite({"results": results, "failures": failures}), ensure_ascii=False, indent=2), encoding="utf-8")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
