from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import cv2
import numpy as np


CODE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CODE_ROOT))
from evaluate_planar_blind_comparison import detect_checker, object_points

SPLIT_ROOT = Path(r"E:\Data_image_3d\data_3D_20260909\dataset_split")
OUTPUT_ROOT = SPLIT_ROOT / "evaluation_ours_vs_zhang"
CONFIGS = ("Alter_1/30_0.852", "Alter_1/45_0.852", "Alter_2/30", "Alter_2/45")


def numeric(path: Path) -> int:
    return int(path.stem.rsplit("_", 1)[-1])


def finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, np.ndarray):
        return finite(value.tolist())
    if isinstance(value, list):
        return [finite(v) for v in value]
    if isinstance(value, dict):
        return {k: finite(v) for k, v in value.items()}
    return value


def calibrate(key: str) -> dict:
    camera, pose = key.split("/")
    paths = sorted((SPLIT_ROOT / "train" / camera / pose / "2D").glob("*.jpg"), key=numeric)
    obj = object_points(25.0).astype(np.float32)
    objects, images, used, failures = [], [], [], []
    image_size = None
    for path in paths:
        corners, detector = detect_checker(path)
        if corners is None:
            failures.append({"image": path.name, "reason": detector})
            continue
        raw = np.fromfile(str(path), np.uint8)
        gray = cv2.imdecode(raw, cv2.IMREAD_GRAYSCALE)
        image_size = (gray.shape[1], gray.shape[0])
        objects.append(obj.copy())
        images.append(corners.astype(np.float32))
        used.append({"image": path.name, "detector": detector})
    if len(images) < 8 or image_size is None:
        raise RuntimeError(f"{key}: only {len(images)} usable planar training images")
    flags = cv2.CALIB_FIX_K3
    rms, K, dist, rvecs, tvecs = cv2.calibrateCamera(
        objects, images, image_size, None, None, flags=flags,
        criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-12),
    )
    dist5 = np.zeros(5, np.float64)
    dist5[: min(5, dist.size)] = dist.reshape(-1)[:5]
    per_view = []
    for meta, op, ip, rv, tv in zip(used, objects, images, rvecs, tvecs):
        projected = cv2.projectPoints(op, rv, tv, K, dist5)[0].reshape(-1, 2)
        err = projected - ip.reshape(-1, 2)
        per_view.append({**meta, "reprojection_rmse_px": float(np.sqrt(np.mean(np.sum(err * err, axis=1))))})
    payload = finite({
        "schema": "zhang-planar-training/v1",
        "configuration": key,
        "source": "OpenCV calibrateCamera on the frozen 20-image planar training split",
        "is_zhang_reference": True,
        "training_images_requested": len(paths),
        "training_images_used": len(images),
        "failures": failures,
        "image_size": list(image_size),
        "pattern_inner_corners": [9, 6],
        "square_size_mm": 25.0,
        "reprojection_rmse_px": float(rms),
        "cameraMatrix": K,
        "distCoeffs": dist5,
        "flags": ["CALIB_FIX_K3"],
        "per_view": per_view,
    })
    out = OUTPUT_ROOT / "zhang_models" / camera / pose
    out.mkdir(parents=True, exist_ok=True)
    (out / "zhang_camera_model.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[{key}] used={len(images)}/{len(paths)} RMS={rms:.6f} K={K.tolist()} dist={dist5.tolist()}", flush=True)
    return payload


def main() -> int:
    results, failures = [], []
    for key in CONFIGS:
        try:
            results.append(calibrate(key))
        except Exception as exc:
            failures.append({"configuration": key, "error": f"{type(exc).__name__}: {exc}"})
            print(f"[{key}] FAILED {exc}", flush=True)
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    (OUTPUT_ROOT / "zhang_training_summary.json").write_text(
        json.dumps({"results": results, "failures": failures}, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
