"""Freeze the Alter_2/45 3-D development subset after the formal corner gate.

The initial split used a fast visual ROI screen only.  This revision replaces four
frames that failed the formal multi-face association gate with four frames selected
solely by pre-training detectability (no camera-error or Zhang result was used).
"""
from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path


SOURCE = Path(r"E:\Data_image_3d\data_3D_20260909")
SPLIT = SOURCE / "dataset_split"
CAMERA, POSE = "Alter_2", "45"
OLD = {"t_3_1.jpg", "t_3_34.jpg", "t_3_39.jpg", "t_3_48.jpg"}
NEW = {"t_3_42.jpg", "t_3_43.jpg", "t_3_44.jpg", "t_3_46.jpg"}
FINAL = {"t_3_41.jpg", *NEW}


def main() -> int:
    train = SPLIT / "train" / CAMERA / POSE / "3D"
    test = SPLIT / "test" / CAMERA / POSE / "3D"
    source = SOURCE / CAMERA / POSE / "3d"
    for name in OLD:
        (train / name).unlink(missing_ok=True)
        shutil.copy2(source / name, test / name)
    for name in NEW:
        (test / name).unlink(missing_ok=True)
        shutil.copy2(source / name, train / name)
    actual = {p.name for p in train.glob("*.jpg")}
    if actual != FINAL:
        raise RuntimeError(f"Unexpected final training set: {sorted(actual)}")

    manifest_path = SPLIT / "split_manifest.csv"
    with manifest_path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
        fields = list(rows[0])
    for row in rows:
        if row["Camera"] == CAMERA and row["PoseName"] == POSE and row["Modality"] == "3D":
            row["Split"] = "train" if row["FileName"] in FINAL else "test"
            row["SplitRelativePath"] = str(Path(row["Split"]) / CAMERA / POSE / "3D" / row["FileName"])
    with manifest_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader(); writer.writerows(rows)

    summary_path = SPLIT / "split_summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    for item in summary["configurations"]:
        if item["camera"] == CAMERA and item["pose"] == POSE:
            item["three_d_selected"] = sorted(FINAL, key=lambda n: int(Path(n).stem.rsplit("_", 1)[-1]))
            item["three_d_selection_revision"] = {
                "reason": "formal multi-face detectability gate before model fitting",
                "removed": sorted(OLD), "added": sorted(NEW),
                "uses_zhang_parameters": False, "uses_test_metric_results": False,
            }
    summary["strategy"]["three_d"] = "5 per camera-pose; visual coverage selection followed by a frozen formal multi-face detectability screen before model fitting"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"configuration": f"{CAMERA}/{POSE}", "training": sorted(FINAL)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
