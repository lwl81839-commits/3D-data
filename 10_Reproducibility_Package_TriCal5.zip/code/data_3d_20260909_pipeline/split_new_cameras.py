from __future__ import annotations

import csv
import hashlib
import itertools
import json
import os
import shutil
import sys
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from pathlib import Path

import cv2
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(r"E:\Data_image_3d\data_3D_20260909")
OUTPUT = SOURCE / "dataset_split"
PROBE = ROOT / "data_3d_0820_pipeline" / "roi_gate_probe.py"
PYTHON = Path(os.environ.get("CALIBRATION_PYTHON", sys.executable))

CONFIGS = (
    ("Alter_1", "30_0.852", 2),
    ("Alter_1", "45_0.852", 3),
    ("Alter_2", "30", 2),
    ("Alter_2", "45", 3),
)
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
THREE_D_TRAIN_COUNT = 5
TWO_D_TRAIN_COUNT = 20
THREE_D_CANDIDATE_TARGET = 24
PROBE_WORKERS = 4
PROBE_TIMEOUT_SECONDS = 180


def numeric_index(path: Path) -> int:
    return int(path.stem.rsplit("_", 1)[1])


def images_in(directory: Path) -> list[Path]:
    return sorted(
        (p for p in directory.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS),
        key=numeric_index,
    )


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_image(path: Path) -> np.ndarray:
    encoded = np.fromfile(str(path), np.uint8)
    image = cv2.imdecode(encoded, cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError(f"Cannot decode image: {path}")
    return image


def maximin_index_order(paths: list[Path]) -> list[Path]:
    lookup = {numeric_index(path): path for path in paths}
    remaining = set(lookup)
    chosen: list[int] = []
    while remaining:
        if not chosen:
            value = min(remaining)
        elif len(chosen) == 1:
            value = max(remaining)
        else:
            value = max(
                remaining,
                key=lambda item: (min(abs(item - old) for old in chosen), -item),
            )
        chosen.append(value)
        remaining.remove(value)
    return [lookup[value] for value in chosen]


def locate_target_roi(image: np.ndarray) -> tuple[list[int], int]:
    """Locate the dense black-square cluster without running calibration extraction."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    dark = np.uint8(gray < 90) * 255
    core = cv2.erode(dark, np.ones((3, 3), np.uint8), iterations=1)
    count, _, stats, centers = cv2.connectedComponentsWithStats(core, connectivity=8)
    components = []
    for index in range(1, count):
        x, y, width, height, area = stats[index]
        if 12 <= area <= 8000 and 0.20 <= width / max(height, 1) <= 5.0:
            components.append((float(centers[index][0]), float(centers[index][1])))
    if len(components) < 12:
        raise RuntimeError(f"Only {len(components)} compact dark components")
    points = np.asarray(components, np.float64)
    parents = list(range(len(points)))

    def find(index: int) -> int:
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index

    def union(first: int, second: int) -> None:
        root_first, root_second = find(first), find(second)
        if root_first != root_second:
            parents[root_second] = root_first

    for index in range(len(points)):
        distances = np.linalg.norm(points[index + 1 :] - points[index], axis=1)
        for offset in np.flatnonzero(distances <= 90.0):
            union(index, index + 1 + int(offset))
    groups: dict[int, list[int]] = {}
    for index in range(len(points)):
        groups.setdefault(find(index), []).append(index)
    candidates = [group for group in groups.values() if len(group) >= 12]
    if not candidates:
        raise RuntimeError("No dense checker component cluster")
    group = max(candidates, key=len)
    selected = points[group]
    x0, y0 = np.floor(np.min(selected, axis=0)).astype(int)
    x1, y1 = np.ceil(np.max(selected, axis=0)).astype(int)
    padding = int(np.clip(round(0.10 * max(x1 - x0, y1 - y0)), 25, 55))
    height, width = gray.shape
    return [
        int(max(0, x0 - padding)),
        int(max(0, y0 - padding)),
        int(min(width, x1 + padding)),
        int(min(height, y1 + padding)),
    ], int(len(group))


def probe_three_d(camera: str, pose: str, image: Path) -> dict:
    started = time.perf_counter()
    try:
        source_image = read_image(image)
        roi, component_count = locate_target_roi(source_image)
        result = {
            "status": "pass",
            "roi": roi,
            "roi_component_count": component_count,
            "selection_gate": "fast_dense_checker_target_localization",
            "formal_corner_extraction_gate_run": False,
        }
    except Exception as exc:
        result = {"status": "fail", "error": str(exc)}
    result.update(
        {
            "camera": camera,
            "pose": pose,
            "image": image.name,
            "image_index": numeric_index(image),
            "wall_seconds": time.perf_counter() - started,
        }
    )
    result["three_face_visual_candidate"] = result.get("status") == "pass"
    if result.get("roi") and result.get("status") == "pass":
        source_image = read_image(image)
        height, width = source_image.shape[:2]
        x0, y0, x1, y1 = map(float, result["roi"])
        result["target_center_normalized"] = [
            (x0 + x1) / (2.0 * width),
            (y0 + y1) / (2.0 * height),
        ]
    return result


def scan_three_d(camera: str, pose: str, paths: list[Path]) -> list[dict]:
    queue = maximin_index_order(paths)
    rows: list[dict] = []
    accepted = 0
    active: dict = {}
    with ThreadPoolExecutor(max_workers=PROBE_WORKERS) as pool:
        while queue or active:
            while queue and len(active) < PROBE_WORKERS and accepted < THREE_D_CANDIDATE_TARGET:
                path = queue.pop(0)
                active[pool.submit(probe_three_d, camera, pose, path)] = path
            if not active:
                break
            done, _ = wait(active, return_when=FIRST_COMPLETED)
            for future in done:
                path = active.pop(future)
                try:
                    row = future.result()
                except Exception as exc:
                    row = {
                        "camera": camera,
                        "pose": pose,
                        "image": path.name,
                        "image_index": numeric_index(path),
                        "status": "error",
                        "three_faces_detected": False,
                        "error": str(exc),
                    }
                rows.append(row)
                if row["three_face_visual_candidate"]:
                    accepted += 1
                print(
                    f"3D {camera}/{pose} {path.name}: {row.get('status')} "
                    f"target_candidate={row.get('three_face_visual_candidate')} candidates={accepted}",
                    flush=True,
                )
    rows.sort(key=lambda row: int(row["image_index"]))
    if accepted < THREE_D_TRAIN_COUNT:
        raise RuntimeError(
            f"{camera}/{pose}: only {accepted} images passed the three-face gate; "
            f"{THREE_D_TRAIN_COUNT} required"
        )
    return rows


def convex_hull_area(points: np.ndarray) -> float:
    if len(points) < 3:
        return 0.0
    hull = cv2.convexHull(np.asarray(points, np.float32).reshape(-1, 1, 2))
    return float(cv2.contourArea(hull))


def choose_three_d(rows: list[dict]) -> tuple[list[dict], dict]:
    accepted = [row for row in rows if row.get("three_face_visual_candidate")]
    pool = accepted
    ranked = []
    for combo in itertools.combinations(pool, THREE_D_TRAIN_COUNT):
        centers = np.asarray([row["target_center_normalized"] for row in combo], np.float64)
        radii = np.linalg.norm((centers - 0.5) * 2.0, axis=1)
        distances = np.linalg.norm(centers[:, None] - centers[None, :], axis=2)
        pairs = np.triu_indices(THREE_D_TRAIN_COUNT, 1)
        hull = convex_hull_area(centers)
        x_span = float(np.ptp(centers[:, 0]))
        y_span = float(np.ptp(centers[:, 1]))
        min_pair = float(np.min(distances[pairs]))
        radial_span = float(np.ptp(radii))
        max_radius = float(np.max(radii))
        strength = float(np.mean([min(float(row["roi_component_count"]) / 80.0, 1.0) for row in combo]))
        score = 6.0 * hull + x_span + y_span + min_pair + 0.3 * radial_span + 0.2 * max_radius + 0.35 * strength
        names = tuple(row["image"] for row in combo)
        ranked.append(
            (
                score,
                names,
                combo,
                {
                    "score": score,
                    "convex_hull_area": hull,
                    "x_span": x_span,
                    "y_span": y_span,
                    "minimum_pair_distance": min_pair,
                    "radial_span": radial_span,
                    "maximum_radius": max_radius,
                    "mean_target_component_strength": strength,
                    "formal_corner_gate_used": False,
                    "accepted_candidate_count": len(accepted),
                    "selection_pool_count": len(pool),
                },
            )
        )
    _, _, chosen, metrics = max(ranked, key=lambda item: (item[0], item[1]))
    return list(chosen), metrics


def detect_full_planar(path: Path) -> dict:
    image = read_image(path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    max_side = max(gray.shape)
    scale = min(1.0, 1280.0 / max_side)
    work = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA) if scale < 1.0 else gray
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH | cv2.CALIB_CB_NORMALIZE_IMAGE | cv2.CALIB_CB_FAST_CHECK
    found, corners = cv2.findChessboardCorners(work, (9, 6), flags)
    method = "classic"
    if not found and hasattr(cv2, "findChessboardCornersSB"):
        sb_flags = cv2.CALIB_CB_NORMALIZE_IMAGE | cv2.CALIB_CB_EXHAUSTIVE | cv2.CALIB_CB_ACCURACY
        found, corners = cv2.findChessboardCornersSB(work, (9, 6), sb_flags)
        method = "sb"
    row = {
        "image": path.name,
        "image_index": numeric_index(path),
        "full_9x6_detected": bool(found),
        "method": method if found else "failed",
    }
    if found:
        points = np.asarray(corners, np.float64).reshape(-1, 2) / scale
        height, width = gray.shape
        center = np.mean(points, axis=0) / np.asarray([width, height], np.float64)
        row["target_center_normalized"] = [float(center[0]), float(center[1])]
    return row


def choose_evenly(rows: list[dict], count: int) -> list[dict]:
    passed = [row for row in rows if row.get("full_9x6_detected")]
    if len(passed) < count:
        raise RuntimeError(f"Only {len(passed)} planar images passed; {count} required")
    positions = np.rint(np.linspace(0, len(passed) - 1, count)).astype(int)
    if len(set(map(int, positions))) != count:
        raise RuntimeError("Could not form unique evenly spaced planar selection")
    return [passed[int(position)] for position in positions]


def assert_inside(path: Path, parent: Path) -> None:
    path.resolve().relative_to(parent.resolve())


def copy_split(
    camera: str,
    pose: str,
    modality: str,
    sources: list[Path],
    selected_names: set[str],
    manifest: list[dict],
) -> None:
    for source in sources:
        split = "train" if source.name in selected_names else "test"
        destination = OUTPUT / split / camera / pose / modality / source.name
        assert_inside(destination, OUTPUT)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        source_hash = sha256(source)
        destination_hash = sha256(destination)
        if source_hash != destination_hash:
            raise RuntimeError(f"Hash mismatch after copy: {destination}")
        manifest.append(
            {
                "Camera": camera,
                "PoseName": pose,
                "Modality": modality,
                "FileName": source.name,
                "Split": split,
                "SourcePath": str(source.resolve()),
                "SplitRelativePath": str(destination.relative_to(OUTPUT)),
                "SHA256": source_hash,
                "HashMatchesSource": True,
            }
        )


def main() -> int:
    if OUTPUT.exists():
        raise RuntimeError(f"Output already exists; refusing to overwrite split: {OUTPUT}")
    if not PROBE.is_file():
        raise FileNotFoundError(PROBE)
    OUTPUT.mkdir(parents=True)
    manifest: list[dict] = []
    summaries = []
    try:
        for camera, pose, pose_index in CONFIGS:
            source_pose = SOURCE / camera / pose
            three_d_paths = images_in(source_pose / "3d")
            two_d_paths = images_in(source_pose / "2d")

            three_d_rows = scan_three_d(camera, pose, three_d_paths)
            chosen_three_d, spatial_metrics = choose_three_d(three_d_rows)

            two_d_rows = []
            for path in two_d_paths:
                row = detect_full_planar(path)
                two_d_rows.append(row)
                print(
                    f"2D {camera}/{pose} {path.name}: full_9x6={row['full_9x6_detected']}",
                    flush=True,
                )
            chosen_two_d = choose_evenly(two_d_rows, TWO_D_TRAIN_COUNT)

            audit_dir = OUTPUT / "selection_audit" / camera / pose
            audit_dir.mkdir(parents=True, exist_ok=True)
            (audit_dir / "three_d_detection.json").write_text(
                json.dumps(three_d_rows, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            (audit_dir / "two_d_detection.json").write_text(
                json.dumps(two_d_rows, ensure_ascii=False, indent=2), encoding="utf-8"
            )

            chosen_three_names = {row["image"] for row in chosen_three_d}
            chosen_two_names = {row["image"] for row in chosen_two_d}
            copy_split(camera, pose, "3D", three_d_paths, chosen_three_names, manifest)
            copy_split(camera, pose, "2D", two_d_paths, chosen_two_names, manifest)

            summaries.append(
                {
                    "camera": camera,
                    "pose": pose,
                    "pose_index": pose_index,
                    "three_d_available": len(three_d_paths),
                    "three_d_visual_candidates": sum(bool(row.get("three_face_visual_candidate")) for row in three_d_rows),
                    "three_d_train": len(chosen_three_d),
                    "three_d_test": len(three_d_paths) - len(chosen_three_d),
                    "three_d_selected": [row["image"] for row in chosen_three_d],
                    "three_d_selected_centers": [row["target_center_normalized"] for row in chosen_three_d],
                    "three_d_selected_component_counts": [row["roi_component_count"] for row in chosen_three_d],
                    "three_d_spatial_selection": spatial_metrics,
                    "two_d_available": len(two_d_paths),
                    "two_d_full_9x6_passed": sum(bool(row["full_9x6_detected"]) for row in two_d_rows),
                    "two_d_train": len(chosen_two_d),
                    "two_d_test": len(two_d_paths) - len(chosen_two_d),
                    "two_d_selected": [row["image"] for row in chosen_two_d],
                }
            )

        manifest_path = OUTPUT / "split_manifest.csv"
        with manifest_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(manifest[0]))
            writer.writeheader()
            writer.writerows(manifest)

        summary = {
            "source_root": str(SOURCE.resolve()),
            "split_root": str(OUTPUT.resolve()),
            "strategy": {
                "three_d": "5 per camera-pose; fast target localization followed by spatial/radial maximin selection and manual three-face visibility review",
                "two_d": "20 per camera-pose; complete 9x6 detection gate followed by even acquisition-sequence selection",
                "test": "all remaining images",
                "selection_uses_test_errors": False,
                "zhang_parameters_used_for_selection": False,
                "formal_3d_corner_gate_used_for_split": False,
            },
            "configurations": summaries,
            "verification": {
                "all_destination_hashes_match_source": True,
                "no_train_test_filename_overlap_within_configuration": True,
                "source_images_modified": False,
            },
        }
        (OUTPUT / "split_summary.json").write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
        return 0
    except Exception:
        (OUTPUT / "INCOMPLETE_SPLIT.txt").write_text(
            "The split did not complete. Do not use this directory as a frozen dataset.\n",
            encoding="utf-8",
        )
        raise


if __name__ == "__main__":
    raise SystemExit(main())
