from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


CODE_ROOT = Path(__file__).resolve().parents[1]
SPLIT_ROOT = Path(r"E:\Data_image_3d\data_3D_20260909\dataset_split")
OUTPUT_ROOT = SPLIT_ROOT / "evaluation_ours_vs_zhang"
TRACKER = CODE_ROOT / "data_3d_0820_pipeline" / "track_cache_probe.py"

CONFIGS = {
    "Alter_1/30_0.852": {
        "reference": "t_2_53.jpg",
        "cache": SPLIT_ROOT / "selection_audit/formal_probe/Alter_1_30/31f99987c58aa4473cd40ff4ea6a3c62af8896854410b914444636675f193653_sq25_measured_cuboid_corner_offsets_face7x6_v1.npz",
    },
    "Alter_1/45_0.852": {
        "reference": "t_3_76.jpg",
        "cache": SPLIT_ROOT / "selection_audit/formal_probe/Alter_1_45_alt/72aa9406bcae1f4273f1750efe0bb0e586229770028aeade01233cf9cd2fd79c_sq25_measured_cuboid_corner_offsets_face7x6_v1.npz",
    },
    "Alter_2/30": {
        "reference": "t_2_25.jpg",
        "cache": SPLIT_ROOT / "selection_audit/formal_probe/Alter_2_30/16b6ad0eed523efdccdd386dd52b64f631770ab69c0f5d8eeb9e229d2e057350_sq25_measured_cuboid_corner_offsets_face7x6_v1.npz",
    },
    "Alter_2/45": {
        "reference": "t_3_44.jpg",
        "cache": SPLIT_ROOT / "selection_audit/tracking_probe_v3/Alter_2_45_candidates/1f0d48c6ebc16497769df7ad4c4b123cd4128ebc98c3d0945ddccaebe220f45d_sq25_measured_cuboid_corner_offsets_face7x6_v1.npz",
    },
}


def numeric(path: Path) -> int:
    return int(path.stem.rsplit("_", 1)[-1])


def resolve_reference_cache(spec: dict) -> Path:
    candidate = Path(spec["cache"])
    if candidate.is_file():
        return candidate
    matches = list(candidate.glob("*_sq25_measured_cuboid_corner_offsets_face7x6_v1.npz"))
    if len(matches) != 1:
        raise RuntimeError(f"Expected one reference cache in {candidate}, found {len(matches)}")
    return matches[0]


def run_one(key: str, spec: dict) -> dict:
    camera, pose = key.split("/")
    train_dir = SPLIT_ROOT / "train" / camera / pose / "3D"
    images = sorted(train_dir.glob("*.jpg"), key=numeric)
    if len(images) != 5:
        raise RuntimeError(f"{key}: expected 5 3D training images, found {len(images)}")
    reference = train_dir / spec["reference"]
    if reference not in images:
        raise RuntimeError(f"{key}: reference {reference.name} is not in training split")
    reference_cache = resolve_reference_cache(spec)
    model_dir = OUTPUT_ROOT / "models" / camera / pose
    cache_dir = model_dir / ".trihedral_correspondence_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(reference_cache, cache_dir / reference_cache.name)

    tracking = []
    for image in images:
        if image == reference:
            continue
        digest = hashlib.sha256(image.read_bytes()).hexdigest()
        existing = list(cache_dir.glob(f"{digest}_sq25_*.npz"))
        if existing:
            tracking.append({"status": "cached", "image": image.name, "cache": str(existing[0])})
            print(f"[{key}] cache {image.name}: existing", flush=True)
            continue
        proc = subprocess.run(
            [sys.executable, str(TRACKER), str(reference), str(reference_cache), str(image), str(cache_dir)],
            cwd=str(CODE_ROOT), text=True, capture_output=True, encoding="utf-8", errors="replace",
            timeout=90, env={**os.environ, "TRACK_CACHE_MAX_MULTI_TRIALS": "64"},
        )
        last = next((line for line in reversed(proc.stdout.splitlines()) if line.strip()), "{}")
        try:
            payload = json.loads(last)
        except json.JSONDecodeError:
            payload = {"status": "fail", "stdout": proc.stdout, "stderr": proc.stderr}
        payload["returncode"] = proc.returncode
        tracking.append(payload)
        print(f"[{key}] cache {image.name}: {payload.get('status')} faces={payload.get('face_inlier_counts')}", flush=True)

    sys.path.insert(0, str(CODE_ROOT))
    from trained_camera_model import train_camera_model

    model_path = model_dir / "trained_camera_model.json"
    model = train_camera_model(
        [str(p) for p in images], 25.0, str(model_path),
        distortion_model="k1_k2",
        minimum_multi_face_images=1,
        progress=lambda msg: print(f"[{key}] {msg}", flush=True),
    )
    result = {
        "configuration": key,
        "accepted": bool(model.get("accepted")),
        "training_images_used": model.get("training_images_used"),
        "training_multi_face_images": model.get("training_multi_face_images"),
        "cameraMatrix": model.get("cameraMatrix"),
        "distCoeffs": model.get("distCoeffs"),
        "diagnostics": model.get("diagnostics"),
        "cross_validation": model.get("cross_validation"),
        "model_path": str(model_path),
        "tracking": tracking,
        "no_zhang_reference_used": True,
    }
    (model_dir / "training_result.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"[{key}] TRAINED accepted={result['accepted']} dist={result['distCoeffs']}", flush=True)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("configs", nargs="*", choices=list(CONFIGS))
    args = parser.parse_args()
    selected = args.configs or list(CONFIGS)
    results = []
    failures = []
    for key in selected:
        try:
            results.append(run_one(key, CONFIGS[key]))
        except Exception as exc:
            failures.append({"configuration": key, "error": f"{type(exc).__name__}: {exc}"})
            print(f"[{key}] FAILED {type(exc).__name__}: {exc}", flush=True)
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    (OUTPUT_ROOT / "training_summary.json").write_text(
        json.dumps({"results": results, "failures": failures}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
