"""Freeze Alter_1 development frames after the pre-training multi-face gate."""
from __future__ import annotations

import csv
import json
import shutil
from pathlib import Path

SOURCE = Path(r"E:\Data_image_3d\data_3D_20260909")
SPLIT = SOURCE / "dataset_split"
REVISIONS = {
    ("Alter_1", "30_0.852"): {
        "old": {"t_2_1.jpg", "t_2_9.jpg", "t_2_86.jpg", "t_2_89.jpg"},
        "new": {"t_2_5.jpg", "t_2_22.jpg", "t_2_39.jpg", "t_2_78.jpg"},
        "final": {"t_2_5.jpg", "t_2_22.jpg", "t_2_39.jpg", "t_2_53.jpg", "t_2_78.jpg"},
    },
    ("Alter_1", "45_0.852"): {
        "old": {"t_3_3.jpg", "t_3_8.jpg", "t_3_21.jpg", "t_3_82.jpg"},
        "new": {"t_3_9.jpg", "t_3_45.jpg", "t_3_64.jpg", "t_3_78.jpg"},
        "final": {"t_3_9.jpg", "t_3_45.jpg", "t_3_64.jpg", "t_3_76.jpg", "t_3_78.jpg"},
    },
}

def order(names): return sorted(names, key=lambda n: int(Path(n).stem.rsplit("_", 1)[-1]))

def main() -> int:
    for (camera, pose), spec in REVISIONS.items():
        train, test = SPLIT / "train" / camera / pose / "3D", SPLIT / "test" / camera / pose / "3D"
        source = SOURCE / camera / pose / "3d"
        for name in spec["old"]:
            (train / name).unlink(missing_ok=True); shutil.copy2(source / name, test / name)
        for name in spec["new"]:
            (test / name).unlink(missing_ok=True); shutil.copy2(source / name, train / name)
        if {p.name for p in train.glob("*.jpg")} != spec["final"]: raise RuntimeError(f"Bad split for {camera}/{pose}")

    manifest_path = SPLIT / "split_manifest.csv"
    with manifest_path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f)); fields = list(rows[0])
    for row in rows:
        key = (row["Camera"], row["PoseName"])
        if key in REVISIONS and row["Modality"] == "3D":
            row["Split"] = "train" if row["FileName"] in REVISIONS[key]["final"] else "test"
            row["SplitRelativePath"] = str(Path(row["Split"]) / key[0] / key[1] / "3D" / row["FileName"])
    with manifest_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader(); writer.writerows(rows)

    summary_path = SPLIT / "split_summary.json"; summary = json.loads(summary_path.read_text(encoding="utf-8"))
    for item in summary["configurations"]:
        key = (item["camera"], item["pose"])
        if key in REVISIONS:
            spec = REVISIONS[key]; item["three_d_selected"] = order(spec["final"])
            item["three_d_selection_revision"] = {"reason": "formal multi-face detectability gate before final model fitting", "removed": order(spec["old"]), "added": order(spec["new"]), "uses_zhang_parameters": False, "uses_camera_error_metrics": False}
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({f"{c}/{p}": order(v["final"]) for (c,p),v in REVISIONS.items()}, ensure_ascii=False))
    return 0

if __name__ == "__main__": raise SystemExit(main())
