"""Audit and select five strict-three-face frames per camera/pose.

Selection uses only cached corner geometry, face inlier gates, and image position.
It never reads Zhang parameters or calibration/test errors.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

from run_training import CODE_ROOT, CONFIGS, OUTPUT_ROOT, SPLIT_ROOT

sys.path.insert(0, str(CODE_ROOT))
from trained_camera_model import extract_correspondences

SOURCE = SPLIT_ROOT.parent


def numeric(path: Path) -> int:
    return int(path.stem.rsplit("_", 1)[-1])


def strict_rows(key: str) -> tuple[list[dict], list[dict]]:
    camera, pose = key.split("/")
    cache_dir = OUTPUT_ROOT / "models" / camera / pose / ".trihedral_correspondence_cache"
    images = sorted((SOURCE / camera / pose / "3d").glob("*.jpg"), key=numeric)
    passed, failed = [], []
    for image in images:
        digest = hashlib.sha256(image.read_bytes()).hexdigest()
        matches = list(cache_dir.glob(f"{digest}_sq25_*.npz"))
        if not matches:
            failed.append({"image": image.name, "reason": "no_cached_correspondence"})
            continue
        try:
            sample = extract_correspondences(
                str(image), 25.0, correspondence_cache_path=str(matches[0]),
                minimum_usable_faces=3,
            )
            pts = np.vstack([np.asarray(p, np.float64).reshape(-1, 2) for p in sample.image_points if len(p)])
            width, height = sample.image_size
            center = np.mean(pts, axis=0) / np.asarray([width, height], np.float64)
            radius = float(np.linalg.norm(center - 0.5) / np.sqrt(0.5))
            passed.append({
                "image": image.name, "source": str(image), "cache": str(matches[0]),
                "face_point_counts": sample.face_point_counts,
                "face_inlier_counts": sample.face_inlier_counts,
                "center_normalized": center.tolist(), "center_radius_normalized": radius,
            })
        except Exception as exc:
            failed.append({"image": image.name, "reason": str(exc)})
    return passed, failed


def maximin(rows: list[dict], count: int = 5) -> list[dict]:
    if len(rows) <= count: return rows
    features = np.asarray([[*r["center_normalized"], r["center_radius_normalized"]] for r in rows])
    chosen = [int(np.argmax(features[:, 2]))]
    while len(chosen) < count:
        remaining = [i for i in range(len(rows)) if i not in chosen]
        nxt = max(remaining, key=lambda i: float(np.min(np.linalg.norm(features[i] - features[chosen], axis=1))))
        chosen.append(nxt)
    return [rows[i] for i in chosen]


def main() -> int:
    output = {}
    for key in CONFIGS:
        passed, failed = strict_rows(key); chosen = maximin(passed)
        output[key] = {"strict_three_face_count": len(passed), "can_select_five": len(passed) >= 5, "selected": chosen, "all_passed": passed, "failed": failed, "selection_uses_zhang": False, "selection_uses_test_errors": False}
        print(f"[{key}] strict-three-face={len(passed)} selected={[r['image'] for r in chosen]}", flush=True)
    out = SPLIT_ROOT / "selection_audit" / "strict_three_face_selection.json"
    out.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0 if all(v["can_select_five"] for v in output.values()) else 2


if __name__ == "__main__": raise SystemExit(main())
