from __future__ import annotations

import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from run_training import CODE_ROOT, CONFIGS, OUTPUT_ROOT, SPLIT_ROOT, TRACKER, resolve_reference_cache


def numeric(path: Path) -> int:
    return int(path.stem.rsplit("_", 1)[-1])


def process(key: str, reference: Path, reference_cache: Path, cache_dir: Path, image: Path) -> dict:
    try:
        proc = subprocess.run(
            [sys.executable, str(TRACKER), str(reference), str(reference_cache), str(image), str(cache_dir)],
            cwd=str(CODE_ROOT), text=True, capture_output=True, encoding="utf-8", errors="replace", timeout=30,
            env={**os.environ, "TRACK_CACHE_MAX_MULTI_TRIALS": "12"},
        )
        line = next((v for v in reversed(proc.stdout.splitlines()) if v.strip()), "{}")
        try: result = json.loads(line)
        except json.JSONDecodeError: result = {"status": "fail", "error": proc.stderr or proc.stdout}
        result["returncode"] = proc.returncode
    except subprocess.TimeoutExpired:
        result = {"status": "timeout", "error": "30 second extraction timeout; counted as processed but not detected"}
    result["configuration"] = key
    result["image"] = image.name
    return result


def run_config(key: str, spec: dict) -> dict:
    camera, pose = key.split("/")
    train_dir = SPLIT_ROOT / "train" / camera / pose / "3D"
    reference = train_dir / spec["reference"]
    reference_cache = resolve_reference_cache(spec)
    paths = sorted((SPLIT_ROOT / "test" / camera / pose / "3D").glob("*.jpg"), key=numeric)
    cache_dir = OUTPUT_ROOT / "models" / camera / pose / ".trihedral_correspondence_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    results = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(process, key, reference, reference_cache, cache_dir, path): path for path in paths}
        for done_count, future in enumerate(as_completed(futures), 1):
            result = future.result(); results.append(result)
            if done_count % 10 == 0 or result["status"] != "pass":
                print(f"[{key}] {done_count}/{len(paths)} {result['image']} {result['status']} faces={result.get('face_inlier_counts')}", flush=True)
    results.sort(key=lambda r: numeric(Path(r["image"])))
    counts = {status: sum(r["status"] == status for r in results) for status in ("pass", "fail", "timeout")}
    face_histogram = {str(n): sum(sum(int(v) >= 8 for v in r.get("face_inlier_counts", [])) == n for r in results if r["status"] == "pass") for n in (1, 2, 3)}
    payload = {"configuration": key, "test_images": len(paths), "status_counts": counts, "reliable_face_histogram": face_histogram, "reference": str(reference), "reference_cache": str(reference_cache), "uses_zhang_parameters": False, "results": results}
    out = OUTPUT_ROOT / "tests" / camera / pose / "3D"
    out.mkdir(parents=True, exist_ok=True)
    (out / "cache_build.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[{key}] cache summary {counts} faces={face_histogram}", flush=True)
    return payload


def main() -> int:
    summaries = []
    for key, spec in CONFIGS.items(): summaries.append(run_config(key, spec))
    (OUTPUT_ROOT / "three_d_cache_summary.json").write_text(json.dumps(summaries, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
