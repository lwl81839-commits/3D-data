from __future__ import annotations

import csv
import json
from pathlib import Path

from run_training import CONFIGS, OUTPUT_ROOT


def load(path: Path): return json.loads(path.read_text(encoding="utf-8"))
def med(summary: dict, key: str): return summary.get(key, {}).get("median")
def fmt(v): return "—" if v is None else f"{v:.4f}"


def paired_image_wins(ours_eval: dict, zhang_eval: dict, metric: str) -> dict:
    ours = {Path(r["image"]).name: r for r in ours_eval["images"] if r.get("status") == "ok"}
    zhang = {Path(r["image"]).name: r for r in zhang_eval["images"] if r.get("status") == "ok"}
    pairs = []
    for name in sorted(set(ours) & set(zhang)):
        a = ours[name].get(metric, {}).get("median")
        b = zhang[name].get(metric, {}).get("median")
        if a is not None and b is not None: pairs.append((a, b))
    return {"paired": len(pairs), "ours_wins": sum(a < b for a,b in pairs), "zhang_wins": sum(b < a for a,b in pairs), "ties": sum(a == b for a,b in pairs)}


def main() -> int:
    rows, detailed = [], []
    for key in CONFIGS:
        camera, pose = key.split("/")
        model = load(OUTPUT_ROOT / "models" / camera / pose / "trained_camera_model.json")
        zhang = load(OUTPUT_ROOT / "zhang_models" / camera / pose / "zhang_camera_model.json")
        planar = load(OUTPUT_ROOT / "tests" / camera / pose / "2D" / "evaluation.json")
        ours3_eval = load(OUTPUT_ROOT / "tests" / camera / pose / "3D" / "ours_3d_5_images" / "evaluation.json")
        zhang3_eval = load(OUTPUT_ROOT / "tests" / camera / pose / "3D" / "zhang_2d_20_images" / "evaluation.json")
        ours3, zhang3 = ours3_eval["summary"], zhang3_eval["summary"]
        wins3 = paired_image_wins(ours3_eval, zhang3_eval, "holdout_error_px")
        wins2 = planar["comparisons"]["holdout_rmse_px"]
        op, zp = planar["summaries"]["ours_3d_5_images"], planar["summaries"]["zhang_2d_20_images"]
        K, Kz, d, dz = model["cameraMatrix"], zhang["cameraMatrix"], model["distCoeffs"], zhang["distCoeffs"]
        row = {
            "configuration": key, "model_accepted": model["accepted"], "training_multi_face_images": model["training_multi_face_images"],
            "ours_fx": K[0][0], "zhang_fx": Kz[0][0], "fx_relative_difference_pct": abs(K[0][0]-Kz[0][0])/Kz[0][0]*100,
            "ours_fy": K[1][1], "zhang_fy": Kz[1][1], "ours_cx": K[0][2], "zhang_cx": Kz[0][2], "ours_cy": K[1][2], "zhang_cy": Kz[1][2],
            "ours_k1": d[0], "zhang_k1": dz[0], "ours_k2": d[1], "zhang_k2": dz[1],
            "2d_test_detected": planar["detected_images"], "2d_test_total": planar["test_images"],
            "2d_ours_reprojection_median_px": op["reprojection_rmse_px"]["median"], "2d_zhang_reprojection_median_px": zp["reprojection_rmse_px"]["median"],
            "2d_ours_holdout_median_px": op["holdout_rmse_px"]["median"], "2d_zhang_holdout_median_px": zp["holdout_rmse_px"]["median"],
            "2d_paired_images": wins2["paired"], "2d_ours_wins": wins2["ours_wins"], "2d_zhang_wins": wins2["zhang_wins"],
            "2d_ours_object_median_mm": op["holdout_object_rmse_mm"]["median"], "2d_zhang_object_median_mm": zp["holdout_object_rmse_mm"]["median"],
            "3d_test_evaluated": ours3["blind_images_extracted"], "3d_test_total_attempted_or_cached": ours3["blind_images_attempted"] + ours3["uncached_images_skipped_by_request"],
            "3d_single_face": ours3["face_evidence_histogram"].get("1", 0), "3d_two_face": ours3["face_evidence_histogram"].get("2", 0), "3d_three_face": ours3["face_evidence_histogram"].get("3", 0),
            "3d_ours_holdout_median_px": med(ours3, "holdout_error_px"), "3d_zhang_holdout_median_px": med(zhang3, "holdout_error_px"),
            "3d_paired_images": wins3["paired"], "3d_ours_wins": wins3["ours_wins"], "3d_zhang_wins": wins3["zhang_wins"],
            "3d_ours_object_median_mm": med(ours3, "holdout_object_point_rmse_mm"), "3d_zhang_object_median_mm": med(zhang3, "holdout_object_point_rmse_mm"),
            "3d_ours_length_median_mm": med(ours3, "holdout_length_absolute_error_mm"), "3d_zhang_length_median_mm": med(zhang3, "holdout_length_absolute_error_mm"),
            "3d_ours_line_median_px": med(ours3, "undistorted_line_rms_px"), "3d_zhang_line_median_px": med(zhang3, "undistorted_line_rms_px"),
        }
        rows.append(row); detailed.append({"configuration": key, "model": model, "zhang": zhang, "planar": planar, "ours_3d_summary": ours3, "zhang_3d_summary": zhang3, "three_d_paired_holdout_wins": wins3})

    with (OUTPUT_ROOT / "FINAL_CONTROLLED_COMPARISON.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    (OUTPUT_ROOT / "FINAL_CONTROLLED_COMPARISON.json").write_text(json.dumps(detailed, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = ["# 2026-09-09 两台新相机冻结测试结果", "", "三维五图模型的训练未使用张正友参数。二维与三维比较均冻结参数；同一模态内，两种参数使用完全相同的角点和留出划分。", "", "## 参数与训练状态", "", "|配置|通过门限|多面训练图|fx(3D/Zhang)|k1(3D/Zhang)|k2(3D/Zhang)|", "|---|---:|---:|---:|---:|---:|"]
    for r in rows: lines.append(f"|{r['configuration']}|{r['model_accepted']}|{r['training_multi_face_images']}|{r['ours_fx']:.2f}/{r['zhang_fx']:.2f}|{r['ours_k1']:.4f}/{r['zhang_k1']:.4f}|{r['ours_k2']:.4f}/{r['zhang_k2']:.4f}|")
    lines += ["", "## 二维测试（中位数）", "", "|配置|有效图/总图|重投影 px (3D/Zhang)|留出 px (3D/Zhang)|物方 mm (3D/Zhang)|逐图胜场 3D/Zhang|", "|---|---:|---:|---:|---:|---:|"]
    for r in rows: lines.append(f"|{r['configuration']}|{r['2d_test_detected']}/{r['2d_test_total']}|{fmt(r['2d_ours_reprojection_median_px'])}/{fmt(r['2d_zhang_reprojection_median_px'])}|{fmt(r['2d_ours_holdout_median_px'])}/{fmt(r['2d_zhang_holdout_median_px'])}|{fmt(r['2d_ours_object_median_mm'])}/{fmt(r['2d_zhang_object_median_mm'])}|{r['2d_ours_wins']}/{r['2d_zhang_wins']}|")
    lines += ["", "## 三维测试（中位数）", "", "|配置|有效图/总图|面证据 1/2/3|留出 px (3D/Zhang)|物方 mm (3D/Zhang)|边长误差 mm (3D/Zhang)|直线 RMS px (3D/Zhang)|逐图胜场 3D/Zhang|", "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in rows: lines.append(f"|{r['configuration']}|{r['3d_test_evaluated']}/{r['3d_test_total_attempted_or_cached']}|{r['3d_single_face']}/{r['3d_two_face']}/{r['3d_three_face']}|{fmt(r['3d_ours_holdout_median_px'])}/{fmt(r['3d_zhang_holdout_median_px'])}|{fmt(r['3d_ours_object_median_mm'])}/{fmt(r['3d_zhang_object_median_mm'])}|{fmt(r['3d_ours_length_median_mm'])}/{fmt(r['3d_zhang_length_median_mm'])}|{fmt(r['3d_ours_line_median_px'])}/{fmt(r['3d_zhang_line_median_px'])}|{r['3d_ours_wins']}/{r['3d_zhang_wins']}|")
    lines += ["", "## 结论", "", "- 本轮跨相机测试不能支持三维五图法整体优于张正友法；二维测试中张正友四组均更好。", "- 三维测试需要分别查看留出像素、物方误差、边长误差和直线度，不能只用训练重投影误差下结论。", "- 第一台相机 45° 模型未通过训练质量门限，相关数字只能作失败诊断。", "- 三维检测前端仍没有产生严格三面测试证据；该限制与参数求解误差应分开报告。"]
    (OUTPUT_ROOT / "FINAL_TEST_REPORT.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
    print("\n".join(lines), flush=True)
    return 0

if __name__ == "__main__": raise SystemExit(main())
