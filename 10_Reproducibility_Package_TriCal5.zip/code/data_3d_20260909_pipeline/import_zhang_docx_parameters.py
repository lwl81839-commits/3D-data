"""Import the user-supplied MATLAB cameraParams values from each zhang.docx.

MATLAB displays ``cameraParams.IntrinsicMatrix`` in its transposed convention;
the matrix is transposed exactly once when exported to OpenCV K.
"""
from __future__ import annotations

import json
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from docx import Document

from run_training import CONFIGS, OUTPUT_ROOT, SPLIT_ROOT


NUMBER = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?")


def numbers(line: str) -> list[float]:
    return [float(v) for v in NUMBER.findall(line)]


def parse_docx(path: Path) -> tuple[np.ndarray, np.ndarray, dict]:
    lines = [p.text.strip() for p in Document(path).paragraphs if p.text.strip()]
    scale_index = next(i for i, line in enumerate(lines) if "e+03" in line.lower() and "*" in line)
    scale_values = numbers(lines[scale_index])
    # The regex parses MATLAB's ``1.0e+03`` as the numeric multiplier 1000.
    scale = scale_values[-1] if scale_values else 1000.0
    matlab_rows = []
    for line in lines[scale_index + 1 :]:
        values = numbers(line)
        if len(values) == 3:
            matlab_rows.append(values)
            if len(matlab_rows) == 3:
                break
    if len(matlab_rows) != 3:
        raise RuntimeError(f"Could not parse 3x3 IntrinsicMatrix from {path}")
    matlab_intrinsic = np.asarray(matlab_rows, np.float64) * scale
    radial_header = next(i for i, line in enumerate(lines) if "RadialDistortion" in line)
    radial = None
    for line in lines[radial_header + 1 :]:
        values = numbers(line)
        if len(values) == 2:
            radial = values
            break
    if radial is None:
        raise RuntimeError(f"Could not parse RadialDistortion from {path}")
    K = matlab_intrinsic.T
    K /= K[2, 2]
    dist = np.asarray([radial[0], radial[1], 0.0, 0.0, 0.0], np.float64)
    return K, dist, {"paragraphs": lines, "matlab_intrinsic_matrix_display": matlab_intrinsic.tolist()}


def main() -> int:
    imported = []
    for key in CONFIGS:
        camera, pose = key.split("/")
        docx = SPLIT_ROOT / "train" / camera / pose / "2D" / "zhang.docx"
        K, dist, audit = parse_docx(docx)
        target_dir = OUTPUT_ROOT / "zhang_models" / camera / pose
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / "zhang_camera_model.json"
        backup = target_dir / "zhang_camera_model_opencv_recalculated_previous.json"
        if target.is_file() and not backup.exists():
            shutil.copy2(target, backup)
        payload = {
            "schema": "user-supplied-matlab-zhang-parameters/v1",
            "configuration": key,
            "source": str(docx.resolve()),
            "source_type": "MATLAB cameraParams trained on the frozen planar training set",
            "is_zhang_reference": True,
            "imported_utc": datetime.now(timezone.utc).isoformat(),
            "matlab_intrinsic_matrix_transposed_to_opencv": True,
            "cameraMatrix": K.tolist(),
            "distCoeffs": dist.tolist(),
            "distCoeffsOrder": "k1,k2,p1,p2,k3",
            "tangential_distortion_from_document": [0.0, 0.0],
            "audit": audit,
        }
        target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        imported.append(payload)
        print(f"[{key}] K={K.tolist()} dist={dist.tolist()}", flush=True)
    (OUTPUT_ROOT / "zhang_docx_import_summary.json").write_text(
        json.dumps(imported, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
