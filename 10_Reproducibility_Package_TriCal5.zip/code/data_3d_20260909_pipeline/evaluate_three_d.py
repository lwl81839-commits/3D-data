from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

from run_training import CODE_ROOT, CONFIGS, OUTPUT_ROOT, SPLIT_ROOT

EVALUATOR = CODE_ROOT / "evaluate_trained_camera_model.py"


def main() -> int:
    runs, failures = [], []
    for key in CONFIGS:
        camera, pose = key.split("/")
        model = OUTPUT_ROOT / "models" / camera / pose / "trained_camera_model.json"
        zhang = OUTPUT_ROOT / "zhang_models" / camera / pose / "zhang_camera_model.json"
        images = SPLIT_ROOT / "test" / camera / pose / "3D"
        cache = model.parent / ".trihedral_correspondence_cache"
        for method, override in (("ours_3d_5_images", None), ("zhang_2d_20_images", zhang)):
            out = OUTPUT_ROOT / "tests" / camera / pose / "3D" / method
            command = [sys.executable, str(EVALUATOR), "--model", str(model), "--images", str(images), "--output-dir", str(out), "--correspondence-cache-dir", str(cache), "--only-existing-cache", "--allow-unaccepted-model", "--repeats", "20"]
            if override is not None: command += ["--camera-override-json", str(override)]
            proc = subprocess.run(command, cwd=str(CODE_ROOT), text=True, capture_output=True, encoding="utf-8", errors="replace")
            record = {"configuration": key, "method": method, "returncode": proc.returncode, "output_dir": str(out), "stdout": proc.stdout[-4000:], "stderr": proc.stderr[-4000:]}
            if proc.returncode == 0 and (out / "evaluation.json").is_file():
                record["evaluation"] = json.loads((out / "evaluation.json").read_text(encoding="utf-8"))
                runs.append(record)
                summary = record["evaluation"].get("summary", {})
                print(f"[{key}] {method} OK evaluated={summary.get('evaluated_images')} detected={summary.get('detection_success_rate')}", flush=True)
            else:
                failures.append(record); print(f"[{key}] {method} FAILED rc={proc.returncode}", flush=True)
    payload = {"schema": "new-camera-controlled-3d-evaluation/v1", "same_cached_correspondences_for_both_methods": True, "runs": runs, "failures": failures}
    (OUTPUT_ROOT / "three_d_test_summary.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return 1 if failures else 0

if __name__ == "__main__": raise SystemExit(main())
