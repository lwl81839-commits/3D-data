#!/usr/bin/env python3
"""Shared acceptance/boundary policy for the calibration tools."""

from __future__ import annotations

import math
import os
import re
from typing import Any, Dict, Optional


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        value = float(raw)
    except ValueError:
        return default
    return value if math.isfinite(value) else default


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


DISABLE_AREA_RATIO_GATES = _env_bool("CALIB_DISABLE_AREA_RATIO_GATES", False)
MIN_ACCEPTED_CUBE_AREA_PCT = _env_float("CALIB_MIN_ACCEPTED_CUBE_AREA_PCT", 6.0)
SMALL_TARGET_ATTEMPT_MIN_AREA_PCT = _env_float(
    "CALIB_SMALL_TARGET_ATTEMPT_MIN_AREA_PCT", 2.0)
NORMAL_RELIABLE_CUBE_AREA_PCT = 8.0


def maybe_float(value: Any) -> Optional[float]:
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    return out if math.isfinite(out) else None


def extract_cube_area_pct(text: Any) -> Optional[float]:
    """Parse cube area percentage from a user-facing diagnostic string."""
    if text is None:
        return None
    raw = str(text)
    patterns = [
        r"cube image area is\s*([\d.]+)%",
        r"cube area(?:\s+is)?\s*([\d.]+)%",
        r"area\s*([\d.]+)%",
    ]
    for pattern in patterns:
        match = re.search(pattern, raw, flags=re.IGNORECASE)
        if match:
            return maybe_float(match.group(1))
    return None


def cube_area_policy(area_pct: Any) -> Dict[str, Any]:
    """Return a compact area-band policy record for UI and reports."""
    area = maybe_float(area_pct)
    if area is None:
        return {
            "area_pct": None,
            "band": "unknown",
            "label": "unknown area",
            "summary": "Cube area could not be estimated.",
        }
    if area < SMALL_TARGET_ATTEMPT_MIN_AREA_PCT:
        return {
            "area_pct": area,
            "band": f"<{SMALL_TARGET_ATTEMPT_MIN_AREA_PCT:g}%",
            "label": "boundary-only",
            "summary": (
                "Cube footprint is below the current small-target attempt "
                f"floor ({SMALL_TARGET_ATTEMPT_MIN_AREA_PCT:g}%); keep this "
                "image in the method-validity boundary set, not the automatic "
                "calibration target set."
            ),
        }
    if area < NORMAL_RELIABLE_CUBE_AREA_PCT:
        return {
            "area_pct": area,
            "band": (
                f"{SMALL_TARGET_ATTEMPT_MIN_AREA_PCT:g}-"
                f"{NORMAL_RELIABLE_CUBE_AREA_PCT:g}%"
            ),
            "label": "small-target gated",
            "summary": (
                "Cube footprint is in the current small-target band; accept "
                "only when the small-target geometry gate passes, otherwise "
                "keep boundary/held."
            ),
        }
    return {
        "area_pct": area,
        "band": ">=8%",
        "label": "normal area",
        "summary": "Cube footprint is in the normal automatic-calibration area band.",
    }


def area_preflight_decision(
    area_pct: Any,
    *,
    manual_override: bool = False,
    precomputed_corners: bool = False,
) -> Dict[str, Any]:
    """Judge target-size boundaries before automatic face/grid calibration."""
    policy = cube_area_policy(area_pct)
    area = policy["area_pct"]
    bypass = bool(manual_override or precomputed_corners)

    out: Dict[str, Any] = {
        "area_pct": area,
        "area_band": policy["band"],
        "area_policy": policy["summary"],
        "recognition_status": "unknown_area",
        "recognition_label": "UNKNOWN AREA",
        "recognition_summary": "Cube area could not be estimated before calibration.",
        "calibration_status": "area_unknown_gate",
        "calibration_label": "AREA UNKNOWN",
        "calibration_summary": (
            "Automatic calibration may run, but the area boundary cannot be "
            "confirmed until downstream face/grid evidence is available."
        ),
        "can_attempt_detection": True,
        "can_attempt_calibration": True,
        "can_accept_automatic": True,
        "requires_strict_small_target_gate": False,
        "is_boundary": False,
    }

    if bypass:
        out.update(
            {
                "recognition_status": "manual_or_precomputed",
                "recognition_label": "MANUAL/PRECOMPUTED",
                "recognition_summary": (
                    "Automatic cube recognition preflight is bypassed by "
                    "manual ROIs or precomputed corners."
                ),
                "calibration_status": "downstream_quality_gate",
                "calibration_label": "QUALITY GATE",
                "calibration_summary": (
                    "Calibration may run, but final acceptance still depends "
                    "on the geometry and reprojection-quality gates."
                ),
                "can_attempt_detection": True,
                "can_attempt_calibration": True,
                "can_accept_automatic": False,
            }
        )
        return out

    if area is None:
        return out

    if area < SMALL_TARGET_ATTEMPT_MIN_AREA_PCT and not DISABLE_AREA_RATIO_GATES:
        out.update(
            {
                "recognition_status": "area_floor_boundary",
                "recognition_label": "TOO SMALL TO RECOGNIZE RELIABLY",
                "recognition_summary": (
                    "Cube footprint is below the current small-target "
                    "attempt floor."
                ),
                "calibration_status": "blocked_area_floor",
                "calibration_label": "BOUNDARY ONLY",
                "calibration_summary": (
                    "Use this image as the area-ratio boundary/validity "
                    "verification set; do not run automatic calibration."
                ),
                "can_attempt_detection": False,
                "can_attempt_calibration": False,
                "can_accept_automatic": False,
                "requires_strict_small_target_gate": False,
                "is_boundary": True,
            }
        )
        return out

    if area < NORMAL_RELIABLE_CUBE_AREA_PCT:
        if DISABLE_AREA_RATIO_GATES:
            out.update(
                {
                    "recognition_status": "small_target_recognition_band",
                    "recognition_label": "SMALL TARGET, AREA RECORDED",
                    "recognition_summary": (
                        "Cube footprint is small, but area-ratio gates are "
                        "disabled; detection and calibration are governed by "
                        "physical face/grid quality instead."
                    ),
                    "calibration_status": "downstream_quality_gate",
                    "calibration_label": "QUALITY GATE",
                    "calibration_summary": (
                        "Automatic calibration may be attempted and accepted "
                        "if the cube geometry, checker topology, and "
                        "reprojection-quality gates pass."
                    ),
                    "can_attempt_detection": True,
                    "can_attempt_calibration": True,
                    "can_accept_automatic": True,
                    "requires_strict_small_target_gate": False,
                    "is_boundary": False,
                }
            )
            return out
        out.update(
            {
                "recognition_status": "small_target_recognition_band",
                "recognition_label": "SMALL TARGET, RECOGNITION ATTEMPT",
                "recognition_summary": (
                    "Cube footprint is large enough to try recognition, but "
                    "the face/grid evidence is expected to be fragile."
                ),
                "calibration_status": "strict_small_target_gate",
                "calibration_label": "STRICT SMALL-TARGET GATE",
                "calibration_summary": (
                    "Automatic calibration may be attempted, but it is "
                    "accepted only if the strict small-target geometry gate "
                    "passes."
                ),
                "can_attempt_detection": True,
                "can_attempt_calibration": True,
                "can_accept_automatic": False,
                "requires_strict_small_target_gate": True,
                "is_boundary": True,
            }
        )
        return out

    out.update(
        {
            "recognition_status": "normal_area_recognition_band",
            "recognition_label": "NORMAL AREA",
            "recognition_summary": (
                "Cube footprint is in the normal band for automatic "
                "cube/face/grid recognition."
            ),
            "calibration_status": "normal_quality_gate",
            "calibration_label": "NORMAL QUALITY GATE",
            "calibration_summary": (
                "Calibration may run and can be accepted if face visibility, "
                "geometry, and reprojection-quality gates pass."
            ),
            "can_attempt_detection": True,
            "can_attempt_calibration": True,
            "can_accept_automatic": True,
            "requires_strict_small_target_gate": False,
            "is_boundary": False,
        }
    )
    return out


def calibration_decision(status: Any, area_pct: Any = None) -> Dict[str, Any]:
    """Map internal status strings to the product-level decision vocabulary."""
    status_text = str(status or "").strip().lower().replace(" ", "_")
    if status_text in {"ok", "accepted", "success"}:
        decision = "accepted"
        label = "ACCEPTED"
        summary = "Calibration accepted."
    elif status_text in {
        "range_boundary",
        "target_too_small",
        "partial_face_geometry_boundary",
        "partial_face_boundary",
    }:
        decision = "boundary"
        label = "BOUNDARY"
        summary = "Use this image as a calibration distance/area boundary."
    else:
        decision = "held"
        label = "HELD"
        summary = "Result is not accepted; recapture or review before use."
    preflight = area_preflight_decision(area_pct)
    result = {
        "decision": decision,
        "label": label,
        "summary": summary,
        "area_band": preflight["area_band"],
        "area_policy": preflight["area_policy"],
    }
    result.update(
        {
            key: preflight[key]
            for key in [
                "recognition_status",
                "recognition_label",
                "recognition_summary",
                "calibration_status",
                "calibration_label",
                "calibration_summary",
                "can_attempt_detection",
                "can_attempt_calibration",
                "can_accept_automatic",
                "requires_strict_small_target_gate",
                "is_boundary",
            ]
        }
    )

    if status_text in {"ok", "accepted", "success"}:
        result.update(
            {
                "calibration_status": "accepted",
                "calibration_label": "ACCEPTED",
                "calibration_summary": "Calibration passed the active acceptance gates.",
                "can_accept_automatic": True,
                "is_boundary": False,
            }
        )
    elif status_text in {"range_boundary", "target_too_small"}:
        result.update(
            {
                "calibration_status": "blocked_target_size",
                "calibration_label": "BOUNDARY ONLY",
                "calibration_summary": (
                    "The target-size gate blocked automatic calibration; keep "
                    "this image as a distance/area boundary."
                ),
                "can_attempt_calibration": False,
                "can_accept_automatic": False,
                "is_boundary": True,
            }
        )
    elif status_text in {"partial_face_geometry_boundary", "partial_face_boundary"}:
        result.update(
            {
                "recognition_status": "partial_faces_recognized",
                "recognition_label": "PARTIAL FACE EVIDENCE",
                "recognition_summary": (
                    "Some cube-face evidence was found, but at least one "
                    "usable face is geometrically sparse or incomplete."
                ),
                "calibration_status": "blocked_partial_face_geometry",
                "calibration_label": "PARTIAL FACE BOUNDARY",
                "calibration_summary": (
                    "Do not accept calibration until every used face has "
                    "enough reliable checkerboard geometry."
                ),
                "can_accept_automatic": False,
                "is_boundary": True,
            }
        )
    elif status_text == "insufficient_visible_faces":
        result.update(
            {
                "recognition_status": "insufficient_visible_faces",
                "recognition_label": "INSUFFICIENT VISIBLE FACES",
                "recognition_summary": (
                    "The cube/target was partly recognized, but fewer than "
                    "three usable faces were visible."
                ),
                "calibration_status": "blocked_insufficient_faces",
                "calibration_label": "FACE VISIBILITY BOUNDARY",
                "calibration_summary": (
                    "Do not calibrate from this image until all required cube "
                    "faces are visible and usable."
                ),
                "can_accept_automatic": False,
                "is_boundary": True,
            }
        )
    elif status_text in {"target_not_visible", "detect_failed"}:
        result.update(
            {
                "recognition_status": "target_not_recognized",
                "recognition_label": "TARGET NOT RECOGNIZED",
                "recognition_summary": (
                    "The automatic pipeline did not find usable cube-face "
                    "checkerboard evidence."
                ),
                "calibration_status": "blocked_not_recognized",
                "calibration_label": "NO CALIBRATION",
                "calibration_summary": (
                    "Calibration is blocked until the cube and its face grids "
                    "can be recognized."
                ),
                "can_attempt_calibration": False,
                "can_accept_automatic": False,
                "is_boundary": False,
            }
        )
    elif status_text == "not_cube_target":
        result.update(
            {
                "recognition_status": "not_cube_target",
                "recognition_label": "NOT CUBE TARGET",
                "recognition_summary": (
                    "The image does not satisfy the required three-visible-face "
                    "cube/cuboid target geometry."
                ),
                "calibration_status": "blocked_not_cube_target",
                "calibration_label": "NO CUBE CALIBRATION",
                "calibration_summary": (
                    "Do not run cube calibration on this image; it is outside "
                    "the single-frame three-face cube method and should not "
                    "fall back to planar Zhang calibration."
                ),
                "can_attempt_calibration": False,
                "can_accept_automatic": False,
                "is_boundary": False,
            }
        )
    elif status_text == "low_confidence":
        result.update(
            {
                "recognition_status": "recognized_low_confidence",
                "recognition_label": "RECOGNIZED, LOW CONFIDENCE",
                "recognition_summary": (
                    "The target was recognized, but the single-frame geometry "
                    "is not stable enough for acceptance."
                ),
                "calibration_status": "blocked_low_confidence",
                "calibration_label": "LOW CONFIDENCE",
                "calibration_summary": (
                    "Do not accept this calibration; use it as a stability "
                    "boundary or recapture with stronger three-face evidence."
                ),
                "can_accept_automatic": False,
                "is_boundary": True,
            }
        )
    elif status_text == "focal_not_identifiable":
        result.update(
            {
                "recognition_status": "three_faces_recognized",
                "recognition_label": "THREE FACES RECOGNIZED",
                "recognition_summary": (
                    "The cube and three face grids were recognized, but the "
                    "single-frame focal profile has no distinct optimum."
                ),
                "calibration_status": "blocked_focal_not_identifiable",
                "calibration_label": "FOCAL NOT IDENTIFIABLE",
                "calibration_summary": (
                    "Do not report a unique intrinsic calibration from this "
                    "frame; retain it as an intrinsics-observability boundary."
                ),
                "can_attempt_calibration": True,
                "can_accept_automatic": False,
                "is_boundary": True,
            }
        )
    return result
