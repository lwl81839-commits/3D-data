#!/usr/bin/env python3
"""
Best Calibration Method — synthesises all experimental findings.

Key design decisions (validated by 100+ trials):
  1. cornerSubPix: 11×11 window, 100 iterations, 1e-6 epsilon
  2. IAC before distortion estimation (K_init >> K_approx)
  3. 5-param BA with k2 regularisation for wide-angle lenses
  4. k1-only BA for consumer webcams (k2 is noise)
  5. 2/3 FOV guidance for optimal principal-point estimation
  6. Optional external constraints (EXIF focal length, measured height)

Usage:
  python best_calibration.py image.jpg 25.0              # auto-detect model
  python best_calibration.py image.jpg 30.0 --k1-only    # force k1-only
  python best_calibration.py image.jpg 25.0 --focal 1200 # EXIF constraint
"""

from __future__ import annotations

import sys, os, json, time, itertools
import importlib
from dataclasses import dataclass, field
from typing import List, Tuple, Optional

import cv2
import numpy as np
from scipy.optimize import least_squares

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from three_face_calib import (
    FaceDefinition, DetectedFace, CalibrationResult, VanishingPoint,
    standard_three_face_target, preprocess_image,
    lines_from_chessboard_corners, estimate_vanishing_point,
    calibrate_intrinsics_from_vps, calibrate_extrinsics,
    estimate_distortion_from_lines, bundle_adjust,
    get_vp_labels, compute_corner_sharpness,
    estimate_blur_level, adaptive_subpix_window, detect_corners_multiscale,
    object_points_for_face, apply_best_face_orientations,
)
from single_cube_zhang_calibration import calibrate_single_cube_zhang


def ensure_numpy_pickle_compat() -> None:
    """Allow NumPy 1.x to read object arrays pickled by NumPy 2.x."""
    try:
        np_core = importlib.import_module("numpy.core")
        sys.modules.setdefault("numpy._core", np_core)
        for name in ("multiarray", "numeric", "umath", "_multiarray_umath"):
            try:
                module = importlib.import_module(f"numpy.core.{name}")
            except Exception:
                continue
            sys.modules.setdefault(f"numpy._core.{name}", module)
    except Exception:
        return
from calibration_policy import (
    MIN_ACCEPTED_CUBE_AREA_PCT,
    NORMAL_RELIABLE_CUBE_AREA_PCT,
    area_preflight_decision,
)


# ═══════════════════════════════════════════════════════════════════════════

def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        value = float(raw)
    except ValueError:
        return default
    return value if np.isfinite(value) else default


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _model_grade_from_name(model_used: str) -> str:
    model_name = str(model_used or "")
    if model_name == "vp-only":
        return "diagnostic_only"
    if model_name.startswith("single-cube-zhang"):
        return "full_single_cube_zhang"
    if model_name in {"5-param", "k1-only"}:
        return "free_intrinsic_ba"
    if (
        model_name.startswith("fixed-focal")
        or model_name.startswith("fixed-intrinsics")
        or model_name.startswith("single-view-wide-offset-fixed-focal")
    ):
        return "bounded_focal_pose"
    if model_name.startswith("single-view-wide-offset-focal-scan"):
        return "bounded_focal_scan"
    if model_name.startswith("single-view"):
        return "bounded_single_view"
    return "accepted_other"


def _accepted_model_grade_filter() -> set[str]:
    raw = os.environ.get("CALIB_ACCEPT_MODEL_GRADES", "").strip()
    if not raw:
        return set()
    return {
        item.strip()
        for item in raw.replace(";", ",").split(",")
        if item.strip()
    }


def _isolated_model_grade_filter() -> set[str]:
    raw = os.environ.get("CALIB_ISOLATE_MODEL_GRADES", "").strip()
    if not raw:
        return set()
    return {
        item.strip()
        for item in raw.replace(";", ",").split(",")
        if item.strip()
    }


DEFAULT_SQUARE_SIZE_MM = 25.0
# Backward-compatible name: this is now only the dataset/default scale.
FIXED_SQUARE_SIZE_MM = DEFAULT_SQUARE_SIZE_MM
MAX_CONFIDENT_FOCAL_DIAG_MULT = 0.85
MIN_CONFIDENT_FOCAL_DIAG_MULT = 0.30
MAX_CONFIDENT_RMSE_PX = 12.0
ENABLE_FOCAL_OBSERVABILITY_GATE = _env_bool(
    "CALIB_ENABLE_FOCAL_OBSERVABILITY_GATE", True)
FOCAL_OBSERVABILITY_STEP_DIAG_MULT = _env_float(
    "CALIB_FOCAL_OBSERVABILITY_STEP_DIAG_MULT", 0.05)
FOCAL_OBSERVABILITY_MIN_CONTRAST_PX = _env_float(
    "CALIB_FOCAL_OBSERVABILITY_MIN_CONTRAST_PX", 0.50)
FOCAL_OBSERVABILITY_PLATEAU_GAP_PX = _env_float(
    "CALIB_FOCAL_OBSERVABILITY_PLATEAU_GAP_PX", 0.25)
FOCAL_OBSERVABILITY_MAX_PLATEAU_WIDTH_DIAG = _env_float(
    "CALIB_FOCAL_OBSERVABILITY_MAX_PLATEAU_WIDTH_DIAG", 0.35)
FOCAL_OBSERVABILITY_EDGE_MARGIN_DIAG = _env_float(
    "CALIB_FOCAL_OBSERVABILITY_EDGE_MARGIN_DIAG", 0.05)
MIN_RELIABLE_CUBE_AREA_PCT = NORMAL_RELIABLE_CUBE_AREA_PCT
DISABLE_AREA_RATIO_GATES = _env_bool("CALIB_DISABLE_AREA_RATIO_GATES", False)
MIN_SMALL_TARGET_ATTEMPT_CUBE_AREA_PCT = _env_float(
    "CALIB_SMALL_TARGET_ATTEMPT_MIN_AREA_PCT", 2.0)
MAX_SMALL_TARGET_RMSE_PX = MAX_CONFIDENT_RMSE_PX
MAX_SCALE_PRIOR_SMALL_TARGET_RMSE_PX = _env_float(
    "CALIB_SCALE_PRIOR_MAX_SMALL_TARGET_RMSE_PX", 14.5)
MAX_SMALL_TARGET_CORNER_QUALITY_PX = 0.85
MAX_SMALL_TARGET_INITIAL_PNP_RMSE_PX = 15.0
MAX_SCALE_PRIOR_INITIAL_PNP_RMSE_PX = _env_float(
    "CALIB_SCALE_PRIOR_MAX_INITIAL_PNP_RMSE_PX", 15.5)
MAX_SCALE_PRIOR_RELAXED_INITIAL_PNP_RMSE_PX = _env_float(
    "CALIB_SCALE_PRIOR_RELAXED_MAX_INITIAL_PNP_RMSE_PX", 24.0)
MIN_SMALL_TARGET_CORNERS = 120
SMALL_TARGET_CANONICAL_PATTERNS = ((9, 6), (9, 6), (6, 6))
SMALL_TARGET_PATTERN_GATE_MODE = os.environ.get(
    "CALIB_SMALL_TARGET_PATTERN_GATE_MODE", "general"
).strip().lower()
MIN_SMALL_TARGET_FACE_INNER_DIM = int(_env_float(
    "CALIB_SMALL_TARGET_MIN_FACE_INNER_DIM", 5))
SCALE_PRIOR_TRIHEDRAL_CLOSURE_PATTERNS = {
    (9, 6),
    (8, 6),
    (7, 6),
    (6, 6),
}
SMALL_TARGET_MAX_FOCAL_DIAG_MULT = 0.85
SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT = _env_float(
    "CALIB_SMALL_TARGET_ACCEPT_MIN_AREA_PCT", 2.00)
SMALL_TARGET_VALIDATED_ACCEPT_MAX_AREA_PCT = _env_float(
    "CALIB_SMALL_TARGET_ACCEPT_MAX_AREA_PCT", 8.00)
SMALL_TARGET_FOCAL_SCAN_MAX_PRIOR_DEVIATION_FRAC = _env_float(
    "CALIB_SMALL_TARGET_FOCAL_SCAN_MAX_PRIOR_DEVIATION_FRAC", 0.08)
PRECOMPUTED_FOCAL_SCAN_MAX_PRIOR_DEVIATION_FRAC = _env_float(
    "CALIB_PRECOMPUTED_FOCAL_SCAN_MAX_PRIOR_DEVIATION_FRAC", 0.25)
PRECOMPUTED_FOCAL_SCAN_MIN_GAIN_PX = _env_float(
    "CALIB_PRECOMPUTED_FOCAL_SCAN_MIN_GAIN_PX", 2.0)
SMALL_TARGET_FOCAL_SCAN_MIN_GAIN_PX = _env_float(
    "CALIB_SMALL_TARGET_FOCAL_SCAN_MIN_GAIN_PX", 0.25)
SMALL_TARGET_MAX_FOV_COVERAGE_PCT = _env_float(
    "CALIB_SMALL_TARGET_MAX_FOV_COVERAGE_PCT", 3.60)
SMALL_TARGET_EXTENDED_MAX_FOV_COVERAGE_PCT = _env_float(
    "CALIB_SMALL_TARGET_EXTENDED_MAX_FOV_COVERAGE_PCT", 4.60)
SMALL_TARGET_EXTENDED_MIN_CUBE_AREA_PCT = _env_float(
    "CALIB_SMALL_TARGET_EXTENDED_MIN_CUBE_AREA_PCT", 7.00)
SMALL_TARGET_EXTENDED_MAX_RMSE_PX = _env_float(
    "CALIB_SMALL_TARGET_EXTENDED_MAX_RMSE_PX", 9.30)
SMALL_TARGET_EXTENDED_MAX_CORNER_QUALITY_PX = _env_float(
    "CALIB_SMALL_TARGET_EXTENDED_MAX_CORNER_QUALITY_PX", 0.45)
SMALL_TARGET_EXTENDED_MAX_INITIAL_PNP_RMSE_PX = _env_float(
    "CALIB_SMALL_TARGET_EXTENDED_MAX_INITIAL_PNP_RMSE_PX", 14.0)
SMALL_TARGET_MAX_PATTERN_STEP_DEFICIT = int(_env_float(
    "CALIB_SMALL_TARGET_MAX_PATTERN_STEP_DEFICIT", 1))
SCALE_PRIOR_MAX_PARTIAL_PATTERN_STEP_DEFICIT = int(_env_float(
    "CALIB_SCALE_PRIOR_MAX_PARTIAL_PATTERN_STEP_DEFICIT", 2))
SCALE_PRIOR_MIN_PARTIAL_TEMPLATE_CORNERS = int(_env_float(
    "CALIB_SCALE_PRIOR_MIN_PARTIAL_TEMPLATE_CORNERS", 132))
SCALE_PRIOR_MAX_PARTIAL_TEMPLATE_RMSE_PX = _env_float(
    "CALIB_SCALE_PRIOR_MAX_PARTIAL_TEMPLATE_RMSE_PX", 8.0)
SCALE_PRIOR_MAX_OVERCOMPLETE_SMALL_FACE_STEPS = int(_env_float(
    "CALIB_SCALE_PRIOR_MAX_OVERCOMPLETE_SMALL_FACE_STEPS", 1))
SCALE_PRIOR_MIN_OVERCOMPLETE_TEMPLATE_CORNERS = int(_env_float(
    "CALIB_SCALE_PRIOR_MIN_OVERCOMPLETE_TEMPLATE_CORNERS", 144))
SCALE_PRIOR_MAX_OVERCOMPLETE_TEMPLATE_CORNERS = int(_env_float(
    "CALIB_SCALE_PRIOR_MAX_OVERCOMPLETE_TEMPLATE_CORNERS", 156))
SCALE_PRIOR_MAX_OVERCOMPLETE_TEMPLATE_RMSE_PX = _env_float(
    "CALIB_SCALE_PRIOR_MAX_OVERCOMPLETE_TEMPLATE_RMSE_PX", 12.5)
SCALE_PRIOR_OVERCOMPLETE_TEMPLATE_MAX_AREA_PCT = _env_float(
    "CALIB_SCALE_PRIOR_OVERCOMPLETE_TEMPLATE_MAX_AREA_PCT", 3.0)
SMALL_TARGET_PATTERN_REPAIR_MAX_CENTERED_PNP_RMSE_PX = _env_float(
    "CALIB_SMALL_TARGET_PATTERN_REPAIR_MAX_CENTERED_PNP_RMSE_PX", 14.0)
SMALL_TARGET_PATTERN_REPAIR_MAX_OFFSET_PNP_RMSE_PX = _env_float(
    "CALIB_SMALL_TARGET_PATTERN_REPAIR_MAX_OFFSET_PNP_RMSE_PX", 5.80)
ENABLE_CUBE_SPATIAL_UNDERSTANDING = _env_bool(
    "CALIB_ENABLE_CUBE_SPATIAL_UNDERSTANDING", True)
STRICT_CUBE_SPATIAL_UNDERSTANDING = _env_bool(
    "CALIB_STRICT_CUBE_SPATIAL_UNDERSTANDING", True)
ENABLE_EARLY_VP_ZHANG_SEED = _env_bool(
    "CALIB_ENABLE_EARLY_VP_ZHANG_SEED", False)
GUARD_EARLY_VP_ZHANG_SEED = _env_bool(
    "CALIB_GUARD_EARLY_VP_ZHANG_SEED", True)
ENABLE_SCALE_PRIOR_CANDIDATES = _env_bool(
    "CALIB_ENABLE_SCALE_PRIOR_CANDIDATES", True)
ENABLE_SCALE_PRIOR_FAST_FIXED_FOCAL = _env_bool(
    "CALIB_SCALE_PRIOR_FAST_FIXED_FOCAL", True)
SCALE_PRIOR_FAST_FIXED_FOCAL_MAX_AREA_PCT = _env_float(
    "CALIB_SCALE_PRIOR_FAST_FIXED_FOCAL_MAX_AREA_PCT", 3.0)


def _small_target_pattern_signature(patterns):
    return tuple(sorted(
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in patterns
    ))


SMALL_TARGET_CANONICAL_PATTERN_SIGNATURE = _small_target_pattern_signature(
    SMALL_TARGET_CANONICAL_PATTERNS)


def _small_target_patterns_allowed(patterns) -> bool:
    observed = [
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in patterns
    ]
    if SMALL_TARGET_PATTERN_GATE_MODE in {
        "general",
        "generalized",
        "generic",
        "geometry",
    }:
        return (
            len(observed) == 3
            and all(
                min(cols, rows) >= MIN_SMALL_TARGET_FACE_INNER_DIM
                for cols, rows in observed
            )
            and sum(cols * rows for cols, rows in observed)
            >= MIN_SMALL_TARGET_CORNERS
        )
    observed = [
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in patterns
    ]
    canonical = [
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in SMALL_TARGET_CANONICAL_PATTERNS
    ]
    if tuple(sorted(observed)) == tuple(sorted(canonical)):
        return True
    if SMALL_TARGET_MAX_PATTERN_STEP_DEFICIT <= 0:
        return False
    best_deficit = None
    for perm in itertools.permutations(canonical):
        total_deficit = 0
        ok = True
        for obs, ref in zip(observed, perm):
            if obs[0] > ref[0] or obs[1] > ref[1]:
                ok = False
                break
            total_deficit += (ref[0] - obs[0]) + (ref[1] - obs[1])
        if not ok:
            continue
        if best_deficit is None or total_deficit < best_deficit:
            best_deficit = total_deficit
    return (
        best_deficit is not None
        and best_deficit <= SMALL_TARGET_MAX_PATTERN_STEP_DEFICIT
    )


def _small_target_pattern_gate_description() -> str:
    if SMALL_TARGET_PATTERN_GATE_MODE in {
        "general",
        "generalized",
        "generic",
        "geometry",
    }:
        return (
            "three visible checkerboard faces, each with at least "
            f"{MIN_SMALL_TARGET_FACE_INNER_DIM} inner corners in both "
            f"directions and at least {MIN_SMALL_TARGET_CORNERS} total "
            "corners; row/column counts are not fixed"
        )
    return (
        f"{SMALL_TARGET_CANONICAL_PATTERNS} up to per-face row/column "
        "rotation"
    )


def _small_target_pattern_deficit(patterns):
    observed = [
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in patterns
    ]
    canonical = [
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in SMALL_TARGET_CANONICAL_PATTERNS
    ]
    best_deficit = None
    for perm in itertools.permutations(canonical):
        total_deficit = 0
        ok = True
        for obs, ref in zip(observed, perm):
            if obs[0] > ref[0] or obs[1] > ref[1]:
                ok = False
                break
            total_deficit += (ref[0] - obs[0]) + (ref[1] - obs[1])
        if not ok:
            continue
        if best_deficit is None or total_deficit < best_deficit:
            best_deficit = total_deficit
    return best_deficit


def _scale_prior_partial_template_allowed(patterns, n_corners, rmse) -> tuple[bool, int | None]:
    deficit = _small_target_pattern_deficit(patterns)
    ok = (
        deficit is not None
        and deficit <= SCALE_PRIOR_MAX_PARTIAL_PATTERN_STEP_DEFICIT
        and int(n_corners) >= SCALE_PRIOR_MIN_PARTIAL_TEMPLATE_CORNERS
        and np.isfinite(rmse)
        and float(rmse) <= SCALE_PRIOR_MAX_PARTIAL_TEMPLATE_RMSE_PX
    )
    return bool(ok), deficit


def _scale_prior_partial_template_prefilter_allowed(patterns, n_corners) -> tuple[bool, int | None]:
    deficit = _small_target_pattern_deficit(patterns)
    ok = (
        deficit is not None
        and deficit <= SCALE_PRIOR_MAX_PARTIAL_PATTERN_STEP_DEFICIT
        and int(n_corners) >= SCALE_PRIOR_MIN_PARTIAL_TEMPLATE_CORNERS
    )
    return bool(ok), deficit


def _small_target_overcomplete_small_face_steps(patterns):
    """Return one-face surplus steps for a near-canonical overcomplete small face."""
    observed = [
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in patterns
    ]
    canonical = [
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in SMALL_TARGET_CANONICAL_PATTERNS
    ]
    best = None
    for perm in itertools.permutations(canonical):
        surplus = 0
        overcomplete_small_faces = 0
        ok = True
        for obs, ref in zip(observed, perm):
            if ref == (6, 6):
                if obs == ref:
                    continue
                if obs[1] == ref[1] and obs[0] > ref[0]:
                    surplus += obs[0] - ref[0]
                    overcomplete_small_faces += 1
                    continue
                ok = False
                break
            if obs != ref:
                ok = False
                break
        if not ok:
            continue
        if overcomplete_small_faces > 1:
            continue
        if best is None or surplus < best:
            best = surplus
    return best


def _scale_prior_overcomplete_template_prefilter_allowed(
    patterns,
    n_corners,
) -> tuple[bool, int | None]:
    surplus = _small_target_overcomplete_small_face_steps(patterns)
    ok = (
        surplus is not None
        and 0 < surplus <= SCALE_PRIOR_MAX_OVERCOMPLETE_SMALL_FACE_STEPS
        and int(n_corners) >= SCALE_PRIOR_MIN_OVERCOMPLETE_TEMPLATE_CORNERS
        and int(n_corners) <= SCALE_PRIOR_MAX_OVERCOMPLETE_TEMPLATE_CORNERS
    )
    return bool(ok), surplus


def _scale_prior_overcomplete_template_allowed(
    patterns,
    n_corners,
    rmse,
    model_used,
    cube_area_pct,
    focal_px,
) -> tuple[bool, int | None]:
    prefilter_ok, surplus = _scale_prior_overcomplete_template_prefilter_allowed(
        patterns,
        n_corners,
    )
    model_name = str(model_used)
    fixed_focal_model = (
        model_name in {
            "fixed-focal-k1",
            "fixed-focal-zero-dist",
            "fixed-intrinsics",
        }
        or model_name.startswith("single-view-wide-offset-fixed-focal")
    )
    area_ok = (
        DISABLE_AREA_RATIO_GATES
        or (
            cube_area_pct is not None
            and np.isfinite(cube_area_pct)
            and float(cube_area_pct) <= SCALE_PRIOR_OVERCOMPLETE_TEMPLATE_MAX_AREA_PCT
        )
    )
    ok = (
        prefilter_ok
        and focal_px is not None
        and np.isfinite(focal_px)
        and float(focal_px) > 0
        and area_ok
        and fixed_focal_model
        and np.isfinite(rmse)
        and float(rmse) <= SCALE_PRIOR_MAX_OVERCOMPLETE_TEMPLATE_RMSE_PX
    )
    return bool(ok), surplus


def _scale_prior_trihedral_closure_prefilter_allowed(
    patterns,
    n_corners,
    *,
    trihedral_closure_source: bool,
) -> bool:
    if not trihedral_closure_source:
        return False
    if int(n_corners) < MIN_SMALL_TARGET_CORNERS:
        return False
    observed = {
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in patterns
    }
    return bool(
        observed
        and observed.issubset(SCALE_PRIOR_TRIHEDRAL_CLOSURE_PATTERNS)
    )


def _vp_focal_estimate_for_cube_candidate(detections, image_shape, n_faces=3):
    if len(detections or []) < n_faces:
        return None
    h_img, w_img = image_shape[:2]
    vp_labels = get_vp_labels(n_faces)
    vp_per_face = []
    try:
        for fi, (corners, pattern, _label) in enumerate(detections[:n_faces]):
            row_lines, col_lines, _rq, _cq = lines_from_chessboard_corners(
                corners, pattern, use_ransac=True)
            vpx = estimate_vanishing_point(np.array(row_lines))
            vpy = estimate_vanishing_point(np.array(col_lines))
            vpx.direction_label = vp_labels[fi][0]
            vpy.direction_label = vp_labels[fi][1]
            vp_per_face.append({vp_labels[fi][0]: vpx, vp_labels[fi][1]: vpy})

        vp_avg = {}
        for label in ["X", "Y", "Z"]:
            V = np.array([
                vp.v
                for face_vps in vp_per_face
                for vp_label, vp in face_vps.items()
                if vp_label == label
            ])
            if len(V) == 0:
                continue
            vm = np.median(V, axis=0)
            if abs(vm[2]) > 1e-6:
                vm /= vm[2]
            vp_avg[label] = VanishingPoint(v=vm, direction_label=label)
        if len(vp_avg) < 3:
            return None

        labels = sorted(vp_avg.keys())
        indices = {label: i for i, label in enumerate(labels)}
        ortho_pairs = [
            (indices[a], indices[b])
            for a, b in [("X", "Y"), ("Y", "Z"), ("Z", "X")]
            if a in indices and b in indices
        ]
        K = calibrate_intrinsics_from_vps(
            [vp_avg[label] for label in labels],
            ortho_pairs,
            assume_zero_skew=True,
            assume_square_pixels=True,
            fix_principal_point=(w_img / 2, h_img / 2),
        )
        fx, fy = float(K[0, 0]), float(K[1, 1])
        if not (np.isfinite(fx) and np.isfinite(fy)):
            return None
        return fx, fy
    except Exception:
        return None


def _transpose_checker_detection(corners, pattern, label):
    """Swap a detected grid so columns/rows match the assigned cube axes."""
    cols, rows = int(pattern[0]), int(pattern[1])
    arr = np.asarray(corners, dtype=np.float32).reshape(rows, cols, 1, 2)
    transposed = arr.transpose(1, 0, 2, 3).reshape(-1, 1, 2).copy()
    return transposed, (rows, cols), label


def _apply_cube_spatial_understanding(
    detections,
    image_size,
    preflight,
    warnings,
    *,
    stage: str,
    strict: bool = True,
):
    """Interpret three detected grids as the physical XY/XZ/YZ cube faces."""
    if not ENABLE_CUBE_SPATIAL_UNDERSTANDING:
        preflight.setdefault("cube_spatial_understanding", {})[stage] = {
            "success": False,
            "status": "disabled",
            "message": "CALIB_ENABLE_CUBE_SPATIAL_UNDERSTANDING is disabled.",
        }
        return detections
    if len(detections or []) < 3:
        preflight.setdefault("cube_spatial_understanding", {})[stage] = {
            "success": False,
            "status": "need_exactly_three_faces",
            "message": f"Only {len(detections or [])}/3 candidate faces are available.",
        }
        return detections

    try:
        from cube_spatial_understanding import (
            make_observation,
            understand_cube_faces,
        )
    except Exception as exc:
        warnings.append(f"Cube spatial understanding unavailable: {exc}")
        return detections

    base = list(detections[:3])
    observations = [
        make_observation(
            corners,
            pat,
            source_label=str(label),
            source_index=index,
        )
        for index, (corners, pat, label) in enumerate(base)
    ]
    result = understand_cube_faces(observations, image_size=image_size)
    preflight.setdefault("cube_spatial_understanding", {})[stage] = result.to_dict()
    if not result.success:
        reason = ", ".join(result.diagnostics.get("reject_reasons", []))
        if not reason:
            reason = result.message
        message = (
            "Not cube target: spatial understanding could not verify three "
            f"mutually adjacent checkerboard faces ({reason})."
        )
        if strict:
            raise RuntimeError(message)
        warnings.append(message)
        return detections

    by_index = {int(face.observation_index): face for face in result.faces}
    ordered = []
    for face in result.faces:
        idx = int(face.observation_index)
        corners, pat, _label = base[idx]
        label = str(face.assigned_label)
        if face.transpose_required:
            corners, pat, label = _transpose_checker_detection(corners, pat, label)
        else:
            corners = np.asarray(corners, dtype=np.float32).reshape(-1, 1, 2)
            pat = (int(pat[0]), int(pat[1]))
        ordered.append((corners, pat, label))

    ordered.extend(list(detections[3:]))
    ordered_desc = ", ".join(
        f"{face.assigned_label}<-#{int(face.observation_index)}"
        + ("T" if face.transpose_required else "")
        for face in result.faces
    )
    warnings.append(
        "Cube spatial understanding verified and ordered the three physical "
        f"faces ({ordered_desc})."
    )
    if set(by_index) != {0, 1, 2}:
        warnings.append(
            "Cube spatial understanding used non-contiguous source indices; "
            "detections were still ordered by the returned topology."
        )
    return ordered


def _subset_chessboard_corners(corners, pattern, target_pattern,
                               start_col: int, start_row: int):
    cols, rows = int(pattern[0]), int(pattern[1])
    target_cols, target_rows = int(target_pattern[0]), int(target_pattern[1])
    arr = np.asarray(corners, dtype=np.float32).reshape(rows, cols, 1, 2)
    cropped = arr[
        int(start_row):int(start_row) + target_rows,
        int(start_col):int(start_col) + target_cols,
    ]
    return cropped.reshape(-1, 1, 2).copy()


def _small_target_pattern_repair_options(corners, pattern, label):
    """Return conservative physical-grid repairs for small-target detections."""
    options = [(corners, pattern, label, None)]
    cols, rows = int(pattern[0]), int(pattern[1])
    if len(corners) != cols * rows:
        return options

    # In the 6-8% band OpenCV sometimes grows the physically small 6x6 face
    # to a neighbouring 7x6/8x6 local grid.  We only trim such over-wide
    # detections back to 6x6; we never synthesize missing corners.
    if rows == 6 and cols in (7, 8):
        for start_col in range(cols - 6 + 1):
            repaired = _subset_chessboard_corners(
                corners, (cols, rows), (6, 6), start_col, 0)
            options.append((
                repaired, (6, 6), label,
                f"{label}:{cols}x{rows}->6x6@col{start_col}",
            ))
    if cols == 6 and rows in (7, 8):
        for start_row in range(rows - 6 + 1):
            repaired = _subset_chessboard_corners(
                corners, (cols, rows), (6, 6), 0, start_row)
            options.append((
                repaired, (6, 6), label,
                f"{label}:{cols}x{rows}->6x6@row{start_row}",
            ))
    return options


def _try_small_target_pattern_repair(cube_first, image_shape, n_faces):
    """Trim over-detected small-target face grids when PnP geometry agrees."""
    if len(cube_first) < n_faces:
        return None, ""
    detections = list(cube_first[:n_faces])
    raw_patterns = tuple(tuple(int(v) for v in pat)
                         for _corners, pat, _label in detections)
    if _small_target_patterns_allowed(raw_patterns):
        return None, ""

    per_face_options = [
        _small_target_pattern_repair_options(corners, pat, label)
        for corners, pat, label in detections
    ]

    try:
        from face_detector import (
            _cube_detection_best_offset_pnp_rmse,
            _cube_detection_geometry_rmse,
            _normalize_face_axis_order,
            _total_corner_count,
        )
    except Exception:
        return None, ""

    best = None
    for combo in itertools.product(*per_face_options):
        repairs = [desc for _corners, _pat, _label, desc in combo if desc]
        if len(repairs) != 1:
            continue
        candidate = [
            (corners, pat, label)
            for corners, pat, label, _desc in combo
        ]
        candidate = _normalize_face_axis_order(candidate)[:n_faces]
        patterns = tuple(tuple(int(v) for v in pat)
                         for _corners, pat, _label in candidate)
        if not _small_target_patterns_allowed(patterns):
            continue
        corner_count = _total_corner_count(candidate)
        if corner_count < MIN_SMALL_TARGET_CORNERS:
            continue
        centered = _cube_detection_geometry_rmse(
            candidate, image_shape, n_faces=n_faces,
            allow_sparse=False, assume_normalized=True)
        offset_rmse, offset, offset_dist = _cube_detection_best_offset_pnp_rmse(
            candidate, image_shape, n_faces=n_faces, assume_normalized=True)
        if (
            not np.isfinite(centered)
            or centered > SMALL_TARGET_PATTERN_REPAIR_MAX_CENTERED_PNP_RMSE_PX
            or not np.isfinite(offset_rmse)
            or offset_rmse > SMALL_TARGET_PATTERN_REPAIR_MAX_OFFSET_PNP_RMSE_PX
        ):
            continue
        score = (
            float(offset_rmse)
            + 0.12 * float(centered)
            + 0.05 * float(offset_dist if np.isfinite(offset_dist) else 0.0)
            - 0.010 * float(corner_count)
        )
        if best is None or score < best[0]:
            best = (
                score, candidate, repairs[0], centered, offset_rmse, offset)

    if best is None:
        return None, ""

    _score, candidate, repair_desc, centered, offset_rmse, offset = best
    off_desc = ""
    if offset is not None:
        labels = ["XY", "XZ", "YZ"]
        off_desc = f", offset {labels[offset[0]]}=({offset[1]:.0f},{offset[2]:.0f})"
    reason = (
        f"Applied small-target physical pattern repair ({repair_desc}); "
        f"centered PnP {centered:.2f}px, offset PnP {offset_rmse:.2f}px"
        f"{off_desc}."
    )
    return candidate, reason
MIN_RELIABLE_FACE_INNER_DIM = 5
MIN_SPARSE_RECOVERY_FACE_INNER_DIM = 4
MAX_SPARSE_RECOVERY_FACES = 1
MAX_CONFIDENT_K1_ABS = 0.8
MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC = 0.25
MAX_CONFIDENT_INITIAL_PNP_RMSE_PX = 15.0
MAX_CONFIDENT_FIXED_FOCAL_RMSE_PX = 14.5
MAX_CONFIDENT_OFFSET_PNP_RMSE_PX = 14.0
MAX_CONFIDENT_OFFSET_K1_RMSE_PX = 10.25
MAX_CONFIDENT_OFFSET_ZERO_DIST_RMSE_PX = 9.35
MAX_CONFIDENT_OFFSET_K1_ABS = 0.35
MAX_CONFIDENT_OFFSET_AMBIGUITY_SCORE_GAP = 1.25
MAX_CONFIDENT_OFFSET_AMBIGUITY_RMSE_GAP = 1.25
MAX_CONFIDENT_OFFSET_AMBIGUITY_FOCAL_SPREAD_FRAC = 0.12
MAX_NEAR_SINGLE_FACE_OFFSET_DIST_SQUARES = 1.05
MAX_SINGLE_FACE_OFFSET_DIST_SQUARES = 1.60
MAX_MULTI_FACE_OFFSET_DIST_SQUARES = 1.60
MIN_MULTI_FACE_OFFSET_CHANGED_FACES = 2
MAX_CONFIDENT_MULTI_OFFSET_PNP_RMSE_PX = 12.0
MAX_STRONG_MULTI_OFFSET_RMSE_PX = 7.0
MAX_STRONG_MULTI_OFFSET_PNP_RMSE_PX = 14.0
MIN_STRONG_MULTI_OFFSET_SCORE_GAP = 0.50
MIN_STRONG_MULTI_OFFSET_RMSE_GAP_PX = 0.35
MAX_STRONG_MULTI_OFFSET_CHANGED_FACES = 2
MAX_WIDE_SINGLE_FACE_OFFSET_DIST_SQUARES = 3.0
MAX_CONFIDENT_WIDE_OFFSET_PNP_RMSE_PX = 10.6
MAX_CONFIDENT_WIDE_OFFSET_FIXED_FOCAL_RMSE_PX = 9.5
WIDE_OFFSET_FOCAL_SCAN_ANCHOR_DIAG_MULT = 0.55
WIDE_OFFSET_FOCAL_SCAN_STEP_PX = 80.0
WIDE_OFFSET_FOCAL_SCAN_PLATEAU_RMSE_GAP_PX = 1.25
MAX_WIDE_OFFSET_FOCAL_SCAN_OFFSETS = 24
MAX_WIDE_OFFSET_FAST_ANCHOR_RMSE_PX = 7.5
MAX_WIDE_OFFSET_FAST_ANCHOR_OFFSETS = 8
SINGLE_VIEW_OFFSET_SEARCH_PNP_TRIGGER_PX = 10.0
ENABLE_MULTI_FACE_OFFSET_FALLBACK = False
ENABLE_RAW_CANDIDATE_WIDE_OFFSET_RECOVERY = True
MAX_RAW_CANDIDATE_RECOVERY_COMBOS = 8
MIN_RAW_CANDIDATE_RECOVERY_CORNERS = 120
MAX_RAW_CANDIDATE_LINE_QUALITY_PX = 0.85
MAX_RAW_CANDIDATE_HOMOGRAPHY_RMSE_PX = 2.25
MAX_RAW_CANDIDATE_ROBUST_HOMOGRAPHY_RMSE_PX = 1.60
MIN_RAW_CANDIDATE_HOMOGRAPHY_INLIER_FRAC = 0.70
MAX_TOPOLOGY_VETTED_RAW_HOMOGRAPHY_RMSE_PX = 8.50
MAX_TOPOLOGY_VETTED_RAW_ROBUST_HOMOGRAPHY_RMSE_PX = 1.60
MIN_TOPOLOGY_VETTED_RAW_HOMOGRAPHY_INLIER_FRAC = 0.30
MAX_TOPOLOGY_VETTED_RAW_LINE_QUALITY_PX = 0.65
MAX_TOPOLOGY_VETTED_RAW_OFFSET_HINT_RMSE_PX = 12.50
MAX_TOPOLOGY_VETTED_RAW_CENTERED_PNP_RMSE_PX = 32.0
MAX_TOPOLOGY_VETTED_WIDE_OFFSET_PNP_RMSE_PX = 14.0
MAX_TOPOLOGY_VETTED_WIDE_OFFSET_RMSE_PX = MAX_CONFIDENT_RMSE_PX


def _range_boundary_message(cube_area_pct: float, tail: str) -> str:
    if DISABLE_AREA_RATIO_GATES:
        return (
            f"Quality boundary: cube image area is {cube_area_pct:.2f}% "
            "of the full image, but area-ratio gates are disabled. "
            f"{tail}"
        )
    return (
        f"Range boundary: cube image area is {cube_area_pct:.2f}% "
        f"of the full image. Normal automatic range requires "
        f"{NORMAL_RELIABLE_CUBE_AREA_PCT:.1f}%+ cube area. The direct-path "
        f"acceptance floor is {MIN_ACCEPTED_CUBE_AREA_PCT:.1f}%; images below "
        f"that floor may still be accepted from "
        f"{MIN_SMALL_TARGET_ATTEMPT_CUBE_AREA_PCT:.1f}% upward after strict "
        f"small-target recovery gates. {tail}"
    )


def _below_small_target_floor(cube_area_pct: Optional[float]) -> bool:
    if DISABLE_AREA_RATIO_GATES:
        return False
    return (
        cube_area_pct is not None
        and cube_area_pct < MIN_SMALL_TARGET_ATTEMPT_CUBE_AREA_PCT
    )


def _in_small_target_attempt_band(cube_area_pct: Optional[float]) -> bool:
    return (
        cube_area_pct is not None
        and MIN_SMALL_TARGET_ATTEMPT_CUBE_AREA_PCT <= cube_area_pct
        and cube_area_pct < NORMAL_RELIABLE_CUBE_AREA_PCT
    )


def _small_target_geometry_gate_active(
    cube_area_pct: Optional[float],
    *,
    preflight_requires_strict_gate: bool,
    manual_override: bool,
) -> bool:
    """Select scale-dependent geometry checks independently of corner source."""
    return (
        not manual_override
        and (
            preflight_requires_strict_gate
            or _in_small_target_attempt_band(cube_area_pct)
        )
    )


def _small_target_boundary_message(cube_area_pct: float, reason: str) -> str:
    return _range_boundary_message(
        cube_area_pct,
        "A small-target calibration attempt was allowed, but the "
        f"candidate did not pass the strict small-target gate: {reason} "
        "Keep this image as a distance/area boundary until the crop-upscale "
        "detector can produce stronger three-face evidence.",
    )


def _has_trihedral_cube_layout_near_components(gray: np.ndarray, n_faces: int = 3) -> bool:
    """Conservatively test whether a single detected checker belongs to a cube."""
    try:
        from face_detector import (
            _cluster_dark_components,
            _find_trihedral_edge_layout,
            _trihedral_face_regions,
        )

        clusters = _cluster_dark_components(gray, n_faces=n_faces, verbose=False)
        if not clusters:
            return False
        pts = np.vstack([
            np.asarray(cluster.get("poly"), dtype=np.float32).reshape(-1, 2)
            for cluster in clusters
            if cluster.get("poly") is not None
        ])
        if pts.size == 0:
            return False

        h, w = gray.shape[:2]
        span = max(float(np.ptp(pts[:, 0])), float(np.ptp(pts[:, 1])), 1.0)
        for pad_factor in (0.80, 1.20, 1.80, 2.50):
            pad = max(60, int(round(float(pad_factor) * span)))
            x1 = max(0, int(np.floor(float(np.min(pts[:, 0])) - pad)))
            y1 = max(0, int(np.floor(float(np.min(pts[:, 1])) - pad)))
            x2 = min(w, int(np.ceil(float(np.max(pts[:, 0])) + pad)))
            y2 = min(h, int(np.ceil(float(np.max(pts[:, 1])) + pad)))
            if x2 <= x1 + 40 or y2 <= y1 + 40:
                continue
            crop = gray[y1:y2, x1:x2]
            for scale in (1.0, 1.5, 2.0, 3.0):
                if scale > 1.01:
                    work = cv2.resize(
                        crop,
                        (
                            int(round(crop.shape[1] * scale)),
                            int(round(crop.shape[0] * scale)),
                        ),
                        interpolation=cv2.INTER_CUBIC,
                    )
                else:
                    work = crop
                layout = _find_trihedral_edge_layout(work, verbose=False)
                if layout is None:
                    continue
                regions = _trihedral_face_regions(work, layout)
                if len(regions) >= 3:
                    return True
    except Exception:
        return False
    return False


def _spatial_prefilter_not_cube_reason(
    gray: np.ndarray,
    cube_area_pct: Optional[float],
    *,
    n_faces: int,
    manual_override: bool,
    precomputed_corners: bool,
) -> Optional[str]:
    """Fast first-stage target screening from physical face components."""
    if not _env_bool("CALIB_ENABLE_SPATIAL_PREFILTER", False):
        return None
    if manual_override or precomputed_corners or int(n_faces) != 3:
        return None
    min_area = _env_float(
        "CALIB_SPATIAL_PREFILTER_MIN_AREA_PCT",
        MIN_SMALL_TARGET_ATTEMPT_CUBE_AREA_PCT,
    )
    if cube_area_pct is None or cube_area_pct < min_area:
        return None
    try:
        from face_detector import _cluster_dark_components

        components = _cluster_dark_components(
            gray, n_faces=int(n_faces), verbose=False)
    except Exception:
        return None
    component_count = len(components or [])
    if component_count >= int(n_faces):
        return None
    return (
        "Not cube target: spatial prefilter found only "
        f"{component_count}/{int(n_faces)} physical face components "
        f"at cube-area estimate {float(cube_area_pct):.2f}%. "
        "The calibration target must be a single cube/cuboid with three "
        "visible checkerboard-bearing faces; refusing planar or incomplete "
        "checkerboard fallback before parameter optimization."
    )


def _corner_line_quality(corners, pattern):
    try:
        _rl, _cl, rq, cq = lines_from_chessboard_corners(
            corners, pattern, use_ransac=True)
    except Exception:
        return float('inf')
    return float(max(rq, cq))


def _refined_quality_is_usable(before, after):
    if not np.isfinite(after):
        return False
    if not np.isfinite(before):
        return True
    return after <= max(1.5, before * 3.0)


def _quality_gated_corner_subpix(gray, corners, pattern, window, criteria):
    original = corners.astype(np.float32).copy()
    before = _corner_line_quality(original, pattern)
    before_topology = _corner_grid_topology_stats(original, pattern)
    refined = cv2.cornerSubPix(gray, original.copy(), window, (-1, -1), criteria)
    after = _corner_line_quality(refined, pattern)
    after_topology = _corner_grid_topology_stats(refined, pattern)
    topology_worsened = bool(
        after_topology["spacing_collapsed"]
        or after_topology["homography_rmse_px"] > max(
            2.0,
            before_topology["homography_rmse_px"] + 0.50,
            1.50 * before_topology["homography_rmse_px"],
        )
    )
    if not _refined_quality_is_usable(before, after) or topology_worsened:
        return original
    return refined


def _corner_grid_topology_stats(corners, pattern):
    """Measure whether row-major checker points still form one projective grid."""
    cols, rows = (int(pattern[0]), int(pattern[1]))
    points = np.asarray(corners, dtype=np.float32).reshape(-1, 2)
    if len(points) != cols * rows or len(points) < 4:
        return {
            "homography_rmse_px": float("inf"),
            "robust_homography_rmse_px": float("inf"),
            "robust_inlier_fraction": 0.0,
            "median_neighbor_spacing_px": 0.0,
            "minimum_pair_spacing_px": 0.0,
            "spacing_collapsed": True,
        }
    grid = np.asarray(
        [[float(col), float(row)] for row in range(rows) for col in range(cols)],
        dtype=np.float32,
    )

    def homography_error(H, mask=None):
        if H is None or not np.all(np.isfinite(H)):
            return float("inf")
        projected = cv2.perspectiveTransform(
            grid.reshape(-1, 1, 2), H,
        ).reshape(-1, 2)
        errors = np.linalg.norm(projected - points, axis=1)
        if mask is not None:
            selected = np.asarray(mask).reshape(-1).astype(bool)
            errors = errors[selected]
        if not len(errors):
            return float("inf")
        return float(np.sqrt(np.mean(errors * errors)))

    try:
        H_all, _ = cv2.findHomography(grid, points, method=0)
        H_robust, inlier_mask = cv2.findHomography(
            grid, points, method=cv2.RANSAC, ransacReprojThreshold=2.5,
        )
    except cv2.error:
        H_all, H_robust, inlier_mask = None, None, None
    inlier_fraction = (
        float(np.mean(np.asarray(inlier_mask).reshape(-1).astype(bool)))
        if inlier_mask is not None else 0.0
    )
    shaped = points.reshape(rows, cols, 2)
    neighbor_distances = np.concatenate([
        np.linalg.norm(np.diff(shaped, axis=1), axis=2).reshape(-1),
        np.linalg.norm(np.diff(shaped, axis=0), axis=2).reshape(-1),
    ])
    median_neighbor = float(np.median(neighbor_distances))
    pair_distances = np.linalg.norm(
        points[:, None, :] - points[None, :, :], axis=2,
    )
    np.fill_diagonal(pair_distances, np.inf)
    minimum_pair = float(np.min(pair_distances))
    spacing_collapsed = bool(
        not np.isfinite(minimum_pair)
        or minimum_pair < max(0.75, 0.20 * median_neighbor)
    )
    return {
        "homography_rmse_px": homography_error(H_all),
        "robust_homography_rmse_px": homography_error(
            H_robust, inlier_mask,
        ),
        "robust_inlier_fraction": inlier_fraction,
        "median_neighbor_spacing_px": median_neighbor,
        "minimum_pair_spacing_px": minimum_pair,
        "spacing_collapsed": spacing_collapsed,
    }


def _homography_regularized_corner_candidate(gray, corners, pattern):
    """Recover a collapsed checker lattice from its image-supported RANSAC fit."""
    source = np.asarray(corners, dtype=np.float32).reshape(-1, 1, 2)
    base = _corner_grid_topology_stats(source, pattern)
    if (
        base["homography_rmse_px"] <= 2.0
        and not base["spacing_collapsed"]
    ):
        return None, None
    if (
        base["robust_inlier_fraction"] < 0.35
        or base["robust_homography_rmse_px"] > 1.5
    ):
        return None, None

    cols, rows = (int(pattern[0]), int(pattern[1]))
    grid = np.asarray(
        [[float(col), float(row)] for row in range(rows) for col in range(cols)],
        dtype=np.float32,
    )
    try:
        H, inlier_mask = cv2.findHomography(
            grid, source.reshape(-1, 2), method=cv2.RANSAC,
            ransacReprojThreshold=2.5,
        )
    except cv2.error:
        H, inlier_mask = None, None
    if H is None or inlier_mask is None or not np.all(np.isfinite(H)):
        return None, None
    projected = cv2.perspectiveTransform(
        grid.reshape(-1, 1, 2), H,
    ).astype(np.float32)

    source_points = source.reshape(-1, 2)
    projected_points = projected.reshape(-1, 2)
    source_center = source_points.mean(axis=0)
    projected_center = projected_points.mean(axis=0)
    source_span = np.ptp(source_points, axis=0)
    projected_span = np.ptp(projected_points, axis=0)
    span_scale = max(float(np.max(source_span)), 1.0)
    span_ratio = projected_span / np.maximum(source_span, 1.0)
    if (
        float(np.linalg.norm(projected_center - source_center)) > 0.08 * span_scale
        or np.any(span_ratio < 0.75)
        or np.any(span_ratio > 1.25)
    ):
        return None, None

    criteria = (
        cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 50, 1e-4,
    )
    try:
        locally_refined = cv2.cornerSubPix(
            gray, projected.copy(), (3, 3), (-1, -1), criteria,
        )
    except cv2.error:
        locally_refined = projected.copy()
    shifts = np.linalg.norm(
        locally_refined.reshape(-1, 2) - projected_points, axis=1,
    )
    supported = np.isfinite(shifts) & (shifts <= 3.0)
    if float(np.mean(supported)) < 0.90:
        return None, None
    candidate = projected.copy()
    candidate[supported] = locally_refined[supported]
    recovered = _corner_grid_topology_stats(candidate, pattern)
    required_rmse = min(
        1.75, max(0.75, 0.55 * base["homography_rmse_px"]),
    )
    if (
        recovered["spacing_collapsed"]
        or recovered["homography_rmse_px"] > required_rmse
    ):
        return None, None
    diagnostics = {
        "source": base,
        "recovered": recovered,
        "locally_supported_fraction": float(np.mean(supported)),
        "local_shift_median_px": float(np.median(shifts[supported])),
        "local_shift_p90_px": float(np.percentile(shifts[supported], 90)),
    }
    return candidate.astype(np.float32), diagnostics


def _repair_collapsed_checker_points(gray, corners, pattern):
    """Repair only duplicate lattice indices while preserving all other points."""
    source = np.asarray(corners, dtype=np.float32).reshape(-1, 1, 2)
    before = _corner_grid_topology_stats(source, pattern)
    if not before["spacing_collapsed"]:
        return None, None
    if (
        before["robust_inlier_fraction"] < 0.35
        or before["robust_homography_rmse_px"] > 1.5
    ):
        return None, None

    cols, rows = int(pattern[0]), int(pattern[1])
    grid = np.asarray([
        [float(col), float(row)]
        for row in range(rows) for col in range(cols)
    ], dtype=np.float32)
    points = source.reshape(-1, 2)
    try:
        H, _mask = cv2.findHomography(
            grid, points, method=cv2.RANSAC, ransacReprojThreshold=2.5,
        )
    except cv2.error:
        H = None
    if H is None or not np.all(np.isfinite(H)):
        return None, None
    projected = cv2.perspectiveTransform(
        grid.reshape(-1, 1, 2), H,
    ).astype(np.float32)
    projected_points = projected.reshape(-1, 2)
    projection_errors = np.linalg.norm(projected_points - points, axis=1)

    shaped = points.reshape(rows, cols, 2)
    neighbor_spacing = np.concatenate([
        np.linalg.norm(np.diff(shaped, axis=1), axis=2).reshape(-1),
        np.linalg.norm(np.diff(shaped, axis=0), axis=2).reshape(-1),
    ])
    duplicate_threshold = max(0.75, 0.20 * float(np.median(neighbor_spacing)))
    pair_distances = np.linalg.norm(
        points[:, None, :] - points[None, :, :], axis=2,
    )
    np.fill_diagonal(pair_distances, np.inf)
    duplicate_pairs = np.argwhere(pair_distances < duplicate_threshold)
    if not len(duplicate_pairs):
        return None, None

    adjacency = {index: set() for index in range(len(points))}
    for first, second in duplicate_pairs:
        adjacency[int(first)].add(int(second))
        adjacency[int(second)].add(int(first))
    replacement_indices = []
    visited = set()
    for start in range(len(points)):
        if start in visited or not adjacency[start]:
            continue
        stack = [start]
        component = []
        while stack:
            current = stack.pop()
            if current in visited:
                continue
            visited.add(current)
            component.append(current)
            stack.extend(adjacency[current] - visited)
        keeper = min(component, key=lambda index: float(projection_errors[index]))
        replacement_indices.extend(
            index for index in component if index != keeper
        )
    replacement_indices = sorted(set(replacement_indices))
    if not replacement_indices:
        return None, None

    candidate = source.copy()
    predicted = projected[replacement_indices].copy()
    criteria = (
        cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 50, 1e-4,
    )
    try:
        refined = cv2.cornerSubPix(
            gray, predicted.copy(), (3, 3), (-1, -1), criteria,
        )
    except cv2.error:
        refined = predicted
    shifts = np.linalg.norm(
        refined.reshape(-1, 2) - predicted.reshape(-1, 2), axis=1,
    )
    for local_index, point_index in enumerate(replacement_indices):
        candidate[point_index] = (
            refined[local_index]
            if np.isfinite(shifts[local_index]) and shifts[local_index] <= 3.0
            else predicted[local_index]
        )
    after = _corner_grid_topology_stats(candidate, pattern)
    if after["spacing_collapsed"]:
        return None, None
    return candidate.astype(np.float32), {
        "source": before,
        "repaired": after,
        "replaced_indices": [int(index) for index in replacement_indices],
        "predicted_shift_px": [
            float(projection_errors[index]) for index in replacement_indices
        ],
        "local_refinement_shift_px": [float(value) for value in shifts],
    }


def _projected_point_rmse(object_points, image_points, K, dist, rvec, tvec):
    proj, _ = cv2.projectPoints(
        object_points.reshape(-1, 1, 3).astype(np.float64),
        rvec, tvec, K, dist,
    )
    diff = proj.reshape(-1, 2) - image_points.reshape(-1, 2)
    return float(np.sqrt(np.mean(np.sum(diff * diff, axis=1))))


def _single_view_k1_fallback(
    object_points,
    image_points,
    image_size,
    K_seed,
    focal_lo,
    focal_hi,
    rmse_limit,
):
    """Conservative non-planar 3D fallback for an already-detected cube."""
    w_img, h_img = image_size
    if object_points.shape[0] < 30:
        return None

    f_seed = float(np.nanmean([K_seed[0, 0], K_seed[1, 1]]))
    if not np.isfinite(f_seed) or f_seed <= 0:
        f_seed = 0.5 * (focal_lo + focal_hi)
    f_seed = float(np.clip(f_seed, focal_lo, focal_hi))

    diag = float(np.hypot(w_img, h_img))
    focal_seeds = [
        f_seed,
        f_seed * 0.75,
        f_seed * 1.25,
        0.35 * diag,
        0.45 * diag,
        0.55 * diag,
        0.70 * diag,
        0.90 * diag,
    ]
    unique_seeds = []
    for seed in focal_seeds:
        seed = float(np.clip(seed, focal_lo, focal_hi))
        if all(abs(seed - old) > 1.0 for old in unique_seeds):
            unique_seeds.append(seed)

    flags = (
        cv2.CALIB_USE_INTRINSIC_GUESS
        | cv2.CALIB_FIX_PRINCIPAL_POINT
        | cv2.CALIB_FIX_ASPECT_RATIO
        | cv2.CALIB_ZERO_TANGENT_DIST
        | cv2.CALIB_FIX_K2
        | cv2.CALIB_FIX_K3
        | cv2.CALIB_FIX_K4
        | cv2.CALIB_FIX_K5
        | cv2.CALIB_FIX_K6
    )

    best = None
    obj = object_points.reshape(-1, 3).astype(np.float32)
    img = image_points.reshape(-1, 2).astype(np.float32)
    for seed in unique_seeds:
        K0 = np.array([
            [seed, 0.0, w_img / 2.0],
            [0.0, seed, h_img / 2.0],
            [0.0, 0.0, 1.0],
        ], dtype=np.float64)
        dist0 = np.zeros(8, dtype=np.float64)
        try:
            _ret, K, dist, rvecs, tvecs = cv2.calibrateCamera(
                [obj],
                [img],
                (int(w_img), int(h_img)),
                K0,
                dist0,
                flags=flags,
            )
        except cv2.error:
            continue

        if not rvecs or not tvecs:
            continue
        dist = dist.reshape(-1)
        dist5 = np.array([
            dist[0] if len(dist) > 0 else 0.0,
            dist[1] if len(dist) > 1 else 0.0,
            dist[2] if len(dist) > 2 else 0.0,
            dist[3] if len(dist) > 3 else 0.0,
            dist[4] if len(dist) > 4 else 0.0,
        ], dtype=np.float64)
        rmse = _projected_point_rmse(
            object_points, image_points, K, dist5, rvecs[0], tvecs[0])

        fx, fy = float(K[0, 0]), float(K[1, 1])
        cx, cy = float(K[0, 2]), float(K[1, 2])
        if not np.all(np.isfinite(K)) or not np.all(np.isfinite(dist5)):
            continue
        if not (focal_lo <= fx <= focal_hi and focal_lo <= fy <= focal_hi):
            continue
        if abs(fx - fy) / max(fx, fy, 1e-6) > 0.02:
            continue
        if abs(cx - w_img / 2.0) > 1e-3 or abs(cy - h_img / 2.0) > 1e-3:
            continue
        if abs(float(dist5[0])) > MAX_CONFIDENT_K1_ABS:
            continue
        if (not np.isfinite(rmse)) or rmse > rmse_limit:
            continue
        score = rmse + 0.25 * abs(float(dist5[0]))
        if best is None or score < best[0]:
            R, _ = cv2.Rodrigues(rvecs[0])
            best = (score, K.copy(), dist5.copy(), R, tvecs[0].reshape(3).copy(), rmse)

    if best is None:
        return None
    _score, K, dist5, R, t, rmse = best
    return K, dist5, R, t, rmse


def _single_view_zero_dist_fallback(
    object_points,
    image_points,
    image_size,
    K_seed,
    focal_lo,
    focal_hi,
    rmse_limit,
):
    """Single-frame fallback when free k1 explains geometry with false distortion."""
    w_img, h_img = image_size
    if object_points.shape[0] < 30:
        return None

    f_seed = float(np.nanmean([K_seed[0, 0], K_seed[1, 1]]))
    if not np.isfinite(f_seed) or f_seed <= 0:
        f_seed = 0.5 * (focal_lo + focal_hi)
    diag = float(np.hypot(w_img, h_img))
    seeds = [
        f_seed, f_seed * 0.75, f_seed * 1.25,
        0.35 * diag, 0.45 * diag, 0.55 * diag, 0.70 * diag, 0.90 * diag,
    ]
    unique_seeds = []
    for seed in seeds:
        seed = float(np.clip(seed, focal_lo, focal_hi))
        if all(abs(seed - old) > 1.0 for old in unique_seeds):
            unique_seeds.append(seed)

    flags = (
        cv2.CALIB_USE_INTRINSIC_GUESS
        | cv2.CALIB_FIX_PRINCIPAL_POINT
        | cv2.CALIB_FIX_ASPECT_RATIO
        | cv2.CALIB_ZERO_TANGENT_DIST
        | cv2.CALIB_FIX_K1
        | cv2.CALIB_FIX_K2
        | cv2.CALIB_FIX_K3
        | cv2.CALIB_FIX_K4
        | cv2.CALIB_FIX_K5
        | cv2.CALIB_FIX_K6
    )

    best = None
    obj = object_points.reshape(-1, 3).astype(np.float32)
    img = image_points.reshape(-1, 2).astype(np.float32)
    dist5 = np.zeros(5, dtype=np.float64)
    for seed in unique_seeds:
        K0 = np.array([
            [seed, 0.0, w_img / 2.0],
            [0.0, seed, h_img / 2.0],
            [0.0, 0.0, 1.0],
        ], dtype=np.float64)
        dist0 = np.zeros(8, dtype=np.float64)
        try:
            _ret, K, _dist, rvecs, tvecs = cv2.calibrateCamera(
                [obj], [img], (int(w_img), int(h_img)), K0, dist0, flags=flags)
        except cv2.error:
            continue
        if not rvecs or not tvecs:
            continue
        rmse = _projected_point_rmse(
            object_points, image_points, K, dist5, rvecs[0], tvecs[0])
        fx, fy = float(K[0, 0]), float(K[1, 1])
        cx, cy = float(K[0, 2]), float(K[1, 2])
        if not np.all(np.isfinite(K)) or not np.isfinite(rmse):
            continue
        if not (focal_lo <= fx <= focal_hi and focal_lo <= fy <= focal_hi):
            continue
        if abs(fx - fy) / max(fx, fy, 1e-6) > 0.02:
            continue
        if abs(cx - w_img / 2.0) > 1e-3 or abs(cy - h_img / 2.0) > 1e-3:
            continue
        if rmse > rmse_limit:
            continue
        if best is None or rmse < best[0]:
            R, _ = cv2.Rodrigues(rvecs[0])
            best = (rmse, K.copy(), R, tvecs[0].reshape(3).copy())

    if best is None:
        return None
    rmse, K, R, t = best
    return K, dist5.copy(), R, t, rmse


def _standard_face_axes():
    ex = np.array([1.0, 0.0, 0.0])
    ey = np.array([0.0, 1.0, 0.0])
    ez = np.array([0.0, 0.0, 1.0])
    return [(ex, ey), (ex, ez), (ey, ez)]


def _offset_solution_is_ambiguous(best, candidates) -> bool:
    if best is None or len(candidates) < 2:
        return False
    best_score = float(best[0])
    best_rmse = float(best[5])
    close_focals = []
    for cand in candidates:
        score = float(cand[0])
        rmse = float(cand[5])
        if (
            score <= best_score + MAX_CONFIDENT_OFFSET_AMBIGUITY_SCORE_GAP
            or rmse <= best_rmse + MAX_CONFIDENT_OFFSET_AMBIGUITY_RMSE_GAP
        ):
            fx = float(cand[1][0, 0])
            if np.isfinite(fx) and fx > 0:
                close_focals.append(fx)
    if len(close_focals) < 2:
        return False
    median_fx = float(np.median(close_focals))
    if not np.isfinite(median_fx) or median_fx <= 0:
        return True
    spread = (max(close_focals) - min(close_focals)) / median_fx
    return spread > MAX_CONFIDENT_OFFSET_AMBIGUITY_FOCAL_SPREAD_FRAC


def _center_offsets_in_squares(patterns):
    max_outer_squares = max(max(c + 1, r + 1) for c, r in patterns)
    offsets = []
    for c, r in patterns:
        offsets.append((
            0.5 * (max_outer_squares - (c + 1)) + 1.0,
            0.5 * (max_outer_squares - (r + 1)) + 1.0,
        ))
    return max_outer_squares, offsets


def _faces_from_square_offsets(patterns, square_size, offsets):
    axes = _standard_face_axes()
    faces = []
    for i, (pattern, (ox, oy)) in enumerate(zip(patterns, offsets)):
        axis_x, axis_y = axes[i]
        faces.append(FaceDefinition(
            pattern_size=pattern,
            square_size=square_size,
            axis_x=axis_x,
            axis_y=axis_y,
            origin_3d=square_size * (ox * axis_x + oy * axis_y),
        ))
    return faces


def _orient_offset_faces_to_pose(
    image_points_by_face,
    faces,
    K,
    dist,
    R,
    t,
):
    """Make per-face grid directions consistent with an accepted offset pose."""
    all_image = np.vstack([
        np.asarray(points, dtype=np.float64).reshape(-1, 2)
        for points in image_points_by_face
    ])
    rvec, _ = cv2.Rodrigues(np.asarray(R, dtype=np.float64).reshape(3, 3))
    best = None
    for flips in itertools.product(
        ((False, False), (True, False), (False, True), (True, True)),
        repeat=len(faces),
    ):
        objects = [
            object_points_for_face(face, flip_x, flip_y).reshape(-1, 3)
            for face, (flip_x, flip_y) in zip(faces, flips)
        ]
        all_object = np.vstack(objects).astype(np.float64)
        rmse = _projected_point_rmse(
            all_object,
            all_image,
            np.asarray(K, dtype=np.float64),
            np.asarray(dist, dtype=np.float64).reshape(-1),
            rvec,
            np.asarray(t, dtype=np.float64).reshape(3, 1),
        )
        if best is None or rmse < best[0]:
            best = (rmse, flips, objects)
    if best is None:
        raise ValueError("No face orientation matches the accepted offset pose")
    rmse, flips, objects = best
    detected = [
        DetectedFace(
            image_points=np.asarray(points, dtype=np.float32).reshape(-1, 1, 2),
            object_points=np.asarray(obj, dtype=np.float32).reshape(-1, 1, 3),
            valid=True,
        )
        for points, obj in zip(image_points_by_face, objects)
    ]
    return detected, [
        {"flip_x": bool(fx), "flip_y": bool(fy)} for fx, fy in flips
    ], float(rmse)


def _single_view_offset_fallback(
    image_points_by_face,
    patterns,
    image_size,
    square_size,
    K_seed,
    focal_lo,
    focal_hi,
    rmse_limit,
    pnp_limit,
):
    """Infer an integer in-face grid offset from one frame, then calibrate.

    This is only used after the centered-board model fails.  Offsets are
    enumerated in checkerboard-square units, so the checker square edge remains
    the only physical scale input.
    """
    if len(image_points_by_face) != 3 or len(patterns) != 3:
        return None
    max_outer_squares, base_offsets = _center_offsets_in_squares(patterns)
    def nearby_integer_offsets(center, low, high):
        vals = {int(np.floor(center)), int(np.ceil(center)), int(round(center))}
        return sorted(v for v in vals if low <= v <= high)

    offset_candidates = []
    for vary_face, (cols, rows) in enumerate(patterns):
        center_x, center_y = base_offsets[vary_face]
        x_choices = range(1, int(max_outer_squares - cols) + 1)
        y_choices = range(1, int(max_outer_squares - rows) + 1)
        for ox in x_choices:
            for oy in y_choices:
                offset_dist = float(np.hypot(
                    float(ox) - float(center_x),
                    float(oy) - float(center_y),
                ))
                if offset_dist > MAX_SINGLE_FACE_OFFSET_DIST_SQUARES:
                    continue
                if (
                    abs(float(ox) - float(center_x)) < 1e-6
                    and abs(float(oy) - float(center_y)) < 1e-6
                ):
                    continue
                offset_candidates.append((
                    vary_face, float(ox), float(oy), offset_dist))
    if not offset_candidates:
        return None

    best_near = None
    best_wide = None
    near_solutions = []
    wide_solutions = []
    focal_ref = float(np.nanmean([K_seed[0, 0], K_seed[1, 1]]))
    if not np.isfinite(focal_ref) or focal_ref <= 0:
        focal_ref = None
    all_img = np.vstack([
        pts.reshape(-1, 2) for pts in image_points_by_face
    ]).astype(np.float32)

    for vary_face, ox, oy, offset_dist in offset_candidates:
            offsets = list(base_offsets)
            offsets[vary_face] = (ox, oy)
            faces = _faces_from_square_offsets(patterns, square_size, offsets)
            detected = []
            for pts, face in zip(image_points_by_face, faces):
                detected.append(DetectedFace(
                    image_points=pts.astype(np.float32),
                    object_points=object_points_for_face(face),
                    valid=True,
                ))
            orientations = apply_best_face_orientations(
                detected, faces, [0, 1, 2], K_seed, None)
            if not orientations:
                continue
            pnp_rmse = float(orientations[0]["rmse"])
            if (
                not np.isfinite(pnp_rmse)
                or pnp_rmse > min(pnp_limit, MAX_CONFIDENT_OFFSET_PNP_RMSE_PX)
            ):
                continue

            all_obj = np.vstack([
                detected[i].object_points for i in range(3)
            ]).reshape(-1, 3).astype(np.float32)
            k1_candidate = _single_view_k1_fallback(
                all_obj, all_img, image_size, K_seed,
                focal_lo, focal_hi, rmse_limit,
            )
            zero_candidate = _single_view_zero_dist_fallback(
                all_obj, all_img, image_size, K_seed,
                focal_lo, focal_hi, rmse_limit,
            )
            for model_name, candidate in (
                ("single-view-offset-k1", k1_candidate),
                ("single-view-offset-zero-dist", zero_candidate),
            ):
                if candidate is None:
                    continue
                K, dist, R, t, rmse = candidate
                offset_rmse_limit = (
                    MAX_CONFIDENT_OFFSET_ZERO_DIST_RMSE_PX
                    if model_name == "single-view-offset-zero-dist"
                    else MAX_CONFIDENT_OFFSET_K1_RMSE_PX
                )
                if not np.isfinite(rmse) or rmse > offset_rmse_limit:
                    continue
                k1 = float(dist[0])
                if abs(k1) > MAX_CONFIDENT_OFFSET_K1_ABS:
                    continue
                focal_penalty = 0.0
                if focal_ref is not None:
                    ratio = float(K[0, 0]) / focal_ref
                    if ratio < 0.80 or ratio > 1.20:
                        continue
                    focal_penalty = abs(np.log(ratio))
                score = float(
                    rmse
                    + 0.10 * pnp_rmse
                    + 1.50 * abs(k1)
                    + 1.50 * focal_penalty
                )
                candidate_best = (
                        score, K, dist, R, t, float(rmse), model_name,
                        (int(vary_face), ox, oy), pnp_rmse,
                    )
                if offset_dist <= MAX_NEAR_SINGLE_FACE_OFFSET_DIST_SQUARES:
                    near_solutions.append(candidate_best)
                    if best_near is None or score < best_near[0]:
                        best_near = candidate_best
                else:
                    wide_solutions.append(candidate_best)
                    if best_wide is None or score < best_wide[0]:
                        best_wide = candidate_best

    best = best_near if best_near is not None else best_wide
    if best is None:
        return None
    solution_pool = near_solutions if best_near is not None else wide_solutions
    if _offset_solution_is_ambiguous(best, solution_pool):
        return None
    _score, K, dist, R, t, rmse, model_name, offset, pnp_rmse = best
    return K, dist, R, t, rmse, model_name, offset, pnp_rmse


def _single_view_wide_offset_fixed_focal_fallback(
    image_points_by_face,
    patterns,
    image_size,
    square_size,
    K_seed,
    *,
    pnp_rmse_limit=None,
    rmse_limit=None,
):
    """Wider one-face offset recovery with a fixed focal length.

    This is a guarded recovery branch for topology-clean single-frame cases
    where the centered cube is plausible but the useful in-face board offset is
    outside the product near-offset radius.  The checker square remains the
    only metric scale; the focal value comes from the supplied seed matrix.
    """
    if len(image_points_by_face) != 3 or len(patterns) != 3:
        return None
    focal_seed = float(np.nanmean([K_seed[0, 0], K_seed[1, 1]]))
    if not np.isfinite(focal_seed) or focal_seed <= 0:
        return None
    if pnp_rmse_limit is None:
        pnp_rmse_limit = MAX_CONFIDENT_WIDE_OFFSET_PNP_RMSE_PX
    if rmse_limit is None:
        rmse_limit = MAX_CONFIDENT_WIDE_OFFSET_FIXED_FOCAL_RMSE_PX

    max_outer_squares, base_offsets = _center_offsets_in_squares(patterns)
    offset_candidates = []
    for vary_face, (cols, rows) in enumerate(patterns):
        center_x, center_y = base_offsets[vary_face]
        x_choices = range(1, int(max_outer_squares - cols) + 1)
        y_choices = range(1, int(max_outer_squares - rows) + 1)
        for ox in x_choices:
            for oy in y_choices:
                offset_dist = float(np.hypot(
                    float(ox) - float(center_x),
                    float(oy) - float(center_y),
                ))
                if (
                    offset_dist <= MAX_SINGLE_FACE_OFFSET_DIST_SQUARES
                    or offset_dist > MAX_WIDE_SINGLE_FACE_OFFSET_DIST_SQUARES
                ):
                    continue
                offset_candidates.append((
                    vary_face, float(ox), float(oy), offset_dist))
    if not offset_candidates:
        return None

    accepted_solutions = []
    best = None
    for vary_face, ox, oy, offset_dist in offset_candidates:
        offsets = list(base_offsets)
        offsets[vary_face] = (ox, oy)
        faces = _faces_from_square_offsets(patterns, square_size, offsets)
        detected = []
        for pts, face in zip(image_points_by_face, faces):
            detected.append(DetectedFace(
                image_points=pts.astype(np.float32),
                object_points=object_points_for_face(face),
                valid=True,
            ))
        orientations = apply_best_face_orientations(
            detected, faces, [0, 1, 2], K_seed, None)
        if not orientations:
            continue
        pnp_rmse = float(orientations[0]["rmse"])
        if (
            not np.isfinite(pnp_rmse)
            or pnp_rmse > pnp_rmse_limit
        ):
            continue

        all_obj = np.vstack([
            df.object_points for df in detected
        ]).reshape(-1, 3).astype(np.float32)
        all_img = np.vstack([
            df.image_points for df in detected
        ]).reshape(-1, 2).astype(np.float32)
        candidates = []
        fixed_k1 = _fixed_focal_k1_pose_fallback(
            all_obj,
            all_img,
            image_size,
            focal_seed,
            k1_seed=0.0,
            k1_prior=None,
            rmse_limit=rmse_limit,
        )
        fixed_zero = _fixed_focal_k1_pose_fallback(
            all_obj,
            all_img,
            image_size,
            focal_seed,
            k1_seed=0.0,
            k1_prior=0.0,
            rmse_limit=rmse_limit,
        )
        if fixed_k1 is not None:
            candidates.append(("single-view-wide-offset-fixed-focal-k1", fixed_k1))
        if fixed_zero is not None:
            candidates.append(("single-view-wide-offset-fixed-focal-zero-dist", fixed_zero))
        for model_name, candidate in candidates:
            K, dist, R, t, rmse = candidate
            k1 = float(dist[0])
            if (
                not np.isfinite(rmse)
                or rmse > rmse_limit
                or abs(k1) > MAX_CONFIDENT_OFFSET_K1_ABS
            ):
                continue
            score = float(
                rmse
                + 0.12 * pnp_rmse
                + 1.50 * abs(k1)
                + 0.08 * offset_dist
            )
            candidate_best = (
                score, K, dist, R, t, float(rmse), model_name,
                (int(vary_face), ox, oy), pnp_rmse,
            )
            accepted_solutions.append(candidate_best)
            if best is None or score < best[0]:
                best = candidate_best

    if best is None:
        return None
    if _offset_solution_is_ambiguous(best, accepted_solutions):
        return None
    _score, K, dist, R, t, rmse, model_name, offset, pnp_rmse = best
    return K, dist, R, t, rmse, model_name, offset, pnp_rmse


def _single_view_wide_offset_focal_scan_fallback(
    image_points_by_face,
    patterns,
    image_size,
    square_size,
    K_seed,
    focal_lo,
    focal_hi,
    *,
    pnp_rmse_limit=None,
    rmse_limit=None,
):
    """Wide one-face offset recovery with a bounded fixed-focal scan.

    This branch is for single-frame ambiguity cases where the VP focal seed is
    unreliable or the centered local board can be explained by a wrong focal.
    It keeps principal point centered, fixes distortion to zero, and chooses a
    focal value from the low-RMSE plateau closest to a mid-envelope focal
    anchor instead of chasing the absolute minimum RMSE at a focal boundary.
    """
    if len(image_points_by_face) != 3 or len(patterns) != 3:
        return None
    if focal_lo is None or focal_hi is None:
        return None
    if (
        not np.isfinite(focal_lo)
        or not np.isfinite(focal_hi)
        or focal_hi <= focal_lo
    ):
        return None
    if pnp_rmse_limit is None:
        pnp_rmse_limit = MAX_CONFIDENT_WIDE_OFFSET_PNP_RMSE_PX
    if rmse_limit is None:
        rmse_limit = MAX_CONFIDENT_WIDE_OFFSET_FIXED_FOCAL_RMSE_PX

    w_img, h_img = image_size
    diag = float(np.hypot(w_img, h_img))
    focal_anchor = float(np.clip(
        WIDE_OFFSET_FOCAL_SCAN_ANCHOR_DIAG_MULT * diag,
        focal_lo,
        focal_hi,
    ))
    focal_seed = float(np.nanmean([K_seed[0, 0], K_seed[1, 1]]))
    if not np.isfinite(focal_seed) or focal_seed <= 0:
        focal_seed = focal_anchor
    orientation_focal = focal_anchor
    K_orientation = np.array([
        [orientation_focal, 0.0, w_img / 2.0],
        [0.0, orientation_focal, h_img / 2.0],
        [0.0, 0.0, 1.0],
    ], dtype=np.float64)

    max_outer_squares, base_offsets = _center_offsets_in_squares(patterns)
    offset_candidates = []
    for vary_face, (cols, rows) in enumerate(patterns):
        center_x, center_y = base_offsets[vary_face]
        x_choices = range(1, int(max_outer_squares - cols) + 1)
        y_choices = range(1, int(max_outer_squares - rows) + 1)
        for ox in x_choices:
            for oy in y_choices:
                offset_dist = float(np.hypot(
                    float(ox) - float(center_x),
                    float(oy) - float(center_y),
                ))
                if (
                    offset_dist <= 1e-6
                    or offset_dist > MAX_WIDE_SINGLE_FACE_OFFSET_DIST_SQUARES
                ):
                    continue
                offsets = list(base_offsets)
                offsets[vary_face] = (float(ox), float(oy))
                faces = _faces_from_square_offsets(patterns, square_size, offsets)
                detected = []
                for pts, face in zip(image_points_by_face, faces):
                    detected.append(DetectedFace(
                        image_points=pts.astype(np.float32),
                        object_points=object_points_for_face(face),
                        valid=True,
                    ))
                orientations = apply_best_face_orientations(
                    detected, faces, [0, 1, 2], K_orientation, None)
                if not orientations:
                    continue
                pnp_rmse = float(orientations[0]["rmse"])
                if (
                    not np.isfinite(pnp_rmse)
                    or pnp_rmse > pnp_rmse_limit
                ):
                    continue
                all_obj = np.vstack([
                    df.object_points for df in detected
                ]).reshape(-1, 3).astype(np.float32)
                all_img = np.vstack([
                    df.image_points for df in detected
                ]).reshape(-1, 2).astype(np.float32)
                offset_score = float(
                    pnp_rmse + 0.08 * offset_dist + 0.35)
                offset_candidates.append((
                    offset_score,
                    pnp_rmse,
                    (int(vary_face), float(ox), float(oy)),
                    offset_dist,
                    all_obj,
                    all_img,
                ))

    if not offset_candidates:
        return None
    offset_candidates.sort(key=lambda item: item[0])
    offset_candidates = offset_candidates[:MAX_WIDE_OFFSET_FOCAL_SCAN_OFFSETS]

    fast_anchor_rows = []
    for _offset_score, pnp_rmse, offset, offset_dist, all_obj, all_img in (
        offset_candidates[:MAX_WIDE_OFFSET_FAST_ANCHOR_OFFSETS]
    ):
        for model_name, k1_prior in (
            ("single-view-wide-offset-focal-scan-zero-dist", 0.0),
            ("single-view-wide-offset-focal-scan-k1", None),
        ):
            candidate = _fixed_focal_k1_pose_fallback(
                all_obj,
                all_img,
                image_size,
                focal_anchor,
                k1_seed=0.0,
                k1_prior=k1_prior,
                rmse_limit=rmse_limit,
            )
            if candidate is None:
                continue
            K, dist, R, t, rmse = candidate
            k1 = float(dist[0])
            if (
                not np.isfinite(rmse)
                or rmse > rmse_limit
                or rmse > MAX_WIDE_OFFSET_FAST_ANCHOR_RMSE_PX
                or abs(k1) > MAX_CONFIDENT_OFFSET_K1_ABS
            ):
                continue
            fast_anchor_rows.append({
                "K": K,
                "dist": dist,
                "R": R,
                "t": t,
                "rmse": float(rmse),
                "pnp_rmse": float(pnp_rmse),
                "offset": offset,
                "offset_dist": float(offset_dist),
                "focal": float(K[0, 0]),
                "model_name": model_name,
                "k1": k1,
            })

    if fast_anchor_rows:
        def fast_row_score(row):
            return (
                float(row["rmse"])
                + 0.025 * float(row["pnp_rmse"])
                + 0.45 * abs(float(row.get("k1", 0.0)))
                + (0.20 if str(row.get("model_name")).endswith("-k1") else 0.0)
                + 0.015 * float(row["offset_dist"])
            )

        chosen = min(fast_anchor_rows, key=fast_row_score)
        return (
            chosen["K"],
            chosen["dist"],
            chosen["R"],
            chosen["t"],
            chosen["rmse"],
            chosen["model_name"],
            chosen["offset"],
            chosen["pnp_rmse"],
        )

    focal_values = []
    step = max(float(WIDE_OFFSET_FOCAL_SCAN_STEP_PX), 20.0)
    n_steps = int(np.floor((focal_hi - focal_lo) / step)) + 1
    for i in range(max(1, n_steps)):
        focal_values.append(float(focal_lo + i * step))
    focal_values.extend([focal_hi, focal_anchor, orientation_focal])
    unique_focals = []
    for focal in sorted(focal_values):
        focal = float(np.clip(focal, focal_lo, focal_hi))
        if all(abs(focal - old) > 1.0 for old in unique_focals):
            unique_focals.append(focal)

    accepted = []
    for _offset_score, pnp_rmse, offset, offset_dist, all_obj, all_img in offset_candidates:
        for focal in unique_focals:
            for model_name, k1_prior in (
                ("single-view-wide-offset-focal-scan-zero-dist", 0.0),
                ("single-view-wide-offset-focal-scan-k1", None),
            ):
                candidate = _fixed_focal_k1_pose_fallback(
                    all_obj,
                    all_img,
                    image_size,
                    focal,
                    k1_seed=0.0,
                    k1_prior=k1_prior,
                    rmse_limit=rmse_limit,
                )
                if candidate is None:
                    continue
                K, dist, R, t, rmse = candidate
                k1 = float(dist[0])
                if (
                    not np.isfinite(rmse)
                    or rmse > rmse_limit
                    or abs(k1) > MAX_CONFIDENT_OFFSET_K1_ABS
                ):
                    continue
                accepted.append({
                    "K": K,
                    "dist": dist,
                    "R": R,
                    "t": t,
                    "rmse": float(rmse),
                    "pnp_rmse": float(pnp_rmse),
                    "offset": offset,
                    "offset_dist": float(offset_dist),
                    "focal": float(K[0, 0]),
                    "model_name": model_name,
                    "k1": k1,
                })

    if not accepted:
        return None
    best_rmse = min(row["rmse"] for row in accepted)
    plateau = [
        row for row in accepted
        if row["rmse"] <= best_rmse + WIDE_OFFSET_FOCAL_SCAN_PLATEAU_RMSE_GAP_PX
    ]
    if not plateau:
        return None

    def row_score(row):
        focal_ratio = row["focal"] / max(focal_anchor, 1.0)
        return (
            abs(float(np.log(max(focal_ratio, 1e-6))))
            + 0.45 * abs(float(row.get("k1", 0.0)))
            + (0.20 if str(row.get("model_name")).endswith("-k1") else 0.0)
            + 0.025 * float(row["pnp_rmse"])
            + 0.015 * float(row["offset_dist"])
            + 0.010 * float(row["rmse"])
        )

    chosen = min(plateau, key=row_score)
    return (
        chosen["K"],
        chosen["dist"],
        chosen["R"],
        chosen["t"],
        chosen["rmse"],
        chosen["model_name"],
        chosen["offset"],
        chosen["pnp_rmse"],
    )


def _wide_offset_recovery_from_detections(
    detections,
    image_size,
    square_size,
    focal_lo,
    focal_hi,
    *,
    model_prefix="raw-candidate",
    sources=None,
    offset_hint_rmse=None,
):
    """Run the raw wide-offset solver on an already selected 3-face candidate."""
    try:
        from face_detector import (
            _cube_detection_best_offset_pnp_rmse,
            _cube_detection_geometry_rmse,
            _detections_have_excessive_overlap,
            _face_homography_stats,
            _normalize_face_axis_order,
        )
    except Exception:
        return None

    w_img, h_img = image_size
    detections = _normalize_face_axis_order(detections or [])[:3]
    if len(detections) < 3:
        return None
    if _detections_have_excessive_overlap(detections, threshold=0.55):
        return None

    corner_count = sum(len(corners) for corners, _pat, _label in detections)
    if corner_count < MIN_RAW_CANDIDATE_RECOVERY_CORNERS:
        return None

    line_qualities = [
        _corner_line_quality(corners, pattern)
        for corners, pattern, _label in detections
    ]
    if (
        any((not np.isfinite(q)) for q in line_qualities)
        or max(line_qualities) > MAX_RAW_CANDIDATE_LINE_QUALITY_PX
    ):
        return None

    homography_rows = []
    strict_homography_ok = True
    topology_homography_ok = True
    for corners, pattern, _label in detections:
        try:
            h_rmse, rh_rmse, inlier = _face_homography_stats(corners, pattern)
        except Exception:
            return None
        homography_rows.append((h_rmse, rh_rmse, inlier))
        strict_row_ok = (
            np.isfinite(h_rmse)
            and h_rmse <= MAX_RAW_CANDIDATE_HOMOGRAPHY_RMSE_PX
            and rh_rmse <= MAX_RAW_CANDIDATE_ROBUST_HOMOGRAPHY_RMSE_PX
            and inlier >= MIN_RAW_CANDIDATE_HOMOGRAPHY_INLIER_FRAC
        )
        topology_row_ok = (
            np.isfinite(h_rmse)
            and h_rmse <= MAX_TOPOLOGY_VETTED_RAW_HOMOGRAPHY_RMSE_PX
            and rh_rmse <= MAX_TOPOLOGY_VETTED_RAW_ROBUST_HOMOGRAPHY_RMSE_PX
            and inlier >= MIN_TOPOLOGY_VETTED_RAW_HOMOGRAPHY_INLIER_FRAC
        )
        strict_homography_ok = strict_homography_ok and strict_row_ok
        topology_homography_ok = topology_homography_ok and topology_row_ok

    centered_rmse = _cube_detection_geometry_rmse(
        detections, (h_img, w_img), n_faces=3, assume_normalized=True)
    offset_hint, _offset, _offset_dist = _cube_detection_best_offset_pnp_rmse(
        detections, (h_img, w_img), n_faces=3, assume_normalized=True,
        max_offset_dist=MAX_WIDE_SINGLE_FACE_OFFSET_DIST_SQUARES)
    topology_vetted_candidate = (
        (not strict_homography_ok)
        and topology_homography_ok
        and all(min(pattern) >= MIN_RELIABLE_FACE_INNER_DIM
                for _corners, pattern, _label in detections)
        and max(line_qualities) <= MAX_TOPOLOGY_VETTED_RAW_LINE_QUALITY_PX
        and np.isfinite(centered_rmse)
        and centered_rmse <= MAX_TOPOLOGY_VETTED_RAW_CENTERED_PNP_RMSE_PX
        and np.isfinite(offset_hint)
        and offset_hint <= MAX_TOPOLOGY_VETTED_RAW_OFFSET_HINT_RMSE_PX
    )
    if not strict_homography_ok and not topology_vetted_candidate:
        return None
    pnp_rmse_limit = (
        MAX_TOPOLOGY_VETTED_WIDE_OFFSET_PNP_RMSE_PX
        if topology_vetted_candidate
        else MAX_CONFIDENT_WIDE_OFFSET_PNP_RMSE_PX
    )
    final_rmse_limit = (
        MAX_TOPOLOGY_VETTED_WIDE_OFFSET_RMSE_PX
        if topology_vetted_candidate
        else MAX_CONFIDENT_WIDE_OFFSET_FIXED_FOCAL_RMSE_PX
    )

    diag = float(np.hypot(w_img, h_img))
    focal_anchor = float(np.clip(
        WIDE_OFFSET_FOCAL_SCAN_ANCHOR_DIAG_MULT * diag,
        focal_lo,
        focal_hi,
    ))
    K_seed = np.array([
        [focal_anchor, 0.0, w_img / 2.0],
        [0.0, focal_anchor, h_img / 2.0],
        [0.0, 0.0, 1.0],
    ], dtype=np.float64)
    patterns = [pattern for _corners, pattern, _label in detections]
    image_points_by_face = [
        corners.reshape(-1, 1, 2).astype(np.float32)
        for corners, _pattern, _label in detections
    ]

    recovered = _single_view_wide_offset_focal_scan_fallback(
        image_points_by_face,
        patterns,
        image_size,
        square_size,
        K_seed,
        focal_lo,
        focal_hi,
        pnp_rmse_limit=pnp_rmse_limit,
        rmse_limit=final_rmse_limit,
    )
    if recovered is None:
        return None
    K, dist, R, t, rmse, model_name, inferred_offset, offset_pnp = recovered
    k1 = float(dist[0])
    if (
        not np.isfinite(rmse)
        or rmse > final_rmse_limit
        or abs(k1) > MAX_CONFIDENT_OFFSET_K1_ABS
        or not np.isfinite(offset_pnp)
        or offset_pnp > pnp_rmse_limit
    ):
        return None

    if topology_vetted_candidate:
        multi_recovered = _multi_face_offset_fallback(
            image_points_by_face,
            patterns,
            image_size,
            square_size,
            K_seed,
            focal_lo,
            focal_hi,
            MAX_CONFIDENT_RMSE_PX,
            force=True,
            max_offset_dist=MAX_WIDE_SINGLE_FACE_OFFSET_DIST_SQUARES,
            min_changed_faces=MIN_MULTI_FACE_OFFSET_CHANGED_FACES,
            pnp_limit=MAX_CONFIDENT_INITIAL_PNP_RMSE_PX,
            allow_strong_ambiguous=True,
        )
        if multi_recovered is not None:
            (
                multi_K, multi_dist, multi_R, multi_t, multi_rmse,
                multi_model_name, multi_offsets, multi_changed,
                multi_pnp_rmse,
            ) = multi_recovered
            if (
                np.isfinite(multi_rmse)
                and multi_rmse + 0.35 < rmse
                and np.isfinite(multi_pnp_rmse)
                and multi_pnp_rmse <= MAX_CONFIDENT_INITIAL_PNP_RMSE_PX
            ):
                multi_faces = _faces_from_square_offsets(
                    patterns, square_size, multi_offsets)
                multi_detected = []
                for pts, face in zip(image_points_by_face, multi_faces):
                    multi_detected.append(DetectedFace(
                        image_points=pts.astype(np.float32),
                        object_points=object_points_for_face(face),
                        valid=True,
                    ))
                primary_face = int(multi_changed[0]) if multi_changed else 0
                primary_offset = (
                    primary_face,
                    float(multi_offsets[primary_face][0]),
                    float(multi_offsets[primary_face][1]),
                )
                if sources is None:
                    sources = [
                        f"detector:{label}:{pattern[0]}x{pattern[1]}"
                        for _corners, pattern, label in detections
                    ]
                hint = offset_hint_rmse
                if hint is None:
                    hint = offset_hint if np.isfinite(offset_hint) else centered_rmse
                return {
                    "K": multi_K,
                    "dist": multi_dist,
                    "R": multi_R,
                    "t": multi_t,
                    "rmse": float(multi_rmse),
                    "model_name": f"{model_prefix}-{multi_model_name}",
                    "inferred_offset": primary_offset,
                    "inferred_offsets": list(multi_offsets),
                    "changed_faces": list(multi_changed),
                    "offset_pnp_rmse": float(multi_pnp_rmse),
                    "faces": multi_faces,
                    "detected_faces": multi_detected,
                    "detections": detections,
                    "sources": list(sources),
                    "offset_hint_rmse": float(
                        hint if np.isfinite(hint) else np.nan),
                    "topology_vetted": True,
                }

    _max_outer_squares, offsets = _center_offsets_in_squares(patterns)
    vary_face = int(inferred_offset[0])
    if not (0 <= vary_face < len(offsets)):
        return None
    offsets = list(offsets)
    offsets[vary_face] = (
        float(inferred_offset[1]),
        float(inferred_offset[2]),
    )
    faces = _faces_from_square_offsets(patterns, square_size, offsets)
    detected = []
    for pts, face in zip(image_points_by_face, faces):
        detected.append(DetectedFace(
            image_points=pts.astype(np.float32),
            object_points=object_points_for_face(face),
            valid=True,
        ))
    if sources is None:
        sources = [
            f"detector:{label}:{pattern[0]}x{pattern[1]}"
            for _corners, pattern, label in detections
        ]
    hint = offset_hint_rmse
    if hint is None:
        hint = offset_hint if np.isfinite(offset_hint) else centered_rmse

    return {
        "K": K,
        "dist": dist,
        "R": R,
        "t": t,
        "rmse": float(rmse),
        "model_name": f"{model_prefix}-{model_name}",
        "inferred_offset": inferred_offset,
        "offset_pnp_rmse": float(offset_pnp),
        "faces": faces,
        "detected_faces": detected,
        "detections": detections,
        "sources": list(sources),
        "offset_hint_rmse": float(hint if np.isfinite(hint) else np.nan),
        "topology_vetted": bool(topology_vetted_candidate),
    }


def _raw_candidate_wide_offset_recovery(
    gray,
    image_size,
    square_size,
    focal_lo,
    focal_hi,
):
    """Retry calibration from unrefined face-grid candidates after failure.

    Some difficult single-frame cases have a physically consistent grid
    candidate whose raw OpenCV corners satisfy the trihedral cube model, while
    subsequent cornerSubPix refinement moves a small face enough to break the
    offset/focal scan.  This branch is intentionally late and conservative:
    it only runs after the normal path is failing, and it still requires all
    three raw faces to pass line, homography, offset-PnP, and final reprojection
    gates.
    """
    if not ENABLE_RAW_CANDIDATE_WIDE_OFFSET_RECOVERY:
        return None
    try:
        from face_detector import (
            _cluster_dark_components,
            _cube_detection_best_offset_pnp_rmse,
            _cube_detection_geometry_rmse,
            _dedupe_face_candidates,
            _detect_pattern_candidates_in_face,
            _detections_have_excessive_overlap,
            _face_homography_stats,
            _label_cube_clusters,
            _normalize_face_axis_order,
            _small_target_region_search_patterns,
            _small_target_top_blob_grid_candidates,
        )
    except Exception:
        return None

    w_img, h_img = image_size
    try:
        clusters = _label_cube_clusters(
            _cluster_dark_components(gray, n_faces=3, verbose=False))
    except Exception:
        return None
    if len(clusters) < 3:
        return None

    labels = ["XY", "XZ", "YZ"]
    by_label = {label: [] for label in labels}
    for face in clusters:
        label = face.get("label")
        if label not in by_label:
            continue
        try:
            by_label[label].extend(_detect_pattern_candidates_in_face(
                gray, face["poly"], label, max_candidates=8,
                patterns_override=_small_target_region_search_patterns(label)))
            if label == "XY":
                by_label[label].extend(_small_target_top_blob_grid_candidates(
                    gray, face["poly"], max_candidates=8))
            by_label[label] = _dedupe_face_candidates(by_label[label])[:8]
        except Exception:
            continue
    if any(not by_label[label] for label in labels):
        return None

    ranked = []
    for combo in itertools.product(by_label["XY"], by_label["XZ"], by_label["YZ"]):
        detections = _normalize_face_axis_order([
            (corners, pattern, label)
            for _score, corners, pattern, label, _source in combo
        ])[:3]
        if len(detections) < 3:
            continue
        if _detections_have_excessive_overlap(detections, threshold=0.55):
            continue
        corner_count = sum(len(corners) for corners, _pat, _label in detections)
        if corner_count < MIN_RAW_CANDIDATE_RECOVERY_CORNERS:
            continue
        line_qualities = [
            _corner_line_quality(corners, pattern)
            for corners, pattern, _label in detections
        ]
        if (
            any((not np.isfinite(q)) for q in line_qualities)
            or max(line_qualities) > MAX_RAW_CANDIDATE_LINE_QUALITY_PX
        ):
            continue
        homography_rows = []
        homography_ok = True
        for corners, pattern, _label in detections:
            try:
                h_rmse, rh_rmse, inlier = _face_homography_stats(corners, pattern)
            except Exception:
                homography_ok = False
                break
            homography_rows.append((h_rmse, rh_rmse, inlier))
            if (
                not np.isfinite(h_rmse)
                or h_rmse > MAX_RAW_CANDIDATE_HOMOGRAPHY_RMSE_PX
                or rh_rmse > MAX_RAW_CANDIDATE_ROBUST_HOMOGRAPHY_RMSE_PX
                or inlier < MIN_RAW_CANDIDATE_HOMOGRAPHY_INLIER_FRAC
            ):
                homography_ok = False
                break
        if not homography_ok:
            continue

        centered_rmse = _cube_detection_geometry_rmse(
            detections, gray.shape, n_faces=3, assume_normalized=True)
        offset_rmse, _offset, offset_dist = _cube_detection_best_offset_pnp_rmse(
            detections, gray.shape, n_faces=3, assume_normalized=True,
            max_offset_dist=MAX_WIDE_SINGLE_FACE_OFFSET_DIST_SQUARES)
        centered_score = centered_rmse if np.isfinite(centered_rmse) else 1e6
        offset_score = offset_rmse if np.isfinite(offset_rmse) else 1e6
        score = (
            min(centered_score, 1.70 * offset_score)
            + 0.35 * max(line_qualities)
            + 0.10 * max(row[0] for row in homography_rows)
            + 0.04 * float(offset_dist if np.isfinite(offset_dist) else 0.0)
            - 0.015 * float(corner_count)
        )
        ranked.append((score, detections, combo, centered_rmse, offset_rmse))

    if not ranked:
        return None
    ranked.sort(key=lambda item: item[0])

    diag = float(np.hypot(w_img, h_img))
    focal_anchor = float(np.clip(
        WIDE_OFFSET_FOCAL_SCAN_ANCHOR_DIAG_MULT * diag,
        focal_lo,
        focal_hi,
    ))
    K_seed = np.array([
        [focal_anchor, 0.0, w_img / 2.0],
        [0.0, focal_anchor, h_img / 2.0],
        [0.0, 0.0, 1.0],
    ], dtype=np.float64)

    best = None
    for _score, detections, combo, centered_rmse, offset_hint in ranked[:MAX_RAW_CANDIDATE_RECOVERY_COMBOS]:
        patterns = [pattern for _corners, pattern, _label in detections]
        image_points_by_face = [
            corners.reshape(-1, 1, 2).astype(np.float32)
            for corners, _pattern, _label in detections
        ]
        recovered = _single_view_wide_offset_focal_scan_fallback(
            image_points_by_face,
            patterns,
            image_size,
            square_size,
            K_seed,
            focal_lo,
            focal_hi,
        )
        if recovered is None:
            continue
        K, dist, R, t, rmse, model_name, inferred_offset, offset_pnp = recovered
        k1 = float(dist[0])
        if (
            not np.isfinite(rmse)
            or rmse > MAX_CONFIDENT_WIDE_OFFSET_FIXED_FOCAL_RMSE_PX
            or abs(k1) > MAX_CONFIDENT_OFFSET_K1_ABS
            or not np.isfinite(offset_pnp)
            or offset_pnp > MAX_CONFIDENT_WIDE_OFFSET_PNP_RMSE_PX
        ):
            continue

        max_outer_squares, offsets = _center_offsets_in_squares(patterns)
        vary_face = int(inferred_offset[0])
        if not (0 <= vary_face < len(offsets)):
            continue
        offsets = list(offsets)
        offsets[vary_face] = (
            float(inferred_offset[1]),
            float(inferred_offset[2]),
        )
        faces = _faces_from_square_offsets(patterns, square_size, offsets)
        detected = []
        for pts, face in zip(image_points_by_face, faces):
            detected.append(DetectedFace(
                image_points=pts.astype(np.float32),
                object_points=object_points_for_face(face),
                valid=True,
            ))
        score = (
            float(rmse)
            + 0.035 * float(offset_pnp)
            + 0.25 * abs(k1)
            + 0.010 * float(centered_rmse if np.isfinite(centered_rmse) else 20.0)
        )
        if best is None or score < best[0]:
            best = (
                score,
                K,
                dist,
                R,
                t,
                float(rmse),
                f"raw-candidate-{model_name}",
                inferred_offset,
                float(offset_pnp),
                faces,
                detected,
                detections,
                combo,
                float(offset_hint if np.isfinite(offset_hint) else np.nan),
            )
            if (
                rmse <= MAX_CONFIDENT_WIDE_OFFSET_FIXED_FOCAL_RMSE_PX
                and offset_pnp <= 10.0
                and abs(k1) <= 0.05
            ):
                break

    if best is None:
        return None
    (
        _score, K, dist, R, t, rmse, model_name, inferred_offset,
        offset_pnp, faces, detected, detections, combo, offset_hint,
    ) = best
    return {
        "K": K,
        "dist": dist,
        "R": R,
        "t": t,
        "rmse": rmse,
        "model_name": model_name,
        "inferred_offset": inferred_offset,
        "offset_pnp_rmse": offset_pnp,
        "faces": faces,
        "detected_faces": detected,
        "detections": detections,
        "sources": [source for _score, _corners, _pattern, _label, source in combo],
        "offset_hint_rmse": offset_hint,
    }


def _multi_face_offset_fallback(
    image_points_by_face,
    patterns,
    image_size,
    square_size,
    K_seed,
    focal_lo,
    focal_hi,
    rmse_limit,
    *,
    force=False,
    max_offset_dist=None,
    min_changed_faces=None,
    pnp_limit=None,
    allow_strong_ambiguous=False,
):
    """Infer coordinated integer offsets for multiple faces.

    This is a stricter last-resort fallback after the one-face offset model
    fails.  It keeps the square edge as the only metric scale, but allows the
    detected local grids on two or three faces to correspond to shifted integer
    positions on their printed face boards.
    """
    if not force and not ENABLE_MULTI_FACE_OFFSET_FALLBACK:
        return None
    if len(image_points_by_face) != 3 or len(patterns) != 3:
        return None

    if max_offset_dist is None:
        max_offset_dist = MAX_MULTI_FACE_OFFSET_DIST_SQUARES
    if min_changed_faces is None:
        min_changed_faces = MIN_MULTI_FACE_OFFSET_CHANGED_FACES
    if pnp_limit is None:
        pnp_limit = MAX_CONFIDENT_MULTI_OFFSET_PNP_RMSE_PX

    debug_multi_offset = os.environ.get("CALIB_DEBUG_MULTI_OFFSET") == "1"
    debug_counts = {
        "combos": 0,
        "orientations": 0,
        "pnp_pass": 0,
        "fit_candidates": 0,
        "rmse_pass": 0,
        "k1_pass": 0,
        "focal_pass": 0,
        "accepted": 0,
    }

    max_outer_squares, base_offsets = _center_offsets_in_squares(patterns)
    per_face_options = []
    for cols, rows in patterns:
        face_idx = len(per_face_options)
        center_x, center_y = base_offsets[face_idx]
        opts = [(float(center_x), float(center_y), 0.0)]
        for ox in range(1, int(max_outer_squares - cols) + 1):
            for oy in range(1, int(max_outer_squares - rows) + 1):
                offset_dist = float(np.hypot(
                    float(ox) - float(center_x),
                    float(oy) - float(center_y),
                ))
                if offset_dist <= max_offset_dist:
                    if (
                        abs(float(ox) - float(center_x)) < 1e-6
                        and abs(float(oy) - float(center_y)) < 1e-6
                    ):
                        continue
                    opts.append((float(ox), float(oy), offset_dist))
        per_face_options.append(opts)
    if debug_multi_offset:
        print(
            "  Multi-face offset search: "
            f"option_counts={[len(opts) for opts in per_face_options]}, "
            f"max_offset_dist={float(max_offset_dist):.2f}, "
            f"min_changed={int(min_changed_faces)}, "
            f"pnp_limit={float(pnp_limit):.2f}"
        )

    focal_ref = float(np.nanmean([K_seed[0, 0], K_seed[1, 1]]))
    if not np.isfinite(focal_ref) or focal_ref <= 0:
        return None

    all_img = np.vstack([
        pts.reshape(-1, 2) for pts in image_points_by_face
    ]).astype(np.float32)
    best = None
    accepted_solutions = []

    for o0 in per_face_options[0]:
        for o1 in per_face_options[1]:
            for o2 in per_face_options[2]:
                raw_options = [o0, o1, o2]
                changed = [
                    i for i, opt in enumerate(raw_options)
                    if opt[2] > 1e-6
                ]
                if len(changed) < min_changed_faces:
                    continue
                debug_counts["combos"] += 1

                offsets = [(opt[0], opt[1]) for opt in raw_options]
                faces = _faces_from_square_offsets(
                    patterns, square_size, offsets)
                detected = []
                for pts, face in zip(image_points_by_face, faces):
                    detected.append(DetectedFace(
                        image_points=pts.astype(np.float32),
                        object_points=object_points_for_face(face),
                        valid=True,
                    ))

                orientations = apply_best_face_orientations(
                    detected, faces, [0, 1, 2], K_seed, None)
                if not orientations:
                    continue
                debug_counts["orientations"] += 1
                pnp_rmse = float(orientations[0]["rmse"])
                if (
                    not np.isfinite(pnp_rmse)
                    or pnp_rmse > pnp_limit
                ):
                    continue
                debug_counts["pnp_pass"] += 1

                all_obj = np.vstack([
                    detected[i].object_points for i in range(3)
                ]).reshape(-1, 3).astype(np.float32)
                k1_candidate = _single_view_k1_fallback(
                    all_obj, all_img, image_size, K_seed,
                    focal_lo, focal_hi, rmse_limit,
                )
                zero_candidate = _single_view_zero_dist_fallback(
                    all_obj, all_img, image_size, K_seed,
                    focal_lo, focal_hi, rmse_limit,
                )

                offset_dist_sum = float(sum(opt[2] for opt in raw_options))
                for model_name, candidate in (
                    ("single-view-multi-offset-k1", k1_candidate),
                    ("single-view-multi-offset-zero-dist", zero_candidate),
                ):
                    if candidate is None:
                        continue
                    debug_counts["fit_candidates"] += 1
                    K, dist, R, t, rmse = candidate
                    offset_rmse_limit = (
                        MAX_CONFIDENT_OFFSET_ZERO_DIST_RMSE_PX
                        if model_name == "single-view-multi-offset-zero-dist"
                        else MAX_CONFIDENT_OFFSET_K1_RMSE_PX
                    )
                    if not np.isfinite(rmse) or rmse > offset_rmse_limit:
                        continue
                    debug_counts["rmse_pass"] += 1
                    k1 = float(dist[0])
                    if abs(k1) > MAX_CONFIDENT_OFFSET_K1_ABS:
                        continue
                    debug_counts["k1_pass"] += 1

                    ratio = float(K[0, 0]) / focal_ref
                    if ratio < 0.80 or ratio > 1.20:
                        continue
                    debug_counts["focal_pass"] += 1
                    focal_penalty = abs(np.log(ratio))
                    # Keep this conservative: prefer fewer changed faces and
                    # smaller offsets unless reprojection is clearly better.
                    score = float(
                        rmse
                        + 0.10 * pnp_rmse
                        + 1.50 * abs(k1)
                        + 1.50 * focal_penalty
                        + 0.55 * len(changed)
                        + 0.10 * offset_dist_sum
                    )
                    candidate_best = (
                        score, K, dist, R, t, float(rmse), model_name,
                        offsets, changed, pnp_rmse,
                    )
                    accepted_solutions.append(candidate_best)
                    debug_counts["accepted"] += 1
                    if best is None or score < best[0]:
                        best = candidate_best

    if best is None:
        if debug_multi_offset:
            print(f"  Multi-face offset search rejected: {debug_counts}")
        return None
    ambiguous = _offset_solution_is_ambiguous(best, accepted_solutions)
    if ambiguous:
        allow_ambiguous_winner = False
        if allow_strong_ambiguous and len(accepted_solutions) >= 2:
            ranked = sorted(accepted_solutions, key=lambda item: item[0])
            top = ranked[0]
            second = ranked[1]
            top_score = float(top[0])
            second_score = float(second[0])
            top_rmse = float(top[5])
            second_rmse = float(second[5])
            top_k1 = abs(float(top[2][0]))
            top_changed = top[8]
            top_pnp = float(top[9])
            allow_ambiguous_winner = (
                top is best
                and np.isfinite(top_rmse)
                and np.isfinite(top_pnp)
                and top_rmse <= MAX_STRONG_MULTI_OFFSET_RMSE_PX
                and top_pnp <= MAX_STRONG_MULTI_OFFSET_PNP_RMSE_PX
                and top_k1 <= MAX_CONFIDENT_OFFSET_K1_ABS
                and len(top_changed) <= MAX_STRONG_MULTI_OFFSET_CHANGED_FACES
                and second_score - top_score >= MIN_STRONG_MULTI_OFFSET_SCORE_GAP
                and second_rmse - top_rmse >= MIN_STRONG_MULTI_OFFSET_RMSE_GAP_PX
            )
            if allow_ambiguous_winner and debug_multi_offset:
                print(
                    "  Multi-face offset strong ambiguous winner accepted: "
                    f"score_gap={second_score - top_score:.2f}, "
                    f"rmse_gap={second_rmse - top_rmse:.2f}"
                )
        if allow_ambiguous_winner:
            ambiguous = False

    if ambiguous:
        if debug_multi_offset:
            ranked_debug = sorted(accepted_solutions, key=lambda item: item[0])[:8]
            for row_idx, row in enumerate(ranked_debug):
                (
                    score, K_dbg, dist_dbg, _R_dbg, _t_dbg, rmse_dbg,
                    model_dbg, offsets_dbg, changed_dbg, pnp_dbg,
                ) = row
                print(
                    "    candidate "
                    f"{row_idx}: score={float(score):.2f}, "
                    f"rmse={float(rmse_dbg):.2f}, pnp={float(pnp_dbg):.2f}, "
                    f"fx={float(K_dbg[0, 0]):.1f}, "
                    f"k1={float(dist_dbg[0]):.3f}, "
                    f"model={model_dbg}, changed={changed_dbg}, "
                    f"offsets={offsets_dbg}"
                )
            print(
                "  Multi-face offset search ambiguous: "
                f"{debug_counts}, accepted={len(accepted_solutions)}"
            )
        return None
    (
        _score, K, dist, R, t, rmse, model_name,
        offsets, changed, pnp_rmse,
    ) = best
    if debug_multi_offset:
        print(
            "  Multi-face offset search selected: "
            f"{model_name}, rmse={float(rmse):.2f}px, "
            f"pnp={float(pnp_rmse):.2f}px, changed={changed}, "
            f"offsets={offsets}, counts={debug_counts}"
        )
    return K, dist, R, t, rmse, model_name, offsets, changed, pnp_rmse


def _fixed_focal_k1_pose_fallback(
    object_points,
    image_points,
    image_size,
    focal_px,
    k1_seed=0.0,
    k1_prior=None,
    rmse_limit=MAX_CONFIDENT_FIXED_FOCAL_RMSE_PX,
):
    """Estimate pose with externally supplied focal length, optionally fixing k1."""
    w_img, h_img = image_size
    if object_points.shape[0] < 30:
        return None
    if focal_px is None or not np.isfinite(focal_px) or focal_px <= 0:
        return None

    K = np.array([
        [float(focal_px), 0.0, w_img / 2.0],
        [0.0, float(focal_px), h_img / 2.0],
        [0.0, 0.0, 1.0],
    ], dtype=np.float64)
    obj = object_points.reshape(-1, 3).astype(np.float64)
    img = image_points.reshape(-1, 2).astype(np.float64)

    try:
        ok, rvec, tvec = cv2.solvePnP(
            obj.reshape(-1, 1, 3),
            img.reshape(-1, 1, 2),
            K,
            np.zeros(5, dtype=np.float64),
            flags=cv2.SOLVEPNP_ITERATIVE,
        )
    except cv2.error:
        return None
    if not ok:
        return None

    k1_fixed = None
    if k1_prior is not None and np.isfinite(k1_prior):
        k1_fixed = float(k1_prior)
        if abs(k1_fixed) > MAX_CONFIDENT_K1_ABS:
            return None

    k1_seed = float(k1_seed) if np.isfinite(k1_seed) else 0.0
    k1_seed = float(np.clip(k1_seed, -MAX_CONFIDENT_K1_ABS, MAX_CONFIDENT_K1_ABS))

    if k1_fixed is None:
        x0 = np.array([
            k1_seed,
            rvec.ravel()[0], rvec.ravel()[1], rvec.ravel()[2],
            tvec.ravel()[0], tvec.ravel()[1], tvec.ravel()[2],
        ], dtype=np.float64)
    else:
        x0 = np.array([
            rvec.ravel()[0], rvec.ravel()[1], rvec.ravel()[2],
            tvec.ravel()[0], tvec.ravel()[1], tvec.ravel()[2],
        ], dtype=np.float64)

    def residuals(params):
        if k1_fixed is None:
            k1 = params[0]
            rv = params[1:4]
            tv = params[4:7]
        else:
            k1 = k1_fixed
            rv = params[:3]
            tv = params[3:6]
        proj, _ = cv2.projectPoints(
            obj.reshape(-1, 1, 3),
            rv.reshape(3, 1),
            tv.reshape(3, 1),
            K,
            np.array([k1, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
        )
        return (proj.reshape(-1, 2) - img).ravel()

    try:
        if k1_fixed is None:
            opt = least_squares(
                residuals,
                x0,
                bounds=(
                    np.array([-MAX_CONFIDENT_K1_ABS, -np.inf, -np.inf, -np.inf, -np.inf, -np.inf, -np.inf]),
                    np.array([MAX_CONFIDENT_K1_ABS, np.inf, np.inf, np.inf, np.inf, np.inf, np.inf]),
                ),
                loss="soft_l1",
                f_scale=3.0,
                max_nfev=1000,
                xtol=1e-10,
                ftol=1e-10,
            )
        else:
            opt = least_squares(
                residuals,
                x0,
                loss="soft_l1",
                f_scale=3.0,
                max_nfev=1000,
                xtol=1e-10,
                ftol=1e-10,
            )
    except (ValueError, RuntimeError):
        return None

    err = residuals(opt.x).reshape(-1, 2)
    rmse = float(np.sqrt(np.mean(np.sum(err * err, axis=1))))
    if (not np.isfinite(rmse)) or rmse > rmse_limit:
        return None

    if k1_fixed is None:
        k1 = float(opt.x[0])
        if abs(k1) >= 0.98 * MAX_CONFIDENT_K1_ABS:
            return None
        rv = opt.x[1:4]
        tv = opt.x[4:7]
    else:
        k1 = k1_fixed
        rv = opt.x[:3]
        tv = opt.x[3:6]
    R, _ = cv2.Rodrigues(rv)
    dist5 = np.array([k1, 0.0, 0.0, 0.0, 0.0], dtype=np.float64)
    if not np.all(np.isfinite(R)) or not np.all(np.isfinite(dist5)):
        return None
    return K, dist5, R, tv.copy(), rmse


def _focal_observability_profile(
    object_points,
    image_points,
    image_size,
    *,
    k1_seed=0.0,
):
    """Measure whether one frame contains a distinct focal-length optimum."""
    w_img, h_img = image_size
    diag = float(np.hypot(w_img, h_img))
    step = max(float(FOCAL_OBSERVABILITY_STEP_DIAG_MULT), 0.01)
    ratios = []
    ratio = float(MIN_CONFIDENT_FOCAL_DIAG_MULT)
    while ratio <= float(MAX_CONFIDENT_FOCAL_DIAG_MULT) + 1e-9:
        ratios.append(float(min(ratio, MAX_CONFIDENT_FOCAL_DIAG_MULT)))
        ratio += step
    if abs(ratios[-1] - MAX_CONFIDENT_FOCAL_DIAG_MULT) > 1e-9:
        ratios.append(float(MAX_CONFIDENT_FOCAL_DIAG_MULT))

    samples = []
    for focal_ratio in ratios:
        focal = float(focal_ratio * diag)
        candidates = []
        for k1_prior in (0.0, None):
            candidate = _fixed_focal_k1_pose_fallback(
                object_points,
                image_points,
                image_size,
                focal,
                k1_seed=k1_seed,
                k1_prior=k1_prior,
                rmse_limit=100.0,
            )
            if candidate is not None:
                candidates.append(candidate)
        if not candidates:
            continue
        chosen = min(candidates, key=lambda item: float(item[4]))
        samples.append({
            "focal_ratio_diag": float(focal_ratio),
            "focal_px": focal,
            "rmse_px": float(chosen[4]),
            "k1": float(chosen[1][0]),
        })

    if len(samples) < 3:
        return {
            "observable": False,
            "reasons": ["fewer than three finite focal-profile samples"],
            "samples": samples,
        }

    best = min(samples, key=lambda item: item["rmse_px"])
    best_rmse = float(best["rmse_px"])
    rmse_values = [float(item["rmse_px"]) for item in samples]
    contrast = float(max(rmse_values) - best_rmse)
    plateau = [
        item for item in samples
        if float(item["rmse_px"])
        <= best_rmse + FOCAL_OBSERVABILITY_PLATEAU_GAP_PX
    ]
    plateau_lo = min(float(item["focal_ratio_diag"]) for item in plateau)
    plateau_hi = max(float(item["focal_ratio_diag"]) for item in plateau)
    plateau_width = float(plateau_hi - plateau_lo)
    best_ratio = float(best["focal_ratio_diag"])
    lower_interior = (
        MIN_CONFIDENT_FOCAL_DIAG_MULT
        + FOCAL_OBSERVABILITY_EDGE_MARGIN_DIAG
    )
    upper_interior = (
        MAX_CONFIDENT_FOCAL_DIAG_MULT
        - FOCAL_OBSERVABILITY_EDGE_MARGIN_DIAG
    )

    reasons = []
    if best_ratio <= lower_interior or best_ratio >= upper_interior:
        reasons.append(
            f"best focal lies at the search boundary ({best_ratio:.2f}x diagonal)"
        )
    if contrast < FOCAL_OBSERVABILITY_MIN_CONTRAST_PX:
        reasons.append(
            f"profile contrast is only {contrast:.3f}px"
        )
    if plateau_width > FOCAL_OBSERVABILITY_MAX_PLATEAU_WIDTH_DIAG:
        reasons.append(
            "near-optimal focal plateau is too wide "
            f"({plateau_width:.2f}x diagonal)"
        )

    return {
        "observable": not reasons,
        "best_focal_px": float(best["focal_px"]),
        "best_focal_ratio_diag": best_ratio,
        "best_rmse_px": best_rmse,
        "profile_contrast_px": contrast,
        "plateau_lo_ratio_diag": plateau_lo,
        "plateau_hi_ratio_diag": plateau_hi,
        "plateau_width_ratio_diag": plateau_width,
        "reasons": reasons,
        "samples": samples,
    }


@dataclass
class BestResult:
    """Complete calibration output with all derived parameters."""
    K: np.ndarray                # 3×3 intrinsic matrix
    dist: np.ndarray             # [k1, k2, p1, p2, k3]
    R: np.ndarray                # 3×3 rotation (world → camera)
    t: np.ndarray                # translation vector (mm)
    rmse: float                  # reprojection RMSE (pixels)
    # Derived
    fx_px: float; fy_px: float; skew_px: float
    cx_px: float; cy_px: float
    height_mm: float             # camera height above ground
    downtilt_deg: float          # optical axis vs horizontal
    cam_position: np.ndarray     # camera position in world frame
    # Quality
    fov_coverage_pct: float      # target coverage of FOV
    cube_area_pct: Optional[float]  # cube footprint / image area
    corner_quality: float        # mean line-fit RMS per face
    model_used: str              # '5-param' or 'k1-only'
    # Diagnostics
    n_corners: int = 0
    n_faces_detected: int = 0
    elapsed_sec: float = 0.0
    warnings: list = field(default_factory=list)
    preflight: dict = field(default_factory=dict)


def _cube_camera_pose_metrics(
    R: np.ndarray,
    t: np.ndarray,
) -> Tuple[np.ndarray, float, float]:
    """Return camera position, height, and downtilt in the cube world frame.

    The target definition uses XY as the top face and positive world Z down
    the two side faces.  OpenCV cameras look along positive camera Z.
    """
    rotation = np.asarray(R, dtype=np.float64).reshape(3, 3)
    translation = np.asarray(t, dtype=np.float64).reshape(3)
    camera_position = -rotation.T @ translation
    viewing_direction = rotation.T @ np.array([0.0, 0.0, 1.0])
    horizontal = float(np.hypot(viewing_direction[0], viewing_direction[1]))
    downtilt = float(np.degrees(np.arctan2(viewing_direction[2], horizontal)))
    height = float(-camera_position[2])
    return camera_position, height, downtilt


def calibrate_best(
    image_path: str,
    square_size_mm: float = DEFAULT_SQUARE_SIZE_MM,
    pattern_cols: int = 9,
    pattern_rows: int = 6,
    *,
    face_patterns: Optional[List[Tuple[int, int]]] = None,
    n_faces: int = 3,
    auto_orient_faces: bool = True,
    k1_only: bool = False,
    focal_px: Optional[float] = None,
    k1_prior: Optional[float] = None,
    verbose: bool = True,
    corners_path: Optional[str] = None,
    manual_face_rois: Optional[List[Tuple[int, int, int, int]]] = None,
    diagnostic_cache_path: Optional[str] = None,
    research_return_rejected: bool = False,
    research_skip_offset_search: bool = False,
    scale_prior_candidate: bool = False,
) -> BestResult:
    """Run the best calibration pipeline.

    Parameters
    ----------
    image_path : path to calibration image.
    square_size_mm : chessboard square edge length.
    pattern_cols, pattern_rows : inner corner counts (used when face_patterns is None).
    face_patterns : optional list of 3 (cols, rows), one per face [A, B, C].
    The checkerboard square edge is the only physical scale input.  Per-face
    grid offsets are inferred in square units from the configured patterns.
    auto_orient_faces : automatically choose per-face x/y flips by PnP.
    k1_only : if True, use k1-only model (recommended for webcams).
    focal_px : known focal length in pixels (from EXIF, sensor spec, or a
        multi-image group prior).
    k1_prior : optional radial distortion prior from a multi-image group
        calibration.  When supplied together with focal_px, the fixed-prior
        fallback estimates pose only.
    verbose : print progress.
    manual_face_rois : optional list of (x, y, w, h) image-space ROIs,
        ordered as [XY, XZ, YZ].  When supplied, chessboards are detected only
        inside these face regions and the cube-first detector is skipped.
    diagnostic_cache_path : optional research-only NPZ output containing the
        final three-face image/object correspondences and physical seed.
    scale_prior_candidate : allow a precomputed/recovered three-face grid to
        return a metric-scale candidate when the input-scale checker geometry is
        internally consistent but focal observability is weak.  The candidate
        is annotated in preflight and is not marked as fully confident.

    Returns
    -------
    BestResult with all parameters and diagnostics.
    """
    t_start = time.time()
    warnings = []
    square_size_mm = float(square_size_mm)
    if not np.isfinite(square_size_mm) or square_size_mm <= 0:
        raise ValueError(
            "square_size_mm must be a positive finite checkerboard square "
            "edge length in physical units, e.g. millimetres."
        )

    # ── Load image (Unicode-safe: cv2.imread fails on non-ASCII paths in some builds) ──
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"File not found: {image_path}")
    with open(image_path, 'rb') as f:
        data = np.frombuffer(f.read(), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Cannot decode: {image_path}")
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray_direct = cv2.imdecode(data, cv2.IMREAD_GRAYSCALE)
    if (
        gray_direct is None
        or gray_direct.shape[:2] != gray.shape[:2]
        or np.array_equal(gray_direct, gray)
    ):
        gray_direct = None
    h_img, w_img = gray.shape[:2]
    try:
        from face_detector import estimate_cube_area_pct
        cube_area_pct = estimate_cube_area_pct(gray, n_faces=n_faces)
    except Exception:
        cube_area_pct = None
    preflight = area_preflight_decision(
        cube_area_pct,
        manual_override=manual_face_rois is not None,
        precomputed_corners=corners_path is not None,
    )
    spatial_reject = _spatial_prefilter_not_cube_reason(
        gray,
        cube_area_pct,
        n_faces=n_faces,
        manual_override=manual_face_rois is not None,
        precomputed_corners=corners_path is not None,
    )
    if spatial_reject is not None:
        raise RuntimeError(spatial_reject)
    isolated_model_grades = _isolated_model_grade_filter()
    if isolated_model_grades:
        preflight["model_grade_isolation_gate"] = {
            "enabled": True,
            "allowed": sorted(isolated_model_grades),
            "decisions": [],
        }

    def _model_grade_isolation_allows(model_name: str, context: str) -> bool:
        if not isolated_model_grades:
            return True
        grade = _model_grade_from_name(model_name)
        allowed = grade in isolated_model_grades
        preflight["model_grade_isolation_gate"]["decisions"].append({
            "context": str(context),
            "model": str(model_name),
            "model_grade": grade,
            "accepted": bool(allowed),
        })
        return allowed

    faces = standard_three_face_target(
        square_size_mm, pattern_cols, pattern_rows,
        face_patterns=face_patterns, n_faces=n_faces,
        center_patterns_on_cube=True,
    )
    vp_labels = get_vp_labels(n_faces)

    small_target_attempt = _small_target_geometry_gate_active(
        cube_area_pct,
        preflight_requires_strict_gate=bool(
            preflight.get("requires_strict_small_target_gate", False)
        ),
        manual_override=manual_face_rois is not None,
    )
    preflight["small_target_geometry_gate_active"] = bool(
        small_target_attempt
    )

    if (
        manual_face_rois is None
        and corners_path is None
        and not preflight.get("can_attempt_calibration", True)
    ):
        raise RuntimeError(
            _range_boundary_message(
                cube_area_pct,
                "Keep this image as the current area-ratio boundary rather "
                "than an accepted calibration.",
            )
        )
    if (
        small_target_attempt
        and not DISABLE_AREA_RATIO_GATES
        and cube_area_pct is not None
        and (
            cube_area_pct < SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT
            or cube_area_pct > SMALL_TARGET_VALIDATED_ACCEPT_MAX_AREA_PCT
        )
    ):
        area_text = f"{cube_area_pct:.2f}%"
        raise RuntimeError(
            _small_target_boundary_message(
                cube_area_pct,
                f"cube area {area_text} is outside the current validated "
                "accepted small-target pocket "
                f"{SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT:.2f}-"
                f"{SMALL_TARGET_VALIDATED_ACCEPT_MAX_AREA_PCT:.2f}%",
            )
        )
    if small_target_attempt:
        warnings.append(
            f"Preflight: {preflight['recognition_label']} / "
            f"{preflight['calibration_label']}. "
            "Final acceptance requires the strict small-target gate."
        )

    if verbose:
        fp = face_patterns or [(pattern_cols, pattern_rows)] * n_faces
        sizes_str = ', '.join(f"{c}×{r}" for c, r in fp)
        print(f"Best Calibration — {w_img}×{h_img}, "
              f"faces=[{sizes_str}], s={square_size_mm}mm")

    # ── Load pre-computed corners if available ──
    precomputed = None
    precomputed_basename = os.path.basename(str(corners_path or ""))
    precomputed_is_grid_extrapolated = (
        corners_path is not None
        and "grid_extrapolated" in precomputed_basename
    )
    precomputed_is_trihedral_closure = (
        corners_path is not None
        and "trihedral_closure" in precomputed_basename
    )
    scale_prior_candidate_active = bool(
        ENABLE_SCALE_PRIOR_CANDIDATES
        and scale_prior_candidate
        and corners_path is not None
        and int(n_faces) == 3
    )
    preflight["scale_prior_candidate"] = {
        "enabled": bool(scale_prior_candidate_active),
        "source": (
            "grid_extrapolated_corners"
            if precomputed_is_grid_extrapolated else
            "precomputed_corners" if corners_path is not None else "none"
        ),
        "relaxed_failures": [],
        "accepted_as_candidate": False,
    }
    if corners_path is None:
        # Auto-detect: look for _gt.npz file next to the image
        auto_path = image_path.rsplit('.', 1)[0] + '_gt.npz'
        if os.path.exists(auto_path):
            corners_path = auto_path
    if corners_path and os.path.exists(corners_path):
        try:
            ensure_numpy_pickle_compat()
            data = np.load(corners_path, allow_pickle=True)
            if 'corners' in data:
                precomputed = data['corners']
            data.close()
        except Exception:
            pass

    # ── Step 0: CLAHE ──
    gray_enhanced = preprocess_image(gray)
    images_to_try = [("enhanced", gray_enhanced), ("original", gray)]

    def _detect_chessboard_in_roi(roi, pattern_size):
        x, y, rw, rh = [int(round(v)) for v in roi]
        x = max(0, min(x, w_img - 1))
        y = max(0, min(y, h_img - 1))
        rw = max(1, min(rw, w_img - x))
        rh = max(1, min(rh, h_img - y))
        if rw < 20 or rh < 20:
            return None, ""

        flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
        for src_name, src_img in images_to_try:
            crop = src_img[y:y + rh, x:x + rw]
            ok, corners = cv2.findChessboardCorners(crop, pattern_size, flags=flags)
            if ok:
                corners = corners.reshape(-1, 1, 2).astype(np.float32)
                corners[:, 0, 0] += x
                corners[:, 0, 1] += y
                return corners, src_name

            if hasattr(cv2, "findChessboardCornersSB"):
                try:
                    ok, corners = cv2.findChessboardCornersSB(
                        crop, pattern_size,
                        flags=cv2.CALIB_CB_NORMALIZE_IMAGE,
                    )
                except cv2.error:
                    ok, corners = False, None
                if ok:
                    corners = corners.reshape(-1, 1, 2).astype(np.float32)
                    corners[:, 0, 0] += x
                    corners[:, 0, 1] += y
                    return corners, src_name

        crop = gray_enhanced[y:y + rh, x:x + rw]
        corners = detect_corners_multiscale(crop, pattern_size)
        if corners is not None:
            corners = corners.reshape(-1, 1, 2).astype(np.float32)
            corners[:, 0, 0] += x
            corners[:, 0, 1] += y
            return corners, "enhanced"
        return None, ""

    # ── Step 1: Corner detection ──
    detected_faces: List[DetectedFace] = []
    cube_first = []
    detector_raw_detections = None
    if manual_face_rois is not None:
        if len(manual_face_rois) != n_faces:
            raise ValueError(
                f"manual_face_rois has {len(manual_face_rois)} entries "
                f"but n_faces={n_faces}"
            )
        warnings.append("Used manual face ROI mode (XY/XZ/YZ boxes).")
        face_names = ["XY", "XZ", "YZ"]
        manual_detections = []
        for fi, face in enumerate(faces):
            corners, src_name = _detect_chessboard_in_roi(
                manual_face_rois[fi], face.pattern_size,
            )
            if corners is None:
                label = face_names[fi] if fi < len(face_names) else f"face {fi}"
                raise RuntimeError(
                    f"Manual ROI {label} did not contain a detectable "
                    f"{face.pattern_size[0]}x{face.pattern_size[1]} chessboard."
                )
            label = face_names[fi] if fi < len(face_names) else f"face {fi}"
            manual_detections.append((corners, face.pattern_size, label))

        try:
            from face_detector import _normalize_face_axis_order
            manual_detections = _normalize_face_axis_order(manual_detections)
        except Exception as exc:
            warnings.append(f"Manual ROI axis normalization skipped: {exc}")
        if n_faces == 3:
            manual_detections = _apply_cube_spatial_understanding(
                manual_detections,
                (w_img, h_img),
                preflight,
                warnings,
                stage="manual_roi",
                strict=False,
            )

        face_patterns = [pat for _corners, pat, _label in manual_detections]
        faces = standard_three_face_target(
            square_size_mm, pattern_cols, pattern_rows,
            face_patterns=face_patterns, n_faces=n_faces,
            center_patterns_on_cube=True,
        )
        vp_labels = get_vp_labels(n_faces)

        for (corners, _pat, _label), face in zip(manual_detections, faces):
            blur_score = estimate_blur_level(gray, corners)
            win_w, win_h = adaptive_subpix_window(blur_score)
            corners_sub = _quality_gated_corner_subpix(
                gray, corners, face.pattern_size, (win_w, win_h),
                (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-6),
            )
            obj_pts = object_points_for_face(face)
            detected_faces.append(DetectedFace(
                image_points=corners_sub, object_points=obj_pts, valid=True))

    if not detected_faces and precomputed is None and n_faces >= 2:
        try:
            from face_detector import detect_corner_cube_faces
            primary_gray = gray
            secondary_gray = gray_direct
            secondary_source = "direct"

            cube_first = detect_corner_cube_faces(
                primary_gray, n_faces=n_faces, verbose=verbose,
                sparse_fast_return=(
                    small_target_attempt and secondary_gray is not None))
            if secondary_gray is not None and n_faces >= 3:
                from face_detector import (
                    _cube_detection_best_offset_pnp_rmse,
                    _cube_detection_geometry_rmse,
                    _cube_detection_sparse_face_count,
                    _normalize_face_axis_order,
                    _total_corner_count,
                )

                def _score_cube_first_for_detection(detections):
                    detections = _normalize_face_axis_order(detections or [])
                    if len(detections) < n_faces:
                        return float('inf'), float('inf'), float('inf'), 0, 99
                    centered = _cube_detection_geometry_rmse(
                        detections, gray.shape, n_faces=n_faces,
                        allow_sparse=True, assume_normalized=True)
                    offset_rmse, _offset, _offset_dist = (
                        _cube_detection_best_offset_pnp_rmse(
                            detections, gray.shape, n_faces=n_faces,
                            assume_normalized=True)
                    )
                    corners = _total_corner_count(detections)
                    sparse = _cube_detection_sparse_face_count(detections)
                    if not np.isfinite(centered):
                        centered = 80.0
                    if not np.isfinite(offset_rmse):
                        offset_rmse = 80.0
                    score = (
                        float(offset_rmse)
                        + 0.15 * float(centered)
                        + 1.25 * float(sparse)
                        - 0.010 * float(corners)
                    )
                    return score, float(offset_rmse), float(centered), corners, sparse

                base_score = _score_cube_first_for_detection(cube_first)
                should_try_secondary_gray = (
                    len(cube_first) < n_faces
                    or base_score[1] > 8.5
                    or base_score[2] > 14.0
                    or base_score[4] > 0
                )
                if small_target_attempt:
                    normalized_cube_first = (
                        _normalize_face_axis_order(cube_first or [])[:n_faces]
                    )
                    candidate_patterns = tuple(
                        tuple(int(v) for v in pat)
                        for _corners, pat, _label in normalized_cube_first
                    )
                    candidate_corners = sum(
                        len(corners)
                        for corners, _pat, _label in normalized_cube_first
                    )
                    if (
                        cube_area_pct is not None
                        and SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT <= 4.0
                        and cube_area_pct < 4.0
                        and len(cube_first) >= n_faces
                        and candidate_corners < MIN_SMALL_TARGET_CORNERS
                        and not _small_target_patterns_allowed(candidate_patterns)
                    ):
                        should_try_secondary_gray = False
                    if (
                        (
                            cube_area_pct is None
                            or cube_area_pct >= 6.0
                        )
                        and
                        len(cube_first) >= n_faces
                        and (
                            (
                                base_score[4] > 1
                                and candidate_corners < 70
                            )
                            or (
                                base_score[4] == 0
                                and candidate_corners >= MIN_SMALL_TARGET_CORNERS
                                and _small_target_patterns_allowed(
                                    candidate_patterns)
                                and base_score[1] <= 10.0
                                and base_score[2] <= 18.0
                            )
                        )
                    ):
                        should_try_secondary_gray = False
                if should_try_secondary_gray:
                    alt_cube_first = detect_corner_cube_faces(
                        secondary_gray, n_faces=n_faces, verbose=verbose)
                    alt_score = _score_cube_first_for_detection(alt_cube_first)
                    alt_allowed = True
                    alt_focal = None
                    if small_target_attempt and len(alt_cube_first) >= n_faces:
                        alt_normalized = _normalize_face_axis_order(
                            alt_cube_first or [])[:n_faces]
                        alt_focal = _vp_focal_estimate_for_cube_candidate(
                            alt_normalized, gray.shape, n_faces=n_faces)
                        if alt_focal is not None:
                            image_diag = float(np.hypot(
                                gray.shape[1], gray.shape[0]))
                            focal_lo = (
                                MIN_CONFIDENT_FOCAL_DIAG_MULT * image_diag
                            )
                            focal_hi = max(
                                MAX_CONFIDENT_FOCAL_DIAG_MULT,
                                SMALL_TARGET_MAX_FOCAL_DIAG_MULT,
                            ) * image_diag
                            fx_alt, fy_alt = alt_focal
                            alt_allowed = (
                                focal_lo <= fx_alt <= focal_hi
                                and focal_lo <= fy_alt <= focal_hi
                            )
                    if alt_allowed and alt_score[0] + 0.35 < base_score[0]:
                        cube_first = _normalize_face_axis_order(alt_cube_first)
                        if secondary_source == "direct":
                            warnings.append(
                                "Used direct grayscale decode as cube-first "
                                "detector fallback because it produced stronger "
                                "three-face geometry."
                            )
                        if verbose:
                            src_desc = (
                                "Direct-gray" if secondary_source == "direct"
                                else "Converted-gray"
                            )
                            print(
                                f"  {src_desc} cube-first fallback selected: "
                                f"score {base_score[0]:.2f} -> {alt_score[0]:.2f}, "
                                f"offset {base_score[1]:.2f} -> {alt_score[1]:.2f}px"
                            )
                    elif (
                        verbose
                        and not alt_allowed
                        and alt_focal is not None
                    ):
                        print(
                            "  Direct-gray cube-first fallback rejected: "
                            f"VP focal {alt_focal[0]:.1f}, {alt_focal[1]:.1f}px "
                            "outside small-target reliable range"
                        )
        except Exception as exc:
            warnings.append(f"Cube-first detector failed: {exc}")

    if len(cube_first) >= n_faces:
        face_patterns = [pat for _corners, pat, _label in cube_first[:n_faces]]
        if small_target_attempt:
            repaired_cube_first, repair_reason = (
                _try_small_target_pattern_repair(cube_first, gray.shape, n_faces)
            )
            if repaired_cube_first is not None:
                cube_first = repaired_cube_first
                face_patterns = [
                    pat for _corners, pat, _label in cube_first[:n_faces]
                ]
                warnings.append(repair_reason)
            raw_patterns = tuple(
                tuple(int(v) for v in pat)
                for pat in face_patterns[:n_faces]
            )
            raw_corners = sum(
                len(corners)
                for corners, _pat, _label in cube_first[:n_faces]
            )
            early_failures = []
            if not _small_target_patterns_allowed(raw_patterns):
                partial_ok = False
                pattern_deficit = None
                overcomplete_ok = False
                overcomplete_surplus = None
                if scale_prior_candidate_active:
                    partial_ok, pattern_deficit = (
                        _scale_prior_partial_template_prefilter_allowed(
                            raw_patterns,
                            raw_corners,
                        )
                    )
                    overcomplete_ok, overcomplete_surplus = (
                        _scale_prior_overcomplete_template_prefilter_allowed(
                            raw_patterns,
                            raw_corners,
                        )
                    )
                if partial_ok:
                    preflight.setdefault("scale_prior_candidate", {})[
                        "partial_template_prefilter"
                    ] = {
                        "patterns": [list(p) for p in raw_patterns],
                        "step_deficit": int(pattern_deficit or 0),
                        "n_corners": int(raw_corners),
                    }
                    warnings.append(
                        "Deferred scale-prior partial-template pattern "
                        f"candidate to the final quality gate ({raw_patterns}; "
                        f"deficit={pattern_deficit}, corners={raw_corners})."
                    )
                elif overcomplete_ok:
                    preflight.setdefault("scale_prior_candidate", {})[
                        "overcomplete_template_prefilter"
                    ] = {
                        "patterns": [list(p) for p in raw_patterns],
                        "small_face_surplus_steps": int(overcomplete_surplus or 0),
                        "n_corners": int(raw_corners),
                    }
                    warnings.append(
                        "Deferred scale-prior overcomplete small-face "
                        "candidate to the final fixed-focal quality gate "
                        f"({raw_patterns}; surplus={overcomplete_surplus}, "
                        f"corners={raw_corners})."
                    )
                else:
                    early_failures.append(
                        "visible grid pattern is "
                        f"{raw_patterns}; accepted small-target automatic calibration "
                        "currently requires "
                        f"{_small_target_pattern_gate_description()}"
                    )
            if raw_corners < MIN_SMALL_TARGET_CORNERS:
                early_failures.append(
                    f"only {raw_corners} corners; need at least "
                    f"{MIN_SMALL_TARGET_CORNERS}"
                )
            if early_failures:
                raise RuntimeError(
                    _small_target_boundary_message(
                        cube_area_pct,
                        "; ".join(early_failures),
                    )
                )
        if n_faces == 3:
            cube_first = _apply_cube_spatial_understanding(
                cube_first,
                (w_img, h_img),
                preflight,
                warnings,
                stage="cube_first",
                strict=STRICT_CUBE_SPATIAL_UNDERSTANDING,
            )
            face_patterns = [
                pat for _corners, pat, _label in cube_first[:n_faces]
            ]
        faces = standard_three_face_target(
            square_size_mm, pattern_cols, pattern_rows,
            face_patterns=face_patterns, n_faces=n_faces,
            center_patterns_on_cube=True,
        )
        vp_labels = get_vp_labels(n_faces)
        warnings.append("Used cube-first face detection (cube -> visible faces -> grids).")
        detector_raw_detections = list(cube_first[:n_faces])

        for fi, ((best_corners, pat, label), face) in enumerate(zip(cube_first, faces)):
            cols, rows = face.pattern_size
            blur_score = estimate_blur_level(gray, best_corners)
            win_w, win_h = adaptive_subpix_window(blur_score)
            corners_sub = _quality_gated_corner_subpix(
                gray, best_corners, pat, (win_w, win_h),
                (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-6),
            )
            if small_target_attempt:
                regularized, regularization_diagnostics = (
                    _homography_regularized_corner_candidate(
                        gray, best_corners, pat,
                    )
                )
            else:
                regularized, regularization_diagnostics = None, None
            if regularized is not None:
                corners_sub = regularized
                row = {
                    "face_index": int(fi),
                    "face_label": str(label),
                    "pattern": [int(pat[0]), int(pat[1])],
                    **regularization_diagnostics,
                }
                preflight.setdefault(
                    "homography_regularized_faces", []
                ).append(row)
                warnings.append(
                    f"Recovered inconsistent {label} checker lattice from "
                    "image-supported RANSAC homography "
                    f"({regularization_diagnostics['source']['homography_rmse_px']:.2f}"
                    "px -> "
                    f"{regularization_diagnostics['recovered']['homography_rmse_px']:.2f}"
                    "px)."
                )
            if _corner_grid_topology_stats(
                corners_sub, pat,
            )["spacing_collapsed"]:
                repaired, repair_diagnostics = _repair_collapsed_checker_points(
                    gray, corners_sub, pat,
                )
                if repaired is not None:
                    corners_sub = repaired
                    preflight.setdefault(
                        "locally_repaired_checker_faces", []
                    ).append({
                        "face_index": int(fi),
                        "face_label": str(label),
                        "pattern": [int(pat[0]), int(pat[1])],
                        **repair_diagnostics,
                    })
                    warnings.append(
                        f"Repaired duplicate {label} checker indices "
                        f"{repair_diagnostics['replaced_indices']} from local "
                        "image-supported projective geometry."
                    )
            final_topology = _corner_grid_topology_stats(corners_sub, pat)
            preflight.setdefault("checker_topology_faces", []).append({
                "face_index": int(fi),
                "face_label": str(label),
                "pattern": [int(pat[0]), int(pat[1])],
                **final_topology,
            })
            if final_topology["spacing_collapsed"]:
                raise RuntimeError(
                    f"Invalid {label} checker topology: duplicate or collapsed "
                    "grid points remained after local recovery. Refusing to "
                    "send non-physical correspondences into calibration."
                )
            obj_pts = object_points_for_face(face)
            detected_faces.append(DetectedFace(
                image_points=corners_sub, object_points=obj_pts, valid=True))
    elif cube_first:
        if (
            len(cube_first) == 1
            and not _has_trihedral_cube_layout_near_components(
                gray, n_faces=n_faces)
        ):
            _corners, pat, label = cube_first[0]
            raise RuntimeError(
                "Not cube target: only one planar checkerboard face was "
                f"found ({label}:{pat[0]}x{pat[1]}), and no trihedral "
                "three-face cube/cuboid layout could be recovered near it. "
                "Refusing planar Zhang fallback because this system is scoped "
                "to the single-frame three-visible-face cube target."
            )
        partial_pts = np.vstack([corners.reshape(-1, 2)
                                 for corners, _pat, _label in cube_first])
        partial_x_span = partial_pts[:, 0].max() - partial_pts[:, 0].min()
        partial_y_span = partial_pts[:, 1].max() - partial_pts[:, 1].min()
        partial_coverage = partial_x_span * partial_y_span / (w_img * h_img) * 100
        if _below_small_target_floor(cube_area_pct):
            raise RuntimeError(
                _range_boundary_message(
                    cube_area_pct,
                    "Keep this as the current area-ratio boundary.",
                )
            )
        if small_target_attempt:
            raise RuntimeError(
                _small_target_boundary_message(
                    cube_area_pct,
                    f"cube-first found only {len(cube_first)}/{n_faces} "
                    "visible faces.",
                )
            )
        if cube_area_pct is None and partial_coverage < 2.0:
            raise RuntimeError(
                f"Calibration target too small ({partial_coverage:.2f}% of image). "
                "Cube-first could not see all three faces; use this distance as "
                "the calibration boundary."
            )
        raise RuntimeError(
            f"Insufficient visible cube faces: cube-first found only "
            f"{len(cube_first)}/{n_faces}. Cube area is sufficient, so this "
            "image is outside the current reliable three-face calibration "
            "conditions rather than a small-target boundary. Refusing "
            "whole-image fallback because it can reuse the same checkerboard "
            "as multiple cube faces."
        )

    for fi, face in enumerate([] if detected_faces else faces):
        cols, rows = face.pattern_size
        best_corners, best_src = None, ""

        # Try precomputed corners first
        if precomputed is not None and fi < len(precomputed):
            pc = precomputed[fi]
            if pc is not None and len(pc) > 0:
                best_corners = pc.reshape(-1, 1, 2).astype(np.float32)
                best_src = (
                    "grid-extrapolated"
                    if precomputed_is_grid_extrapolated
                    else "enhanced"
                )
                if verbose:
                    print(f"  Face {fi}: loaded {len(best_corners)} precomputed corners")

        # Fall back to OpenCV detection
        detected_via_multiscale = False
        if best_corners is None:
            for src_name, src_img in images_to_try:
                ok, corners = cv2.findChessboardCorners(
                    src_img, (cols, rows),
                    flags=cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE,
                )
                if ok:
                    best_corners = corners
                    best_src = src_name
                    break

        # Multi-scale fallback for blurry faces
        if best_corners is None:
            ref_for_ms = gray_enhanced
            ms_corners = detect_corners_multiscale(ref_for_ms, (cols, rows))
            if ms_corners is not None:
                best_corners = ms_corners
                best_src = "enhanced"
                detected_via_multiscale = True

        if best_corners is None:
            detected_faces.append(DetectedFace(
                image_points=np.zeros((0, 1, 2)),
                object_points=np.zeros((0, 1, 3)), valid=False))
            warnings.append(f"Face {fi}: not detected")
            continue

        # ── Adaptive subpix window based on blur level ──
        if best_src == "grid-extrapolated":
            corners_sub = best_corners.astype(np.float32)
            blur_score = 0.0
            win_w, win_h = 0, 0
            refine_grid = os.environ.get(
                "CALIB_REFINE_GRID_EXTRAPOLATED_CORNERS", "1"
            ).strip().lower() in {"1", "true", "yes", "on"}
            if refine_grid:
                try:
                    win = int(float(os.environ.get(
                        "CALIB_GRID_EXTRAPOLATED_SUBPIX_WINDOW", "5")))
                except ValueError:
                    win = 5
                win = max(3, min(15, win))
                if win % 2 == 0:
                    win += 1
                try:
                    max_shift_px = float(os.environ.get(
                        "CALIB_GRID_EXTRAPOLATED_SUBPIX_MAX_SHIFT_PX", "3.5"))
                except ValueError:
                    max_shift_px = 3.5
                candidate = _quality_gated_corner_subpix(
                    gray_enhanced,
                    best_corners,
                    face.pattern_size,
                    (win, win),
                    (
                        cv2.TERM_CRITERIA_EPS
                        + cv2.TERM_CRITERIA_MAX_ITER,
                        40,
                        1e-4,
                    ),
                )
                shifts = np.linalg.norm(
                    candidate.reshape(-1, 2)
                    - best_corners.reshape(-1, 2),
                    axis=1,
                )
                if (
                    len(shifts)
                    and np.all(np.isfinite(shifts))
                    and float(np.percentile(shifts, 95)) <= max_shift_px
                ):
                    corners_sub = candidate.astype(np.float32)
                    win_w, win_h = win, win
        else:
            ref_img = gray_enhanced if best_src == "enhanced" else gray
            blur_score = estimate_blur_level(ref_img, best_corners)
            win_w, win_h = adaptive_subpix_window(blur_score)
            corners_sub = _quality_gated_corner_subpix(
                ref_img, best_corners, face.pattern_size, (win_w, win_h),
                (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-6),
            )
        if detected_via_multiscale and verbose:
            print(f"  Face {fi}: detected via multi-scale, "
                  f"blur={blur_score:.2f}, window={win_w}×{win_h}")
        obj_pts = object_points_for_face(face)
        detected_faces.append(DetectedFace(
            image_points=corners_sub, object_points=obj_pts, valid=True))

    # ── Compute per-point sharpness weights (blurry corners → lower weight) ──
    corner_weights = []
    for fi, df in enumerate(detected_faces):
        if not df.valid:
            continue
        w = compute_corner_sharpness(gray, df.image_points)
        corner_weights.append(w)

    valid_idx = [i for i, df in enumerate(detected_faces) if df.valid]
    n_valid = len(valid_idx)
    n_corners = sum(detected_faces[i].image_points.shape[0] for i in valid_idx)

    grid_recovery_corners = (
        precomputed_is_grid_extrapolated
        and os.environ.get(
            "CALIB_ALLOW_GRID_RECOVERY_BELOW_AREA_FLOOR", "0"
        ).strip().lower() in {"1", "true", "yes", "on"}
    )
    if _below_small_target_floor(cube_area_pct) and not grid_recovery_corners:
        raise RuntimeError(
            _range_boundary_message(
                cube_area_pct,
                "Keep this image as the current area-ratio boundary rather "
                "than an accepted calibration.",
            )
        )
    if _below_small_target_floor(cube_area_pct) and grid_recovery_corners:
        warnings.append(
            "Grid-recovered three-face corners bypassed the default area-floor "
            "preflight for an explicit boundary-research run; this is outside "
            "the >=2% automatic-calibration method scope and final acceptance "
            "still depends on geometric quality gates."
        )

    if n_valid < 1:
        if cube_area_pct is not None and cube_area_pct >= MIN_RELIABLE_CUBE_AREA_PCT:
            raise RuntimeError(
                "No calibration target detected: no usable checkerboard face "
                f"was detected although dark-component cube-area evidence is "
                f"{cube_area_pct:.2f}% of the image. Treat the area estimate "
                "as possible false cube evidence or severe occlusion rather "
                "than an accepted three-face calibration."
            )
        raise RuntimeError(
            "No calibration target detected: no usable cube face and no "
            "reliable cube-area estimate were found in the image."
        )

    sparse_faces = []
    sparse_face_dims = []
    for i in valid_idx:
        cols, rows = faces[i].pattern_size
        if min(cols, rows) < MIN_RELIABLE_FACE_INNER_DIM:
            sparse_faces.append(f"face {i}:{cols}x{rows}")
            sparse_face_dims.append((i, cols, rows))
    sparse_recovery_mode = False
    sparse_recovery_boundary_msg = ""
    if sparse_faces:
        detail = ", ".join(sparse_faces)
        sparse_recovery_boundary_msg = (
            "Partial-face geometry boundary: at least one visible face "
            f"contains only a sparse local checkerboard ({detail}). "
            f"Require at least {MIN_RELIABLE_FACE_INNER_DIM} inner corners "
            "in both directions on every used face for reliable single-image "
            "three-face calibration from square size alone."
        )
        can_try_sparse_recovery = (
            len(sparse_face_dims) <= MAX_SPARSE_RECOVERY_FACES
            and all(
                min(cols, rows) >= MIN_SPARSE_RECOVERY_FACE_INNER_DIM
                for _i, cols, rows in sparse_face_dims
            )
        )
        if not can_try_sparse_recovery:
            raise RuntimeError(sparse_recovery_boundary_msg)
        sparse_recovery_mode = True
        warnings.append(
            "Attempting sparse single-face recovery; final calibration must "
            "pass the normal reliability gates or remain a partial-face "
            "geometry boundary."
        )

    def _points_bbox(points):
        pts = points.reshape(-1, 2)
        return (
            float(pts[:, 0].min()), float(pts[:, 1].min()),
            float(pts[:, 0].max()), float(pts[:, 1].max()),
        )

    def _bbox_overlap_ratio(a, b):
        ax1, ay1, ax2, ay2 = a
        bx1, by1, bx2, by2 = b
        ix1, iy1 = max(ax1, bx1), max(ay1, by1)
        ix2, iy2 = min(ax2, bx2), min(ay2, by2)
        if ix2 <= ix1 or iy2 <= iy1:
            return 0.0
        inter = (ix2 - ix1) * (iy2 - iy1)
        area_a = max((ax2 - ax1) * (ay2 - ay1), 1e-6)
        area_b = max((bx2 - bx1) * (by2 - by1), 1e-6)
        return float(inter / min(area_a, area_b))

    face_boxes = [_points_bbox(detected_faces[i].image_points) for i in valid_idx]
    for ai in range(len(face_boxes)):
        for bi in range(ai + 1, len(face_boxes)):
            overlap = _bbox_overlap_ratio(face_boxes[ai], face_boxes[bi])
            if overlap > 0.65:
                raise RuntimeError(
                    f"Detected face ROIs overlap too much ({overlap:.2f}); "
                    "refusing a likely duplicate-face calibration."
                )

    # Compute FOV coverage from detected corners
    all_pts = np.vstack([detected_faces[i].image_points.reshape(-1, 2)
                         for i in valid_idx])
    x_span = all_pts[:, 0].max() - all_pts[:, 0].min()
    y_span = all_pts[:, 1].max() - all_pts[:, 1].min()
    fov_coverage = x_span * y_span / (w_img * h_img) * 100

    warn_target_coverage_pct = 4.0
    if cube_area_pct is None and fov_coverage < 2.0:
        raise RuntimeError(
            f"Calibration target too small ({fov_coverage:.2f}% of image). "
            "Could not estimate cube area; move the camera closer or use this "
            "image as the calibration boundary."
        )
    if small_target_attempt:
        early_failures = []
        if n_valid < n_faces:
            early_failures.append(f"only {n_valid}/{n_faces} faces survived")
        if (
            not DISABLE_AREA_RATIO_GATES
            and (
            cube_area_pct is None
            or cube_area_pct < SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT
            or cube_area_pct > SMALL_TARGET_VALIDATED_ACCEPT_MAX_AREA_PCT
            )
        ):
            area_text = (
                "unknown"
                if cube_area_pct is None
                else f"{cube_area_pct:.2f}%"
            )
            early_failures.append(
                f"cube area {area_text} is outside the current "
                "validated accepted small-target pocket "
                f"{SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT:.2f}-"
                f"{SMALL_TARGET_VALIDATED_ACCEPT_MAX_AREA_PCT:.2f}%"
            )
        if fov_coverage > SMALL_TARGET_EXTENDED_MAX_FOV_COVERAGE_PCT:
            early_failures.append(
                f"corner coverage {fov_coverage:.2f}% exceeds the current "
                "extended small-target coverage probe pocket "
                f"({SMALL_TARGET_EXTENDED_MAX_FOV_COVERAGE_PCT:.2f}% max)"
            )
        observed_patterns = tuple(
            tuple(int(v) for v in faces[i].pattern_size)
            for i in valid_idx[:n_faces]
        )
        if not _small_target_patterns_allowed(observed_patterns):
            partial_ok = False
            pattern_deficit = None
            overcomplete_ok = False
            overcomplete_surplus = None
            trihedral_closure_ok = False
            if scale_prior_candidate_active:
                partial_ok, pattern_deficit = (
                    _scale_prior_partial_template_prefilter_allowed(
                        observed_patterns,
                        n_corners,
                    )
                )
                overcomplete_ok, overcomplete_surplus = (
                    _scale_prior_overcomplete_template_prefilter_allowed(
                        observed_patterns,
                        n_corners,
                    )
                )
                trihedral_closure_ok = (
                    _scale_prior_trihedral_closure_prefilter_allowed(
                        observed_patterns,
                        n_corners,
                        trihedral_closure_source=precomputed_is_trihedral_closure,
                    )
                )
            if partial_ok:
                preflight.setdefault("scale_prior_candidate", {})[
                    "partial_template_prefilter"
                ] = {
                    "patterns": [list(p) for p in observed_patterns],
                    "step_deficit": int(pattern_deficit or 0),
                    "n_corners": int(n_corners),
                }
                warnings.append(
                    "Deferred scale-prior partial-template pattern candidate "
                    f"to the final quality gate ({observed_patterns}; "
                    f"deficit={pattern_deficit}, corners={n_corners})."
                )
            elif overcomplete_ok:
                preflight.setdefault("scale_prior_candidate", {})[
                    "overcomplete_template_prefilter"
                ] = {
                    "patterns": [list(p) for p in observed_patterns],
                    "small_face_surplus_steps": int(overcomplete_surplus or 0),
                    "n_corners": int(n_corners),
                }
                warnings.append(
                    "Deferred scale-prior overcomplete small-face candidate "
                    "to the final fixed-focal quality gate "
                    f"({observed_patterns}; surplus={overcomplete_surplus}, "
                    f"corners={n_corners})."
                )
            elif trihedral_closure_ok:
                preflight.setdefault("scale_prior_candidate", {})[
                    "trihedral_closure_template_prefilter"
                ] = {
                    "patterns": [list(p) for p in observed_patterns],
                    "allowed_patterns": [
                        list(p) for p in sorted(SCALE_PRIOR_TRIHEDRAL_CLOSURE_PATTERNS)
                    ],
                    "n_corners": int(n_corners),
                    "source": precomputed_basename,
                }
                warnings.append(
                    "Deferred scale-prior trihedral-closure template candidate "
                    f"to the final quality gate ({observed_patterns}; "
                    f"corners={n_corners})."
                )
            else:
                early_failures.append(
                    "visible grid pattern is "
                    f"{observed_patterns}; accepted small-target automatic calibration "
                    "currently requires "
                    f"{_small_target_pattern_gate_description()}"
                )
        if n_corners < MIN_SMALL_TARGET_CORNERS:
            early_failures.append(
                f"only {n_corners} corners; need at least "
                f"{MIN_SMALL_TARGET_CORNERS}"
            )
        if early_failures:
            raise RuntimeError(
                _small_target_boundary_message(
                    cube_area_pct,
                    "; ".join(early_failures),
                )
            )
    if fov_coverage < warn_target_coverage_pct:
        warnings.append(
            f"Target coverage is only {fov_coverage:.2f}% of image; "
            f"{warn_target_coverage_pct:.1f}%+ is recommended for stable calibration."
        )

    if False and fov_coverage < 40:
        warnings.append(f"FOV coverage only {fov_coverage:.0f}% — "
                        f"recommend ≥50% (move camera closer)")

    # Primary one-frame physical calibration.  The existing detection and
    # recovery stages supply three checker grids; the three metric planes then
    # provide six Zhang IAC constraints for all five intrinsic parameters.
    homography_regularized_count = len(
        preflight.get("homography_regularized_faces", [])
    )
    zhang_shared_axis_weight = (
        _env_float("CALIB_SMALL_TARGET_SHARED_AXIS_WEIGHT", 0.16)
        if small_target_attempt
        else _env_float("CALIB_NORMAL_SHARED_AXIS_WEIGHT", 0.04)
    )
    preflight["shared_axis_constraint"] = {
        "weight": float(zhang_shared_axis_weight),
        "homography_regularized_face_count": int(
            homography_regularized_count
        ),
        "early_vp_refinement_seed_guard": bool(GUARD_EARLY_VP_ZHANG_SEED),
    }
    zhang_refinement_K_seeds = []
    if (
        ENABLE_EARLY_VP_ZHANG_SEED
        and n_valid >= 3
        and len(detected_faces) >= 3
    ):
        try:
            vp_seed_detections = [
                (
                    detected_faces[i].image_points,
                    faces[i].pattern_size,
                    str(i),
                )
                for i in valid_idx[:3]
            ]
            vp_focal_pair = _vp_focal_estimate_for_cube_candidate(
                vp_seed_detections,
                (h_img, w_img),
                n_faces=3,
            )
            if vp_focal_pair is not None:
                image_diag_for_vp = float(np.hypot(w_img, h_img))
                fx_seed, fy_seed = (float(vp_focal_pair[0]), float(vp_focal_pair[1]))
                if (
                    np.isfinite(fx_seed)
                    and np.isfinite(fy_seed)
                    and 0.10 * image_diag_for_vp <= fx_seed <= 10.0 * image_diag_for_vp
                    and 0.10 * image_diag_for_vp <= fy_seed <= 10.0 * image_diag_for_vp
                ):
                    zhang_refinement_K_seeds.append(np.array([
                        [fx_seed, 0.0, w_img / 2.0],
                        [0.0, fy_seed, h_img / 2.0],
                        [0.0, 0.0, 1.0],
                    ], dtype=np.float64))
                    preflight["shared_axis_constraint"][
                        "early_vp_refinement_seed"
                    ] = {
                        "enabled": True,
                        "accepted": True,
                        "fx_px": fx_seed,
                        "fy_px": fy_seed,
                        "source": "checker_row_col_vanishing_points",
                    }
                else:
                    preflight["shared_axis_constraint"][
                        "early_vp_refinement_seed"
                    ] = {
                        "enabled": True,
                        "accepted": False,
                        "reason": "vp focal outside camera-like bounds",
                        "fx_px": fx_seed,
                        "fy_px": fy_seed,
                    }
        except Exception as exc:
            preflight["shared_axis_constraint"][
                "early_vp_refinement_seed"
            ] = {
                "enabled": True,
                "accepted": False,
                "reason": str(exc),
            }
    cube_zhang_candidate = None
    cube_zhang_error = None
    zhang_homography_points = None
    if precomputed is not None and len(precomputed) >= 3:
        raw_homography_points = [
            np.asarray(precomputed[i]).reshape(-1, 2)
            for i in range(3)
        ]
        if all(
            len(raw_homography_points[i])
                == detected_faces[valid_idx[i]].image_points.shape[0]
                for i in range(3)
        ):
            zhang_homography_points = raw_homography_points
    scale_prior_skip_initial_zhang = bool(
        ENABLE_SCALE_PRIOR_FAST_FIXED_FOCAL
        and scale_prior_candidate_active
        and small_target_attempt
        and focal_px is not None
        and cube_area_pct is not None
        and cube_area_pct <= SCALE_PRIOR_FAST_FIXED_FOCAL_MAX_AREA_PCT
    )
    if scale_prior_skip_initial_zhang:
        preflight["single_cube_zhang"] = {
            "success": False,
            "skipped": True,
            "reason": (
                "scale-prior fast fixed-focal precomputed/grid candidate "
                f"below {SCALE_PRIOR_FAST_FIXED_FOCAL_MAX_AREA_PCT:.2f}% "
                "cube area; initial Zhang full-parameter diagnostic was "
                "skipped before fixed-focal quality gates"
            ),
        }
    if (
        not scale_prior_skip_initial_zhang
        and n_valid == 3
        and len(detected_faces) >= 3
    ):
        try:
            cube_zhang_candidate = calibrate_single_cube_zhang(
                [detected_faces[i] for i in valid_idx[:3]],
                image_size=(w_img, h_img),
                square_size=square_size_mm,
                face_definitions=[faces[i] for i in valid_idx[:3]],
                allow_face_permutations=False,
                refinement_K_seeds=zhang_refinement_K_seeds or None,
                guard_refinement_K_seeds=bool(
                    zhang_refinement_K_seeds and GUARD_EARLY_VP_ZHANG_SEED
                ),
                homography_image_points=zhang_homography_points,
                shared_axis_weight=zhang_shared_axis_weight,
            )
            preflight["single_cube_zhang"] = {
                "success": bool(cube_zhang_candidate.success),
                "linear_K": cube_zhang_candidate.linear_K.tolist(),
                "reproj_rmse": float(cube_zhang_candidate.reproj_rmse),
                "face_assignment": cube_zhang_candidate.face_assignment,
                "face_orientations": cube_zhang_candidate.face_orientations,
                "diagnostics": cube_zhang_candidate.diagnostics,
            }
        except Exception as exc:
            cube_zhang_error = str(exc)
            preflight["single_cube_zhang"] = {
                "success": False,
                "error": cube_zhang_error,
            }

    # ── Step 2: Vanishing points ──
    vp_per_face = []
    face_qualities = []
    for fi, df in enumerate(detected_faces):
        if not df.valid:
            vp_per_face.append({}); continue
        face = faces[fi]; cols, rows = face.pattern_size
        rl, cl, rq, cq = lines_from_chessboard_corners(
            df.image_points, (cols, rows), use_ransac=True)
        # rl are lines along the chessboard column index (face.axis_x);
        # cl are lines along the row index (face.axis_y).
        vpx = estimate_vanishing_point(np.array(rl))
        vpy = estimate_vanishing_point(np.array(cl))
        vpx.direction_label = vp_labels[fi][0]
        vpy.direction_label = vp_labels[fi][1]
        vp_per_face.append({vp_labels[fi][0]: vpx, vp_labels[fi][1]: vpy})
        face_qualities.append(max(rq, cq))

    corner_quality = np.mean(face_qualities) if face_qualities else float('inf')
    if (not np.isfinite(corner_quality)) or any(
        (not np.isfinite(q)) or q > 5.0 for q in face_qualities
    ):
        detail = ", ".join(
            "inf" if not np.isfinite(q) else f"{q:.2f}"
            for q in face_qualities
        )
        raise RuntimeError(
            f"Face line-fit quality failed ({detail}); "
            "the detected grids are not geometrically reliable."
        )
    if corner_quality > 1.0:
        warnings.append(f"Line-fit quality {corner_quality:.2f}px (>1.0) — "
                        f"check focus/lighting")

    vp_avg = {}
    for label in ["X", "Y", "Z"]:
        V = np.array([vp.v for fv in vp_per_face
                      for l, vp in fv.items() if l == label])
        if len(V) == 0: continue
        vm = np.median(V, axis=0)
        if abs(vm[2]) > 1e-6: vm /= vm[2]
        vp_avg[label] = VanishingPoint(v=vm, direction_label=label)

    # ── Step 3: IAC (BEFORE distortion estimation — critical fix) ──
    lo = sorted(vp_avg.keys()); vpl = [vp_avg[l] for l in lo]
    ali = {l: i for i, l in enumerate(lo)}
    op = [(ali[a], ali[b]) for a, b in [("X","Y"),("Y","Z"),("Z","X")]
          if a in ali and b in ali]

    K_init = calibrate_intrinsics_from_vps(
        vpl, op, assume_zero_skew=True, assume_square_pixels=True,
        fix_principal_point=(w_img / 2, h_img / 2),
    )

    # ── Step 4: Distortion estimation (uses K_init from IAC) ──
    dist_est = estimate_distortion_from_lines(
        detected_faces, faces, K_init, verbose=False,
    )

    pnp_rmse_before_ba = None
    if auto_orient_faces:
        K_orientation = K_init
        orientation_source = "VP focal"
        if focal_px is not None and np.isfinite(focal_px) and focal_px > 0:
            K_orientation = np.array([
                [float(focal_px), 0.0, w_img / 2.0],
                [0.0, float(focal_px), h_img / 2.0],
                [0.0, 0.0, 1.0],
            ], dtype=np.float64)
            orientation_source = "fixed focal"
        orientations = apply_best_face_orientations(
            detected_faces, faces, valid_idx, K_orientation, None,
        )
        if orientations:
            pnp_rmse_before_ba = float(orientations[0]["rmse"])
        flipped = [o for o in orientations if o["flip_x"] or o["flip_y"]]
        if flipped:
            desc = ", ".join(
                f"face {o['face']}:"
                f"{'x' if o['flip_x'] else ''}{'y' if o['flip_y'] else ''}"
                for o in flipped
            )
            warnings.append(
                f"Auto-selected physical grid orientation ({desc}); "
                f"PnP RMSE {orientations[0]['rmse']:.2f}px before BA "
                f"using {orientation_source}."
            )

    # Detect lens type from initial k1 estimate
    k1_abs = abs(dist_est[0])
    if not k1_only:
        # Auto-detect: if k1 is small, suggest k1-only
        if k1_abs < 0.15 and not k1_only:
            warnings.append(f"Low distortion detected (k1≈{k1_abs:.3f}) — "
                            f"k1-only model may be more robust")
        suggested_model = 'k1-only' if k1_abs < 0.15 else '5-param'
    else:
        suggested_model = 'k1-only'

    # ── Step 5: PnP ──
    all_obj = np.vstack([detected_faces[i].object_points for i in valid_idx])
    all_img = np.vstack([detected_faces[i].image_points for i in valid_idx])
    all_weights = np.concatenate(corner_weights) if corner_weights else None
    R_init, t_init = calibrate_extrinsics(all_obj, all_img, K_init)

    # ── Step 6: BA (with optional external constraints) ──
    obj_f = all_obj.reshape(-1, 3).astype(np.float64)
    img_f = all_img.reshape(-1, 2).astype(np.float64)
    N = len(img_f)
    rvec_i = cv2.Rodrigues(R_init)[0].ravel()

    if k1_only:
        # ── k1-only BA ──
        model_used = 'k1-only'

        def residuals(params):
            fx, fy, cx, cy, k1 = params[:5]
            rx, ry, rz = params[5:8]
            tx, ty, tz = params[8:11]
            Kc = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1.]])
            Rc, _ = cv2.Rodrigues(np.array([rx, ry, rz]))
            tc = np.array([tx, ty, tz])
            Xc = (Rc @ obj_f.T + tc.reshape(3, 1)).T
            xn = Xc[:, :2] / Xc[:, 2:3]
            r2 = np.sum(xn ** 2, axis=1)
            rad = 1 + k1 * r2
            xd = xn[:, 0] * rad; yd = xn[:, 1] * rad
            u = fx * xd + cx; v = fy * yd + cy
            res = np.hstack([u - img_f[:, 0], v - img_f[:, 1]])
            if all_weights is not None:
                res[:N] *= all_weights
                res[N:] *= all_weights
            # External constraints
            extra = []
            if focal_px is not None:
                extra.append(np.sqrt(N) * 0.01 * (fx - focal_px))
            if extra:
                res = np.concatenate([res, extra])
            return res

        x0 = np.array([
            K_init[0, 0], K_init[1, 1], K_init[0, 2], K_init[1, 2], dist_est[0],
            rvec_i[0], rvec_i[1], rvec_i[2],
            t_init[0], t_init[1], t_init[2],
        ])
        result_ls = least_squares(residuals, x0, method='lm',
                                  xtol=1e-12, ftol=1e-12)
        fx, fy, cx, cy, k1 = result_ls.x[:5]
        R_opt, _ = cv2.Rodrigues(result_ls.x[5:8])
        t_opt = result_ls.x[8:11]
        K_opt = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1.]])
        dist_opt = np.array([k1, 0., 0., 0., 0.])
        rmse = np.sqrt(np.mean(residuals(result_ls.x)[:2 * N] ** 2))

    else:
        # ── 5-param BA ──
        model_used = '5-param'

        def residuals_5p(params):
            fx, fy, cx, cy = params[:4]
            k1, k2, k3, p1, p2 = params[4:9]
            rx, ry, rz = params[9:12]
            tx, ty, tz = params[12:15]
            Kc = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1.]])
            Rc, _ = cv2.Rodrigues(np.array([rx, ry, rz]))
            tc = np.array([tx, ty, tz])
            Xc = (Rc @ obj_f.T + tc.reshape(3, 1)).T
            xn = Xc[:, :2] / Xc[:, 2:3]
            r2 = np.sum(xn ** 2, axis=1); r4 = r2 ** 2; r6 = r2 ** 3
            rad = 1 + k1 * r2 + k2 * r4 + k3 * r6
            xd = xn[:, 0] * rad + 2 * p1 * xn[:, 0] * xn[:, 1] \
                 + p2 * (r2 + 2 * xn[:, 0] ** 2)
            yd = xn[:, 1] * rad + p1 * (r2 + 2 * xn[:, 1] ** 2) \
                 + 2 * p2 * xn[:, 0] * xn[:, 1]
            u = fx * xd + cx; v = fy * yd + cy
            res = np.hstack([u - img_f[:, 0], v - img_f[:, 1]])
            if all_weights is not None:
                res[:N] *= all_weights
                res[N:] *= all_weights
            # k2 regularisation + external constraints
            extra = []
            extra.append(0.05 * (k2 / max(abs(k1), 1e-6)))
            if focal_px is not None:
                extra.append(np.sqrt(N) * 0.01 * (fx - focal_px))
            if extra:
                res = np.concatenate([res, extra])
            return res

        x0 = np.array([
            K_init[0, 0], K_init[1, 1], K_init[0, 2], K_init[1, 2],
            dist_est[0], dist_est[1], dist_est[2], dist_est[3], dist_est[4],
            rvec_i[0], rvec_i[1], rvec_i[2],
            t_init[0], t_init[1], t_init[2],
        ])
        result_ls = least_squares(residuals_5p, x0, method='lm',
                                  xtol=1e-12, ftol=1e-12, max_nfev=2000)
        fx, fy, cx, cy = result_ls.x[:4]
        k1, k2, k3, p1, p2 = result_ls.x[4:9]
        R_opt, _ = cv2.Rodrigues(result_ls.x[9:12])
        t_opt = result_ls.x[12:15]
        K_opt = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1.]])
        dist_opt = np.array([k1, k2, p1, p2, k3])
        rmse = np.sqrt(np.mean(residuals_5p(result_ls.x)[:2 * N] ** 2))

    if cube_zhang_error:
        warnings.append(
            "Three-plane Zhang candidate was unavailable; retained the "
            f"validated legacy solver cascade ({cube_zhang_error})."
        )

    # ── Derived parameters ──
    def _projection_rmse(K, dist, R, t):
        proj, _ = cv2.projectPoints(
            all_obj.reshape(-1, 1, 3).astype(np.float64),
            cv2.Rodrigues(R)[0], t, K, dist,
        )
        diff = proj.reshape(-1, 2) - all_img.reshape(-1, 2)
        return float(np.sqrt(np.mean(np.sum(diff * diff, axis=1))))

    def _ba_result_is_sane(K, err):
        fx_s, fy_s = float(K[0, 0]), float(K[1, 1])
        cx_s, cy_s = float(K[0, 2]), float(K[1, 2])
        if not np.all(np.isfinite(K)) or not np.isfinite(err):
            return False
        if fx_s <= 0 or fy_s <= 0:
            return False
        aspect_limit = 2.5 if model_used.startswith('single-cube-zhang') else 1.15
        if max(fx_s, fy_s) / max(min(fx_s, fy_s), 1e-6) > aspect_limit:
            return False
        if cx_s < -0.25 * w_img or cx_s > 1.25 * w_img:
            return False
        if cy_s < -0.25 * h_img or cy_s > 1.25 * h_img:
            return False
        if err > 5.0:
            return False
        return True

    if not _ba_result_is_sane(K_opt, rmse):
        warnings.append(
            "Bundle adjustment was rejected by the physical sanity gate; "
            "using VP-only intrinsics. Extrinsics/height remain approximate; "
            "target layout is inferred from checkerboard square size only."
        )
        model_used = 'vp-only'
        K_opt = K_init.copy()
        dist_opt = np.zeros(5, dtype=np.float64)
        R_opt = R_init.copy()
        t_opt = t_init.copy()
        rmse = _projection_rmse(K_opt, dist_opt, R_opt, t_opt)

    fx, fy = float(K_opt[0, 0]), float(K_opt[1, 1])
    cx, cy = float(K_opt[0, 2]), float(K_opt[1, 2])

    image_diag = float(np.hypot(w_img, h_img))
    focal_hi_limit = MAX_CONFIDENT_FOCAL_DIAG_MULT * image_diag
    focal_lo_limit = MIN_CONFIDENT_FOCAL_DIAG_MULT * image_diag
    principal_dx = abs(cx - w_img / 2.0)
    principal_dy = abs(cy - h_img / 2.0)
    quality_fails = (
        (not np.isfinite(fx)) or (not np.isfinite(fy))
        or max(fx, fy) > focal_hi_limit
        or min(fx, fy) < focal_lo_limit
        or principal_dx > MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC * w_img
        or principal_dy > MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC * h_img
        or (not np.isfinite(rmse))
        or rmse > MAX_CONFIDENT_RMSE_PX
        or (not np.isfinite(dist_opt[0]))
        or abs(float(dist_opt[0])) > MAX_CONFIDENT_K1_ABS
        or model_used == 'vp-only'
    )
    if not _model_grade_isolation_allows(model_used, "initial_ba_candidate"):
        quality_fails = True
        warnings.append(
            "Model-grade isolation skipped the initial BA candidate "
            f"({model_used})."
        )
    if quality_fails and n_valid >= 3 and focal_px is not None:
        fallback = _fixed_focal_k1_pose_fallback(
            all_obj.reshape(-1, 3),
            all_img.reshape(-1, 2),
            (w_img, h_img),
            focal_px,
            k1_seed=dist_est[0],
            k1_prior=k1_prior,
            rmse_limit=MAX_CONFIDENT_FIXED_FOCAL_RMSE_PX,
        )
        fixed_focal_zero_dist = False
        if fallback is None and k1_prior is None:
            fallback = _fixed_focal_k1_pose_fallback(
                all_obj.reshape(-1, 3),
                all_img.reshape(-1, 2),
                (w_img, h_img),
                focal_px,
                k1_seed=0.0,
                k1_prior=0.0,
                rmse_limit=MAX_CONFIDENT_FIXED_FOCAL_RMSE_PX,
            )
            fixed_focal_zero_dist = fallback is not None
        if fallback is not None:
            if k1_prior is not None:
                fallback_model_used = 'fixed-intrinsics'
            elif fixed_focal_zero_dist:
                fallback_model_used = 'fixed-focal-zero-dist'
            else:
                fallback_model_used = 'fixed-focal-k1'
            if not _model_grade_isolation_allows(
                fallback_model_used, "fixed_focal_pose_fallback"
            ):
                fallback = None
                warnings.append(
                    "Model-grade isolation skipped the fixed-focal pose "
                    f"fallback ({fallback_model_used})."
                )
            else:
                K_opt, dist_opt, R_opt, t_opt, rmse = fallback
                model_used = fallback_model_used
        if fallback is not None:
            warnings[:] = [
                w for w in warnings
                if not w.startswith("Bundle adjustment was rejected")
            ]
            warnings.append(
                "Used fixed-prior pose fallback "
                "(external/group focal prior, centered principal point)."
            )
            fx, fy = float(K_opt[0, 0]), float(K_opt[1, 1])
            cx, cy = float(K_opt[0, 2]), float(K_opt[1, 2])
            principal_dx = abs(cx - w_img / 2.0)
            principal_dy = abs(cy - h_img / 2.0)
            quality_fails = (
                (not np.isfinite(fx)) or (not np.isfinite(fy))
                or max(fx, fy) > focal_hi_limit
                or min(fx, fy) < focal_lo_limit
                or principal_dx > MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC * w_img
                or principal_dy > MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC * h_img
                or (not np.isfinite(rmse))
                or rmse > MAX_CONFIDENT_FIXED_FOCAL_RMSE_PX
                or (not np.isfinite(dist_opt[0]))
                or abs(float(dist_opt[0])) > MAX_CONFIDENT_K1_ABS
            )
    if quality_fails and n_valid >= 3:
        fallback = _single_view_k1_fallback(
            all_obj.reshape(-1, 3),
            all_img.reshape(-1, 2),
            (w_img, h_img),
            K_init,
            focal_lo_limit,
            focal_hi_limit,
            MAX_CONFIDENT_RMSE_PX,
        )
        if (
            fallback is not None
            and not _model_grade_isolation_allows(
                "single-view-k1", "single_view_k1_fallback"
            )
        ):
            fallback = None
            warnings.append(
                "Model-grade isolation skipped the single-view k1 fallback."
            )
        if fallback is not None:
            K_opt, dist_opt, R_opt, t_opt, rmse = fallback
            model_used = 'single-view-k1'
            warnings.append(
                "Used conservative single-view 3D fallback "
                "(fixed principal point, square pixels, k1 only)."
            )
            fx, fy = float(K_opt[0, 0]), float(K_opt[1, 1])
            cx, cy = float(K_opt[0, 2]), float(K_opt[1, 2])
        else:
            fallback = _single_view_zero_dist_fallback(
                all_obj.reshape(-1, 3),
                all_img.reshape(-1, 2),
                (w_img, h_img),
                K_init,
                focal_lo_limit,
                focal_hi_limit,
                MAX_CONFIDENT_RMSE_PX,
            )
            if (
                fallback is not None
                and not _model_grade_isolation_allows(
                    "single-view-zero-dist", "single_view_zero_dist_fallback"
                )
            ):
                fallback = None
                warnings.append(
                    "Model-grade isolation skipped the single-view zero-dist "
                    "fallback."
                )
            if fallback is not None:
                K_opt, dist_opt, R_opt, t_opt, rmse = fallback
                model_used = 'single-view-zero-dist'
                warnings.append(
                    "Used conservative single-view 3D fallback "
                    "(fixed principal point, square pixels, zero distortion)."
                )
                fx, fy = float(K_opt[0, 0]), float(K_opt[1, 1])
                cx, cy = float(K_opt[0, 2]), float(K_opt[1, 2])

    offset_quality_fails = (
        (not np.isfinite(fx)) or (not np.isfinite(fy))
        or max(fx, fy) > focal_hi_limit
        or min(fx, fy) < focal_lo_limit
        or abs(cx - w_img / 2.0) > MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC * w_img
        or abs(cy - h_img / 2.0) > MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC * h_img
        or (not np.isfinite(rmse))
        or rmse > MAX_CONFIDENT_RMSE_PX
        or (not np.isfinite(dist_opt[0]))
        or abs(float(dist_opt[0])) > MAX_CONFIDENT_K1_ABS
        or model_used == 'vp-only'
    )
    scale_prior_fast_fixed_focal_candidate = bool(
        ENABLE_SCALE_PRIOR_FAST_FIXED_FOCAL
        and scale_prior_candidate_active
        and small_target_attempt
        and focal_px is not None
        and cube_area_pct is not None
        and cube_area_pct <= SCALE_PRIOR_FAST_FIXED_FOCAL_MAX_AREA_PCT
        and str(model_used) in {
            "fixed-focal-k1",
            "fixed-focal-zero-dist",
            "fixed-intrinsics",
            "single-view-wide-offset-fixed-focal-k1",
            "single-view-wide-offset-fixed-focal-zero-dist",
        }
        and np.isfinite(rmse)
        and float(rmse) <= MAX_CONFIDENT_FIXED_FOCAL_RMSE_PX
    )
    offset_search_needed = (
        not research_skip_offset_search
        and not scale_prior_fast_fixed_focal_candidate
        and
        n_valid == 3
        and len(detected_faces) >= 3
        and (
            small_target_attempt
            or offset_quality_fails
            or (
                model_used in {
                    'single-view-k1',
                    'single-view-zero-dist',
                    'fixed-focal-k1',
                    'fixed-focal-zero-dist',
                    'fixed-intrinsics',
                }
                and pnp_rmse_before_ba is not None
                and pnp_rmse_before_ba > SINGLE_VIEW_OFFSET_SEARCH_PNP_TRIGGER_PX
            )
        )
    )
    preflight["offset_search"] = {
        "needed": bool(offset_search_needed),
        "research_skipped": bool(research_skip_offset_search),
        "scale_prior_fast_fixed_focal_skipped": bool(
            scale_prior_fast_fixed_focal_candidate
        ),
        "quality_failed": bool(offset_quality_fails),
    }
    K_offset_seed = K_init
    if focal_px is not None and np.isfinite(focal_px) and focal_px > 0:
        K_offset_seed = np.array([
            [float(focal_px), 0.0, w_img / 2.0],
            [0.0, float(focal_px), h_img / 2.0],
            [0.0, 0.0, 1.0],
        ], dtype=np.float64)
    if os.environ.get("CALIB_DEBUG_OFFSET_GATE") == "1":
        print(
            "  Offset gate: "
            f"needed={bool(offset_search_needed)}, "
            f"model={model_used}, n_valid={n_valid}, "
            f"detected={len(detected_faces)}, rmse={float(rmse):.2f}, "
            f"pnp={pnp_rmse_before_ba}, "
            f"quality_fails={bool(offset_quality_fails)}"
        )
    if offset_search_needed:
        pre_offset_reprojection_rmse = float(rmse)
        image_points_by_face = [
            detected_faces[i].image_points.reshape(-1, 1, 2).astype(np.float32)
            for i in valid_idx[:3]
        ]
        patterns_for_offset = [faces[i].pattern_size for i in valid_idx[:3]]
        offset_fallback = None
        fixed_offset_fallback = None
        if focal_px is not None and np.isfinite(focal_px) and focal_px > 0:
            fixed_offset_fallback = _single_view_wide_offset_fixed_focal_fallback(
                image_points_by_face,
                patterns_for_offset,
                (w_img, h_img),
                square_size_mm,
                K_offset_seed,
                pnp_rmse_limit=MAX_CONFIDENT_INITIAL_PNP_RMSE_PX,
                rmse_limit=MAX_CONFIDENT_FIXED_FOCAL_RMSE_PX,
            )
            offset_fallback = fixed_offset_fallback
        precomputed_focal_challenge = False
        if (
            corners_path is not None
            and offset_fallback is not None
            and cube_area_pct is not None
            and SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT <= cube_area_pct
            and cube_area_pct <= SMALL_TARGET_VALIDATED_ACCEPT_MAX_AREA_PCT
        ):
            try:
                precomputed_fixed_rmse = float(offset_fallback[4])
            except (TypeError, ValueError, IndexError):
                precomputed_fixed_rmse = float("nan")
            precomputed_focal_challenge = (
                np.isfinite(precomputed_fixed_rmse)
                and precomputed_fixed_rmse > MAX_CONFIDENT_RMSE_PX
            )
        scan_offset_fallback = None
        if (
            offset_fallback is None
            or small_target_attempt
            or precomputed_focal_challenge
        ):
            scan_offset_fallback = _single_view_wide_offset_focal_scan_fallback(
                image_points_by_face,
                patterns_for_offset,
                (w_img, h_img),
                square_size_mm,
                K_offset_seed,
                focal_lo_limit,
                focal_hi_limit,
            )
            if offset_fallback is None:
                offset_fallback = scan_offset_fallback
            elif (
                scan_offset_fallback is not None
                and (small_target_attempt or precomputed_focal_challenge)
            ):
                try:
                    fixed_rmse = float(offset_fallback[4])
                    scan_rmse = float(scan_offset_fallback[4])
                    scan_fx = float(scan_offset_fallback[0][0, 0])
                except (TypeError, ValueError, IndexError):
                    fixed_rmse = scan_rmse = scan_fx = float("nan")
                if focal_px is None or not np.isfinite(float(focal_px)):
                    focal_deviation = 0.0
                else:
                    focal_deviation = (
                        abs(scan_fx - float(focal_px))
                        / max(float(focal_px), 1.0)
                    )
                focal_close = (
                    focal_px is None
                    or not np.isfinite(float(focal_px))
                    or focal_deviation
                    <= SMALL_TARGET_FOCAL_SCAN_MAX_PRIOR_DEVIATION_FRAC
                )
                scan_gain = fixed_rmse - scan_rmse
                precomputed_focal_rescue = (
                    corners_path is not None
                    and np.isfinite(focal_deviation)
                    and focal_deviation
                    <= PRECOMPUTED_FOCAL_SCAN_MAX_PRIOR_DEVIATION_FRAC
                    and np.isfinite(scan_gain)
                    and scan_gain >= PRECOMPUTED_FOCAL_SCAN_MIN_GAIN_PX
                )
                if (
                    np.isfinite(fixed_rmse)
                    and np.isfinite(scan_rmse)
                    and (focal_close or precomputed_focal_rescue)
                    and scan_rmse + SMALL_TARGET_FOCAL_SCAN_MIN_GAIN_PX
                    < fixed_rmse
                ):
                    offset_fallback = scan_offset_fallback
        if offset_fallback is None and sparse_recovery_mode:
            offset_fallback = _single_view_wide_offset_fixed_focal_fallback(
                image_points_by_face,
                patterns_for_offset,
                (w_img, h_img),
                square_size_mm,
                K_offset_seed,
            )
        if offset_fallback is None:
            offset_fallback = _single_view_offset_fallback(
                image_points_by_face,
                patterns_for_offset,
                (w_img, h_img),
                square_size_mm,
                K_offset_seed,
                focal_lo_limit,
                focal_hi_limit,
                MAX_CONFIDENT_RMSE_PX,
                MAX_CONFIDENT_INITIAL_PNP_RMSE_PX,
            )
        if offset_fallback is not None:
            if not _model_grade_isolation_allows(
                str(offset_fallback[5]), "single_face_offset_fallback"
            ):
                preflight["single_face_offset_comparison"] = {
                    "searched": True,
                    "accepted": False,
                    "rejection_reason": "model_grade_isolation",
                    "candidate_model": str(offset_fallback[5]),
                }
                warnings.append(
                    "Model-grade isolation skipped the single-face offset "
                    f"fallback ({offset_fallback[5]})."
                )
                offset_fallback = None
        if offset_fallback is not None:
            offset_candidate_rmse = float(offset_fallback[4])
            offset_candidate_gain = (
                pre_offset_reprojection_rmse - offset_candidate_rmse
            )
            offset_comparison = {
                "searched": True,
                "baseline_rmse_px": pre_offset_reprojection_rmse,
                "baseline_physical_gate_passed": bool(
                    not offset_quality_fails
                ),
                "candidate_rmse_px": offset_candidate_rmse,
                "gain_px": float(offset_candidate_gain),
                "candidate_model": str(offset_fallback[5]),
                "candidate_offset": [
                    int(offset_fallback[6][0]),
                    float(offset_fallback[6][1]),
                    float(offset_fallback[6][2]),
                ],
            }
            if (
                not offset_quality_fails
                and offset_candidate_gain < 0.35
            ):
                offset_comparison["accepted"] = False
                offset_comparison["rejection_reason"] = (
                    "insufficient_reprojection_gain"
                )
                offset_fallback = None
            else:
                offset_comparison["accepted"] = True
                offset_comparison["acceptance_reason"] = (
                    "baseline_failed_physical_gate"
                    if offset_quality_fails
                    else "significant_reprojection_gain"
                )
            preflight["single_face_offset_comparison"] = offset_comparison
        offset_recovery_applied = False
        if offset_fallback is not None:
            (
                K_opt, dist_opt, R_opt, t_opt, rmse, model_used,
                inferred_offset, offset_pnp_rmse,
            ) = offset_fallback
            if (
                str(model_used).startswith("single-view-wide-offset-focal-scan")
                or str(model_used).startswith(
                    "single-view-wide-offset-fixed-focal")
            ):
                warnings[:] = [
                    w for w in warnings
                    if not (
                        w.startswith("Used conservative single-view 3D fallback")
                        or w.startswith("Bundle adjustment was rejected")
                        or w.startswith("Auto-selected physical grid orientation")
                    )
                ]
            offset_recovery_applied = True
            pnp_rmse_before_ba = offset_pnp_rmse
            offset_face_labels = ["XY", "XZ", "YZ"]
            offset_face_idx = int(inferred_offset[0])
            offset_face_label = (
                offset_face_labels[offset_face_idx]
                if 0 <= offset_face_idx < len(offset_face_labels)
                else f"face {offset_face_idx}"
            )
            _max_outer_squares, applied_offsets = _center_offsets_in_squares(
                patterns_for_offset
            )
            applied_offsets = list(applied_offsets)
            if 0 <= offset_face_idx < len(applied_offsets):
                applied_offsets[offset_face_idx] = (
                    float(inferred_offset[1]),
                    float(inferred_offset[2]),
                )
            faces = _faces_from_square_offsets(
                patterns_for_offset,
                square_size_mm,
                applied_offsets,
            )
            detected_faces, offset_orientation, orientation_rmse = (
                _orient_offset_faces_to_pose(
                    image_points_by_face, faces,
                    K_opt, dist_opt, R_opt, t_opt,
                )
            )
            valid_idx = list(range(len(detected_faces)))
            all_obj = np.vstack([
                detected_faces[i].object_points for i in valid_idx
            ])
            all_img = np.vstack([
                detected_faces[i].image_points for i in valid_idx
            ])
            if str(model_used).startswith("single-view-wide-offset-focal-scan"):
                warnings.append(
                    f"Inferred {offset_face_label} face grid offset from "
                    "single-frame cube geometry "
                    f"({inferred_offset[1]:.0f}, {inferred_offset[2]:.0f}) "
                    "squares from the face origin using a bounded focal "
                    "plateau scan."
                )
            elif str(model_used).startswith("single-view-wide-offset-fixed-focal"):
                warnings.append(
                    f"Inferred wide {offset_face_label} face grid offset from "
                    "single-frame cube geometry "
                    f"({inferred_offset[1]:.0f}, {inferred_offset[2]:.0f}) "
                    "squares from the face origin using fixed focal length."
                )
            else:
                warnings.append(
                    f"Inferred {offset_face_label} face grid offset from "
                    "single-frame cube geometry "
                    f"({inferred_offset[1]:.0f}, {inferred_offset[2]:.0f}) "
                    "squares from the face origin."
                )
            warnings.append(
                "Synchronized offset face directions with the accepted "
                f"pose (RMSE {orientation_rmse:.2f}px, "
                f"flips={offset_orientation})."
            )
            fx, fy = float(K_opt[0, 0]), float(K_opt[1, 1])
            cx, cy = float(K_opt[0, 2]), float(K_opt[1, 2])
            if (
                sparse_recovery_mode
                and pnp_rmse_before_ba is not None
                and pnp_rmse_before_ba > MAX_CONFIDENT_INITIAL_PNP_RMSE_PX
            ):
                previous_offset_pnp_rmse = float(pnp_rmse_before_ba)
                multi_offset_fallback = _multi_face_offset_fallback(
                    image_points_by_face,
                    patterns_for_offset,
                    (w_img, h_img),
                    square_size_mm,
                    K_offset_seed,
                    focal_lo_limit,
                    focal_hi_limit,
                    MAX_CONFIDENT_RMSE_PX,
                    force=True,
                    max_offset_dist=MAX_WIDE_SINGLE_FACE_OFFSET_DIST_SQUARES,
                    min_changed_faces=MIN_MULTI_FACE_OFFSET_CHANGED_FACES,
                    pnp_limit=MAX_CONFIDENT_INITIAL_PNP_RMSE_PX,
                )
                if multi_offset_fallback is not None:
                    if not _model_grade_isolation_allows(
                        str(multi_offset_fallback[5]),
                        "sparse_multi_offset_replacement",
                    ):
                        warnings.append(
                            "Model-grade isolation skipped the sparse "
                            "multi-face offset replacement "
                            f"({multi_offset_fallback[5]})."
                        )
                        multi_offset_fallback = None
                if multi_offset_fallback is not None:
                    (
                        K_opt, dist_opt, R_opt, t_opt, rmse, model_used,
                        inferred_offsets, changed_faces, offset_pnp_rmse,
                    ) = multi_offset_fallback
                    pnp_rmse_before_ba = offset_pnp_rmse
                    warnings[:] = [
                        w for w in warnings
                        if not (
                            w.startswith("Inferred ")
                            and "face grid offset" in w
                        )
                    ]
                    offset_face_labels = ["XY", "XZ", "YZ"]
                    parts = []
                    for changed_face_idx in changed_faces:
                        offset_face_label = (
                            offset_face_labels[changed_face_idx]
                            if 0 <= changed_face_idx < len(offset_face_labels)
                            else f"face {changed_face_idx}"
                        )
                        ox, oy = inferred_offsets[changed_face_idx]
                        parts.append(f"{offset_face_label}=({ox:.0f},{oy:.0f})")
                    warnings.append(
                        "Replaced a high-error single-face offset with "
                        "coordinated face grid offsets from single-frame cube "
                        f"geometry ({', '.join(parts)}) squares from each "
                        f"face origin; initial PnP RMSE "
                        f"{previous_offset_pnp_rmse:.2f}px -> "
                        f"{offset_pnp_rmse:.2f}px."
                    )
                    faces = _faces_from_square_offsets(
                        patterns_for_offset,
                        square_size_mm,
                        inferred_offsets,
                    )
                    detected_faces, offset_orientation, orientation_rmse = (
                        _orient_offset_faces_to_pose(
                            image_points_by_face, faces,
                            K_opt, dist_opt, R_opt, t_opt,
                        )
                    )
                    valid_idx = list(range(len(detected_faces)))
                    all_obj = np.vstack([
                        detected_faces[i].object_points for i in valid_idx
                    ])
                    all_img = np.vstack([
                        detected_faces[i].image_points for i in valid_idx
                    ])
                    warnings.append(
                        "Synchronized coordinated offset face directions with "
                        f"the accepted pose (RMSE {orientation_rmse:.2f}px, "
                        f"flips={offset_orientation})."
                    )
                    fx, fy = float(K_opt[0, 0]), float(K_opt[1, 1])
                    cx, cy = float(K_opt[0, 2]), float(K_opt[1, 2])
        elif sparse_recovery_mode:
            multi_offset_fallback = _multi_face_offset_fallback(
                image_points_by_face,
                patterns_for_offset,
                (w_img, h_img),
                square_size_mm,
                K_offset_seed,
                focal_lo_limit,
                focal_hi_limit,
                MAX_CONFIDENT_RMSE_PX,
                force=True,
                max_offset_dist=MAX_WIDE_SINGLE_FACE_OFFSET_DIST_SQUARES,
                min_changed_faces=MIN_MULTI_FACE_OFFSET_CHANGED_FACES,
                pnp_limit=MAX_CONFIDENT_INITIAL_PNP_RMSE_PX,
            )
            if multi_offset_fallback is not None:
                if not _model_grade_isolation_allows(
                    str(multi_offset_fallback[5]),
                    "sparse_multi_offset_fallback",
                ):
                    warnings.append(
                        "Model-grade isolation skipped the sparse multi-face "
                        f"offset fallback ({multi_offset_fallback[5]})."
                    )
                    multi_offset_fallback = None
            if multi_offset_fallback is not None:
                (
                    K_opt, dist_opt, R_opt, t_opt, rmse, model_used,
                    inferred_offsets, changed_faces, offset_pnp_rmse,
                ) = multi_offset_fallback
                offset_recovery_applied = True
                pnp_rmse_before_ba = offset_pnp_rmse
                faces = _faces_from_square_offsets(
                    patterns_for_offset,
                    square_size_mm,
                    inferred_offsets,
                )
                detected_faces, offset_orientation, orientation_rmse = (
                    _orient_offset_faces_to_pose(
                        image_points_by_face, faces,
                        K_opt, dist_opt, R_opt, t_opt,
                    )
                )
                valid_idx = list(range(len(detected_faces)))
                all_obj = np.vstack([
                    detected_faces[i].object_points for i in valid_idx
                ])
                all_img = np.vstack([
                    detected_faces[i].image_points for i in valid_idx
                ])
                warnings[:] = [
                    w for w in warnings
                    if not (
                        w.startswith("Used conservative single-view 3D fallback")
                        or w.startswith("Bundle adjustment was rejected")
                        or w.startswith("Auto-selected physical grid orientation")
                    )
                ]
                offset_face_labels = ["XY", "XZ", "YZ"]
                parts = []
                for changed_face_idx in changed_faces:
                    offset_face_label = (
                        offset_face_labels[changed_face_idx]
                        if 0 <= changed_face_idx < len(offset_face_labels)
                        else f"face {changed_face_idx}"
                    )
                    ox, oy = inferred_offsets[changed_face_idx]
                    parts.append(f"{offset_face_label}=({ox:.0f},{oy:.0f})")
                warnings.append(
                    "Inferred coordinated face grid offsets from sparse "
                    "single-frame cube geometry "
                    f"({', '.join(parts)}) squares from each face origin."
                )
                fx, fy = float(K_opt[0, 0]), float(K_opt[1, 1])
                cx, cy = float(K_opt[0, 2]), float(K_opt[1, 2])
        elif not sparse_recovery_mode:
            force_grid_multi_offset = (
                grid_recovery_corners
                and os.environ.get(
                    "CALIB_FORCE_GRID_RECOVERY_MULTI_OFFSET", "0"
                ).strip().lower() in {"1", "true", "yes", "on"}
            )
            multi_offset_fallback = _multi_face_offset_fallback(
                image_points_by_face,
                patterns_for_offset,
                (w_img, h_img),
                square_size_mm,
                K_offset_seed,
                focal_lo_limit,
                focal_hi_limit,
                MAX_CONFIDENT_RMSE_PX,
                force=force_grid_multi_offset,
                max_offset_dist=(
                    MAX_WIDE_SINGLE_FACE_OFFSET_DIST_SQUARES
                    if force_grid_multi_offset
                    else None
                ),
                pnp_limit=(
                    MAX_CONFIDENT_INITIAL_PNP_RMSE_PX
                    if force_grid_multi_offset
                    else None
                ),
                allow_strong_ambiguous=force_grid_multi_offset,
            )
            if multi_offset_fallback is not None:
                if not _model_grade_isolation_allows(
                    str(multi_offset_fallback[5]),
                    "grid_multi_offset_fallback",
                ):
                    warnings.append(
                        "Model-grade isolation skipped the grid multi-face "
                        f"offset fallback ({multi_offset_fallback[5]})."
                    )
                    multi_offset_fallback = None
            if multi_offset_fallback is not None:
                (
                    K_opt, dist_opt, R_opt, t_opt, rmse, model_used,
                    inferred_offsets, changed_faces, offset_pnp_rmse,
                ) = multi_offset_fallback
                offset_recovery_applied = True
                pnp_rmse_before_ba = offset_pnp_rmse
                faces = _faces_from_square_offsets(
                    patterns_for_offset,
                    square_size_mm,
                    inferred_offsets,
                )
                detected_faces, offset_orientation, orientation_rmse = (
                    _orient_offset_faces_to_pose(
                        image_points_by_face, faces,
                        K_opt, dist_opt, R_opt, t_opt,
                    )
                )
                valid_idx = list(range(len(detected_faces)))
                all_obj = np.vstack([
                    detected_faces[i].object_points for i in valid_idx
                ])
                all_img = np.vstack([
                    detected_faces[i].image_points for i in valid_idx
                ])
                warnings[:] = [
                    w for w in warnings
                    if not (
                        w.startswith("Used conservative single-view 3D fallback")
                        or w.startswith("Bundle adjustment was rejected")
                    )
                ]
                offset_face_labels = ["XY", "XZ", "YZ"]
                parts = []
                for offset_face_idx in changed_faces:
                    offset_face_label = (
                        offset_face_labels[offset_face_idx]
                        if 0 <= offset_face_idx < len(offset_face_labels)
                        else f"face {offset_face_idx}"
                    )
                    ox, oy = inferred_offsets[offset_face_idx]
                    parts.append(f"{offset_face_label}=({ox:.0f},{oy:.0f})")
                warnings.append(
                    "Inferred coordinated face grid offsets from "
                    "single-frame cube geometry "
                    f"({', '.join(parts)}) squares from each face origin."
                )
                warnings.append(
                    "Synchronized offset face directions with the accepted "
                    f"pose (RMSE {orientation_rmse:.2f}px, "
                    f"flips={offset_orientation})."
                )
                fx, fy = float(K_opt[0, 0]), float(K_opt[1, 1])
                cx, cy = float(K_opt[0, 2]), float(K_opt[1, 2])
        if not offset_recovery_applied:
            wide_offset_fallback = _single_view_wide_offset_fixed_focal_fallback(
                image_points_by_face,
                patterns_for_offset,
                (w_img, h_img),
                square_size_mm,
                K_offset_seed,
            )
            if wide_offset_fallback is not None:
                if not _model_grade_isolation_allows(
                    str(wide_offset_fallback[5]),
                    "wide_offset_fixed_focal_fallback",
                ):
                    warnings.append(
                        "Model-grade isolation skipped the wide-offset "
                        f"fixed-focal fallback ({wide_offset_fallback[5]})."
                    )
                    wide_offset_fallback = None
            if wide_offset_fallback is not None:
                (
                    K_opt, dist_opt, R_opt, t_opt, rmse, model_used,
                    inferred_offset, offset_pnp_rmse,
                ) = wide_offset_fallback
                pnp_rmse_before_ba = offset_pnp_rmse
                _max_outer_squares, applied_offsets = _center_offsets_in_squares(
                    patterns_for_offset
                )
                applied_offsets = list(applied_offsets)
                applied_face = int(inferred_offset[0])
                if 0 <= applied_face < len(applied_offsets):
                    applied_offsets[applied_face] = (
                        float(inferred_offset[1]),
                        float(inferred_offset[2]),
                    )
                faces = _faces_from_square_offsets(
                    patterns_for_offset,
                    square_size_mm,
                    applied_offsets,
                )
                detected_faces, offset_orientation, orientation_rmse = (
                    _orient_offset_faces_to_pose(
                        image_points_by_face, faces,
                        K_opt, dist_opt, R_opt, t_opt,
                    )
                )
                valid_idx = list(range(len(detected_faces)))
                all_obj = np.vstack([
                    detected_faces[i].object_points for i in valid_idx
                ])
                all_img = np.vstack([
                    detected_faces[i].image_points for i in valid_idx
                ])
                warnings[:] = [
                    w for w in warnings
                    if not (
                        w.startswith("Used conservative single-view 3D fallback")
                        or w.startswith("Bundle adjustment was rejected")
                    )
                ]
                offset_face_labels = ["XY", "XZ", "YZ"]
                offset_face_idx = int(inferred_offset[0])
                offset_face_label = (
                    offset_face_labels[offset_face_idx]
                    if 0 <= offset_face_idx < len(offset_face_labels)
                    else f"face {offset_face_idx}"
                )
                warnings.append(
                    f"Inferred wide {offset_face_label} face grid offset from "
                    "single-frame cube geometry "
                    f"({inferred_offset[1]:.0f}, {inferred_offset[2]:.0f}) "
                    "squares from the face origin using fixed focal length."
                )
                warnings.append(
                    "Synchronized offset face directions with the accepted "
                    f"pose (RMSE {orientation_rmse:.2f}px, "
                    f"flips={offset_orientation})."
                )
                fx, fy = float(K_opt[0, 0]), float(K_opt[1, 1])
                cx, cy = float(K_opt[0, 2]), float(K_opt[1, 2])

    raw_recovery_rmse_limit = (
        MAX_CONFIDENT_FIXED_FOCAL_RMSE_PX
        if (
            model_used in {'fixed-focal-k1', 'fixed-intrinsics'}
            or model_used == 'fixed-focal-zero-dist'
            or str(model_used).startswith("single-view-wide-offset-fixed-focal")
        )
        else MAX_CONFIDENT_RMSE_PX
    )
    raw_candidate_recovery_needed = (
        manual_face_rois is None
        and corners_path is None
        and n_valid == 3
        and (
            (not np.isfinite(fx))
            or (not np.isfinite(fy))
            or max(fx, fy) > focal_hi_limit
            or min(fx, fy) < focal_lo_limit
            or abs(cx - w_img / 2.0) > MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC * w_img
            or abs(cy - h_img / 2.0) > MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC * h_img
            or (not np.isfinite(rmse))
            or rmse > raw_recovery_rmse_limit
            or (not np.isfinite(dist_opt[0]))
            or abs(float(dist_opt[0])) > MAX_CONFIDENT_K1_ABS
            or model_used == 'vp-only'
        )
    )
    if raw_candidate_recovery_needed:
        raw_recovery = None
        try:
            if (
                detector_raw_detections is not None
                and len(detector_raw_detections) >= 3
            ):
                detector_sources = [
                    f"detector-cube-first:{label}:{pat[0]}x{pat[1]}"
                    for _corners, pat, label in detector_raw_detections[:3]
                ]
                raw_recovery = _wide_offset_recovery_from_detections(
                    detector_raw_detections,
                    (w_img, h_img),
                    square_size_mm,
                    focal_lo_limit,
                    focal_hi_limit,
                    model_prefix="raw-candidate",
                    sources=detector_sources,
                    offset_hint_rmse=(
                        pnp_rmse_before_ba
                        if pnp_rmse_before_ba is not None
                        else None
                    ),
                )
        except Exception:
            raw_recovery = None
        try:
            if (
                raw_recovery is None
                and len(image_points_by_face) == 3
                and len(patterns_for_offset) == 3
            ):
                focal_anchor = float(np.clip(
                    WIDE_OFFSET_FOCAL_SCAN_ANCHOR_DIAG_MULT * image_diag,
                    focal_lo_limit,
                    focal_hi_limit,
                ))
                K_seed = np.array([
                    [focal_anchor, 0.0, w_img / 2.0],
                    [0.0, focal_anchor, h_img / 2.0],
                    [0.0, 0.0, 1.0],
                ], dtype=np.float64)
                current_recovered = _single_view_wide_offset_focal_scan_fallback(
                    image_points_by_face,
                    patterns_for_offset,
                    (w_img, h_img),
                    square_size_mm,
                    K_seed,
                    focal_lo_limit,
                    focal_hi_limit,
                )
                if current_recovered is not None:
                    (
                        cur_K,
                        cur_dist,
                        cur_R,
                        cur_t,
                        cur_rmse,
                        cur_model_name,
                        cur_offset,
                        cur_offset_pnp,
                    ) = current_recovered
                    cur_k1 = float(cur_dist[0])
                    if (
                        np.isfinite(cur_rmse)
                        and cur_rmse <= MAX_CONFIDENT_WIDE_OFFSET_FIXED_FOCAL_RMSE_PX
                        and abs(cur_k1) <= MAX_CONFIDENT_OFFSET_K1_ABS
                        and np.isfinite(cur_offset_pnp)
                        and cur_offset_pnp <= MAX_CONFIDENT_WIDE_OFFSET_PNP_RMSE_PX
                    ):
                        max_outer_squares, cur_offsets = _center_offsets_in_squares(
                            patterns_for_offset)
                        vary_face = int(cur_offset[0])
                        if 0 <= vary_face < len(cur_offsets):
                            cur_offsets = list(cur_offsets)
                            cur_offsets[vary_face] = (
                                float(cur_offset[1]),
                                float(cur_offset[2]),
                            )
                            cur_faces = _faces_from_square_offsets(
                                patterns_for_offset,
                                square_size_mm,
                                cur_offsets,
                            )
                            cur_detected = []
                            for pts, face in zip(image_points_by_face, cur_faces):
                                cur_detected.append(DetectedFace(
                                    image_points=pts.astype(np.float32),
                                    object_points=object_points_for_face(face),
                                    valid=True,
                                ))
                            raw_recovery = {
                                "K": cur_K,
                                "dist": cur_dist,
                                "R": cur_R,
                                "t": cur_t,
                                "rmse": float(cur_rmse),
                                "model_name": (
                                    f"current-candidate-{cur_model_name}"
                                ),
                                "inferred_offset": cur_offset,
                                "offset_pnp_rmse": float(cur_offset_pnp),
                                "faces": cur_faces,
                                "detected_faces": cur_detected,
                                "detections": None,
                                "sources": ["current-detection"] * 3,
                                "offset_hint_rmse": float(
                                    pnp_rmse_before_ba
                                    if pnp_rmse_before_ba is not None
                                    else np.nan
                                ),
                            }
        except Exception:
            raw_recovery = None
        if raw_recovery is None or raw_recovery.get("topology_vetted"):
            searched_raw_recovery = _raw_candidate_wide_offset_recovery(
                gray,
                (w_img, h_img),
                square_size_mm,
                focal_lo_limit,
                focal_hi_limit,
            )
            if (
                searched_raw_recovery is not None
                and (
                    raw_recovery is None
                    or searched_raw_recovery["rmse"] + 0.35
                    < raw_recovery["rmse"]
                )
            ):
                raw_recovery = searched_raw_recovery
        if raw_recovery is not None:
            if not _model_grade_isolation_allows(
                str(raw_recovery["model_name"]), "raw_candidate_recovery"
            ):
                warnings.append(
                    "Model-grade isolation skipped raw face-grid recovery "
                    f"({raw_recovery['model_name']})."
                )
                raw_recovery = None
        if raw_recovery is not None:
            K_opt = raw_recovery["K"]
            dist_opt = raw_recovery["dist"]
            R_opt = raw_recovery["R"]
            t_opt = raw_recovery["t"]
            rmse = raw_recovery["rmse"]
            model_used = raw_recovery["model_name"]
            faces = raw_recovery["faces"]
            detected_faces = raw_recovery["detected_faces"]
            valid_idx = [0, 1, 2]
            n_valid = 3
            n_corners = sum(
                df.image_points.shape[0]
                for df in detected_faces
                if df.valid
            )
            face_qualities = [
                _corner_line_quality(df.image_points, face.pattern_size)
                for df, face in zip(detected_faces, faces)
                if df.valid
            ]
            corner_quality = (
                float(np.mean(face_qualities))
                if face_qualities else float('inf')
            )
            all_obj = np.vstack([
                detected_faces[i].object_points for i in valid_idx
            ])
            all_img = np.vstack([
                detected_faces[i].image_points for i in valid_idx
            ])
            all_pts = np.vstack([
                detected_faces[i].image_points.reshape(-1, 2)
                for i in valid_idx
            ])
            x_span = all_pts[:, 0].max() - all_pts[:, 0].min()
            y_span = all_pts[:, 1].max() - all_pts[:, 1].min()
            fov_coverage = x_span * y_span / (w_img * h_img) * 100
            pnp_rmse_before_ba = raw_recovery["offset_pnp_rmse"]
            fx, fy = float(K_opt[0, 0]), float(K_opt[1, 1])
            cx, cy = float(K_opt[0, 2]), float(K_opt[1, 2])
            inferred_offset = raw_recovery["inferred_offset"]
            inferred_offsets = raw_recovery.get("inferred_offsets")
            changed_faces = raw_recovery.get("changed_faces")
            offset_face_labels = ["XY", "XZ", "YZ"]
            offset_face_idx = int(inferred_offset[0])
            offset_face_label = (
                offset_face_labels[offset_face_idx]
                if 0 <= offset_face_idx < len(offset_face_labels)
                else f"face {offset_face_idx}"
            )
            pattern_desc = ", ".join(
                f"{face.pattern_size[0]}x{face.pattern_size[1]}"
                for face in faces
            )
            source_desc = ", ".join(str(s) for s in raw_recovery["sources"])
            warnings[:] = [
                w for w in warnings
                if not (
                    w.startswith("Used conservative single-view 3D fallback")
                    or w.startswith("Bundle adjustment was rejected")
                )
            ]
            warnings.append(
                "Recovered from raw face-grid candidates after refined "
                "corner geometry failed. "
                f"Faces=[{pattern_desc}], sources=[{source_desc}]."
            )
            if inferred_offsets is not None and changed_faces:
                parts = []
                for changed_face_idx in changed_faces:
                    offset_face_label = (
                        offset_face_labels[changed_face_idx]
                        if 0 <= changed_face_idx < len(offset_face_labels)
                        else f"face {changed_face_idx}"
                    )
                    ox, oy = inferred_offsets[changed_face_idx]
                    parts.append(f"{offset_face_label}=({ox:.0f},{oy:.0f})")
                warnings.append(
                    "Inferred raw coordinated face grid offsets from "
                    "single-frame cube geometry "
                    f"({', '.join(parts)}) squares from each face origin; "
                    f"offset PnP RMSE {pnp_rmse_before_ba:.2f}px."
                )
            else:
                warnings.append(
                    f"Inferred raw {offset_face_label} face grid offset from "
                    "single-frame cube geometry "
                    f"({inferred_offset[1]:.0f}, {inferred_offset[2]:.0f}) "
                    "squares from the face origin using a bounded focal plateau "
                    f"scan; offset PnP RMSE {pnp_rmse_before_ba:.2f}px."
                )

    if diagnostic_cache_path:
        cache_parent = os.path.dirname(os.path.abspath(diagnostic_cache_path))
        if cache_parent:
            os.makedirs(cache_parent, exist_ok=True)
        np.savez_compressed(
            diagnostic_cache_path,
            image_points=np.array([
                np.asarray(detected_faces[i].image_points).reshape(-1, 2)
                for i in valid_idx[:3]
            ], dtype=object),
            object_points=np.array([
                np.asarray(detected_faces[i].object_points).reshape(-1, 3)
                for i in valid_idx[:3]
            ], dtype=object),
            patterns=np.array([
                faces[i].pattern_size for i in valid_idx[:3]
            ], dtype=np.int32),
            image_size=np.array([w_img, h_img], dtype=np.int32),
            K_seed=np.asarray(K_opt, dtype=np.float64),
            dist_seed=np.asarray(dist_opt, dtype=np.float64),
            R_seed=np.asarray(R_opt, dtype=np.float64),
            t_seed=np.asarray(t_opt, dtype=np.float64),
            image_path=np.array([os.path.abspath(image_path)]),
        )
        preflight["diagnostic_cache_path"] = os.path.abspath(
            diagnostic_cache_path
        )

    # Re-run the full Zhang-system refinement after the legacy candidate
    # cascade has recovered checker placement offsets.  This is where earlier
    # experiments contribute their strongest result: reliable physical layout
    # and a stable initializer, while all camera parameters remain free.
    scale_prior_fast_fixed_focal = bool(
        scale_prior_fast_fixed_focal_candidate
    )
    if scale_prior_fast_fixed_focal:
        preflight["single_cube_zhang_final"] = {
            "success": False,
            "skipped": True,
            "reason": (
                "scale-prior fast fixed-focal candidate below "
                f"{SCALE_PRIOR_FAST_FIXED_FOCAL_MAX_AREA_PCT:.2f}% cube "
                "area; final Zhang full-parameter diagnostic was skipped "
                "to avoid turning a valid 2-3% recovery into a timeout"
            ),
            "candidate_model": str(model_used),
            "candidate_rmse_px": float(rmse),
            "focal_px": float(focal_px),
        }
        warnings.append(
            "Skipped final Zhang full-parameter diagnostic for a scale-prior "
            f"fixed-focal small-target candidate ({cube_area_pct:.2f}% area, "
            f"RMSE {rmse:.2f}px)."
        )
    if (
        not scale_prior_fast_fixed_focal
        and n_valid == 3
        and len(detected_faces) >= 3
    ):
        try:
            final_cube_zhang = calibrate_single_cube_zhang(
                [detected_faces[i] for i in valid_idx[:3]],
                image_size=(w_img, h_img),
                square_size=square_size_mm,
                face_definitions=[faces[i] for i in valid_idx[:3]],
                allow_face_permutations=False,
                refinement_K_seeds=[K_opt],
                physical_parameter_seed=(K_opt, dist_opt, R_opt, t_opt),
                homography_image_points=zhang_homography_points,
                shared_axis_weight=zhang_shared_axis_weight,
            )
            preflight["single_cube_zhang_final"] = {
                "success": bool(final_cube_zhang.success),
                "linear_K": final_cube_zhang.linear_K.tolist(),
                "K": final_cube_zhang.K.tolist(),
                "dist": final_cube_zhang.dist.tolist(),
                "reproj_rmse": float(final_cube_zhang.reproj_rmse),
                "face_assignment": final_cube_zhang.face_assignment,
                "face_orientations": final_cube_zhang.face_orientations,
                "diagnostics": final_cube_zhang.diagnostics,
            }
            zhang_accept_limit = (
                min(MAX_CONFIDENT_RMSE_PX, float(rmse) + 0.5)
                if np.isfinite(rmse) else MAX_CONFIDENT_RMSE_PX
            )
            zhang_fx = float(final_cube_zhang.K[0, 0])
            zhang_fy = float(final_cube_zhang.K[1, 1])
            zhang_cx = float(final_cube_zhang.K[0, 2])
            zhang_cy = float(final_cube_zhang.K[1, 2])
            zhang_skew = float(final_cube_zhang.K[0, 1])
            zhang_aspect = max(zhang_fx, zhang_fy) / max(
                min(zhang_fx, zhang_fy), 1e-9,
            )
            zhang_multi_start = final_cube_zhang.diagnostics.get(
                "multi_start_stability", {}
            )
            zhang_local_uncertainty = final_cube_zhang.diagnostics.get(
                "local_parameter_uncertainty", {}
            )
            zhang_confidence = final_cube_zhang.diagnostics.get(
                "full_parameter_confidence", {}
            )
            zhang_multi_stable = bool(zhang_multi_start.get("stable", False))
            zhang_multi_core_stable = bool(
                zhang_confidence.get("multi_start_core_stable", False)
            )
            zhang_local_identifiable = bool(
                zhang_local_uncertainty.get("stable", False)
            )
            zhang_stable = bool(
                zhang_confidence.get("calibration_model_confident", False)
            )
            zhang_full_confident = bool(
                zhang_confidence.get("full_16_parameter_confident", False)
            )
            zhang_parameter_model = str(
                zhang_confidence.get(
                    "selected_parameter_model", "full_16_parameter",
                )
            )
            zhang_physical = bool(
                focal_lo_limit <= min(zhang_fx, zhang_fy)
                and max(zhang_fx, zhang_fy) <= focal_hi_limit
                and zhang_aspect <= 1.35
                and abs(zhang_cx - w_img / 2.0)
                <= MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC * w_img
                and abs(zhang_cy - h_img / 2.0)
                <= MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC * h_img
                and abs(zhang_skew) <= 0.15 * min(zhang_fx, zhang_fy)
                and abs(float(final_cube_zhang.dist[0])) < 0.76
                and abs(float(final_cube_zhang.dist[1])) < 0.38
                and abs(float(final_cube_zhang.dist[2])) < 0.0475
                and abs(float(final_cube_zhang.dist[3])) < 0.0475
                and abs(float(final_cube_zhang.dist[4])) < 0.285
            )
            preflight["single_cube_zhang_final"]["physical_candidate"] = (
                zhang_physical
            )
            preflight["single_cube_zhang_final"]["multi_start_stable"] = (
                zhang_multi_stable
            )
            preflight["single_cube_zhang_final"]["multi_start_core_stable"] = (
                zhang_multi_core_stable
            )
            preflight["single_cube_zhang_final"]["local_identifiable"] = (
                zhang_local_identifiable
            )
            preflight["single_cube_zhang_final"]["full_parameter_confident"] = (
                zhang_full_confident
            )
            preflight["single_cube_zhang_final"]["supported_model_confident"] = (
                zhang_stable
            )
            preflight["single_cube_zhang_final"]["selected_parameter_model"] = (
                zhang_parameter_model
            )
            if (
                final_cube_zhang.success
                and np.isfinite(final_cube_zhang.reproj_rmse)
                and final_cube_zhang.reproj_rmse <= zhang_accept_limit
                and zhang_physical
                and zhang_stable
            ):
                zhang_model_used = (
                    'single-cube-zhang-full'
                    if zhang_parameter_model == 'full_16_parameter'
                    else 'single-cube-zhang-k1'
                    if zhang_parameter_model == 'k1_only_12_parameter'
                    else 'single-cube-zhang-radial'
                )
                if not _model_grade_isolation_allows(
                    zhang_model_used, "final_single_cube_zhang_refinement"
                ):
                    preflight["single_cube_zhang_final"][
                        "model_grade_isolation_rejected"
                    ] = True
                    warnings.append(
                        "Model-grade isolation skipped the final "
                        f"single-cube Zhang candidate ({zhang_model_used})."
                    )
                else:
                    K_opt = final_cube_zhang.K.copy()
                    dist_opt = final_cube_zhang.dist.copy()
                    R_opt = final_cube_zhang.R.copy()
                    t_opt = final_cube_zhang.t.copy()
                    rmse = float(final_cube_zhang.reproj_rmse)
                    model_used = zhang_model_used
                    all_obj = final_cube_zhang.object_points.reshape(-1, 1, 3)
                    all_img = final_cube_zhang.image_points.reshape(-1, 1, 2)
                    fx, fy = float(K_opt[0, 0]), float(K_opt[1, 1])
                    cx, cy = float(K_opt[0, 2]), float(K_opt[1, 2])
                    warnings[:] = [
                        warning for warning in warnings
                        if not (
                            warning.startswith(
                                "Used single-image three-plane Zhang initialization"
                            )
                            or warning.startswith("Low distortion detected")
                        )
                    ]
                    if zhang_parameter_model == 'full_16_parameter':
                        warnings.append(
                            "Used recovered three-face physical layout followed by "
                            "single-image Zhang full-parameter refinement."
                        )
                    elif zhang_parameter_model == 'tangential_fixed_14_parameter':
                        warnings.append(
                            "Tangential distortion was not observable in this frame; "
                            "p1/p2 were fixed to zero and the remaining 14 camera and "
                            "pose parameters passed the confidence gates."
                        )
                    else:
                        warnings.append(
                            "Only first-order radial distortion was observable in "
                            "this frame; k2/p1/p2/k3 were fixed to zero and the "
                            "remaining 12 camera and pose parameters passed the "
                            "confidence gates."
                        )
        except Exception as exc:
            preflight["single_cube_zhang_final"] = {
                "success": False,
                "error": str(exc),
            }

    def _raise_low_confidence_or_sparse_boundary(
        message,
        *,
        allow_scale_prior_relaxation=True,
    ):
        if sparse_recovery_mode:
            sparse_reason = (
                message
                .replace("Low-confidence calibration: ", "candidate rejection: ")
                .replace("Low-confidence ", "candidate rejection ")
                .replace("low-confidence ", "candidate rejection ")
            )
            raise RuntimeError(
                f"{sparse_recovery_boundary_msg} Sparse recovery was "
                f"attempted but rejected: {sparse_reason}"
            )
        if scale_prior_candidate_active and allow_scale_prior_relaxation:
            preflight.setdefault("scale_prior_candidate", {}).setdefault(
                "relaxed_failures", []
            ).append(str(message))
            warnings.append(
                "Scale-prior diagnostic candidate: relaxed a confidence gate "
                "after recovered three-face input-scale checker geometry "
                f"({message})"
            )
            return
        if small_target_attempt:
            raise RuntimeError(
                _small_target_boundary_message(cube_area_pct, message)
            )
        raise RuntimeError(message)

    final_focal_hi_limit = focal_hi_limit
    if small_target_attempt:
        final_focal_hi_limit = max(
            final_focal_hi_limit,
            SMALL_TARGET_MAX_FOCAL_DIAG_MULT * image_diag,
        )
    if (not np.isfinite(fx) or not np.isfinite(fy)
            or max(fx, fy) > final_focal_hi_limit
            or min(fx, fy) < focal_lo_limit):
        _raise_low_confidence_or_sparse_boundary(
            "Low-confidence calibration: vanishing-point focal estimate is "
            f"outside the reliable range ({fx:.1f}, {fy:.1f}px; "
            f"expected {focal_lo_limit:.1f}-{final_focal_hi_limit:.1f}px). "
            "Treat this image as a calibration boundary or recapture closer "
            "with clearer three-face geometry."
        )
    rmse_limit = (
        MAX_CONFIDENT_FIXED_FOCAL_RMSE_PX
        if (
            model_used in {'fixed-focal-k1', 'fixed-intrinsics'}
            or model_used == 'fixed-focal-zero-dist'
            or str(model_used).startswith("single-view-wide-offset-fixed-focal")
        )
        else MAX_CONFIDENT_RMSE_PX
    )
    if (not np.isfinite(rmse)) or rmse > rmse_limit:
        _raise_low_confidence_or_sparse_boundary(
            "Low-confidence calibration: reprojection geometry is unstable "
            f"(RMSE {rmse:.2f}px; limit {rmse_limit:.1f}px). "
            "Treat this image as a calibration boundary or recapture closer "
            "with clearer three-face geometry."
        )
    principal_dx = abs(cx - w_img / 2.0)
    principal_dy = abs(cy - h_img / 2.0)
    if (
        principal_dx > MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC * w_img
        or principal_dy > MAX_CONFIDENT_PRINCIPAL_CENTER_FRAC * h_img
    ):
        _raise_low_confidence_or_sparse_boundary(
            "Low-confidence calibration: optimized principal point is too far "
            f"from the image center (cx={cx:.1f}, cy={cy:.1f}; center="
            f"{w_img / 2.0:.1f},{h_img / 2.0:.1f}). Treat this image as an "
            "intrinsics-stability boundary rather than an accepted "
            "calibration."
        )
    if abs(float(dist_opt[0])) > MAX_CONFIDENT_K1_ABS:
        _raise_low_confidence_or_sparse_boundary(
            "Low-confidence calibration: estimated radial distortion is too "
            f"large for the current single-image reliability gate "
            f"(k1={float(dist_opt[0]):.3f}; limit {MAX_CONFIDENT_K1_ABS:.2f}). "
            "Treat this image as an intrinsics-stability boundary rather "
            "than an accepted calibration."
        )
    if model_used == 'vp-only':
        _raise_low_confidence_or_sparse_boundary(
            "Low-confidence calibration: bundle adjustment was rejected and "
            "only VP-only intrinsics remain. VP-only is useful for diagnosis, "
            "but it is not accepted as a final calibration in the current "
            "reliability gate.",
            allow_scale_prior_relaxation=False,
        )
    if (
        model_used in {
            'single-view-k1',
            'single-view-zero-dist',
            'single-view-offset-k1',
            'single-view-offset-zero-dist',
            'fixed-focal-k1',
            'fixed-focal-zero-dist',
            'fixed-intrinsics',
        }
        and pnp_rmse_before_ba is not None
        and pnp_rmse_before_ba > MAX_CONFIDENT_INITIAL_PNP_RMSE_PX
        and n_valid == 3
        and len(detected_faces) >= 3
    ):
        retry_image_points_by_face = [
            detected_faces[i].image_points.reshape(-1, 1, 2).astype(np.float32)
            for i in valid_idx[:3]
        ]
        retry_patterns_for_offset = [
            faces[i].pattern_size for i in valid_idx[:3]
        ]
        final_multi_offset = _multi_face_offset_fallback(
            retry_image_points_by_face,
            retry_patterns_for_offset,
            (w_img, h_img),
            square_size_mm,
            K_offset_seed,
            focal_lo_limit,
            focal_hi_limit,
            MAX_CONFIDENT_RMSE_PX,
            force=True,
            max_offset_dist=MAX_WIDE_SINGLE_FACE_OFFSET_DIST_SQUARES,
            min_changed_faces=MIN_MULTI_FACE_OFFSET_CHANGED_FACES,
            pnp_limit=MAX_CONFIDENT_INITIAL_PNP_RMSE_PX,
            allow_strong_ambiguous=True,
        )
        if final_multi_offset is not None:
            if not _model_grade_isolation_allows(
                str(final_multi_offset[5]), "final_multi_offset_rescue"
            ):
                warnings.append(
                    "Model-grade isolation skipped the final multi-face "
                    f"offset rescue ({final_multi_offset[5]})."
                )
                final_multi_offset = None
        if final_multi_offset is not None:
            previous_offset_pnp_rmse = float(pnp_rmse_before_ba)
            (
                K_opt, dist_opt, R_opt, t_opt, rmse, model_used,
                inferred_offsets, changed_faces, offset_pnp_rmse,
            ) = final_multi_offset
            pnp_rmse_before_ba = offset_pnp_rmse
            offset_faces = _faces_from_square_offsets(
                retry_patterns_for_offset,
                square_size_mm,
                inferred_offsets,
            )
            detected_faces = [
                DetectedFace(
                    image_points=pts.astype(np.float32),
                    object_points=object_points_for_face(face),
                    valid=True,
                )
                for pts, face in zip(retry_image_points_by_face, offset_faces)
            ]
            faces = offset_faces
            valid_idx = [0, 1, 2]
            n_valid = 3
            all_obj = np.vstack([
                detected_faces[i].object_points for i in valid_idx
            ])
            all_img = np.vstack([
                detected_faces[i].image_points for i in valid_idx
            ])
            fx, fy = float(K_opt[0, 0]), float(K_opt[1, 1])
            cx, cy = float(K_opt[0, 2]), float(K_opt[1, 2])
            rmse_limit = (
                MAX_CONFIDENT_FIXED_FOCAL_RMSE_PX
                if (
                    model_used in {'fixed-focal-k1', 'fixed-intrinsics'}
                    or model_used == 'fixed-focal-zero-dist'
                    or str(model_used).startswith(
                        "single-view-wide-offset-fixed-focal")
                )
                else MAX_CONFIDENT_RMSE_PX
            )
            warnings[:] = [
                w for w in warnings
                if not (
                    w.startswith("Used conservative single-view 3D fallback")
                    or w.startswith("Bundle adjustment was rejected")
                )
            ]
            offset_face_labels = ["XY", "XZ", "YZ"]
            parts = []
            for changed_face_idx in changed_faces:
                offset_face_label = (
                    offset_face_labels[changed_face_idx]
                    if 0 <= changed_face_idx < len(offset_face_labels)
                    else f"face {changed_face_idx}"
                )
                ox, oy = inferred_offsets[changed_face_idx]
                parts.append(f"{offset_face_label}=({ox:.0f},{oy:.0f})")
            warnings.append(
                "Rescued a high initial-PnP single-view solution with "
                "coordinated face grid offsets from single-frame cube geometry "
                f"({', '.join(parts)}) squares from each face origin; initial "
                f"PnP RMSE {previous_offset_pnp_rmse:.2f}px -> "
                f"{offset_pnp_rmse:.2f}px."
            )
    if (
        model_used in {
            'single-view-k1',
            'single-view-zero-dist',
            'single-view-offset-k1',
            'single-view-offset-zero-dist',
            'fixed-focal-k1',
            'fixed-focal-zero-dist',
            'fixed-intrinsics',
        }
        and pnp_rmse_before_ba is not None
        and pnp_rmse_before_ba > MAX_CONFIDENT_INITIAL_PNP_RMSE_PX
    ):
        fixed_focal_external_accept = (
            focal_px is not None
            and np.isfinite(focal_px)
            and float(focal_px) > 0.0
            and (
                model_used in {
                    'fixed-focal-k1',
                    'fixed-focal-zero-dist',
                    'fixed-intrinsics',
                }
                or str(model_used).startswith(
                    "single-view-wide-offset-fixed-focal")
            )
            and np.isfinite(rmse)
            and float(rmse) <= MAX_CONFIDENT_FIXED_FOCAL_RMSE_PX
        )
        if fixed_focal_external_accept:
            warnings.append(
                "Accepted fixed-focal single-frame solution despite high "
                "zero-distortion initial PnP because the external/group focal "
                "prior and k1 pose fit passed the fixed-focal RMSE gate "
                f"({float(rmse):.2f}px <= "
                f"{MAX_CONFIDENT_FIXED_FOCAL_RMSE_PX:.1f}px)."
            )
        else:
            if os.environ.get("CALIB_DEBUG_OFFSET_GATE") == "1":
                print(
                    "  Final initial-PnP gate: "
                    f"model={model_used}, rmse={float(rmse):.2f}, "
                    f"pnp={float(pnp_rmse_before_ba):.2f}"
                )
            _raise_low_confidence_or_sparse_boundary(
                "Low-confidence calibration: single-view fallback required too "
                f"much correction from the initial three-face PnP geometry "
                f"(PnP RMSE {pnp_rmse_before_ba:.2f}px; limit "
                f"{MAX_CONFIDENT_INITIAL_PNP_RMSE_PX:.1f}px). Treat this image "
                "as an intrinsics-stability boundary."
            )

    if small_target_attempt:
        strict_failures = []
        if n_valid < n_faces:
            strict_failures.append(f"only {n_valid}/{n_faces} faces survived")
        if (
            not DISABLE_AREA_RATIO_GATES
            and (
            cube_area_pct is None
            or cube_area_pct < SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT
            or cube_area_pct > SMALL_TARGET_VALIDATED_ACCEPT_MAX_AREA_PCT
            )
        ):
            area_text = (
                "unknown"
                if cube_area_pct is None
                else f"{cube_area_pct:.2f}%"
            )
            strict_failures.append(
                f"cube area {area_text} is outside the current "
                "validated accepted small-target pocket "
                f"{SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT:.2f}-"
                f"{SMALL_TARGET_VALIDATED_ACCEPT_MAX_AREA_PCT:.2f}%"
            )
        observed_patterns = tuple(
            tuple(int(v) for v in faces[i].pattern_size)
            for i in valid_idx[:n_faces]
        )
        trihedral_closure_template_ok = (
            scale_prior_candidate_active
            and _scale_prior_trihedral_closure_prefilter_allowed(
                observed_patterns,
                n_corners,
                trihedral_closure_source=precomputed_is_trihedral_closure,
            )
        )
        extended_coverage_probe = (
            fov_coverage > SMALL_TARGET_MAX_FOV_COVERAGE_PCT
        )
        if fov_coverage > SMALL_TARGET_EXTENDED_MAX_FOV_COVERAGE_PCT:
            strict_failures.append(
                f"corner coverage {fov_coverage:.2f}% exceeds the current "
                "extended small-target coverage probe pocket "
                f"({SMALL_TARGET_EXTENDED_MAX_FOV_COVERAGE_PCT:.2f}% max)"
            )
        elif extended_coverage_probe:
            extended_failures = []
            if (
                not DISABLE_AREA_RATIO_GATES
                and (
                cube_area_pct is None
                or cube_area_pct < SMALL_TARGET_EXTENDED_MIN_CUBE_AREA_PCT
                )
            ):
                area_text = (
                    "unknown"
                    if cube_area_pct is None
                    else f"{cube_area_pct:.2f}%"
                )
                if trihedral_closure_template_ok:
                    preflight.setdefault("scale_prior_candidate", {})[
                        "trihedral_closure_extended_area_relaxed"
                    ] = {
                        "area_pct": None if cube_area_pct is None else float(cube_area_pct),
                        "base_min_area_pct": float(
                            SMALL_TARGET_EXTENDED_MIN_CUBE_AREA_PCT
                        ),
                    }
                    warnings.append(
                        "Relaxed the extended-coverage cube-area floor for a "
                        "trihedral-closure candidate; final acceptance still "
                        "depends on reprojection, line-quality, and initial-PnP "
                        "gates."
                    )
                else:
                    extended_failures.append(
                        f"cube area {area_text} is below the extended-coverage "
                        f"minimum {SMALL_TARGET_EXTENDED_MIN_CUBE_AREA_PCT:.2f}%"
                    )
            if n_corners < sum(c * r for c, r in SMALL_TARGET_CANONICAL_PATTERNS):
                extended_failures.append(
                    "extended coverage requires the complete 144-corner "
                    "three-face target"
                )
            if (
                not _small_target_patterns_allowed(observed_patterns)
                and not trihedral_closure_template_ok
            ):
                extended_failures.append(
                    "extended coverage requires the canonical visible "
                    "three-face grid pattern"
                )
            if not (
                str(model_used).startswith(
                    "single-view-wide-offset-focal-scan"
                )
                or str(model_used).startswith("single-cube-zhang")
            ):
                extended_failures.append(
                    "extended coverage requires wide-offset focal-scan "
                    "single-frame geometry"
                )
            if (
                (not np.isfinite(corner_quality))
                or corner_quality > SMALL_TARGET_EXTENDED_MAX_CORNER_QUALITY_PX
            ):
                extended_failures.append(
                    f"line-fit quality {corner_quality:.2f}px; extended "
                    f"limit {SMALL_TARGET_EXTENDED_MAX_CORNER_QUALITY_PX:.2f}px"
                )
            if (
                (not np.isfinite(rmse))
                or rmse > SMALL_TARGET_EXTENDED_MAX_RMSE_PX
            ):
                extended_failures.append(
                    f"RMSE {rmse:.2f}px; extended limit "
                    f"{SMALL_TARGET_EXTENDED_MAX_RMSE_PX:.2f}px"
                )
            if (
                pnp_rmse_before_ba is None
                or pnp_rmse_before_ba > SMALL_TARGET_EXTENDED_MAX_INITIAL_PNP_RMSE_PX
            ):
                pnp_text = (
                    "unknown"
                    if pnp_rmse_before_ba is None
                    else f"{pnp_rmse_before_ba:.2f}px"
                )
                extended_failures.append(
                    f"initial three-face PnP RMSE {pnp_text}; extended "
                    f"limit {SMALL_TARGET_EXTENDED_MAX_INITIAL_PNP_RMSE_PX:.1f}px"
                )
            if extended_failures:
                strict_failures.append(
                    f"corner coverage {fov_coverage:.2f}% exceeds the base "
                    "validated small-target coverage pocket "
                    f"({SMALL_TARGET_MAX_FOV_COVERAGE_PCT:.2f}% max) and "
                    "did not pass the extended-coverage quality gate: "
                    + "; ".join(extended_failures)
                )
        if not _small_target_patterns_allowed(observed_patterns):
            partial_ok = False
            pattern_deficit = None
            overcomplete_ok = False
            overcomplete_surplus = None
            trihedral_closure_ok = False
            if scale_prior_candidate_active:
                partial_ok, pattern_deficit = (
                    _scale_prior_partial_template_allowed(
                        observed_patterns,
                        n_corners,
                        rmse,
                    )
                )
                overcomplete_ok, overcomplete_surplus = (
                    _scale_prior_overcomplete_template_allowed(
                        observed_patterns,
                        n_corners,
                        rmse,
                        model_used,
                        cube_area_pct,
                        focal_px,
                    )
                )
                trihedral_closure_ok = trihedral_closure_template_ok
            if partial_ok:
                preflight.setdefault("scale_prior_candidate", {})[
                    "partial_template"
                ] = {
                    "patterns": [list(p) for p in observed_patterns],
                    "canonical_patterns": [
                        list(p) for p in SMALL_TARGET_CANONICAL_PATTERNS
                    ],
                    "step_deficit": int(pattern_deficit or 0),
                    "max_step_deficit": int(
                        SCALE_PRIOR_MAX_PARTIAL_PATTERN_STEP_DEFICIT
                    ),
                    "n_corners": int(n_corners),
                    "min_corners": int(
                        SCALE_PRIOR_MIN_PARTIAL_TEMPLATE_CORNERS
                    ),
                    "rmse_px": float(rmse),
                    "max_rmse_px": float(
                        SCALE_PRIOR_MAX_PARTIAL_TEMPLATE_RMSE_PX
                    ),
                }
                warnings.append(
                    "Accepted scale-prior partial-template candidate "
                    f"({observed_patterns}; deficit={pattern_deficit}, "
                    f"corners={n_corners}, RMSE={rmse:.2f}px)."
                )
            elif overcomplete_ok:
                preflight.setdefault("scale_prior_candidate", {})[
                    "overcomplete_template"
                ] = {
                    "patterns": [list(p) for p in observed_patterns],
                    "canonical_patterns": [
                        list(p) for p in SMALL_TARGET_CANONICAL_PATTERNS
                    ],
                    "small_face_surplus_steps": int(overcomplete_surplus or 0),
                    "max_surplus_steps": int(
                        SCALE_PRIOR_MAX_OVERCOMPLETE_SMALL_FACE_STEPS
                    ),
                    "n_corners": int(n_corners),
                    "min_corners": int(
                        SCALE_PRIOR_MIN_OVERCOMPLETE_TEMPLATE_CORNERS
                    ),
                    "max_corners": int(
                        SCALE_PRIOR_MAX_OVERCOMPLETE_TEMPLATE_CORNERS
                    ),
                    "rmse_px": float(rmse),
                    "max_rmse_px": float(
                        SCALE_PRIOR_MAX_OVERCOMPLETE_TEMPLATE_RMSE_PX
                    ),
                    "model": str(model_used),
                    "area_pct": None if cube_area_pct is None else float(cube_area_pct),
                    "max_area_pct": float(
                        SCALE_PRIOR_OVERCOMPLETE_TEMPLATE_MAX_AREA_PCT
                    ),
                }
                warnings.append(
                    "Accepted scale-prior overcomplete small-face candidate "
                    f"({observed_patterns}; surplus={overcomplete_surplus}, "
                    f"corners={n_corners}, model={model_used}, "
                    f"RMSE={rmse:.2f}px)."
                )
            elif trihedral_closure_ok:
                preflight.setdefault("scale_prior_candidate", {})[
                    "trihedral_closure_template"
                ] = {
                    "patterns": [list(p) for p in observed_patterns],
                    "allowed_patterns": [
                        list(p) for p in sorted(SCALE_PRIOR_TRIHEDRAL_CLOSURE_PATTERNS)
                    ],
                    "n_corners": int(n_corners),
                    "rmse_px": float(rmse),
                    "model": str(model_used),
                    "source": precomputed_basename,
                }
                warnings.append(
                    "Accepted scale-prior trihedral-closure template "
                    f"candidate ({observed_patterns}; corners={n_corners}, "
                    f"model={model_used}, RMSE={rmse:.2f}px)."
                )
            else:
                detail = ""
                if pattern_deficit is not None:
                    detail = (
                        f"; nearest canonical step deficit {pattern_deficit} "
                        "exceeds the scale-prior partial-template gate"
                    )
                elif overcomplete_surplus is not None:
                    detail = (
                        f"; nearest canonical overcomplete small-face surplus "
                        f"{overcomplete_surplus} exceeds the fixed-focal "
                        "scale-prior gate"
                    )
                strict_failures.append(
                    "visible grid pattern is "
                    f"{observed_patterns}; accepted small-target automatic calibration "
                    "currently requires "
                    f"{_small_target_pattern_gate_description()}"
                    f"{detail}"
                )
        if n_corners < MIN_SMALL_TARGET_CORNERS:
            strict_failures.append(
                f"only {n_corners} corners; need at least "
                f"{MIN_SMALL_TARGET_CORNERS}"
            )
        if (
            (not np.isfinite(corner_quality))
            or corner_quality > MAX_SMALL_TARGET_CORNER_QUALITY_PX
        ):
            strict_failures.append(
                f"line-fit quality {corner_quality:.2f}px; limit "
                f"{MAX_SMALL_TARGET_CORNER_QUALITY_PX:.2f}px"
            )
        small_target_rmse_limit = MAX_SMALL_TARGET_RMSE_PX
        scale_prior_rmse_relaxed = False
        if scale_prior_candidate_active and focal_px is not None:
            small_target_rmse_limit = max(
                small_target_rmse_limit,
                MAX_SCALE_PRIOR_SMALL_TARGET_RMSE_PX,
            )
            scale_prior_rmse_relaxed = (
                np.isfinite(rmse)
                and rmse > MAX_SMALL_TARGET_RMSE_PX
                and rmse <= small_target_rmse_limit
            )
            preflight.setdefault("scale_prior_candidate", {})[
                "small_target_rmse_limit_px"
            ] = float(small_target_rmse_limit)
        if (not np.isfinite(rmse)) or rmse > small_target_rmse_limit:
            strict_failures.append(
                f"RMSE {rmse:.2f}px; limit {small_target_rmse_limit:.1f}px"
            )
        elif scale_prior_rmse_relaxed:
            preflight.setdefault("scale_prior_candidate", {})[
                "relaxed_small_target_rmse"
            ] = {
                "rmse_px": float(rmse),
                "base_limit_px": float(MAX_SMALL_TARGET_RMSE_PX),
                "scale_prior_limit_px": float(small_target_rmse_limit),
            }
            warnings.append(
                "Accepted scale-prior small-target candidate with relaxed "
                f"RMSE gate ({rmse:.2f}px; base "
                f"{MAX_SMALL_TARGET_RMSE_PX:.1f}px, scale-prior "
                f"{small_target_rmse_limit:.1f}px)."
            )
        initial_pnp_limit = MAX_SMALL_TARGET_INITIAL_PNP_RMSE_PX
        if scale_prior_candidate_active and focal_px is not None:
            initial_pnp_limit = max(
                initial_pnp_limit,
                MAX_SCALE_PRIOR_INITIAL_PNP_RMSE_PX,
            )
        if (
            pnp_rmse_before_ba is not None
            and pnp_rmse_before_ba > initial_pnp_limit
        ):
            scale_prior_initial_relaxed = (
                scale_prior_candidate_active
                and focal_px is not None
                and np.isfinite(rmse)
                and rmse <= small_target_rmse_limit
                and pnp_rmse_before_ba <= MAX_SCALE_PRIOR_RELAXED_INITIAL_PNP_RMSE_PX
            )
            if scale_prior_initial_relaxed:
                preflight.setdefault("scale_prior_candidate", {})[
                    "relaxed_initial_pnp"
                ] = {
                    "initial_pnp_rmse_px": float(pnp_rmse_before_ba),
                    "base_limit_px": float(initial_pnp_limit),
                    "scale_prior_relaxed_limit_px": float(
                        MAX_SCALE_PRIOR_RELAXED_INITIAL_PNP_RMSE_PX
                    ),
                }
                warnings.append(
                    "Accepted scale-prior small-target candidate with relaxed "
                    f"initial-PnP gate ({pnp_rmse_before_ba:.2f}px; base "
                    f"{initial_pnp_limit:.1f}px, scale-prior "
                    f"{MAX_SCALE_PRIOR_RELAXED_INITIAL_PNP_RMSE_PX:.1f}px)."
                )
            else:
                strict_failures.append(
                    f"initial three-face PnP RMSE {pnp_rmse_before_ba:.2f}px; "
                    f"limit {initial_pnp_limit:.1f}px"
                )
        preflight["small_target_strict_gate"] = {
            "passed": not strict_failures,
            "failures": list(strict_failures),
            "research_override": bool(
                strict_failures and research_return_rejected
            ),
        }
        if strict_failures and not research_return_rejected:
            raise RuntimeError(
                _small_target_boundary_message(
                    cube_area_pct,
                    "; ".join(strict_failures),
                )
            )
        if strict_failures:
            warnings.append(
                "Research diagnostic only: returned a candidate rejected by "
                "the strict small-target gate: " + "; ".join(strict_failures)
            )
        elif fov_coverage > SMALL_TARGET_MAX_FOV_COVERAGE_PCT:
            warnings.append(
                "Accepted through the guarded extended small-target "
                f"coverage gate ({fov_coverage:.2f}% corner coverage; "
                f"base {SMALL_TARGET_MAX_FOV_COVERAGE_PCT:.2f}%, "
                f"extended {SMALL_TARGET_EXTENDED_MAX_FOV_COVERAGE_PCT:.2f}%)."
            )
        if not strict_failures:
            warnings.append(
                "Accepted through the strict small-target geometry gate."
            )

    if (
        focal_px is None
        and ENABLE_FOCAL_OBSERVABILITY_GATE
        and not model_used.startswith('single-cube-zhang')
    ):
        focal_profile = _focal_observability_profile(
            all_obj.reshape(-1, 3),
            all_img.reshape(-1, 2),
            (w_img, h_img),
            k1_seed=float(dist_opt[0]),
        )
        preflight["focal_observability"] = focal_profile
        if not focal_profile.get("observable", False):
            reasons = "; ".join(
                str(reason) for reason in focal_profile.get("reasons", [])
            ) or "the focal profile has no stable interior optimum"
            if scale_prior_candidate_active:
                preflight.setdefault("scale_prior_candidate", {}).setdefault(
                    "relaxed_failures", []
                ).append(
                    "focal length is not uniquely identifiable from this "
                    f"single frame ({reasons})"
                )
            elif not research_return_rejected:
                _raise_low_confidence_or_sparse_boundary(
                    "Low-confidence calibration: focal length is not identifiable "
                    f"from this single frame ({reasons}). The three-face geometry "
                    "may support pose fitting, but it does not support a unique "
                    "intrinsic calibration without a camera focal prior."
                )
            warnings.append(
                "Research diagnostic only: focal length is not identifiable "
                f"from this single frame ({reasons})."
            )
        else:
            warnings.append(
                "Single-frame focal observability gate passed: best profile focal "
                f"{float(focal_profile['best_focal_px']):.1f}px, contrast "
                f"{float(focal_profile['profile_contrast_px']):.2f}px, plateau "
                f"width {float(focal_profile['plateau_width_ratio_diag']):.2f}x "
                "image diagonal."
            )

    accepted_model_grades = _accepted_model_grade_filter()
    if accepted_model_grades:
        selected_model_grade = _model_grade_from_name(model_used)
        preflight["model_grade_ablation_gate"] = {
            "enabled": True,
            "allowed": sorted(accepted_model_grades),
            "selected_model": str(model_used),
            "selected_model_grade": selected_model_grade,
        }
        if selected_model_grade not in accepted_model_grades:
            raise RuntimeError(
                "Candidate-family ablation gate rejected the selected "
                f"model grade `{selected_model_grade}` from model "
                f"`{model_used}`; allowed grades are "
                f"{sorted(accepted_model_grades)}."
            )
        warnings.append(
            "Candidate-family ablation gate accepted selected model grade "
            f"{selected_model_grade}."
        )

    if isolated_model_grades:
        isolated_selected_grade = _model_grade_from_name(model_used)
        preflight["model_grade_isolation_gate"]["selected_model"] = str(model_used)
        preflight["model_grade_isolation_gate"]["selected_model_grade"] = (
            isolated_selected_grade
        )
        if isolated_selected_grade not in isolated_model_grades:
            raise RuntimeError(
                "Candidate-family isolation gate rejected the final "
                f"model grade `{isolated_selected_grade}` from model "
                f"`{model_used}`; isolated grades are "
                f"{sorted(isolated_model_grades)}."
            )
        warnings.append(
            "Candidate-family isolation gate accepted final model grade "
            f"{isolated_selected_grade}."
        )

    cam_pos, camera_height, downtilt = _cube_camera_pose_metrics(R_opt, t_opt)

    elapsed = time.time() - t_start
    scale_prior_info = preflight.get("scale_prior_candidate")
    if isinstance(scale_prior_info, dict) and scale_prior_info.get("enabled"):
        scale_prior_info["accepted_as_candidate"] = True
        scale_prior_info["fully_confident"] = not bool(
            scale_prior_info.get("relaxed_failures")
        )

    result = BestResult(
        K=K_opt, dist=dist_opt, R=R_opt, t=t_opt, rmse=rmse,
        fx_px=float(fx), fy_px=float(fy), skew_px=float(K_opt[0, 1]),
        cx_px=float(cx), cy_px=float(cy),
        height_mm=camera_height,
        downtilt_deg=downtilt,
        cam_position=cam_pos,
        fov_coverage_pct=fov_coverage,
        cube_area_pct=cube_area_pct,
        corner_quality=corner_quality,
        model_used=model_used,
        n_corners=n_corners, n_faces_detected=n_valid,
        elapsed_sec=elapsed, warnings=warnings,
        preflight=preflight,
    )

    if verbose:
        _print_result(result)

    return result


def _print_result(r: BestResult):
    """Pretty-print calibration result."""
    print(f"\n{'='*60}")
    print(f"  Calibration Result")
    print(f"{'='*60}")
    print(f"  Model:       {r.model_used}")
    print(f"  Faces:       {r.n_faces_detected}/3 detected, {r.n_corners} corners")
    print(f"  FOV coverage:{r.fov_coverage_pct:.0f}%")
    if r.cube_area_pct is not None:
        print(f"  Cube area:   {r.cube_area_pct:.1f}%")
    print(f"  Corner qual: {r.corner_quality:.3f} px")
    print(f"  Time:        {r.elapsed_sec:.3f}s")
    print()
    print(f"  ── Intrinsics ──")
    print(f"  fx = {r.fx_px:.4f} px    fy = {r.fy_px:.4f} px")
    print(f"  skew = {r.skew_px:.4f} px")
    print(f"  cx = {r.cx_px:.4f} px    cy = {r.cy_px:.4f} px")
    print(f"  K  = {np.array2string(r.K, precision=2, suppress_small=True)}")
    print()
    print(f"  ── Distortion [{r.model_used}] ──")
    print(f"  k1={r.dist[0]:.6f}  k2={r.dist[1]:.6f}  k3={r.dist[4]:.6f}")
    print(f"  p1={r.dist[2]:.6f}  p2={r.dist[3]:.6f}")
    print()
    print(f"  ── Extrinsics ──")
    print(f"  Rotation R = {np.array2string(r.R, precision=4, suppress_small=True)}")
    print(f"  Position   = [{r.cam_position[0]:.2f}, {r.cam_position[1]:.2f}, "
          f"{r.cam_position[2]:.2f}] mm")
    print()
    print(f"  ── Derived ──")
    print(f"  Camera height: {r.height_mm:.2f} mm")
    print(f"  Downtilt:      {r.downtilt_deg:.4f}°")
    print(f"  Reprojection RMSE: {r.rmse:.4f} px")
    if r.warnings:
        print(f"\n  ── Warnings ──")
        for w in r.warnings:
            print(f"  WARNING: {w}")
    print(f"{'='*60}")


# ═══════════════════════════════════════════════════════════════════════════

def benchmark_best(n_trials: int = 100):
    """Validate best method against ground truth."""
    from three_face_calib import generate_synthetic_data
    import tempfile

    np.random.seed(42)
    w, h = 1920, 1080
    K_gt = np.array([[1200., 0., w/2], [0., 1200., h/2], [0., 0., 1.]])

    print(f"\n{'='*70}")
    print(f"  Best Method Benchmark ({n_trials} trials, 2/3 FOV)")
    print(f"{'='*70}")

    for k1v, k2v, label in [(0.12, 0.01, 'webcam'), (0.25, 0.05, 'wide-angle')]:
        dist_gt = np.array([k1v, k2v, 0.001, -0.0005, 0.0])
        dist_mm = 305.0; elev = np.deg2rad(35); azim = np.deg2rad(35)
        cam = np.array([dist_mm * np.cos(elev) * np.sin(azim),
                        -dist_mm * np.sin(elev),
                        dist_mm * np.cos(elev) * np.cos(azim)])
        target = np.array([112.5, 75.0, 75.0])
        look = target - cam; look /= np.linalg.norm(look)
        zc = -look; xc = np.cross([0., 1., 0.], zc); xc /= np.linalg.norm(xc)
        yc = np.cross(zc, xc)
        R_gt = np.vstack([xc, yc, zc]); t_gt = -R_gt @ cam
        faces = standard_three_face_target(25.0, 9, 6)

        results = {'5-param': {'fx':[],'cx':[],'cy':[],'k1':[],'k2':[],'rmse':[]},
                   'k1-only': {'fx':[],'cx':[],'cy':[],'k1':[],'rmse':[]}}

        for _ in range(n_trials):
            detected, all_obj, all_img, _ = generate_synthetic_data(
                K_gt, R_gt, t_gt, faces,
                noise_std=0.3, image_size=(w, h), dist=dist_gt,
            )

            # Save a temporary image for the pipeline
            tmp = tempfile.NamedTemporaryFile(suffix='.png', delete=False)
            cv2.imwrite(tmp.name, np.full((h, w, 3), 128, dtype=np.uint8))
            tmp.close()

            # We can't use calibrate_best with a blank image (no corners).
            # Instead, directly test the BA with synthetic corners.
            # Simulate what happens AFTER corner detection:
            vp_labels = get_vp_labels(len(faces))
            vp_per_face = []
            for fi, df in enumerate(detected):
                face = faces[fi]; cls, rws = face.pattern_size
                rl, cl, _, _ = lines_from_chessboard_corners(
                    df.image_points, (cls, rws), use_ransac=True)
                vpx = estimate_vanishing_point(np.array(rl))
                vpy = estimate_vanishing_point(np.array(cl))
                vpx.direction_label = vp_labels[fi][0]
                vpy.direction_label = vp_labels[fi][1]
                vp_per_face.append({vp_labels[fi][0]: vpx, vp_labels[fi][1]: vpy})
            vp_avg = {}
            for label in ['X', 'Y', 'Z']:
                V = np.array([vp.v for fv in vp_per_face
                              for l, vp in fv.items() if l == label])
                vm = np.median(V, axis=0)
                if abs(vm[2]) > 1e-6: vm /= vm[2]
                vp_avg[label] = VanishingPoint(v=vm, direction_label=label)
            lo = sorted(vp_avg.keys()); vpl = [vp_avg[l] for l in lo]
            ali = {l: i for i, l in enumerate(lo)}
            op = [(ali[a], ali[b]) for a, b in [('X','Y'),('Y','Z'),('Z','X')]
                  if a in ali and b in ali]
            Ki = calibrate_intrinsics_from_vps(
                vpl, op, assume_zero_skew=True, assume_square_pixels=True,
                fix_principal_point=(w / 2, h / 2))
            Ri, ti = calibrate_extrinsics(all_obj, all_img, Ki)
            obj_f = all_obj.reshape(-1, 3).astype(np.float64)
            img_f = all_img.reshape(-1, 2).astype(np.float64)
            rvec_i = cv2.Rodrigues(Ri)[0].ravel()
            N = len(img_f)

            # 5-param
            def _res5(p):
                fx,fy,cx,cy=p[:4];k1,k2,k3,p1,p2=p[4:9];rx,ry,rz=p[9:12];tx,ty,tz=p[12:15]
                Kc=np.array([[fx,0,cx],[0,fy,cy],[0,0,1.]])
                Rc,_=cv2.Rodrigues(np.array([rx,ry,rz]));tc=np.array([tx,ty,tz])
                Xc=(Rc@obj_f.T+tc.reshape(3,1)).T;xn=Xc[:,:2]/Xc[:,2:3]
                r2=np.sum(xn**2,axis=1);r4=r2**2;r6=r2**3
                rad=1+k1*r2+k2*r4+k3*r6
                xd=xn[:,0]*rad+2*p1*xn[:,0]*xn[:,1]+p2*(r2+2*xn[:,0]**2)
                yd=xn[:,1]*rad+p1*(r2+2*xn[:,1]**2)+2*p2*xn[:,0]*xn[:,1]
                u=fx*xd+cx;v=fy*yd+cy
                res=np.hstack([u-img_f[:,0],v-img_f[:,1]])
                return np.concatenate([res,[0.05*k2/max(abs(k1),1e-6)]])
            x0_5=np.array([Ki[0,0],Ki[1,1],Ki[0,2],Ki[1,2],0.,0.,0.,0.,0.,
                           rvec_i[0],rvec_i[1],rvec_i[2],ti[0],ti[1],ti[2]])
            r5=least_squares(_res5,x0_5,method='lm',xtol=1e-12,ftol=1e-12,max_nfev=2000)
            results['5-param']['fx'].append(100*abs(r5.x[0]-K_gt[0,0])/K_gt[0,0])
            results['5-param']['cx'].append(abs(r5.x[2]-K_gt[0,2]))
            results['5-param']['cy'].append(abs(r5.x[3]-K_gt[1,2]))
            results['5-param']['k1'].append(100*abs(r5.x[4]-dist_gt[0])/abs(dist_gt[0]))
            results['5-param']['k2'].append(100*abs(r5.x[5]-dist_gt[1])/abs(dist_gt[1]))
            results['5-param']['rmse'].append(np.sqrt(np.mean(_res5(r5.x)[:2*N]**2)))

            # k1-only
            def _res1(p):
                fx,fy,cx,cy,k1=p[:5];rx,ry,rz=p[5:8];tx,ty,tz=p[8:11]
                Kc=np.array([[fx,0,cx],[0,fy,cy],[0,0,1.]])
                Rc,_=cv2.Rodrigues(np.array([rx,ry,rz]));tc=np.array([tx,ty,tz])
                Xc=(Rc@obj_f.T+tc.reshape(3,1)).T;xn=Xc[:,:2]/Xc[:,2:3];r2=np.sum(xn**2,axis=1)
                rad=1+k1*r2;xd=xn[:,0]*rad;yd=xn[:,1]*rad
                u=Kc[0,0]*xd+Kc[0,2];v=Kc[1,1]*yd+Kc[1,2]
                return np.hstack([u-img_f[:,0],v-img_f[:,1]])
            x0_1=np.array([Ki[0,0],Ki[1,1],Ki[0,2],Ki[1,2],0.,
                           rvec_i[0],rvec_i[1],rvec_i[2],ti[0],ti[1],ti[2]])
            r1=least_squares(_res1,x0_1,method='lm',xtol=1e-12,ftol=1e-12)
            results['k1-only']['fx'].append(100*abs(r1.x[0]-K_gt[0,0])/K_gt[0,0])
            results['k1-only']['cx'].append(abs(r1.x[2]-K_gt[0,2]))
            results['k1-only']['cy'].append(abs(r1.x[3]-K_gt[1,2]))
            results['k1-only']['k1'].append(100*abs(r1.x[4]-dist_gt[0])/abs(dist_gt[0]))
            results['k1-only']['rmse'].append(np.sqrt(np.mean(_res1(r1.x)**2)))

            os.unlink(tmp.name)

        print(f"\n--- {label} (k1={k1v}, k2={k2v}) ---")
        for method, keys in [('5-param', ['fx','cx','cy','k1','k2','rmse']),
                              ('k1-only', ['fx','cx','cy','k1','rmse'])]:
            vals = {k: results[method][k] for k in keys}
            parts = [f"{k}={np.mean(vals[k]):.3f}" for k in keys]
            if method == 'k1-only':
                parts.append("k2=0(fixed)")
            print(f"  {method}: {', '.join(parts)}")

    print(f"\n  Benchmark complete.")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--benchmark":
        benchmark_best(100)
    elif len(sys.argv) > 1:
        import argparse
        p = argparse.ArgumentParser(description='Best Calibration Method')
        p.add_argument('image', help='Path to calibration image')
        p.add_argument('square', type=float, default=DEFAULT_SQUARE_SIZE_MM, nargs='?',
                       help='Checkerboard square edge length in physical units, default 25.0 mm for the current dataset')
        p.add_argument('--cols', type=int, default=9)
        p.add_argument('--rows', type=int, default=6)
        p.add_argument('--k1-only', action='store_true',
                       help='Use k1-only distortion model')
        p.add_argument('--focal', type=float,
                       help='Known focal length in pixels (from EXIF)')
        p.add_argument('--k1-prior', type=float,
                       help='Known k1 radial distortion from group calibration')
        p.add_argument('--no-auto-orient', action='store_true',
                       help='Do not auto-select per-face grid orientation flips')
        args = p.parse_args()

        result = calibrate_best(
            args.image, args.square, args.cols, args.rows,
            auto_orient_faces=not args.no_auto_orient,
            k1_only=args.k1_only,
            focal_px=args.focal,
            k1_prior=args.k1_prior,
        )

        # Export JSON
        out = {
            'K': result.K.tolist(),
            'dist': result.dist.tolist(),
            'R': result.R.tolist(),
            't': result.t.tolist(),
            'fx_px': float(result.fx_px), 'fy_px': float(result.fy_px),
            'skew_px': float(result.skew_px),
            'cx_px': float(result.cx_px), 'cy_px': float(result.cy_px),
            'height_mm': float(result.height_mm),
            'downtilt_deg': float(result.downtilt_deg),
            'rmse_px': float(result.rmse),
            'model': result.model_used,
            'fov_coverage_pct': float(result.fov_coverage_pct),
            'cube_area_pct': (
                None if result.cube_area_pct is None
                else float(result.cube_area_pct)
            ),
            'preflight': result.preflight,
        }
        print(f"\nJSON: {json.dumps(out, indent=2)}")
    else:
        benchmark_best(100)
