"""Matched staged solver, all nonempty subsets of original 0820 five-image sets."""
import itertools, time, traceback, hashlib
from pathlib import Path
import numpy as np
import cv2
import trained_camera_model as t
import evaluate_trained_camera_model as ev
import evaluate_planar_blind_comparison as ep
from evaluate_planar_per_pose_controlled import image_dir
from run_stability_verification_20260914 import ROOT,SPLIT,BASE,POSES,read,save
OUT=ROOT/'output/information_budget_20260915'

def run():
    cv2.setNumThreads(1)
    save(OUT/'protocol.json',dict(source_sha256=hashlib.sha256((ROOT/'trained_camera_model.py').read_bytes()).hexdigest(),dataset=str(SPLIT),budgets=[1,2,3,4,5],subsets='all 31 nonempty subsets per original five-image training set; overlapping, not independent replicates',solver='same float64 staged local homography plus fixed-K k1+k2 refinement at every budget',prior='unchanged production ratio and monotonicity priors',scope='conditional cached-observation research, not production acceptance; no Zhang parameters; existing test data already consulted',regions='observed pixel elliptical radius from image center divided by half image width/height; bins [0,.4),[.4,.7),[.7,infinity); fixed across models, not lens-normalized radius',evaluation='all original held-out 2D and 3D images, five paired corner splits; pooled held-out corner RMSE per image/region; retain failure counts; no application tolerance asserted'))
    for pi,pose in enumerate(POSES):
        job=read(ROOT/'output/stability_verification_20260914/models'/pose/'ratio_base/job.json')
        raw=[t._load_cache(x['cache'],x['image'],None) for x in job['selected']]
        samples=[];failed=[]
        for kind in ['2D','3D']:
            folder=image_dir(SPLIT,pose) if kind=='2D' else SPLIT/'test'/pose/'3D'
            for n,p in enumerate(sorted(folder.glob('*.jpg'))):
                try:
                    if kind=='2D':
                        im,detail=ep.detect_checker(p)
                        if im is None: raise ValueError(detail)
                        obj=ep.object_points(25);ids=np.zeros(len(obj),int)
                    else:
                        h=hashlib.sha256(p.read_bytes()).hexdigest()
                        cache=list((BASE/'test_correspondence_cache'/pose).glob(h+'_sq25_*.npz'))
                        assert len(cache)==1
                        cv2.setRNGSeed(20260912)
                        s=t.extract_correspondences(str(p),25,correspondence_cache_path=str(cache[0]),minimum_usable_faces=1)
                        obj,im=s.object_points,s.image_points;ids=ev.face_ids(obj)
                    w,h=raw[0].image_size
                    rho=np.linalg.norm((im.reshape(-1,2)-[w/2,h/2])/[w/2,h/2],axis=1)
                    bins=np.digitize(rho,[.4,.7])
                    rng=np.random.default_rng(915000+pi*1000+n)
                    splits=[ev.stratified_holdout(ids,rng,.2,4) for _ in range(5)]
                    samples.append((kind,p.name,obj,im,bins,splits))
                except Exception as e: failed.append(dict(kind=kind,image=str(p),error=str(e)))
        save(OUT/pose/'test_manifest.json',dict(images=[dict(kind=s[0],image=s[1]) for s in samples],failures=failed,training=job['selected']))
        for budget in range(1,6):
            for indices in itertools.combinations(range(5),budget):
                dest=OUT/pose/('subset_'+''.join(map(str,indices))+'.json')
                if dest.exists():continue
                start=time.perf_counter();result=dict(pose=pose,budget=budget,indices=indices,production_accepted=None)
                try:
                    chosen=[raw[i] for i in indices]
                    obs=t._local_face_observations(chosen,25)
                    result['faces_per_image']=[len(t._local_face_observations([s],25)) for s in chosen]
                    points=np.concatenate([o['points'].reshape(-1,2) for o in obs])
                    w,h=chosen[0].image_size
                    result['coverage']=dict(points=len(points),usable_faces=len(obs),radial_quantiles=np.quantile(np.linalg.norm((points-[w/2,h/2])/[w/2,h/2],axis=1),[0,.25,.5,.75,1]).tolist(),bbox_fraction=(np.ptp(points,axis=0)/[w,h]).tolist())
                    cv2.setRNGSeed(20260912)
                    K,d,diag=t._fit_partial_planar_model(chosen,25,2)
                    result.update(completed=True,cameraMatrix=K.tolist(),distCoeffs=d.tolist(),diagnostics=diag)
                    rows=[]
                    for kind,name,obj,im,bins,splits in samples:
                        solver=ep if kind=='2D' else ev
                        groups=[[],[],[]];success=0
                        for r,(tr,te) in enumerate(splits):
                            cv2.setRNGSeed(915000+r)
                            p=solver.solve_pose(obj,im,tr,K,d)
                            if p is None:continue
                            errors=solver.project_errors(obj,im,te,p,K,d)
                            if not np.all(np.isfinite(errors)):continue
                            success+=1
                            for b in range(3):groups[b].extend(errors[bins[te]==b].tolist())
                        rows.append(dict(kind=kind,image=name,successful_trials=success,total_trials=5,regions=[dict(bin=b,n=len(g),rmse=float(np.sqrt(np.mean(np.square(g)))) if g else None) for b,g in enumerate(groups)]))
                    result['evaluation']=rows
                except Exception as e:result.update(completed=False,error=str(e),traceback=traceback.format_exc())
                result['elapsed_s']=time.perf_counter()-start
                save(dest,t._finite_json_value(result))
                print(pose,indices,result['completed'],round(result['elapsed_s'],2),flush=True)

if __name__=='__main__':run()
