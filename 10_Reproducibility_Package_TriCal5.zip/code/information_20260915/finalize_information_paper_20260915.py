from pathlib import Path
import shutil,json,hashlib,zipfile
ROOT=Path(__file__).resolve().parents[1]
P=Path('C:/Users/15808/Desktop/三维/TriCal5_Submission_20260910')
T=P/'09_LaTeX_Source_TriCal5'
C=P/'10_Reproducibility_Package_TriCal5/code/information_20260915'
D=P/'11_Processed_Data_TriCal5/information_20260915'
C.mkdir(parents=True,exist_ok=True);D.mkdir(parents=True,exist_ok=True)
for name in ['run_information_budget_20260915.py','summarize_information_budget_20260915.py','summarize_strict_single_20260915.py','run_stability_verification_20260914.py','trained_camera_model.py','evaluate_trained_camera_model.py','evaluate_planar_blind_comparison.py','evaluate_planar_per_pose_controlled.py']:
    shutil.copy2(ROOT/name,C/name)
for name in ['revise_information_paper_20260915.py','finalize_information_paper_20260915.py']:
    shutil.copy2(ROOT/'output'/name,C/name)
for exp in ['information_budget_20260915','stability_verification_20260914']:
    source=ROOT/'output'/exp
    for f in source.rglob('*'):
        if f.is_file() and f.suffix in ['.json','.md','.py'] and '.trihedral_correspondence_cache' not in str(f) and 'prediction_screen' not in f.parts:
            dest=D/exp/f.relative_to(source);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
for folder in [P,T,C,D]:
    if folder!=T:shutil.copy2(T/'REVISION_20260915.md',folder/'REVISION_20260915.md')
shutil.copy2(T/'main.pdf',P/'02_Main_Manuscript_TriCal5.pdf')
shutil.copy2(T/'supplement.pdf',P/'04_Supplementary_Appendix.pdf')
(P/'07_Highlights_TriCal5.txt').write_text('Few-shot calibration pools locally ordered trihedral checker observations.\nSuccessful single-image fits show regional pixel-level predictive utility.\nDifferent radial coefficient pairs can retain similar held-out predictions.\nMatched ablations and perturbations expose information-dependent sensitivity.\nFive images are a tested budget, not a universal sufficiency guarantee.\n',encoding='utf-8')
for name in ['09_LaTeX_Source_TriCal5','10_Reproducibility_Package_TriCal5','11_Processed_Data_TriCal5']:
    with zipfile.ZipFile(P/(name+'.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted((P/name).rglob('*')):
            if f.is_file():z.write(f,f.relative_to(P/name))
    with zipfile.ZipFile(P/(name+'.zip')) as z:assert z.testzip() is None
    print(name,'verified',flush=True)
files=[dict(path=f.relative_to(P).as_posix(),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in sorted(P.rglob('*')) if f.is_file() and f.name!='file_manifest.json']
(P/'file_manifest.json').write_text(json.dumps(files,ensure_ascii=False,indent=2),encoding='utf-8')
print('manifest',len(files),flush=True)
