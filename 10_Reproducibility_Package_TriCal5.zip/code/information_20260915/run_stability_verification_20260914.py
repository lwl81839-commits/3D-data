"""Frozen-source 0820 verification. No production models are overwritten."""
from pathlib import Path
import os,sys,json,hashlib,shutil,subprocess,time,traceback
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parent
SPLIT=Path('E:/Data_image_3d/data_3D_0820_split_model_3D5_Zhang2D20_each_pose_quality_gated')
BASE=SPLIT/'validation_ours_vs_zhang'
POSES=['15_0.528','30_0.827','45_0.827','45_1.155','60_1.155']
OUT=ROOT/'output/stability_verification_20260914'
def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def prepare():
    import numpy as np
    source=(ROOT/'trained_camera_model.py').read_text(encoding='utf-8')
    assert 'object_groups = [np.asarray(obj, dtype=np.float64)' in source
    needle='                max(0.0, abs(k2) - allowed_k2)\n                / K2_COEFFICIENT_HINGE_SIGMA'
    assert source.count(needle)==1
    no=source.replace(needle,'                0.0  # ratio hinge removed; other penalties retained')
    a=no.index('        initial_k2_limit = (');b=no.index('    for rvec, tvec in zip(initial_rvecs, initial_tvecs):',a)
    no=no[:a]+'        values.append(float(np.clip(initial_dist[1], -K2_OPTIMIZATION_BOUND, K2_OPTIMIZATION_BOUND)))\n'+no[b:]
    no=no.replace('"method": "k2_to_k1_coefficient_ratio_soft_hinge",','"method": "ratio_removed_monotonicity_retained",')
    for variant,s in [('ratio',source),('no_ratio',no)]:
        d=OUT/'code'/variant;d.mkdir(parents=True,exist_ok=True);(d/'trained_camera_model.py').write_text(s,encoding='utf-8')
    jobs=[]
    for pi,pose in enumerate(POSES):
        imgs=sorted((SPLIT/'train'/pose/'3D').glob('*.jpg'));assert len(imgs)==5
        selected=[]
        for p in imgs:
            h=hashlib.sha256(p.read_bytes()).hexdigest();cs=list((BASE/'per_pose_models'/pose/'.trihedral_correspondence_cache').glob(h+'_sq25_*.npz'));assert len(cs)==1
            selected.append(dict(image=str(p),sha256=h,cache=str(cs[0]),cache_sha256=hashlib.sha256(cs[0].read_bytes()).hexdigest()))
        specs=[dict(tag='base',sigma=0.,rep=0,omit=None)]
        specs += [dict(tag=f'noise{s}_{r}',sigma=s,rep=r,omit=None) for s in [.1,.3] for r in range(3)]
        specs += [dict(tag=f'omit{k}',sigma=0.,rep=0,omit=k) for k in range(5)]
        for variant in ['ratio','no_ratio']:
            for spec in specs:
                name=variant+'_'+spec['tag'];d=OUT/'models'/pose/name
                keep=[x for k,x in enumerate(selected) if k!=spec['omit']]
                cache=d/'.trihedral_correspondence_cache';cache.mkdir(parents=True,exist_ok=True)
                rng=np.random.default_rng(914000+pi*100+spec['rep'])
                for x in keep:
                    target=cache/Path(x['cache']).name
                    if spec['sigma']:
                        with np.load(x['cache'],allow_pickle=True) as z:payload={k:z[k] for k in z.files}
                        groups=payload['image_points'].copy()
                        for i,g in enumerate(groups):
                            q=np.asarray(g,dtype=float);groups[i]=q+rng.normal(0,spec['sigma'],q.shape)
                        payload['image_points']=groups;np.savez_compressed(target,**payload)
                    else:shutil.copy2(x['cache'],target)
                j=dict(pose=pose,name=name,variant=variant,selected=keep,**spec);save(d/'job.json',j);jobs.append(j)
    save(OUT/'protocol.json',dict(source_sha256=hashlib.sha256(source.encode()).hexdigest(),jobs=jobs,scope='existing-data verification, not new blind testing',no_zhang_training=True,noise='independent Gaussian pixel perturbations; identical paired noise; assumed levels, not measured detector noise',omission='four-image sensitivity, not independent five-image acquisition',ablation='remove ratio initial clipping and ratio hinge only; other bounds and penalties retained',strict_three_face_claim=False,original_models_untouched=True))
    shutil.copy2(ROOT/'run_stability_verification_20260914.py',OUT/'code/driver_snapshot.py')
    return jobs
def worker(pose,name):
    d=OUT/'models'/pose/name;j=read(d/'job.json');sys.path.insert(0,str(OUT/'code'/j['variant']))
    import cv2
    cv2.setNumThreads(1);cv2.setRNGSeed(20260912)
    import trained_camera_model as t
    start=time.perf_counter()
    try:
        m=t.train_camera_model([x['image'] for x in j['selected']],25,str(d/'trained_camera_model.json'),distortion_model='k1_k2')
        m['verification']=dict(variant=j['variant'],sigma_px=j['sigma'],ratio_initial_clipping=j['variant']=='ratio',ratio_penalty=j['variant']=='ratio',scope='diagnostic unless accepted; no production replacement')
        t.save_camera_model(m,str(d/'trained_camera_model.json'))
        save(d/'status.json',dict(completed=True,accepted=m['accepted'],elapsed_s=time.perf_counter()-start))
    except Exception as e:save(d/'status.json',dict(completed=False,accepted=False,error=str(e),traceback=traceback.format_exc(),elapsed_s=time.perf_counter()-start))
def run(j):
    d=OUT/'models'/j['pose']/j['name']
    if (d/'status.json').exists():return read(d/'status.json')
    logs=OUT/'logs';logs.mkdir(exist_ok=True)
    env=os.environ.copy();env.update(PYTHONPATH=str(ROOT),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONIOENCODING='utf-8')
    with (logs/(j['pose']+'_'+j['name']+'.log')).open('w',encoding='utf-8') as f:
        p=subprocess.run([sys.executable,__file__,'worker',j['pose'],j['name']],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    result=read(d/'status.json') if (d/'status.json').exists() else dict(completed=False,returncode=p.returncode)
    print(j['pose'],j['name'],result,flush=True);return result
if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'base'
    if mode=='worker':worker(*sys.argv[2:4])
    else:
        jobs=read(OUT/'protocol.json')['jobs'] if (OUT/'protocol.json').exists() else prepare()
        jobs=[j for j in jobs if (j['tag']=='base')==(mode=='base')] if mode in ['base','sensitivity'] else jobs
        with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(run,jobs))
