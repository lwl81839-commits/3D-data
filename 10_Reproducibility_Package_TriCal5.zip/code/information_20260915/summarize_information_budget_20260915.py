"""Descriptive ranges, never choose models using test scores."""
from run_information_budget_20260915 import OUT,POSES,read,save
import numpy as np
def run():
    lines=['# 0820 matched-solver image-budget experiment','','All original five-image subsets. Existing-data exploratory evaluation, not fresh blind testing.','Pixel-radius regions: center <0.4, middle 0.4–0.7, outer >=0.7. Elliptical radius uses image dimensions, not estimated intrinsics.','No universal accuracy threshold is assumed. Production acceptance is not evaluated by this diagnostic fitter.','','|Configuration|Images|Completed/expected|Type|Region|Median-error range across subsets (px)|Successful/attempted pose trials|','|---|---|---|---|---|---|---|']
    records=[]
    import math
    for pose in POSES:
        models=[read(p) for p in sorted((OUT/pose).glob('subset_*.json'))]
        for n in range(1,6):
            group=[m for m in models if m['budget']==n];done=[m for m in group if m['completed']]
            for kind in ['2D','3D']:
                for b,label in enumerate(['center','middle','outer']):
                    vals=[];ok=total=0
                    for m in done:
                        rows=[r for r in m['evaluation'] if r['kind']==kind]
                        es=[r['regions'][b]['rmse'] for r in rows if r['regions'][b]['rmse'] is not None]
                        ok+=sum(r['successful_trials'] for r in rows);total+=sum(r['total_trials'] for r in rows)
                        if es:vals.append(float(np.median(es)))
                    rec=dict(pose=pose,budget=n,recorded=len(group),completed=len(done),expected=math.comb(5,n),kind=kind,region=label,model_medians=vals,successful_trials=ok,total_trials=total)
                    records.append(rec)
                    span=f'{min(vals):.4f}–{max(vals):.4f}' if vals else 'NA'
                    lines.append(f'|{pose}|{n}|{len(done)}/{math.comb(5,n)}|{kind}|{label}|{span}|{ok}/{total}|')
    lines.extend(['','Ranges are descriptive across overlapping subsets, not confidence intervals. Five images have only one subset, so zero subset range at five is NOT evidence of stability. Pose success counts cover each geometry, not region-specific independent trials. A region can have no observed corners; no accuracy is inferred there.','Single-image fits require at least three usable local homographies; this is not the same as verified full rigid three-face consensus. Insufficient inputs remain recorded.','Training and evaluation times here include cached extraction/pose evaluation as stated in individual files; not an end-to-end GUI timing benchmark.'])
    save(OUT/'summary.json',records)
    (OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
if __name__=='__main__':run()
