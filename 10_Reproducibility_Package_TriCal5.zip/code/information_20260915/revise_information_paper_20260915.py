from pathlib import Path
P=Path('C:/Users/15808/Desktop/三维/TriCal5_Submission_20260910')
T=P/'09_LaTeX_Source_TriCal5'
p=T/'main.tex';s=p.read_text(encoding='utf-8')
s=s.replace('\\subsection{Measured trihedral target}','\\input{predictive_scope.tex}\n\n\\subsection{Measured trihedral target}')
a=s.index('\\subsection{Estimated camera models}');b=s.index('\\subsection{External cross-camera results}',a)
(T/'historical_primary_results.tex').write_text(s[a:b],encoding='utf-8')
s=s[:a]+'\\input{current_results.tex}\n\n'+s[b:]
a=s.index('\\subsection{External cross-camera results}');b=s.index('\\input{robustness_main_summary.tex}',a)
(T/'external_full_record.tex').write_text(s[a:b],encoding='utf-8')
s=s[:a]+r'''\subsection{Camera-specific reuse at 30 degrees}
On two additional cameras, fresh five-image fits gave planar/cuboid medians of 0.714/2.064 pixels for A1 and 0.568/1.741 pixels for A2. The corresponding MATLAB values were 0.334/2.003 and 0.446/1.851 pixels. A1 cuboid prediction was close to the reference, whereas A2 had lower median error. These are historical-source results, not a D retraining. They support camera-specific method reuse, not parameter transfer. This main-text focus on 30 degrees is descriptive and post hoc. The complete record, including the adverse 45-degree outcomes, remains in Supplementary Section S11.

'''+s[b:]
a=s.index('The external planar test sets contained');b=s.index('\\subsection{Metrics}',a)
s=s[:a]+'The complete external acquisition record is retained in Supplementary Section S11. The main text emphasizes the two 30-degree configurations; this emphasis was not prespecified.\n\n'+s[b:]
s=s.replace('\\input{discussion_readable.tex}','\\input{discussion_information.tex}').replace('\\input{claim_evidence_alignment.tex}','\\input{questions_information.tex}')
p.write_text(s,encoding='utf-8')
p=T/'supplement.tex';s=p.read_text(encoding='utf-8')
s=s.replace('A corrected-version budget curve and ratio-prior ablation remain outstanding.','The corrected ratio ablation and an original-pool subset audit are available in Section S10. A budget curve with a uniform strict-three-face input standard remains outstanding.')
s=s.replace('\\end{document}',r'''\section{Corrected information-budget and stability record}
\input{information_supplement.tex}
\section{Complete external-camera record}
These historical results are preserved for transparency. The main-text emphasis on 30 degrees is not a prespecified exclusion protocol. No acquisition fault is asserted without verification.
\input{external_full_record.tex}
\section{Historical primary comparison}
These L results retain their original model identities. Their dimensional metrics must not be attributed to the corrected D models.
\input{historical_primary_results.tex}
\end{document}''').replace('\\date{13 September 2026}','\\date{15 September 2026}')
p.write_text(s,encoding='utf-8')
