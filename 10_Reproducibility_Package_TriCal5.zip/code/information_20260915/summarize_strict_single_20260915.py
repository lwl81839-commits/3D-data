import json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/information_budget_20260915'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
audit=read(ROOT/'output/single_frame_k1_experiment/training_three_face_audit.json')
good={(x['pose'],Path(x['image']).name) for x in audit if x.get('strict_three_face')}
lines=['# Strict-three-face single-image subset results','','Eligibility uses archived strict rigid three-face audit; fitting uses current staged solver. No five-image parameters used. Missing local patches are implementation incompatibility, not failed single-image theory. Regions use fixed elliptical pixel radius, not physical field of view. Values are medians across images of pooled held-out point RMSE. Five repeated splits per image. Existing-data exploratory evaluation.','']
for folder in sorted(OUT.iterdir()):
    if not folder.is_dir() or not (folder/'test_manifest.json').exists():continue
    manifest=read(folder/'test_manifest.json')
    for i,tr in enumerate(manifest['training']):
        name=Path(tr['image']).name
        if (folder.name,name) not in good:continue
        m=read(folder/f'subset_{i}.json')
        lines.append(f'## {folder.name} / {name}\n')
        if not m['completed']:
            lines.append('Not fitted: '+m.get('error','unknown')+'\n');continue
        lines.append(f"k1,k2 = {m['distCoeffs'][:2]}\n")
        for kind in ['2D','3D']:
            rows=[r for r in m['evaluation'] if r['kind']==kind]
            lines.append(f"{kind}: pose trials {sum(r['successful_trials'] for r in rows)}/{5*len(rows)}\n")
            for b,label in enumerate(['center','middle','outer']):
                vals=[r['regions'][b]['rmse'] for r in rows if r['regions'][b]['rmse'] is not None]
                lines.append(f'- {label}: images={len(vals)}, median_px={np.median(vals) if vals else None}')
            lines.append('')
(OUT/'STRICT_SINGLE_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
print('\n'.join(lines))
