#!/usr/bin/env python3
"""
Comprehensive batch analysis of all real calibration images.
"""

import sys, os, re, json, time, zipfile, io, tempfile
from collections import defaultdict
import numpy as np
import cv2

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from three_face_calib import preprocess_image


# ─── DOCX Parsing ────────────────────────────────────────────────────────────

def parse_all_docx(zip_path):
    """Parse all DOCX files from zip."""
    import docx
    zf = zipfile.ZipFile(zip_path)
    per_image_gt = {}
    zhang_gt = None

    for info in zf.filelist:
        if not info.filename.endswith('.docx'):
            continue
        content = zf.read(info.filename)
        tmp = '_parse_tmp.docx'
        with open(tmp, 'wb') as f:
            f.write(content)
        try:
            doc = docx.Document(tmp)
            text = '\n'.join([p.text for p in doc.paragraphs])
            if 'zhang' in info.filename.lower():
                zhang_gt = _parse_zhang(text)
            else:
                results = _parse_calib_log(text)
                per_image_gt.update(results)
        finally:
            try: os.unlink(tmp)
            except: pass
    zf.close()
    return per_image_gt, zhang_gt


def _parse_zhang(text):
    result = {}
    k_sec = re.search(r'1\.0e\+03\s*\*\s*\n(.*?)\n(.*?)\n(.*?)(?=\n\n|\n>>)', text, re.DOTALL)
    if k_sec:
        scale = 1000.0
        r1 = [float(x)*scale for x in re.findall(r'[-\d.]+', k_sec.group(1))]
        r2 = [float(x)*scale for x in re.findall(r'[-\d.]+', k_sec.group(2))]
        r3 = [float(x)*scale for x in re.findall(r'[-\d.]+', k_sec.group(3))]
        if len(r1)>=3 and len(r2)>=3 and len(r3)>=3:
            result = {'fx': r1[0], 'fy': r2[1], 'cx': r3[0], 'cy': r3[1]}
    dist_match = re.search(r'ans\s*=\s*\n\s*([-\d.]+)\s+([-\d.]+)', text)
    if dist_match:
        result['k1'] = float(dist_match.group(1))
        result['k2'] = float(dist_match.group(2))
        result['p1'] = 0.0; result['p2'] = 0.0; result['k3'] = 0.0
    return result


def _parse_calib_log(text):
    results = {}
    entries = re.split(r'\n(?=(?:[\w]+\.jpg|t_\d+_\d+(?:\.jpg)?)(?:\s|\n|$))', text)
    for entry in entries:
        img_match = re.search(r'^((?:[\w]+\.jpg|t_\d+_\d+(?:\.jpg)?))\b', entry, re.MULTILINE)
        if not img_match:
            continue
        img = img_match.group(1)
        if not img.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
            img = f"{img}.jpg"

        fx = fy = cx = cy = k1 = k2 = p1 = p2 = k3 = rms = None
        accepted = None

        k_blocks = list(re.finditer(
            r'(K_final|K_k1|K0|K_line)\s*=\s*\n\s*\[\[([^\]]+)\]\s*\n\s*\[([^\]]+)\]\s*\n\s*\[([^\]]+)\]\]',
            entry
        ))
        for prefix in ['K_final', 'K_k1', 'K0']:
            for m in k_blocks:
                if m.group(1) == prefix:
                    r1 = [float(x) for x in re.findall(r'[-\d.]+(?:e[+-]\d+)?', m.group(2))]
                    r2 = [float(x) for x in re.findall(r'[-\d.]+(?:e[+-]\d+)?', m.group(3))]
                    r3 = [float(x) for x in re.findall(r'[-\d.]+(?:e[+-]\d+)?', m.group(4))]
                    if len(r1)==3 and len(r2)==3 and len(r3)==3:
                        fx, cx = r1[0], r1[2]
                        fy, cy = r2[1], r2[2]
                    break
            if fx is not None:
                break

        for pat in [r'distCoeffs\s*=\s*\[([^\]]+)\]', r'dist_k1\s*=\s*\[([^\]]+)\]',
                     r'dist_line\s*=\s*\[([^\]]+)\]', r'k0\s*=\s*\[([^\]]+)\]']:
            dm = re.search(pat, entry)
            if dm:
                d_nums = [float(x) for x in re.findall(r'[-\d.]+(?:e[+-]\d+)?', dm.group(1))]
                if len(d_nums) >= 2:
                    k1, k2 = d_nums[0], d_nums[1]
                    if len(d_nums) >= 5: p1, p2, k3 = d_nums[2], d_nums[3], d_nums[4]
                break

        for pat in [r'rms_px\s*=\s*([\d.]+)', r'[Rr][Mm][Ss]_k1\s*=\s*([\d.]+)',
                     r'RMS0\s*=\s*([\d.]+)']:
            rm = re.search(pat, entry)
            if rm:
                val = float(rm.group(1))
                if val < 5000: rms = val
                break

        acc_match = re.search(r'accepted\s*=\s*(True|False)', entry)
        if acc_match:
            accepted = acc_match.group(1) == 'True'

        quality_fail = bool(re.search(
            r'(三面物理几何质量门控失败|Stage 2A.*未通过|回退到 Stage 1|本次不继续标定)', entry))

        quick_fail = bool(re.search(r'(未检测到|三个面中至少有一个没有检测到|\.\.[\s]*$)', entry))

        if fx is not None:
            results[img] = {
                'fx': fx, 'fy': fy, 'cx': cx, 'cy': cy,
                'k1': k1 if k1 is not None else 0.0,
                'k2': k2 if k2 is not None else 0.0,
                'p1': p1 if p1 is not None else 0.0,
                'p2': p2 if p2 is not None else 0.0,
                'k3': k3 if k3 is not None else 0.0,
                'rms_px': rms,
                'accepted': accepted if accepted is not None else (not quality_fail),
            }
        elif quick_fail:
            results[img] = {'failed': True, 'reason': 'detection_failed'}
        elif quality_fail:
            results[img] = {'failed': True, 'reason': 'quality_gate'}

    return results


# ─── Detection Analysis ──────────────────────────────────────────────────────

def analyze_detection(gray, verbose=False):
    """Test what patterns can be detected with sequential masking."""
    enhanced = preprocess_image(gray)
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    h, w = gray.shape[:2]

    face_configs = [
        {'name': 'XY', 'patterns': [(9,6), (9,5), (8,6)]},
        {'name': 'XZ', 'patterns': [(9,6), (8,4), (8,5), (7,4), (6,6), (6,5)]},
        {'name': 'YZ', 'patterns': [(6,5), (5,5), (5,4), (6,6), (4,5), (4,4)]},
    ]

    mask = np.ones((h, w), dtype=np.uint8) * 255
    detected = []

    for cfg in face_configs:
        found_pat = None
        for pat in cfg['patterns']:
            search = enhanced.copy()
            search[mask == 0] = 0
            ok, corners = cv2.findChessboardCorners(search, pat, flags=flags)
            if not ok:
                continue
            c = corners.reshape(-1, 2)
            x_min, x_max = int(c[:,0].min()), int(c[:,0].max())
            y_min, y_max = int(c[:,1].min()), int(c[:,1].max())

            overlap = False
            for prev in detected:
                if prev['pattern'] is None: continue
                px1, px2, py1, py2 = prev['bbox']
                ix1, ix2 = max(x_min, px1), min(x_max, px2)
                iy1, iy2 = max(y_min, py1), min(y_max, py2)
                if ix1 < ix2 and iy1 < iy2:
                    inter = (ix2-ix1)*(iy2-iy1)
                    area = (x_max-x_min)*(y_max-y_min)
                    if area > 0 and inter/area > 0.3:
                        overlap = True; break

            if not overlap:
                found_pat = pat
                detected.append({
                    'name': cfg['name'], 'pattern': pat,
                    'bbox': (x_min, y_min, x_max, y_max),
                    'area': (x_max-x_min)*(y_max-y_min),
                    'n_corners': len(c),
                })
                pad = 30
                y1, y2 = max(0, y_min-pad), min(h, y_max+pad)
                x1, x2 = max(0, x_min-pad), min(w, x_max+pad)
                mask[y1:y2, x1:x2] = 0
                break

        if not found_pat:
            detected.append({'name': cfg['name'], 'pattern': None, 'bbox': (0,0,0,0)})

    return detected


# ─── Main Report ─────────────────────────────────────────────────────────────

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--zip', default='材料.zip')
    ap.add_argument('--output', default='batch_results')
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--groups', nargs='+', default=None)
    args = ap.parse_args()

    os.makedirs(args.output, exist_ok=True)

    # ── Parse GT ──
    print("Parsing DOCX ground truth...")
    gt_data, zhang_gt = parse_all_docx(args.zip)
    n_gt_ok = sum(1 for v in gt_data.values() if 'fx' in v)
    n_gt_fail = sum(1 for v in gt_data.values() if v.get('failed'))
    print(f"  Per-image results: {len(gt_data)} ({n_gt_ok} with K, {n_gt_fail} failed)")

    if zhang_gt:
        print(f"  Zhang ref: fx={zhang_gt.get('fx','?'):.1f} fy={zhang_gt.get('fy','?'):.1f} "
              f"k1={zhang_gt.get('k1','?'):.4f}")

    # ── Load images ──
    print(f"\nLoading images from {args.zip}...")
    zf = zipfile.ZipFile(args.zip)
    images_by_group = defaultdict(list)
    for info in zf.filelist:
        if not info.filename.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
            continue
        parts = info.filename.split('/')
        group = parts[-2] if len(parts) >= 2 else 'root'
        if args.groups and group not in args.groups:
            continue
        img_bytes = zf.read(info.filename)
        images_by_group[group].append((os.path.basename(info.filename), img_bytes))
    zf.close()

    for g in sorted(images_by_group):
        imgs = images_by_group[g]
        if args.limit > 0: imgs = imgs[:args.limit]
        images_by_group[g] = imgs
        print(f"  {g}: {len(imgs)} images")

    # ── Analyze detection ──
    print(f"\n{'='*80}")
    print(f"  DETECTION ANALYSIS")
    print(f"{'='*80}")

    all_detection = {}
    for group in sorted(images_by_group):
        print(f"\n  --- {group} ---")
        group_stats = {'total': len(images_by_group[group]),
                       'n_xy': 0, 'n_xz': 0, 'n_yz': 0,
                       'n_at_least_1': 0, 'n_at_least_2': 0, 'n_all_3': 0}

        for img_name, img_bytes in images_by_group[group]:
            arr = np.frombuffer(img_bytes, dtype=np.uint8)
            img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            if img is None: continue
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            detected = analyze_detection(gray)

            n_found = sum(1 for d in detected if d['pattern'] is not None)
            group_stats['n_at_least_1'] += (n_found >= 1)
            group_stats['n_at_least_2'] += (n_found >= 2)
            group_stats['n_all_3'] += (n_found >= 3)

            for d in detected:
                if d['pattern']:
                    group_stats[f'n_{d["name"].lower()}'] += 1

            gt = gt_data.get(img_name, {})
            all_detection[f"{group}/{img_name}"] = {
                'detected': [d['name'] for d in detected if d['pattern']],
                'patterns': [d['pattern'] for d in detected if d['pattern']],
                'has_gt': 'fx' in gt,
                'gt_failed': gt.get('failed', False),
            }

        n = group_stats['total']
        print(f"    At least 1 face: {group_stats['n_at_least_1']}/{n} ({100*group_stats['n_at_least_1']/n:.0f}%)")
        print(f"    At least 2 faces: {group_stats['n_at_least_2']}/{n} ({100*group_stats['n_at_least_2']/n:.0f}%)")
        print(f"    All 3 faces: {group_stats['n_all_3']}/{n} ({100*group_stats['n_all_3']/n:.0f}%)")
        print(f"    XY(top): {group_stats['n_xy']}/{n}, XZ(right): {group_stats['n_xz']}/{n}, YZ(left): {group_stats['n_yz']}/{n}")

    # ── GT Statistics ──
    print(f"\n{'='*80}")
    print(f"  GROUND TRUTH STATISTICS (from DOCX)")
    print(f"{'='*80}")

    gt_by_group = defaultdict(list)
    for img_name, gt in gt_data.items():
        group = None
        for g in images_by_group:
            if img_name in dict(images_by_group[g]):
                group = g
                break
        if group is None:
            # Try to infer from filename
            if img_name.startswith('t_1_'):
                group = '33.4_0.819'
            elif img_name.startswith('t_2_'):
                group = '25_0.821'
            elif img_name.startswith('t_3_'):
                group = '20_0.840'
            elif img_name.startswith('t_4_'):
                group = '15.2_0.840'
            elif img_name.startswith('t_5_'):
                group = '15.2_0.986'
            elif img_name.startswith('z_'):
                group = 'zhang'
            else:
                group = 'unknown'
        gt_by_group[group].append((img_name, gt))

    for group in sorted(gt_by_group):
        entries = gt_by_group[group]
        ok_entries = [(n, g) for n, g in entries if 'fx' in g and g.get('accepted', True)]
        fail_entries = [(n, g) for n, g in entries if g.get('failed')]
        warn_entries = [(n, g) for n, g in entries if 'fx' in g and not g.get('accepted', True)]

        print(f"\n  {group}: {len(entries)} entries ({len(ok_entries)} ok, {len(warn_entries)} quality-warn, {len(fail_entries)} failed)")

        if ok_entries:
            fxs = [g['fx'] for _, g in ok_entries]
            fys = [g['fy'] for _, g in ok_entries]
            cxs = [g['cx'] for _, g in ok_entries]
            cys = [g['cy'] for _, g in ok_entries]
            k1s = [g['k1'] for _, g in ok_entries]
            rmss = [g['rms_px'] for _, g in ok_entries if g.get('rms_px')]

            print(f"    fx: {np.mean(fxs):.0f} ± {np.std(fxs):.0f}  [{np.min(fxs):.0f}, {np.max(fxs):.0f}]")
            print(f"    fy: {np.mean(fys):.0f} ± {np.std(fys):.0f}  [{np.min(fys):.0f}, {np.max(fys):.0f}]")
            print(f"    cx: {np.mean(cxs):.0f} ± {np.std(cxs):.0f}  [{np.min(cxs):.0f}, {np.max(cxs):.0f}]")
            print(f"    cy: {np.mean(cys):.0f} ± {np.std(cys):.0f}  [{np.min(cys):.0f}, {np.max(cys):.0f}]")
            print(f"    k1: {np.mean(k1s):.4f} ± {np.std(k1s):.4f}  [{np.min(k1s):.4f}, {np.max(k1s):.4f}]")
            if rmss:
                print(f"    RMS: {np.mean(rmss):.2f} ± {np.std(rmss):.2f}  [{np.min(rmss):.2f}, {np.max(rmss):.2f}]")

        for img_name, gt in ok_entries:
            print(f"    {img_name}: fx={gt['fx']:.0f} fy={gt['fy']:.0f} "
                  f"cx={gt['cx']:.0f} cy={gt['cy']:.0f} k1={gt['k1']:.4f} rms={gt.get('rms_px','?')}")

        if warn_entries:
            print(f"    Quality-rejected:")
            for img_name, gt in warn_entries:
                print(f"    {img_name}: fx={gt['fx']:.0f} fy={gt['fy']:.0f} "
                      f"k1={gt['k1']:.4f} rms={gt.get('rms_px','?')} (accepted=False)")

        if fail_entries:
            print(f"    Failed detection:")
            for img_name, gt in fail_entries:
                print(f"    {img_name}: {gt.get('reason','?')}")

    # ── Cross-reference: detection vs GT ──
    print(f"\n{'='*80}")
    print(f"  CROSS-REFERENCE: Detection Success vs GT Availability")
    print(f"{'='*80}")

    for group in sorted(images_by_group):
        has_gt_ok = 0
        has_gt_fail = 0
        no_gt = 0
        detect_ok = 0

        for img_name, _ in images_by_group[group]:
            gt = gt_data.get(img_name, {})
            if 'fx' in gt and gt.get('accepted', True):
                has_gt_ok += 1
            elif gt.get('failed'):
                has_gt_fail += 1
            else:
                no_gt += 1

            key = f"{group}/{img_name}"
            if key in all_detection:
                if len(all_detection[key]['detected']) >= 2:
                    detect_ok += 1

        n = len(images_by_group[group])
        print(f"  {group}: {n} imgs, {has_gt_ok} GT-ok, {has_gt_fail} GT-fail, "
              f"{no_gt} no-GT, {detect_ok} detect≥2faces")

    # ── Overall Summary ──
    print(f"\n{'='*80}")
    print(f"  SUMMARY & RECOMMENDATIONS")
    print(f"{'='*80}")

    total = sum(len(v) for v in images_by_group.values())
    total_gt_ok = sum(1 for v in gt_data.values() if 'fx' in v and v.get('accepted', True))
    total_detect_2plus = sum(
        1 for v in all_detection.values() if len(v['detected']) >= 2
    )

    print(f"""
  Total images:              {total}
  With GT (accepted):        {total_gt_ok}
  Detectable (≥2 faces):     {total_detect_2plus}
  Detection success rate:    {100*total_detect_2plus/total:.0f}%

  Key issues preventing auto-calibration:
  ┌─────────────────────────────────────────────────────────────────┐
  │ 1. SAME-FACE problem: cv2.findChessboardCorners on full image  │
  │    finds the XY(top) face 3 times — the 3 faces are spatially  │
  │    adjacent and the side faces are not detected with 9×6.      │
  │                                                                │
  │ 2. Different face patterns: XZ/YZ faces have fewer visible     │
  │    inner corners than XY. Need per-face pattern sizes:         │
  │      XY(top)  = (9,6)                                          │
  │      XZ(right)= (8,4) or (6,6)                                 │
  │      YZ(left) = (6,5) or (4,5)                                 │
  │                                                                │
  │ 3. Sequential masked detection CAN find 2 unique faces, but    │
  │    a 3rd face is rarely visible. Even with 2 faces, FOV        │
  │    coverage is too low (<10%) for reliable VP estimation.      │
  │                                                                │
  │ 4. The original tool (022.py) used MANUAL ROI to solve this,   │
  │    achieving RMS 0.6-3.0px on accepted results.                │
  └─────────────────────────────────────────────────────────────────┘

  Recommended fixes for calibrate_best to work on real images:
  1. Implement sequential masked face detection (as in improved_calibrate.py)
  2. Accept n_faces=2 when only 2 faces are detectable
  3. Use Zhang calibration as prior when available
  4. Add ROI-based face selection as a fallback

  Zhang reference calibration (36-image, trustworthy):
    fx={zhang_gt.get('fx', 1251.0):.1f} fy={zhang_gt.get('fy', 1252.0):.1f}
    cx={zhang_gt.get('cx', 955.0):.1f} cy={zhang_gt.get('cy', 514.0):.1f}
    k1={zhang_gt.get('k1', -0.37):.4f} k2={zhang_gt.get('k2', 0.14):.4f}
""")

    # Save results
    out_path = os.path.join(args.output, 'comprehensive_analysis.json')
    def convert(obj):
        if isinstance(obj, (np.integer,)): return int(obj)
        if isinstance(obj, (np.floating,)): return float(obj)
        if isinstance(obj, np.ndarray): return obj.tolist()
        if isinstance(obj, dict): return {str(k): convert(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)): return [convert(i) for i in obj]
        return obj

    # Group detection results
    detection_summary = {}
    for group in sorted(images_by_group):
        group_det = {}
        for img_name, _ in images_by_group[group]:
            key = f"{group}/{img_name}"
            if key in all_detection:
                group_det[img_name] = all_detection[key]
        detection_summary[group] = {
            'n_images': len(images_by_group[group]),
            'detection': group_det,
        }

    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(convert({
            'detection_analysis': detection_summary,
            'ground_truth': gt_data,
            'zhang_reference': zhang_gt,
        }), f, indent=2, ensure_ascii=False)
    print(f"  Full results saved to: {out_path}")


if __name__ == '__main__':
    main()
