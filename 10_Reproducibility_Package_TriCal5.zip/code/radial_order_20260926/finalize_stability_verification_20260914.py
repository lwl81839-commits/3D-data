"""Archive drivers and verify no original training data/model/source changed."""
import hashlib,shutil,sys
import numpy as np, scipy,cv2
from run_stability_verification_20260914 import ROOT,OUT,BASE,POSES,read,save
p=read(OUT/'protocol.json');seen=set();errors=[]
for j in p['jobs']:
    for x in j['selected']:
        if x['sha256'] in seen:continue
        seen.add(x['sha256'])
        for key,hkey in [('image','sha256'),('cache','cache_sha256')]:
            from pathlib import Path
            if hashlib.sha256(Path(x[key]).read_bytes()).hexdigest()!=x[hkey]:errors.append(x[key])
assert hashlib.sha256((ROOT/'trained_camera_model.py').read_bytes()).hexdigest()==p['source_sha256']
assert not errors,errors
drivers=['run_stability_verification_20260914.py','evaluate_stability_verification_20260914.py','audit_identifiability_20260914.py','run_identifiability_batch_20260914.py','screen_stability_predictions_20260914.py','run_prediction_screen_batch_20260914.py','summarize_stability_verification_20260914.py','finalize_stability_verification_20260914.py']
for name in drivers:shutil.copy2(ROOT/name,OUT/'code'/name)
shutil.copy2(BASE/'zhang_parameters.csv',OUT/'code/zhang_parameters_evaluation_only.csv')
deps=['trained_camera_model.py','best_calibration.py','calibration_engine.py','evaluate_trained_camera_model.py','evaluate_planar_blind_comparison.py','evaluate_planar_per_pose_controlled.py']
for name in deps:
    dest=OUT/'code/dependency_snapshot'/name;dest.parent.mkdir(exist_ok=True);shutil.copy2(ROOT/name,dest)
save(OUT/'integrity.json',dict(original_training_images_verified=len(seen),original_caches_verified=len(seen),production_source_unchanged=True,errors=errors,python=sys.version,numpy=np.__version__,scipy=scipy.__version__,opencv=cv2.__version__,scope='dependency snapshots cover directly audited modules, not a clean-machine installer'))
files=[]
for f in sorted((OUT/'code').rglob('*')):
    if f.is_file():files.append(dict(path=str(f.relative_to(OUT)),sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
save(OUT/'code_manifest.json',files)
print('Verified original 25 images, 25 caches and production source unchanged',flush=True)
checks=[]
for pose in POSES:
    for name in ['ratio_base','no_ratio_base','zhang_reference']:
        path=OUT/'evaluations'/pose/name/'evaluation.json'
        assert path.exists(),path
        q=read(path)['summary']
        checks.append(dict(pose=pose,name=name,complete=True,images=q['blind_images_attempted'],extracted=q['blind_images_extracted'],face_histogram=q['face_evidence_histogram']))
    screen=read(OUT/'prediction_screen'/pose/'results.json')
    names={r['model'] for r in screen['rows']}
    required={j['name'] for j in p['jobs'] if j['pose']==pose and read(OUT/'models'/pose/j['name']/'status.json')['completed']}
    assert names==required,(pose,names^required)
    assert {r['kind'] for r in screen['rows']}=={'2D','3D'}
save(OUT/'evaluation_completion.json',dict(full_cuboid=checks,full_planar_configs=len(read(OUT/'planar_summary.json')),screen_all_solved_models_covered=True,note='Initial reference-loader attempts were rejected; corrected using the evaluator native camera-override interface. Old job log is retained; this file records final verified completion.'))
print('Verified 15 full cuboid evaluations, 5 planar configurations and all prediction-screen models',flush=True)
