"""Isolated paired sparse observations, with or without actual inlier transfer."""
from pathlib import Path
import sys,hashlib,shutil,json
from concurrent.futures import ThreadPoolExecutor
import run_0820_stability_curve as r
from ablate_0820_ratio_prior import ROOT,BASE,SPLIT,POSES
OUT=ROOT/'output/precision_fix_20260912/inlier_transfer'
r.OUT=OUT
def prepare():
    original=(ROOT/'output/experiment_0820_sparse_observation_test/code/trained_camera_model.py').read_text(encoding='utf-8')
    for variant in ['sparse_all','sparse_inliers']:
        s=original
        start=s.index('    fx, fy = float(K[0, 0]), float(K[1, 1])',s.index('def _refine_fixed_intrinsics_planar_radial'))
        s=s[:start]+'''    object_groups = [np.asarray(obj, dtype=np.float64) for obj in object_groups]
    image_groups = [np.asarray(img, dtype=np.float64) for img in image_groups]
    K = np.asarray(K, dtype=np.float64)
'''+s[start:]
        if variant=='sparse_inliers':
            a=s.index('def _local_face_observations');b=s.index('def _estimate_local_homography_seed',a)
            sub=s[a:b]
            sub=sub.replace('"points": points,','"points": points[inlier_mask],')
            sub=sub.replace('np.column_stack([local, np.zeros(len(local))]),','np.column_stack([local, np.zeros(len(local))])[inlier_mask],')
            s=s[:a]+sub+s[b:]
        d=OUT/'code'/variant;d.mkdir(parents=True,exist_ok=True);(d/'trained_camera_model.py').write_text(s,encoding='utf-8')
        for pose in POSES:
            d=OUT/'models'/pose/variant;cache=d/'.trihedral_correspondence_cache';cache.mkdir(parents=True,exist_ok=True);images=[]
            for p in sorted((SPLIT/'train'/pose/'3D').glob('*.jpg')):
                h=hashlib.sha256(p.read_bytes()).hexdigest();c=next((BASE/'per_pose_models'/pose/'.trihedral_correspondence_cache').glob(h+'_sq25_*.npz'));shutil.copy2(c,cache/c.name);images.append(str(p))
            r.save(d/'selection.json',images)
    r.save(OUT/'protocol.json',dict(scope='diagnostic only; do not release unaccepted models',changed='identical sparse local observations and float64 refinement; only transfer homography inlier mask to both corresponding arrays',poses=POSES,training_images_per_configuration=5,priors_unchanged=True))
def train(pose,variant):
    sys.path.insert(0,str(OUT/'code'/variant));import cv2
    cv2.setNumThreads(1);cv2.setRNGSeed(20260912)
    import trained_camera_model as t
    d=OUT/'models'/pose/variant
    try:
        m=t.train_camera_model(r.read(d/'selection.json'),25,str(d/'trained_camera_model.json'),distortion_model='k1_k2')
        r.save(d/'status.json',dict(completed=True,accepted=m['accepted']))
    except Exception as e:r.save(d/'status.json',dict(completed=False,error=str(e)))
if __name__=='__main__':
    if len(sys.argv)>1:train(sys.argv[2],sys.argv[3])
    else:
        prepare()
        with ThreadPoolExecutor(max_workers=3) as pool:res=list(pool.map(lambda j:r.run('train_'+j[0]+'_'+j[1],[__file__,'train',*j]),[(p,v) for p in POSES for v in ['sparse_all','sparse_inliers']]))
        r.save(OUT/'training_jobs.json',res)
        jobs=[]
        for p in POSES:
            for v in ['sparse_all','sparse_inliers']:
                d=OUT/'models'/p/v
                if not r.read(d/'status.json')['completed']:continue
                jobs.append((p+'_'+v,[ROOT/'evaluate_trained_camera_model.py','--model',d/'trained_camera_model.json','--images',SPLIT/'test'/p/'3D','--output-dir',OUT/'evaluations'/p/v,'--correspondence-cache-dir',BASE/'test_correspondence_cache'/p,'--only-existing-cache','--allow-unaccepted-model','--repeats','20']))
        with ThreadPoolExecutor(max_workers=3) as pool:res=list(pool.map(lambda j:r.run(*j),jobs))
        r.save(OUT/'evaluation_jobs.json',res)
