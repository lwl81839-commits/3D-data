from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any


POSES = ("15_0.528", "30_0.827", "45_0.827", "45_1.155", "60_1.155")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate each frozen per-pose 3-D model and existing MATLAB Zhang "
            "parameters on identical cached test correspondences."
        )
    )
    parser.add_argument("--split-root", type=Path, required=True)
    parser.add_argument("--validation-root", type=Path, default=None)
    parser.add_argument("--python", type=Path, default=Path(sys.executable))
    parser.add_argument("--repeats", type=int, default=20)
    parser.add_argument("--workers", type=int, default=5)
    return parser.parse_args()


def stat_median(summary: dict[str, Any], key: str) -> Any:
    value = summary.get(key, {})
    return value.get("median") if isinstance(value, dict) else None


def row_from_summary(pose: str, method: str, summary: dict[str, Any]) -> dict[str, Any]:
    hist = summary.get("face_evidence_histogram", {})
    return {
        "pose": pose,
        "method": method,
        "original_3d_model_accepted": summary.get("original_model_accepted"),
        "test_images_attempted": summary.get("blind_images_attempted"),
        "test_images_extracted": summary.get("blind_images_extracted"),
        "extraction_success_rate_pct": summary.get("blind_extraction_success_rate_pct"),
        "one_face_images": hist.get("1", 0),
        "two_face_images": hist.get("2", 0),
        "three_face_images": hist.get("3", 0),
        "holdout_rmse_px_median": stat_median(summary, "holdout_error_px"),
        "object_point_rmse_mm_median": stat_median(
            summary, "holdout_object_point_rmse_mm"
        ),
        "length_abs_error_mm_median": stat_median(
            summary, "holdout_length_absolute_error_mm"
        ),
        "length_rel_error_pct_median": stat_median(
            summary, "holdout_length_relative_error_pct"
        ),
        "cross_face_prediction_rmse_px_median": stat_median(
            summary, "cross_face_prediction_rmse_px"
        ),
        "undistorted_line_rms_px_median": stat_median(
            summary, "undistorted_line_rms_px"
        ),
    }


def fmt(value: Any, digits: int = 3) -> str:
    if value is None:
        return "-"
    try:
        return f"{float(value):.{digits}f}"
    except (TypeError, ValueError):
        return str(value)


def main() -> int:
    args = parse_args()
    split_root = args.split_root.resolve()
    validation = (
        args.validation_root.resolve()
        if args.validation_root is not None
        else split_root / "validation_ours_vs_zhang"
    )
    zhang_csv = validation / "zhang_parameters.csv"
    evaluator = Path(__file__).resolve().parent / "evaluate_trained_camera_model.py"
    output_root = validation / "final_test_evaluation"
    override_root = output_root / "fixed_zhang_overrides"
    override_root.mkdir(parents=True, exist_ok=True)

    with zhang_csv.open("r", encoding="utf-8-sig", newline="") as handle:
        zhang_rows = {row["Pose"]: row for row in csv.DictReader(handle)}

    overrides: dict[str, Path] = {}
    for pose in POSES:
        row = zhang_rows[pose]
        payload = {
            "cameraMatrix": [
                [float(row["fx_px"]), 0.0, float(row["cx_px"])],
                [0.0, float(row["fy_px"]), float(row["cy_px"])],
                [0.0, 0.0, 1.0],
            ],
            "distCoeffs": [
                float(row["k1"]), float(row["k2"]),
                float(row["p1"]), float(row["p2"]), 0.0,
            ],
            "source": str(row["source"]),
            "is_zhang_reference": True,
            "provenance": (
                "Existing MATLAB built-in Zhang calibration supplied before this "
                "evaluation; values copied without recalibration."
            ),
        }
        path = override_root / f"{pose}.json"
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        overrides[pose] = path

    def run_pose(pose: str) -> list[dict[str, Any]]:
        model = validation / "per_pose_models" / pose / "trained_camera_model.json"
        images = split_root / "test" / pose / "3D"
        cache = validation / "test_correspondence_cache" / pose
        results: list[dict[str, Any]] = []
        for method in ("ours_3d_5_images", "zhang_matlab_20_images"):
            out = output_root / pose / method
            cmd = [
                str(args.python), str(evaluator),
                "--model", str(model),
                "--images", str(images),
                "--output-dir", str(out),
                "--correspondence-cache-dir", str(cache),
                "--only-existing-cache",
                "--repeats", str(args.repeats),
                "--allow-unaccepted-model",
            ]
            if method.startswith("zhang"):
                cmd.extend(["--camera-override-json", str(overrides[pose])])
            completed = subprocess.run(
                cmd,
                text=True,
                encoding="utf-8",
                errors="replace",
                capture_output=True,
            )
            out.mkdir(parents=True, exist_ok=True)
            (out / "run_stdout.log").write_text(completed.stdout, encoding="utf-8")
            (out / "run_stderr.log").write_text(completed.stderr, encoding="utf-8")
            evaluation = out / "evaluation.json"
            if completed.returncode != 0 or not evaluation.is_file():
                raise RuntimeError(
                    f"{pose} {method} failed with exit {completed.returncode}: "
                    f"{completed.stderr or completed.stdout[-1000:]}"
                )
            summary = json.loads(evaluation.read_text(encoding="utf-8"))["summary"]
            results.append(row_from_summary(pose, method, summary))
            print(
                f"DONE {pose} {method}: "
                f"{summary['blind_images_extracted']}/{summary['blind_images_attempted']} "
                f"median={fmt(stat_median(summary, 'holdout_error_px'))} px",
                flush=True,
            )
        return results

    rows: list[dict[str, Any]] = []
    errors: list[str] = []
    with ThreadPoolExecutor(max_workers=max(1, min(args.workers, len(POSES)))) as pool:
        futures = {pool.submit(run_pose, pose): pose for pose in POSES}
        for future in as_completed(futures):
            pose = futures[future]
            try:
                rows.extend(future.result())
            except Exception as exc:
                errors.append(f"{pose}: {exc}")
                print(f"ERROR {pose}: {exc}", flush=True)

    rows.sort(key=lambda row: (POSES.index(row["pose"]), row["method"]))
    if rows:
        with (output_root / "comparison_metrics.csv").open(
            "w", encoding="utf-8-sig", newline=""
        ) as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

    payload = {
        "schema": "per-pose-ours-vs-fixed-matlab-zhang/v1",
        "split_root": str(split_root),
        "test_face_policy": "use every formally usable detected face (1, 2, or 3)",
        "ours_training_policy": "five three-face-detected 3-D images per pose",
        "zhang_policy": (
            "existing MATLAB built-in calibration from 20 2-D images per pose; "
            "not recalculated"
        ),
        "shared_correspondences_between_methods": True,
        "repeats": int(args.repeats),
        "rows": rows,
        "errors": errors,
    }
    (output_root / "comparison_summary.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    by_pose = {
        pose: {row["method"]: row for row in rows if row["pose"] == pose}
        for pose in POSES
    }
    report = [
        "# 分姿态测试：三维五图法与 MATLAB Zhang 二维二十图法",
        "",
        "- 我们的方法：每个姿态仅用 5 张检测到三面的三维图训练。",
        "- Zhang 方法：直接读取既有 MATLAB 内置算法标定结果，不重新计算。",
        "- 测试图：检测到 1/2/3 面就使用对应的全部正式可用面。",
        "- 公平性：两种参数使用完全相同的测试角点缓存、留出划分和随机种子。",
        "",
        "| 姿态 | 方法 | 成功图/总图 | 面数(1/2/3) | 留出RMSE(px) | 物点RMSE(mm) | 长度相对误差(%) | 跨面RMSE(px) | 去畸变直线RMS(px) |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for pose in POSES:
        for method in ("ours_3d_5_images", "zhang_matlab_20_images"):
            row = by_pose.get(pose, {}).get(method)
            if row is None:
                continue
            label = "三维5图" if method.startswith("ours") else "Zhang二维20图"
            report.append(
                f"| {pose} | {label} | {row['test_images_extracted']}/{row['test_images_attempted']} "
                f"| {row['one_face_images']}/{row['two_face_images']}/{row['three_face_images']} "
                f"| {fmt(row['holdout_rmse_px_median'])} "
                f"| {fmt(row['object_point_rmse_mm_median'])} "
                f"| {fmt(row['length_rel_error_pct_median'])} "
                f"| {fmt(row['cross_face_prediction_rmse_px_median'])} "
                f"| {fmt(row['undistorted_line_rms_px_median'])} |"
            )
    if errors:
        report.extend(["", "## 运行错误", ""] + [f"- {item}" for item in errors])
    (output_root / "COMPARISON_REPORT.md").write_text(
        "\n".join(report) + "\n", encoding="utf-8"
    )
    return 0 if not errors and len(rows) == 2 * len(POSES) else 2


if __name__ == "__main__":
    raise SystemExit(main())
