#!/usr/bin/env python3
"""Pose-guided missing face recovery from SAM deep two-face evidence.

Offline experiment only.  It fits a physical pose from two SAM-recovered
faces, projects the missing cube face into the image, rectifies only that
small predicted region, and then searches for the real checkerboard corners.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import time
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import cv2
import numpy as np
import torch
from segment_anything import SamPredictor, sam_model_registry

from best_calibration import (
    MAX_CONFIDENT_WIDE_OFFSET_PNP_RMSE_PX,
    calibrate_best,
)
from face_detector import (
    _cube_detection_best_offset_pnp_rmse,
    _cube_detection_geometry_rmse,
    _dark_square_components,
    _dedupe_face_candidates,
    _detections_have_excessive_overlap,
    _label_cube_clusters,
    _cluster_dark_components,
    _normalize_face_axis_order,
    _score_face_upgrade_candidate,
    _transpose_detection,
    estimate_cube_area_pct,
)
from partial_offset_probe import _face_definition
from sam_three_face_deep_calibrate_probe import (
    MAX_RECOVERED_CORNER_OFFSET_PNP_RMSE_PX,
    PHYSICAL_LABELS,
    TARGET_FACE_PATTERNS,
    add_direct_candidates,
    recover_needed_candidates,
    strict_failures,
)
from sam_two_face_physical_probe import (
    TARGET_PATTERNS,
    _all_two_face_combos,
    _candidate_desc,
    _fit_two_face_models,
)
from sam_xy_calibrate_probe import load_rel_paths, object_corners_array, pattern_exact
from sam_xy_deep_probe import read_image
from three_face_calib import object_points_for_face, preprocess_image


def _jsonable(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return value


def pose_guided_strict_failures(result, offset_rmse: float) -> List[str]:
    failures = strict_failures(result, offset_rmse)
    if (
        "offset_pnp" in failures
        and str(result.model_used).startswith("single-view-wide-offset")
        and np.isfinite(offset_rmse)
        and float(offset_rmse) <= float(MAX_CONFIDENT_WIDE_OFFSET_PNP_RMSE_PX)
    ):
        failures = [failure for failure in failures if failure != "offset_pnp"]
    return failures


def _outer_quad_object(label: str) -> np.ndarray:
    pattern = TARGET_PATTERNS[label]
    full_patterns = {k: v for k, v in TARGET_PATTERNS.items()}
    face = _face_definition(label, pattern, full_patterns, (0, 0))
    cols, rows = pattern
    s = float(face.square_size)
    return np.array([
        face.origin_3d - s * face.axis_x - s * face.axis_y,
        face.origin_3d + cols * s * face.axis_x - s * face.axis_y,
        face.origin_3d + cols * s * face.axis_x + rows * s * face.axis_y,
        face.origin_3d - s * face.axis_x + rows * s * face.axis_y,
    ], dtype=np.float64)


def _project_points(points3d: np.ndarray, fit: Dict[str, Any]) -> np.ndarray:
    rvec, _ = cv2.Rodrigues(np.asarray(fit["R"], dtype=np.float64))
    proj, _ = cv2.projectPoints(
        points3d.reshape(-1, 1, 3).astype(np.float64),
        rvec,
        np.asarray(fit["t"], dtype=np.float64).reshape(3, 1),
        np.asarray(fit["K"], dtype=np.float64),
        np.asarray(fit["dist"], dtype=np.float64).reshape(-1),
    )
    return proj.reshape(-1, 2).astype(np.float32)


def _scale_quad(quad: np.ndarray, scale: float) -> np.ndarray:
    center = quad.reshape(-1, 2).mean(axis=0)
    return center + (quad.reshape(-1, 2) - center) * float(scale)


def _find_checker_in_projected_face(
    gray: np.ndarray,
    quad: np.ndarray,
    pattern: Tuple[int, int],
) -> Tuple[np.ndarray | None, str]:
    cols, rows = pattern
    h, w = gray.shape[:2]
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    attempts = []
    for scale in (1.00, 1.10, 1.24):
        q = _scale_quad(np.asarray(quad, dtype=np.float32), scale)
        if (
            np.max(q[:, 0]) < 0 or np.max(q[:, 1]) < 0
            or np.min(q[:, 0]) >= w or np.min(q[:, 1]) >= h
        ):
            attempts.append(f"s{scale:.2f}:outside")
            continue
        cell = 58
        dst_w = max(280, int(round((cols + 1) * cell)))
        dst_h = max(220, int(round((rows + 1) * cell)))
        dst = np.array(
            [[0, 0], [dst_w - 1, 0], [dst_w - 1, dst_h - 1], [0, dst_h - 1]],
            dtype=np.float32,
        )
        H = cv2.getPerspectiveTransform(q.astype(np.float32), dst)
        H_inv = cv2.getPerspectiveTransform(dst, q.astype(np.float32))
        warped = cv2.warpPerspective(
            gray,
            H,
            (dst_w, dst_h),
            flags=cv2.INTER_CUBIC,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=210,
        )
        variants = [
            ("pre", preprocess_image(warped)),
            ("eq", cv2.equalizeHist(warped)),
            ("raw", warped),
        ]
        for name, work in variants:
            ok, corners = cv2.findChessboardCorners(work, pattern, flags=flags)
            attempts.append(f"s{scale:.2f}-{name}-classic:{int(bool(ok))}")
            if ok and corners is not None:
                if corners.reshape(-1, 2).shape[0] != cols * rows:
                    attempts.append(
                        f"s{scale:.2f}-{name}-classic-wrong-count:"
                        f"{corners.reshape(-1, 2).shape[0]}"
                    )
                    continue
                mapped = cv2.perspectiveTransform(corners.astype(np.float32), H_inv)
                return mapped.reshape(-1, 1, 2), ";".join(attempts)
            if hasattr(cv2, "findChessboardCornersSB"):
                ok, corners = cv2.findChessboardCornersSB(
                    work,
                    pattern,
                    flags=cv2.CALIB_CB_NORMALIZE_IMAGE,
                )
                attempts.append(f"s{scale:.2f}-{name}-SB:{int(bool(ok))}")
                if ok and corners is not None:
                    if corners.reshape(-1, 2).shape[0] != cols * rows:
                        attempts.append(
                            f"s{scale:.2f}-{name}-SB-wrong-count:"
                            f"{corners.reshape(-1, 2).shape[0]}"
                        )
                        continue
                    mapped = cv2.perspectiveTransform(corners.astype(np.float32), H_inv)
                    return mapped.reshape(-1, 1, 2), ";".join(attempts)
    return None, ";".join(attempts)


def _two_face_fit_candidates(by_label, image_shape, rmse_limit: float):
    candidates = []
    tested = 0
    model_count = 0
    for raw in _all_two_face_combos(by_label):
        dets = [(c, p, l) for _s, c, p, l, _src in raw]
        fits = _fit_two_face_models(dets, image_shape, rmse_limit=rmse_limit)
        tested += 1
        model_count += len(fits)
        if not fits:
            continue
        for fit in fits:
            fit["raw_combo"] = raw
            candidates.append(fit)
    candidates.sort(key=lambda row: (
        float(row["rmse_px"]),
        0 if row["model"] == "single-view-zero-dist" else 1,
        abs(float(row["k1"])),
    ))
    return candidates, tested, model_count


def _find_checker_in_bbox(
    gray: np.ndarray,
    bbox: Tuple[int, int, int, int],
    pattern: Tuple[int, int],
) -> Tuple[np.ndarray | None, str]:
    x1, y1, x2, y2 = bbox
    crop = gray[y1:y2, x1:x2]
    if crop.size == 0:
        return None, "empty"
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    attempts = []
    cols, rows = pattern
    for scale in (1.2, 1.5, 2.0, 2.8, 3.6, 5.0):
        work0 = cv2.resize(
            crop,
            (max(2, int(round(crop.shape[1] * scale))),
             max(2, int(round(crop.shape[0] * scale)))),
            interpolation=cv2.INTER_CUBIC,
        )
        variants = [
            ("pre", preprocess_image(work0)),
            ("eq", cv2.equalizeHist(work0)),
            ("raw", work0),
        ]
        for name, work in variants:
            ok, corners = cv2.findChessboardCorners(work, pattern, flags=flags)
            attempts.append(f"s{scale:.1f}-{name}-classic:{int(bool(ok))}")
            if ok and corners is not None:
                if corners.reshape(-1, 2).shape[0] != cols * rows:
                    attempts.append(
                        f"s{scale:.1f}-{name}-classic-wrong-count:"
                        f"{corners.reshape(-1, 2).shape[0]}"
                    )
                    continue
                corners = corners.reshape(-1, 1, 2).astype(np.float32)
                corners[:, 0, 0] = corners[:, 0, 0] / float(scale) + float(x1)
                corners[:, 0, 1] = corners[:, 0, 1] / float(scale) + float(y1)
                return corners, ";".join(attempts)
            if hasattr(cv2, "findChessboardCornersSB"):
                ok, corners = cv2.findChessboardCornersSB(
                    work, pattern, flags=cv2.CALIB_CB_NORMALIZE_IMAGE)
                attempts.append(f"s{scale:.1f}-{name}-SB:{int(bool(ok))}")
                if ok and corners is not None:
                    if corners.reshape(-1, 2).shape[0] != cols * rows:
                        attempts.append(
                            f"s{scale:.1f}-{name}-SB-wrong-count:"
                            f"{corners.reshape(-1, 2).shape[0]}"
                        )
                        continue
                    corners = corners.reshape(-1, 1, 2).astype(np.float32)
                    corners[:, 0, 0] = corners[:, 0, 0] / float(scale) + float(x1)
                    corners[:, 0, 1] = corners[:, 0, 1] / float(scale) + float(y1)
                    return corners, ";".join(attempts)
    return None, ";".join(attempts)


def _component_bbox_missing_candidates(
    gray: np.ndarray,
    missing_label: str,
    *,
    max_candidates: int = 12,
    max_boxes: int = 36,
) -> Tuple[List[Tuple], str]:
    pattern = TARGET_PATTERNS[missing_label]
    _mask, components = _dark_square_components(gray)
    clusters = _label_cube_clusters(
        _cluster_dark_components(gray, n_faces=3, verbose=False))
    if not clusters:
        return [], "no_clusters"

    cluster_pts = np.vstack([
        np.asarray(face["poly"], dtype=np.float32).reshape(-1, 2)
        for face in clusters
        if "poly" in face
    ])
    h, w = gray.shape[:2]
    x1, y1 = cluster_pts.min(axis=0)
    x2, y2 = cluster_pts.max(axis=0)
    span = max(float(x2 - x1), float(y2 - y1), 1.0)
    extent = (
        max(0.0, x1 - 0.35 * span),
        max(0.0, y1 - 0.35 * span),
        min(float(w - 1), x2 + 1.15 * span),
        min(float(h - 1), y2 + 0.55 * span),
    )

    roi_components = []
    for comp in components:
        cx, cy = np.asarray(comp["center"], dtype=np.float32)
        if extent[0] <= cx <= extent[2] and extent[1] <= cy <= extent[3]:
            roi_components.append(comp)
    if len(roi_components) < 8:
        return [], f"too_few_components:{len(roi_components)}"

    def ordered_unique(values):
        out = []
        for value in values:
            rounded = float(np.round(value, 1))
            if rounded not in out:
                out.append(rounded)
        return out

    centers = np.asarray([c["center"] for c in roi_components], dtype=np.float32)
    right_cuts = ordered_unique(
        np.percentile(centers[:, 0], [40, 35, 45, 30, 50, 25, 20]))
    left_cuts = ordered_unique(
        np.percentile(centers[:, 0], [60, 65, 55, 70, 50, 75, 80]))
    y_tops = ordered_unique(
        np.percentile(centers[:, 1], [0, 5, 10, 15, 20]))
    y_tops_lower = ordered_unique(
        np.percentile(centers[:, 1], [20, 25, 30, 15, 35, 40]))
    y_bottoms = ordered_unique(
        np.percentile(centers[:, 1], [100, 95, 90, 85, 80]))

    modes = (
        [
            ("left-lower", left_cuts, y_tops_lower),
            ("left", left_cuts, y_tops),
            ("right", right_cuts, y_tops),
        ]
        if pattern_exact(pattern, (6, 6))
        else [
            ("right-lower", right_cuts, y_tops_lower),
            ("right", right_cuts, y_tops),
            ("left", left_cuts, y_tops),
        ]
    )

    candidates: List[Tuple] = []
    traces = []
    seen_boxes = set()
    boxes_tested = 0
    for mode, x_cuts, mode_y_tops in modes:
        for x_cut in x_cuts:
            for yt in mode_y_tops:
                for yb in y_bottoms:
                    if yb - yt < 80:
                        continue
                    subset = []
                    for comp in roi_components:
                        cx, cy = comp["center"]
                        side_ok = (
                            cx <= x_cut
                            if mode.startswith("left")
                            else cx >= x_cut
                        )
                        if side_ok and yt <= cy <= yb:
                            subset.append(comp)
                    if len(subset) < 8:
                        continue
                    pts = []
                    for comp in subset:
                        bx, by, bw, bh = comp["bbox"]
                        pts.extend([
                            (bx, by), (bx + bw, by),
                            (bx + bw, by + bh), (bx, by + bh)
                        ])
                    pts_np = np.asarray(pts, dtype=np.float32)
                    bx1, by1 = pts_np.min(axis=0)
                    bx2, by2 = pts_np.max(axis=0)
                    for pad in (10, 20, 35, 0, 55):
                        xx1 = max(0, int(np.floor(bx1 - pad)))
                        yy1 = max(0, int(np.floor(by1 - pad)))
                        xx2 = min(w, int(np.ceil(bx2 + pad)))
                        yy2 = min(h, int(np.ceil(by2 + pad)))
                        if xx2 - xx1 < 90 or yy2 - yy1 < 80:
                            continue
                        if xx2 - xx1 > 420 or yy2 - yy1 > 420:
                            continue
                        key = (xx1, yy1, xx2, yy2)
                        if key in seen_boxes:
                            continue
                        seen_boxes.add(key)
                        boxes_tested += 1
                        if boxes_tested > max_boxes:
                            return (
                                _dedupe_face_candidates(candidates)[:max_candidates],
                                " || ".join(traces[:40]) + " || max_boxes",
                            )
                        corners, trace = _find_checker_in_bbox(gray, key, pattern)
                        traces.append(
                            f"{mode}:box={key}:n={len(subset)}:{trace[:160]}")
                        if corners is None:
                            continue
                        source = f"component-bbox-{mode}:{key}:n={len(subset)}"
                        score = _score_face_upgrade_candidate(corners, pattern, source)
                        candidates.append(
                            (score, corners, pattern, missing_label, source))
                        if len(candidates) >= max_candidates:
                            return (
                                _dedupe_face_candidates(candidates)[:max_candidates],
                                " || ".join(traces[:40]),
                            )
    return _dedupe_face_candidates(candidates)[:max_candidates], " || ".join(traces[:40])


def _combo_signature(dets):
    sig = []
    for corners, pattern, label in dets:
        pts = np.asarray(corners, dtype=np.float32).reshape(-1, 2)
        center = pts.mean(axis=0)
        span = pts.max(axis=0) - pts.min(axis=0)
        sig.append((
            str(label),
            tuple(int(v) for v in pattern),
            tuple(float(v) for v in np.round(np.r_[center, span], 1)),
        ))
    return tuple(sig)


def _bbox_iou_from_corners(a, b) -> float:
    pts_a = np.asarray(a, dtype=np.float32).reshape(-1, 2)
    pts_b = np.asarray(b, dtype=np.float32).reshape(-1, 2)
    ax1, ay1 = pts_a.min(axis=0)
    ax2, ay2 = pts_a.max(axis=0)
    bx1, by1 = pts_b.min(axis=0)
    bx2, by2 = pts_b.max(axis=0)
    ix1, iy1 = max(float(ax1), float(bx1)), max(float(ay1), float(by1))
    ix2, iy2 = min(float(ax2), float(bx2)), min(float(ay2), float(by2))
    iw, ih = max(0.0, ix2 - ix1), max(0.0, iy2 - iy1)
    inter = iw * ih
    area_a = max(0.0, float(ax2 - ax1)) * max(0.0, float(ay2 - ay1))
    area_b = max(0.0, float(bx2 - bx1)) * max(0.0, float(by2 - by1))
    denom = area_a + area_b - inter
    return 0.0 if denom <= 1e-6 else float(inter / denom)


def _overlap_pairs(dets, threshold: float = 0.80):
    pairs = []
    for i in range(len(dets)):
        for j in range(i + 1, len(dets)):
            iou = _bbox_iou_from_corners(dets[i][0], dets[j][0])
            if iou > threshold:
                pairs.append({
                    "a": str(dets[i][2]),
                    "b": str(dets[j][2]),
                    "iou": float(iou),
                })
    return pairs


def _axis_order_variants(base_dets):
    """Try fixed and transposed row/column interpretations for one 3-face set."""
    fixed = sorted(base_dets, key=lambda det: PHYSICAL_LABELS.index(det[2]))
    variants = [("fixed-label-order", fixed)]
    normalized = _normalize_face_axis_order(base_dets)
    if normalized:
        variants.append(("normalized-axis-order", normalized))

    n = len(fixed)
    for mask in range(1 << n):
        dets = []
        names = []
        for i, det in enumerate(fixed):
            if mask & (1 << i):
                dets.append(_transpose_detection(det))
                names.append(det[2])
            else:
                dets.append(det)
        if names:
            variants.append((f"transpose:{','.join(names)}", dets))

    out = []
    seen = set()
    for name, dets in variants:
        sig = _combo_signature(dets)
        if sig in seen:
            continue
        seen.add(sig)
        out.append((name, dets))
    return out


def _best_full_combo(by_label, image_shape, *, return_trace: bool = False):
    trace = {
        "missing_label": [],
        "raw_combos": 0,
        "axis_variants": 0,
        "pattern_rejects": 0,
        "overlap_rejects": 0,
        "nonfinite_rejects": 0,
        "finite_candidates": 0,
        "best_offset_pnp": None,
        "best_centered_pnp": None,
        "best_order": "",
        "nonfinite_samples": [],
        "overlap_samples": [],
    }
    if any(not by_label.get(label) for label in PHYSICAL_LABELS):
        trace["missing_label"] = [
            label for label in PHYSICAL_LABELS if not by_label.get(label)
        ]
        return (None, trace) if return_trace else None
    best = None
    for xy, xz, yz in itertools.product(
        by_label["XY"], by_label["XZ"], by_label["YZ"]):
        trace["raw_combos"] += 1
        raw = [xy, xz, yz]
        base_dets = [(c, p, l) for _s, c, p, l, _src in raw]
        variants = _axis_order_variants(base_dets)
        for order_source, dets in variants:
            trace["axis_variants"] += 1
            if any(
                label not in TARGET_PATTERNS
                or not pattern_exact(pattern, TARGET_PATTERNS[label])
                for _corners, pattern, label in dets
            ):
                trace["pattern_rejects"] += 1
                continue
            overlap_pairs = _overlap_pairs(dets, threshold=0.80)
            if overlap_pairs:
                trace["overlap_rejects"] += 1
                if len(trace["overlap_samples"]) < 8:
                    trace["overlap_samples"].append({
                        "order": order_source,
                        "pairs": overlap_pairs,
                    })
                continue
            centered = _cube_detection_geometry_rmse(
                dets, image_shape, n_faces=3, allow_sparse=False,
                assume_normalized=True)
            offset_rmse, offset, offset_dist = _cube_detection_best_offset_pnp_rmse(
                dets, image_shape, n_faces=3, assume_normalized=True)
            if not (np.isfinite(centered) and np.isfinite(offset_rmse)):
                trace["nonfinite_rejects"] += 1
                if len(trace["nonfinite_samples"]) < 8:
                    trace["nonfinite_samples"].append({
                        "order": order_source,
                        "centered": None if not np.isfinite(centered) else float(centered),
                        "offset": None if not np.isfinite(offset_rmse) else float(offset_rmse),
                        "patterns": [
                            f"{label}:{int(pattern[0])}x{int(pattern[1])}"
                            for _corners, pattern, label in dets
                        ],
                    })
                continue
            trace["finite_candidates"] += 1
            score = (
                float(offset_rmse)
                + 0.10 * float(centered)
                + 0.05 * float(offset_dist)
                + 0.005 * sum(float(s) for s, _c, _p, _l, _src in raw)
            )
            if best is None or score < best["score"]:
                best = {
                    "score": score,
                    "dets": dets,
                    "centered_pnp": float(centered),
                    "offset_pnp": float(offset_rmse),
                    "offset": offset,
                    "offset_dist": float(offset_dist),
                    "face_patterns": [
                        tuple(int(v) for v in pattern)
                        for _corners, pattern, _label in dets
                    ],
                    "order_source": order_source,
                    "sources": (
                        ";".join(src for _s, _c, _p, _l, src in raw)
                        + f";order={order_source}"
                    ),
                }
                trace["best_offset_pnp"] = float(offset_rmse)
                trace["best_centered_pnp"] = float(centered)
                trace["best_order"] = order_source
    return (best, trace) if return_trace else best


def _save_overlay(image: np.ndarray, rel: str, dets, out_dir: Path) -> None:
    colors = {"XY": (0, 220, 255), "XZ": (0, 180, 0), "YZ": (255, 80, 0)}
    vis = image.copy()
    for corners, pattern, label in dets:
        color = colors.get(label, (255, 255, 255))
        pts = corners.reshape(-1, 2)
        for x, y in pts:
            cv2.circle(vis, (int(round(x)), int(round(y))), 2, color, -1)
        x1, y1 = np.floor(pts.min(axis=0)).astype(int)
        x2, y2 = np.ceil(pts.max(axis=0)).astype(int)
        cv2.rectangle(vis, (x1, y1), (x2, y2), color, 2)
        cv2.putText(
            vis,
            f"{label} {int(pattern[0])}x{int(pattern[1])}",
            (x1, max(20, y1 - 6)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            color,
            2,
        )
    out_dir.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out_dir / f"{rel.replace('/', '__').replace(chr(92), '__')}.jpg"), vis)


def probe_one(
    image_root: Path,
    rel: str,
    predictor: SamPredictor,
    out_dir: Path,
    *,
    two_face_rmse_limit: float,
    max_pose_candidates: int,
) -> Dict[str, Any]:
    image_path = image_root / rel
    image = read_image(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    cube_area = float(estimate_cube_area_pct(gray, n_faces=3))

    by_label = {label: [] for label in PHYSICAL_LABELS}
    direct = add_direct_candidates(gray, by_label)
    direct_desc = ";".join(f"{label}:{int(pat[0])}x{int(pat[1])}" for _c, pat, label in direct)
    recovered, attempts_total = recover_needed_candidates(image, gray, predictor, by_label)

    row: Dict[str, Any] = {
        "rel_path": rel,
        "status": "not_recovered",
        "cube_area_pct": cube_area,
        "direct": direct_desc,
        "xy_candidates": _candidate_desc(by_label["XY"]),
        "xz_candidates": _candidate_desc(by_label["XZ"]),
        "yz_candidates": _candidate_desc(by_label["YZ"]),
        "recovered": json.dumps(recovered, ensure_ascii=False),
        "attempts": attempts_total,
    }

    best_failure = None
    initial_best, initial_trace = _best_full_combo(
        by_label, gray.shape, return_trace=True)
    row["initial_full_combo_trace"] = json.dumps(
        _jsonable(initial_trace), ensure_ascii=False)
    if initial_best is not None:
        dets = initial_best["dets"]
        face_patterns = initial_best.get("face_patterns") or TARGET_FACE_PATTERNS
        corners_dir = out_dir / "corners"
        corners_dir.mkdir(parents=True, exist_ok=True)
        stem = rel.replace("/", "__").replace("\\", "__").rsplit(".", 1)[0]
        corners_path = corners_dir / f"{stem}_initial_full_combo.npz"
        np.savez(corners_path, corners=object_corners_array(dets))
        _save_overlay(image, rel, dets, out_dir / "overlays")
        try:
            result = calibrate_best(
                str(image_path),
                25.0,
                face_patterns=face_patterns,
                corners_path=str(corners_path),
                verbose=False,
            )
            failures = pose_guided_strict_failures(
                result, initial_best["offset_pnp"])
            candidate_row = {
                "status": "calibrated",
                "strict_like": "pass" if not failures else "fail:" + ",".join(failures),
                "pose_idx": "initial_full_combo",
                "centered_pnp": initial_best["centered_pnp"],
                "offset_pnp": initial_best["offset_pnp"],
                "offset": str(initial_best["offset"]),
                "offset_dist": initial_best["offset_dist"],
                "rmse_px": result.rmse,
                "fx_px": result.fx_px,
                "fy_px": result.fy_px,
                "fov_coverage_pct": result.fov_coverage_pct,
                "n_corners": result.n_corners,
                "corner_quality": result.corner_quality,
                "model": result.model_used,
                "sources": initial_best["sources"],
                "face_patterns_used": ";".join(
                    f"{int(p[0])}x{int(p[1])}" for p in face_patterns),
                "corners_path": str(corners_path),
                "warnings": " | ".join(result.warnings or []),
            }
            if candidate_row["strict_like"] == "pass":
                row.update(candidate_row)
                row["find_trace"] = ""
                return row
            best_failure = candidate_row
        except Exception as exc:
            best_failure = {
                "status": "calibration_error",
                "error": str(exc),
                "pose_idx": "initial_full_combo",
                "centered_pnp": initial_best["centered_pnp"],
                "offset_pnp": initial_best["offset_pnp"],
                "sources": initial_best["sources"],
                "corners_path": str(corners_path),
            }

    two_candidates, tested, model_count = _two_face_fit_candidates(
        by_label, gray.shape, two_face_rmse_limit)
    row["two_face_combos_tested"] = tested
    row["two_face_model_count"] = model_count
    if not two_candidates:
        if best_failure is not None:
            row.update(best_failure)
            return row
        row["status"] = "no_two_face_pose"
        return row

    traces = []
    for pose_idx, best_two in enumerate(two_candidates[:max_pose_candidates], 1):
        present = set(best_two["labels"].split(","))
        missing = [label for label in PHYSICAL_LABELS if label not in present]
        if len(missing) != 1:
            continue

        missing_label = missing[0]
        pattern = TARGET_PATTERNS[missing_label]
        quad = _project_points(_outer_quad_object(missing_label), best_two)
        corners, find_trace = _find_checker_in_projected_face(gray, quad, pattern)
        traces.append(
            f"pose{pose_idx}:{best_two['labels']}:rmse={float(best_two['rmse_px']):.3f}:"
            f"missing={missing_label}:{find_trace}"
        )
        row.update({
            "two_face_labels": best_two["labels"],
            "two_face_rmse_px": best_two["rmse_px"],
            "two_face_fx_px": best_two["fx_px"],
            "two_face_k1": best_two["k1"],
            "missing_labels": ",".join(missing),
            "missing_label": missing_label,
            "projected_quad": json.dumps(_jsonable(quad), ensure_ascii=False),
        })
        if corners is None:
            continue

        raw_dets = [(c, p, l) for _s, c, p, l, _src in best_two["raw_combo"]]
        raw_dets.append((corners, pattern, missing_label))
        dets = sorted(raw_dets, key=lambda det: PHYSICAL_LABELS.index(det[2]))
        if len(dets) < 3 or _detections_have_excessive_overlap(dets, threshold=0.80):
            best_failure = {
                "status": "projected_face_bad_combo",
                "pose_idx": pose_idx,
            }
            continue

        centered = _cube_detection_geometry_rmse(
            dets, gray.shape, n_faces=3, allow_sparse=False, assume_normalized=True)
        offset_rmse, offset, offset_dist = _cube_detection_best_offset_pnp_rmse(
            dets, gray.shape, n_faces=3, assume_normalized=True)

        corners_dir = out_dir / "corners"
        corners_dir.mkdir(parents=True, exist_ok=True)
        stem = rel.replace("/", "__").replace("\\", "__").rsplit(".", 1)[0]
        corners_path = corners_dir / f"{stem}_pose_guided_missing_pose{pose_idx}.npz"
        np.savez(corners_path, corners=object_corners_array(dets))
        _save_overlay(image, rel, dets, out_dir / "overlays")

        try:
            result = calibrate_best(
                str(image_path),
                25.0,
                face_patterns=TARGET_FACE_PATTERNS,
                corners_path=str(corners_path),
                verbose=False,
            )
            failures = pose_guided_strict_failures(result, offset_rmse)
            candidate_row = {
                "status": "calibrated",
                "strict_like": "pass" if not failures else "fail:" + ",".join(failures),
                "pose_idx": pose_idx,
                "centered_pnp": float(centered),
                "offset_pnp": float(offset_rmse),
                "offset": str(offset),
                "offset_dist": float(offset_dist),
                "rmse_px": result.rmse,
                "fx_px": result.fx_px,
                "fy_px": result.fy_px,
                "fov_coverage_pct": result.fov_coverage_pct,
                "n_corners": result.n_corners,
                "corner_quality": result.corner_quality,
                "model": result.model_used,
                "corners_path": str(corners_path),
                "warnings": " | ".join(result.warnings or []),
            }
            if candidate_row["strict_like"] == "pass":
                row.update(candidate_row)
                row["find_trace"] = " || ".join(traces)
                return row
            if (
                best_failure is None
                or float(candidate_row.get("offset_pnp", float("inf")))
                < float(best_failure.get("offset_pnp", float("inf")))
            ):
                best_failure = candidate_row
        except Exception as exc:
            candidate_row = {
                "status": "calibration_error",
                "error": str(exc),
                "pose_idx": pose_idx,
                "centered_pnp": float(centered),
                "offset_pnp": float(offset_rmse),
                "corners_path": str(corners_path),
            }
            best_failure = candidate_row

    component_traces = []
    for missing_label in [label for label in PHYSICAL_LABELS if not by_label[label]]:
        comp_candidates, comp_trace = _component_bbox_missing_candidates(
            gray, missing_label)
        component_traces.append(f"{missing_label}:{comp_trace}")
        if comp_candidates:
            by_label[missing_label].extend(comp_candidates)
            by_label[missing_label] = _dedupe_face_candidates(
                by_label[missing_label])[:12]

    if component_traces:
        row["component_bbox_trace"] = " || ".join(component_traces)
        row["xy_candidates"] = _candidate_desc(by_label["XY"])
        row["xz_candidates"] = _candidate_desc(by_label["XZ"])
        row["yz_candidates"] = _candidate_desc(by_label["YZ"])

    component_best, component_combo_trace = _best_full_combo(
        by_label, gray.shape, return_trace=True)
    row["component_combo_trace"] = json.dumps(
        _jsonable(component_combo_trace), ensure_ascii=False)

    retry_reason = ""
    if (
        component_best is None
        and component_combo_trace.get("overlap_rejects", 0) > 0
        and component_combo_trace.get("finite_candidates", 0) == 0
    ):
        retry_reason = "overlap_reject"
    elif (
        component_best is not None
        and float(component_best.get("offset_pnp", float("inf")))
        > float(MAX_RECOVERED_CORNER_OFFSET_PNP_RMSE_PX)
    ):
        retry_reason = "high_offset_pnp"

    if retry_reason:
        suspect_labels = []
        if retry_reason == "overlap_reject":
            for sample in component_combo_trace.get("overlap_samples", []):
                for pair in sample.get("pairs", []):
                    for key in ("a", "b"):
                        label = pair.get(key)
                        if label in PHYSICAL_LABELS and label not in suspect_labels:
                            suspect_labels.append(label)
        if not suspect_labels:
            suspect_labels = ["YZ"] if retry_reason == "high_offset_pnp" else ["YZ", "XZ", "XY"]

        retry_traces = []
        for label in suspect_labels:
            comp_candidates, comp_trace = _component_bbox_missing_candidates(
                gray, label, max_candidates=4, max_boxes=18)
            retry_traces.append(f"{label}:{comp_trace}")
            if comp_candidates:
                by_label[label].extend(comp_candidates)
                by_label[label] = _dedupe_face_candidates(
                    by_label[label])[:12]

        row["component_retry_reason"] = retry_reason
        row["component_bbox_retry_trace"] = " || ".join(retry_traces)
        row["xy_candidates"] = _candidate_desc(by_label["XY"])
        row["xz_candidates"] = _candidate_desc(by_label["XZ"])
        row["yz_candidates"] = _candidate_desc(by_label["YZ"])
        component_best, component_combo_retry_trace = _best_full_combo(
            by_label, gray.shape, return_trace=True)
        row["component_combo_retry_trace"] = json.dumps(
            _jsonable(component_combo_retry_trace), ensure_ascii=False)

    if component_best is not None:
        dets = component_best["dets"]
        face_patterns = component_best.get("face_patterns") or TARGET_FACE_PATTERNS
        corners_dir = out_dir / "corners"
        corners_dir.mkdir(parents=True, exist_ok=True)
        stem = rel.replace("/", "__").replace("\\", "__").rsplit(".", 1)[0]
        corners_path = corners_dir / f"{stem}_component_bbox_missing.npz"
        np.savez(corners_path, corners=object_corners_array(dets))
        _save_overlay(image, rel, dets, out_dir / "overlays")
        try:
            result = calibrate_best(
                str(image_path),
                25.0,
                face_patterns=face_patterns,
                corners_path=str(corners_path),
                verbose=False,
            )
            failures = pose_guided_strict_failures(
                result, component_best["offset_pnp"])
            candidate_row = {
                "status": "calibrated",
                "strict_like": "pass" if not failures else "fail:" + ",".join(failures),
                "pose_idx": "component_bbox",
                "centered_pnp": component_best["centered_pnp"],
                "offset_pnp": component_best["offset_pnp"],
                "offset": str(component_best["offset"]),
                "offset_dist": component_best["offset_dist"],
                "rmse_px": result.rmse,
                "fx_px": result.fx_px,
                "fy_px": result.fy_px,
                "fov_coverage_pct": result.fov_coverage_pct,
                "n_corners": result.n_corners,
                "corner_quality": result.corner_quality,
                "model": result.model_used,
                "sources": component_best["sources"],
                "face_patterns_used": ";".join(
                    f"{int(p[0])}x{int(p[1])}" for p in face_patterns),
                "corners_path": str(corners_path),
                "warnings": " | ".join(result.warnings or []),
            }
            if candidate_row["strict_like"] == "pass":
                row.update(candidate_row)
                row["find_trace"] = " || ".join(traces)
                return row
            if (
                best_failure is None
                or float(candidate_row.get("offset_pnp", float("inf")))
                < float(best_failure.get("offset_pnp", float("inf")))
            ):
                best_failure = candidate_row
        except Exception as exc:
            candidate_row = {
                "status": "calibration_error",
                "error": str(exc),
                "pose_idx": "component_bbox",
                "centered_pnp": component_best["centered_pnp"],
                "offset_pnp": component_best["offset_pnp"],
                "sources": component_best["sources"],
                "corners_path": str(corners_path),
            }
            best_failure = candidate_row

    row["find_trace"] = " || ".join(traces)
    if best_failure is not None:
        row.update(best_failure)
        return row
    row["status"] = "projected_face_checker_not_found"
    return row


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--rel-list", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--model-type", default="vit_b")
    parser.add_argument("--two-face-rmse-limit", type=float, default=18.0)
    parser.add_argument("--max-pose-candidates", type=int, default=12)
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    sam = sam_model_registry[args.model_type](checkpoint=str(args.checkpoint))
    sam.to(device=device)
    predictor = SamPredictor(sam)

    rows = []
    for rel in load_rel_paths(args.rel_list):
        print(f"START {rel}", flush=True)
        started = time.perf_counter()
        try:
            row = probe_one(
                args.image_root,
                rel,
                predictor,
                args.out_dir,
                two_face_rmse_limit=args.two_face_rmse_limit,
                max_pose_candidates=args.max_pose_candidates,
            )
        except Exception as exc:
            row = {"rel_path": rel, "status": "error", "error": str(exc)}
        row["elapsed_sec"] = time.perf_counter() - started
        print(json.dumps(row, ensure_ascii=False), flush=True)
        rows.append(row)

    (args.out_dir / "sam_pose_guided_missing_face_results.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    fields = sorted({key for row in rows for key in row.keys()})
    with (args.out_dir / "sam_pose_guided_missing_face_results.csv").open(
        "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
