#!/usr/bin/env python3
"""Probe whether partial face grids have a unique, safe full-face offset.

The calibration pipeline deliberately rejects sparse local checkerboards
because their 3D origin on the cube face is ambiguous.  This diagnostic script
tries possible full-face grid sizes, integer in-face offsets, and x/y flips. It
does not change the production acceptance logic; it produces evidence for
which partial samples are safe enough to promote later.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import statistics
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import cv2
import numpy as np

from best_calibration import _single_view_k1_fallback
from face_detector import detect_corner_cube_faces
from three_face_calib import (
    FaceDefinition,
    VanishingPoint,
    calibrate_intrinsics_from_vps,
    estimate_vanishing_point,
    lines_from_chessboard_corners,
    object_points_for_face,
)


SQUARE_SIZE_MM = 25.0
FULL_PATTERN_OPTIONS = {
    "XY": [(9, 6), (6, 9), (6, 8)],
    "XZ": [(9, 6), (6, 9), (7, 6), (6, 6)],
    "YZ": [(9, 6), (6, 9), (6, 6)],
}
AXES = {
    "XY": (np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])),
    "XZ": (np.array([1.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0])),
    "YZ": (np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0])),
}
VP_LABELS = {"XY": ("X", "Y"), "XZ": ("X", "Z"), "YZ": ("Y", "Z")}


def _maybe_float(value: Any) -> Optional[float]:
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def _median_quartiles(values: Sequence[float]) -> Tuple[float, float, float]:
    ordered = sorted(values)
    n = len(ordered)
    median = statistics.median(ordered)
    if n < 4:
        return median, ordered[0], ordered[-1]
    lower = ordered[: n // 2]
    upper = ordered[(n + 1) // 2 :]
    return median, statistics.median(lower), statistics.median(upper)


def build_group_focal_priors(
    rows: Sequence[Dict[str, Any]],
    *,
    min_samples: int,
    max_rel_iqr: float,
) -> Dict[str, Dict[str, Any]]:
    by_group: Dict[str, List[float]] = {}
    for row in rows:
        if row.get("status") != "ok" or row.get("group") == "zhang":
            continue
        fx = _maybe_float(row.get("fx_px"))
        if fx is None:
            continue
        by_group.setdefault(str(row.get("group", "")), []).append(fx)

    priors: Dict[str, Dict[str, Any]] = {}
    for group, values in by_group.items():
        median, q1, q3 = _median_quartiles(values)
        rel_iqr = (q3 - q1) / max(abs(median), 1e-6)
        stable = len(values) >= min_samples and rel_iqr <= max_rel_iqr
        if len(values) < min_samples:
            status = "insufficient_prior"
        elif rel_iqr > max_rel_iqr:
            status = "unstable_prior"
        else:
            status = "stable_prior"
        priors[group] = {
            "status": status,
            "stable": stable,
            "n": len(values),
            "fx_median": median,
            "fx_q1": q1,
            "fx_q3": q3,
            "fx_rel_iqr": rel_iqr,
            "fx_values": sorted(values),
        }
    return priors


def _load_gray(path: Path) -> np.ndarray:
    data = np.fromfile(str(path), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Cannot decode image: {path}")
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def _full_options(label: str, pattern: Tuple[int, int]) -> List[Tuple[int, int]]:
    cols, rows = pattern
    opts = []
    for full_cols, full_rows in FULL_PATTERN_OPTIONS.get(label, []):
        if full_cols >= cols and full_rows >= rows:
            opts.append((full_cols, full_rows))
    if not opts:
        opts.append(pattern)
    return opts


def _face_candidates(
    label: str,
    pattern: Tuple[int, int],
) -> List[Tuple[Tuple[int, int], Tuple[int, int]]]:
    cols, rows = pattern
    out = []
    for full_cols, full_rows in _full_options(label, pattern):
        for ox in range(max(1, full_cols - cols + 1)):
            for oy in range(max(1, full_rows - rows + 1)):
                out.append(((full_cols, full_rows), (ox, oy)))
    return out


def _origin_for(
    label: str,
    full_patterns: Dict[str, Tuple[int, int]],
    offset: Tuple[int, int],
) -> np.ndarray:
    side_squares = max(max(c + 1, r + 1) for c, r in full_patterns.values())
    side = side_squares * SQUARE_SIZE_MM
    full_cols, full_rows = full_patterns[label]
    base_x = 0.5 * (side - (full_cols + 1) * SQUARE_SIZE_MM) + SQUARE_SIZE_MM
    base_y = 0.5 * (side - (full_rows + 1) * SQUARE_SIZE_MM) + SQUARE_SIZE_MM
    axis_x, axis_y = AXES[label]
    return (
        (base_x + offset[0] * SQUARE_SIZE_MM) * axis_x
        + (base_y + offset[1] * SQUARE_SIZE_MM) * axis_y
    )


def _face_definition(
    label: str,
    pattern: Tuple[int, int],
    full_patterns: Dict[str, Tuple[int, int]],
    offset: Tuple[int, int],
) -> FaceDefinition:
    axis_x, axis_y = AXES[label]
    return FaceDefinition(
        pattern_size=pattern,
        square_size=SQUARE_SIZE_MM,
        axis_x=axis_x,
        axis_y=axis_y,
        origin_3d=_origin_for(label, full_patterns, offset),
    )


def _intrinsics_from_vps(
    detections: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    image_size: Tuple[int, int],
) -> np.ndarray:
    w_img, h_img = image_size
    vp_per_face = []
    for corners, pattern, label in detections:
        row_lines, col_lines, _, _ = lines_from_chessboard_corners(
            corners, pattern, use_ransac=True
        )
        vpx = estimate_vanishing_point(np.array(row_lines))
        vpy = estimate_vanishing_point(np.array(col_lines))
        lx, ly = VP_LABELS[label]
        vpx.direction_label = lx
        vpy.direction_label = ly
        vp_per_face.append({lx: vpx, ly: vpy})

    vp_avg = {}
    for label in ("X", "Y", "Z"):
        values = np.array([
            vp.v
            for face_vps in vp_per_face
            for key, vp in face_vps.items()
            if key == label
        ])
        if len(values) == 0:
            continue
        median = np.median(values, axis=0)
        if abs(median[2]) > 1e-6:
            median /= median[2]
        vp_avg[label] = VanishingPoint(v=median, direction_label=label)

    labels = sorted(vp_avg)
    label_to_idx = {label: i for i, label in enumerate(labels)}
    orthogonal_pairs = [
        (label_to_idx[a], label_to_idx[b])
        for a, b in (("X", "Y"), ("Y", "Z"), ("Z", "X"))
        if a in label_to_idx and b in label_to_idx
    ]
    return calibrate_intrinsics_from_vps(
        [vp_avg[label] for label in labels],
        orthogonal_pairs,
        assume_zero_skew=True,
        assume_square_pixels=True,
        fix_principal_point=(w_img / 2, h_img / 2),
    )


def _build_points(
    detections: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    face_specs: Dict[str, Dict[str, Tuple[int, int]]],
    flips: Sequence[Tuple[bool, bool]],
) -> Tuple[np.ndarray, np.ndarray]:
    full_patterns = {
        label: spec["full_pattern"] for label, spec in face_specs.items()
    }
    object_points = []
    image_points = []
    for i, (corners, pattern, label) in enumerate(detections):
        face = _face_definition(
            label,
            pattern,
            full_patterns,
            face_specs[label]["offset"],
        )
        flip_x, flip_y = flips[i]
        object_points.append(
            object_points_for_face(face, flip_x, flip_y).reshape(-1, 3)
        )
        image_points.append(corners.reshape(-1, 2))
    return np.vstack(object_points), np.vstack(image_points)


def _pnp_rmse(
    detections: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    face_specs: Dict[str, Dict[str, Tuple[int, int]]],
    K: np.ndarray,
) -> Optional[float]:
    object_points, image_points = _build_points(
        detections, face_specs, [(False, False)] * len(detections)
    )
    try:
        ok, rvec, tvec = cv2.solvePnP(
            object_points.astype(np.float32),
            image_points.astype(np.float32),
            K.astype(np.float64),
            np.zeros(5),
            flags=cv2.SOLVEPNP_ITERATIVE,
        )
    except cv2.error:
        return None
    if not ok:
        return None
    proj, _ = cv2.projectPoints(
        object_points.reshape(-1, 1, 3).astype(np.float64),
        rvec,
        tvec,
        K.astype(np.float64),
        np.zeros(5),
    )
    diff = proj.reshape(-1, 2) - image_points
    return float(np.sqrt(np.mean(np.sum(diff * diff, axis=1))))


def _candidate_specs(
    detections: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
) -> Iterable[Dict[str, Dict[str, Tuple[int, int]]]]:
    labels = [label for _corners, _pattern, label in detections]
    candidate_lists = []
    for _corners, pattern, label in detections:
        candidate_lists.append(_face_candidates(label, pattern))

    for combo in itertools.product(*candidate_lists):
        specs = {}
        for label, (full_pattern, offset) in zip(labels, combo):
            specs[label] = {
                "full_pattern": full_pattern,
                "offset": offset,
            }
        yield specs


def probe_image(
    image_path: Path,
    *,
    rmse_limit: float,
    k1_limit: float,
    top_offsets: int,
    ambiguity_gap_px: float,
    focal_spread_limit: float,
    flip_mode: str = "all",
    focal_prior: Optional[Dict[str, Any]] = None,
    focal_prior_tolerance: float = 0.15,
) -> Dict[str, Any]:
    gray = _load_gray(image_path)
    h_img, w_img = gray.shape[:2]
    detections = detect_corner_cube_faces(gray, n_faces=3, verbose=False)
    labels = [label for _corners, _pattern, label in detections]
    row: Dict[str, Any] = {
        "image": image_path.name,
        "n_faces": len(detections),
        "patterns": json.dumps([(label, pattern) for _c, pattern, label in detections]),
        "probe_status": "not_probed",
        "prior_status": focal_prior.get("status") if focal_prior else "no_prior",
        "prior_n": focal_prior.get("n") if focal_prior else "",
        "prior_fx_median": focal_prior.get("fx_median") if focal_prior else "",
        "prior_fx_rel_iqr": focal_prior.get("fx_rel_iqr") if focal_prior else "",
        "prior_probe_status": "not_probed",
    }

    if len(detections) != 3 or len(set(labels)) != 3:
        row["probe_status"] = "invalid_face_set"
        return row
    if any(label not in AXES for label in labels):
        row["probe_status"] = "unknown_label"
        return row
    if all(min(pattern) >= 5 for _corners, pattern, _label in detections):
        row["probe_status"] = "not_partial"
        return row

    K_seed = _intrinsics_from_vps(detections, (w_img, h_img))
    offset_scores = []
    for specs in _candidate_specs(detections):
        rmse = _pnp_rmse(detections, specs, K_seed)
        if rmse is not None and math.isfinite(rmse):
            offset_scores.append((rmse, specs))
    offset_scores.sort(key=lambda item: item[0])

    diag = float(np.hypot(w_img, h_img))
    focal_lo = 0.30 * diag
    focal_hi = 3.0 * diag
    if flip_mode == "none":
        flip_options = [((False, False),) * len(detections)]
    elif flip_mode == "axis":
        flip_options = list(itertools.product(
            [(False, False), (True, False), (False, True)],
            repeat=len(detections),
        ))
    else:
        flip_options = list(itertools.product(
            [(False, False), (True, False), (False, True), (True, True)],
            repeat=len(detections),
        ))

    candidates = []
    for _score, specs in offset_scores[:top_offsets]:
        for flips in flip_options:
            object_points, image_points = _build_points(detections, specs, flips)
            fallback = _single_view_k1_fallback(
                object_points,
                image_points,
                (w_img, h_img),
                K_seed,
                focal_lo,
                focal_hi,
                rmse_limit,
            )
            if fallback is None:
                continue
            K, dist, _R, _t, rmse = fallback
            k1 = float(dist[0])
            if abs(k1) > k1_limit:
                continue
            candidates.append({
                "rmse_px": float(rmse),
                "fx_px": float(K[0, 0]),
                "fy_px": float(K[1, 1]),
                "cx_px": float(K[0, 2]),
                "cy_px": float(K[1, 2]),
                "k1": k1,
                "specs": specs,
                "flips": flips,
            })

    candidates.sort(key=lambda c: c["rmse_px"])
    row["offset_specs_tested"] = len(offset_scores)
    row["valid_candidates"] = len(candidates)
    if not candidates:
        row["probe_status"] = "no_candidate"
        row["prior_probe_status"] = "no_candidate"
        return row

    best = candidates[0]
    close = [
        c for c in candidates
        if c["rmse_px"] <= best["rmse_px"] + ambiguity_gap_px
    ]
    focal_spread = 0.0
    if len(close) > 1:
        focal_spread = max(
            abs(c["fx_px"] - best["fx_px"]) / max(abs(best["fx_px"]), 1e-6)
            for c in close[1:]
        )
    unique = len(close) == 1 or focal_spread <= focal_spread_limit

    row.update({
        "probe_status": "unique_candidate" if unique else "ambiguous_candidate",
        "best_rmse_px": best["rmse_px"],
        "best_fx_px": best["fx_px"],
        "best_fy_px": best["fy_px"],
        "best_cx_px": best["cx_px"],
        "best_cy_px": best["cy_px"],
        "best_k1": best["k1"],
        "best_specs": json.dumps(best["specs"], sort_keys=True),
        "best_flips": json.dumps(best["flips"]),
        "close_candidates": len(close),
        "close_focal_spread": focal_spread,
    })

    if not focal_prior:
        row["prior_probe_status"] = "no_prior"
        return row
    if not focal_prior.get("stable"):
        row["prior_probe_status"] = str(focal_prior.get("status", "unstable_prior"))
        return row

    prior_fx = float(focal_prior["fx_median"])
    prior_candidates = [
        c for c in candidates
        if abs(c["fx_px"] - prior_fx) / max(abs(prior_fx), 1e-6)
        <= focal_prior_tolerance
    ]
    row["prior_candidates"] = len(prior_candidates)
    if not prior_candidates:
        row["prior_probe_status"] = "no_prior_candidate"
        return row

    prior_candidates.sort(key=lambda c: c["rmse_px"])
    prior_best = prior_candidates[0]
    prior_close = [
        c for c in prior_candidates
        if c["rmse_px"] <= prior_best["rmse_px"] + ambiguity_gap_px
    ]
    prior_spread = 0.0
    if len(prior_close) > 1:
        prior_spread = max(
            abs(c["fx_px"] - prior_best["fx_px"]) / max(abs(prior_best["fx_px"]), 1e-6)
            for c in prior_close[1:]
        )
    prior_unique = len(prior_close) == 1 or prior_spread <= focal_spread_limit
    row.update({
        "prior_probe_status": (
            "unique_prior_candidate" if prior_unique
            else "ambiguous_prior_candidate"
        ),
        "prior_best_rmse_px": prior_best["rmse_px"],
        "prior_best_fx_px": prior_best["fx_px"],
        "prior_best_fy_px": prior_best["fy_px"],
        "prior_best_cx_px": prior_best["cx_px"],
        "prior_best_cy_px": prior_best["cy_px"],
        "prior_best_k1": prior_best["k1"],
        "prior_best_specs": json.dumps(prior_best["specs"], sort_keys=True),
        "prior_best_flips": json.dumps(prior_best["flips"]),
        "prior_close_candidates": len(prior_close),
        "prior_close_focal_spread": prior_spread,
    })
    return row


def _read_csv(path: Path) -> List[Dict[str, Any]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def _write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    fields = [
        "workspace_path", "rel_path", "group", "image", "status",
        "cube_area_pct", "manual_source", "fx_gt", "fy_gt", "cx_gt", "cy_gt",
        "probe_status", "n_faces", "patterns", "offset_specs_tested",
        "valid_candidates", "best_rmse_px", "best_fx_px", "best_fy_px",
        "best_cx_px", "best_cy_px", "best_k1", "best_specs", "best_flips",
        "close_candidates", "close_focal_spread", "fx_abs_err_pct",
        "fy_abs_err_pct", "cx_abs_err_px", "cy_abs_err_px",
        "prior_status", "prior_n", "prior_fx_median", "prior_fx_rel_iqr",
        "prior_probe_status", "prior_candidates", "prior_best_rmse_px",
        "prior_best_fx_px", "prior_best_fy_px", "prior_best_cx_px",
        "prior_best_cy_px", "prior_best_k1", "prior_best_specs",
        "prior_best_flips", "prior_close_candidates",
        "prior_close_focal_spread", "prior_fx_abs_err_pct",
        "prior_fy_abs_err_pct", "prior_cx_abs_err_px", "prior_cy_abs_err_px",
    ]
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _add_truth_errors(row: Dict[str, Any]) -> None:
    fx = _maybe_float(row.get("best_fx_px"))
    fy = _maybe_float(row.get("best_fy_px"))
    cx = _maybe_float(row.get("best_cx_px"))
    cy = _maybe_float(row.get("best_cy_px"))
    fx_gt = _maybe_float(row.get("fx_gt"))
    fy_gt = _maybe_float(row.get("fy_gt"))
    cx_gt = _maybe_float(row.get("cx_gt"))
    cy_gt = _maybe_float(row.get("cy_gt"))
    if fx is not None and fx_gt:
        row["fx_abs_err_pct"] = abs(fx - fx_gt) / abs(fx_gt) * 100.0
    if fy is not None and fy_gt:
        row["fy_abs_err_pct"] = abs(fy - fy_gt) / abs(fy_gt) * 100.0
    if cx is not None and cx_gt is not None:
        row["cx_abs_err_px"] = abs(cx - cx_gt)
    if cy is not None and cy_gt is not None:
        row["cy_abs_err_px"] = abs(cy - cy_gt)

    pfx = _maybe_float(row.get("prior_best_fx_px"))
    pfy = _maybe_float(row.get("prior_best_fy_px"))
    pcx = _maybe_float(row.get("prior_best_cx_px"))
    pcy = _maybe_float(row.get("prior_best_cy_px"))
    if pfx is not None and fx_gt:
        row["prior_fx_abs_err_pct"] = abs(pfx - fx_gt) / abs(fx_gt) * 100.0
    if pfy is not None and fy_gt:
        row["prior_fy_abs_err_pct"] = abs(pfy - fy_gt) / abs(fy_gt) * 100.0
    if pcx is not None and cx_gt is not None:
        row["prior_cx_abs_err_px"] = abs(pcx - cx_gt)
    if pcy is not None and cy_gt is not None:
        row["prior_cy_abs_err_px"] = abs(pcy - cy_gt)


def _write_markdown(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    counts: Dict[str, int] = {}
    for row in rows:
        status = str(row.get("probe_status", ""))
        counts[status] = counts.get(status, 0) + 1

    lines = [
        "# Partial Offset Probe",
        "",
        f"- Images probed: {len(rows)}",
        f"- Probe status counts: `{counts}`",
        "",
        "| image | group | original status | probe | prior probe | cube area % | candidates | prior cand | rmse px | fx px | prior fx | fx err % | prior fx err % | k1 |",
        "|---|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            "| {image} | {group} | {status} | {probe} | {pprobe} | "
            "{cube} | {cand} | {pcand} | {rmse} | {fx} | {pfx} | "
            "{fxe} | {pfxe} | {k1} |".format(
                image=row.get("image", ""),
                group=row.get("group", ""),
                status=row.get("status", ""),
                probe=row.get("probe_status", ""),
                pprobe=row.get("prior_probe_status", ""),
                cube=_fmt(row.get("cube_area_pct")),
                cand=row.get("valid_candidates", ""),
                pcand=row.get("prior_candidates", ""),
                rmse=_fmt(row.get("best_rmse_px")),
                fx=_fmt(row.get("best_fx_px")),
                pfx=_fmt(row.get("prior_best_fx_px")),
                fxe=_fmt(row.get("fx_abs_err_pct")),
                pfxe=_fmt(row.get("prior_fx_abs_err_pct")),
                k1=_fmt(row.get("best_k1")),
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _fmt(value: Any) -> str:
    f = _maybe_float(value)
    return "-" if f is None else f"{f:.3f}"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--batch-csv",
        type=Path,
        default=Path("batch_results/auto_strict_area_partial_rmse_v1/current_batch_results.csv"),
    )
    parser.add_argument("--image-root", type=Path, default=None)
    parser.add_argument("--out-dir", type=Path, default=Path("batch_results/partial_offset_probe_v1"))
    parser.add_argument("--rmse-limit", type=float, default=12.0)
    parser.add_argument("--k1-limit", type=float, default=0.8)
    parser.add_argument("--top-offsets", type=int, default=40)
    parser.add_argument("--ambiguity-gap-px", type=float, default=2.0)
    parser.add_argument("--focal-spread-limit", type=float, default=0.10)
    parser.add_argument(
        "--flip-mode",
        choices=["none", "axis", "all"],
        default="all",
        help="Corner-order flip enumeration for each offset candidate.",
    )
    parser.add_argument("--use-focal-prior", action="store_true")
    parser.add_argument("--min-prior-samples", type=int, default=3)
    parser.add_argument("--max-prior-rel-iqr", type=float, default=0.30)
    parser.add_argument("--prior-tolerance", type=float, default=0.15)
    parser.add_argument(
        "--include-status",
        action="append",
        default=None,
        help=(
            "Status values to probe. Defaults to the original partial/low "
            "confidence statuses; repeat to include range_boundary etc."
        ),
    )
    args = parser.parse_args()

    rows = _read_csv(args.batch_csv)
    priors = (
        build_group_focal_priors(
            rows,
            min_samples=args.min_prior_samples,
            max_rel_iqr=args.max_prior_rel_iqr,
        )
        if args.use_focal_prior else {}
    )
    if args.image_root is None:
        roots = sorted(Path(".").glob("*_extracted/shengkelou"))
        if not roots:
            raise FileNotFoundError("Could not find *_extracted/shengkelou")
        image_root = roots[0].resolve()
    else:
        image_root = args.image_root.resolve()

    include_status = set(
        args.include_status
        or ["partial_face_geometry_boundary", "low_confidence"]
    )
    selected = [
        row for row in rows
        if row.get("group") != "zhang"
        and row.get("status") in include_status
    ]
    out_rows: List[Dict[str, Any]] = []
    for i, row in enumerate(selected, 1):
        image_path = image_root / str(row.get("rel_path", ""))
        probe = probe_image(
            image_path,
            rmse_limit=args.rmse_limit,
            k1_limit=args.k1_limit,
            top_offsets=args.top_offsets,
            ambiguity_gap_px=args.ambiguity_gap_px,
            focal_spread_limit=args.focal_spread_limit,
            flip_mode=args.flip_mode,
            focal_prior=priors.get(str(row.get("group", ""))),
            focal_prior_tolerance=args.prior_tolerance,
        )
        merged = dict(row)
        merged.update(probe)
        _add_truth_errors(merged)
        out_rows.append(merged)
        print(f"[{i}/{len(selected)}] {row.get('image')} {merged.get('probe_status')}")

    args.out_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.out_dir / "partial_offset_probe_results.csv"
    md_path = args.out_dir / "partial_offset_probe_summary.md"
    _write_csv(csv_path, out_rows)
    _write_markdown(md_path, out_rows)
    print(f"Wrote: {csv_path}")
    print(f"Wrote: {md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
