from concurrent.futures import ThreadPoolExecutor
from run_stability_verification_20260914 import ROOT,OUT,POSES,save
from evaluate_stability_verification_20260914 import run
jobs=[('screen_'+p,[ROOT/'screen_stability_predictions_20260914.py',p]) for p in POSES[1:]]
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,jobs))
save(OUT/'prediction_screen_jobs.json',results)
