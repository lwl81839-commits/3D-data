from __future__ import annotations

import csv
import math
from collections import Counter
from pathlib import Path

import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[1]
RESULT_CSV = ROOT / "batch_results" / "full136_round5_fusion_20260718_v1" / "current_batch_results.csv"
OUT_DIR = ROOT / "paper_drafts" / "figures_20260718_v3"


def fnum(value: str):
    try:
        if value is None or value == "":
            return None
        return float(value)
    except ValueError:
        return None


def pearson(xs, ys):
    pairs = [(x, y) for x, y in zip(xs, ys) if x is not None and y is not None]
    if len(pairs) < 2:
        return float("nan")
    xvals = [p[0] for p in pairs]
    yvals = [p[1] for p in pairs]
    mx = sum(xvals) / len(xvals)
    my = sum(yvals) / len(yvals)
    num = sum((x - mx) * (y - my) for x, y in pairs)
    denx = math.sqrt(sum((x - mx) ** 2 for x in xvals))
    deny = math.sqrt(sum((y - my) ** 2 for y in yvals))
    if denx == 0 or deny == 0:
        return float("nan")
    return num / (denx * deny)


def load_rows():
    with RESULT_CSV.open("r", encoding="utf-8-sig", newline="") as fp:
        return list(csv.DictReader(fp))


def savefig(name: str):
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    path = OUT_DIR / name
    plt.tight_layout()
    plt.savefig(path, dpi=220, bbox_inches="tight")
    plt.close()
    return path


def style_axes(ax):
    ax.grid(True, color="#d8dee9", linewidth=0.8, alpha=0.7)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.tick_params(labelsize=9)


def fig_area_rmse(real_ok):
    areas = [fnum(r["cube_area_pct"]) for r in real_ok]
    rmses = [fnum(r["rmse_px"]) for r in real_ok]
    colors = ["#d95f02" if (a is not None and a < 2.0) else "#1f77b4" for a in areas]
    r = pearson(areas, rmses)

    fig, ax = plt.subplots(figsize=(6.6, 4.2))
    ax.scatter(areas, rmses, s=34, c=colors, alpha=0.82, edgecolor="white", linewidth=0.45)
    ax.axvline(2.0, color="#d95f02", linestyle="--", linewidth=1.4, label="2% guaranteed range reference")
    ax.set_xlabel("Cube footprint / image area (%)", fontsize=10)
    ax.set_ylabel("Reprojection RMSE (px)", fontsize=10)
    ax.set_title("Area Ratio vs. Calibration RMSE", fontsize=12)
    ax.text(
        0.98,
        0.95,
        f"n=98, Pearson r={r:.3f}",
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=9,
        bbox=dict(facecolor="white", edgecolor="#c8ccd0", boxstyle="round,pad=0.25"),
    )
    ax.legend(loc="upper right", bbox_to_anchor=(0.98, 0.86), frameon=True, fontsize=8)
    style_axes(ax)
    return savefig("fig1_area_ratio_vs_rmse.png")


def fig_area_time(real_ok):
    areas = [fnum(r["cube_area_pct"]) for r in real_ok]
    walls = [fnum(r["wall_elapsed_sec"]) for r in real_ok]
    colors = ["#d95f02" if (a is not None and a < 2.0) else "#2ca02c" for a in areas]
    r = pearson(areas, walls)

    fig, ax = plt.subplots(figsize=(6.6, 4.2))
    ax.scatter(areas, walls, s=34, c=colors, alpha=0.78, edgecolor="white", linewidth=0.45)
    ax.axvline(2.0, color="#d95f02", linestyle="--", linewidth=1.4, label="2% guaranteed range reference")
    ax.set_xlabel("Cube footprint / image area (%)", fontsize=10)
    ax.set_ylabel("Wall time per image (s)", fontsize=10)
    ax.set_title("Area Ratio vs. Calibration Runtime", fontsize=12)
    ax.text(
        0.98,
        0.95,
        f"n=98, Pearson r={r:.3f}",
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=9,
        bbox=dict(facecolor="white", edgecolor="#c8ccd0", boxstyle="round,pad=0.25"),
    )
    ax.legend(loc="upper right", bbox_to_anchor=(0.98, 0.86), frameon=True, fontsize=8)
    style_axes(ax)
    return savefig("fig2_area_ratio_vs_runtime.png")


def fig_decision_matrix(rows):
    true_target = [r for r in rows if r["group"] != "zhang" and r["status"] == "ok"]
    unusable = [r for r in rows if r["group"] != "zhang" and r["status"] != "ok"]
    zhang = [r for r in rows if r["group"] == "zhang"]

    labels = ["True trihedral cube", "Planar Zhang checkerboard", "No/unusable target"]
    accepted = [sum(1 for r in true_target if r["decision"] == "accepted"), sum(1 for r in zhang if r["decision"] == "accepted"), sum(1 for r in unusable if r["decision"] == "accepted")]
    rejected = [len(true_target) - accepted[0], len(zhang) - accepted[1], len(unusable) - accepted[2]]

    fig, ax = plt.subplots(figsize=(7.2, 4.0))
    y = range(len(labels))
    ax.barh(y, accepted, color="#1f77b4", label="Accepted/calibrated")
    ax.barh(y, rejected, left=accepted, color="#7f7f7f", label="Rejected/held")
    ax.set_yticks(list(y))
    ax.set_yticklabels(labels, fontsize=9)
    ax.set_xlabel("Number of images", fontsize=10)
    ax.set_title("Full-set Decision Outcomes", fontsize=12)
    for i, (a, h) in enumerate(zip(accepted, rejected)):
        if a:
            ax.text(a / 2, i, str(a), va="center", ha="center", color="white", fontsize=9, fontweight="bold")
        if h:
            ax.text(a + h / 2, i, str(h), va="center", ha="center", color="white", fontsize=9, fontweight="bold")
    ax.legend(loc="lower right", fontsize=8, frameon=True)
    style_axes(ax)
    return savefig("fig3_full_set_decision_outcomes.png")


def fig_route_contribution(real_ok):
    counts = Counter(r.get("calibration_status", "") or "unknown" for r in real_ok)
    display_names = {
        "grid_recovered_calibration": "Grid-recovered calibration",
        "downstream_quality_gate": "Downstream quality gate",
        "normal_quality_gate": "Normal quality gate",
        "final_manifest_calibration": "Final manifest calibration",
    }
    items = sorted(counts.items(), key=lambda kv: kv[1])
    labels = [display_names.get(k, k) for k, _ in items]
    values = [v for _, v in items]

    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    ax.barh(range(len(labels)), values, color="#4c78a8")
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels(labels, fontsize=8)
    ax.set_xlabel("Accepted true-target images", fontsize=10)
    ax.set_title("Accepted True Targets by Calibration Gate", fontsize=12)
    for i, v in enumerate(values):
        ax.text(v + 0.4, i, str(v), va="center", fontsize=8)
    ax.set_xlim(0, max(values) + 8)
    style_axes(ax)
    return savefig("fig4_candidate_gate_contributions.png")


def write_summary(rows, real_ok):
    status_counts = Counter(r["status"] for r in rows)
    area_bins = [
        ("<2%", lambda a: a is not None and a < 2),
        ("2-3%", lambda a: a is not None and 2 <= a < 3),
        ("3-6%", lambda a: a is not None and 3 <= a < 6),
        ("6-10%", lambda a: a is not None and 6 <= a < 10),
        (">=10%", lambda a: a is not None and a >= 10),
    ]
    out = OUT_DIR / "figure_source_summary.csv"
    with out.open("w", encoding="utf-8", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(["metric", "group", "value"])
        for key, value in sorted(status_counts.items()):
            writer.writerow(["status_count", key, value])
        writer.writerow(["real_ok_count", "all", len(real_ok)])
        writer.writerow(["area_rmse_pearson", "real_ok", f"{pearson([fnum(r['cube_area_pct']) for r in real_ok], [fnum(r['rmse_px']) for r in real_ok]):.6f}"])
        writer.writerow(["area_runtime_pearson", "real_ok", f"{pearson([fnum(r['cube_area_pct']) for r in real_ok], [fnum(r['wall_elapsed_sec']) for r in real_ok]):.6f}"])
        for name, pred in area_bins:
            subset = [r for r in real_ok if pred(fnum(r["cube_area_pct"]))]
            writer.writerow(["area_bin_count", name, len(subset)])
    return out


def main():
    rows = load_rows()
    real_ok = [r for r in rows if r["group"] != "zhang" and r["status"] == "ok"]
    paths = [
        fig_area_rmse(real_ok),
        fig_area_time(real_ok),
        fig_decision_matrix(rows),
        fig_route_contribution(real_ok),
    ]
    summary = write_summary(rows, real_ok)
    print("Generated figures:")
    for path in paths:
        print(path)
    print("Generated summary:")
    print(summary)


if __name__ == "__main__":
    main()
