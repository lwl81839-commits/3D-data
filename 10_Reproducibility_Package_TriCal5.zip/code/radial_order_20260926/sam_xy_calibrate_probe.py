#!/usr/bin/env python3
"""Calibrate from SAM-recovered XY corners plus direct XZ/YZ detections.

Offline probe only. It verifies whether the SAM + rectified XY detections that
pass fast cube PnP also survive the existing calibration pipeline when supplied
as precomputed three-face corners.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import cv2
import numpy as np
import torch
from segment_anything import SamPredictor, sam_model_registry

from best_calibration import (
    MAX_SMALL_TARGET_CORNER_QUALITY_PX,
    MAX_SMALL_TARGET_INITIAL_PNP_RMSE_PX,
    MAX_SMALL_TARGET_RMSE_PX,
    MIN_SMALL_TARGET_CORNERS,
    SMALL_TARGET_PATTERN_REPAIR_MAX_OFFSET_PNP_RMSE_PX,
    SMALL_TARGET_MAX_FOV_COVERAGE_PCT,
    SMALL_TARGET_VALIDATED_ACCEPT_MAX_AREA_PCT,
    SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT,
    calibrate_best,
)
from face_detector import (
    _cluster_dark_components,
    _cube_detection_best_offset_pnp_rmse,
    _cube_detection_geometry_rmse,
    _detect_cube_first,
    _label_cube_clusters,
    _normalize_face_axis_order,
    estimate_cube_area_pct,
)
from sam_xy_deep_probe import (
    PATTERNS,
    expand_box,
    mask_to_poly,
    read_image,
    try_rectified,
)


TARGET_FACE_PATTERNS = [(9, 6), (9, 6), (6, 6)]
MAX_RECOVERED_CORNER_OFFSET_PNP_RMSE_PX = min(
    MAX_SMALL_TARGET_INITIAL_PNP_RMSE_PX,
    SMALL_TARGET_PATTERN_REPAIR_MAX_OFFSET_PNP_RMSE_PX,
)


def pattern_exact(pattern, wanted):
    obs = (max(int(pattern[0]), int(pattern[1])),
           min(int(pattern[0]), int(pattern[1])))
    ref = (max(int(wanted[0]), int(wanted[1])),
           min(int(wanted[0]), int(wanted[1])))
    return obs == ref


def load_rel_paths(path: Path):
    return [
        line.strip().replace("\\", "/")
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]


def find_direct_side_faces(gray):
    direct = _detect_cube_first(gray, n_faces=3, verbose=False)
    sides = {}
    for corners, pat, label in direct:
        if label == "XZ" and pattern_exact(pat, (9, 6)):
            sides["XZ"] = (corners, pat, label)
        if label == "YZ" and pattern_exact(pat, (6, 6)):
            sides["YZ"] = (corners, pat, label)
    return direct, sides


def recover_xy(image, gray, predictor: SamPredictor):
    clusters = _label_cube_clusters(
        _cluster_dark_components(gray, n_faces=3, verbose=False))
    xy = next((face for face in clusters if face.get("label") == "XY"), None)
    if xy is None:
        return None, "no_xy_cluster"

    rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    polys = [("cluster", np.asarray(xy["poly"], dtype=np.float32))]
    predictor.set_image(rgb)
    for scale in (1.18, 1.42):
        box = expand_box(xy["poly"], gray.shape, scale)
        masks, scores, _ = predictor.predict(box=box, multimask_output=True)
        ranked = sorted(
            enumerate(zip(masks, scores)),
            key=lambda item: float(item[1][1]),
            reverse=True,
        )[:2]
        for mask_idx, (mask, score) in ranked:
            poly = mask_to_poly(mask)
            if poly is not None:
                polys.append((f"sam{mask_idx}-s{scale:.2f}-{float(score):.3f}", poly))

    attempts = 0
    for source, poly in polys:
        result = try_rectified(gray, poly, source)
        attempts += len(result.get("attempts", []))
        if result.get("found"):
            corners = np.asarray(result["corners"], dtype=np.float32).reshape(-1, 1, 2)
            return (
                (corners, result["pattern"], "XY", result["source"], result["method"], attempts),
                "found",
            )
    return None, f"not_found:{attempts}"


def object_corners_array(dets):
    arr = np.empty((len(dets),), dtype=object)
    for i, (corners, _pat, _label) in enumerate(dets):
        arr[i] = corners.reshape(-1, 1, 2).astype(np.float32)
    return arr


def probe_one(image_root: Path, rel: str, predictor: SamPredictor, out_dir: Path):
    image_path = image_root / rel
    image = read_image(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    cube_area = float(estimate_cube_area_pct(gray, n_faces=3))
    direct, sides = find_direct_side_faces(gray)
    direct_desc = ";".join(f"{label}:{pat[0]}x{pat[1]}" for _c, pat, label in direct)
    if "XZ" not in sides or "YZ" not in sides:
        return {
            "rel_path": rel,
            "status": "missing_side",
            "cube_area_pct": cube_area,
            "direct": direct_desc,
            "sides": ",".join(sorted(sides)),
        }

    xy, xy_status = recover_xy(image, gray, predictor)
    if xy is None:
        return {
            "rel_path": rel,
            "status": "xy_not_found",
            "cube_area_pct": cube_area,
            "direct": direct_desc,
            "xy_status": xy_status,
        }
    xy_corners, xy_pat, _label, xy_source, xy_method, xy_attempts = xy
    dets = _normalize_face_axis_order([xy[:3], sides["XZ"], sides["YZ"]])
    centered = _cube_detection_geometry_rmse(
        dets, gray.shape, n_faces=3, allow_sparse=False,
        assume_normalized=True)
    offset_rmse, offset, offset_dist = _cube_detection_best_offset_pnp_rmse(
        dets, gray.shape, n_faces=3, assume_normalized=True)

    corners_dir = out_dir / "corners"
    corners_dir.mkdir(parents=True, exist_ok=True)
    stem = rel.replace("/", "__").replace("\\", "__").rsplit(".", 1)[0]
    corners_path = corners_dir / f"{stem}_sam_xy.npz"
    np.savez(corners_path, corners=object_corners_array(dets))

    try:
        result = calibrate_best(
            str(image_path),
            25.0,
            face_patterns=TARGET_FACE_PATTERNS,
            corners_path=str(corners_path),
            verbose=False,
        )
        strict_failures = []
        if result.cube_area_pct is None or not (
            SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT
            <= result.cube_area_pct
            <= SMALL_TARGET_VALIDATED_ACCEPT_MAX_AREA_PCT
        ):
            strict_failures.append("area")
        if result.fov_coverage_pct > SMALL_TARGET_MAX_FOV_COVERAGE_PCT:
            strict_failures.append("coverage")
        if result.n_corners < MIN_SMALL_TARGET_CORNERS:
            strict_failures.append("corners")
        if result.corner_quality > MAX_SMALL_TARGET_CORNER_QUALITY_PX:
            strict_failures.append("line_quality")
        if result.rmse > MAX_SMALL_TARGET_RMSE_PX:
            strict_failures.append("rmse")
        if (
            np.isfinite(offset_rmse)
            and offset_rmse > MAX_RECOVERED_CORNER_OFFSET_PNP_RMSE_PX
        ):
            strict_failures.append("offset_pnp")
        return {
            "rel_path": rel,
            "status": "calibrated",
            "strict_like": "pass" if not strict_failures else "fail:" + ",".join(strict_failures),
            "cube_area_pct": result.cube_area_pct,
            "fov_coverage_pct": result.fov_coverage_pct,
            "n_corners": result.n_corners,
            "corner_quality": result.corner_quality,
            "rmse_px": result.rmse,
            "fx_px": result.fx_px,
            "fy_px": result.fy_px,
            "cx_px": result.cx_px,
            "cy_px": result.cy_px,
            "model": result.model_used,
            "centered_pnp": float(centered) if np.isfinite(centered) else None,
            "offset_pnp": float(offset_rmse) if np.isfinite(offset_rmse) else None,
            "offset": str(offset),
            "offset_dist": float(offset_dist) if np.isfinite(offset_dist) else None,
            "direct": direct_desc,
            "xy_source": xy_source,
            "xy_method": xy_method,
            "xy_attempts": xy_attempts,
            "warnings": " | ".join(result.warnings or []),
            "corners_path": str(corners_path),
        }
    except Exception as exc:
        return {
            "rel_path": rel,
            "status": "calibration_error",
            "error": str(exc),
            "cube_area_pct": cube_area,
            "direct": direct_desc,
            "centered_pnp": float(centered) if np.isfinite(centered) else None,
            "offset_pnp": float(offset_rmse) if np.isfinite(offset_rmse) else None,
            "xy_source": xy_source,
            "xy_method": xy_method,
            "corners_path": str(corners_path),
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--rel-list", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--model-type", default="vit_b")
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    sam = sam_model_registry[args.model_type](checkpoint=str(args.checkpoint))
    sam.to(device=device)
    predictor = SamPredictor(sam)

    rows = []
    for rel in load_rel_paths(args.rel_list):
        print(f"START {rel}", flush=True)
        try:
            row = probe_one(args.image_root, rel, predictor, args.out_dir)
        except Exception as exc:
            row = {"rel_path": rel, "status": "error", "error": str(exc)}
        print(json.dumps(row, ensure_ascii=False), flush=True)
        rows.append(row)

    (args.out_dir / "sam_xy_calibrate_results.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    accepted = [
        {
            "rel_path": row["rel_path"],
            "corners_path": row.get("corners_path"),
            "face_patterns": TARGET_FACE_PATTERNS,
            "model": row.get("model"),
            "cube_area_pct": row.get("cube_area_pct"),
            "fov_coverage_pct": row.get("fov_coverage_pct"),
            "n_corners": row.get("n_corners"),
            "corner_quality": row.get("corner_quality"),
            "rmse_px": row.get("rmse_px"),
            "fx_px": row.get("fx_px"),
            "fy_px": row.get("fy_px"),
            "offset_pnp": row.get("offset_pnp"),
            "xy_source": row.get("xy_source"),
            "xy_method": row.get("xy_method"),
        }
        for row in rows
        if row.get("status") == "calibrated"
        and row.get("strict_like") == "pass"
    ]
    (args.out_dir / "sam_xy_recovered_manifest.json").write_text(
        json.dumps({
            "face_patterns": TARGET_FACE_PATTERNS,
            "accepted_count": len(accepted),
            "accepted": accepted,
        }, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (args.out_dir / "sam_xy_recovered_relpaths.txt").write_text(
        "\n".join(item["rel_path"] for item in accepted) + ("\n" if accepted else ""),
        encoding="utf-8",
    )
    fields = sorted({key for row in rows for key in row})
    with (args.out_dir / "sam_xy_calibrate_results.csv").open(
        "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
