#!/usr/bin/env python3
"""Recover tiny targets by extrapolating partial face grids.

For 2%-3% cube targets, the detector often sees only local checkerboard
patches.  This probe treats those patches as sub-grids of the full face,
enumerates integer offsets inside plausible full-face patterns, scores each
extrapolation against image evidence, then replays the best full grids through
the normal calibrator.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import os
import time
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from best_calibration import calibrate_best, _fixed_focal_k1_pose_fallback
from face_detector import (
    _cluster_dark_components,
    _cube_detection_best_offset_pnp_rmse,
    _cube_detection_geometry_rmse,
    _detect_pattern_candidates_in_face,
    _find_trihedral_edge_layout,
    _label_cube_clusters,
    _line_quality_for_candidate,
    _patterns_for_label,
    _quad_from_poly,
    _normalize_face_axis_order,
    _trihedral_face_regions,
    detect_corner_cube_faces,
    estimate_cube_area_pct,
)
from partial_offset_probe import FULL_PATTERN_OPTIONS, _load_gray
from partial_offset_probe import _candidate_specs as partial_candidate_specs
from partial_offset_probe import _intrinsics_from_vps as partial_intrinsics_from_vps
from three_face_calib import preprocess_image
from three_face_calib import (
    DetectedFace,
    VanishingPoint,
    apply_best_face_orientations,
    calibrate_intrinsics_from_vps,
    estimate_vanishing_point,
    get_vp_labels,
    lines_from_chessboard_corners,
    object_points_for_face,
    standard_three_face_target,
)
from trihedral_boundary_probe import _edge_distance_map
from trihedral_closure_probe import (
    _best_oriented_pnp_rmse as trihedral_best_oriented_pnp_rmse,
    _infer_shared_edge_indices as trihedral_infer_shared_edge_indices,
    _quad_edge_support_summary as trihedral_quad_edge_support_summary,
    _spec_to_quads as trihedral_spec_to_quads,
)


def env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        value = float(raw)
    except ValueError:
        return default
    return value if np.isfinite(value) else default


MAX_JOINT_FACE_OVERLAP_RATIO = env_float(
    "GRID_PROBE_MAX_JOINT_FACE_OVERLAP_RATIO", 0.65)
CANONICAL_FULL_PATTERNS_ONLY = os.environ.get(
    "GRID_PROBE_CANONICAL_FULL_PATTERNS_ONLY", "0"
).strip().lower() in {"1", "true", "yes", "on"}
CANONICAL_PATTERN_SIGNATURE = sorted([(9, 6), (9, 6), (6, 6)])
JOINT_OVERLAP_RECOVERY_POOL = 8
FIXED_FOCAL_JOINT_REFINE_TOP = 24
NO_FOCAL_FINAL_REFINE_TOP = int(env_float(
    "GRID_PROBE_NO_FOCAL_FINAL_REFINE_TOP", 12))
NO_FOCAL_UNOBSERVABLE_REFINE_TOP = int(env_float(
    "GRID_PROBE_NO_FOCAL_UNOBSERVABLE_REFINE_TOP", 3))
FIXED_FOCAL_FINAL_REFINE_TOP = int(env_float(
    "GRID_PROBE_FIXED_FOCAL_FINAL_REFINE_TOP", 4))
FIXED_FOCAL_FINAL_REFINE_MAX_PROXY_RMSE = env_float(
    "GRID_PROBE_FIXED_FOCAL_FINAL_REFINE_MAX_PROXY_RMSE", 18.0)
ENABLE_NO_FOCAL_FINAL_REFINE = os.environ.get(
    "GRID_PROBE_ENABLE_NO_FOCAL_FINAL_REFINE", "1"
).strip().lower() in {"1", "true", "yes", "on"}
ENABLE_FIXED_FOCAL_FINAL_REFINE = os.environ.get(
    "GRID_PROBE_ENABLE_FIXED_FOCAL_FINAL_REFINE", "1"
).strip().lower() in {"1", "true", "yes", "on"}
SEED_GEOMETRY_REFINE_TOP = int(env_float(
    "GRID_PROBE_SEED_GEOMETRY_REFINE_TOP", 18))
COMPLETE_SEED_GEOMETRY_REFINE_TOP = int(env_float(
    "GRID_PROBE_COMPLETE_SEED_GEOMETRY_REFINE_TOP", 12))
COMPONENT_SEED_GEOMETRY_REFINE_TOP = int(env_float(
    "GRID_PROBE_COMPONENT_SEED_GEOMETRY_REFINE_TOP", 12))
COMPONENT_STRICT_RECTIFIED_SCALES = (1.0, 1.12, 1.28)
REGION_SEED_FACE_CANDIDATES = 12
REGION_ALTERNATIVE_SEEDS = 4
SEED_ONLY_FIXED_FOCAL_RMSE_LIMIT = env_float(
    "GRID_PROBE_SEED_ONLY_FIXED_FOCAL_RMSE_LIMIT", 16.0)
COMPONENT_SEED_ONLY_EARLY_RMSE_LIMIT = env_float(
    "GRID_PROBE_COMPONENT_SEED_ONLY_EARLY_RMSE_LIMIT", 15.0)
SEED_ONLY_PRESERVE_RMSE_LIMIT = env_float(
    "GRID_PROBE_SEED_ONLY_PRESERVE_RMSE_LIMIT", 9.0)
ENABLE_OUTER_EDGE_SCORE = os.environ.get(
    "GRID_PROBE_ENABLE_OUTER_EDGE_SCORE", "0"
).strip().lower() in {"1", "true", "yes", "on"}
OUTER_EDGE_SCORE_WEIGHT = env_float(
    "GRID_PROBE_OUTER_EDGE_SCORE_WEIGHT", 0.55)
OUTER_EDGE_SCORE_TOL_PX = env_float(
    "GRID_PROBE_OUTER_EDGE_SCORE_TOL_PX", 3.0)
ENABLE_SHARED_VP_SCORE = os.environ.get(
    "GRID_PROBE_ENABLE_SHARED_VP_SCORE", "0"
).strip().lower() in {"1", "true", "yes", "on"}
ENABLE_COMPONENT_SHARED_VP_SCORE = os.environ.get(
    "GRID_PROBE_ENABLE_COMPONENT_SHARED_VP_SCORE", "1"
).strip().lower() in {"1", "true", "yes", "on"}
SHARED_VP_SCORE_WEIGHT = env_float(
    "GRID_PROBE_SHARED_VP_SCORE_WEIGHT", 8.0)
SHARED_VP_FOCAL_WEIGHT = env_float(
    "GRID_PROBE_SHARED_VP_FOCAL_WEIGHT", 5.0)
AUTO_ROUTE_CHALLENGE_RMSE_PX = env_float(
    "GRID_PROBE_AUTO_ROUTE_CHALLENGE_RMSE_PX", 12.0)
TRIHEDRAL_CLOSURE_PNP_GATE_PX = env_float(
    "GRID_PROBE_TRIHEDRAL_CLOSURE_PNP_GATE_PX", 18.0)
TRIHEDRAL_CLOSURE_MIN_EDGE_SUPPORT = env_float(
    "GRID_PROBE_TRIHEDRAL_CLOSURE_MIN_EDGE_SUPPORT", 0.25)
TRIHEDRAL_CLOSURE_MAX_SPREAD_NORM = env_float(
    "GRID_PROBE_TRIHEDRAL_CLOSURE_MAX_SPREAD_NORM", 0.12)


def component_face_label_permutations_enabled() -> bool:
    return os.environ.get(
        "GRID_PROBE_COMPONENT_FACE_LABEL_PERMUTATIONS", "0"
    ).strip().lower() in {"1", "true", "yes", "on"}


def auto_route_name_filter() -> set[str] | None:
    raw = (
        os.environ.get("GRID_PROBE_AUTO_ROUTE_NAMES")
        or os.environ.get("CALIB_GRID_RECOVERY_ROUTES")
        or ""
    ).strip()
    if not raw:
        return None
    names = {
        item.strip()
        for item in raw.replace(";", ",").split(",")
        if item.strip()
    }
    return names or None


def auto_route_should_stop(row: dict[str, Any]) -> bool:
    status = row.get("status")
    if status == "not_cube_target":
        return True
    if status != "calibrated":
        return False
    if AUTO_ROUTE_CHALLENGE_RMSE_PX <= 0:
        return True
    try:
        rmse = float(row.get("rmse_px"))
    except (TypeError, ValueError):
        return False
    return math.isfinite(rmse) and rmse <= AUTO_ROUTE_CHALLENGE_RMSE_PX


def load_rel_paths(path: Path) -> list[str]:
    return [
        line.strip().replace("\\", "/")
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]


def jsonable(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    return str(value)


def object_corners_array(dets: list[tuple[np.ndarray, tuple[int, int], str]]) -> np.ndarray:
    return np.array(
        [corners.reshape(-1, 2).astype(np.float64) for corners, _pat, _label in dets],
        dtype=object,
    )


def rel_stem(rel: str) -> str:
    return rel.replace("/", "__").replace("\\", "__").rsplit(".", 1)[0]


def load_raw_detection_cache(
    cache_dir: Path | None,
    rel: str,
) -> list[tuple[np.ndarray, tuple[int, int], str]] | None:
    if cache_dir is None:
        return None
    path = cache_dir / f"{rel_stem(rel)}_raw_faces.npz"
    if not path.exists():
        return None
    try:
        data = np.load(path, allow_pickle=True)
        corners_arr = data["corners"]
        patterns_arr = data["patterns"]
        labels_arr = data["labels"]
        out = []
        for corners, pattern, label in zip(corners_arr, patterns_arr, labels_arr):
            out.append((
                np.asarray(corners, dtype=np.float32).reshape(-1, 1, 2),
                (int(pattern[0]), int(pattern[1])),
                str(label),
            ))
        data.close()
        return _normalize_face_axis_order(out)[:3]
    except Exception:
        return None


def save_raw_detection_cache(
    cache_dir: Path | None,
    rel: str,
    raw: list[tuple[np.ndarray, tuple[int, int], str]],
) -> None:
    if cache_dir is None or not raw:
        return
    cache_dir.mkdir(parents=True, exist_ok=True)
    path = cache_dir / f"{rel_stem(rel)}_raw_faces.npz"
    corners = np.array(
        [c.reshape(-1, 2).astype(np.float32) for c, _p, _l in raw],
        dtype=object,
    )
    patterns = np.array([[int(p[0]), int(p[1])] for _c, p, _l in raw], dtype=np.int32)
    labels = np.array([str(l) for _c, _p, l in raw], dtype=object)
    np.savez(path, corners=corners, patterns=patterns, labels=labels)


def grid_coords(pattern: tuple[int, int], offset: tuple[int, int] = (0, 0)) -> np.ndarray:
    cols, rows = pattern
    ox, oy = offset
    return np.array(
        [[x + ox, y + oy] for y in range(rows) for x in range(cols)],
        dtype=np.float32,
    )


def project_grid(h: np.ndarray, pattern: tuple[int, int], offset: tuple[int, int] = (0, 0)) -> np.ndarray:
    pts = grid_coords(pattern, offset).reshape(-1, 1, 2)
    return cv2.perspectiveTransform(pts, h).reshape(-1, 1, 2).astype(np.float32)


def sample_bilinear(img: np.ndarray, pts: np.ndarray) -> np.ndarray:
    h, w = img.shape[:2]
    xy = pts.reshape(-1, 2).astype(np.float32)
    x = xy[:, 0]
    y = xy[:, 1]
    valid = (x >= 0) & (x <= w - 2) & (y >= 0) & (y <= h - 2)
    out = np.full(len(x), np.nan, dtype=np.float32)
    if not np.any(valid):
        return out
    xv = x[valid]
    yv = y[valid]
    x0 = np.floor(xv).astype(np.int32)
    y0 = np.floor(yv).astype(np.int32)
    dx = xv - x0
    dy = yv - y0
    v = (
        img[y0, x0] * (1 - dx) * (1 - dy)
        + img[y0, x0 + 1] * dx * (1 - dy)
        + img[y0 + 1, x0] * (1 - dx) * dy
        + img[y0 + 1, x0 + 1] * dx * dy
    )
    out[valid] = v
    return out


def board_outer_quad_from_h(
    h: np.ndarray,
    full: tuple[int, int],
) -> np.ndarray | None:
    cols, rows = full
    outer = np.array(
        [[-1, -1], [cols, -1], [cols, rows], [-1, rows]],
        dtype=np.float32,
    ).reshape(-1, 1, 2)
    quad = cv2.perspectiveTransform(outer, h).reshape(-1, 2)
    if not np.all(np.isfinite(quad)):
        return None
    if abs(float(cv2.contourArea(quad.astype(np.float32)))) < 25.0:
        return None
    return quad.astype(np.float32)


def board_edge_distance_map(gray: np.ndarray) -> np.ndarray:
    enhanced = preprocess_image(gray, clip_limit=4.0)
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    edges_a = cv2.Canny(blur, 45, 135, apertureSize=3)
    edges_b = cv2.Canny(enhanced, 60, 180, apertureSize=3)
    edges = cv2.bitwise_or(edges_a, edges_b)
    edge_zero = np.where(edges > 0, 0, 255).astype(np.uint8)
    return cv2.distanceTransform(edge_zero, cv2.DIST_L2, 3).astype(np.float32)


def outer_edge_support_score(
    edge_distance: np.ndarray | None,
    h: np.ndarray,
    full: tuple[int, int],
) -> tuple[float, float]:
    if edge_distance is None:
        return 0.0, float("inf")
    quad = board_outer_quad_from_h(h, full)
    if quad is None:
        return 0.0, float("inf")
    samples: list[np.ndarray] = []
    for idx in range(4):
        p0 = quad[idx]
        p1 = quad[(idx + 1) % 4]
        length = float(np.linalg.norm(p1 - p0))
        if length < 2.0:
            continue
        n = max(8, min(80, int(round(length / 5.0))))
        ts = np.linspace(0.04, 0.96, n, dtype=np.float32)
        samples.append(
            p0.reshape(1, 2) * (1.0 - ts).reshape(-1, 1)
            + p1.reshape(1, 2) * ts.reshape(-1, 1)
        )
    if not samples:
        return 0.0, float("inf")
    pts = np.vstack(samples).reshape(-1, 1, 2).astype(np.float32)
    distances = sample_bilinear(edge_distance, pts)
    finite = distances[np.isfinite(distances)]
    if len(finite) < 8:
        return 0.0, float("inf")
    tol = max(0.75, float(OUTER_EDGE_SCORE_TOL_PX))
    support = float(np.mean(np.exp(-finite / tol)))
    mean_dist = float(np.mean(finite))
    return support, mean_dist


def face_candidate_vps(
    corners: np.ndarray,
    pattern: tuple[int, int],
) -> tuple[np.ndarray | None, np.ndarray | None]:
    try:
        row_lines, col_lines, _rq, _cq = lines_from_chessboard_corners(
            corners, pattern, use_ransac=False)
        if len(row_lines) < 2 or len(col_lines) < 2:
            return None, None
        vp_row = estimate_vanishing_point(np.asarray(row_lines)).v
        vp_col = estimate_vanishing_point(np.asarray(col_lines)).v
        return (
            np.asarray(vp_row, dtype=np.float64),
            np.asarray(vp_col, dtype=np.float64),
        )
    except Exception:
        return None, None


def full_pattern_options(label: str, partial: tuple[int, int]) -> list[tuple[int, int]]:
    cols, rows = partial
    options: list[tuple[int, int]] = []
    source_patterns = FULL_PATTERN_OPTIONS.get(label, [])
    if CANONICAL_FULL_PATTERNS_ONLY:
        source_patterns = [(9, 6), (6, 6)]
    for pat in source_patterns:
        for full in (tuple(pat), tuple(reversed(pat))):
            if full[0] >= cols and full[1] >= rows and full not in options:
                options.append(full)
    if not options:
        options.append(partial)
    return options


def unique_patterns(patterns: list[tuple[int, int]]) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    seen = set()
    for cols, rows in patterns:
        pat = (int(cols), int(rows))
        if pat not in seen:
            seen.add(pat)
            out.append(pat)
    return out


def face_search_patterns(label: str) -> list[tuple[int, int]]:
    # This strict branch proposes complete physical face grids.  Keep it to
    # the known target family; partial grids are handled by detector fallback.
    by_label = {
        "XY": [(9, 6), (6, 9), (6, 8), (8, 6)],
        "XZ": [(9, 6), (6, 9), (6, 6)],
        "YZ": [(6, 6), (9, 6), (6, 9)],
    }
    if CANONICAL_FULL_PATTERNS_ONLY:
        return [(9, 6), (6, 9), (6, 6)]
    return unique_patterns(by_label.get(label, [(9, 6), (6, 9), (6, 6)]))


def corners_inside_poly_ratio(corners: np.ndarray, poly: np.ndarray) -> float:
    pts = corners.reshape(-1, 2)
    polygon = np.asarray(poly, dtype=np.float32).reshape(-1, 2)
    if len(pts) == 0 or len(polygon) < 3:
        return 0.0
    inside = [
        cv2.pointPolygonTest(polygon, (float(x), float(y)), False) >= 0
        for x, y in pts
    ]
    return float(np.mean(inside))


def dedupe_ranked_candidates(
    candidates: list[tuple[float, np.ndarray, tuple[int, int], str, str, float]],
) -> list[tuple[float, np.ndarray, tuple[int, int], str, str, float]]:
    def family(source: str) -> str:
        text = str(source)
        if "strict-dark-grid" in text:
            return "dark-grid"
        if "strict-phase-grid" in text:
            return "phase-grid"
        if "strict-lattice" in text:
            return "lattice"
        if "strict-rect" in text:
            return "rectified"
        if text.startswith("direct-fallback"):
            return "direct"
        return text.split(":", 1)[0].split("-", 1)[0]

    ranked = sorted(candidates, key=lambda item: item[0], reverse=True)
    kept: list[tuple[float, np.ndarray, tuple[int, int], str, str, float]] = []
    for cand in ranked:
        _score, corners, pat, label, source, _inside = cand
        cand_family = family(source)
        box = bbox_of_corners(corners)
        duplicate = False
        for _old_score, old_corners, old_pat, old_label, old_source, _old_inside in kept:
            if label != old_label:
                continue
            old_family = family(old_source)
            same_family = cand_family == old_family
            overlap = bbox_overlap_ratio(box, bbox_of_corners(old_corners))
            if pat == old_pat and same_family and overlap > 0.82:
                duplicate = True
                break
            if same_family and overlap > 0.90:
                duplicate = True
                break
        if not duplicate:
            kept.append(cand)
    return kept


def strict_rectified_face_candidates(
    gray: np.ndarray,
    poly: np.ndarray,
    label: str,
    *,
    min_inside: float,
    max_candidates: int,
    enable_phase_grid: bool = False,
    enable_dark_square_grid: bool = False,
    strict_rectified_scales: tuple[float, ...] | None = None,
) -> list[tuple[float, np.ndarray, tuple[int, int], str, str, float]]:
    """Find candidates on one rectified physical face only."""
    quad0 = _quad_from_poly(poly)
    if quad0 is None:
        return []

    h_img, w_img = gray.shape[:2]
    patterns = face_search_patterns(label)[:6]
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    candidates: list[tuple[float, np.ndarray, tuple[int, int], str, str, float]] = []

    def lattice_points(
        pattern: tuple[int, int],
        margins: tuple[float, float, float, float],
        width: int,
        height: int,
    ) -> tuple[np.ndarray, np.ndarray]:
        cols, rows = pattern
        ml, mt, mr, mb = margins
        x0, x1 = ml * width, (1.0 - mr) * width
        y0, y1 = mt * height, (1.0 - mb) * height
        bw, bh = x1 - x0, y1 - y0
        corners = np.array(
            [
                [x0 + (x + 1) * bw / (cols + 1), y0 + (y + 1) * bh / (rows + 1)]
                for y in range(rows)
                for x in range(cols)
            ],
            dtype=np.float32,
        ).reshape(-1, 1, 2)
        centers = np.array(
            [
                [x0 + (x + 0.5) * bw / (cols + 1), y0 + (y + 0.5) * bh / (rows + 1)]
                for y in range(rows + 1)
                for x in range(cols + 1)
            ],
            dtype=np.float32,
        ).reshape(-1, 1, 2)
        return corners, centers

    def lattice_score(
        img: np.ndarray,
        response: np.ndarray,
        pattern: tuple[int, int],
        corners: np.ndarray,
        centers: np.ndarray,
        margins: tuple[float, float, float, float],
    ) -> float:
        cols, rows = pattern
        values = sample_bilinear(img, centers)
        parity = np.array(
            [(x + y) & 1 for y in range(rows + 1) for x in range(cols + 1)],
            dtype=np.int32,
        )
        valid = np.isfinite(values)
        contrast = 0.0
        if (
            np.count_nonzero(valid & (parity == 0)) >= 4
            and np.count_nonzero(valid & (parity == 1)) >= 4
        ):
            contrast = abs(
                float(np.nanmean(values[valid & (parity == 0)]))
                - float(np.nanmean(values[valid & (parity == 1)]))
            )
        resp = sample_bilinear(response, corners)
        finite = resp[np.isfinite(resp)]
        response_score = float(np.mean(finite)) if len(finite) else 0.0
        margin_penalty = sum(abs(v - 0.06) for v in margins)
        canonical_bonus = 4.0 if (max(pattern), min(pattern)) in {(9, 6), (6, 6)} else 0.0
        return (
            0.055 * contrast
            + 5.0 * response_score
            + canonical_bonus
            - 3.0 * margin_penalty
        )

    def checker_alternation_metrics(
        img: np.ndarray,
        pattern: tuple[int, int],
        centers: np.ndarray,
    ) -> dict[str, float]:
        """Score black/white checker alternation after removing illumination tilt."""
        cols, rows = pattern
        xy = centers.reshape(-1, 2).astype(np.float32)
        values = sample_bilinear(img, centers).astype(np.float32)
        parity = np.array(
            [1.0 if ((x + y) & 1) else -1.0
             for y in range(rows + 1) for x in range(cols + 1)],
            dtype=np.float32,
        )
        valid = np.isfinite(values)
        if np.count_nonzero(valid) < max(12, len(values) // 2):
            return {"score": 0.0, "agreement": 0.0, "diff": 0.0, "corr": 0.0}
        x = xy[valid, 0]
        y = xy[valid, 1]
        vals = values[valid].astype(np.float64)
        signs = parity[valid].astype(np.float64)
        design = np.column_stack([
            x / max(float(np.nanmax(x) - np.nanmin(x)), 1.0),
            y / max(float(np.nanmax(y) - np.nanmin(y)), 1.0),
            np.ones_like(x, dtype=np.float64),
        ])
        try:
            plane, *_ = np.linalg.lstsq(design, vals, rcond=None)
            resid = vals - design @ plane
        except np.linalg.LinAlgError:
            resid = vals - float(np.nanmean(vals))
        if not np.any(np.isfinite(resid)):
            return {"score": 0.0, "agreement": 0.0, "diff": 0.0, "corr": 0.0}
        signed = resid * signs
        polarity = 1.0 if float(np.nanmean(signed)) >= 0.0 else -1.0
        agreement = float(np.mean((signed * polarity) > 0.0))
        group_a = resid[signs < 0]
        group_b = resid[signs > 0]
        if len(group_a) < 4 or len(group_b) < 4:
            return {"score": 0.0, "agreement": agreement, "diff": 0.0, "corr": 0.0}
        diff = abs(float(np.nanmean(group_a) - np.nanmean(group_b)))
        within = 0.5 * (
            float(np.nanstd(group_a)) + float(np.nanstd(group_b))
        )
        corr = abs(float(np.nanmean(signed))) / max(float(np.nanstd(resid)), 1.0)
        score = (
            1.8 * max(0.0, agreement - 0.50)
            + 0.12 * diff
            + 2.8 * corr
            - 0.035 * within
        )
        return {
            "score": float(score),
            "agreement": agreement,
            "diff": float(diff),
            "corr": float(corr),
        }

    def sample_1d(values: np.ndarray, positions: np.ndarray) -> np.ndarray:
        x = np.asarray(positions, dtype=np.float32)
        valid = (x >= 0) & (x <= len(values) - 2)
        out = np.full(len(x), np.nan, dtype=np.float32)
        if not np.any(valid):
            return out
        x0 = np.floor(x[valid]).astype(np.int32)
        dx = x[valid] - x0
        out[valid] = values[x0] * (1.0 - dx) + values[x0 + 1] * dx
        return out

    def axis_sequence_candidates(
        projection: np.ndarray,
        n_points: int,
        length: int,
        *,
        max_sequences: int = 8,
        nominal_denominator: float | None = None,
    ) -> list[dict[str, Any]]:
        if n_points <= 1 or length <= n_points + 2:
            return []
        proj = projection.astype(np.float32)
        proj = proj - float(np.nanmin(proj))
        peak = float(np.nanmax(proj))
        if not np.isfinite(peak) or peak <= 1e-6:
            return []
        proj = proj / peak
        proj = cv2.GaussianBlur(proj.reshape(1, -1), (0, 0), 2.0).ravel()
        denom = float(nominal_denominator or (n_points + 1))
        nominal = float(length) / max(denom, 1.0)
        step_values = np.linspace(0.62 * nominal, 1.42 * nominal, 20)
        rows: list[dict[str, Any]] = []
        for step in step_values:
            max_start = float(length - 1) - (n_points - 1) * float(step)
            min_start = max(2.0, 0.015 * float(length))
            max_start = min(max_start, 0.985 * float(length))
            if max_start <= min_start:
                continue
            start_values = np.linspace(min_start, max_start, 24)
            for start in start_values:
                pos = start + float(step) * np.arange(n_points, dtype=np.float32)
                vals = sample_1d(proj, pos)
                if np.count_nonzero(np.isfinite(vals)) < n_points:
                    continue
                score = float(np.nanmean(vals))
                left_margin = float(pos[0])
                right_margin = float(length - 1 - pos[-1])
                if min(left_margin, right_margin) < 1.0:
                    continue
                margin_balance = abs(left_margin - right_margin) / max(length, 1)
                step_prior = abs(float(step) - nominal) / max(nominal, 1e-6)
                score -= 0.10 * margin_balance + 0.04 * step_prior
                rows.append({
                    "score": score,
                    "start": float(start),
                    "step": float(step),
                    "positions": pos.astype(np.float32),
                    "margins": (left_margin, right_margin),
                })
        rows.sort(key=lambda r: r["score"], reverse=True)
        kept: list[dict[str, Any]] = []
        for row in rows:
            duplicate = False
            for old in kept:
                if (
                    abs(row["start"] - old["start"]) < 0.22 * min(row["step"], old["step"])
                    and abs(row["step"] - old["step"]) < 0.12 * min(row["step"], old["step"])
                ):
                    duplicate = True
                    break
            if not duplicate:
                kept.append(row)
            if len(kept) >= min(max_sequences, 4):
                break
        return kept

    def phase_grid_candidates(
        img: np.ndarray,
        response: np.ndarray,
        pattern: tuple[int, int],
        width: int,
        height: int,
    ) -> list[tuple[float, np.ndarray, np.ndarray, str]]:
        cols, rows = pattern
        # Use high-percentile projections so true grid-line intersections are
        # preserved even when large blank face regions dominate the average.
        proj_x = np.percentile(response, 82, axis=0).astype(np.float32)
        proj_y = np.percentile(response, 82, axis=1).astype(np.float32)
        x_sequences = axis_sequence_candidates(proj_x, cols, width)
        y_sequences = axis_sequence_candidates(proj_y, rows, height)
        out: list[tuple[float, np.ndarray, np.ndarray, str]] = []
        for xi, xs in enumerate(x_sequences[:6]):
            for yi, ys in enumerate(y_sequences[:6]):
                x_pos = xs["positions"]
                y_pos = ys["positions"]
                corners = np.array(
                    [[x, y] for y in y_pos for x in x_pos],
                    dtype=np.float32,
                ).reshape(-1, 1, 2)
                sx, sy = float(xs["step"]), float(ys["step"])
                cx0, cy0 = float(x_pos[0] - 0.5 * sx), float(y_pos[0] - 0.5 * sy)
                centers = np.array(
                    [
                        [cx0 + x * sx, cy0 + y * sy]
                        for y in range(rows + 1)
                        for x in range(cols + 1)
                    ],
                    dtype=np.float32,
                ).reshape(-1, 1, 2)
                photo = lattice_score(
                    img,
                    response,
                    pattern,
                    corners,
                    centers,
                    (
                        float(x_pos[0] / max(width, 1)),
                        float(y_pos[0] / max(height, 1)),
                        float((width - 1 - x_pos[-1]) / max(width, 1)),
                        float((height - 1 - y_pos[-1]) / max(height, 1)),
                    ),
                )
                resp_vals = sample_bilinear(response, corners)
                resp_mean = float(np.nanmean(resp_vals)) if np.any(np.isfinite(resp_vals)) else 0.0
                checker = checker_alternation_metrics(img, pattern, centers)
                score = (
                    14.0 * float(xs["score"])
                    + 14.0 * float(ys["score"])
                    + 10.0 * resp_mean
                    + photo
                    + 18.0 * checker["score"]
                )
                source = (
                    f"strict-phase-grid-x{xi}-y{yi}-"
                    f"sx{sx:.1f}-sy{sy:.1f}-"
                    f"alt{checker['agreement']:.2f}"
                )
                out.append((float(score), corners, centers, source))
        out.sort(key=lambda item: item[0], reverse=True)
        return out[:10]

    def dark_square_grid_candidates(
        img: np.ndarray,
        response: np.ndarray,
        pattern: tuple[int, int],
        width: int,
        height: int,
    ) -> list[tuple[float, np.ndarray, np.ndarray, str]]:
        cols, rows = pattern
        blur = cv2.GaussianBlur(img, (0, 0), 1.2).astype(np.float32)
        base = float(np.percentile(blur, 58))
        dark_strength = np.clip(base - blur, 0.0, None)
        peak = float(np.nanmax(dark_strength))
        if not np.isfinite(peak) or peak <= 1e-6:
            return []
        dark_strength = dark_strength / peak
        proj_x = np.percentile(dark_strength, 88, axis=0).astype(np.float32)
        proj_y = np.percentile(dark_strength, 88, axis=1).astype(np.float32)
        x_sequences = axis_sequence_candidates(
            proj_x,
            cols + 1,
            width,
            nominal_denominator=cols + 1,
        )
        y_sequences = axis_sequence_candidates(
            proj_y,
            rows + 1,
            height,
            nominal_denominator=rows + 1,
        )
        out: list[tuple[float, np.ndarray, np.ndarray, str]] = []
        for xi, xs in enumerate(x_sequences[:5]):
            for yi, ys in enumerate(y_sequences[:5]):
                sx, sy = float(xs["step"]), float(ys["step"])
                square_x = xs["positions"].astype(np.float32)
                square_y = ys["positions"].astype(np.float32)
                if len(square_x) != cols + 1 or len(square_y) != rows + 1:
                    continue
                corner_x = 0.5 * (square_x[:-1] + square_x[1:])
                corner_y = 0.5 * (square_y[:-1] + square_y[1:])
                corners = np.array(
                    [[x, y] for y in corner_y for x in corner_x],
                    dtype=np.float32,
                ).reshape(-1, 1, 2)
                centers = np.array(
                    [[x, y] for y in square_y for x in square_x],
                    dtype=np.float32,
                ).reshape(-1, 1, 2)
                checker = checker_alternation_metrics(img, pattern, centers)
                resp_vals = sample_bilinear(response, corners)
                resp_mean = (
                    float(np.nanmean(resp_vals))
                    if np.any(np.isfinite(resp_vals))
                    else 0.0
                )
                center_vals = sample_bilinear(img, centers)
                parity = np.array(
                    [(x + y) & 1 for y in range(rows + 1) for x in range(cols + 1)],
                    dtype=np.int32,
                )
                valid = np.isfinite(center_vals)
                contrast = 0.0
                if (
                    np.count_nonzero(valid & (parity == 0)) >= 4
                    and np.count_nonzero(valid & (parity == 1)) >= 4
                ):
                    contrast = abs(
                        float(np.nanmean(center_vals[valid & (parity == 0)]))
                        - float(np.nanmean(center_vals[valid & (parity == 1)]))
                    )
                score = (
                    13.0 * float(xs["score"])
                    + 13.0 * float(ys["score"])
                    + 7.0 * resp_mean
                    + 0.055 * contrast
                    + 16.0 * checker["score"]
                )
                source = (
                    f"strict-dark-grid-x{xi}-y{yi}-"
                    f"sx{sx:.1f}-sy{sy:.1f}-"
                    f"alt{checker['agreement']:.2f}"
                )
                out.append((float(score), corners, centers, source))
        out.sort(key=lambda item: item[0], reverse=True)
        return out[:10]

    def refine_synthetic_rectified_corners(
        img: np.ndarray,
        corners: np.ndarray,
        pattern: tuple[int, int],
    ) -> tuple[np.ndarray, bool]:
        enabled = os.environ.get(
            "GRID_PROBE_REFINE_SYNTHETIC_RECTIFIED_CORNERS", "0"
        ).strip().lower() in {"1", "true", "yes", "on"}
        if not enabled:
            return corners, False
        try:
            win = int(float(os.environ.get(
                "GRID_PROBE_SYNTHETIC_RECTIFIED_SUBPIX_WINDOW", "5")))
        except ValueError:
            win = 5
        win = max(3, min(15, win))
        if win % 2 == 0:
            win += 1
        try:
            max_shift_px = float(os.environ.get(
                "GRID_PROBE_SYNTHETIC_RECTIFIED_MAX_SHIFT_PX", "16.0"))
        except ValueError:
            max_shift_px = 16.0
        src = np.ascontiguousarray(img.astype(np.uint8))
        original = corners.reshape(-1, 1, 2).astype(np.float32)
        before = _line_quality_for_candidate(original, pattern)
        try:
            refined = cv2.cornerSubPix(
                src,
                original.copy(),
                (win, win),
                (-1, -1),
                (
                    cv2.TERM_CRITERIA_EPS
                    + cv2.TERM_CRITERIA_MAX_ITER,
                    40,
                    1e-4,
                ),
            )
        except cv2.error:
            return corners, False
        shifts = np.linalg.norm(
            refined.reshape(-1, 2) - original.reshape(-1, 2),
            axis=1,
        )
        after = _line_quality_for_candidate(refined, pattern)
        if not len(shifts) or not np.all(np.isfinite(shifts)):
            return corners, False
        if float(np.percentile(shifts, 95)) > max_shift_px:
            return corners, False
        if np.isfinite(after) and after > max(1.5, float(before) * 3.0):
            return corners, False
        return refined.astype(np.float32), True

    scales = strict_rectified_scales or (1.00, 1.12, 1.28, 1.45, 1.62)
    for scale in scales:
        center = quad0.mean(axis=0)
        quad = center + (quad0 - center) * float(scale)
        quad[:, 0] = np.clip(quad[:, 0], 0, w_img - 1)
        quad[:, 1] = np.clip(quad[:, 1], 0, h_img - 1)
        inside_poly = quad.astype(np.float32)
        edges = [np.linalg.norm(quad[(i + 1) % 4] - quad[i]) for i in range(4)]
        if min(edges) < 8:
            continue
        dst_w = max(420, min(1200, int(max(edges[0], edges[2]) * 8.0)))
        dst_h = max(320, min(1000, int(max(edges[1], edges[3]) * 8.0)))
        dst = np.array(
            [[0, 0], [dst_w - 1, 0], [dst_w - 1, dst_h - 1], [0, dst_h - 1]],
            dtype=np.float32,
        )
        H = cv2.getPerspectiveTransform(quad.astype(np.float32), dst)
        H_inv = cv2.getPerspectiveTransform(dst, quad.astype(np.float32))
        warped = cv2.warpPerspective(
            gray,
            H,
            (dst_w, dst_h),
            flags=cv2.INTER_CUBIC,
            borderMode=cv2.BORDER_REPLICATE,
        )
        sharp = cv2.addWeighted(
            warped, 1.6, cv2.GaussianBlur(warped, (0, 0), 1.2), -0.6, 0)
        enhanced_lattice = preprocess_image(warped, clip_limit=4.0)
        response = cv2.cornerMinEigenVal(enhanced_lattice, blockSize=5, ksize=3)
        response = response / max(float(np.nanmax(response)), 1e-6)
        margin_values = (0.02, 0.06, 0.10, 0.14)
        for pat in patterns:
            if enable_phase_grid:
                for phase_score, corners_rect, _centers_rect, phase_source in phase_grid_candidates(
                    enhanced_lattice,
                    response,
                    pat,
                    dst_w,
                    dst_h,
                ):
                    corners_rect, refined = refine_synthetic_rectified_corners(
                        enhanced_lattice, corners_rect, pat)
                    mapped = cv2.perspectiveTransform(corners_rect, H_inv)
                    inside = corners_inside_poly_ratio(mapped, inside_poly)
                    if inside < min_inside:
                        continue
                    score = (
                        float(len(mapped))
                        + 18.0 * inside
                        + phase_score
                        - 0.5 * abs(float(scale) - 1.0)
                    )
                    source = f"{phase_source}-s{scale:.2f}"
                    if refined:
                        source += "-subpix"
                    candidates.append((score, mapped, pat, label, source, inside))

            if enable_dark_square_grid:
                for dark_score, corners_rect, _centers_rect, dark_source in dark_square_grid_candidates(
                    enhanced_lattice,
                    response,
                    pat,
                    dst_w,
                    dst_h,
                ):
                    corners_rect, refined = refine_synthetic_rectified_corners(
                        enhanced_lattice, corners_rect, pat)
                    mapped = cv2.perspectiveTransform(corners_rect, H_inv)
                    inside = corners_inside_poly_ratio(mapped, inside_poly)
                    if inside < min_inside:
                        continue
                    score = (
                        float(len(mapped))
                        + 18.0 * inside
                        + dark_score
                        - 0.5 * abs(float(scale) - 1.0)
                    )
                    source = f"{dark_source}-s{scale:.2f}"
                    if refined:
                        source += "-subpix"
                    candidates.append((score, mapped, pat, label, source, inside))

            for ml in margin_values:
                for mr in margin_values:
                    for mt in margin_values:
                        for mb in margin_values:
                            corners_rect, centers_rect = lattice_points(
                                pat, (ml, mt, mr, mb), dst_w, dst_h)
                            mapped = cv2.perspectiveTransform(corners_rect, H_inv)
                            inside = corners_inside_poly_ratio(mapped, inside_poly)
                            if inside < min_inside:
                                continue
                            photo = lattice_score(
                                enhanced_lattice,
                                response,
                                pat,
                                corners_rect,
                                centers_rect,
                                (ml, mt, mr, mb),
                            )
                            score = (
                                float(len(mapped))
                                + 18.0 * inside
                                + photo
                                - 0.5 * abs(float(scale) - 1.0)
                            )
                            source = (
                                f"strict-lattice-s{scale:.2f}-"
                                f"m{ml:.2f},{mt:.2f},{mr:.2f},{mb:.2f}"
                            )
                            candidates.append((score, mapped, pat, label, source, inside))

        enable_rectified_extra = os.environ.get(
            "GRID_PROBE_ENABLE_RECTIFIED_EXTRA_CANDIDATES", "0"
        ).strip().lower() in {"1", "true", "yes", "on"}
        variants = [
            ("rect-clahe4", enhanced_lattice),
            ("rect-sharp", sharp),
        ]
        if enable_rectified_extra:
            variants.extend([
                ("rect-clahe2", preprocess_image(warped, clip_limit=2.0)),
                ("rect-eq", cv2.equalizeHist(warped)),
            ])
        for variant_name, img in variants:
            for pat in patterns:
                ok, corners = cv2.findChessboardCorners(img, pat, flags=flags)
                source = f"strict-{variant_name}-s{scale:.2f}"
                if not ok or corners is None:
                    continue
                mapped = cv2.perspectiveTransform(
                    corners.reshape(-1, 1, 2).astype(np.float32), H_inv)
                inside = corners_inside_poly_ratio(mapped, inside_poly)
                if inside < min_inside:
                    continue
                quality = _line_quality_for_candidate(mapped, pat)
                if not np.isfinite(quality):
                    quality = 8.0
                canonical_bonus = 8.0 if (max(pat), min(pat)) in {
                    (9, 6), (6, 6)
                } else 0.0
                score = (
                    float(len(mapped))
                    + 30.0 * inside
                    + canonical_bonus
                    - 4.0 * float(min(quality, 8.0))
                    - 2.0 * abs(float(scale) - 1.0)
                )
                candidates.append((score, mapped, pat, label, source, inside))
                break

        if enable_rectified_extra and hasattr(cv2, "findChessboardCornersSB"):
            sb_flags = cv2.CALIB_CB_NORMALIZE_IMAGE
            for variant_name, img in variants:
                for pat in patterns:
                    try:
                        ok, corners = cv2.findChessboardCornersSB(
                            img, pat, flags=sb_flags)
                    except cv2.error:
                        ok, corners = False, None
                    source = f"strict-{variant_name}-SB-s{scale:.2f}"
                    if not ok or corners is None:
                        continue
                    mapped = cv2.perspectiveTransform(
                        corners.reshape(-1, 1, 2).astype(np.float32), H_inv)
                    inside = corners_inside_poly_ratio(mapped, inside_poly)
                    if inside < min_inside:
                        continue
                    quality = _line_quality_for_candidate(mapped, pat)
                    if not np.isfinite(quality):
                        quality = 8.0
                    canonical_bonus = 8.0 if (max(pat), min(pat)) in {
                        (9, 6), (6, 6)
                    } else 0.0
                    score = (
                        float(len(mapped))
                        + 30.0 * inside
                        + canonical_bonus
                        - 4.0 * float(min(quality, 8.0))
                        - 2.0 * abs(float(scale) - 1.0)
                        + 2.0
                    )
                    candidates.append((score, mapped, pat, label, source, inside))
                    break

    return dedupe_ranked_candidates(candidates)[:max_candidates]


def score_extrapolation(
    gray: np.ndarray,
    response: np.ndarray,
    h: np.ndarray,
    partial: tuple[int, int],
    full: tuple[int, int],
    offset: tuple[int, int],
    edge_distance: np.ndarray | None = None,
) -> dict[str, Any]:
    full_pts = project_grid(h, full)
    partial_pts = project_grid(h, partial, offset)
    h_img, w_img = gray.shape[:2]
    all_xy = full_pts.reshape(-1, 2)
    inside = (
        (all_xy[:, 0] >= 0)
        & (all_xy[:, 0] < w_img)
        & (all_xy[:, 1] >= 0)
        & (all_xy[:, 1] < h_img)
    )
    inside_ratio = float(np.mean(inside)) if len(inside) else 0.0

    corner_resp = sample_bilinear(response, full_pts)
    finite_resp = corner_resp[np.isfinite(corner_resp)]
    response_score = float(np.mean(finite_resp)) if len(finite_resp) else 0.0

    cols, rows = full
    centers = np.array(
        [[x - 0.5, y - 0.5] for y in range(rows + 1) for x in range(cols + 1)],
        dtype=np.float32,
    ).reshape(-1, 1, 2)
    centers_img = cv2.perspectiveTransform(centers, h).reshape(-1, 1, 2)
    values = sample_bilinear(gray, centers_img)
    parity = np.array(
        [(x + y) & 1 for y in range(rows + 1) for x in range(cols + 1)],
        dtype=np.int32,
    )
    valid = np.isfinite(values)
    contrast = 0.0
    if np.count_nonzero(valid & (parity == 0)) >= 4 and np.count_nonzero(valid & (parity == 1)) >= 4:
        contrast = abs(float(np.nanmean(values[valid & (parity == 0)])) - float(np.nanmean(values[valid & (parity == 1)])))

    outer_edge_support, outer_edge_mean_dist = outer_edge_support_score(
        edge_distance, h, full)

    # Penalize extrapolations that put many predicted corners outside image, but
    # allow a little spill because outer face borders may be near the crop edge.
    score = (
        0.020 * contrast
        + 1.50 * response_score
        + 0.80 * inside_ratio
        + float(OUTER_EDGE_SCORE_WEIGHT) * outer_edge_support
        - 0.15 * math.hypot(float(offset[0]), float(offset[1]))
    )
    return {
        "score": float(score),
        "contrast": float(contrast),
        "response": response_score,
        "inside_ratio": inside_ratio,
        "outer_edge_support": float(outer_edge_support),
        "outer_edge_mean_dist": float(outer_edge_mean_dist),
        "full_corners": full_pts,
        "partial_reproj": partial_pts,
    }


def recover_face(
    gray: np.ndarray,
    response: np.ndarray,
    corners: np.ndarray,
    partial: tuple[int, int],
    label: str,
    *,
    enable_shared_vp_score: bool = ENABLE_SHARED_VP_SCORE,
) -> dict[str, Any]:
    image_pts = corners.reshape(-1, 2).astype(np.float32)
    best: dict[str, Any] | None = None
    rows: list[dict[str, Any]] = []
    edge_distance = board_edge_distance_map(gray) if ENABLE_OUTER_EDGE_SCORE else None
    for full in full_pattern_options(label, partial):
        for ox in range(full[0] - partial[0] + 1):
            for oy in range(full[1] - partial[1] + 1):
                src = grid_coords(partial, (ox, oy))
                if len(src) < 4:
                    continue
                h, mask = cv2.findHomography(src, image_pts, method=0)
                if h is None or not np.all(np.isfinite(h)):
                    continue
                scored = score_extrapolation(
                    gray, response, h, partial, full, (ox, oy),
                    edge_distance=edge_distance,
                )
                vp_row, vp_col = (
                    face_candidate_vps(scored["full_corners"], full)
                    if enable_shared_vp_score
                    else (None, None)
                )
                row = {
                    "label": label,
                    "partial_pattern": partial,
                    "full_pattern": full,
                    "offset": (ox, oy),
                    "score": scored["score"],
                    "contrast": scored["contrast"],
                    "response": scored["response"],
                    "inside_ratio": scored["inside_ratio"],
                    "outer_edge_support": scored["outer_edge_support"],
                    "outer_edge_mean_dist": scored["outer_edge_mean_dist"],
                    "h": h,
                    "full_corners": scored["full_corners"],
                    "_vp_row": vp_row,
                    "_vp_col": vp_col,
                }
                rows.append(row)
                if best is None or row["score"] > best["score"]:
                    best = row
    if best is None:
        return {"status": "no_candidate", "candidates": 0}
    rows.sort(key=lambda r: r["score"], reverse=True)
    best = rows[0]
    second = rows[1] if len(rows) > 1 else None
    return {
        "status": "ok",
        "candidates": len(rows),
        "best": best,
        "score_gap": None if second is None else float(best["score"] - second["score"]),
        "top": rows[:5],
        "ranked": rows,
    }


def dedupe_recovered_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    kept: list[dict[str, Any]] = []
    for row in sorted(rows, key=lambda r: float(r["score"]), reverse=True):
        box = bbox_of_corners(row["full_corners"])
        duplicate = False
        for old in kept:
            if row["label"] != old["label"]:
                continue
            if row["full_pattern"] != old["full_pattern"]:
                continue
            if bbox_overlap_ratio(box, bbox_of_corners(old["full_corners"])) > 0.88:
                duplicate = True
                break
        if not duplicate:
            kept.append(row)
    return kept


def bbox_of_corners(corners: np.ndarray) -> tuple[float, float, float, float]:
    pts = corners.reshape(-1, 2)
    return (
        float(np.min(pts[:, 0])),
        float(np.min(pts[:, 1])),
        float(np.max(pts[:, 0])),
        float(np.max(pts[:, 1])),
    )


def bbox_overlap_ratio(
    a: tuple[float, float, float, float],
    b: tuple[float, float, float, float],
) -> float:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    if ix2 <= ix1 or iy2 <= iy1:
        return 0.0
    inter = (ix2 - ix1) * (iy2 - iy1)
    area_a = max((ax2 - ax1) * (ay2 - ay1), 1e-6)
    area_b = max((bx2 - bx1) * (by2 - by1), 1e-6)
    return float(inter / min(area_a, area_b))


def max_corner_bbox_overlap(corner_sets: list[np.ndarray]) -> float:
    if len(corner_sets) < 2:
        return 0.0
    boxes = [bbox_of_corners(corners) for corners in corner_sets]
    max_overlap = 0.0
    for ia in range(len(boxes)):
        for ib in range(ia + 1, len(boxes)):
            max_overlap = max(
                max_overlap,
                bbox_overlap_ratio(boxes[ia], boxes[ib]),
            )
    return float(max_overlap)


def is_complete_face_source(source: str) -> bool:
    return "strict-" in str(source)


def crop_trihedral_face_regions(
    gray: np.ndarray,
    seed_faces: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Run edge-layout recovery on a tight cube crop and map regions back."""
    if len(seed_faces) < 1:
        return [], {"status": "not_enough_seed_faces"}
    try:
        pts = np.vstack([
            np.asarray(face["poly"], dtype=np.float32).reshape(-1, 2)
            for face in seed_faces
            if "poly" in face
        ])
    except Exception as exc:
        return [], {"status": "bad_seed_polys", "error": str(exc)}
    if pts.size == 0:
        return [], {"status": "empty_seed_polys"}
    h, w = gray.shape[:2]
    span = max(float(np.ptp(pts[:, 0])), float(np.ptp(pts[:, 1])), 1.0)
    pad_factors = (0.55,) if len(seed_faces) >= 3 else (0.80, 1.20, 1.80, 2.50)
    attempts = []
    for pad_factor in pad_factors:
        pad = max(60, int(round(float(pad_factor) * span)))
        x1 = max(0, int(math.floor(float(np.min(pts[:, 0])) - pad)))
        y1 = max(0, int(math.floor(float(np.min(pts[:, 1])) - pad)))
        x2 = min(w, int(math.ceil(float(np.max(pts[:, 0])) + pad)))
        y2 = min(h, int(math.ceil(float(np.max(pts[:, 1])) + pad)))
        if x2 <= x1 + 40 or y2 <= y1 + 40:
            attempts.append({
                "pad_factor": pad_factor,
                "status": "crop_too_small",
                "crop": (x1, y1, x2, y2),
            })
            continue

        crop = gray[y1:y2, x1:x2]
        for scale in (1.0, 1.5, 2.0, 3.0):
            if scale > 1.01:
                work = cv2.resize(
                    crop,
                    (
                        int(round(crop.shape[1] * scale)),
                        int(round(crop.shape[0] * scale)),
                    ),
                    interpolation=cv2.INTER_CUBIC,
                )
            else:
                work = crop
            layout = _find_trihedral_edge_layout(work, verbose=False)
            if layout is None:
                attempts.append({
                    "pad_factor": pad_factor,
                    "scale": scale,
                    "crop": (x1, y1, x2, y2),
                    "status": "no_layout",
                })
                continue
            regions = _trihedral_face_regions(work, layout)
            attempts.append({
                "pad_factor": pad_factor,
                "scale": scale,
                "crop": (x1, y1, x2, y2),
                "status": "layout",
                "regions": len(regions),
                "score": float(layout.get("score", 0.0)),
                "counts": layout.get("counts"),
            })
            if len(regions) < 3:
                continue
            mapped: list[dict[str, Any]] = []
            for region in regions[:3]:
                poly = np.asarray(region["poly"], dtype=np.float32).reshape(-1, 2)
                poly = poly / float(scale) + np.array([x1, y1], dtype=np.float32)
                center = np.asarray(region["center"], dtype=np.float32) / float(scale)
                center = center + np.array([x1, y1], dtype=np.float32)
                mapped_region = dict(region)
                mapped_region["poly"] = poly
                mapped_region["center"] = center
                mapped_region["source"] = "crop-trihedral"
                mapped.append(mapped_region)
            return mapped, {
                "status": "ok",
                "crop": (x1, y1, x2, y2),
                "scale": scale,
                "pad_factor": pad_factor,
                "attempts": attempts,
            }
    return [], {
        "status": "no_valid_layout",
        "attempts": attempts,
    }


def component_mask_face_regions(gray: np.ndarray) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Recover face quadrilaterals from a cube-local component mask."""
    try:
        from component_face_quad_probe import (
            _expand_quad,
            _quad_from_mask,
            build_component_target_mask,
            split_mask_by_face_seeds,
            split_mask_by_trihedral_sectors,
        )
    except Exception as exc:
        return [], {"status": "import_failed", "error": str(exc)}
    try:
        target_mask, mask_trace = build_component_target_mask(gray)
        split_mode = os.environ.get(
            "GRID_PROBE_COMPONENT_SPLIT_MODE", "seed"
        ).strip().lower()
        if split_mode == "trihedral":
            face_masks, split_trace = split_mask_by_trihedral_sectors(
                gray, target_mask)
            if not face_masks:
                face_masks, fallback_trace = split_mask_by_face_seeds(
                    gray, target_mask)
                split_trace = {
                    "status": "trihedral_failed_seed_fallback",
                    "trihedral": split_trace,
                    "fallback": fallback_trace,
                }
        else:
            face_masks, split_trace = split_mask_by_face_seeds(
                gray, target_mask)
            split_mode = "seed"
    except Exception as exc:
        return [], {"status": "component_mask_failed", "error": str(exc)}
    if not face_masks:
        return [], {
            "status": "no_face_masks",
            "mask_trace": mask_trace,
            "split_trace": split_trace,
        }
    regions: list[dict[str, Any]] = []
    quad_traces: dict[str, Any] = {}
    for label in ("XY", "XZ", "YZ"):
        mask = face_masks.get(label)
        if mask is None:
            continue
        quad, qtrace = _quad_from_mask(mask)
        quad_traces[label] = qtrace
        if quad is None:
            continue
        quad = _expand_quad(quad, 1.08, gray.shape)
        regions.append({
            "label": label,
            "poly": quad.astype(np.float32),
            "center": quad.reshape(-1, 2).mean(axis=0).astype(np.float32),
            "source": "component-mask",
            "quad_trace": qtrace,
        })
    return regions, {
        "status": "ok" if len(regions) >= 3 else "partial",
        "regions": len(regions),
        "split_mode": split_mode,
        "mask_trace": mask_trace,
        "split_trace": split_trace,
        "quad_traces": quad_traces,
    }


def region_seed_faces(
    gray: np.ndarray,
    raw: list[tuple[np.ndarray, tuple[int, int], str]],
    *,
    enable_phase_grid: bool = False,
    enable_dark_square_grid: bool = False,
    enable_component_face_quads: bool | None = None,
    seed_geometry_refine: bool = False,
    enable_crop_trihedral: bool = False,
    focal_px: float | None = None,
    enable_component_label_permutations: bool | None = None,
    strict_rectified_scales: tuple[float, ...] | None = None,
    seed_geometry_refine_top: int | None = None,
) -> tuple[
    list[tuple[np.ndarray, tuple[int, int], str]],
    list[dict[str, Any]],
    dict[str, list[tuple[np.ndarray, tuple[int, int], str]]],
]:
    """Prefer one candidate per physical face polygon before extrapolation."""
    trace: list[dict[str, Any]] = []
    try:
        clusters = _cluster_dark_components(gray, n_faces=3, verbose=False)
        labeled = _label_cube_clusters(clusters)
    except Exception as exc:
        return raw, [{"status": "region_failed", "error": str(exc)}], {}

    crop_faces: list[dict[str, Any]] = []
    if enable_crop_trihedral:
        crop_faces, crop_trace = crop_trihedral_face_regions(gray, labeled)
        trace.append({
            "status": "crop_trihedral",
            **crop_trace,
        })
    component_faces: list[dict[str, Any]] = []
    enable_component_mask = (
        os.environ.get("GRID_PROBE_ENABLE_COMPONENT_FACE_QUADS", "0")
        .strip()
        .lower()
        in {"1", "true", "yes", "on"}
        if enable_component_face_quads is None
        else bool(enable_component_face_quads)
    )
    if enable_component_mask:
        component_faces, component_trace = component_mask_face_regions(gray)
        trace.append({
            "status": "component_mask_quads",
            **component_trace,
        })

    raw_by_label: dict[str, list[tuple[np.ndarray, tuple[int, int], str]]] = {}
    for item in raw:
        raw_by_label.setdefault(item[2], []).append(item)

    crop_by_label: dict[str, list[dict[str, Any]]] = {}
    for face in crop_faces:
        label = face.get("label")
        if label in {"XY", "XZ", "YZ"}:
            crop_by_label.setdefault(str(label), []).append(face)
    labeled_by_label: dict[str, list[dict[str, Any]]] = {}
    for face in labeled:
        label = face.get("label")
        if label in {"XY", "XZ", "YZ"}:
            labeled_by_label.setdefault(str(label), []).append(face)
    component_by_label: dict[str, list[dict[str, Any]]] = {}
    for face in component_faces:
        label = face.get("label")
        if label in {"XY", "XZ", "YZ"}:
            component_by_label.setdefault(str(label), []).append(face)

    face_records: list[dict[str, Any]] = []
    use_crop_as_base = len(crop_faces) >= 3
    use_component_as_base = len(component_faces) >= 3
    component_label_permutations = (
        use_component_as_base
        and (
            component_face_label_permutations_enabled()
            if enable_component_label_permutations is None
            else bool(enable_component_label_permutations)
        )
    )
    if component_label_permutations:
        base_faces = []
        labels = ("XY", "XZ", "YZ")
        for idx, label in enumerate(labels):
            base = (
                component_by_label.get(label, [])[:1]
                or component_faces[idx:idx + 1]
            )
            if not base:
                continue
            face = dict(base[0])
            face["label"] = label
            face["source"] = "component-mask-label-permutation-base"
            base_faces.append(face)
        trace.append({
            "status": "component_label_permutations",
            "enabled": True,
            "component_faces": len(component_faces),
            "base_faces": len(base_faces),
        })
    else:
        base_faces = (
            component_faces if use_component_as_base
            else crop_faces if use_crop_as_base
            else labeled
        )
    for face in base_faces:
        label = face.get("label")
        if label not in {"XY", "XZ", "YZ"}:
            continue
        strict_candidates = []
        if component_label_permutations:
            poly_variants = [
                (
                    f"component-mask-perm:{component_face.get('label', '?')}->{label}",
                    component_face["poly"],
                )
                for component_face in component_faces
                if component_face.get("poly") is not None
            ]
        else:
            poly_variants = [("cluster", face["poly"])]
        enable_cluster_support = os.environ.get(
            "GRID_PROBE_ENABLE_CLUSTER_SUPPORT_POLY", "0"
        ).strip().lower() in {"1", "true", "yes", "on"}
        if component_label_permutations:
            pass
        elif use_crop_as_base and enable_cluster_support:
            poly_variants.extend(
                ("cluster-support", item["poly"])
                for item in labeled_by_label.get(str(label), [])[:1]
            )
        else:
            poly_variants.extend(
                ("crop-trihedral", item["poly"])
                for item in crop_by_label.get(str(label), [])[:1]
            )
        if not use_component_as_base:
            poly_variants.extend(
                ("component-mask", item["poly"])
                for item in component_by_label.get(str(label), [])[:1]
            )
        for poly_source, poly in poly_variants:
            for score, corners, pat, lab, src, inside in strict_rectified_face_candidates(
                gray,
                poly,
                label,
                min_inside=0.72,
                max_candidates=REGION_SEED_FACE_CANDIDATES,
                enable_phase_grid=enable_phase_grid,
                enable_dark_square_grid=enable_dark_square_grid,
                strict_rectified_scales=strict_rectified_scales,
            ):
                tagged = src if poly_source == "cluster" else f"{poly_source}:{src}"
                strict_candidates.append((score, corners, pat, lab, tagged, inside))
        region_candidates: list[tuple[float, np.ndarray, tuple[int, int], str, str, float]] = []
        face_poly = np.asarray(face["poly"], dtype=np.float32).reshape(-1, 2)
        region_poly_variants = (
            poly_variants if component_label_permutations
            else [("cluster", face_poly)]
        )
        for region_poly_source, region_poly in region_poly_variants:
            region_poly_arr = np.asarray(region_poly, dtype=np.float32).reshape(-1, 2)
            for item in _detect_pattern_candidates_in_face(
                gray, region_poly_arr, label, max_candidates=8
            ):
                _score, corners, pat, lab, src = item
                inside = corners_inside_poly_ratio(corners, region_poly_arr)
                if inside >= 0.72:
                    tagged = (
                        src
                        if region_poly_source == "cluster"
                        else f"{region_poly_source}:{src}"
                    )
                    region_candidates.append((
                        _score, corners, pat, lab, tagged, inside))
        candidates = list(strict_candidates) + list(region_candidates)
        fallback_items = raw_by_label.get(label, [])
        center = face_poly.mean(axis=0)
        for corners, pat, lab in sorted(
            fallback_items,
            key=lambda item: float(np.linalg.norm(
                item[0].reshape(-1, 2).mean(axis=0) - center)),
        )[:3]:
            inside = corners_inside_poly_ratio(corners, face_poly)
            if inside < 0.35:
                continue
            score = float(len(corners)) + 15.0 * inside + 10.0
            candidates.append((score, corners, pat, lab, "direct-fallback", inside))
        normalized = []
        for score, corners, pat, lab, src, inside in candidates:
            source_score = float(score)
            src_text = str(src)
            if "strict-phase-grid" in src_text:
                source_score *= 0.38
            elif "strict-dark-grid" in src_text:
                source_score *= 0.40
            elif "strict-lattice" in src_text:
                # Lattice points are inferred from image texture, not directly
                # detected corners.  Use them as missing-face support.
                source_score *= 0.32
            elif not src_text.startswith("direct-fallback"):
                source_score += 25.0
            normalized.append((source_score, corners, pat, lab, src, inside))
        candidates = dedupe_ranked_candidates(normalized)
        if not candidates:
            trace.append({
                "label": label,
                "status": "missing",
                "strict_candidates": len(strict_candidates),
                "region_candidates": len(region_candidates),
                "component_label_permutation": bool(component_label_permutations),
            })
            continue
        face_records.append({
            "label": label,
            "candidates": candidates[:REGION_SEED_FACE_CANDIDATES],
            "strict_candidates": len(strict_candidates),
            "region_candidates": len(region_candidates),
            "component_label_permutation": bool(component_label_permutations),
        })

    if len(face_records) < 3:
        return raw, trace, {}

    canonical_signature = CANONICAL_PATTERN_SIGNATURE

    def pat_sig(pat: tuple[int, int]) -> tuple[int, int]:
        return (max(int(pat[0]), int(pat[1])), min(int(pat[0]), int(pat[1])))

    best_combo = None
    best_nonoverlap_combo = None
    combo_records = []
    for combo in itertools.product(*[rec["candidates"] for rec in face_records]):
        patterns = [pat for _score, _corners, pat, _lab, _src, _inside in combo]
        signature = sorted(pat_sig(pat) for pat in patterns)
        is_canonical = signature == canonical_signature
        local_score = sum(float(item[0]) for item in combo)
        local_score += 20.0 if is_canonical else -5.0
        max_overlap = max_corner_bbox_overlap([item[1] for item in combo])
        local_score -= 180.0 * max(0.0, max_overlap - 0.25)
        score = local_score
        seed_geom = None
        record = (score, combo, is_canonical, max_overlap, seed_geom, local_score)
        combo_records.append(record)
        if best_combo is None or score > best_combo[0]:
            best_combo = record
        if (
            max_overlap <= MAX_JOINT_FACE_OVERLAP_RATIO
            and (
                best_nonoverlap_combo is None
                or score > best_nonoverlap_combo[0]
            )
        ):
            best_nonoverlap_combo = record

    if best_combo is None:
        return raw, trace, {}

    if seed_geometry_refine:
        refine_top = (
            max(1, int(seed_geometry_refine_top))
            if seed_geometry_refine_top is not None
            else SEED_GEOMETRY_REFINE_TOP
        )
        refine_pool = []
        for record in combo_records:
            _score, combo, _is_canonical, max_overlap, _seed_geom, _local_score = record
            if max_overlap > MAX_JOINT_FACE_OVERLAP_RATIO:
                continue
            all_complete_sources = all(
                is_complete_face_source(str(item[4])) for item in combo)
            if not all_complete_sources and not _is_canonical:
                continue
            refine_pool.append(record)
        refined_records = []
        ranked_refine_pool = sorted(
            refine_pool,
            key=lambda item: item[5],
            reverse=True,
        )
        shortlist = list(ranked_refine_pool[:refine_top])

        def add_shortlist(predicate, limit: int) -> None:
            seen = {tuple(id(item[1]) for item in record[1]) for record in shortlist}
            added = 0
            for record in ranked_refine_pool:
                key = tuple(id(item[1]) for item in record[1])
                if key in seen:
                    continue
                if not predicate(record):
                    continue
                shortlist.append(record)
                seen.add(key)
                added += 1
                if added >= limit:
                    break

        add_shortlist(
            lambda record: not any(
                "strict-dark-grid" in str(item[4]) for item in record[1]),
            max(4, refine_top // 2),
        )
        add_shortlist(
            lambda record: any(
                "strict-dark-grid" in str(item[4]) for item in record[1]),
            max(6, refine_top // 2),
        )
        add_shortlist(
            lambda record: all(
                "strict-lattice" in str(item[4]) for item in record[1]),
            max(4, refine_top // 2),
        )

        for record in shortlist:
            _score, combo, is_canonical, max_overlap, _seed_geom, local_score = record
            dets = _normalize_face_axis_order([
                (corners, pat, lab)
                for _score2, corners, pat, lab, _src, _inside in combo
            ])[:3]
            fixed_geom = fixed_focal_combo_rmse(dets, gray.shape, focal_px)
            if np.isfinite(fixed_geom):
                geom = fixed_geom
                geom_kind = "fixed_focal"
            else:
                geom = fast_combo_pnp_rmse(dets, gray.shape, focal_px=focal_px)
                geom_kind = "fast_pnp"
            if np.isfinite(geom):
                seed_geom = float(geom)
                score = -seed_geom + 0.002 * local_score
                if CANONICAL_FULL_PATTERNS_ONLY and not is_canonical:
                    score -= 100.0
            else:
                seed_geom = None
                geom_kind = "none"
                score = -1e6 + 0.002 * local_score
            refined_records.append((
                score, combo, is_canonical, max_overlap, seed_geom, local_score,
                geom_kind))
        if refined_records:
            best_nonoverlap_combo = max(refined_records, key=lambda item: item[0])

    if best_nonoverlap_combo is not None:
        best_combo = best_nonoverlap_combo

    if len(best_combo) == 7:
        combo_score, combo, is_canonical, combo_max_overlap, seed_geom, local_score, seed_geom_kind = best_combo
    else:
        combo_score, combo, is_canonical, combo_max_overlap, seed_geom, local_score = best_combo
        seed_geom_kind = None
    selected_raw: list[tuple[np.ndarray, tuple[int, int], str]] = []
    for rec, item in zip(face_records, combo):
        item_score, corners, pat, lab, src, inside = item
        selected_raw.append((corners, pat, lab))
        trace.append({
            "label": rec["label"],
            "status": "ok",
            "source": f"{src}:inside={inside:.2f}",
            "pattern": pat,
            "score": float(item_score),
            "strict_candidates": rec["strict_candidates"],
            "region_candidates": rec["region_candidates"],
            "component_label_permutation": bool(
                rec.get("component_label_permutation", False)),
            "canonical_combo": bool(is_canonical),
            "combo_max_overlap": float(combo_max_overlap),
            "combo_score": float(combo_score),
            "combo_local_score": float(local_score),
            "seed_geometry_rmse": seed_geom,
            "seed_geometry_kind": seed_geom_kind,
        })

    selected_normalized = _normalize_face_axis_order(selected_raw)[:3]
    selected = selected_normalized
    if (
        len(selected_raw) >= 3
        and focal_px is not None
        and np.isfinite(focal_px)
        and focal_px > 0
    ):
        raw_fixed_geom = fixed_focal_combo_rmse(
            selected_raw[:3],
            gray.shape,
            focal_px,
        )
        normalized_fixed_geom = fixed_focal_combo_rmse(
            selected_normalized,
            gray.shape,
            focal_px,
        )
        margin = env_float(
            "GRID_PROBE_AXIS_NORMALIZATION_FIXED_FOCAL_MARGIN_PX",
            1.0,
        )
        accept_limit = env_float(
            "GRID_PROBE_AXIS_NORMALIZATION_MAX_FIXED_FOCAL_RMSE_PX",
            16.0,
        )
        keep_raw_axis_order = (
            np.isfinite(raw_fixed_geom)
            and raw_fixed_geom <= accept_limit
            and (
                not np.isfinite(normalized_fixed_geom)
                or raw_fixed_geom + margin < normalized_fixed_geom
            )
        )
        trace.append({
            "status": "seed_axis_normalization_check",
            "raw_fixed_focal_rmse": (
                None
                if not np.isfinite(raw_fixed_geom)
                else float(raw_fixed_geom)
            ),
            "normalized_fixed_focal_rmse": (
                None
                if not np.isfinite(normalized_fixed_geom)
                else float(normalized_fixed_geom)
            ),
            "kept_raw_axis_order": bool(keep_raw_axis_order),
            "margin_px": float(margin),
            "accept_limit_px": float(accept_limit),
        })
        if keep_raw_axis_order:
            selected = selected_raw[:3]
    alternatives: dict[str, list[tuple[np.ndarray, tuple[int, int], str]]] = {}
    for face_idx, rec in enumerate(face_records):
        label = str(rec["label"])
        added = 0
        seen_boxes: list[tuple[tuple[int, int], tuple[float, float, float, float]]] = []
        for alt in rec["candidates"]:
            _score, corners, pat, lab, _src, _inside = alt
            alt_raw = list(selected_raw)
            alt_raw[face_idx] = (corners, pat, lab)
            normalized = _normalize_face_axis_order(alt_raw)[:3]
            match = next(
                ((c, p, l) for c, p, l in normalized if str(l) == label),
                None,
            )
            if match is None:
                continue
            c, p, l = match
            box = bbox_of_corners(c)
            duplicate = False
            for old_pat, old_box in seen_boxes:
                if p == old_pat and bbox_overlap_ratio(box, old_box) > 0.88:
                    duplicate = True
                    break
            if duplicate:
                continue
            seen_boxes.append((p, box))
            alternatives.setdefault(label, []).append((c, p, l))
            added += 1
            if added >= REGION_ALTERNATIVE_SEEDS:
                break

    return selected, trace, alternatives


def clean_candidate(row: dict[str, Any]) -> dict[str, Any]:
    out = {
        "label": row["label"],
        "partial_pattern": row["partial_pattern"],
        "full_pattern": row["full_pattern"],
        "offset": row["offset"],
        "score": float(row["score"]),
        "contrast": float(row["contrast"]),
        "response": float(row["response"]),
        "inside_ratio": float(row["inside_ratio"]),
    }
    if "outer_edge_support" in row:
        out["outer_edge_support"] = float(row["outer_edge_support"])
    if "outer_edge_mean_dist" in row:
        out["outer_edge_mean_dist"] = float(row["outer_edge_mean_dist"])
    return out


def clean_seed_candidate(
    det: tuple[np.ndarray, tuple[int, int], str],
) -> dict[str, Any]:
    corners, pattern, label = det
    return {
        "label": label,
        "partial_pattern": pattern,
        "full_pattern": pattern,
        "offset": (0, 0),
        "score": 0.0,
        "contrast": 0.0,
        "response": 0.0,
        "inside_ratio": 1.0,
        "bbox": bbox_of_corners(corners),
    }


def not_cube_target_reason(
    raw: list[tuple[np.ndarray, tuple[int, int], str]],
    region_trace: list[dict[str, Any]],
    *,
    expected_faces: int = 3,
) -> str | None:
    """Classify planar/non-cube inputs before cube calibration starts."""
    if len(raw) >= expected_faces:
        return None
    trihedral_ok = any(
        item.get("status") == "ok"
        and "crop" in item
        and item.get("attempts") is not None
        for item in region_trace
    )
    if trihedral_ok:
        return None
    if len(raw) == 1:
        _corners, pat, label = raw[0]
        return (
            "Only one planar checkerboard face was found "
            f"({label}:{pat[0]}x{pat[1]}), and no trihedral three-face "
            "cube/cuboid layout could be recovered. This image is outside "
            "the single-frame three-face cube calibration method."
        )
    if len(raw) == 0:
        return (
            "No usable cube-face checkerboard was found, and no trihedral "
            "three-face cube/cuboid layout could be recovered."
        )
    return (
        f"Only {len(raw)}/{expected_faces} cube faces were found, and no "
        "trihedral three-face cube/cuboid layout could be recovered."
    )


def reorder_corners_for_flip(
    corners: np.ndarray,
    pattern: tuple[int, int],
    flip_x: bool,
    flip_y: bool,
) -> np.ndarray:
    cols, rows = pattern
    arr = corners.reshape(rows, cols, 1, 2)
    if flip_y:
        arr = arr[::-1, :, :, :]
    if flip_x:
        arr = arr[:, ::-1, :, :]
    return arr.reshape(-1, 1, 2).astype(np.float32)


def reprojection_rmse(
    obj: np.ndarray,
    img: np.ndarray,
    rvec: np.ndarray,
    tvec: np.ndarray,
    K: np.ndarray,
) -> float:
    proj, _ = cv2.projectPoints(obj, rvec, tvec, K, None)
    diff = proj.reshape(-1, 2) - img.reshape(-1, 2)
    return float(np.sqrt(np.mean(np.sum(diff * diff, axis=1))))


def fast_combo_pnp_rmse(
    dets: list[tuple[np.ndarray, tuple[int, int], str]],
    image_shape: tuple[int, int],
    focal_px: float | None = None,
) -> float:
    """Fast candidate score; final acceptance still uses calibrate_best."""
    if len(dets) < 3:
        return float("inf")
    h, w = image_shape[:2]
    diag = float(np.hypot(w, h))
    patterns = [pat for _corners, pat, _label in dets[:3]]
    try:
        faces = standard_three_face_target(
            25.0, 9, 6,
            face_patterns=patterns,
            n_faces=3,
            center_patterns_on_cube=True,
        )
    except Exception:
        return float("inf")
    obj_by_face = [object_points_for_face(face).reshape(-1, 3) for face in faces]
    best = float("inf")
    flip_options = [(False, False), (True, False), (False, True), (True, True)]
    for flips in __import__("itertools").product(flip_options, repeat=3):
        obj = []
        img = []
        ok = True
        for (corners, pat, _label), face_obj, (fx_flip, fy_flip) in zip(dets[:3], obj_by_face, flips):
            pts = reorder_corners_for_flip(corners, pat, fx_flip, fy_flip).reshape(-1, 2)
            if len(pts) != len(face_obj):
                ok = False
                break
            obj.append(face_obj)
            img.append(pts)
        if not ok:
            continue
        obj_all = np.vstack(obj).astype(np.float32)
        img_all = np.vstack(img).astype(np.float32)
        if focal_px is not None and np.isfinite(focal_px) and focal_px > 0:
            focal_seeds = (float(focal_px),)
        else:
            focal_seeds = (0.55 * diag, 0.70 * diag, 0.85 * diag, 1.10 * diag)
        for focal in focal_seeds:
            K = np.array(
                [[focal, 0.0, w / 2.0], [0.0, focal, h / 2.0], [0.0, 0.0, 1.0]],
                dtype=np.float64,
            )
            try:
                ok_pnp, rvec, tvec = cv2.solvePnP(
                    obj_all, img_all, K, None, flags=cv2.SOLVEPNP_ITERATIVE)
            except cv2.error:
                continue
            if not ok_pnp:
                continue
            rmse = reprojection_rmse(obj_all, img_all, rvec, tvec, K)
            if rmse < best:
                best = rmse
    return best


def fixed_focal_combo_rmse(
    dets: list[tuple[np.ndarray, tuple[int, int], str]],
    image_shape: tuple[int, int],
    focal_px: float | None,
) -> float:
    """Final-model proxy used only to rank a small joint-candidate shortlist."""
    if (
        focal_px is None
        or not np.isfinite(focal_px)
        or focal_px <= 0
        or len(dets) < 3
    ):
        return float("inf")
    h, w = image_shape[:2]
    patterns = [pat for _corners, pat, _label in dets[:3]]
    try:
        faces = standard_three_face_target(
            25.0, 9, 6,
            face_patterns=patterns,
            n_faces=3,
            center_patterns_on_cube=True,
        )
    except Exception:
        return float("inf")
    detected = [
        DetectedFace(
            image_points=corners.reshape(-1, 1, 2).astype(np.float32),
            object_points=object_points_for_face(face),
            valid=True,
        )
        for (corners, _pat, _label), face in zip(dets[:3], faces)
    ]
    K = np.array([
        [float(focal_px), 0.0, w / 2.0],
        [0.0, float(focal_px), h / 2.0],
        [0.0, 0.0, 1.0],
    ], dtype=np.float64)
    orientations = apply_best_face_orientations(
        detected, faces, [0, 1, 2], K, None)
    if not orientations:
        return float("inf")
    obj = np.vstack([df.object_points for df in detected]).reshape(-1, 3)
    img = np.vstack([df.image_points for df in detected]).reshape(-1, 2)
    candidates = []
    for k1_prior in (None, 0.0):
        result = _fixed_focal_k1_pose_fallback(
            obj.astype(np.float32),
            img.astype(np.float32),
            (w, h),
            float(focal_px),
            k1_seed=0.0,
            k1_prior=k1_prior,
            rmse_limit=100.0,
        )
        if result is not None:
            candidates.append(float(result[4]))
    if not candidates:
        return float("inf")
    return float(min(candidates))


def shared_vp_combo_metrics(
    dets: list[tuple[np.ndarray, tuple[int, int], str]],
    image_shape: tuple[int, int],
    focal_px: float | None,
) -> dict[str, Any]:
    """Score whether adjacent faces share the same X/Y/Z vanishing axes."""
    if len(dets) < 3:
        return {"score": float("inf"), "penalty": float("inf")}
    h_img, w_img = image_shape[:2]
    diag = float(np.hypot(w_img, h_img))
    labels_by_face = get_vp_labels(3)
    vp_by_axis: dict[str, list[np.ndarray]] = {"X": [], "Y": [], "Z": []}
    try:
        ordered = _normalize_face_axis_order(dets)[:3]
        for face_idx, (corners, pattern, _label) in enumerate(ordered):
            row_lines, col_lines, _rq, _cq = lines_from_chessboard_corners(
                corners, pattern, use_ransac=True)
            if len(row_lines) < 2 or len(col_lines) < 2:
                return {"score": float("inf"), "penalty": float("inf")}
            vp_row = estimate_vanishing_point(np.asarray(row_lines))
            vp_col = estimate_vanishing_point(np.asarray(col_lines))
            axis_row, axis_col = labels_by_face[face_idx]
            vp_by_axis[axis_row].append(np.asarray(vp_row.v, dtype=np.float64))
            vp_by_axis[axis_col].append(np.asarray(vp_col.v, dtype=np.float64))
    except Exception as exc:
        return {
            "score": float("inf"),
            "penalty": float("inf"),
            "error": str(exc),
        }

    axis_dists: list[float] = []
    for axis in ("X", "Y", "Z"):
        values = vp_by_axis.get(axis, [])
        if len(values) < 2:
            return {"score": float("inf"), "penalty": float("inf")}
        for a, b in itertools.combinations(values, 2):
            if abs(float(a[2])) <= 1e-6 or abs(float(b[2])) <= 1e-6:
                axis_dists.append(3.0)
                continue
            aa = a / a[2]
            bb = b / b[2]
            dist = float(np.linalg.norm(aa[:2] - bb[:2]) / max(diag, 1.0))
            axis_dists.append(min(dist, 3.0))
    shared_score = float(np.mean(axis_dists)) if axis_dists else float("inf")

    focal_est = None
    focal_score = 0.0
    try:
        vp_avg: list[VanishingPoint] = []
        for axis in ("X", "Y", "Z"):
            values = []
            for v in vp_by_axis[axis]:
                vv = np.asarray(v, dtype=np.float64).copy()
                if abs(float(vv[2])) > 1e-6:
                    vv /= vv[2]
                values.append(vv)
            vm = np.median(np.vstack(values), axis=0)
            if abs(float(vm[2])) > 1e-6:
                vm /= vm[2]
            vp_avg.append(VanishingPoint(v=vm, direction_label=axis))
        K = calibrate_intrinsics_from_vps(
            vp_avg,
            [(0, 1), (1, 2), (2, 0)],
            assume_zero_skew=True,
            assume_square_pixels=True,
            fix_principal_point=(w_img / 2.0, h_img / 2.0),
        )
        fx = float(K[0, 0])
        fy = float(K[1, 1])
        if np.isfinite(fx) and np.isfinite(fy) and fx > 0.0 and fy > 0.0:
            focal_est = 0.5 * (fx + fy)
            if focal_px is not None and np.isfinite(focal_px) and focal_px > 0:
                focal_score = abs(math.log(max(focal_est, 1e-6) / float(focal_px)))
            else:
                lo, hi = 0.30 * diag, 2.50 * diag
                if focal_est < lo:
                    focal_score = math.log(lo / max(focal_est, 1e-6))
                elif focal_est > hi:
                    focal_score = math.log(max(focal_est, 1e-6) / hi)
    except Exception:
        focal_est = None
        focal_score = 1.0

    penalty = (
        float(SHARED_VP_SCORE_WEIGHT) * shared_score
        + float(SHARED_VP_FOCAL_WEIGHT) * focal_score
    )
    return {
        "score": shared_score,
        "focal_score": float(focal_score),
        "focal_px": focal_est,
        "axis_distances": axis_dists,
        "penalty": float(penalty),
    }


def shared_vp_combo_metrics_from_rows(
    combo: tuple[dict[str, Any], ...],
    image_shape: tuple[int, int],
    focal_px: float | None,
) -> dict[str, Any]:
    h_img, w_img = image_shape[:2]
    diag = float(np.hypot(w_img, h_img))
    axis_map = {
        "XY": ("X", "Y"),
        "XZ": ("X", "Z"),
        "YZ": ("Y", "Z"),
    }
    vp_by_axis: dict[str, list[np.ndarray]] = {"X": [], "Y": [], "Z": []}
    for item in combo:
        label = str(item.get("label"))
        if label not in axis_map:
            return {"score": float("inf"), "penalty": float("inf")}
        vp_row = item.get("_vp_row")
        vp_col = item.get("_vp_col")
        if vp_row is None or vp_col is None:
            return {"score": float("inf"), "penalty": float("inf")}
        axis_row, axis_col = axis_map[label]
        vp_by_axis[axis_row].append(np.asarray(vp_row, dtype=np.float64))
        vp_by_axis[axis_col].append(np.asarray(vp_col, dtype=np.float64))

    axis_dists: list[float] = []
    for axis in ("X", "Y", "Z"):
        values = vp_by_axis.get(axis, [])
        if len(values) < 2:
            return {"score": float("inf"), "penalty": float("inf")}
        for a, b in itertools.combinations(values, 2):
            if abs(float(a[2])) <= 1e-6 or abs(float(b[2])) <= 1e-6:
                axis_dists.append(3.0)
                continue
            aa = a / a[2]
            bb = b / b[2]
            dist = float(np.linalg.norm(aa[:2] - bb[:2]) / max(diag, 1.0))
            axis_dists.append(min(dist, 3.0))
    shared_score = float(np.mean(axis_dists)) if axis_dists else float("inf")

    focal_est = None
    focal_score = 0.0
    try:
        vp_avg: list[VanishingPoint] = []
        for axis in ("X", "Y", "Z"):
            values = []
            for v in vp_by_axis[axis]:
                vv = np.asarray(v, dtype=np.float64).copy()
                if abs(float(vv[2])) > 1e-6:
                    vv /= vv[2]
                values.append(vv)
            vm = np.median(np.vstack(values), axis=0)
            if abs(float(vm[2])) > 1e-6:
                vm /= vm[2]
            vp_avg.append(VanishingPoint(v=vm, direction_label=axis))
        K = calibrate_intrinsics_from_vps(
            vp_avg,
            [(0, 1), (1, 2), (2, 0)],
            assume_zero_skew=True,
            assume_square_pixels=True,
            fix_principal_point=(w_img / 2.0, h_img / 2.0),
        )
        fx = float(K[0, 0])
        fy = float(K[1, 1])
        if np.isfinite(fx) and np.isfinite(fy) and fx > 0.0 and fy > 0.0:
            focal_est = 0.5 * (fx + fy)
            if focal_px is not None and np.isfinite(focal_px) and focal_px > 0:
                focal_score = abs(math.log(max(focal_est, 1e-6) / float(focal_px)))
            else:
                lo, hi = 0.30 * diag, 2.50 * diag
                if focal_est < lo:
                    focal_score = math.log(lo / max(focal_est, 1e-6))
                elif focal_est > hi:
                    focal_score = math.log(max(focal_est, 1e-6) / hi)
    except Exception:
        focal_est = None
        focal_score = 1.0

    penalty = (
        float(SHARED_VP_SCORE_WEIGHT) * shared_score
        + float(SHARED_VP_FOCAL_WEIGHT) * focal_score
    )
    return {
        "score": shared_score,
        "focal_score": float(focal_score),
        "focal_px": focal_est,
        "axis_distances": axis_dists,
        "penalty": float(penalty),
    }


def choose_joint_combo(
    recovered_by_face: list[list[dict[str, Any]]],
    image_shape: tuple[int, int],
    *,
    top_per_face: int,
    max_combos: int,
    fast_geometry: bool,
    focal_px: float | None = None,
    fixed_focal_joint_refine: bool = False,
    enable_shared_vp_score: bool = ENABLE_SHARED_VP_SCORE,
    require_canonical_patterns: bool = False,
) -> dict[str, Any]:
    """Select a three-face extrapolation using whole-cube geometry."""
    import itertools

    pool_width = max(top_per_face, JOINT_OVERLAP_RECOVERY_POOL)
    pools = [items[:pool_width] for items in recovered_by_face]
    best: dict[str, Any] | None = None
    best_canonical: dict[str, Any] | None = None
    best_overlapping: dict[str, Any] | None = None
    nonoverlap_records: list[dict[str, Any]] = []
    checked = 0
    skipped_overlap = 0
    for combo in itertools.product(*pools):
        if checked >= max_combos:
            break
        checked += 1
        dets = [
            (item["full_corners"], item["full_pattern"], item["label"])
            for item in combo
        ]
        max_overlap = max_corner_bbox_overlap([item["full_corners"] for item in combo])
        photo = float(np.mean([item["score"] for item in combo]))
        signature = sorted(
            (max(int(item["full_pattern"][0]), int(item["full_pattern"][1])),
             min(int(item["full_pattern"][0]), int(item["full_pattern"][1])))
            for item in combo
        )
        is_canonical = signature == CANONICAL_PATTERN_SIGNATURE
        if max_overlap > MAX_JOINT_FACE_OVERLAP_RATIO:
            skipped_overlap += 1
            blocked_record = {
                "combo": combo,
                "rank": float(max_overlap - 0.01 * photo),
                "geom": float("inf"),
                "max_overlap": float(max_overlap),
                "centered_pnp": None,
                "offset_pnp": None,
                "offset": None,
                "offset_dist": None,
                "photometric": photo,
            }
            if (
                best_overlapping is None
                or blocked_record["rank"] < best_overlapping["rank"]
            ):
                best_overlapping = blocked_record
            continue
        if fast_geometry:
            centered = fast_combo_pnp_rmse(dets, image_shape, focal_px=focal_px)
            offset_pnp, offset, offset_dist = None, None, None
            geom = float(centered) if np.isfinite(centered) else float("inf")
        else:
            centered = _cube_detection_geometry_rmse(
                dets, image_shape, n_faces=3,
                allow_sparse=False, assume_normalized=True,
            )
            offset_pnp, offset, offset_dist = _cube_detection_best_offset_pnp_rmse(
                dets, image_shape, n_faces=3, assume_normalized=True,
            )
            geom = min(
                float(centered) if np.isfinite(centered) else float("inf"),
                float(offset_pnp) if np.isfinite(offset_pnp) else float("inf"),
            )
        # Geometry is the hard constraint; photometric score only breaks
        # near-ties so a shiny but physically inconsistent face cannot win.
        shared_vp = (
            shared_vp_combo_metrics_from_rows(combo, image_shape, focal_px)
            if enable_shared_vp_score
            else None
        )
        shared_vp_penalty = (
            float(shared_vp.get("penalty", float("inf")))
            if shared_vp is not None
            else 0.0
        )
        if not np.isfinite(shared_vp_penalty):
            shared_vp_penalty = 50.0
        rank = geom - 0.20 * photo + shared_vp_penalty
        if CANONICAL_FULL_PATTERNS_ONLY and not is_canonical:
            rank += 100.0
        record = {
            "combo": combo,
            "rank": rank,
            "geom": geom,
            "max_overlap": float(max_overlap),
            "centered_pnp": float(centered) if np.isfinite(centered) else None,
            "offset_pnp": (
                float(offset_pnp)
                if offset_pnp is not None and np.isfinite(offset_pnp)
                else None
            ),
            "offset": offset,
            "offset_dist": (
                float(offset_dist)
                if offset_dist is not None and np.isfinite(offset_dist)
                else None
            ),
            "photometric": photo,
            "canonical_patterns": bool(is_canonical),
            "shared_vp_score": (
                None if shared_vp is None else shared_vp.get("score")
            ),
            "shared_vp_focal_score": (
                None if shared_vp is None else shared_vp.get("focal_score")
            ),
            "shared_vp_focal_px": (
                None if shared_vp is None else shared_vp.get("focal_px")
            ),
            "shared_vp_penalty": (
                None if shared_vp is None else shared_vp.get("penalty")
            ),
        }
        if (
            best_overlapping is None
            or record["rank"] < best_overlapping["rank"]
        ):
            best_overlapping = record
        nonoverlap_records.append(record)
        if is_canonical and (
            best_canonical is None or record["rank"] < best_canonical["rank"]
        ):
            best_canonical = record
        if best is None or record["rank"] < best["rank"]:
            best = record
    if (
        fast_geometry
        and fixed_focal_joint_refine
        and focal_px is not None
        and np.isfinite(focal_px)
        and focal_px > 0
        and nonoverlap_records
    ):
        shortlist = sorted(
            nonoverlap_records,
            key=lambda item: item["rank"],
        )[:FIXED_FOCAL_JOINT_REFINE_TOP]
        refined = []
        for record in shortlist:
            dets = [
                (item["full_corners"], item["full_pattern"], item["label"])
                for item in record["combo"]
            ]
            fixed_rmse = fixed_focal_combo_rmse(
                dets, image_shape, focal_px)
            if np.isfinite(fixed_rmse):
                record["fixed_focal_rmse"] = float(fixed_rmse)
                shared_vp_penalty = 0.0
                if record.get("shared_vp_penalty") is not None:
                    try:
                        shared_vp_penalty = float(record["shared_vp_penalty"])
                    except (TypeError, ValueError):
                        shared_vp_penalty = 50.0
                    if not np.isfinite(shared_vp_penalty):
                        shared_vp_penalty = 50.0
                record["rank"] = float(
                    fixed_rmse
                    - 0.20 * record["photometric"]
                    + shared_vp_penalty
                )
                refined.append(record)
        if refined:
            best = min(refined, key=lambda item: item["rank"])
            canonical_refined = [
                item for item in refined if item.get("canonical_patterns")
            ]
            if canonical_refined:
                best_canonical = min(
                    canonical_refined,
                    key=lambda item: item["rank"],
                )
    if require_canonical_patterns:
        best = best_canonical
    if best is None:
        out = {
            "status": (
                "no_canonical_joint_combo"
                if require_canonical_patterns
                else "no_nonoverlap_joint_combo"
            ),
            "checked": checked,
            "skipped_overlap": skipped_overlap,
        }
        if best_overlapping is not None:
            out.update({
                "best_blocked_overlap": best_overlapping.get("max_overlap"),
                "best_blocked_centered_pnp": best_overlapping.get("centered_pnp"),
                "best_blocked_offset_pnp": best_overlapping.get("offset_pnp"),
                "best_blocked_trace": [
                    clean_candidate(item) for item in best_overlapping["combo"]
                ],
            })
        return out
    best["candidate_records"] = sorted(
        nonoverlap_records,
        key=lambda item: item["rank"],
    )[:max(1, NO_FOCAL_FINAL_REFINE_TOP)]
    best["status"] = "ok"
    best["checked"] = checked
    best["skipped_overlap"] = skipped_overlap
    best["dets"] = [
        (item["full_corners"], item["full_pattern"], item["label"])
        for item in best["combo"]
    ]
    best["combo_trace"] = [clean_candidate(item) for item in best["combo"]]
    return best


def save_overlay(
    gray: np.ndarray,
    rel: str,
    dets: list[tuple[np.ndarray, tuple[int, int], str]],
    out_dir: Path,
) -> Path:
    colors = {"XY": (0, 220, 255), "XZ": (0, 180, 0), "YZ": (255, 80, 0)}
    vis = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    for corners, pattern, label in dets:
        color = colors.get(label, (255, 255, 255))
        pts = corners.reshape(-1, 2)
        for x, y in pts:
            cv2.circle(vis, (int(round(x)), int(round(y))), 2, color, -1)
        x1, y1 = np.floor(pts.min(axis=0)).astype(int)
        x2, y2 = np.ceil(pts.max(axis=0)).astype(int)
        cv2.rectangle(vis, (x1, y1), (x2, y2), color, 2)
        cv2.putText(
            vis,
            f"{label} {pattern[0]}x{pattern[1]}",
            (x1, max(20, y1 - 6)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            color,
            2,
            cv2.LINE_AA,
        )
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{rel.replace('/', '__').replace(chr(92), '__')}_grid_extrapolated.jpg"
    cv2.imwrite(str(path), vis)
    return path


def probe_one(
    rel: str,
    image_root: Path,
    out_dir: Path,
    *,
    top_per_face: int,
    max_combos: int,
    run_calibration: bool,
    fast_geometry: bool,
    focal_px: float | None,
    enable_phase_grid: bool,
    enable_dark_square_grid: bool,
    enable_component_face_quads: bool,
    seed_geometry_refine: bool,
    enable_crop_trihedral: bool,
    augment_seed_alternatives: bool,
    allow_seed_only_fallback: bool,
    fixed_focal_joint_refine: bool,
    enable_component_label_permutations: bool,
    detect_cache_dir: Path | None,
    enable_shared_vp_score: bool = ENABLE_SHARED_VP_SCORE,
    preserve_direct_complete_faces: bool = False,
    expand_direct_square_faces: bool = False,
    require_canonical_patterns: bool = False,
    nofocal_final_refine_top: int | None = None,
    nofocal_unobservable_refine_top: int | None = None,
    fixed_focal_final_refine_top: int | None = None,
    strict_rectified_scales: tuple[float, ...] | None = None,
    seed_geometry_refine_top: int | None = None,
) -> dict[str, Any]:
    image_path = image_root / rel
    row: dict[str, Any] = {"rel_path": rel, "image_path": str(image_path)}
    if not image_path.exists():
        row["status"] = "missing_image"
        return row
    gray = _load_gray(image_path)
    enhanced = preprocess_image(gray)
    response = cv2.cornerMinEigenVal(enhanced, blockSize=5, ksize=3)
    response = response / max(float(np.nanmax(response)), 1e-6)
    raw = load_raw_detection_cache(detect_cache_dir, rel)
    row["raw_detection_cache"] = "hit" if raw is not None else "miss"
    if raw is None:
        raw = _normalize_face_axis_order(
            detect_corner_cube_faces(gray, n_faces=3, verbose=False)
        )[:3]
        save_raw_detection_cache(detect_cache_dir, rel, raw)
    row.update({
        "cube_area_pct": float(estimate_cube_area_pct(gray, n_faces=3)),
        "direct_faces": len(raw),
        "direct_patterns": ";".join(f"{label}:{pat[0]}x{pat[1]}" for _c, pat, label in raw),
    })
    if len(raw) != 3 and not enable_crop_trihedral:
        row.update({"status": "not_three_faces"})
        return row

    if preserve_direct_complete_faces:
        seeded = list(raw)
        region_trace = [{
            "status": "direct_partial_preserve",
            "patterns": ";".join(
                f"{label}:{pat[0]}x{pat[1]}"
                for _corners, pat, label in seeded
            ),
        }]
        seed_alternatives = {}
    else:
        seeded, region_trace, seed_alternatives = region_seed_faces(
            gray,
            raw,
            enable_phase_grid=enable_phase_grid,
            enable_dark_square_grid=enable_dark_square_grid,
            enable_component_face_quads=enable_component_face_quads,
            seed_geometry_refine=seed_geometry_refine,
            enable_crop_trihedral=enable_crop_trihedral,
            focal_px=focal_px,
            enable_component_label_permutations=enable_component_label_permutations,
            strict_rectified_scales=strict_rectified_scales,
            seed_geometry_refine_top=seed_geometry_refine_top,
        )
    row.update({
        "seeded_patterns": ";".join(
            f"{label}:{pat[0]}x{pat[1]}" for _c, pat, label in seeded),
        "seed_centered_pnp": fast_combo_pnp_rmse(
            seeded, gray.shape, focal_px=focal_px),
        "seed_fixed_focal_rmse": fixed_focal_combo_rmse(
            seeded, gray.shape, focal_px),
        "seed_max_overlap": max_corner_bbox_overlap(
            [corners for corners, _pat, _label in seeded]),
        "seed_alternative_counts": json.dumps(
            {k: len(v) for k, v in seed_alternatives.items()},
            ensure_ascii=False,
            default=jsonable,
        ),
        "region_trace": json.dumps(region_trace, ensure_ascii=False, default=jsonable),
    })
    if len(seeded) != 3:
        reason = not_cube_target_reason(raw, region_trace)
        if reason is None:
            row.update({"status": "not_three_faces"})
        else:
            row.update({
                "status": "not_cube_target",
                "not_cube_reason": reason,
            })
        return row

    corners_dir = out_dir / "corners"
    corners_dir.mkdir(parents=True, exist_ok=True)
    stem = rel.replace("/", "__").replace("\\", "__").rsplit(".", 1)[0]

    def _patterns_text(dets: list[tuple[np.ndarray, tuple[int, int], str]]) -> str:
        return ";".join(f"{label}:{pat[0]}x{pat[1]}" for _c, pat, label in dets)

    def _write_corners(
        dets: list[tuple[np.ndarray, tuple[int, int], str]],
        suffix: str,
    ) -> Path:
        path = corners_dir / f"{stem}{suffix}_grid_extrapolated.npz"
        np.savez(path, corners=object_corners_array(dets))
        return path

    def _apply_recovered_outputs(
        dets: list[tuple[np.ndarray, tuple[int, int], str]],
        corners_path_in: Path,
        *,
        joint_record: dict[str, Any] | None = None,
        overlay_suffix: str = "",
    ) -> None:
        overlay_rel = rel
        if overlay_suffix:
            root, ext = os.path.splitext(rel)
            overlay_rel = f"{root}{overlay_suffix}{ext}"
        overlay_path_in = save_overlay(
            gray, overlay_rel, dets, out_dir / "overlays")
        row["corners_path"] = str(corners_path_in)
        row["overlay_path"] = str(overlay_path_in)
        row["extrapolated_patterns"] = _patterns_text(dets)
        if joint_record is not None:
            row["extrapolated_centered_pnp"] = joint_record.get("centered_pnp")
            row["extrapolated_offset_pnp"] = joint_record.get("offset_pnp")
            row["extrapolated_offset"] = str(joint_record.get("offset"))
            row["extrapolated_offset_dist"] = joint_record.get("offset_dist")
            row["joint_max_overlap"] = joint_record.get("max_overlap")
            row["joint_photometric"] = joint_record.get("photometric")
            row["joint_fixed_focal_rmse"] = joint_record.get("fixed_focal_rmse")
            if joint_record.get("combo") is not None:
                row["joint_trace"] = json.dumps(
                    [clean_candidate(item) for item in joint_record.get("combo", [])],
                    ensure_ascii=False,
                    default=jsonable,
                )

    def _apply_calibration_result(result) -> None:
        row.update({
            "status": "calibrated",
            "rmse_px": result.rmse,
            "fx_px": result.fx_px,
            "fy_px": result.fy_px,
            "fov_coverage_pct": result.fov_coverage_pct,
            "n_corners": result.n_corners,
            "corner_quality": result.corner_quality,
            "model": result.model_used,
            "warnings": " | ".join(result.warnings or []),
        })

    def _canonical_seed_patterns(
        dets: list[tuple[np.ndarray, tuple[int, int], str]],
    ) -> bool:
        signature = sorted(
            (max(int(pat[0]), int(pat[1])), min(int(pat[0]), int(pat[1])))
            for _corners, pat, _label in dets
        )
        return signature == CANONICAL_PATTERN_SIGNATURE

    seed_fixed = row.get("seed_fixed_focal_rmse")
    seed_overlap = row.get("seed_max_overlap")
    canonical_seed = _canonical_seed_patterns(seeded)
    seed_rmse_limit = (
        COMPONENT_SEED_ONLY_EARLY_RMSE_LIMIT
        if enable_component_label_permutations
        else SEED_ONLY_PRESERVE_RMSE_LIMIT
    )
    early_seed_only_preserve = (
        allow_seed_only_fallback
        and focal_px is not None
        and np.isfinite(float(focal_px))
        and seed_fixed is not None
        and np.isfinite(float(seed_fixed))
        and float(seed_fixed) <= seed_rmse_limit
        and seed_overlap is not None
        and np.isfinite(float(seed_overlap))
        and float(seed_overlap) <= MAX_JOINT_FACE_OVERLAP_RATIO
        and canonical_seed
    )
    if early_seed_only_preserve:
        seed_joint = {
            "status": "ok",
            "centered_pnp": row.get("seed_centered_pnp"),
            "offset_pnp": None,
            "offset": None,
            "offset_dist": None,
            "max_overlap": row.get("seed_max_overlap"),
            "photometric": None,
            "fixed_focal_rmse": row.get("seed_fixed_focal_rmse"),
            "combo_trace": [clean_seed_candidate(det) for det in seeded],
        }
        corners_path = _write_corners(seeded, "_component_seed_only_early")
        _apply_recovered_outputs(
            seeded,
            corners_path,
            joint_record=seed_joint,
            overlay_suffix="_component_seed_only_early",
        )
        row.update({
            "used_seed_only_fallback": True,
            "seed_only_preserve_early": True,
            "component_seed_only_early": bool(enable_component_label_permutations),
            "seed_only_preserve_rmse_limit": float(seed_rmse_limit),
            "joint_checked": 0,
            "joint_skipped_overlap": 0,
            "joint_trace": json.dumps(
                seed_joint["combo_trace"],
                ensure_ascii=False,
                default=jsonable,
            ),
            "face_trace": json.dumps([], ensure_ascii=False, default=jsonable),
        })
        if not run_calibration:
            row["status"] = "geometry_recovered"
            return row
        try:
            result = calibrate_best(
                str(image_path),
                25.0,
                face_patterns=[pat for _c, pat, _label in seeded],
                corners_path=str(corners_path),
                focal_px=focal_px,
                scale_prior_candidate=True,
                verbose=False,
            )
            _apply_calibration_result(result)
            return row
        except Exception as exc:
            row["component_seed_only_early_error"] = str(exc)

    recovered_by_face = []
    face_trace = []
    for corners, partial, label in seeded:
        partial_signature = (max(int(partial[0]), int(partial[1])),
                             min(int(partial[0]), int(partial[1])))
        lock_direct_face = (
            preserve_direct_complete_faces
            and partial_signature in {(9, 6), (6, 6)}
            and not (expand_direct_square_faces and partial_signature == (6, 6))
        )
        if lock_direct_face:
            image_pts = corners.reshape(-1, 2).astype(np.float32)
            src = grid_coords(partial, (0, 0))
            h, _mask = cv2.findHomography(src, image_pts, method=0)
            if h is None or not np.all(np.isfinite(h)):
                rec = {"status": "homography_failed", "ranked": []}
            else:
                scored = score_extrapolation(
                    gray,
                    response,
                    h,
                    partial,
                    partial,
                    (0, 0),
                    edge_distance=(
                        board_edge_distance_map(gray)
                        if ENABLE_OUTER_EDGE_SCORE
                        else None
                    ),
                )
                vp_row, vp_col = (
                    face_candidate_vps(corners, partial)
                    if enable_shared_vp_score
                    else (None, None)
                )
                locked_row = {
                    "label": label,
                    "partial_pattern": partial,
                    "full_pattern": partial,
                    "offset": (0, 0),
                    "score": scored["score"],
                    "contrast": scored["contrast"],
                    "response": scored["response"],
                    "inside_ratio": scored["inside_ratio"],
                    "outer_edge_support": scored["outer_edge_support"],
                    "outer_edge_mean_dist": scored["outer_edge_mean_dist"],
                    "h": h,
                    "full_corners": corners.reshape(-1, 1, 2).astype(np.float32),
                    "partial_reproj": corners.reshape(-1, 1, 2).astype(np.float32),
                    "vp_row": vp_row,
                    "vp_col": vp_col,
                }
                rec = {
                    "status": "ok",
                    "candidates": 1,
                    "score_gap": None,
                    "ranked": [locked_row],
                }
        else:
            rec = recover_face(
                gray,
                response,
                corners,
                partial,
                label,
                enable_shared_vp_score=enable_shared_vp_score,
            )
        ranked_rows = list(rec.get("ranked", []))
        alternative_recoveries = 0
        if augment_seed_alternatives:
            for alt_corners, alt_partial, alt_label in seed_alternatives.get(label, []):
                alt_rec = recover_face(
                    gray,
                    response,
                    alt_corners,
                    alt_partial,
                    alt_label,
                    enable_shared_vp_score=enable_shared_vp_score,
                )
                if alt_rec.get("status") != "ok":
                    continue
                ranked_rows.extend(alt_rec.get("ranked", []))
                alternative_recoveries += 1
            if ranked_rows:
                ranked_rows = dedupe_recovered_rows(ranked_rows)
        face_trace.append({
            "label": label,
            "partial_pattern": partial,
            "status": rec.get("status"),
            "candidates": rec.get("candidates"),
            "augmented_candidates": len(ranked_rows),
            "alternative_recoveries": alternative_recoveries,
            "score_gap": rec.get("score_gap"),
            "top": [
                {
                    "full_pattern": r["full_pattern"],
                    "offset": r["offset"],
                    "score": r["score"],
                    "contrast": r["contrast"],
                    "response": r["response"],
                    "inside_ratio": r["inside_ratio"],
                    "outer_edge_support": r.get("outer_edge_support"),
                    "outer_edge_mean_dist": r.get("outer_edge_mean_dist"),
                }
                for r in ranked_rows[:5]
            ],
        })
        if rec.get("status") != "ok":
            row.update({
                "status": "face_recovery_failed",
                "face_trace": json.dumps(face_trace, ensure_ascii=False, default=jsonable),
            })
            return row
        recovered_by_face.append(ranked_rows or rec["ranked"])

    joint = choose_joint_combo(
        recovered_by_face,
        gray.shape,
        top_per_face=top_per_face,
        max_combos=max_combos,
        fast_geometry=fast_geometry,
        focal_px=focal_px,
        fixed_focal_joint_refine=fixed_focal_joint_refine,
        enable_shared_vp_score=enable_shared_vp_score,
        require_canonical_patterns=require_canonical_patterns,
    )

    def seed_only_is_better_than(joint_record: dict[str, Any] | None) -> bool:
        if not allow_seed_only_fallback:
            return False
        seed_fixed = row.get("seed_fixed_focal_rmse")
        if seed_fixed is None or not np.isfinite(float(seed_fixed)):
            return False
        if float(seed_fixed) > SEED_ONLY_FIXED_FOCAL_RMSE_LIMIT:
            return False
        if joint_record is None or joint_record.get("status") != "ok":
            return True
        joint_fixed = joint_record.get("fixed_focal_rmse")
        joint_centered = joint_record.get("centered_pnp")
        joint_score = (
            float(joint_fixed)
            if joint_fixed is not None and np.isfinite(float(joint_fixed))
            else (
                float(joint_centered)
                if joint_centered is not None and np.isfinite(float(joint_centered))
                else float("inf")
            )
        )
        return float(seed_fixed) + 0.50 < joint_score

    use_seed_only = seed_only_is_better_than(joint)
    if joint.get("status") != "ok":
        if use_seed_only:
            recovered = seeded
            joint = {
                "status": "ok",
                "checked": joint.get("checked"),
                "skipped_overlap": joint.get("skipped_overlap"),
                "centered_pnp": row.get("seed_centered_pnp"),
                "offset_pnp": None,
                "offset": None,
                "offset_dist": None,
                "max_overlap": row.get("seed_max_overlap"),
                "photometric": None,
                "fixed_focal_rmse": row.get("seed_fixed_focal_rmse"),
                "combo_trace": [clean_seed_candidate(det) for det in seeded],
            }
        else:
            row.update({
                "status": "joint_recovery_failed",
                "face_trace": json.dumps(face_trace, ensure_ascii=False, default=jsonable),
                "joint_checked": joint.get("checked"),
                "joint_skipped_overlap": joint.get("skipped_overlap"),
                "joint_best_blocked_overlap": joint.get("best_blocked_overlap"),
                "joint_best_blocked_centered_pnp": joint.get("best_blocked_centered_pnp"),
                "joint_best_blocked_offset_pnp": joint.get("best_blocked_offset_pnp"),
                "joint_best_blocked_trace": json.dumps(
                    joint.get("best_blocked_trace"),
                    ensure_ascii=False,
                    default=jsonable,
                ),
            })
            return row
    else:
        recovered = seeded if use_seed_only else joint["dets"]
        if use_seed_only:
            joint = {
                **joint,
                "centered_pnp": row.get("seed_centered_pnp"),
                "offset_pnp": None,
                "offset": None,
                "offset_dist": None,
                "max_overlap": row.get("seed_max_overlap"),
                "photometric": None,
                "fixed_focal_rmse": row.get("seed_fixed_focal_rmse"),
                "combo_trace": [clean_seed_candidate(det) for det in seeded],
            }

    row.update({
        "used_seed_only_fallback": bool(use_seed_only),
        "extrapolated_patterns": ";".join(f"{label}:{pat[0]}x{pat[1]}" for _c, pat, label in recovered),
        "extrapolated_centered_pnp": joint.get("centered_pnp"),
        "extrapolated_offset_pnp": joint.get("offset_pnp"),
        "extrapolated_offset": str(joint.get("offset")),
        "extrapolated_offset_dist": joint.get("offset_dist"),
        "joint_checked": joint.get("checked"),
        "joint_max_overlap": joint.get("max_overlap"),
        "joint_skipped_overlap": joint.get("skipped_overlap"),
        "joint_photometric": joint.get("photometric"),
        "joint_fixed_focal_rmse": joint.get("fixed_focal_rmse"),
        "joint_shared_vp_score": joint.get("shared_vp_score"),
        "joint_shared_vp_focal_score": joint.get("shared_vp_focal_score"),
        "joint_shared_vp_focal_px": joint.get("shared_vp_focal_px"),
        "joint_shared_vp_penalty": joint.get("shared_vp_penalty"),
        "joint_trace": json.dumps(joint.get("combo_trace"), ensure_ascii=False, default=jsonable),
        "face_trace": json.dumps(face_trace, ensure_ascii=False, default=jsonable),
    })
    corners_dir = out_dir / "corners"
    corners_dir.mkdir(parents=True, exist_ok=True)
    stem = rel.replace("/", "__").replace("\\", "__").rsplit(".", 1)[0]

    def _patterns_text(dets: list[tuple[np.ndarray, tuple[int, int], str]]) -> str:
        return ";".join(f"{label}:{pat[0]}x{pat[1]}" for _c, pat, label in dets)

    def _write_corners(
        dets: list[tuple[np.ndarray, tuple[int, int], str]],
        suffix: str,
    ) -> Path:
        path = corners_dir / f"{stem}{suffix}_grid_extrapolated.npz"
        np.savez(path, corners=object_corners_array(dets))
        return path

    def _apply_recovered_outputs(
        dets: list[tuple[np.ndarray, tuple[int, int], str]],
        corners_path_in: Path,
        *,
        joint_record: dict[str, Any] | None = None,
        overlay_suffix: str = "",
    ) -> None:
        overlay_rel = rel
        if overlay_suffix:
            root, ext = os.path.splitext(rel)
            overlay_rel = f"{root}{overlay_suffix}{ext}"
        overlay_path_in = save_overlay(
            gray, overlay_rel, dets, out_dir / "overlays")
        row["corners_path"] = str(corners_path_in)
        row["overlay_path"] = str(overlay_path_in)
        row["extrapolated_patterns"] = _patterns_text(dets)
        if joint_record is not None:
            row["extrapolated_centered_pnp"] = joint_record.get("centered_pnp")
            row["extrapolated_offset_pnp"] = joint_record.get("offset_pnp")
            row["extrapolated_offset"] = str(joint_record.get("offset"))
            row["extrapolated_offset_dist"] = joint_record.get("offset_dist")
            row["joint_max_overlap"] = joint_record.get("max_overlap")
            row["joint_photometric"] = joint_record.get("photometric")
            row["joint_fixed_focal_rmse"] = joint_record.get("fixed_focal_rmse")
            if joint_record.get("combo") is not None:
                row["joint_trace"] = json.dumps(
                    [clean_candidate(item) for item in joint_record.get("combo", [])],
                    ensure_ascii=False,
                    default=jsonable,
                )

    def _apply_calibration_result(result) -> None:
        row.update({
            "status": "calibrated",
            "rmse_px": result.rmse,
            "fx_px": result.fx_px,
            "fy_px": result.fy_px,
            "fov_coverage_pct": result.fov_coverage_pct,
            "n_corners": result.n_corners,
            "corner_quality": result.corner_quality,
            "model": result.model_used,
            "warnings": " | ".join(result.warnings or []),
        })

    corners_path = _write_corners(recovered, "")
    _apply_recovered_outputs(recovered, corners_path, joint_record=joint)
    if not run_calibration:
        row["status"] = "geometry_recovered"
        return row
    try:
        result = calibrate_best(
            str(image_path),
            25.0,
            face_patterns=[pat for _c, pat, _label in recovered],
            corners_path=str(corners_path),
            focal_px=focal_px,
            scale_prior_candidate=True,
            verbose=False,
        )
        _apply_calibration_result(result)
    except Exception as exc:
        initial_error = str(exc)
        initial_focal_unobservable = (
            "focal length is not identifiable" in initial_error.lower()
        )
        refine_attempts: list[dict[str, Any]] = []
        has_fixed_focal = (
            focal_px is not None
            and np.isfinite(focal_px)
            and float(focal_px) > 0
        )
        can_final_refine = (
            joint.get("status") == "ok"
            and (
                (focal_px is None and ENABLE_NO_FOCAL_FINAL_REFINE)
                or (has_fixed_focal and ENABLE_FIXED_FOCAL_FINAL_REFINE)
            )
        )
        refine_prefix = "fixed_focal" if has_fixed_focal else "nofocal"
        if can_final_refine:
            candidate_records = list(joint.get("candidate_records") or [])
            if has_fixed_focal:
                filtered_records = []
                for record in candidate_records:
                    try:
                        proxy_rmse = float(record.get("fixed_focal_rmse"))
                    except (TypeError, ValueError):
                        continue
                    if (
                        np.isfinite(proxy_rmse)
                        and proxy_rmse <= FIXED_FOCAL_FINAL_REFINE_MAX_PROXY_RMSE
                    ):
                        filtered_records.append(record)
                candidate_records = filtered_records[
                    :max(1, int(
                        fixed_focal_final_refine_top
                        if fixed_focal_final_refine_top is not None
                        else FIXED_FOCAL_FINAL_REFINE_TOP
                    ))
                ]
            elif initial_focal_unobservable:
                candidate_records = candidate_records[
                    :max(1, int(
                        nofocal_unobservable_refine_top
                        if nofocal_unobservable_refine_top is not None
                        else NO_FOCAL_UNOBSERVABLE_REFINE_TOP
                    ))
                ]
            elif nofocal_final_refine_top is not None:
                candidate_records = candidate_records[
                    :max(1, int(nofocal_final_refine_top))
                ]
            for idx, record in enumerate(candidate_records, 1):
                if record is joint:
                    continue
                cand_dets = [
                    (item["full_corners"], item["full_pattern"], item["label"])
                    for item in record.get("combo", [])
                ]
                if len(cand_dets) != 3:
                    continue
                cand_trace = [
                    clean_candidate(item)
                    for item in record.get("combo", [])
                ]
                cand_path = _write_corners(
                    cand_dets, f"_{refine_prefix}_refine_{idx:02d}")
                attempt: dict[str, Any] = {
                    "idx": idx,
                    "patterns": _patterns_text(cand_dets),
                    "rank": record.get("rank"),
                    "centered_pnp": record.get("centered_pnp"),
                    "fixed_focal_rmse": record.get("fixed_focal_rmse"),
                    "max_overlap": record.get("max_overlap"),
                }
                try:
                    cand_result = calibrate_best(
                        str(image_path),
                        25.0,
                        face_patterns=[pat for _c, pat, _label in cand_dets],
                        corners_path=str(cand_path),
                        focal_px=focal_px,
                        scale_prior_candidate=True,
                        verbose=False,
                    )
                    _apply_recovered_outputs(
                        cand_dets,
                        cand_path,
                        joint_record=record,
                        overlay_suffix=f"_{refine_prefix}_refine_{idx:02d}",
                    )
                    _apply_calibration_result(cand_result)
                    row[f"{refine_prefix}_final_refine_status"] = "accepted"
                    row[f"{refine_prefix}_final_refine_selected_idx"] = idx
                    row[f"{refine_prefix}_final_refine_attempts"] = (
                        len(refine_attempts) + 1
                    )
                    attempt.update({
                        "status": "accepted",
                        "rmse_px": cand_result.rmse,
                        "fx_px": cand_result.fx_px,
                        "model": cand_result.model_used,
                    })
                    refine_attempts.append(attempt)
                    row[f"{refine_prefix}_final_refine_trace"] = json.dumps(
                        refine_attempts,
                        ensure_ascii=False,
                        default=jsonable,
                    )
                    row[f"{refine_prefix}_final_refine_selected_trace"] = json.dumps(
                        cand_trace,
                        ensure_ascii=False,
                        default=jsonable,
                    )
                    return row
                except Exception as cand_exc:
                    attempt.update({
                        "status": "rejected",
                        "error": str(cand_exc),
                    })
                    refine_attempts.append(attempt)
        row.update({
            "status": (
                "focal_not_identifiable"
                if initial_focal_unobservable
                else "calibration_error"
            ),
            "error": initial_error,
        })
        if refine_attempts:
            row[f"{refine_prefix}_final_refine_status"] = "rejected"
            row[f"{refine_prefix}_final_refine_attempts"] = len(refine_attempts)
            row[f"{refine_prefix}_final_refine_trace"] = json.dumps(
                refine_attempts,
                ensure_ascii=False,
                default=jsonable,
            )
    return row


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = sorted({key for row in rows for key in row.keys()})
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _clean_specs(specs: dict[str, Any] | None) -> dict[str, Any] | None:
    if specs is None:
        return None
    out: dict[str, Any] = {}
    for label, spec in specs.items():
        out[str(label)] = {
            "full_pattern": [
                int(v) for v in spec.get("full_pattern", ())
            ],
            "offset": [int(v) for v in spec.get("offset", ())],
        }
    return out


def probe_trihedral_closure_route(
    rel: str,
    image_root: Path,
    out_dir: Path,
    *,
    run_calibration: bool,
    focal_px: float | None,
    detect_cache_dir: Path | None,
) -> dict[str, Any]:
    image_path = image_root / rel
    row: dict[str, Any] = {
        "rel_path": rel,
        "image_path": str(image_path),
        "selected_route": "trihedral_closure",
    }
    if not image_path.exists():
        row["status"] = "missing_image"
        return row
    gray = _load_gray(image_path)
    h_img, w_img = gray.shape[:2]

    raw = load_raw_detection_cache(detect_cache_dir, rel)
    if raw is None:
        raw = detect_corner_cube_faces(gray, n_faces=3, verbose=False)
        raw = _normalize_face_axis_order(raw or [])[:3]
        save_raw_detection_cache(detect_cache_dir, rel, raw)
    labels = [label for _corners, _pattern, label in raw]
    row.update({
        "direct_faces": len(raw),
        "direct_patterns": ";".join(
            f"{label}:{pat[0]}x{pat[1]}" for _c, pat, label in raw
        ),
    })
    if len(raw) != 3 or set(labels) != {"XY", "XZ", "YZ"}:
        row["status"] = "trihedral_closure_invalid_face_set"
        return row

    try:
        k_seed = partial_intrinsics_from_vps(raw, (w_img, h_img))
    except Exception as exc:
        row.update({
            "status": "trihedral_closure_no_vp_intrinsics",
            "error": str(exc),
        })
        return row

    edge_dist = _edge_distance_map(gray)
    ranked: list[dict[str, Any]] = []
    for specs in partial_candidate_specs(raw):
        quads = trihedral_spec_to_quads(raw, specs)
        if quads is None:
            continue
        shared = trihedral_infer_shared_edge_indices(quads)
        tri = shared.get("__trihedral__", {})
        valid = bool(shared.get("__valid__") and tri.get("valid"))
        edge_summary = trihedral_quad_edge_support_summary(
            quads,
            edge_dist,
            gray.shape,
        )
        pnp_rmse = trihedral_best_oriented_pnp_rmse(raw, specs, k_seed)
        edge_min = edge_summary.get("edge_support_min")
        edge_mean = edge_summary.get("edge_support_mean")
        spread_norm = tri.get("vertex_spread_max_norm")
        try:
            pnp_value = float(pnp_rmse)
        except (TypeError, ValueError):
            pnp_value = float("inf")
        try:
            edge_min_value = float(edge_min)
        except (TypeError, ValueError):
            edge_min_value = float("-inf")
        try:
            edge_mean_value = float(edge_mean)
        except (TypeError, ValueError):
            edge_mean_value = float("-inf")
        try:
            spread_value = float(spread_norm)
        except (TypeError, ValueError):
            spread_value = float("inf")
        passes_gate = (
            valid
            and np.isfinite(pnp_value)
            and pnp_value <= TRIHEDRAL_CLOSURE_PNP_GATE_PX
            and np.isfinite(edge_min_value)
            and edge_min_value >= TRIHEDRAL_CLOSURE_MIN_EDGE_SUPPORT
            and np.isfinite(spread_value)
            and spread_value <= TRIHEDRAL_CLOSURE_MAX_SPREAD_NORM
        )
        ranked.append({
            "rank_key": (
                0 if passes_gate else 1,
                0 if valid else 1,
                pnp_value if np.isfinite(pnp_value) else 99.0,
                -edge_min_value if np.isfinite(edge_min_value) else 99.0,
                spread_value if np.isfinite(spread_value) else 99.0,
            ),
            "passes_gate": bool(passes_gate),
            "valid": bool(valid),
            "specs": specs,
            "pnp_rmse": None if not np.isfinite(pnp_value) else pnp_value,
            "edge_min": None if not np.isfinite(edge_min_value) else edge_min_value,
            "edge_mean": None if not np.isfinite(edge_mean_value) else edge_mean_value,
            "spread_norm": None if not np.isfinite(spread_value) else spread_value,
            "shared": shared,
        })
    ranked.sort(key=lambda item: item["rank_key"])
    gate_candidates = [item for item in ranked if item.get("passes_gate")]
    row.update({
        "trihedral_closure_specs_tested": len(ranked),
        "trihedral_closure_gate_candidates": len(gate_candidates),
    })
    if not gate_candidates:
        row["status"] = "trihedral_closure_no_candidate"
        if ranked:
            best = ranked[0]
            row.update({
                "trihedral_closure_best_valid": best.get("valid"),
                "trihedral_closure_pnp_rmse_px": best.get("pnp_rmse"),
                "trihedral_closure_edge_min": best.get("edge_min"),
                "trihedral_closure_spread_norm": best.get("spread_norm"),
                "trihedral_closure_specs": json.dumps(
                    _clean_specs(best.get("specs")),
                    ensure_ascii=False,
                    default=jsonable,
                ),
            })
        return row

    best = gate_candidates[0]
    specs = best["specs"]
    recovered: list[tuple[np.ndarray, tuple[int, int], str]] = []
    for corners, pattern, label in raw:
        spec = specs.get(label)
        if spec is None:
            row.update({
                "status": "trihedral_closure_missing_face_spec",
                "error": f"missing spec for {label}",
            })
            return row
        full_pattern = tuple(int(v) for v in spec["full_pattern"])
        offset = tuple(int(v) for v in spec["offset"])
        h, _mask = cv2.findHomography(
            grid_coords(pattern, offset),
            corners.reshape(-1, 2).astype(np.float32),
            method=0,
        )
        if h is None or not np.all(np.isfinite(h)):
            row.update({
                "status": "trihedral_closure_homography_failed",
                "error": f"homography failed for {label}",
            })
            return row
        full_corners = project_grid(h, full_pattern, (0, 0))
        recovered.append((full_corners, full_pattern, label))

    corners_dir = out_dir / "corners"
    corners_dir.mkdir(parents=True, exist_ok=True)
    stem = rel_stem(rel)
    corners_path = corners_dir / f"{stem}_trihedral_closure_grid_extrapolated.npz"
    np.savez(
        corners_path,
        corners=object_corners_array(recovered),
        patterns=np.array(
            [[int(pat[0]), int(pat[1])] for _c, pat, _l in recovered],
            dtype=np.int32,
        ),
        labels=np.array([str(label) for _c, _p, label in recovered], dtype=object),
        trihedral_closure_specs=json.dumps(
            _clean_specs(specs),
            ensure_ascii=False,
            default=jsonable,
        ),
    )
    root, ext = os.path.splitext(rel)
    overlay_path = save_overlay(
        gray,
        f"{root}_trihedral_closure{ext}",
        recovered,
        out_dir / "overlays",
    )
    row.update({
        "status": "geometry_recovered",
        "corners_path": str(corners_path),
        "overlay_path": str(overlay_path),
        "extrapolated_patterns": ";".join(
            f"{label}:{pat[0]}x{pat[1]}" for _c, pat, label in recovered
        ),
        "trihedral_closure_pnp_rmse_px": best.get("pnp_rmse"),
        "trihedral_closure_edge_min": best.get("edge_min"),
        "trihedral_closure_edge_mean": best.get("edge_mean"),
        "trihedral_closure_spread_norm": best.get("spread_norm"),
        "trihedral_closure_specs": json.dumps(
            _clean_specs(specs),
            ensure_ascii=False,
            default=jsonable,
        ),
        "joint_fixed_focal_rmse": best.get("pnp_rmse"),
        "joint_trace": json.dumps(
            {
                "source": "trihedral_closure",
                "specs": _clean_specs(specs),
                "pnp_rmse": best.get("pnp_rmse"),
                "edge_min": best.get("edge_min"),
                "spread_norm": best.get("spread_norm"),
            },
            ensure_ascii=False,
            default=jsonable,
        ),
    })
    if not run_calibration:
        return row
    try:
        result = calibrate_best(
            str(image_path),
            25.0,
            face_patterns=[pat for _c, pat, _label in recovered],
            corners_path=str(corners_path),
            focal_px=focal_px,
            scale_prior_candidate=True,
            verbose=False,
        )
        row.update({
            "status": "calibrated",
            "rmse_px": result.rmse,
            "fx_px": result.fx_px,
            "fy_px": result.fy_px,
            "fov_coverage_pct": result.fov_coverage_pct,
            "n_corners": result.n_corners,
            "corner_quality": result.corner_quality,
            "model": result.model_used,
            "warnings": " | ".join(result.warnings or []),
        })
    except Exception as exc:
        error = str(exc)
        row.update({
            "status": (
                "focal_not_identifiable"
                if "focal length is not identifiable" in error.lower()
                else "calibration_error"
            ),
            "error": error,
        })
    return row


def _route_rank(row: dict[str, Any]) -> tuple[int, float, float]:
    def finite_value(name: str, default: float = float("inf")) -> float:
        value = row.get(name)
        try:
            value_f = float(value)
        except (TypeError, ValueError):
            return default
        return value_f if np.isfinite(value_f) else default

    if row.get("status") == "calibrated":
        return (0, finite_value("rmse_px"), finite_value("joint_fixed_focal_rmse"))
    if row.get("corners_path"):
        geom = min(
            finite_value("joint_fixed_focal_rmse"),
            finite_value("extrapolated_centered_pnp"),
            finite_value("seed_fixed_focal_rmse"),
        )
        return (1, geom, finite_value("joint_photometric"))
    return (2, float("inf"), float("inf"))


def _route_summary(name: str, row: dict[str, Any]) -> dict[str, Any]:
    return {
        "route": name,
        "status": row.get("status"),
        "patterns": row.get("extrapolated_patterns"),
        "rmse_px": row.get("rmse_px"),
        "elapsed_sec": row.get("route_elapsed_sec"),
        "joint_fixed_focal_rmse": row.get("joint_fixed_focal_rmse"),
        "seed_fixed_focal_rmse": row.get("seed_fixed_focal_rmse"),
        "seeded_patterns": row.get("seeded_patterns"),
        "used_seed_only_fallback": row.get("used_seed_only_fallback"),
        "trihedral_closure_pnp_rmse_px": row.get("trihedral_closure_pnp_rmse_px"),
        "trihedral_closure_edge_min": row.get("trihedral_closure_edge_min"),
        "trihedral_closure_spread_norm": row.get("trihedral_closure_spread_norm"),
        "not_cube_reason": row.get("not_cube_reason"),
        "error": row.get("error"),
    }


def probe_auto_seed_routes(
    rel: str,
    image_root: Path,
    out_dir: Path,
    *,
    top_per_face: int,
    max_combos: int,
    run_calibration: bool,
    fast_geometry: bool,
    focal_px: float | None,
    enable_phase_grid: bool,
    enable_dark_square_grid: bool,
    enable_component_face_quads: bool | None,
    enable_crop_trihedral: bool,
    augment_seed_alternatives: bool,
    allow_seed_only_fallback: bool,
    fixed_focal_joint_refine: bool,
    enable_component_label_permutations: bool,
    detect_cache_dir: Path | None,
    route_names: set[str] | None = None,
    enable_shared_vp_score: bool | None = None,
) -> dict[str, Any]:
    base_shared_vp_score = (
        ENABLE_SHARED_VP_SCORE
        if enable_shared_vp_score is None
        else bool(enable_shared_vp_score)
    )
    component_mask_enabled = (
        os.environ.get("GRID_PROBE_ENABLE_COMPONENT_FACE_QUADS", "0")
        .strip()
        .lower()
        in {"1", "true", "yes", "on"}
        if enable_component_face_quads is None
        else bool(enable_component_face_quads)
    )
    route_defs = [
        (
            "complete_geometry",
            {
                "enable_phase_grid": enable_phase_grid,
                "enable_dark_square_grid": enable_dark_square_grid,
                "enable_component_face_quads": component_mask_enabled,
                "seed_geometry_refine": True,
                "enable_crop_trihedral": enable_crop_trihedral,
                "augment_seed_alternatives": augment_seed_alternatives,
                "allow_seed_only_fallback": allow_seed_only_fallback,
                "fixed_focal_joint_refine": fixed_focal_joint_refine,
                "enable_component_label_permutations": False,
                "enable_shared_vp_score": base_shared_vp_score,
                "seed_geometry_refine_top": COMPLETE_SEED_GEOMETRY_REFINE_TOP,
            },
        ),
        (
            "direct_partial_preserve",
            {
                "enable_phase_grid": False,
                "enable_dark_square_grid": False,
                "enable_component_face_quads": False,
                "seed_geometry_refine": False,
                "enable_crop_trihedral": False,
                "augment_seed_alternatives": False,
                "allow_seed_only_fallback": False,
                "fixed_focal_joint_refine": fixed_focal_joint_refine,
                "enable_component_label_permutations": False,
                "enable_shared_vp_score": True,
                "preserve_direct_complete_faces": True,
                "nofocal_final_refine_top": 1,
                "nofocal_unobservable_refine_top": 1,
                "fixed_focal_final_refine_top": 1,
            },
        ),
        (
            "small_target_long_face_completion",
            {
                "enable_phase_grid": False,
                "enable_dark_square_grid": False,
                "enable_component_face_quads": False,
                "seed_geometry_refine": False,
                "enable_crop_trihedral": False,
                "augment_seed_alternatives": False,
                "allow_seed_only_fallback": False,
                "fixed_focal_joint_refine": fixed_focal_joint_refine,
                "enable_component_label_permutations": False,
                "enable_shared_vp_score": True,
                "preserve_direct_complete_faces": True,
                "expand_direct_square_faces": True,
                "require_canonical_patterns": True,
                "nofocal_final_refine_top": 1,
                "nofocal_unobservable_refine_top": 1,
                "fixed_focal_final_refine_top": 1,
            },
        ),
    ]
    if component_mask_enabled and enable_component_label_permutations:
        route_defs.append((
            "component_labelperm_seed_only",
            {
                "enable_phase_grid": enable_phase_grid,
                "enable_dark_square_grid": enable_dark_square_grid,
                "enable_component_face_quads": component_mask_enabled,
                "seed_geometry_refine": True,
                "enable_crop_trihedral": enable_crop_trihedral,
                "augment_seed_alternatives": True,
                "allow_seed_only_fallback": True,
                "fixed_focal_joint_refine": fixed_focal_joint_refine,
                "enable_component_label_permutations": True,
                "enable_shared_vp_score": (
                    base_shared_vp_score or ENABLE_COMPONENT_SHARED_VP_SCORE
                ),
                "strict_rectified_scales": COMPONENT_STRICT_RECTIFIED_SCALES,
                "seed_geometry_refine_top": COMPONENT_SEED_GEOMETRY_REFINE_TOP,
            },
        ))
    route_defs.extend([
        (
            "local_rescue",
            {
                "enable_phase_grid": enable_phase_grid,
                "enable_dark_square_grid": enable_dark_square_grid,
                "enable_component_face_quads": component_mask_enabled,
                "seed_geometry_refine": False,
                "enable_crop_trihedral": enable_crop_trihedral,
                "augment_seed_alternatives": augment_seed_alternatives,
                "allow_seed_only_fallback": allow_seed_only_fallback,
                "fixed_focal_joint_refine": fixed_focal_joint_refine,
                "enable_component_label_permutations": False,
                "enable_shared_vp_score": base_shared_vp_score,
            },
        ),
        (
            "local_partial",
            {
                "enable_phase_grid": enable_phase_grid,
                "enable_dark_square_grid": False,
                "enable_component_face_quads": component_mask_enabled,
                "seed_geometry_refine": False,
                "enable_crop_trihedral": False,
                "augment_seed_alternatives": False,
                "allow_seed_only_fallback": False,
                "fixed_focal_joint_refine": fixed_focal_joint_refine,
                "enable_component_label_permutations": False,
                "enable_shared_vp_score": base_shared_vp_score,
            },
        ),
        (
            "local_partial_tight",
            {
                "enable_phase_grid": enable_phase_grid,
                "enable_dark_square_grid": False,
                "enable_component_face_quads": component_mask_enabled,
                "seed_geometry_refine": False,
                "enable_crop_trihedral": False,
                "augment_seed_alternatives": False,
                "allow_seed_only_fallback": False,
                "fixed_focal_joint_refine": fixed_focal_joint_refine,
                "enable_component_label_permutations": False,
                "enable_shared_vp_score": base_shared_vp_score,
                "strict_rectified_scales": (1.0,),
            },
        ),
        (
            "trihedral_closure",
            {
                "route_kind": "trihedral_closure",
            },
        ),
    ])
    route_filter = route_names if route_names is not None else auto_route_name_filter()
    if route_filter is not None:
        route_defs = [
            (name, config)
            for name, config in route_defs
            if name in route_filter
        ]
    if not route_defs:
        return {
            "rel_path": rel,
            "status": "grid_recovery_no_enabled_routes",
            "enabled_routes": sorted(route_filter or []),
        }

    route_rows: list[tuple[str, dict[str, Any]]] = []
    seen_configs: set[tuple[tuple[str, Any], ...]] = set()
    for name, config in route_defs:
        key = tuple(sorted(config.items()))
        if key in seen_configs:
            continue
        seen_configs.add(key)
        route_started = time.perf_counter()
        if config.get("route_kind") == "trihedral_closure":
            row = probe_trihedral_closure_route(
                rel,
                image_root,
                out_dir / "routes" / name,
                run_calibration=run_calibration,
                focal_px=focal_px,
                detect_cache_dir=detect_cache_dir,
            )
        else:
            row = probe_one(
                rel,
                image_root,
                out_dir / "routes" / name,
                top_per_face=top_per_face,
                max_combos=max_combos,
                run_calibration=run_calibration,
                fast_geometry=fast_geometry,
                focal_px=focal_px,
                detect_cache_dir=detect_cache_dir,
                **config,
            )
        row["route_elapsed_sec"] = time.perf_counter() - route_started
        route_rows.append((name, row))
        if auto_route_should_stop(row):
            break

    best_name, best_row = min(route_rows, key=lambda item: _route_rank(item[1]))
    selected = dict(best_row)
    selected["selected_route"] = best_name
    selected["selected_route_elapsed_sec"] = best_row.get("route_elapsed_sec")
    selected["elapsed_sec"] = sum(
        float(row.get("route_elapsed_sec") or 0.0)
        for _name, row in route_rows
    )
    selected["route_summaries"] = json.dumps(
        [_route_summary(name, row) for name, row in route_rows],
        ensure_ascii=False,
        default=jsonable,
    )
    selected["enabled_routes"] = ",".join(name for name, _config in route_defs)
    return selected


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--rel-list", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--rel-path", action="append", default=None)
    parser.add_argument("--top-per-face", type=int, default=6)
    parser.add_argument("--max-combos", type=int, default=800)
    parser.add_argument("--skip-calibration", action="store_true")
    parser.add_argument("--slow-geometry", action="store_true")
    parser.add_argument("--focal-px", type=float, default=None)
    parser.add_argument("--enable-phase-grid", action="store_true")
    parser.add_argument("--enable-dark-square-grid", action="store_true")
    parser.add_argument("--seed-geometry-refine", action="store_true")
    parser.add_argument("--enable-crop-trihedral", action="store_true")
    parser.add_argument("--augment-seed-alternatives", action="store_true")
    parser.add_argument("--allow-seed-only-fallback", action="store_true")
    parser.add_argument("--fixed-focal-joint-refine", action="store_true")
    parser.add_argument("--auto-seed-routes", action="store_true")
    parser.add_argument(
        "--auto-route",
        action="append",
        choices=[
            "complete_geometry",
            "component_labelperm_seed_only",
            "local_rescue",
            "local_partial",
            "local_partial_tight",
            "direct_partial_preserve",
            "trihedral_closure",
            "small_target_long_face_completion",
        ],
        default=None,
        help="Restrict --auto-seed-routes to named route(s). May be repeated.",
    )
    parser.add_argument("--enable-component-face-quads", action="store_true")
    parser.add_argument("--component-face-label-permutations", action="store_true")
    parser.add_argument("--seed-geometry-refine-top", type=int, default=None)
    parser.add_argument(
        "--detect-cache-dir",
        type=Path,
        default=Path("batch_results/grid_probe_detection_cache"),
    )
    args = parser.parse_args()
    global SEED_GEOMETRY_REFINE_TOP
    if args.seed_geometry_refine_top is not None:
        SEED_GEOMETRY_REFINE_TOP = max(1, int(args.seed_geometry_refine_top))
    if args.enable_component_face_quads:
        os.environ["GRID_PROBE_ENABLE_COMPONENT_FACE_QUADS"] = "1"
    if args.component_face_label_permutations and not args.auto_seed_routes:
        os.environ["GRID_PROBE_COMPONENT_FACE_LABEL_PERMUTATIONS"] = "1"
    if args.auto_route:
        os.environ["GRID_PROBE_AUTO_ROUTE_NAMES"] = ",".join(args.auto_route)

    rels = load_rel_paths(args.rel_list)
    if args.rel_path:
        wanted = {item.replace("\\", "/") for item in args.rel_path}
        rels = [rel for rel in rels if rel in wanted]
    args.out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for rel in rels:
        image_started = time.perf_counter()
        common = {
            "top_per_face": max(1, int(args.top_per_face)),
            "max_combos": max(1, int(args.max_combos)),
            "run_calibration": not args.skip_calibration,
            "fast_geometry": not args.slow_geometry,
            "focal_px": args.focal_px,
            "enable_phase_grid": bool(args.enable_phase_grid),
            "enable_dark_square_grid": bool(args.enable_dark_square_grid),
            "enable_component_face_quads": bool(args.enable_component_face_quads),
            "enable_crop_trihedral": bool(args.enable_crop_trihedral),
            "augment_seed_alternatives": bool(args.augment_seed_alternatives),
            "allow_seed_only_fallback": bool(args.allow_seed_only_fallback),
            "fixed_focal_joint_refine": bool(args.fixed_focal_joint_refine),
            "enable_component_label_permutations": bool(
                args.component_face_label_permutations),
            "detect_cache_dir": args.detect_cache_dir,
        }
        if args.auto_seed_routes:
            row = probe_auto_seed_routes(
                rel,
                args.image_root,
                args.out_dir,
                **common,
            )
        else:
            row = probe_one(
                rel,
                args.image_root,
                args.out_dir,
                seed_geometry_refine=bool(args.seed_geometry_refine),
                **common,
            )
            row["elapsed_sec"] = time.perf_counter() - image_started
        rows.append(row)
        print(json.dumps({
            "rel_path": rel,
            "status": row.get("status"),
            "patterns": row.get("extrapolated_patterns"),
            "offset_pnp": row.get("extrapolated_offset_pnp"),
            "rmse_px": row.get("rmse_px"),
            "selected_route": row.get("selected_route"),
        }, ensure_ascii=False), flush=True)
        write_csv(args.out_dir / "grid_extrapolate_recovery_probe.csv", rows)
        (args.out_dir / "grid_extrapolate_recovery_probe.json").write_text(
            json.dumps(rows, ensure_ascii=False, indent=2, default=jsonable),
            encoding="utf-8",
        )
    write_csv(args.out_dir / "grid_extrapolate_recovery_probe.csv", rows)
    (args.out_dir / "grid_extrapolate_recovery_probe.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2, default=jsonable),
        encoding="utf-8",
    )
    print(json.dumps({
        "total": len(rows),
        "calibrated": sum(1 for row in rows if row.get("status") == "calibrated"),
        "out_dir": str(args.out_dir),
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
