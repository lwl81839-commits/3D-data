#!/usr/bin/env python3
"""Probe cube faces from checkerboard line vanishing-point sharing.

This is diagnostic-only.  It does not relax the production acceptance gate.
The goal is to test a different recognition idea:

1. collect chessboard detections from the current detectors;
2. fit row/column line pencils for every detection;
3. cluster those pencils by vanishing point, not by image-line angle;
4. look for three board detections whose VP pairs form a trihedral triangle.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import cv2
import numpy as np

from calibration_policy import maybe_float
from face_detector import (
    _bbox_of_corners,
    _cube_detection_geometry_rmse,
    _detect_all,
    _detect_cube_first,
    _detect_cube_first_in_upscaled_crop,
    _iou,
    _line_quality_for_candidate,
    detect_corner_cube_faces,
)
from three_face_calib import (
    estimate_vanishing_point,
    lines_from_chessboard_corners,
)


DEFAULT_RESULTS_CSV = Path(
    "batch_results/exe_full_all_final_20260621_2158/current_batch_results.csv"
)
DEFAULT_OUT_DIR = Path("batch_results/checkerline_vp_probe")
DEFAULT_STATUSES = [
    "partial_face_geometry_boundary",
    "insufficient_visible_faces",
    "low_confidence",
]
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def _first_existing_image_root() -> Path:
    for extracted in sorted(Path(".").glob("*_extracted")):
        candidate = extracted / "shengkelou"
        if candidate.is_dir():
            return candidate
    raise FileNotFoundError("Could not find *_extracted/shengkelou")


def _safe_rel(path: Path, base: Path) -> str:
    try:
        return path.resolve().relative_to(base.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def _read_gray(path: Path) -> np.ndarray:
    data = np.fromfile(str(path), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Cannot decode image: {path}")
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def _load_rows(path: Path) -> List[Dict[str, Any]]:
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def _filter_rows(
    rows: List[Dict[str, Any]],
    statuses: Optional[Sequence[str]],
    groups: Optional[Sequence[str]],
    rel_paths: Optional[Sequence[str]],
    limit: Optional[int],
) -> List[Dict[str, Any]]:
    status_set = {s for s in statuses or [] if s}
    group_set = {g for g in groups or [] if g}
    rel_set = {p.replace("\\", "/") for p in rel_paths or [] if p}
    out = []
    for row in rows:
        if status_set and row.get("status") not in status_set:
            continue
        if group_set and row.get("group") not in group_set:
            continue
        rel = str(row.get("rel_path", "")).replace("\\", "/")
        if rel_set and rel not in rel_set:
            continue
        out.append(row)
        if limit is not None and len(out) >= limit:
            break
    return out


def _candidate_key(corners: np.ndarray, pattern: Tuple[int, int]) -> Tuple[Any, ...]:
    bbox = _bbox_of_corners(corners)
    cx = int(round((bbox[0] + bbox[2]) / 24.0))
    cy = int(round((bbox[1] + bbox[3]) / 24.0))
    return (int(pattern[0]), int(pattern[1]), cx, cy)


def _quality(corners: np.ndarray, pattern: Tuple[int, int]) -> float:
    q = _line_quality_for_candidate(corners, pattern)
    return float(q) if np.isfinite(q) else float("inf")


def _add_candidate(
    candidates: List[Dict[str, Any]],
    corners: np.ndarray,
    pattern: Tuple[int, int],
    label: str,
    source: str,
) -> None:
    if corners is None:
        return
    pat = (int(pattern[0]), int(pattern[1]))
    c = corners.reshape(-1, 1, 2).astype(np.float32)
    q = _quality(c, pat)
    bbox = _bbox_of_corners(c)
    candidates.append(
        {
            "corners": c,
            "pattern": pat,
            "label": str(label or ""),
            "source": source,
            "bbox": bbox,
            "corner_count": int(len(c)),
            "quality": q,
            "key": _candidate_key(c, pat),
        }
    )


def _dedupe_candidates(candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    candidates = sorted(
        candidates,
        key=lambda c: (
            int(c["corner_count"]),
            -float(c["quality"] if np.isfinite(c["quality"]) else 99.0),
        ),
        reverse=True,
    )
    kept: List[Dict[str, Any]] = []
    for cand in candidates:
        duplicate = False
        for old in kept:
            if cand["pattern"] == old["pattern"] and _iou(cand["bbox"], old["bbox"]) > 0.68:
                duplicate = True
                break
            if _iou(cand["bbox"], old["bbox"]) > 0.82:
                duplicate = True
                break
        if not duplicate:
            cand["idx"] = len(kept)
            kept.append(cand)
    return kept


def collect_candidates(gray: np.ndarray, sources: Sequence[str]) -> List[Dict[str, Any]]:
    candidates: List[Dict[str, Any]] = []

    raw_sources = []
    source_set = {str(s).strip() for s in sources if str(s).strip()}
    for source, fn in [
        ("cube_direct", _detect_cube_first),
        ("cube_upscaled", _detect_cube_first_in_upscaled_crop),
        ("current_full", detect_corner_cube_faces),
    ]:
        if source not in source_set:
            continue
        try:
            dets = fn(gray, n_faces=3, verbose=False)
        except Exception:
            dets = []
        for corners, pat, label in dets or []:
            raw_sources.append((source, corners, pat, label))

    if "global_pattern" in source_set:
        try:
            for corners, pat in _detect_all(gray, n_faces=3, verbose=False) or []:
                raw_sources.append(("global_pattern", corners, pat, ""))
        except Exception:
            pass

    for source, corners, pat, label in raw_sources:
        _add_candidate(candidates, corners, pat, label, source)

    return _dedupe_candidates(candidates)


def _vp_bearing(v: np.ndarray, image_shape: Tuple[int, int]) -> np.ndarray:
    h, w = image_shape[:2]
    cx, cy = w / 2.0, h / 2.0
    f = 0.85 * float(math.hypot(w, h))
    v = np.asarray(v, dtype=np.float64).reshape(3)
    if abs(v[2]) > 1e-8:
        x = float(v[0] / v[2])
        y = float(v[1] / v[2])
        ray = np.array([x - cx, y - cy, f], dtype=np.float64)
    else:
        ray = np.array([float(v[0]), float(v[1]), 0.0], dtype=np.float64)
    n = np.linalg.norm(ray)
    if n < 1e-12 or not np.all(np.isfinite(ray)):
        return np.array([1.0, 0.0, 0.0], dtype=np.float64)
    ray = ray / n
    if ray[2] < 0:
        ray = -ray
    return ray


def _angle_deg(a: np.ndarray, b: np.ndarray) -> float:
    dot = float(np.clip(abs(np.dot(a, b)), -1.0, 1.0))
    return float(np.degrees(np.arccos(dot)))


def axis_observations(
    candidates: List[Dict[str, Any]],
    image_shape: Tuple[int, int],
) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for cand in candidates:
        try:
            row_lines, col_lines, row_q, col_q = lines_from_chessboard_corners(
                cand["corners"], cand["pattern"], use_ransac=True
            )
            row_vp = estimate_vanishing_point(np.asarray(row_lines, dtype=np.float64))
            col_vp = estimate_vanishing_point(np.asarray(col_lines, dtype=np.float64))
        except Exception:
            continue
        for axis_type, lines, q, vp in [
            ("row", row_lines, row_q, row_vp),
            ("col", col_lines, col_q, col_vp),
        ]:
            quality = float(q) if np.isfinite(q) else 99.0
            out.append(
                {
                    "candidate_idx": cand["idx"],
                    "axis_type": axis_type,
                    "lines": lines,
                    "line_count": int(len(lines)),
                    "quality": quality,
                    "vp": np.asarray(vp.v, dtype=np.float64),
                    "bearing": _vp_bearing(vp.v, image_shape),
                    "weight": float(len(lines)) / max(quality, 0.25),
                }
            )
    return out


def cluster_axis_observations(
    observations: List[Dict[str, Any]],
    angle_thresh_deg: float,
) -> List[Dict[str, Any]]:
    clusters: List[Dict[str, Any]] = []
    for obs in sorted(observations, key=lambda o: o["weight"], reverse=True):
        best_i = -1
        best_angle = float("inf")
        for i, cl in enumerate(clusters):
            angle = _angle_deg(obs["bearing"], cl["bearing"])
            if angle < best_angle:
                best_i = i
                best_angle = angle
        if best_i >= 0 and best_angle <= angle_thresh_deg:
            cl = clusters[best_i]
            cl["observations"].append(obs)
            _refresh_cluster(cl)
        else:
            clusters.append(
                {
                    "id": len(clusters),
                    "observations": [obs],
                    "bearing": obs["bearing"].copy(),
                    "weight": obs["weight"],
                }
            )
    clusters.sort(key=lambda c: c["weight"], reverse=True)
    for i, cl in enumerate(clusters):
        cl["id"] = i
        for obs in cl["observations"]:
            obs["cluster"] = i
    return clusters


def _refresh_cluster(cluster: Dict[str, Any]) -> None:
    base = cluster["observations"][0]["bearing"]
    acc = np.zeros(3, dtype=np.float64)
    weight = 0.0
    for obs in cluster["observations"]:
        b = obs["bearing"].copy()
        if np.dot(base, b) < 0:
            b = -b
        w = float(obs["weight"])
        acc += w * b
        weight += w
    n = np.linalg.norm(acc)
    cluster["bearing"] = acc / n if n > 1e-12 else base
    cluster["weight"] = weight


def _candidate_axis_pairs(
    candidates: List[Dict[str, Any]],
    observations: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    by_candidate: Dict[int, Dict[str, Dict[str, Any]]] = {}
    for obs in observations:
        if "cluster" not in obs:
            continue
        by_candidate.setdefault(int(obs["candidate_idx"]), {})[obs["axis_type"]] = obs

    out = []
    for cand in candidates:
        axes = by_candidate.get(int(cand["idx"]), {})
        if "row" not in axes or "col" not in axes:
            continue
        a = int(axes["row"]["cluster"])
        b = int(axes["col"]["cluster"])
        if a == b:
            continue
        pair = tuple(sorted((a, b)))
        out.append(
            {
                "candidate": cand,
                "pair": pair,
                "row_cluster": a,
                "col_cluster": b,
                "axis_quality": max(float(axes["row"]["quality"]), float(axes["col"]["quality"])),
                "axis_lines": int(axes["row"]["line_count"] + axes["col"]["line_count"]),
            }
        )
    return out


def _max_overlap(items: Sequence[Dict[str, Any]]) -> float:
    max_iou = 0.0
    for a, b in itertools.combinations(items, 2):
        max_iou = max(max_iou, float(_iou(a["candidate"]["bbox"], b["candidate"]["bbox"])))
    return max_iou


def find_trihedral_combo(
    candidates: List[Dict[str, Any]],
    observations: List[Dict[str, Any]],
    image_shape: Tuple[int, int],
) -> Optional[Dict[str, Any]]:
    pair_items = _candidate_axis_pairs(candidates, observations)
    best = None
    for combo in itertools.combinations(pair_items, 3):
        cand_ids = [int(item["candidate"]["idx"]) for item in combo]
        if len(set(cand_ids)) < 3:
            continue
        pairs = [item["pair"] for item in combo]
        if len(set(pairs)) < 3:
            continue
        clusters = sorted(set(v for pair in pairs for v in pair))
        if len(clusters) != 3:
            continue
        degree = Counter(v for pair in pairs for v in pair)
        if sorted(degree.values()) != [2, 2, 2]:
            continue
        overlap = _max_overlap(combo)
        if overlap > 0.70:
            continue
        corner_count = sum(int(item["candidate"]["corner_count"]) for item in combo)
        mean_quality = sum(float(item["axis_quality"]) for item in combo) / 3.0
        sparse_count = sum(1 for item in combo if min(item["candidate"]["pattern"]) < 5)
        source_bonus = sum(
            10.0 if str(item["candidate"]["source"]).startswith("cube") else 0.0
            for item in combo
        )
        score = (
            float(corner_count)
            + source_bonus
            - 18.0 * float(mean_quality)
            - 35.0 * float(overlap)
            - 25.0 * float(sparse_count)
        )
        record = {
            "score": score,
            "corner_count": corner_count,
            "mean_quality": mean_quality,
            "max_overlap": overlap,
            "sparse_count": sparse_count,
            "pairs": pairs,
            "clusters": clusters,
            "items": combo,
            "fast_pnp_rmse": _combo_fast_pnp_rmse(combo, image_shape),
        }
        if best is None or score > best["score"]:
            best = record
    return best


def _combo_fast_pnp_rmse(
    combo: Sequence[Dict[str, Any]],
    image_shape: Tuple[int, int],
) -> float:
    order_pairs = sorted({item["pair"] for item in combo})
    expected_pairs = [(0, 1), (0, 2), (1, 2)]
    label_by_pair = dict(zip(order_pairs, ["XY", "XZ", "YZ"]))
    detections = []
    for item in combo:
        cand = item["candidate"]
        label = cand["label"] if cand["label"] in {"XY", "XZ", "YZ"} else label_by_pair.get(item["pair"], "")
        detections.append((cand["corners"], cand["pattern"], label))
    try:
        return float(_cube_detection_geometry_rmse(detections, image_shape, n_faces=3))
    except Exception:
        return float("inf")


def _cluster_summary(clusters: List[Dict[str, Any]], max_items: int = 5) -> str:
    parts = []
    for cl in clusters[:max_items]:
        obs = cl["observations"]
        dets = sorted(set(int(o["candidate_idx"]) for o in obs))
        lines = sum(int(o["line_count"]) for o in obs)
        q = np.mean([float(o["quality"]) for o in obs]) if obs else float("inf")
        parts.append(
            f"V{cl['id']}:obs={len(obs)},dets={len(dets)},lines={lines},q={q:.2f}"
        )
    return " | ".join(parts)


def _combo_desc(best: Optional[Dict[str, Any]]) -> Tuple[str, str, str, str]:
    if best is None:
        return "", "", "", ""
    faces = []
    patterns = []
    pairs = []
    sources = []
    for item in best["items"]:
        cand = item["candidate"]
        faces.append(f"{cand['label'] or '?'}#{cand['idx']}")
        patterns.append(f"{cand['pattern'][0]}x{cand['pattern'][1]}")
        pairs.append(f"V{item['pair'][0]}-V{item['pair'][1]}")
        sources.append(str(cand["source"]))
    return ";".join(faces), ";".join(patterns), ";".join(pairs), ";".join(sources)


def probe_one(
    row: Dict[str, Any],
    image_root: Path,
    angle_thresh_deg: float,
    sources: Sequence[str],
) -> Dict[str, Any]:
    started = time.perf_counter()
    rel_path = str(row.get("rel_path") or f"{row.get('group')}/{row.get('image')}")
    path = image_root / rel_path
    out: Dict[str, Any] = {
        "rel_path": rel_path.replace("\\", "/"),
        "group": row.get("group", ""),
        "image": row.get("image", Path(rel_path).name),
        "baseline_status": row.get("status", ""),
        "baseline_decision": row.get("decision", ""),
        "cube_area_pct": maybe_float(row.get("cube_area_pct")),
        "baseline_recognition_status": row.get("recognition_status", ""),
        "baseline_calibration_status": row.get("calibration_status", ""),
        "probe_status": "error",
        "reason": "",
    }
    try:
        gray = _read_gray(path)
        candidates = collect_candidates(gray, sources)
        observations = axis_observations(candidates, gray.shape)
        clusters = cluster_axis_observations(observations, angle_thresh_deg)
        best = find_trihedral_combo(candidates, observations, gray.shape)
        valid_clusters = [
            cl for cl in clusters
            if len(cl["observations"]) >= 2
        ]
        if best is not None:
            if best["sparse_count"] == 0 and best["mean_quality"] <= 5.0:
                probe_status = "trihedral_vp_combo"
            else:
                probe_status = "trihedral_vp_combo_sparse_or_noisy"
            reason = (
                f"score={best['score']:.1f}; corners={best['corner_count']}; "
                f"q={best['mean_quality']:.2f}; overlap={best['max_overlap']:.2f}; "
                f"sparse={best['sparse_count']}"
            )
        elif len(valid_clusters) >= 3:
            probe_status = "vp_support_no_face_combo"
            reason = "Three or more shared VP clusters found, but no 3-face triangle combo."
        elif len(clusters) >= 3:
            probe_status = "weak_vp_support"
            reason = "Three VP clusters found, but not enough shared observations."
        else:
            probe_status = "insufficient_vp_support"
            reason = "Fewer than three VP clusters found."
        faces, patterns, pairs, sources = _combo_desc(best)
        out.update(
            {
                "probe_status": probe_status,
                "reason": reason,
                "num_candidates": len(candidates),
                "num_axis_observations": len(observations),
                "num_vp_clusters": len(clusters),
                "num_shared_vp_clusters": len(valid_clusters),
                "cluster_summary": _cluster_summary(clusters),
                "best_combo_score": None if best is None else best["score"],
                "best_combo_corners": None if best is None else best["corner_count"],
                "best_combo_mean_quality": None if best is None else best["mean_quality"],
                "best_combo_max_overlap": None if best is None else best["max_overlap"],
                "best_combo_sparse_count": None if best is None else best["sparse_count"],
                "best_combo_fast_pnp_rmse": None if best is None else best["fast_pnp_rmse"],
                "best_combo_faces": faces,
                "best_combo_patterns": patterns,
                "best_combo_pairs": pairs,
                "best_combo_sources": sources,
                "elapsed_sec": time.perf_counter() - started,
            }
        )
    except Exception as exc:
        out["probe_status"] = "error"
        out["reason"] = str(exc)
        out["elapsed_sec"] = time.perf_counter() - started
    return out


CSV_FIELDS = [
    "rel_path",
    "group",
    "image",
    "baseline_status",
    "baseline_decision",
    "cube_area_pct",
    "baseline_recognition_status",
    "baseline_calibration_status",
    "probe_status",
    "reason",
    "num_candidates",
    "num_axis_observations",
    "num_vp_clusters",
    "num_shared_vp_clusters",
    "cluster_summary",
    "best_combo_score",
    "best_combo_corners",
    "best_combo_mean_quality",
    "best_combo_max_overlap",
    "best_combo_sparse_count",
    "best_combo_fast_pnp_rmse",
    "best_combo_faces",
    "best_combo_patterns",
    "best_combo_pairs",
    "best_combo_sources",
    "elapsed_sec",
]


def _clean(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.10g}" if math.isfinite(value) else ""
    return value


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: _clean(row.get(k)) for k in CSV_FIELDS})


def write_json(path: Path, rows: List[Dict[str, Any]], summary: Dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump({"summary": summary, "rows": rows}, f, ensure_ascii=False, indent=2)


def write_markdown(path: Path, rows: List[Dict[str, Any]], summary: Dict[str, Any]) -> None:
    lines = [
        "# Checkerboard-Line Vanishing-Point Probe",
        "",
        f"- Generated: {summary['generated_at']}",
        f"- Images: {summary['images']}",
        f"- Angle threshold: {summary['angle_thresh_deg']:.1f} deg",
        f"- Probe status counts: `{summary['probe_status_counts']}`",
        f"- Baseline status counts: `{summary['baseline_status_counts']}`",
        "",
        "## Interpretation",
        "",
        "`trihedral_vp_combo` means three candidate boards formed the expected "
        "three VP-pair triangle. `vp_support_no_face_combo` means three VP "
        "directions were present but could not yet be assigned to three usable "
        "faces. This probe is diagnostic-only and does not change product "
        "acceptance.",
        "",
        "## Candidate Signals",
        "",
        "| image | baseline | cube area % | probe | candidates | VP clusters | combo faces | combo pairs | reason |",
        "|---|---|---:|---|---:|---:|---|---|---|",
    ]
    for row in rows:
        reason = str(row.get("reason", "")).replace("|", "/")
        if len(reason) > 140:
            reason = reason[:137] + "..."
        lines.append(
            "| {image} | {baseline} | {area} | {probe} | {cand} | {vps} | {faces} | {pairs} | {reason} |".format(
                image=f"{row.get('group','')}/{row.get('image','')}",
                baseline=row.get("baseline_status", ""),
                area=_clean(row.get("cube_area_pct")),
                probe=row.get("probe_status", ""),
                cand=row.get("num_candidates", ""),
                vps=row.get("num_vp_clusters", ""),
                faces=row.get("best_combo_faces", ""),
                pairs=row.get("best_combo_pairs", ""),
                reason=reason,
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-csv", type=Path, default=DEFAULT_RESULTS_CSV)
    parser.add_argument("--image-root", type=Path, default=None)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    parser.add_argument("--status", action="append", default=None)
    parser.add_argument("--group", action="append", default=None)
    parser.add_argument("--rel-path", action="append", default=None)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--angle-thresh-deg", type=float, default=10.0)
    parser.add_argument(
        "--source",
        action="append",
        default=None,
        choices=["cube_direct", "cube_upscaled", "current_full", "global_pattern"],
        help=(
            "Candidate source to use. Repeat for multiple. Default is fast: "
            "cube_direct + global_pattern."
        ),
    )
    parser.add_argument("--all-statuses", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    image_root = (args.image_root or _first_existing_image_root()).resolve()
    rows = _load_rows(args.results_csv)
    statuses = None if args.all_statuses else (args.status or DEFAULT_STATUSES)
    selected = _filter_rows(rows, statuses, args.group, args.rel_path, args.limit)
    if not selected:
        raise FileNotFoundError("No rows selected for probe.")
    sources = args.source or ["cube_direct", "global_pattern"]

    args.out_dir.mkdir(parents=True, exist_ok=True)
    out_rows = []
    for idx, row in enumerate(selected, 1):
        result = probe_one(row, image_root, args.angle_thresh_deg, sources)
        out_rows.append(result)
        print(
            f"[{idx}/{len(selected)}] {result['rel_path']} "
            f"{result['baseline_status']} -> {result['probe_status']} "
            f"({result.get('num_candidates', 0)} cand, "
            f"{result.get('num_vp_clusters', 0)} VP, "
            f"{result.get('elapsed_sec', 0):.1f}s)"
        )

    summary = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "results_csv": str(args.results_csv),
        "image_root": str(image_root),
        "images": len(out_rows),
        "angle_thresh_deg": float(args.angle_thresh_deg),
        "sources": list(sources),
        "probe_status_counts": dict(Counter(r.get("probe_status", "") for r in out_rows)),
        "baseline_status_counts": dict(Counter(r.get("baseline_status", "") for r in out_rows)),
    }
    write_csv(args.out_dir / "checkerline_vp_probe.csv", out_rows)
    write_json(args.out_dir / "checkerline_vp_probe.json", out_rows, summary)
    write_markdown(args.out_dir / "checkerline_vp_probe.md", out_rows, summary)
    print(f"Wrote: {args.out_dir / 'checkerline_vp_probe.csv'}")
    print(f"Wrote: {args.out_dir / 'checkerline_vp_probe.json'}")
    print(f"Wrote: {args.out_dir / 'checkerline_vp_probe.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
