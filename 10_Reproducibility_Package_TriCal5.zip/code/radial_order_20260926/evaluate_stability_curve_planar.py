from run_0820_stability_curve import OUT,ROOT,SPLIT,POSES,read,save,run
from concurrent.futures import ThreadPoolExecutor
import sys,os,runpy,time
def prepare():
    s=(ROOT/'evaluate_planar_per_pose_controlled.py').read_text(encoding='utf-8')
    s=s.replace('for pose_index, pose in enumerate(POSES):','for pose_index, pose in enumerate(POSES):\n        if pose != __import__("os").environ["CURVE_POSE"]: continue')
    needle='models = {"ours_3d_5_images": (ours_K, ours_dist), "zhang_matlab_20_images": (zhang_K, zhang_dist)}'
    s=s.replace(needle,needle+'\n        for mp in Path('+repr(str(OUT/'models'))+').joinpath(pose).glob("*/trained_camera_model.json"):\n            m = json.loads(mp.read_text(encoding="utf-8"))\n            models[mp.parent.name] = (np.array(m["cameraMatrix"]), np.array(m["distCoeffs"]))')
    s=s.replace('out = validation / "final_test_evaluation" / pose / "planar_2d_controlled"','out = Path('+repr(str(OUT))+') / "planar_evaluations" / pose')
    s=s.replace('validation / "final_test_evaluation" / "PLANAR_2D_CONTROLLED_SUMMARY.json"','Path('+repr(str(OUT))+') / ("planar_summary_" + __import__("os").environ["CURVE_POSE"] + ".json")')
    (OUT/'code/evaluate_planar_curve.py').write_text(s,encoding='utf-8')
def wait_and_run(pose):
    jobs=[j for j in read(OUT/'protocol.json')['jobs'] if j['pose']==pose]
    start=time.monotonic()
    while not all((OUT/'models'/pose/j['name']/'status.json').exists() for j in jobs):
        if time.monotonic()-start>3600:raise RuntimeError('Training wait exceeded one hour')
        time.sleep(5)
    return run('planar_'+pose,[__file__,pose])
if __name__=='__main__':
    if len(sys.argv)>1:
        os.environ['CURVE_POSE']=sys.argv[1];sys.argv=[str(OUT/'code/evaluate_planar_curve.py'),'--split-root',str(SPLIT),'--repeats','20'];runpy.run_path(sys.argv[0],run_name='__main__')
    else:
        prepare()
        poses=[s['pose'] for s in read(OUT/'protocol.json')['splits']]
        with ThreadPoolExecutor(max_workers=3) as pool:statuses=list(pool.map(wait_and_run,poses))
        save(OUT/'planar_jobs.json',statuses)
