import unittest

import numpy as np

from evaluate_trained_camera_model import face_ids, finite, stats


class EvaluationHelpersTest(unittest.TestCase):
    def test_face_assignment(self):
        points = np.array([
            [10.0, 20.0, 0.0],
            [10.0, 0.0, 20.0],
            [0.0, 10.0, 20.0],
        ])
        np.testing.assert_array_equal(face_ids(points), [0, 1, 2])

    def test_statistics(self):
        result = stats([1.0, 2.0, 3.0])
        self.assertEqual(result["n"], 3)
        self.assertAlmostEqual(result["mean"], 2.0)
        self.assertAlmostEqual(result["rmse"], np.sqrt(14.0 / 3.0))

    def test_boolean_json_value_stays_boolean(self):
        self.assertIs(finite(True), True)
        self.assertIs(finite(np.bool_(False)), False)


if __name__ == "__main__":
    unittest.main()
