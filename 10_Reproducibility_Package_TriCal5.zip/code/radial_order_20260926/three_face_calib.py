#!/usr/bin/env python3
"""
Three-Face Chessboard Single-Image Camera Calibration
======================================================

Theory:
  Uses vanishing points from three mutually orthogonal chessboard faces
  to decouple intrinsic (IAC) and extrinsic (PnP) calibration from a
  single photograph.

  Three orthogonal vanishing points V_X, V_Y, V_Z satisfy:
      V_i^T · ω · V_j = 0   (i ≠ j)
  where ω = K^{-T} K^{-1} is the Image of the Absolute Conic.

  Solving for ω → Cholesky factorisation → K.  With K known, extrinsics
  follow from PnP on the known 3D→2D correspondences.  A final bundle
  adjustment refines all parameters jointly.

Assumptions:
  - Three chessboard faces are mutually orthogonal (corner-cube target).
  - Target sits on a flat ground plane; side faces are perpendicular to
    the ground; the top face is parallel to the ground.
  - Chessboard square size is known exactly.
  - Each face can provide at least two sets of parallel lines (rows & cols)
    so that the three mutually orthogonal vanishing directions are covered.

Usage:
  python three_face_calib.py                    # run synthetic demo
  python three_face_calib.py image.jpg          # calibrate from real image
"""

from __future__ import annotations

import itertools
import os
import sys
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import cv2
import numpy as np
from scipy.optimize import least_squares
from scipy.linalg import cholesky

from checker_plumbline_distortion import estimate_checker_plumbline_distortion


# ──────────────────────────────── VP Label Helper ────────────────────────

def get_vp_labels(n_faces: int = 3) -> List[List[str]]:
    """Return VP direction labels for the selected face configuration.

    Face A (XY plane): X from cols, Y from rows
    Face B (XZ plane): X from cols, Z from rows
    Face C (YZ plane): Y from cols, Z from rows

    Returns n_faces entries from [["X","Y"], ["X","Z"], ["Y","Z"]].
    """
    all_labels = [["X", "Y"], ["X", "Z"], ["Y", "Z"]]
    return all_labels[:n_faces]


# ──────────────────────────────── Data Structures ────────────────────────

@dataclass
class FaceDefinition:
    """Geometry of one chessboard face on the 3-D target.

    Parameters
    ----------
    pattern_size : (cols, rows)
        Number of *inner* corners along each axis of the chessboard
        (the OpenCV convention).
    square_size : float
        Side length of one square (mm or any consistent unit).
    axis_x : (3,) ndarray
        Direction in world coordinates of the chessboard *columns*
        (horizontal vanishing direction for this face).
    axis_y : (3,) ndarray
        Direction in world coordinates of the chessboard *rows*
        (vertical vanishing direction for this face).
    origin_3d : (3,) ndarray
        World coordinate of the first corner (top-left of the pattern).
    """

    pattern_size: Tuple[int, int]       # (cols, rows) inner corners
    square_size: float
    axis_x: np.ndarray                  # unit vector for columns
    axis_y: np.ndarray                  # unit vector for rows
    origin_3d: np.ndarray               # world coords of corner (0, 0)


@dataclass
class DetectedFace:
    """Corners detected on one face + pre-computed world points."""

    image_points: np.ndarray            # (N, 1, 2)  float32
    object_points: np.ndarray           # (N, 1, 3)  float32
    valid: bool = True


@dataclass
class VanishingPoint:
    """A homogeneous vanishing point + diagnostic info."""

    v: np.ndarray                       # (3,) homogeneous, v[2] ≈ 1 or ≈ 0 (inf)
    direction_label: str = ""           # "X", "Y", "Z"
    is_finite: bool = True


@dataclass
class CalibrationResult:
    """Output of the single-image calibration pipeline."""

    K: np.ndarray                       # 3x3 intrinsic matrix
    dist: np.ndarray                    # [k1,k2,p1,p2,k3] or empty
    R: np.ndarray                       # 3x3 rotation (world -> camera)
    t: np.ndarray                       # (3,) translation (mm)
    scale: Optional[float] = None       # recovered square size (mm), None if fixed
    reproj_error: float = 0.0           # RMSE (pixels)
    vanishing_points: dict = field(default_factory=dict)


# ──────────────────────── Image Preprocessing ──────────────────────────

def preprocess_image(gray: np.ndarray,
                     clip_limit: float = 2.0,
                     ) -> np.ndarray:
    """Enhance contrast with CLAHE to handle uneven lighting across faces.

    Parameters
    ----------
    gray : (H, W) uint8 grayscale image.
    clip_limit : CLAHE clip limit (higher = more aggressive contrast).

    Returns
    -------
    enhanced : (H, W) uint8
    """
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=(8, 8))
    return clahe.apply(gray)


# ──────────────── Blur-Adaptive Corner Refinement ─────────────────────

def estimate_blur_level(gray: np.ndarray,
                         corners: np.ndarray,
                         sample_radius: int = 12,
                         ) -> float:
    """Estimate blur level from the mean gradient energy at corner locations.

    Lower value = more blur.  Used to choose cornerSubPix window size
    adaptively: blurry faces need larger windows to capture enough
    gradient context for saddle-point localisation.

    Returns a score in approximately [0, 1] range (0 = severe blur, 1 = sharp).
    """
    gx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    h_img, w_img = gray.shape[:2]
    scores = []
    for pt in corners.reshape(-1, 2):
        x, y = int(round(pt[0])), int(round(pt[1]))
        y0, y1 = max(0, y - sample_radius), min(h_img, y + sample_radius + 1)
        x0, x1 = max(0, x - sample_radius), min(w_img, x + sample_radius + 1)
        if y1 <= y0 or x1 <= x0:
            continue
        patch_gx = gx[y0:y1, x0:x1]
        patch_gy = gy[y0:y1, x0:x1]
        scores.append(float((patch_gx * patch_gx + patch_gy * patch_gy).mean()))
    if not scores:
        return 0.5
    # Normalise to [0, 1] using log scale with reference points:
    #   raw ~ 200000: very sharp chessboard  → score ≈ 1.0
    #   raw ~  20000: moderately sharp        → score ≈ 0.7
    #   raw ~   2000: moderate blur           → score ≈ 0.45
    #   raw ~    200: severe blur             → score ≈ 0.2
    raw = float(np.mean(scores))
    return float(np.clip(np.log1p(raw) / np.log1p(100000), 0.0, 1.0))


def adaptive_subpix_window(blur_score: float) -> Tuple[int, int]:
    """Return (window_w, window_h) for cornerSubPix based on blur level.

    Blurry images need larger windows because the saddle-point gradient
    is spread over more pixels.  Uses continuous mapping from 11→31.
    """
    # Linear interpolation: score 1.0 → 11, score 0.0 → 31
    w = int(round(31.0 - blur_score * 20.0))
    w = max(11, min(31, w))
    # Force odd
    if w % 2 == 0:
        w += 1
    return (w, w)


def detect_corners_multiscale(gray: np.ndarray,
                               pattern_size: Tuple[int, int],
                               max_scales: int = 3,
                               ) -> Optional[np.ndarray]:
    """Multi-scale fallback for blurry faces where standard detection fails.

    Downsamples the image step by step (factor 2 each time).  Blur
    removes high-frequency noise; at lower resolution the chessboard
    pattern may become detectable again.

    Returns corners in ORIGINAL image coordinates, or None.
    """
    h, w = gray.shape[:2]
    for scale_idx in range(max_scales):
        factor = 2 ** scale_idx
        scaled_h, scaled_w = h // factor, w // factor
        if scaled_h < 100 or scaled_w < 100:
            break
        if factor == 1:
            scaled = gray
        else:
            scaled = cv2.resize(gray, (scaled_w, scaled_h),
                                interpolation=cv2.INTER_AREA)
        ok, corners = cv2.findChessboardCorners(
            scaled, pattern_size,
            flags=cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE,
        )
        if ok and corners is not None:
            # Scale back to original coordinates
            if factor > 1:
                corners = corners.astype(np.float32) * float(factor)
            return corners
    return None


# ──────────────────────── Vanishing Point Estimation ────────────────────

def robust_fit_line_ransac(pts: np.ndarray,
                           n_iterations: int = 200,
                           threshold: float = 1.5,
                           min_inlier_ratio: float = 0.5,
                           ) -> Tuple[np.ndarray, np.ndarray, float]:
    """Fit a 2-D line robustly using RANSAC.

    This handles non-ideal chessboard prints where individual corners
    may be significantly displaced from the ideal grid.

    Parameters
    ----------
    pts : (N, 2)
    n_iterations : RANSAC iterations.
    threshold : inlier distance threshold (pixels).
    min_inlier_ratio : minimum fraction of inliers to accept the model.

    Returns
    -------
    line : (3,) homogeneous line [a, b, c] with a²+b²=1.
    inlier_mask : (N,) bool array.
    quality : RMS error of inliers (pixels).  Lower is better.
    """
    N = len(pts)
    if N < 3:
        line = fit_line_tls(pts)
        return line, np.ones(N, dtype=bool), 0.0

    best_line = None
    best_inliers = None
    best_count = 0
    best_rms = np.inf

    try:
        exhaustive_max_points = int(float(os.environ.get(
            "CALIB_LINE_RANSAC_EXHAUSTIVE_MAX_POINTS", "0")))
    except ValueError:
        exhaustive_max_points = 0
    exhaustive_max_points = max(0, exhaustive_max_points)
    all_pairs = N * (N - 1) // 2
    if N <= exhaustive_max_points and all_pairs <= n_iterations:
        candidate_pairs = itertools.combinations(range(N), 2)
    else:
        candidate_pairs = (
            tuple(np.random.choice(N, 2, replace=False))
            for _ in range(n_iterations)
        )

    for i1, i2 in candidate_pairs:
        p1, p2 = pts[i1], pts[i2]
        dx, dy = p2 - p1
        a, b = -dy, dx
        nrm = np.hypot(a, b)
        if nrm < 1e-10:
            continue
        a, b = a / nrm, b / nrm
        c = -(a * p1[0] + b * p1[1])

        dists = np.abs(a * pts[:, 0] + b * pts[:, 1] + c)
        inliers = dists < threshold
        count = inliers.sum()

        if count >= max(2, int(N * min_inlier_ratio)) and count >= best_count:
            # Refit on inliers with TLS
            if count >= 3:
                refined = fit_line_tls(pts[inliers])
                rms = np.sqrt(np.mean(
                    (refined[0] * pts[inliers, 0]
                     + refined[1] * pts[inliers, 1]
                     + refined[2]) ** 2
                ))
                if count > best_count or (count == best_count and rms < best_rms):
                    best_count = count
                    best_rms = rms
                    best_line = refined
                    best_inliers = inliers.copy()
            elif count > best_count:
                # fallback
                a0, b0, c0 = a, b, c
                if a0 < 0 or (abs(a0) < 1e-12 and b0 < 0):
                    a0, b0, c0 = -a0, -b0, -c0
                best_line = np.array([a0, b0, c0])
                best_inliers = inliers.copy()
                best_count = count
                best_rms = 0.0

    if best_line is None:
        return fit_line_tls(pts), np.ones(N, dtype=bool), np.inf

    return best_line, best_inliers, best_rms


def fit_line_tls(pts: np.ndarray) -> np.ndarray:
    """Fit a 2-D line with Total Least Squares (orthogonal distance).

    Parameters
    ----------
    pts : (N, 2) array of 2-D points.

    Returns
    -------
    line : (3,)  homogeneous line vector  [a, b, c]  with  a²+b² = 1,
            such that  a·x + b·y + c = 0.
    """
    assert pts.ndim == 2 and pts.shape[1] == 2
    centroid = pts.mean(axis=0)
    U, S, Vt = np.linalg.svd(pts - centroid)
    normal = Vt[-1]                     # smallest singular vector
    a, b = normal
    if a < 0 or (abs(a) < 1e-12 and b < 0):
        a, b = -a, -b                   # sign convention
    c = -(a * centroid[0] + b * centroid[1])
    return np.array([a, b, c])


def estimate_vanishing_point(lines: np.ndarray,
                             weights: Optional[np.ndarray] = None,
                             ) -> VanishingPoint:
    """Robust vanishing point from a pencil of (nearly) parallel lines.

    Minimises  Σ w_i · (l_iᵀ v)²  subject to  ‖v‖ = 1.
    The solution is the right-singular vector for the smallest
    singular value of the weighted line matrix.

    Parameters
    ----------
    lines : (M, 3)
        Each row is a homogeneous line [a, b, c] with a²+b²=1.
    weights : (M,) or None

    Returns
    -------
    VanishingPoint
    """
    M = lines.shape[0]
    if weights is None:
        weights = np.ones(M)
    W = np.diag(np.sqrt(weights))
    L = W @ lines                     # weighted line matrix
    _, _, Vt = np.linalg.svd(L)
    v = Vt[-1]                        # null-space vector

    # Normalise so that the third coordinate is ≈1 when the VP is finite,
    # or ≈0 when it lies at infinity.
    if abs(v[2]) > 1e-6:
        v = v / v[2]
        is_finite = True
    else:
        # vanishing point at infinity — keep homogeneous form
        is_finite = False
    return VanishingPoint(v=v, is_finite=is_finite)


def lines_from_chessboard_corners(corners: np.ndarray,
                                  pattern_size: Tuple[int, int],
                                  use_ransac: bool = True,
                                  ) -> Tuple[List[np.ndarray], List[np.ndarray],
                                             float, float]:
    """Group chessboard corners into row-lines and column-lines.

    Parameters
    ----------
    corners : (M*N, 1, 2) or (M*N, 2)
        Detected inner corners in OpenCV row-major order.
    pattern_size : (cols, rows)
    use_ransac : use RANSAC robust line fitting.

    Returns
    -------
    row_lines, col_lines : lists of (3,) homogeneous line vectors.
    row_quality, col_quality : mean RMS errors (pixels).  Higher values
        indicate non-ideal chessboard or detection problems.
    """
    corners = corners.reshape(-1, 2)
    cols, rows = pattern_size
    n_pts = rows * cols
    if corners.shape[0] != n_pts:
        raise ValueError(
            f"Expected {n_pts} corners ({cols}×{rows}), got {corners.shape[0]}"
        )

    grid = corners.reshape(rows, cols, 2)       # row-major: grid[r][c]

    row_lines = []
    row_errors = []
    for r in range(rows):
        pts = grid[r]                            # (cols, 2)
        if use_ransac:
            line, _, quality = robust_fit_line_ransac(pts)
        else:
            line = fit_line_tls(pts)
            quality = np.sqrt(np.mean(
                (line[0] * pts[:, 0] + line[1] * pts[:, 1] + line[2]) ** 2
            ))
        row_lines.append(line)
        row_errors.append(quality)

    col_lines = []
    col_errors = []
    for c in range(cols):
        pts = grid[:, c]                         # (rows, 2)
        if use_ransac:
            line, _, quality = robust_fit_line_ransac(pts)
        else:
            line = fit_line_tls(pts)
            quality = np.sqrt(np.mean(
                (line[0] * pts[:, 0] + line[1] * pts[:, 1] + line[2]) ** 2
            ))
        col_lines.append(line)
        col_errors.append(quality)

    return row_lines, col_lines, float(np.mean(row_errors)), float(np.mean(col_errors))


# ─────────────────── Distortion Estimation (Straight-Line Constraint) ──

def _undistort_line_residuals(dist_params: np.ndarray,
                               corners_per_face: List[np.ndarray],
                               pattern_sizes: List[Tuple[int, int]],
                               K_approx: np.ndarray,
                               ) -> np.ndarray:
    """Residual vector for distortion optimisation.

    For each chessboard row/column, the undistorted points must be
    collinear.  The residual is the RMS perpendicular distance from
    each point to the fitted line, PLUS a regularisation term to
    prevent the degenerate solution where all undistorted points
    collapse to the principal point.

    Parameters
    ----------
    dist_params : [k1, k2, k3, p1, p2]
    corners_per_face : list of (N, 1, 2) distorted pixel coordinates per face.
    pattern_sizes : list of (cols, rows) per face.
    K_approx : rough intrinsic matrix.

    Returns
    -------
    residuals : (F + 1,) array — per-face line errors + regularisation.
    """
    k1, k2, k3, p1, p2 = dist_params
    D = np.array([k1, k2, p1, p2, k3], dtype=np.float64)
    residuals = []

    for face_corners, (cols, rows) in zip(corners_per_face, pattern_sizes):
        if face_corners.shape[0] == 0:
            continue
        pts_dist = face_corners.reshape(-1, 1, 2).astype(np.float64)

        pts_undist = cv2.undistortPoints(pts_dist, K_approx, D, P=K_approx)
        pts_undist = pts_undist.reshape(-1, 2)

        # Guard against point collapse: if all points are within 1 px,
        # this is degenerate — return a large penalty.
        span = (pts_undist.max(axis=0) - pts_undist.min(axis=0))
        if span[0] < 1.0 or span[1] < 1.0:
            residuals.append(1e6)
            continue

        grid = pts_undist.reshape(rows, cols, 2)

        face_err = 0.0
        n_lines = 0
        for r in range(rows):
            line = fit_line_tls(grid[r])
            err = np.mean(np.abs(
                line[0] * grid[r][:, 0] + line[1] * grid[r][:, 1]
                + line[2]
            ))
            face_err += err
            n_lines += 1
        for c in range(cols):
            line = fit_line_tls(grid[:, c])
            err = np.mean(np.abs(
                line[0] * grid[:, c][:, 0] + line[1] * grid[:, c][:, 1]
                + line[2]
            ))
            face_err += err
            n_lines += 1
        residuals.append(face_err / max(n_lines, 1))

    # Regularisation: penalise extreme distortion (Tikhonov)
    reg = 1e-3 * (k1**2 + k2**2 + 0.1*k3**2 + p1**2 + p2**2)
    residuals.append(reg)

    return np.array(residuals)


def estimate_distortion_from_lines(
    detected_faces: list,
    faces: list,
    K_approx: np.ndarray,
    max_k1: float = 0.8,
    max_k2: float = 0.3,
    verbose: bool = True,
) -> np.ndarray:
    """Estimate distortion from point-level checker straightness residuals."""
    corners_per_face = [df.image_points for df in detected_faces
                        if df.valid and df.image_points.shape[0] > 0]
    pattern_sizes = [faces[i].pattern_size
                     for i, df in enumerate(detected_faces) if df.valid]
    if not corners_per_face:
        if verbose:
            print("  No valid faces for distortion estimation; using zeros.")
        return np.zeros(5, dtype=np.float64)
    result = estimate_checker_plumbline_distortion(
        corners_per_face,
        pattern_sizes,
        K_approx,
        allow_high_order=True,
        max_k1=max_k1,
        max_k2=max_k2,
    )
    if verbose:
        status = "accepted" if result.success else "kept zero"
        print(
            f"  Point-level plumb-line model {result.model} ({status}): "
            f"{result.raw_rms_px:.4f} -> {result.undistorted_rms_px:.4f} px, "
            f"r2 span={result.radial_r2_span:.5f}"
        )
    return result.dist.copy()


# ──────────────────────── IAC Intrinsic Calibration ─────────────────────

def vanishing_constraints_to_omega(V: List[np.ndarray],
                                   ortho_pairs: List[Tuple[int, int]],
                                   ) -> np.ndarray:
    """Build the linear system  A · ω_vec = 0  from orthogonal VP pairs.

    Each pair (i, j) gives  V_iᵀ ω V_j = 0, which is a linear equation in
    the 6 unique entries of ω.

    Parameters
    ----------
    V : list of (3,) homogeneous vanishing points.
    ortho_pairs : list of (i, j) index pairs that are orthogonal.

    Returns
    -------
    A : (K, 6) matrix.
    """
    K = len(ortho_pairs)
    A = np.zeros((K, 6))
    for k, (i, j) in enumerate(ortho_pairs):
        vi, vj = V[i], V[j]
        # ω₁₁·vi₀·vj₀ + ω₁₂·(vi₀·vj₁+vi₁·vj₀) + ω₁₃·(vi₀·vj₂+vi₂·vj₀)
        # + ω₂₂·vi₁·vj₁ + ω₂₃·(vi₁·vj₂+vi₂·vj₁) + ω₃₃·vi₂·vj₂ = 0
        A[k] = [
            vi[0] * vj[0],                               # ω₁₁
            vi[0] * vj[1] + vi[1] * vj[0],               # ω₁₂
            vi[0] * vj[2] + vi[2] * vj[0],               # ω₁₃
            vi[1] * vj[1],                               # ω₂₂
            vi[1] * vj[2] + vi[2] * vj[1],               # ω₂₃
            vi[2] * vj[2],                               # ω₃₃
        ]
    return A


def omega_to_K(omega: np.ndarray) -> np.ndarray:
    """Extract intrinsic matrix K from ω = K^{-T} K^{-1} via Cholesky.

    K is normalised so that K[2, 2] = 1.
    """
    # Ensure ω is symmetric positive-definite (clip negative eigenvalues)
    w = (omega + omega.T) / 2
    eigvals, eigvecs = np.linalg.eigh(w)
    eigvals = np.clip(eigvals, 1e-12, None)
    w = eigvecs @ np.diag(eigvals) @ eigvecs.T

    # Cholesky:  ω = L Lᵀ,  then  K⁻¹ = Lᵀ (upper triangular).
    L = cholesky(w, lower=True)
    K_inv = L.T
    K = np.linalg.inv(K_inv)
    K = K / K[2, 2]
    return K


def calibrate_intrinsics_from_vps(
    vanishing_points: List[VanishingPoint],
    ortho_pairs: List[Tuple[int, int]],
    assume_zero_skew: bool = True,
    assume_square_pixels: bool = True,
    fix_principal_point: Optional[Tuple[float, float]] = None,
) -> np.ndarray:
    """Solve for K from orthogonal vanishing-point constraints.

    **Critical note on degrees of freedom:**
    With only 3 vanishing points, we have 3 orthogonality constraints
    (V_iᵀ ω V_j = 0).  The IAC ω has:
      - 6 DoF  (general)       →  rank ≤ 3  →  underdetermined
      - 5 DoF  (zero skew)     →  rank ≤ 3  →  underdetermined
      - 4 DoF  (skew + f_x=f_y)→  rank ≤ 3  →  underdetermined
      - 2 DoF  (also fix cx,cy)→  rank ≤ 3  →  overdetermined ✓

    Therefore the IAC step alone cannot uniquely determine K from three
    vanishing points without a prior on the principal point.  Setting
    ``fix_principal_point`` to the image centre is recommended for the
    initialisation; the subsequent bundle adjustment recovers the true
    principal point.

    Parameters
    ----------
    vanishing_points : list of VanishingPoint
    ortho_pairs : list of (i, j)
    assume_zero_skew : bool
    assume_square_pixels : bool
    fix_principal_point : (cx, cy) or None
        If provided, cx and cy are treated as known, leaving only the
        focal length(s) as unknowns.

    Returns
    -------
    K : (3, 3) intrinsic matrix.
    """
    V_hom = [vp.v for vp in vanishing_points]
    A6 = vanishing_constraints_to_omega(V_hom, ortho_pairs)

    # With fix_principal_point we express ω entries in terms of the
    # unknowns, using the relations:
    #   ω₁₃ = -cx · ω₁₁        (since ω₁₃ = -cx/fx², ω₁₁ = 1/fx²)
    #   ω₂₃ = -cy · ω₂₂
    #   ω₃₃ = cx²·ω₁₁ + cy²·ω₂₂ + 1
    # When also square_pixels: ω₂₂ = ω₁₁, reducing to ONE unknown.
    if fix_principal_point is not None:
        cx, cy = fix_principal_point
        # Model: unknowns = [ω₁₁, ω₂₂]  (or just [ω₁₁] if square pixels)
        # ω₁₃ = -cx·ω₁₁,  ω₂₃ = -cy·ω₂₂,  ω₃₃ = cx²·ω₁₁ + cy²·ω₂₂ + 1
        # The homogeneous equation  A6·ω_vec = 0  becomes
        # A6·[ω₁₁, 0, -cx·ω₁₁, ω₂₂, -cy·ω₂₂, cx²·ω₁₁+cy²·ω₂₂+1]ᵀ = 0
        # Separate known (constant) and unknown parts:
        #   B·[ω₁₁, ω₂₂]ᵀ = -A6[:,5]  (the constant from ω₃₃ = ... + 1)
        if assume_square_pixels:
            # single unknown a = ω₁₁ = ω₂₂
            # ω_vec = [a, 0, -cx·a, a, -cy·a, (cx²+cy²)·a + 1]
            # A6 @ ω_vec = a·(A6[:,0] - cx·A6[:,2] + A6[:,3] - cy·A6[:,4]
            #                  + (cx²+cy²)·A6[:,5]) + A6[:,5] = 0
            coeff = (A6[:, 0] - cx * A6[:, 2] + A6[:, 3]
                     - cy * A6[:, 4] + (cx**2 + cy**2) * A6[:, 5])
            rhs = -A6[:, 5]
            a = np.linalg.lstsq(coeff.reshape(-1, 1), rhs, rcond=None)[0][0]
            a = max(a, 1e-8)

            omega = np.zeros((3, 3))
            omega[0, 0] = a
            omega[1, 1] = a
            omega[0, 2] = omega[2, 0] = -cx * a
            omega[1, 2] = omega[2, 1] = -cy * a
            omega[2, 2] = (cx**2 + cy**2) * a + 1
        else:
            # 2 unknowns: a=ω₁₁, b=ω₂₂
            # ω_vec = [a, 0, -cx·a, b, -cy·b, cx²·a + cy²·b + 1]
            B = np.zeros((A6.shape[0], 2))
            B[:, 0] = A6[:, 0] - cx * A6[:, 2] + cx**2 * A6[:, 5]
            B[:, 1] = A6[:, 3] - cy * A6[:, 4] + cy**2 * A6[:, 5]
            rhs = -A6[:, 5]
            ab = np.linalg.lstsq(B, rhs, rcond=None)[0]
            a, b = max(ab[0], 1e-8), max(ab[1], 1e-8)

            omega = np.zeros((3, 3))
            omega[0, 0] = a
            omega[1, 1] = b
            omega[0, 2] = omega[2, 0] = -cx * a
            omega[1, 2] = omega[2, 1] = -cy * b
            omega[2, 2] = cx**2 * a + cy**2 * b + 1

        return omega_to_K(omega)

    # ── Path without fix_principal_point (underdetermined in general) ──
    if assume_square_pixels:
        A = np.zeros((A6.shape[0], 4))
        A[:, 0] = A6[:, 0] + A6[:, 3]   # ω₁₁ = ω₂₂
        A[:, 1] = A6[:, 2]              # ω₁₃
        A[:, 2] = A6[:, 4]              # ω₂₃
        A[:, 3] = A6[:, 5]              # ω₃₃
    elif assume_zero_skew:
        A = A6[:, [0, 2, 3, 4, 5]]
    else:
        A = A6

    _, _, Vt = np.linalg.svd(A)
    x = Vt[-1]

    omega = np.zeros((3, 3))
    if assume_square_pixels:
        a, d, e, f = x
        omega[0, 0] = a
        omega[1, 1] = a
        omega[0, 2] = omega[2, 0] = d
        omega[1, 2] = omega[2, 1] = e
        omega[2, 2] = f
    elif assume_zero_skew:
        omega[0, 0], omega[0, 2], omega[1, 1], omega[1, 2], omega[2, 2] = x
        omega[2, 0] = omega[0, 2]
        omega[2, 1] = omega[1, 2]
    else:
        omega[0, 0], omega[0, 1], omega[0, 2], \
            omega[1, 1], omega[1, 2], omega[2, 2] = x
        omega[1, 0] = omega[0, 1]
        omega[2, 0] = omega[0, 2]
        omega[2, 1] = omega[1, 2]

    return omega_to_K(omega)


# ──────────────────────── Extrinsic Calibration (PnP) ──────────────────

def calibrate_extrinsics(object_points: np.ndarray,
                         image_points: np.ndarray,
                         K: np.ndarray,
                         dist: Optional[np.ndarray] = None,
                         ) -> Tuple[np.ndarray, np.ndarray]:
    """Solve for camera extrinsics (R, t) using PnP.

    All detected faces are pooled into a single PnP problem in the
    world coordinate frame.

    Returns (R, t) such that  X_cam = R @ X_world + t.
    """
    if dist is None:
        dist = np.zeros(5, dtype=np.float32)

    object_pts = object_points.reshape(-1, 3).astype(np.float32)
    image_pts = image_points.reshape(-1, 2).astype(np.float32)

    ok, rvec, tvec = cv2.solvePnP(
        object_pts, image_pts, K, dist,
        flags=cv2.SOLVEPNP_ITERATIVE,
    )
    if not ok:
        raise RuntimeError("PnP failed to converge")
    R, _ = cv2.Rodrigues(rvec)
    return R, tvec.ravel()


# ──────────────────── Corner Sharpness / Blur Detection ────────────────

def compute_corner_sharpness(gray: np.ndarray,
                              corners: np.ndarray,
                              window_size: int = 15,
                              ) -> np.ndarray:
    """Compute per-corner sharpness weights using gradient magnitude.

    Uses Tenengrad (mean squared gradient magnitude) in a local window
    around each corner.  Blurry corners have low gradient energy → low
    weight.  Sharp corners have high gradient energy → high weight.

    Parameters
    ----------
    gray : (H, W) uint8 grayscale image.
    corners : (N, 1, 2) float32 corner positions.
    window_size : local patch size for sharpness evaluation.

    Returns
    -------
    weights : (N,) float64 array in [0.05, 1.0].
    """
    # Sobel gradient magnitude
    gx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    grad_mag = gx * gx + gy * gy  # squared gradient, avoid sqrt for speed
    h_img, w_img = gray.shape[:2]
    half = window_size // 2
    scores = []
    for pt in corners.reshape(-1, 2):
        x, y = int(round(pt[0])), int(round(pt[1]))
        y0, y1 = max(0, y - half), min(h_img, y + half + 1)
        x0, x1 = max(0, x - half), min(w_img, x + half + 1)
        patch = grad_mag[y0:y1, x0:x1]
        scores.append(float(patch.mean()))
    w = np.array(scores, dtype=np.float64)
    if w.max() > w.min() + 1e-12:
        w = 0.05 + 0.95 * (w - w.min()) / (w.max() - w.min())
    else:
        w = np.ones_like(w)
    return w


# ──────────────────────── Bundle Adjustment ────────────────────────────

def _params_to_components(params: np.ndarray,
                          n_points: int,
                          with_distortion: bool,
                          full_distortion: bool = False,
                          ) -> Tuple[np.ndarray, np.ndarray,
                                     np.ndarray, np.ndarray, np.ndarray]:
    """Unpack the optimisation vector.

    Parameter order:
      [fx, fy, cx, cy] + optionally [k1,k2,k3,p1,p2] + [rx,ry,rz,tx,ty,tz]
    """
    fx, fy, cx, cy = params[0:4]
    if with_distortion:
        if full_distortion:
            k1, k2, k3, p1, p2 = params[4:9]
            offset = 9
        else:
            k1, k2, k3, p1, p2 = params[4], params[5], 0.0, 0.0, 0.0
            offset = 6
    else:
        k1, k2, k3, p1, p2 = 0.0, 0.0, 0.0, 0.0, 0.0
        offset = 4

    rvec = params[offset:offset + 3]
    tvec = params[offset + 3:offset + 6]
    K = np.array([[fx, 0, cx],
                  [0, fy, cy],
                  [0, 0, 1]], dtype=np.float64)
    dist = np.array([k1, k2, p1, p2, k3], dtype=np.float64)
    R, _ = cv2.Rodrigues(rvec)
    return K, dist, R, tvec.ravel(), rvec


def _reprojection_residuals(params: np.ndarray,
                            object_points: np.ndarray,
                            image_points: np.ndarray,
                            with_distortion: bool,
                            full_distortion: bool = False,
                            weights: Optional[np.ndarray] = None,
                            ) -> np.ndarray:
    """Residual vector for scipy least_squares.

    Uses the OpenCV 5-parameter model: k1, k2, p1, p2, k3.

    If ``weights`` is provided, each point's residual is multiplied
    by its weight (blurry corners → lower weight → less influence).
    """
    N = object_points.shape[0]
    K, dist_coeffs, R, t, _ = _params_to_components(
        params, N, with_distortion, full_distortion
    )

    X_cam = (R @ object_points.reshape(N, 3).T + t.reshape(3, 1)).T
    x = X_cam[:, 0] / X_cam[:, 2]
    y = X_cam[:, 1] / X_cam[:, 2]

    if with_distortion:
        r2 = x ** 2 + y ** 2
        r4 = r2 ** 2
        r6 = r2 ** 3
        k1, k2, p1, p2, k3 = dist_coeffs
        radial = 1 + k1 * r2 + k2 * r4 + k3 * r6
        x_dist = x * radial + 2 * p1 * x * y + p2 * (r2 + 2 * x ** 2)
        y_dist = y * radial + p1 * (r2 + 2 * y ** 2) + 2 * p2 * x * y
    else:
        x_dist, y_dist = x, y

    u = K[0, 0] * x_dist + K[0, 2]
    v = K[1, 1] * y_dist + K[1, 2]

    pts_det = image_points.reshape(N, 2)
    residuals = np.hstack([u - pts_det[:, 0], v - pts_det[:, 1]])
    if weights is not None:
        residuals[:N] *= weights
        residuals[N:] *= weights
    return residuals


def bundle_adjust(K_init: np.ndarray,
                  R_init: np.ndarray,
                  t_init: np.ndarray,
                  object_points: np.ndarray,
                  image_points: np.ndarray,
                  dist_init: Optional[np.ndarray] = None,
                  with_distortion: bool = False,
                  full_distortion: bool = False,
                  fix_distortion: bool = False,
                  k2_reg_weight: float = 0.0,
                  weights: Optional[np.ndarray] = None,
                  ) -> Tuple[np.ndarray, np.ndarray,
                             np.ndarray, np.ndarray, float]:
    """Joint non-linear refinement of intrinsics + extrinsics.

    Parameters
    ----------
    K_init, R_init, t_init : initial estimates.
    dist_init : (5,) initial distortion [k1,k2,p1,p2,k3] or None.
    object_points : (N, 3), image_points : (N, 2).
    with_distortion : include at least k1, k2.
    full_distortion : include k3, p1, p2 as well.
    fix_distortion : if True, keep distortion fixed at dist_init.
    k2_reg_weight : if > 0, penalise large |k2/k1| ratio to prevent
        k2 overfitting (recommended: 0.01–0.1 for consumer lenses).

    Returns
    -------
    K, dist, R, t, rmse
    """
    N = object_points.shape[0]
    rvec_init, _ = cv2.Rodrigues(R_init)
    rvec_init = rvec_init.ravel()

    x0 = [K_init[0, 0], K_init[1, 1],
          K_init[0, 2], K_init[1, 2]]

    if with_distortion:
        if dist_init is not None and len(dist_init) >= 5:
            x0 += dist_init[:5].tolist()
        elif dist_init is not None and len(dist_init) >= 2:
            x0 += [dist_init[0], dist_init[1], 0.0, 0.0, 0.0]
        else:
            x0 += [0.0, 0.0, 0.0, 0.0, 0.0]
    x0 += rvec_init.tolist() + t_init.ravel().tolist()
    x0 = np.array(x0, dtype=np.float64)

    extra_args = (weights,) if weights is not None else ()

    # If fixing distortion, we mask the distortion params in the residual
    # by not including them in the parameter vector.
    # For simplicity, we run the full optimisation but freeze distortion
    # via the bounds / or by a wrapper.
    if fix_distortion and with_distortion:
        # Use a wrapper that fixes dist params
        dist_fixed = np.array(x0[4:9], copy=True)

        def _residuals_fixed_dist(params, obj_pts, img_pts, _dist, _w=None):
            full_params = np.concatenate([
                params[:4], _dist, params[4:]
            ])
            return _reprojection_residuals(
                full_params, obj_pts, img_pts, True, full_distortion, _w,
            )

        x0_reduced = np.concatenate([x0[:4], x0[9:]])
        result = least_squares(
            _residuals_fixed_dist,
            x0_reduced,
            method='lm',
            args=(object_points, image_points, dist_fixed) + extra_args,
            xtol=1e-12, ftol=1e-12,
        )
        x_final = np.concatenate([result.x[:4], dist_fixed, result.x[4:]])
    else:
        # Wrap residuals with optional k2 regularisation
        if k2_reg_weight > 0 and with_distortion:
            def _wrapped_residuals(params, obj_pts, img_pts, wdist, fdist, _w=None):
                base = _reprojection_residuals(
                    params, obj_pts, img_pts, wdist, fdist, _w)
                k1 = params[4]
                k2 = params[5]
                k2_penalty = k2_reg_weight * (k2 / max(abs(k1), 1e-6)) * np.ones(1)
                return np.concatenate([base, k2_penalty])

            result = least_squares(
                _wrapped_residuals,
                x0,
                method='lm',
                args=(object_points, image_points, with_distortion,
                      full_distortion) + extra_args,
                xtol=1e-12, ftol=1e-12,
            )
        else:
            result = least_squares(
                _reprojection_residuals,
                x0,
                method='lm',
                args=(object_points, image_points, with_distortion,
                      full_distortion) + extra_args,
                xtol=1e-12, ftol=1e-12,
            )
        x_final = result.x

    K_opt, dist_opt, R_opt, t_opt, _ = _params_to_components(
        x_final, N, with_distortion, full_distortion
    )
    rmse = float(np.sqrt(np.mean(
        _reprojection_residuals(x_final, object_points, image_points,
                                with_distortion, full_distortion, weights) ** 2
    )))
    return K_opt, dist_opt, R_opt, t_opt, rmse


# ──────────────────────── Target Geometry Builders ─────────────────────

def build_corner_cube_target(faces: List[FaceDefinition],
                             ) -> Tuple[np.ndarray, np.ndarray]:
    """Build the combined object-points array for all faces.

    Returns (obj_pts, img_pts_placeholder).
    img_pts_placeholder has the same shape as obj_pts for later filling.
    """
    all_obj = []
    for face in faces:
        all_obj.append(object_points_for_face(face).reshape(-1, 3))
    obj = np.vstack(all_obj).reshape(-1, 1, 3)
    return obj


def object_points_for_face(face: FaceDefinition,
                           flip_x: bool = False,
                           flip_y: bool = False,
                           ) -> np.ndarray:
    """Build object points for one face, with optional local-axis flips.

    OpenCV orders chessboard corners from the image, not from the physical
    cube corner.  flip_x/flip_y let the same detected grid be mapped to the
    opposite physical direction while preserving row-major image order.
    """
    cols, rows = face.pattern_size
    ss = face.square_size
    pts = []
    for r in range(rows):
        rr = rows - 1 - r if flip_y else r
        for c in range(cols):
            cc = cols - 1 - c if flip_x else c
            p = (face.origin_3d
                 + cc * ss * face.axis_x
                 + rr * ss * face.axis_y)
            pts.append(p)
    return np.array(pts, dtype=np.float32).reshape(-1, 1, 3)


def apply_best_face_orientations(detected_faces: List[DetectedFace],
                                 faces: List[FaceDefinition],
                                 valid_idx: List[int],
                                 K: np.ndarray,
                                 dist: Optional[np.ndarray] = None,
                                 ) -> List[dict]:
    """Choose per-face x/y flips by minimizing pooled PnP reprojection RMSE."""
    if not valid_idx:
        return []
    if dist is None:
        dist = np.zeros(5, dtype=np.float64)
    dist = np.asarray(dist, dtype=np.float64).reshape(-1)

    candidate_sets = []
    for fi in valid_idx:
        opts = []
        for flip_x in (False, True):
            for flip_y in (False, True):
                opts.append((fi, flip_x, flip_y,
                             object_points_for_face(faces[fi], flip_x, flip_y)))
        candidate_sets.append(opts)

    all_img = np.vstack([
        detected_faces[i].image_points.reshape(-1, 2) for i in valid_idx
    ]).astype(np.float32)
    if all_img.shape[0] < 6:
        return []

    best_combo = None
    best_rmse = float("inf")
    K64 = np.asarray(K, dtype=np.float64)

    for combo in itertools.product(*candidate_sets):
        obj = np.vstack([entry[3].reshape(-1, 3) for entry in combo]).astype(np.float32)
        try:
            ok, rvec, tvec = cv2.solvePnP(
                obj, all_img, K64, dist, flags=cv2.SOLVEPNP_ITERATIVE,
            )
        except cv2.error:
            continue
        if not ok:
            continue
        proj, _ = cv2.projectPoints(
            obj.reshape(-1, 1, 3).astype(np.float64),
            rvec, tvec, K64, dist,
        )
        diff = proj.reshape(-1, 2) - all_img.reshape(-1, 2)
        rmse = float(np.sqrt(np.mean(np.sum(diff * diff, axis=1))))
        if rmse < best_rmse:
            best_rmse = rmse
            best_combo = combo

    if best_combo is None:
        return []

    chosen = []
    for fi, flip_x, flip_y, obj_pts in best_combo:
        detected_faces[fi].object_points = obj_pts
        chosen.append({
            "face": int(fi),
            "flip_x": bool(flip_x),
            "flip_y": bool(flip_y),
            "rmse": float(best_rmse),
        })
    return chosen


def standard_three_face_target(square_size: float = 30.0,
                               cols: int = 9,
                               rows: int = 6,
                               face_patterns: Optional[List[Tuple[int, int]]] = None,
                               n_faces: int = 3,
                               center_patterns_on_cube: bool = False,
                               ) -> List[FaceDefinition]:
    """Create the standard corner-cube target definition.

    World frame:
      - Origin at the corner where the faces meet.
      - Face A:  XY plane (z=0),  columns ∥ X,  rows ∥ Y   ("top")
      - Face B:  XZ plane (y=0),  columns ∥ X,  rows ∥ Z   ("side-1")
      - Face C:  YZ plane (x=0),  columns ∥ Y,  rows ∥ Z   ("side-2")

    Parameters
    ----------
    square_size : square side length in mm.
    cols, rows : default inner corner counts (used when face_patterns is None).
    face_patterns : optional list of (cols, rows) tuples, one per face.
        Must have n_faces entries if provided.
    n_faces : number of faces to build (1, 2, or 3).  Default 3.
    center_patterns_on_cube : if True, infer per-axis offsets by centering each
        full checkerboard square area on an inferred square cube face.  The
        inferred face side is the largest outer checkerboard square count, so
        square_size is the only physical scale input.
    """
    if face_patterns is not None:
        if len(face_patterns) != n_faces:
            raise ValueError(
                f"face_patterns has {len(face_patterns)} entries "
                f"but n_faces={n_faces}"
            )
        patterns = face_patterns
    else:
        patterns = [(cols, rows)] * n_faces

    if center_patterns_on_cube:
        max_outer_squares = max(max(c + 1, r + 1) for c, r in patterns)
        inferred_face_side = max_outer_squares * square_size
        offsets = []
        for c, r in patterns:
            board_w = (c + 1) * square_size
            board_h = (r + 1) * square_size
            offsets.append((
                0.5 * (inferred_face_side - board_w) + square_size,
                0.5 * (inferred_face_side - board_h) + square_size,
            ))
    else:
        offsets = [(0.0, 0.0)] * n_faces

    ex = np.array([1., 0., 0.])
    ey = np.array([0., 1., 0.])
    ez = np.array([0., 0., 1.])

    def _pat(i):
        return patterns[i] if i < len(patterns) else patterns[0]

    def _origin(i, axis_x, axis_y):
        ox, oy = offsets[i] if i < len(offsets) else offsets[0]
        return ox * axis_x + oy * axis_y

    all_faces = [
        FaceDefinition(pattern_size=_pat(0), square_size=square_size,
                       axis_x=ex, axis_y=ey, origin_3d=_origin(0, ex, ey)),
        FaceDefinition(pattern_size=_pat(1),
                       square_size=square_size, axis_x=ex, axis_y=ez,
                       origin_3d=_origin(1, ex, ez)),
        FaceDefinition(pattern_size=_pat(2),
                       square_size=square_size, axis_x=ey, axis_y=ez,
                       origin_3d=_origin(2, ey, ez)),
    ]
    return all_faces[:n_faces]


# ──────────────────────── Synthetic Data Generator ─────────────────────

def generate_synthetic_data(K: np.ndarray,
                            R: np.ndarray,
                            t: np.ndarray,
                            faces: List[FaceDefinition],
                            noise_std: float = 0.0,
                            image_size: Tuple[int, int] = (1920, 1080),
                            dist: Optional[np.ndarray] = None,
                            ) -> Tuple[List[DetectedFace], np.ndarray,
                                       np.ndarray, np.ndarray]:
    """Generate synthetic image points by projecting the 3-D target.

    Returns
    -------
    detected_faces : list of DetectedFace with (noisy) image points.
    all_obj_pts, all_img_pts, all_img_pts_noiseless : stacked arrays
    """
    if dist is None:
        dist = np.zeros(5)

    detected = []
    for face in faces:
        obj_pts = []
        cols, rows = face.pattern_size
        ss = face.square_size
        for r in range(rows):
            for c in range(cols):
                p = (face.origin_3d
                     + c * ss * face.axis_x
                     + r * ss * face.axis_y)
                obj_pts.append(p)
        obj_pts = np.array(obj_pts, dtype=np.float32).reshape(-1, 1, 3)

        # Project
        img_pts, _ = cv2.projectPoints(obj_pts, cv2.Rodrigues(R)[0], t,
                                       K, dist)
        img_pts_clean = img_pts.copy()
        if noise_std > 0:
            img_pts += np.random.randn(*img_pts.shape) * noise_std

        detected.append(DetectedFace(
            image_points=img_pts,
            object_points=obj_pts,
        ))

    all_obj = np.vstack([d.object_points for d in detected])
    all_img = np.vstack([d.image_points for d in detected])
    all_img_clean = np.vstack([
        cv2.projectPoints(d.object_points, cv2.Rodrigues(R)[0], t, K, dist)[0]
        for d in detected
    ])
    return detected, all_obj, all_img, all_img_clean


# ──────────────────────── Main Calibration Pipeline ─────────────────────

def calibrate_single_image(
    detected_faces: List[DetectedFace],
    vp_labels: Optional[List[List[str]]] = None,
    assume_square_pixels: bool = False,
    with_distortion: bool = False,
    verbose: bool = True,
) -> CalibrationResult:
    """Run the full single-image calibration pipeline.

    Parameters
    ----------
    detected_faces : list of DetectedFace
        One entry per visible face.  Must cover all three orthogonal
        directions (X, Y, Z).
    vp_labels : optional list of [label_col, label_row] per face.
        E.g. [["X","Y"], ["X","Z"], ["Y","Z"]] for the standard target.
        If None, auto-assign based on face order.
    assume_square_pixels : bool
    with_distortion : bool
        Include k1, k2 radial distortion in the bundle adjustment.
    verbose : bool

    Returns
    -------
    CalibrationResult
    """
    if vp_labels is None:
        vp_labels = get_vp_labels(len(faces))

    # ── Step 1: Estimate vanishing points from each face ────────────
    if verbose:
        print("=" * 60)
        print("Step 1: Vanishing-point estimation")
        print("=" * 60)

    # We collect all vanishing points, keyed by direction label
    vp_collections: dict = {"X": [], "Y": [], "Z": []}

    for fi, face in enumerate(detected_faces):
        if not face.valid:
            continue
        cols, rows = detected_faces[fi].object_points.shape[0], 1
        # Infer pattern size from the object points
        # The object points are in row-major order: r=0..rows-1, c=0..cols-1
        # Pattern size is embedded in the face definition – we re-derive it
        # from the object-point coordinates.
        # Actually, let's get pattern size from the original face def.
        # But we don't have it here.  We'll pass it through or infer it.

        # For now, extract row-lines and col-lines from the image points
        # We need pattern size.  Since we don't have it directly in
        # DetectedFace, we'll detect it from the corners.
        # The corners are in OpenCV order: row 0 all cols, row 1 all cols, ...

        n_pts = face.image_points.shape[0]
        # Assume we know the pattern – for real usage this comes from config
        # Here we use a heuristic: find the grid dimensions by looking at
        # the sorted x,y values.
        pts = face.image_points.reshape(-1, 2)
        # Sort by y, then x within each row
        # Use the FaceDefinition that was passed – we'll handle this
        # in the top-level calibrate() wrapper instead.
        raise NotImplementedError(
            "Pattern size not available in DetectedFace. "
            "Use calibrate() which accepts FaceDefinitions."
        )


def calibrate(
    image_path_or_array,
    faces: List[FaceDefinition],
    assume_square_pixels: bool = True,
    estimate_distortion: bool = True,
    full_distortion: bool = False,
    preprocess: bool = True,
    vp_labels: Optional[List[List[str]]] = None,
    verbose: bool = True,
) -> CalibrationResult:
    """High-level entry point: image → calibration result.

    Robust pipeline addressing three practical issues:
      1.  Uneven lighting  → CLAHE preprocessing + retry
      2.  Lens distortion   → straight-line constraint estimation
      3.  Non-ideal boards  → RANSAC line fitting + quality warnings

    Parameters
    ----------
    image_path_or_array : str or (H,W,3) ndarray
    faces : list of FaceDefinition
    assume_square_pixels : use f_x = f_y assumption for IAC step.
    estimate_distortion : run straight-line-based distortion estimation.
    full_distortion : include k3, p1, p2 in BA (not just k1, k2).
    preprocess : apply CLAHE contrast enhancement.
    vp_labels : optional per-face [col_label, row_label]
    verbose : bool

    Returns
    -------
    CalibrationResult
    """
    # Load image
    if isinstance(image_path_or_array, str):
        img = cv2.imread(image_path_or_array)
        if img is None:
            raise FileNotFoundError(f"Cannot read {image_path_or_array}")
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        img = image_path_or_array
        if img.ndim == 3:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        else:
            gray = img

    h_img, w_img = gray.shape[:2]

    if vp_labels is None:
        vp_labels = get_vp_labels(len(faces))

    # ── Step 0: Preprocess (CLAHE) ──────────────────────────────────
    if preprocess:
        gray_enhanced = preprocess_image(gray)
        images_to_try = [("enhanced", gray_enhanced), ("original", gray)]
    else:
        images_to_try = [("original", gray)]

    # ── Step 1: Detect chessboard corners (with retry) ──────────────
    if verbose:
        print("=" * 60)
        print("Step 1: Corner detection")
        print("=" * 60)

    detected_faces: List[DetectedFace] = []
    for fi, face in enumerate(faces):
        cols, rows = face.pattern_size
        best_corners = None
        best_src = ""
        for src_name, src_img in images_to_try:
            ok, corners = cv2.findChessboardCorners(
                src_img, (cols, rows),
                flags=cv2.CALIB_CB_ADAPTIVE_THRESH
                       + cv2.CALIB_CB_NORMALIZE_IMAGE,
            )
            if ok:
                best_corners = corners
                best_src = src_name
                break

        if best_corners is None:
            if verbose:
                print(f"  Face {fi}: NOT FOUND  (pattern {cols}×{rows})"
                      f"  ⚠ poorly lit or occluded")
            detected_faces.append(DetectedFace(
                image_points=np.zeros((0, 1, 2)),
                object_points=np.zeros((0, 1, 3)),
                valid=False,
            ))
            continue

        # Sub-pixel refinement on the image where detection succeeded
        ref_img = gray_enhanced if best_src == "enhanced" else gray
        # Improved sub-pixel refinement: larger window, more iterations,
        # stricter epsilon for 0.05-0.1 px accuracy on well-focused images.
        corners_sub = cv2.cornerSubPix(
            ref_img, best_corners, (11, 11), (-1, -1),
            (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-6),
        )

        # Build object points
        obj_pts = []
        ss = face.square_size
        for r in range(rows):
            for c in range(cols):
                p = (face.origin_3d
                     + c * ss * face.axis_x
                     + r * ss * face.axis_y)
                obj_pts.append(p)
        obj_pts = np.array(obj_pts, dtype=np.float32).reshape(-1, 1, 3)

        if verbose:
            status = f" ({best_src})" if best_src != "original" else ""
            print(f"  Face {fi}: {cols}×{rows} → "
                  f"{len(corners_sub)} corners OK{status}")

        detected_faces.append(DetectedFace(
            image_points=corners_sub,
            object_points=obj_pts,
            valid=True,
        ))

    valid_idx = [i for i, df in enumerate(detected_faces) if df.valid]
    n_valid = len(valid_idx)

    if n_valid < 1:
        raise RuntimeError(
            f"No faces detected.  "
            f"Check lighting and target placement."
        )
    if n_valid < 3 and verbose:
        missing = set(['X', 'Y', 'Z']) - set().union(
              *(set(vp_labels[i]) for i in valid_idx))
        print(f"\n  ⚠ Only {n_valid}/3 faces detected — "
              f"missing direction: {missing}")

    # ── Step 2: Vanishing points (with RANSAC lines) ────────────────
    if verbose:
        print()
        print("=" * 60)
        print("Step 2: Vanishing-point estimation (RANSAC lines)")
        print("=" * 60)

    vp_per_face: List[dict] = []
    face_quality_warnings = []
    for fi, df in enumerate(detected_faces):
        if not df.valid:
            vp_per_face.append({})
            continue
        face = faces[fi]
        cols, rows = face.pattern_size
        row_lines, col_lines, row_q, col_q = lines_from_chessboard_corners(
            df.image_points, (cols, rows), use_ransac=True,
        )

        if max(row_q, col_q) > 1.0:
            face_quality_warnings.append(
                f"Face {fi}: line-fit RMS row={row_q:.2f} col={col_q:.2f} px"
                f" — possible non-ideal chessboard"
            )

        vp_col = estimate_vanishing_point(np.array(col_lines))
        vp_row = estimate_vanishing_point(np.array(row_lines))

        col_label = vp_labels[fi][0]
        row_label = vp_labels[fi][1]
        vp_col.direction_label = col_label
        vp_row.direction_label = row_label

        vp_per_face.append({col_label: vp_col, row_label: vp_row})
        if verbose:
            print(f"  Face {fi}: V_{col_label} = ({vp_col.v[0]:.1f}, "
                  f"{vp_col.v[1]:.1f}, {vp_col.v[2]:.3f})  "
                  f"V_{row_label} = ({vp_row.v[0]:.1f}, "
                  f"{vp_row.v[1]:.1f}, {vp_row.v[2]:.3f})")

    if face_quality_warnings and verbose:
        print()
        for w in face_quality_warnings:
            print(f"  ⚠ {w}")

    # ── Step 3: Vanishing points → IAC (get K_init first) ─────────
    if verbose:
        print()
        print("=" * 60)
        print("Step 3: Intrinsic calibration (IAC)")
        print("=" * 60)

    vp_by_dir: dict = {"X": [], "Y": [], "Z": []}
    for fv in vp_per_face:
        for label, vp in fv.items():
            vp_by_dir[label].append(vp)

    vp_avg: dict = {}
    for label in ["X", "Y", "Z"]:
        vlist = vp_by_dir[label]
        if not vlist:
            continue
        V_stack = np.array([vp.v for vp in vlist])
        v_med = np.median(V_stack, axis=0)
        if abs(v_med[2]) > 1e-6:
            v_med = v_med / v_med[2]
        vp_avg[label] = VanishingPoint(v=v_med, direction_label=label)
        if verbose:
            print(f"  V_{label} = ({v_med[0]:.2f}, {v_med[1]:.2f}, "
                  f"{v_med[2]:.4f})")

    labels_ordered = sorted(vp_avg.keys())
    vp_list = [vp_avg[l] for l in labels_ordered]
    label_to_idx = {l: i for i, l in enumerate(labels_ordered)}
    ortho_pairs = []
    for a, b in [("X", "Y"), ("Y", "Z"), ("Z", "X")]:
        if a in label_to_idx and b in label_to_idx:
            ortho_pairs.append((label_to_idx[a], label_to_idx[b]))

    K_init = calibrate_intrinsics_from_vps(
        vp_list, ortho_pairs,
        assume_zero_skew=True,
        assume_square_pixels=assume_square_pixels,
        fix_principal_point=(w_img / 2, h_img / 2),
    )
    if verbose:
        print(f"\n  K (initial) =\n{np.array2string(K_init, precision=1, suppress_small=True)}")

    # ── Step 4: Distortion estimation (straight-line constraint) ────
    #   CRITICAL: uses K_init from IAC, NOT crude K_approx.
    #   An accurate K is essential for correct undistortion during
    #   line-fitting, which directly determines k1,k2 quality.
    if verbose:
        print()
        print("=" * 60)
        print("Step 4: Distortion estimation (straight-line constraint)")
        print("=" * 60)

    if estimate_distortion:
        dist_est = estimate_distortion_from_lines(
            detected_faces, faces, K_init, verbose=verbose,
        )
    else:
        dist_est = np.zeros(5, dtype=np.float64)
        if verbose:
            print("  Skipped.")

    # ── Step 5: Extrinsic calibration (PnP) ─────────────────────────
    if verbose:
        print()
        print("=" * 60)
        print("Step 5: Extrinsic calibration (PnP)")
        print("=" * 60)

    all_obj = np.vstack([detected_faces[i].object_points
                          for i in valid_idx])
    all_img = np.vstack([detected_faces[i].image_points
                          for i in valid_idx])

    R_init, t_init = calibrate_extrinsics(all_obj, all_img, K_init)
    if verbose:
        print(f"  t = [{t_init[0]:.1f}, {t_init[1]:.1f}, {t_init[2]:.1f}] mm")

    # ── Step 6: Bundle adjustment ───────────────────────────────────
    if verbose:
        print()
        print("=" * 60)
        print("Step 6: Bundle adjustment")
        print("=" * 60)

    proj_init, _ = cv2.projectPoints(
        all_obj, cv2.Rodrigues(R_init)[0], t_init, K_init,
        dist_est if estimate_distortion else None,
    )
    err_init = np.sqrt(np.mean(
        (proj_init.reshape(-1, 2) - all_img.reshape(-1, 2)) ** 2
    ))

    K_opt, dist_opt, R_opt, t_opt, err_final = bundle_adjust(
        K_init, R_init, t_init,
        all_obj.reshape(-1, 3), all_img.reshape(-1, 2),
        dist_init=dist_est,
        with_distortion=estimate_distortion,
        full_distortion=full_distortion,
        k2_reg_weight=0.05,  # prevent k2 overfitting
    )

    if verbose:
        print(f"  Reprojection RMSE: {err_init:.4f} px  →  {err_final:.4f} px")
        print(f"\n  K (refined) =\n{np.array2string(K_opt, precision=1, suppress_small=True)}")
        if estimate_distortion:
            print(f"  dist [k1,k2,p1,p2,k3] = ["
                  f"{dist_opt[0]:.6f}, {dist_opt[1]:.6f}, "
                  f"{dist_opt[2]:.6f}, {dist_opt[3]:.6f}, "
                  f"{dist_opt[4]:.6f}]")
        print(f"  t   = [{t_opt[0]:.1f}, {t_opt[1]:.1f}, {t_opt[2]:.1f}]")

    vp_result = {label: vp.v for label, vp in vp_avg.items()}

    return CalibrationResult(
        K=K_opt,
        dist=dist_opt,
        R=R_opt,
        t=t_opt,
        reproj_error=err_final,
        vanishing_points=vp_result,
    )


# ────────────── Calibration with Unknown Scale ─────────────────────

@dataclass
class ScaleConstraint:
    """Physical constraint used to resolve the scale ambiguity.

    Exactly ONE constraint type must be provided.  The constraint pins
    one absolute physical quantity, which breaks the (s, t) degeneracy
    and makes the square size s identifiable.

    Types
    -----
    ground_height : float (mm)
        Camera height above the ground plane.  The target must sit
        on the ground with its corner at ground level.
    focal_length_px : float (pixels)
        Known focal length in pixels.  Derived from EXIF f_mm and
        sensor pixel pitch:  f_px = f_mm / pixel_size_mm.
    camera_distance : float (mm)
        Known Euclidean distance from camera to the target corner.
    """
    ground_height: Optional[float] = None
    focal_length_px: Optional[float] = None
    camera_distance: Optional[float] = None
    weight: float = 1.0                # constraint strength (automatic if 0)


def calibrate_unknown_scale(
    image_or_path,
    faces_unit: List[FaceDefinition],
    constraint: ScaleConstraint,
    assume_square_pixels: bool = True,
    full_distortion: bool = False,
    preprocess: bool = True,
    verbose: bool = True,
) -> CalibrationResult:
    """Calibrate camera intrinsics AND recover the unknown square size.

    Unlike :func:`calibrate`, this treats the chessboard square size as
    a FREE parameter.  A single physical constraint breaks the scale
    ambiguity (see :class:`ScaleConstraint`).

    Practical example — a phone photo with EXIF data:
        >>> constraint = ScaleConstraint(focal_length_px=3000.0)
        >>> result = calibrate_unknown_scale('photo.jpg', faces, constraint)
        >>> print(result.scale)   # recovered square size in mm

    Parameters
    ----------
    image_or_path : str or ndarray
    faces_unit : list of FaceDefinition with square_size=1.0
    constraint : ScaleConstraint
    assume_square_pixels, full_distortion, preprocess, verbose

    Returns
    -------
    CalibrationResult with .scale set to the recovered square size (mm).
    """
    # ── load image ──
    if isinstance(image_or_path, str):
        img = cv2.imread(image_or_path)
        if img is None:
            raise FileNotFoundError(f"Cannot read {image_or_path}")
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        img = image_or_path
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img

    h_img, w_img = gray.shape[:2]

    if preprocess:
        gray = preprocess_image(gray)

    vp_labels = get_vp_labels(len(faces_unit))

    # ── Step 1: corner detection ──
    if verbose:
        print("Step 1: Corner detection")
    detected_faces: List[DetectedFace] = []
    for fi, face in enumerate(faces_unit):
        cols, rows = face.pattern_size
        ok, corners = cv2.findChessboardCorners(
            gray, (cols, rows),
            flags=cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE,
        )
        if not ok:
            if verbose:
                print(f"  Face {fi}: NOT FOUND")
            detected_faces.append(DetectedFace(
                image_points=np.zeros((0, 1, 2)),
                object_points=np.zeros((0, 1, 3)),
                valid=False,
            ))
            continue
        corners_sub = cv2.cornerSubPix(
            gray, corners, (7, 7), (-1, -1),
            (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 50, 0.0001),
        )
        obj_pts = []
        for r in range(rows):
            for c in range(cols):
                p = (face.origin_3d
                     + c * 1.0 * face.axis_x
                     + r * 1.0 * face.axis_y)
                obj_pts.append(p)
        obj_pts = np.array(obj_pts, dtype=np.float32).reshape(-1, 1, 3)
        detected_faces.append(DetectedFace(
            image_points=corners_sub, object_points=obj_pts, valid=True,
        ))
        if verbose:
            print(f"  Face {fi}: {cols}x{rows} -> {len(corners_sub)} corners")

    valid_idx = [i for i, df in enumerate(detected_faces) if df.valid]
    if len(valid_idx) < 1:
        raise RuntimeError(f"No faces detected; need >= 1")

    # ── Step 2: vanishing points ──
    if verbose:
        print("\nStep 2: Vanishing points")
    vp_per_face = []
    for fi, df in enumerate(detected_faces):
        if not df.valid:
            vp_per_face.append({})
            continue
        face = faces_unit[fi]
        cols, rows = face.pattern_size
        row_lines, col_lines, _, _ = lines_from_chessboard_corners(
            df.image_points, (cols, rows), use_ransac=True,
        )
        vp_col = estimate_vanishing_point(np.array(col_lines))
        vp_row = estimate_vanishing_point(np.array(row_lines))
        vp_col.direction_label = vp_labels[fi][0]
        vp_row.direction_label = vp_labels[fi][1]
        vp_per_face.append({vp_labels[fi][0]: vp_col,
                            vp_labels[fi][1]: vp_row})

    vp_avg = {}
    for label in ["X", "Y", "Z"]:
        V = np.array([vp.v for fv in vp_per_face
                      for l, vp in fv.items() if l == label])
        if len(V) == 0:
            continue
        vm = np.median(V, axis=0)
        if abs(vm[2]) > 1e-6:
            vm /= vm[2]
        vp_avg[label] = VanishingPoint(v=vm, direction_label=label)
        if verbose:
            print(f"  V_{label} = ({vm[0]:.0f}, {vm[1]:.0f})")

    # ── Step 3: IAC initial K ──
    lo = sorted(vp_avg.keys())
    vpl = [vp_avg[l] for l in lo]
    ali = {l: i for i, l in enumerate(lo)}
    op = [(ali[a], ali[b]) for a, b in [("X", "Y"), ("Y", "Z"), ("Z", "X")]
          if a in ali and b in ali]
    K_init = calibrate_intrinsics_from_vps(
        vpl, op, assume_zero_skew=True,
        assume_square_pixels=assume_square_pixels,
        fix_principal_point=(w_img / 2, h_img / 2),
    )
    if verbose:
        print(f"\nStep 3: K_init =\n{np.array2string(K_init, precision=1, suppress_small=True)}")

    # ── Step 4: PnP with unit scale + initial s guess ──
    all_obj_u = np.vstack([detected_faces[i].object_points
                           for i in valid_idx]).reshape(-1, 1, 3)
    all_img = np.vstack([detected_faces[i].image_points
                         for i in valid_idx]).reshape(-1, 1, 2)

    R_init, t_unit = calibrate_extrinsics(all_obj_u, all_img, K_init)
    rvec_init = cv2.Rodrigues(R_init)[0].ravel()
    t_unit = t_unit.ravel()

    # Rough initial s from constraint or default
    if constraint.camera_distance is not None:
        s_init = constraint.camera_distance / np.linalg.norm(t_unit)
    elif constraint.ground_height is not None:
        s_init = constraint.ground_height / abs(t_unit[1])
    elif constraint.focal_length_px is not None:
        s_init = 25.0  # arbitrary, will be pulled by constraint
    else:
        s_init = 25.0

    # ── Step 5: BA with scale as free parameter + constraint ──
    if verbose:
        print("\nStep 5: BA with unknown scale + constraint")

    obj_u_flat = all_obj_u.reshape(-1, 3)
    img_flat = all_img.reshape(-1, 2)
    N = obj_u_flat.shape[0]

    # Auto-weight: balance reprojection (324 residuals) with 1 constraint residual
    auto_weight = constraint.weight
    if auto_weight <= 0:
        auto_weight = float(N)  # one constraint ~ N reprojection residuals

    x0 = np.array([
        float(K_init[0, 0]), float(K_init[1, 1]),
        float(K_init[0, 2]), float(K_init[1, 2]),
        0., 0., 0., 0., 0.,          # k1, k2, k3, p1, p2
        s_init,
        float(rvec_init[0]), float(rvec_init[1]), float(rvec_init[2]),
        float(t_unit[0]), float(t_unit[1]), float(t_unit[2]),
    ])

    def _ba_residuals(params):
        fx, fy, cx, cy, k1, k2, k3, p1, p2, s, rx, ry, rz, tx, ty, tz = params
        Kc = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1.]])
        Rc, _ = cv2.Rodrigues(np.array([rx, ry, rz]))
        tc = np.array([tx, ty, tz])

        X = obj_u_flat * s
        Xc = (Rc @ X.T + tc.reshape(3, 1)).T
        xn = Xc[:, :2] / Xc[:, 2:3]
        r2 = np.sum(xn ** 2, axis=1)
        r4 = r2 ** 2

        if full_distortion:
            rad = 1 + k1 * r2 + k2 * r4 + k3 * r2 ** 3
            xd = xn[:, 0] * rad + 2 * p1 * xn[:, 0] * xn[:, 1] \
                 + p2 * (r2 + 2 * xn[:, 0] ** 2)
            yd = xn[:, 1] * rad + p1 * (r2 + 2 * xn[:, 1] ** 2) \
                 + 2 * p2 * xn[:, 0] * xn[:, 1]
        else:
            rad = 1 + k1 * r2 + k2 * r4
            xd = xn[:, 0] * rad
            yd = xn[:, 1] * rad

        u = fx * xd + cx
        v = fy * yd + cy
        res = np.hstack([u - img_flat[:, 0], v - img_flat[:, 1]])

        # Append physical constraint
        if constraint.ground_height is not None:
            res = np.append(
                res,
                np.sqrt(auto_weight) * (ty - constraint.ground_height),
            )
        if constraint.focal_length_px is not None:
            res = np.append(
                res,
                np.sqrt(auto_weight) * (fx - constraint.focal_length_px),
            )
        if constraint.camera_distance is not None:
            res = np.append(
                res,
                np.sqrt(auto_weight)
                * (np.linalg.norm([tx, ty, tz])
                   - constraint.camera_distance),
            )
        return res

    result_ls = least_squares(
        _ba_residuals, x0, method='lm',
        xtol=1e-12, ftol=1e-12, max_nfev=2000,
    )

    fx, fy, cx, cy = result_ls.x[0:4]
    k1, k2, k3, p1, p2 = result_ls.x[4:9]
    s_opt = result_ls.x[9]
    rvec_opt = result_ls.x[10:13]
    t_opt = result_ls.x[13:16]

    K_opt = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1.]])
    dist_opt = np.array([k1, k2, p1, p2, k3])
    R_opt, _ = cv2.Rodrigues(rvec_opt)

    rmse = np.sqrt(np.mean(
        _ba_residuals(result_ls.x)[:2 * N] ** 2
    ))

    if verbose:
        print(f"  Recovered scale s = {s_opt:.3f} mm")
        print(f"  K =\n{np.array2string(K_opt, precision=1, suppress_small=True)}")
        print(f"  dist [k1,k2,p1,p2,k3] = [{k1:.5f}, {k2:.5f}, {p1:.5f}, {p2:.5f}, {k3:.5f}]")
        print(f"  t = [{t_opt[0]:.1f}, {t_opt[1]:.1f}, {t_opt[2]:.1f}] mm")
        print(f"  RMSE = {rmse:.4f} px")

    return CalibrationResult(
        K=K_opt,
        dist=dist_opt,
        R=R_opt,
        t=t_opt,
        scale=s_opt,
        reproj_error=rmse,
        vanishing_points={l: vp.v for l, vp in vp_avg.items()},
    )


# ──────────────────────── Visualisation ────────────────────────────────

def visualise_result(result: CalibrationResult,
                     detected_faces: List[DetectedFace],
                     image=None,
                     ) -> None:
    """Plot the calibration result: reprojection overlay + 3-D view."""
    import matplotlib.pyplot as plt
    fig = plt.figure(figsize=(16, 5))

    # --- Subplot 1: Reprojection ---
    ax1 = fig.add_subplot(1, 3, 1)
    if image is not None:
        ax1.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                   if image.ndim == 3 else image, cmap='gray')
    colors = ['red', 'lime', 'cyan']
    for fi, df in enumerate(detected_faces):
        if not df.valid or df.image_points.shape[0] == 0:
            continue
        pts = df.image_points.reshape(-1, 2)
        ax1.scatter(pts[:, 0], pts[:, 1], c=colors[fi % 3], s=10,
                    marker='+', label=f'Face {fi} (detected)')

        # Reprojected
        obj = df.object_points.reshape(-1, 3)
        proj, _ = cv2.projectPoints(
            obj, cv2.Rodrigues(result.R)[0], result.t, result.K, result.dist
        )
        proj = proj.reshape(-1, 2)
        ax1.scatter(proj[:, 0], proj[:, 1], c=colors[fi % 3], s=3,
                    marker='o', alpha=0.6, label=f'Face {fi} (reproj)')
    ax1.set_title(f'Reprojection  (RMSE={result.reproj_error:.3f} px)')
    ax1.legend(fontsize=6)
    ax1.set_xlim([0, image.shape[1] if image is not None else 1920])
    ax1.set_ylim([image.shape[0] if image is not None else 1080, 0])

    # --- Subplot 2: Vanishing points ---
    ax2 = fig.add_subplot(1, 3, 2)
    if image is not None:
        ax2.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                   if image.ndim == 3 else image, cmap='gray')
    h, w = (image.shape[:2] if image is not None else (1080, 1920))
    vp_colors = {'X': 'red', 'Y': 'lime', 'Z': 'blue'}
    for label, v in result.vanishing_points.items():
        x, y = v[0] / v[2], v[1] / v[2]
        ax2.plot(x, y, 'o', color=vp_colors.get(label, 'white'),
                 markersize=12, markeredgewidth=2, fillstyle='none')
        ax2.annotate(f'  V_{label}', (x, y),
                     color=vp_colors.get(label, 'white'),
                     fontsize=10, fontweight='bold')
    ax2.set_title('Vanishing Points')
    ax2.set_xlim([0, w])
    ax2.set_ylim([h, 0])

    # --- Subplot 3: 3-D view ---
    ax3 = fig.add_subplot(1, 3, 3, projection='3d')
    # Plot camera
    cam_pos = -result.R.T @ result.t
    ax3.scatter(*cam_pos, c='red', s=80, marker='^', label='Camera')

    # Plot target points
    for fi, df in enumerate(detected_faces):
        if not df.valid:
            continue
        obj = df.object_points.reshape(-1, 3)
        ax3.scatter(obj[:, 0], obj[:, 1], obj[:, 2],
                    c=colors[fi % 3], s=5, alpha=0.5)

    # World axes
    ax3.quiver(0, 0, 0, 50, 0, 0, color='red', linewidth=1, label='X')
    ax3.quiver(0, 0, 0, 0, 50, 0, color='lime', linewidth=1, label='Y')
    ax3.quiver(0, 0, 0, 0, 0, 50, color='blue', linewidth=1, label='Z')

    ax3.set_xlabel('X (mm)')
    ax3.set_ylabel('Y (mm)')
    ax3.set_zlabel('Z (mm)')
    ax3.set_title('3-D View')
    ax3.legend(fontsize=6)

    plt.tight_layout()
    plt.show()


# ──────────────────────── Evaluation Utilities ─────────────────────────

def evaluate_calibration(result: CalibrationResult,
                         K_gt: np.ndarray,
                         R_gt: np.ndarray,
                         t_gt: np.ndarray,
                         ) -> dict:
    """Compare calibration result against ground truth.

    Returns a dict of error metrics.
    """
    metrics = {}

    # Intrinsic errors
    metrics['fx_err_pct'] = 100 * abs(result.K[0, 0] - K_gt[0, 0]) / K_gt[0, 0]
    metrics['fy_err_pct'] = 100 * abs(result.K[1, 1] - K_gt[1, 1]) / K_gt[1, 1]
    metrics['cx_err_px'] = abs(result.K[0, 2] - K_gt[0, 2])
    metrics['cy_err_px'] = abs(result.K[1, 2] - K_gt[1, 2])

    # Extrinsic errors
    # Rotation error: angle of delta-R
    R_delta = result.R @ R_gt.T
    trace_val = np.clip((np.trace(R_delta) - 1) / 2, -1, 1)
    metrics['rot_err_deg'] = np.rad2deg(np.arccos(trace_val))

    # Translation direction error
    t_norm = result.t / np.linalg.norm(result.t)
    t_gt_norm = t_gt / np.linalg.norm(t_gt)
    metrics['trans_angle_err_deg'] = np.rad2deg(
        np.arccos(np.clip(np.dot(t_norm, t_gt_norm), -1, 1))
    )

    metrics['trans_scale_err_pct'] = 100 * abs(
        np.linalg.norm(result.t) - np.linalg.norm(t_gt)
    ) / np.linalg.norm(t_gt)

    return metrics


# ──────────────────────── Demo ─────────────────────────────────────────

def run_demo():
    """Synthetic-data demonstration of the full pipeline."""
    print("Three-Face Single-Image Calibration — Synthetic Demo")
    print("=" * 60)

    # --- Ground-truth camera ---
    w, h = 1920, 1080
    K_gt = np.array([[1200., 0., w / 2],
                     [0., 1200., h / 2],
                     [0., 0., 1.]], dtype=np.float64)

    # Camera pose: looking at the target corner from ~500 mm away, elevated
    t_gt = np.array([-300., -350., 600.], dtype=np.float64)
    # Rotation: look towards origin roughly from (-300,-350,600)
    look_at = -t_gt / np.linalg.norm(t_gt)
    up = np.array([0., 1., 0.])
    z_axis = -look_at
    x_axis = np.cross(up, z_axis)
    x_axis = x_axis / np.linalg.norm(x_axis)
    y_axis = np.cross(z_axis, x_axis)
    R_gt = np.vstack([x_axis, y_axis, z_axis]).T   # 3×3

    # --- Target ---
    faces = standard_three_face_target(square_size=25.0, cols=9, rows=6)

    # --- Generate synthetic data ---
    detected, all_obj, all_img, _ = generate_synthetic_data(
        K_gt, R_gt, t_gt, faces,
        noise_std=0.3,                         # 0.3 px Gaussian noise
        image_size=(w, h),
    )
    print(f"Generated {all_obj.shape[0]} corner points across "
          f"{len([d for d in detected if d.valid])} faces\n")

    # --- Run calibration ---
    result = calibrate(
        np.full((h, w), 128, dtype=np.uint8),   # placeholder image
        faces,
        assume_square_pixels=False,
        with_distortion=False,
        verbose=True,
    )
    # (We bypass corner-detection in this demo by directly using the
    # synthetic DetectedFaces — see the notes below.)

    print()
    print("=" * 60)
    print("Evaluation vs. Ground Truth")
    print("=" * 60)

    metrics = evaluate_calibration(result, K_gt, R_gt, t_gt)
    for k, v in metrics.items():
        print(f"  {k}: {v:.4f}")

    # Visualise
    visualise_result(result, detected,
                     image=np.full((h, w, 3), 200, dtype=np.uint8))


def _demo_core(title: str, K_gt: np.ndarray, R_gt: np.ndarray,
               t_gt: np.ndarray, dist_gt: np.ndarray,
               faces: List[FaceDefinition], w: int, h: int,
               vp_labels: List[List[str]], noise_std: float):
    """Run one synthetic test case and print metrics."""
    print()
    print("=" * 70)
    print(f"  {title}")
    print("=" * 70)

    detected, all_obj, all_img, all_img_clean = generate_synthetic_data(
        K_gt, R_gt, t_gt, faces,
        noise_std=noise_std, image_size=(w, h), dist=dist_gt,
    )
    print(f"  Corners: {all_obj.shape[0]}  |  "
          f"noise σ={noise_std} px  |  "
          f"dist_gt k1={dist_gt[0]:.3f} k2={dist_gt[1]:.3f}")

    # ── Vanishing points (RANSAC lines) ──
    vp_per_face = []
    for fi, df in enumerate(detected):
        face = faces[fi]
        cols, rows = face.pattern_size
        row_lines, col_lines, rq, cq = lines_from_chessboard_corners(
            df.image_points, (cols, rows), use_ransac=True,
        )
        vp_col = estimate_vanishing_point(np.array(col_lines))
        vp_row = estimate_vanishing_point(np.array(row_lines))
        vp_col.direction_label = vp_labels[fi][0]
        vp_row.direction_label = vp_labels[fi][1]
        vp_per_face.append({vp_labels[fi][0]: vp_col,
                            vp_labels[fi][1]: vp_row})

    vp_avg = {}
    for label in ["X", "Y", "Z"]:
        V_stack = np.array([vp.v for fv in vp_per_face
                            for l, vp in fv.items() if l == label])
        if len(V_stack) == 0:
            continue
        v_med = np.median(V_stack, axis=0)
        if abs(v_med[2]) > 1e-6:
            v_med = v_med / v_med[2]
        vp_avg[label] = VanishingPoint(v=v_med, direction_label=label)

    # ── Distortion diagnostic (straight-line error, not a separate fit) ──
    K_approx = np.array([
        [max(w, h), 0, w / 2],
        [0, max(w, h), h / 2],
        [0, 0, 1],
    ], dtype=np.float64)
    diag_corners = [df.image_points for df in detected
                    if df.valid and df.image_points.shape[0] > 0]
    diag_sizes = [faces[i].pattern_size
                  for i, df in enumerate(detected) if df.valid]
    line_err_zero = np.mean(_undistort_line_residuals(
        np.zeros(5), diag_corners, diag_sizes, K_approx
    )[:-1])

    # Initialise distortion at zero — BA handles the rest
    dist_init = np.zeros(5, dtype=np.float64)

    # ── IAC ──
    labels_ordered = sorted(vp_avg.keys())
    vp_list = [vp_avg[l] for l in labels_ordered]
    li = {l: i for i, l in enumerate(labels_ordered)}
    ortho_pairs = [(li[a], li[b]) for a, b in [("X","Y"),("Y","Z"),("Z","X")]
                   if a in li and b in li]

    K_init = calibrate_intrinsics_from_vps(
        vp_list, ortho_pairs, assume_zero_skew=True,
        assume_square_pixels=True,
        fix_principal_point=(w / 2, h / 2),
    )

    # ── PnP ──
    R_init, t_init = calibrate_extrinsics(all_obj, all_img, K_init)

    # ── Bundle adjustment (distortion initialised at zero) ──
    proj_init = cv2.projectPoints(
        all_obj, cv2.Rodrigues(R_init)[0], t_init, K_init, dist_init,
    )[0]
    err_init = np.sqrt(np.mean(
        (proj_init.reshape(-1, 2) - all_img.reshape(-1, 2)) ** 2
    ))

    K_opt, dist_opt, R_opt, t_opt, err_final = bundle_adjust(
        K_init, R_init, t_init,
        all_obj.reshape(-1, 3), all_img.reshape(-1, 2),
        dist_init=dist_init,
        with_distortion=True,
        full_distortion=True,
    )

    # ── Report ──
    fx_err = 100 * abs(K_opt[0, 0] - K_gt[0, 0]) / K_gt[0, 0]
    fy_err = 100 * abs(K_opt[1, 1] - K_gt[1, 1]) / K_gt[1, 1]
    cx_err = abs(K_opt[0, 2] - K_gt[0, 2])
    cy_err = abs(K_opt[1, 2] - K_gt[1, 2])
    R_delta = R_opt @ R_gt.T
    rot_err = np.rad2deg(np.arccos(
        np.clip((np.trace(R_delta) - 1) / 2, -1, 1)
    ))
    d_opt = dist_opt
    d_gt = dist_gt
    print(f"  Line-fit (k=0): {line_err_zero:.3f} px")
    print(f"  RMSE:           {err_init:.3f} → {err_final:.3f} px")
    print(f"  fx error:       {fx_err:.3f}%   fy error: {fy_err:.3f}%")
    print(f"  cx error:       {cx_err:.3f} px  cy error: {cy_err:.3f} px")
    print(f"  rot error:      {rot_err:.4f}°")
    print(f"  dist gt:    k1={d_gt[0]:.5f}  k2={d_gt[1]:.5f}  "
          f"p1={d_gt[2]:.5f}  p2={d_gt[3]:.5f}  k3={d_gt[4]:.5f}")
    print(f"  dist final: k1={d_opt[0]:.5f}  k2={d_opt[1]:.5f}  "
          f"p1={d_opt[2]:.5f}  p2={d_opt[3]:.5f}  k3={d_opt[4]:.5f}")
    # k1 accuracy
    if abs(d_gt[0]) > 0.001:
        k1_acc = 100 * abs(d_opt[0] - d_gt[0]) / abs(d_gt[0])
        print(f"  k1 accuracy:    {k1_acc:.1f}% error")

    return CalibrationResult(
        K=K_opt, dist=dist_opt, R=R_opt, t=t_opt,
        reproj_error=err_final,
        vanishing_points={l: vp.v for l, vp in vp_avg.items()},
    )


def run_demo_direct():
    """Synthetic demo with two test cases: distortion-free and distorted."""
    print("Three-Face Single-Image Calibration — Robustness Demo")
    print("=" * 70)

    w, h = 1920, 1080
    K_gt = np.array([[1200., 0., w / 2],
                     [0., 1200., h / 2],
                     [0., 0., 1.]], dtype=np.float64)

    t_gt = np.array([-300., -350., 600.], dtype=np.float64)
    look_at = -t_gt / np.linalg.norm(t_gt)
    up = np.array([0., 1., 0.])
    z_axis = -look_at
    x_axis = np.cross(up, z_axis)
    x_axis = x_axis / np.linalg.norm(x_axis)
    y_axis = np.cross(z_axis, x_axis)
    R_gt = np.vstack([x_axis, y_axis, z_axis]).T

    faces = standard_three_face_target(square_size=25.0, cols=9, rows=6)
    vp_labels = get_vp_labels(len(faces))

    # ── Test 1: No distortion, low noise ──
    _demo_core("Test 1 — No distortion (σ=0.3 px)",
               K_gt, R_gt, t_gt,
               np.zeros(5, dtype=np.float64),
               faces, w, h, vp_labels, 0.3)

    # ── Test 2: Moderate barrel distortion + noise ──
    # Typical smartphone lens: k1 ≈ 0.12, slight k2
    dist_gt = np.array([0.12, 0.008, 0.0008, -0.0004, 0.0],
                       dtype=np.float64)
    _demo_core("Test 2 — Barrel distortion (k1=0.12, σ=0.3 px)",
               K_gt, R_gt, t_gt, dist_gt,
               faces, w, h, vp_labels, 0.3)

    # ── Test 3: Strong distortion + higher noise ──
    dist_gt2 = np.array([0.25, 0.02, 0.002, -0.001, 0.001],
                        dtype=np.float64)
    _demo_core("Test 3 — Strong distortion (k1=0.25, σ=0.5 px)",
               K_gt, R_gt, t_gt, dist_gt2,
               faces, w, h, vp_labels, 0.5)

    print()
    print("=" * 70)
    print("  All tests complete.")

    # ── Test 4: Unknown scale recovery via physical constraints ──
    print()
    print("=" * 70)
    print("  Test 4: Unknown scale recovery")
    print("=" * 70)

    t_gt2 = np.array([-200., 350., 500.], dtype=np.float64)
    cam_h = t_gt2[1]
    look_at2 = np.array([5*25.0, 3*25.0, 5*25.0]) - t_gt2
    look_at2 = look_at2 / np.linalg.norm(look_at2)
    z2 = -look_at2; x2 = np.cross([0.,1.,0.], z2)
    x2 /= np.linalg.norm(x2); y2 = np.cross(z2, x2)
    R_gt2 = np.vstack([x2, y2, z2]).T

    faces_unit = standard_three_face_target(square_size=1.0, cols=9, rows=6)
    detected_u, all_obj_u, all_img_u, _ = generate_synthetic_data(
        K_gt, R_gt2, t_gt2, standard_three_face_target(25.0, 9, 6),
        noise_std=0.3, image_size=(w, h), dist=dist_gt,
    )
    obj_u_arr = build_corner_cube_target(faces_unit).reshape(-1, 1, 3)
    for df in detected_u:
        df.object_points = obj_u_arr[:df.image_points.shape[0]].reshape(-1, 1, 3)
        obj_u_arr = obj_u_arr[df.image_points.shape[0]:]

    # Vanishing-point estimation (needed for K_init)
    vp_per_face = []
    for fi, df in enumerate(detected_u):
        face = faces_unit[fi]; cols, rows = face.pattern_size
        rl, cl, _, _ = lines_from_chessboard_corners(df.image_points, (cols, rows), use_ransac=True)
        vpc = estimate_vanishing_point(np.array(cl)); vpr = estimate_vanishing_point(np.array(rl))
        vpc.direction_label = vp_labels[fi][0]; vpr.direction_label = vp_labels[fi][1]
        vp_per_face.append({vp_labels[fi][0]: vpc, vp_labels[fi][1]: vpr})

    vp_avg = {}
    for label in ['X','Y','Z']:
        V = np.array([vp.v for fv in vp_per_face for l,vp in fv.items() if l == label])
        if len(V) == 0: continue
        vm = np.median(V, axis=0)
        if abs(vm[2]) > 1e-6: vm /= vm[2]
        vp_avg[label] = VanishingPoint(v=vm, direction_label=label)
    lo = sorted(vp_avg.keys()); vpl = [vp_avg[l] for l in lo]
    ali = {l: i for i, l in enumerate(lo)}
    op = [(ali[a], ali[b]) for a, b in [('X','Y'),('Y','Z'),('Z','X')] if a in ali and b in ali]
    K_iac = calibrate_intrinsics_from_vps(vpl, op, assume_zero_skew=True,
                                           assume_square_pixels=True,
                                           fix_principal_point=(w/2, h/2))
    R_iac, t_unit = calibrate_extrinsics(
        np.vstack([df.object_points for df in detected_u]),
        np.vstack([df.image_points for df in detected_u]), K_iac)
    rvec_iac = cv2.Rodrigues(R_iac)[0].ravel(); t_unit = t_unit.ravel()

    all_img_flat = np.vstack([df.image_points for df in detected_u]).reshape(-1, 2)
    obj_u_flat = np.vstack([df.object_points for df in detected_u]).reshape(-1, 3)
    N = obj_u_flat.shape[0]

    def _run_unknown_scale(constraint_name, constraint_type, target_value):
        # Initialize scale from the constraint
        if constraint_type == 'ground_height':
            s_init = abs(target_value / t_unit[1]) if abs(t_unit[1]) > 1e-6 else 25.0
        elif constraint_type == 'camera_distance':
            s_init = target_value / np.linalg.norm(t_unit)
        else:
            s_init = 25.0
        t_init_val = t_unit * s_init

        x0 = np.array([
            float(K_iac[0,0]), float(K_iac[1,1]), float(K_iac[0,2]), float(K_iac[1,2]),
            0., 0., 0., 0., 0.,
            s_init,
            float(rvec_iac[0]), float(rvec_iac[1]), float(rvec_iac[2]),
            float(t_init_val[0]), float(t_init_val[1]), float(t_init_val[2]),
        ])

        def _res(params):
            fx,fy,cx,cy,k1,k2,k3,p1,p2,s,rx,ry,rz,tx,ty,tz = params
            Kc = np.array([[fx,0,cx],[0,fy,cy],[0,0,1.]])
            Rc, _ = cv2.Rodrigues(np.array([rx,ry,rz]))
            tc = np.array([tx,ty,tz])
            X = obj_u_flat * s
            Xc = (Rc @ X.T + tc.reshape(3,1)).T
            xn = Xc[:,:2] / Xc[:,2:3]; r2 = np.sum(xn**2, axis=1); r4 = r2**2
            rad = 1 + k1*r2 + k2*r4 + k3*r2**3
            xd = xn[:,0]*rad + 2*p1*xn[:,0]*xn[:,1] + p2*(r2 + 2*xn[:,0]**2)
            yd = xn[:,1]*rad + p1*(r2 + 2*xn[:,1]**2) + 2*p2*xn[:,0]*xn[:,1]
            res = np.hstack([fx*xd+cx - all_img_flat[:,0], fy*yd+cy - all_img_flat[:,1]])
            w = np.sqrt(float(N))
            if constraint_type == 'ground_height':
                res = np.append(res, w * (ty - target_value))
            elif constraint_type == 'camera_distance':
                res = np.append(res, w * (np.linalg.norm([tx,ty,tz]) - target_value))
            return res

        res = least_squares(_res, x0, method='lm', xtol=1e-12, ftol=1e-12, max_nfev=2000)
        s_opt = res.x[9]; f_opt = res.x[0]; t_opt = res.x[13:16]
        rmse = np.sqrt(np.mean(_res(res.x)[:2*N]**2))
        print(f'  [{constraint_name}]  s={s_opt:.2f} mm  '
              f'(true=25.0, err={abs(s_opt-25.0):.2f} mm)  f={f_opt:.1f}  RMSE={rmse:.4f}')

    for desc, ctype, target in [
        ('ground height = 350 mm', 'ground_height', float(cam_h)),
        ('camera dist = {:.0f} mm'.format(np.linalg.norm(t_gt2)),
         'camera_distance', np.linalg.norm(t_gt2)),
    ]:
        _run_unknown_scale(desc, ctype, target)


# ──────────────────────── CLI ──────────────────────────────────────────

if __name__ == "__main__":
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
        faces = standard_three_face_target(
            square_size=float(sys.argv[2]) if len(sys.argv) > 2 else 30.0,
            cols=int(sys.argv[3]) if len(sys.argv) > 3 else 9,
            rows=int(sys.argv[4]) if len(sys.argv) > 4 else 6,
        )
        result = calibrate(
            image_path, faces,
            assume_square_pixels=True,
            estimate_distortion=True,
            full_distortion=True,
            preprocess=True,
        )
        print(f"\nFinal K =\n{np.array2string(result.K, precision=2)}")
        print(f"Reprojection RMSE = {result.reproj_error:.4f} px")
        if len(result.dist) >= 5:
            print(f"Distortion [k1,k2,p1,p2,k3] = ["
                  f"{result.dist[0]:.6f}, {result.dist[1]:.6f}, "
                  f"{result.dist[2]:.6f}, {result.dist[3]:.6f}, "
                  f"{result.dist[4]:.6f}]")
    else:
        run_demo_direct()
