import concurrent.futures, json, re, urllib.request, urllib.parse
from pathlib import Path

PKG = Path(r'C:\Users\15808\Desktop\三维\TriCal5_TIM_Submission_20260922')
BIB = PKG / '09_LaTeX_Source_TriCal5/references.bib'
OUT = PKG / 'reference_audit_20260926'

def fetch(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'CalibrationManuscriptReferenceAudit/1.0'})
    with urllib.request.urlopen(req, timeout=35) as response:
        return json.load(response)

def audit(block):
    key = re.search(r'@\w+\{([^,]+),', block).group(1)
    fields = dict(re.findall(r'^\s*(\w+)\s*=\s*\{(.*?)\},?\s*$', block, re.M))
    result = {'key':key, 'original':fields}
    try:
        if 'doi' in fields:
            url = 'https://api.crossref.org/works/' + urllib.parse.quote(fields['doi'], safe='')
            result['records'] = [fetch(url)['message']]
        elif key != 'brown1966':
            url = 'https://api.crossref.org/works?rows=2&query.title=' + urllib.parse.quote(fields['title'].replace('{','').replace('}',''))
            result['records'] = fetch(url)['message']['items']
        else:
            url = 'https://www.asprs.org/wp-content/uploads/pers/1966journal/may/1966_may_444-462.pdf'
            result['manual_primary_source'] = url
        result['lookup_url'] = url
    except Exception as exc:
        result['error'] = str(exc)
    return result

if __name__ == '__main__':
    blocks = re.findall(r'@\w+\{.*?(?=\n@|\Z)', BIB.read_text(encoding='utf-8'), re.S)
    OUT.mkdir(exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(audit, blocks))
    (OUT/'crossref_records.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    for row in results:
        print(row['key'], row.get('error',''))
        for r in row.get('records',[]):
            print(json.dumps({k:r.get(k) for k in ('DOI','title','author','container-title','published','volume','issue','page')},ensure_ascii=False))
