"""Generate tables from the version-matched radial-order experiment."""
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'output/radial_order_matched_0820_20260926'
DEST=Path(r'C:\Users\15808\Desktop\三维\TriCal5_TIM_Submission_20260922\09_LaTeX_Source_TriCal5')
rows=[json.loads(p.read_text(encoding='utf-8')) for p in sorted(DATA.glob('*/evaluation.json'))]
assert len(rows)==5
for order in ('k1','k1_k2'):
    fits=json.loads((DATA/(order+'_training_summary.json')).read_text(encoding='utf-8'))
    assert all(x['accepted'] and x['cross_validation']['successful_folds']==5 for x in fits)
for r in rows:
    assert all(x[m]['successful_repeats']==5 for x in r['images'] for m in ('k1_only','k1_k2'))

def ci(x):
    return f"{x['median_difference']:.4f} [{x['ci95'][0]:.4f}, {x['ci95'][1]:.4f}]"

text=r'''\section{Matched radial-model-order ablation: $k_1$ versus $k_1+k_2$}
\label{sec:s14-radial-order}
This post-hoc analysis tests whether a second radial coefficient improves prediction on the existing 0820 data. Both model orders were freshly fitted with the same float64-corrected source, Python environment, five development images, and cached observations per configuration. The $k_1$-only branch fixes $k_2=0$; the two-coefficient branch retains the empirical ratio prior. The common intrinsic priors, geometric processing, and training gates remain unchanged. These are matched operational pipelines, not an unconstrained test of polynomial order alone. All ten fits passed their training gates and completed all five leave-one-development-image-out folds.

Both models used identical detected test points and five repeated pose/evaluation splits per image. Single-face cases used a local planar pose; multi-face cases used a shared rigid pose. The score pools held-out squared errors over the five repeats within each image, then takes the median across images. Paired differences are the median of imagewise $k_1$-only minus $k_1+k_2$ errors, not the difference between the two marginal medians. Negative differences favor $k_1$-only. Intervals use 10,000 paired image-bootstrap resamples without multiplicity adjustment. They describe sampling variation, not measurement uncertainty; successive images may be correlated.

Of 273 planar test images, one failed complete-lattice detection in 60\_1.155. All 272 evaluable planar images and all 330 cached cuboid cases completed five pose trials for both models. The test images had been examined in earlier development, so this is not a new blind test. Python 3.12, OpenCV 4.12.0, and NumPy 2.4.3 were used; full versions and source hashes accompany the results.

\begin{table}[H]\centering\small
\caption{Matched radial-order prediction on planar and cuboid images. Entries are per-configuration median RMSEs in pixels. Differences are paired imagewise medians with unadjusted 95\% bootstrap intervals.}
\label{tab:s14-radial-order}
\begin{tabular}{lrrrl}\toprule
Configuration & $N$ & $k_1$ & $k_1+k_2$ & Difference [95\% interval]\\\midrule
'''
for kind,label in [('2D','Planar test'),('3D','Cuboid test')]:
    text+=r'\multicolumn{5}{l}{\textbf{'+label+r'}}\\'+'\n'
    for r in rows:
        s=r['summary'][kind]
        text+=f"{r['pose'].replace('_',r'\_')}&{s['k1_only']['image_count']}&{s['k1_only']['rmse']['median']:.3f}&{s['k1_k2']['rmse']['median']:.3f}&{ci(s['paired_rmse_difference'])}"+r'\\'+'\n'
    text+=r'\midrule'+'\n' if kind=='2D' else ''
text+=r'''\bottomrule\end{tabular}\end{table}

The two-coefficient model had lower marginal median error in three of five configurations for each test geometry. Planar paired intervals favored it at 45\_0.827 and 60\_1.155; the remaining three included zero. Cuboid paired intervals favored $k_1+k_2$ at 60\_1.155 and $k_1$-only at 15\_0.528, with the latter effect below 0.001 pixel. The other three included zero. Statistical direction must therefore be distinguished from practical magnitude and tail behavior. For example, at 60\_1.155 the cuboid median improved, while its 95th-percentile error increased from 2.924 to 3.163 pixels.

We also measured RMS distances of undistorted planar checker rows and columns from their best-fit straight lines. This metric uses no square pitch, so it is independent of the nominal \SI{25}{mm} scale. It is not independent ground truth for the camera model.
\begin{table}[H]\centering\small
\caption{Planar line-straightness RMS in pixels. All paired intervals include zero.}
\begin{tabular}{lrrl}\toprule
Configuration & $k_1$ & $k_1+k_2$ & Difference [95\% interval]\\\midrule
'''
for r in rows:
    s=r['summary']['2D']
    text+=f"{r['pose'].replace('_',r'\_')}&{s['k1_only']['line_rms']['median']:.3f}&{s['k1_k2']['line_rms']['median']:.3f}&{ci(s['paired_line_rms_difference'])}"+r'\\'+'\n'
text+=r'''\bottomrule\end{tabular}\end{table}

The archived experiment \nolinkurl{radial_order_matched_0820_20260926} contains both model families, per-image outputs, cached observations, source hashes, and the evaluation protocol. It supersedes an earlier version-confounded radial-order comparison, which combined a corrected single-coefficient fit with a legacy two-coefficient model. That comparison is retained only as an audit record and is not used for inference here. Neither branch replaces the historical primary or external-camera results.

\section{Outer-field prediction in the matched radial-order ablation}
\label{sec:s15-outer-field}
To assess peripheral prediction at the recorded 1920 by 1080 resolution, we partitioned observed image points using
\[
\rho=\sqrt{\left(\frac{u-960}{960}\right)^2+\left(\frac{v-540}{540}\right)^2}.
\]
The outer band is $\rho\geq0.7$. This is a fixed display-space partition shared by both models, not an optical radius normalized by either fitted camera matrix. Each regional image RMSE pools the same five held-out splits. Only images with evaluated points in the band contribute. The scores remain conditional on detected observations and previously inspected test data.

\begin{table}[H]\centering\small
\caption{Outer-band held-out RMSE in pixels. Differences and intervals follow Section~\ref{sec:s14-radial-order}.}
\label{tab:s15-outer-field}
\begin{tabular}{lrrrl}\toprule
Configuration & $N$ & $k_1$ & $k_1+k_2$ & Difference [95\% interval]\\\midrule
'''
for kind,label in [('2D','Planar test'),('3D','Cuboid test')]:
    text+=r'\multicolumn{5}{l}{\textbf{'+label+r'}}\\'+'\n'
    for r in rows:
        s=r['summary'][kind]['display_radius_regions']['outer_rho_ge_0.7']
        text+=f"{r['pose'].replace('_',r'\_')}&{s['image_count']}&{s['k1_only']['median']:.3f}&{s['k1_k2']['median']:.3f}&{ci(s['paired_difference'])}"+r'\\'+'\n'
    text+=r'\midrule'+'\n' if kind=='2D' else ''
text+=r'''\bottomrule\end{tabular}\end{table}

The two-coefficient model had lower outer-band marginal medians in four planar configurations and all five cuboid configurations. Planar paired intervals favored it at 30\_0.827, 45\_0.827, and 60\_1.155; the remaining two included zero. Only the 45\_0.827 cuboid interval excluded zero in its favor. This supports a configuration-dependent peripheral prediction benefit, rather than either a universal benefit or the claim that $k_2$ is unnecessary. Small samples, unadjusted comparisons, and reused test images limit the strength of the evidence. These results do not identify a unique physical $(k_1,k_2)$ pair or establish an application-specific accuracy tolerance.
'''
(DEST/'radial_order_matched.tex').write_text(text,encoding='utf-8')
print('Generated matched radial-order tables; all image trials and model gates verified.')
