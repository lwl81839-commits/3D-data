"""Matched k1-only versus k1+k2 experiment on the existing 0820 split.

This is a post-hoc existing-data analysis. It does not change production models,
images, or the official test split. Camera models are trained from the same five
trihedral images per configuration; test scoring shares detections and splits.
"""
from __future__ import annotations

import csv
import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import trained_camera_model as t
import evaluate_trained_camera_model as ev
import evaluate_planar_blind_comparison as ep
from evaluate_planar_per_pose_controlled import image_dir, camera_from_model

SPLIT = Path(r"E:\Data_image_3d\data_3D_0820_split_model_3D5_Zhang2D20_each_pose_quality_gated")
VAL = SPLIT / "validation_ours_vs_zhang"
OUT = ROOT / "output" / "radial_order_matched_0820_20260926"
POSES = ("15_0.528", "30_0.827", "45_0.827", "45_1.155", "60_1.155")
SEED = 20260926
N_BOOT = 10000


def dump(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def train_models(order: str) -> list[dict]:
    outputs = []
    for pose in POSES:
        images = sorted((SPLIT / "train" / pose / "3D").glob("*.jpg"), key=lambda p: int(p.stem.rsplit("_", 1)[-1]))
        if len(images) != 5:
            raise RuntimeError(f"{pose}: expected 5 development images, found {len(images)}")
        dest = OUT / ("models_" + order) / pose / "trained_camera_model.json"
        dest.parent.mkdir(parents=True, exist_ok=True)
        model = t.train_camera_model(
            [str(p) for p in images], 25.0, str(dest), distortion_model=order,
            progress=lambda msg, p=pose: print(f"[{p}] {msg}", flush=True),
        )
        outputs.append({
            "pose": pose, "accepted": bool(model.get("accepted")),
            "distortion_model_selected": model.get("distortion_model_selected"),
            "cameraMatrix": model.get("cameraMatrix"), "distCoeffs": model.get("distCoeffs"),
            "cross_validation": model.get("cross_validation"),
            "training_images": [p.name for p in images], "model_path": str(dest),
            "model_sha256": hashlib.sha256(dest.read_bytes()).hexdigest(),
        })
    dump(OUT / (order + "_training_summary.json"), outputs)
    return outputs


def model_paths(pose: str) -> dict[str, Path]:
    return {
        "k1_only": OUT / "models_k1" / pose / "trained_camera_model.json",
        "k1_k2": OUT / "models_k1_k2" / pose / "trained_camera_model.json",
    }


def paired_bootstrap(a: list[float], b: list[float], seed: int) -> dict:
    pairs = [(x, y) for x, y in zip(a, b) if np.isfinite(x) and np.isfinite(y)]
    if not pairs:
        return {"n": 0, "median_difference": None, "ci95": None}
    av, bv = np.asarray(pairs, dtype=float).T
    delta = av - bv
    rng = np.random.default_rng(seed)
    draws = np.median(delta[rng.integers(0, len(delta), size=(N_BOOT, len(delta)))], axis=1)
    return {"n": len(delta), "median_difference": float(np.median(delta)),
            "ci95": [float(x) for x in np.quantile(draws, [0.025, 0.975])],
            "direction": "k1_only minus k1_k2; negative favors k1_only"}


def stats(values: list[float]) -> dict:
    arr = np.asarray([x for x in values if np.isfinite(x)], dtype=float)
    if not len(arr):
        return {"n": 0}
    return {
        "n": int(len(arr)), "median": float(np.median(arr)),
        "p95": float(np.percentile(arr, 95)), "maximum": float(np.max(arr)),
        "fraction_le_1px": float(np.mean(arr <= 1.0)),
        "fraction_le_2px": float(np.mean(arr <= 2.0)),
        "fraction_le_3px": float(np.mean(arr <= 3.0)),
    }


def run_pose(pose: str) -> dict:
    paths = model_paths(pose)
    models = {}
    for name, path in paths.items():
        if not path.is_file():
            raise FileNotFoundError(path)
        K, dist, accepted = camera_from_model(path)
        models[name] = {"K": K, "dist": dist, "accepted": accepted, "path": str(path)}

    image_rows = []
    failures = []
    for kind in ("2D", "3D"):
        folder = image_dir(SPLIT, pose) if kind == "2D" else SPLIT / "test" / pose / "3D"
        paths_img = sorted(folder.glob("*.jpg"), key=lambda p: p.name)
        for file_idx, path in enumerate(paths_img):
            try:
                if kind == "2D":
                    img, detector = ep.detect_checker(path)
                    if img is None:
                        raise RuntimeError(detector)
                    obj = ep.object_points(25.0)
                    face_ids = np.zeros(len(obj), dtype=int)
                    faces = 1
                    local_obj = obj
                else:
                    digest = hashlib.sha256(path.read_bytes()).hexdigest()
                    caches = list((VAL / "test_correspondence_cache" / pose).glob(
                        digest + "_sq25_*.npz"))
                    if len(caches) != 1:
                        raise RuntimeError(f"expected one correspondence cache, found {len(caches)}")
                    cv2.setRNGSeed(SEED)
                    sample = t.extract_correspondences(str(path), 25.0,
                        correspondence_cache_path=str(caches[0]), minimum_usable_faces=1)
                    obj, img = sample.object_points, sample.image_points
                    face_ids = ev.face_ids(obj)
                    faces = len(np.unique(face_ids))
                    detector = "cached_geometric_correspondences"
                    local_obj = obj
                    if faces == 1:
                        axes = np.argsort(np.ptp(obj, axis=0))[-2:]
                        local_obj = np.zeros_like(obj)
                        local_obj[:, :2] = obj[:, axes]

                radius = np.linalg.norm((img.reshape(-1, 2) - [960.0, 540.0]) / [960.0, 540.0], axis=1)
                region = np.digitize(radius, [0.4, 0.7])
                rng = np.random.default_rng(SEED + POSES.index(pose) * 100000 + file_idx)
                splits = [ev.stratified_holdout(face_ids, rng, 0.20, 4) for _ in range(5)]
                row = {"pose": pose, "kind": kind, "image": path.name, "faces": faces,
                       "points": len(img), "detector": detector,
                       "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                for model_name, model in models.items():
                    errs, regional_errs, line_score, successful_repeats = [], [[], [], []], None, 0
                    for rep, (train_idx, test_idx) in enumerate(splits):
                        cv2.setRNGSeed(SEED + rep)
                        solver = ep if kind == "2D" or faces == 1 else ev
                        fitted = solver.solve_pose(local_obj, img, train_idx, model["K"], model["dist"])
                        if fitted is None:
                            continue
                        e = solver.project_errors(local_obj, img, test_idx, fitted, model["K"], model["dist"])
                        if np.all(np.isfinite(e)):
                            successful_repeats += 1
                            errs.extend(e.tolist())
                            for point_index, point_error in zip(test_idx, e):
                                regional_errs[int(region[point_index])].append(float(point_error))
                    if kind == "2D":
                        line_score = ep.line_rms(img, model["K"], model["dist"])
                    row[model_name] = {
                        "rmse_px": float(np.sqrt(np.mean(np.square(errs)))) if errs else None,
                        "regional_rmse_px": [float(np.sqrt(np.mean(np.square(x)))) if x else None
                                              for x in regional_errs],
                        "successful_repeats": successful_repeats,
                        "line_rms_px": line_score,
                        "accepted": model["accepted"],
                    }
                image_rows.append(row)
            except Exception as exc:
                failures.append({"kind": kind, "image": path.name, "error": str(exc)})
        print(f"[{pose}] {kind}: processed {sum(r['kind']==kind for r in image_rows)}/{len(paths_img)}; failures={len([x for x in failures if x['kind']==kind])}", flush=True)

    summary = {}
    for kind in ("2D", "3D"):
        subset = [r for r in image_rows if r["kind"] == kind]
        summary[kind] = {name: {
            "image_count": len([r for r in subset if r[name]["rmse_px"] is not None]),
            "rmse": stats([r[name]["rmse_px"] for r in subset if r[name]["rmse_px"] is not None]),
            "line_rms": stats([r[name]["line_rms_px"] for r in subset if r[name]["line_rms_px"] is not None]) if kind == "2D" else None,
        } for name in models}
        summary[kind]["paired_rmse_difference"] = paired_bootstrap(
            [r["k1_only"]["rmse_px"] for r in subset if r["k1_only"]["rmse_px"] is not None and r["k1_k2"]["rmse_px"] is not None],
            [r["k1_k2"]["rmse_px"] for r in subset if r["k1_only"]["rmse_px"] is not None and r["k1_k2"]["rmse_px"] is not None],
            SEED + POSES.index(pose),
        )
        summary[kind]["display_radius_regions"] = {}
        for region_idx, region_name in enumerate(("center_rho_lt_0.4", "mid_0.4_le_rho_lt_0.7", "outer_rho_ge_0.7")):
            region_pairs = [r for r in subset
                            if r["k1_only"]["regional_rmse_px"][region_idx] is not None
                            and r["k1_k2"]["regional_rmse_px"][region_idx] is not None]
            summary[kind]["display_radius_regions"][region_name] = {
                "image_count": len(region_pairs),
                "k1_only": stats([r["k1_only"]["regional_rmse_px"][region_idx] for r in region_pairs]),
                "k1_k2": stats([r["k1_k2"]["regional_rmse_px"][region_idx] for r in region_pairs]),
                "paired_difference": paired_bootstrap(
                    [r["k1_only"]["regional_rmse_px"][region_idx] for r in region_pairs],
                    [r["k1_k2"]["regional_rmse_px"][region_idx] for r in region_pairs],
                    SEED + 1000 + POSES.index(pose) * 10 + region_idx),
            }
        if kind == "2D":
            pairs = [r for r in subset if r["k1_only"]["line_rms_px"] is not None and r["k1_k2"]["line_rms_px"] is not None]
            summary[kind]["paired_line_rms_difference"] = paired_bootstrap(
                [r["k1_only"]["line_rms_px"] for r in pairs],
                [r["k1_k2"]["line_rms_px"] for r in pairs], SEED + 100 + POSES.index(pose))

    result = {"pose": pose, "models": {k: {"accepted": v["accepted"], "path": v["path"]} for k, v in models.items()},
              "summary": summary, "failures": failures, "images": image_rows,
              "protocol": {"training_images": 5, "repeats_per_test_image": 5,
                  "primary_score": "per-image RMSE pooled over identical held-out corner splits",
                  "paired_bootstrap_resamples": N_BOOT, "test_scope": "existing 0820 test set, already consulted during development; post-hoc analysis",
                  "line_metric": "all detected checker rows/columns after undistortion; independent of square pitch, not an absolute calibration truth",
                  "regional_metric": "held-out corner RMSE in fixed display-space elliptical radius bins centered at (960,540); bins shared by both models and not normalized by fitted K"}}
    dump(OUT / pose / "evaluation.json", result)
    return result


def main() -> int:
    global SPLIT, VAL, OUT
    parser = argparse.ArgumentParser()
    parser.add_argument("--split-root", type=Path, default=SPLIT)
    parser.add_argument("--output-root", type=Path, default=OUT)
    parser.add_argument("--evaluate-only", action="store_true",
                        help="reuse both existing model families instead of retraining them")
    args = parser.parse_args()
    SPLIT, OUT = args.split_root.resolve(), args.output_root.resolve()
    VAL = SPLIT / "validation_ours_vs_zhang"
    if not SPLIT.is_dir():
        raise FileNotFoundError(f"Split dataset not found: {SPLIT}")
    OUT.mkdir(parents=True, exist_ok=True)
    if not args.evaluate_only:
        train_models("k1")
        train_models("k1_k2")
    for pose in POSES:
        run_pose(pose)
    print(f"DONE {OUT}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
