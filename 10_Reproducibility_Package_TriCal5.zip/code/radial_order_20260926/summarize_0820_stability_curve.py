from run_0820_stability_curve import OUT,ROOT,POSES,read,save
from pathlib import Path
import numpy as np,hashlib
from trained_camera_model import _load_cache,_local_face_observations
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
protocol=read(OUT/'protocol.json');rows=[];groups=[]
POSES=[s['pose'] for s in protocol['splits']]
local_evidence={}
for split in protocol['splits']:
    for x in split['pool']:
        raw=_load_cache(x['cache'],x['image'],None)
        obs=_local_face_observations([raw],25)
        local_evidence[x['sha256']]=dict(image=x['image'],usable_local_homographies=len(obs),face_indices=[o['face_index'] for o in obs],fit_rmse_px=[o['rmse_px'] for o in obs])
save(OUT/'local_homography_evidence.json',local_evidence)
for split in protocol['splits']:
    pose=split['pose'];planar=read(OUT/'planar_evaluations'/pose/'evaluation.json')
    for j in [j for j in protocol['jobs'] if j['pose']==pose]:
        d=OUT/'models'/pose/j['name'];status=read(d/'status.json')
        r=dict(pose=pose,n=j['n'],repeat=j['repeat'],name=j['name'],selected_hashes=sorted(x['sha256'] for x in j['selected']),**status)
        hs=[local_evidence[x['sha256']]['usable_local_homographies'] for x in j['selected']]
        r['local_homographies_per_image']=hs;r['local_homography_sum']=sum(hs);r['minimum_LOO_local_homography_sum']=sum(hs)-max(hs)
        pts=np.array([x['center'] for x in j['selected']]);r['center_spread']=float(np.linalg.norm(np.ptp(pts,axis=0)));r['selected_corner_sum']=sum(x['inliers'] for x in j['selected']);r['selected_min_faces']=min(x['faces'] for x in j['selected']);r['selected_radius_p95_max']=max(x['radius_p95'] for x in j['selected'])
        if status['completed']:
            m=read(d/'trained_camera_model.json');c=m['candidate_comparison']['k1_k2'];r.update(K=m['cameraMatrix'],dist=m['distCoeffs'],base_quality_accepted=c['base_quality_accepted'],k2_stability=c['k2_stability'],cross_validation=m['cross_validation'],training_evidence=m['training_images'],optical_radial_coverage=c['radial_coverage'])
            e=OUT/'evaluations'/pose/j['name']/'evaluation.json'
            if e.exists():
                summary=read(e)['summary'];r['3D_summary']=summary;r['3D_px']=summary['holdout_error_px']['median']
            p=planar['summaries'].get(j['name']);r['2D_summary']=p;r['2D_px']=p['holdout_rmse_px']['median'] if p else None
        rows.append(r)
    for n in split['sizes']:
        rr=[r for r in rows if r['pose']==pose and r['n']==n]
        g=dict(pose=pose,n=n,runs=len(rr),unique_subsets=len({tuple(r['selected_hashes']) for r in rr}),completed=sum(r['completed'] for r in rr),accepted=sum(r['accepted'] for r in rr))
        for kind in ['2D','3D']:
            v=[r.get(kind+'_px') for r in rr];v=[x for x in v if x is not None and np.isfinite(x)]
            g[kind]=None if not v else dict(n=len(v),median=float(np.median(v)),min=min(v),max=max(v),relative_range=(max(v)-min(v))/max(np.median(v),1e-12))
        dist=[r['dist'][:2] for r in rr if r.get('dist')]
        g['coefficient_std']=np.std(dist,axis=0).tolist() if dist else None
        groups.append(g)
screen=[]
for pose in POSES:
    gg=[g for g in groups if g['pose']==pose]
    for i,g in enumerate(gg):
        r=dict(pose=pose,n=g['n'],unique_subsets=g['unique_subsets'],all_three_accepted=g['accepted']==3)
        r['repeat_score_range_within_10pct']=all(g[k] and g[k]['n']==3 and g[k]['relative_range']<=.10 for k in ['2D','3D'])
        r['next_budget']=gg[i+1]['n'] if i+1<len(gg) else None
        r['next_budget_change']=None if r['next_budget'] is None else {k:abs(gg[i+1][k]['median']-g[k]['median'])/max(g[k]['median'],1e-12) if g[k] and gg[i+1][k] else None for k in ['2D','3D']}
        r['descriptive_plateau']=bool(r['all_three_accepted'] and r['repeat_score_range_within_10pct'] and r['next_budget_change'] and all(v is not None and v<=.05 for v in r['next_budget_change'].values()))
        r['prediction_only_plateau']=bool(g['completed']==3 and r['repeat_score_range_within_10pct'] and r['next_budget_change'] and all(v is not None and v<=.05 for v in r['next_budget_change'].values()))
        r['sustained_prediction_plateau']=bool(r['prediction_only_plateau'] and all(h['completed']==3 and all(h[k] and h[k]['n']==3 and h[k]['relative_range']<=.1 and abs(h[k]['median']-g[k]['median'])/max(g[k]['median'],1e-12)<=.05 for k in ['2D','3D']) for h in gg[i+1:]))
        screen.append(r)
save(OUT/'analysis.json',dict(groups=groups,models=rows,plateau_screen=screen))
lines=['# 0820 exploratory calibration sample-count curves','',
'This experiment reuses previously inspected 0820 training/test images in a NEW exploratory development/validation partition. Original folders and primary models are untouched. It is NOT a fresh independent final test. No MATLAB/reference parameter is used in fitting.','',
'Geometry screening found 6, 8, 24, 12, 37 eligible multi-face images. After reserving fixed eligible validation images, development pools have 5, 7, 20, 10, 30 images. Non-eligible images are retained in the fixed validation pools to evaluate conditional detected-point performance. Selection is three fixed random nested orders, not selected using validation errors.','',
'Only the training-entry minimum is reduced from four to two; minimum multi-face image count is min(4,n). Pixel, principal-point, radial-ratio, monotonicity and fold-stability gates remain unchanged. Two-image LOO uses one remaining image and can fail for insufficient plane constraints; this is reported, not bypassed.','',
'## Curves','', '|Config.|Images|Unique subsets / runs|Completed / runs|Accepted / runs|2D RMSE median [min,max]|3D RMSE median [min,max]|','|---|---|---|---|---|---|---|']
def fmt(v):return '-' if v is None else f"{v['median']:.4f} [{v['min']:.4f}, {v['max']:.4f}]"
for g in groups:lines.append(f"|{g['pose']}|{g['n']}|{g['unique_subsets']}/{g['runs']}|{g['completed']}/{g['runs']}|{g['accepted']}/{g['runs']}|{fmt(g['2D'])}|{fmt(g['3D'])}|")
lines+=['','Ranges summarize only three runs and are not confidence intervals. When n equals the pool size, the three runs have the same subset in different input orders; they do NOT measure random-subset uncertainty. Errors include completed rejected models diagnostically, avoiding success-only reporting. Cuboid metrics are original evaluator medians over trial RMSEs; planar metrics are medians of per-image median trial RMSEs.','',
'## Descriptive plateau screen','',
'A provisional screen requires 3/3 existing release passes, <=10% relative validation-score range and <=5% change at the next tested budget on both validation geometries. These are disclosed exploratory tolerances, NOT user-specified application tolerances and NOT an optimized threshold. Three repeats cannot establish a population reliability level. The maximum tested budget cannot establish a plateau by itself.','']
for pose in POSES:
    hits=[r['n'] for r in screen if r['pose']==pose and r['descriptive_plateau']]
    prediction=[r['n'] for r in screen if r['pose']==pose and r['prediction_only_plateau']]
    sustained=[r['n'] for r in screen if r['pose']==pose and r['sustained_prediction_plateau']]
    lines.append(f'- {pose}: local prediction-only candidates = {prediction}; local candidates also passing all legacy release gates = {hits}; sustained across all larger tested budgets = {sustained}.')
lines+=['','The separate prediction-only screen does not require the legacy LOO release gate, because deleting one of two images can make the one-image fold underconstrained even if the two-image fit predicts held-out images adequately. Prediction-only candidates are NOT relabeled accepted calibrations.','',
'## External accuracy guidance','',
'MathWorks describes mean reprojection error below one pixel as a general practical guideline, and states acceptability depends on application precision: https://www.mathworks.com/help/vision/ug/using-the-single-camera-calibrator-app.html and https://www.mathworks.com/help/vision/ug/evaluating-the-accuracy-of-single-camera-calibration.html (accessed 2026-09-12). This concerns mean reprojection error and is not a universal standard for independent hold-out RMSE, 3D measurement error, or coefficient identification. Our current code release gates (e.g. 8px development median) do not establish subpixel accuracy.','',
'Exploratory validation threshold sensitivity below counts runs whose reported validation median RMSE is below each threshold on BOTH 2D and 3D. These are deliberately labeled analysis thresholds, not official MATLAB acceptance criteria.','',
'|Config.|Images|<0.5px|<1px|<2px|<3px|','|---|---|---|---|---|---|']
for g in groups:
    rr=[r for r in rows if r['pose']==g['pose'] and r['n']==g['n']]
    counts=[sum(r.get('2D_px') is not None and r.get('3D_px') is not None and r['2D_px']<t and r['3D_px']<t for r in rr) for t in [.5,1,2,3]]
    lines.append(f"|{g['pose']}|{g['n']}|"+'|'.join(f'{c}/3' for c in counts)+'|')
lines+=['','Even a candidate plateau is not a minimum sufficient image count: application accuracy requirements, broader subset repetition, and fresh data confirmation remain needed. Stable but biased predictions can also form a plateau.','',
'## Image requirements','',
'analysis.json retains training face counts, spans, final inliers, optical radial coverage, image-center spread, k2 fold statistics and all failures per subset. The screen requires at least two usable faces per pool image; complete three-face detection is not required. Acquisition position is not equivalent to accepted corner radial coverage. No new sharpness, angle or radial cutoff is claimed from these correlated small samples.','',
'Code snapshots, input hashes, split membership and original-role labels are in code/, *_pool.json and protocol.json.']
(OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
if protocol.get('selection_policy'):
    lines[0]='# 0820 matched quality-filtered sample-count curves'
    lines[4]='Selection policy: '+protocol['selection_policy']+'. Development pools and all selected image hashes are in protocol.json; validation membership is identical to the unfiltered experiment.'
    (OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
fig,axes=plt.subplots(3,len(POSES),figsize=(3.4*len(POSES),9),sharex='col')
for col,pose in enumerate(POSES):
    gg=[g for g in groups if g['pose']==pose];xx=[g['n'] for g in gg]
    for row,kind in enumerate(['2D','3D']):
        a=axes[row,col];values=[g[kind]['median'] if g[kind] else np.nan for g in gg];a.plot(xx,values,'o-',color='#236b8e');a.fill_between(xx,[g[kind]['min'] if g[kind] else np.nan for g in gg],[g[kind]['max'] if g[kind] else np.nan for g in gg],alpha=.18,color='#236b8e');a.set_ylabel(kind+' RMSE (px)');a.grid(alpha=.2)
    axes[0,col].set_title(pose)
    axes[2,col].plot(xx,[g['accepted']/g['runs'] for g in gg],'o-',color='#945326');axes[2,col].set_ylim(-.05,1.05);axes[2,col].set_ylabel('Release pass fraction');axes[2,col].set_xlabel('Training images');axes[2,col].set_xticks(xx);axes[2,col].grid(alpha=.2)
fig.suptitle('Exploratory 0820 sample-count curves: three nested runs; shaded range is not a confidence interval')
fig.tight_layout(rect=[0,0,1,.96]);fig.savefig(OUT/'sample_count_curves.png',dpi=170);plt.close(fig)
assert hashlib.sha256((ROOT/'trained_camera_model.py').read_text(encoding='utf-8').encode()).hexdigest()==protocol['main_source_sha256']
print('\n'.join(lines))
