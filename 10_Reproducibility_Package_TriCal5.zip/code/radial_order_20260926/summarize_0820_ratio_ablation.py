from pathlib import Path
import json,csv,hashlib
from ablate_0820_ratio_prior import OUT,BASE,ROOT,POSES,FULL_REMOVAL

def read(p): return json.loads(p.read_text(encoding='utf-8'))
def med(s,k): return s.get(k,{}).get('median')
def fmt(v): return '-' if v is None else f'{v:.4f}'
rows=[]; parameters=[]; allcounts=[]
for pose in POSES:
    a=read(OUT/'per_pose_models'/pose/'trained_camera_model.json')
    b=read(BASE/'per_pose_models'/pose/'trained_camera_model.json')
    import numpy as np
    parameters.append(dict(pose=pose,accepted_without=a['accepted'],accepted_with=b['accepted'],k1_with=np.asarray(b['distCoeffs']).ravel()[0],k2_with=np.asarray(b['distCoeffs']).ravel()[1],k1_without=np.asarray(a['distCoeffs']).ravel()[0],k2_without=np.asarray(a['distCoeffs']).ravel()[1],K_max_absolute_change=float(np.max(abs(np.array(a['cameraMatrix'])-np.array(b['cameraMatrix']))))))
    for method in ['with_ratio_prior','without_ratio_prior']:
        s=read(OUT/'final_test_evaluation'/pose/method/'evaluation.json')['summary']
        if method=='without_ratio_prior': allcounts.append((pose,s.get('face_evidence_histogram',{})))
        rows.append(dict(pose=pose,kind='3D',method=method,attempted=s['blind_images_attempted'],evaluated=s['blind_images_extracted'],holdout_rmse_px=med(s,'holdout_error_px'),object_rmse_mm=med(s,'holdout_object_point_rmse_mm'),length_error_pct=med(s,'holdout_length_relative_error_pct'),line_rms_px=med(s,'undistorted_line_rms_px'),pose_trial_success_pct=s.get('holdout_pose_trial_success_rate_pct'),uncached_skipped=s['uncached_images_skipped_by_request']))
    p=read(OUT/'final_test_evaluation'/pose/'planar_2d_controlled/evaluation.json')
    for key,method in [('with_ratio_prior','with_ratio_prior'),('ours_3d_5_images','without_ratio_prior'),('zhang_matlab_20_images','zhang_reference')]:
        s=p['summaries'][key]
        rows.append(dict(pose=pose,kind='2D',method=method,attempted=p['test_images'],evaluated=p['detected_images'],holdout_rmse_px=med(s,'holdout_rmse_px'),object_rmse_mm=med(s,'holdout_object_rmse_mm'),length_error_pct=med(s,'length_relative_error_pct'),line_rms_px=med(s,'undistorted_line_rms_px'),pose_trial_success_pct=None,uncached_skipped=0))
for name,data in [('comparison_metrics',rows),('parameter_comparison',parameters)]:
    with (OUT/(name+'.csv')).open('w',newline='',encoding='utf-8-sig') as f:
        wr=csv.DictWriter(f,fieldnames=list(data[0])); wr.writeheader(); wr.writerows(data)
    (OUT/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
lines=['# 0820五图训练系数比例惩罚消融','',
'原有五组各5张训练图，完整重新训练及留一验证；独立二维和三维测试。模型、数据划分与原稿均保留。','',
'唯一计算改变：径向精修中的 max(0,|k2|-0.5|k1|)/0.001 残差置零。参数边界、单调性约束、主点和纵横比先验、优化器、质量门限保持不变。','',
'特别说明：初始化中原有的按系数比例裁剪k2初值仍保留，因此这是“移除优化惩罚项”的严格消融，并非移除全部与比例有关的处理。最终参数可超出该比例；若要评估完全不使用比例信息，需要另做取消初值裁剪的实验。','',
'## 训练参数','',
'|配置|原k1|原k2|去惩罚k1|去惩罚k2|去惩罚训练接收|','|---|---|---|---|---|---|']
for r in parameters: lines.append(f"|{r['pose']}|{fmt(r['k1_with'])}|{fmt(r['k2_with'])}|{fmt(r['k1_without'])}|{fmt(r['k2_without'])}|{r['accepted_without']}|")
lines+=['','## 完整测试','',
'|配置|测试|方法|可评估/尝试|留出RMSE(px)|物点RMSE(mm)|长度误差(%)|','|---|---|---|---|---|---|---|']
for r in rows: lines.append(f"|{r['pose']}|{r['kind']}|{r['method']}|{r['evaluated']}/{r['attempted']}|{fmt(r['holdout_rmse_px'])}|{fmt(r['object_rmse_mm'])}|{fmt(r['length_error_pct'])}|")
lines+=['','二维两组模型与Zhang共同使用同次检测和划分。三维原模型和消融模型均重跑同一评估器、相同缓存和随机种子；Zhang三维历史结果没有重复计算。所有指标沿用原完整流程的统计口径。三维长度包含原评估器的多个长度档，非单独25mm格长。','',
'代码快照位于code/，训练图与缓存哈希位于protocol.json，各图各次试验位于final_test_evaluation/。误差为同一标定物上的内部几何验证，不能当成独立计量真值。',
'本消融保留真实未变化结果；不能因为结果近似就宣布软先验具有显著精度贡献，也不能把优化器返回成功当作系数已充分可辨识。']
lines+=['','## 三维测试实际面数','', '|配置|单面|两面|三面|','|---|---|---|---|']
if FULL_REMOVAL:
    lines=[line.replace('五图训练系数比例惩罚消融','五图训练完整比例约束消融').replace('唯一计算改变：径向精修中的 max(0,|k2|-0.5|k1|)/0.001 残差置零。','计算改变：取消按k1大小裁剪k2初值，并移除系数比例优化惩罚。') for line in lines if not line.startswith('特别说明：')]
    lines+=['','本次初始化、最终拟合和留一验证均不施加 |k1|>=2|k2|。仍保留与比例无关的独立数值边界及径向单调性约束。']
for pose,h in allcounts: lines.append(f"|{pose}|{h.get('1',0)}|{h.get('2',0)}|{h.get('3',0)}|")
lines+=['','## 质量门限与诊断测试','', '未接收模型仍用于消融诊断评估，但未改写accepted状态，不能作为正式合格模型。']
for pose in POSES:
    m=read(OUT/'per_pose_models'/pose/'trained_camera_model.json')
    c=m['candidate_comparison']['k1_k2']
    lines.append(f"- {pose}: accepted={m['accepted']}; {c.get('k2_stability',{}).get('reason','')}")
(OUT/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
protocol=read(OUT/'protocol.json')
assert hashlib.sha256((ROOT/'trained_camera_model.py').read_text(encoding='utf-8').encode()).hexdigest()==protocol['source_sha256']
print(json.dumps(parameters),flush=True)
print('Report saved:',OUT/'REPORT.md',flush=True)
