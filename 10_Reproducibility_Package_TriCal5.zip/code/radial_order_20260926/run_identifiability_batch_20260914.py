from concurrent.futures import ThreadPoolExecutor
from run_stability_verification_20260914 import OUT,ROOT,POSES,save
from evaluate_stability_verification_20260914 import run
jobs=[('ident_'+p+'_'+v,[ROOT/'audit_identifiability_20260914.py',p,v]) for p in POSES for v in ['ratio','no_ratio'] if not (OUT/'identifiability'/p/(v+'.json')).exists()]
with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,jobs))
save(OUT/'identifiability_jobs.json',results)
