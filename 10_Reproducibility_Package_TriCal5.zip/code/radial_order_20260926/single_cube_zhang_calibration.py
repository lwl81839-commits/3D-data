#!/usr/bin/env python3
"""Full-parameter Zhang calibration from one three-face cube image.

The three mutually perpendicular checkerboard faces act as three metric
planes observed by the same camera.  Each face contributes the two standard
Zhang constraints on the image of the absolute conic, so one image supplies
six constraints for the five intrinsic degrees of freedom.  The linear
solution is followed by a single physical 3-D bundle adjustment over all
corners.
"""

from __future__ import annotations

import itertools
import json
import math
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np
from scipy.optimize import least_squares

from checker_plumbline_distortion import (
    checker_line_residuals,
    checker_line_rms,
    estimate_checker_plumbline_distortion,
)
from three_face_calib import (
    DetectedFace,
    FaceDefinition,
    object_points_for_face,
    standard_three_face_target,
)


@dataclass
class SingleCubeZhangResult:
    """Result of the one-image, three-plane calibration."""

    K: np.ndarray
    dist: np.ndarray
    R: np.ndarray
    t: np.ndarray
    reproj_rmse: float
    linear_K: np.ndarray
    homographies: List[np.ndarray]
    face_assignment: List[int]
    face_orientations: List[Dict[str, object]]
    object_points: np.ndarray
    image_points: np.ndarray
    success: bool
    message: str
    diagnostics: Dict[str, object] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, object]:
        return {
            "success": bool(self.success),
            "message": self.message,
            "K": self.K.tolist(),
            "dist": self.dist.tolist(),
            "R": self.R.tolist(),
            "t": self.t.tolist(),
            "reproj_rmse": float(self.reproj_rmse),
            "linear_K": self.linear_K.tolist(),
            "face_assignment": [int(v) for v in self.face_assignment],
            "face_orientations": self.face_orientations,
            "diagnostics": self.diagnostics,
        }


def _normalize_points_2d(points: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Hartley-normalize 2-D points to zero mean and RMS distance sqrt(2)."""
    pts = np.asarray(points, dtype=np.float64).reshape(-1, 2)
    if len(pts) < 4:
        raise ValueError("At least four points are required for a homography")
    center = pts.mean(axis=0)
    centered = pts - center
    rms = float(np.sqrt(np.mean(np.sum(centered * centered, axis=1))))
    if not np.isfinite(rms) or rms < 1e-12:
        raise ValueError("Degenerate 2-D point configuration")
    scale = math.sqrt(2.0) / rms
    T = np.array([
        [scale, 0.0, -scale * center[0]],
        [0.0, scale, -scale * center[1]],
        [0.0, 0.0, 1.0],
    ])
    homogeneous = np.column_stack([pts, np.ones(len(pts))])
    normalized = (T @ homogeneous.T).T[:, :2]
    return normalized, T


def normalized_dlt_homography(
    plane_points: np.ndarray,
    image_points: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Estimate a plane-to-image homography with normalized DLT."""
    src, Ts = _normalize_points_2d(plane_points)
    dst, Td = _normalize_points_2d(image_points)
    if len(src) != len(dst):
        raise ValueError("Plane and image point counts differ")

    A = np.zeros((2 * len(src), 9), dtype=np.float64)
    for i, ((x, y), (u, v)) in enumerate(zip(src, dst)):
        A[2 * i] = [-x, -y, -1.0, 0.0, 0.0, 0.0,
                    u * x, u * y, u]
        A[2 * i + 1] = [0.0, 0.0, 0.0, -x, -y, -1.0,
                        v * x, v * y, v]
    _, singular_values, vt = np.linalg.svd(A, full_matrices=False)
    Hn = vt[-1].reshape(3, 3)
    H = np.linalg.inv(Td) @ Hn @ Ts
    scale = H[2, 2] if abs(H[2, 2]) > 1e-12 else np.linalg.norm(H[:, 0])
    H /= scale
    return H, singular_values


def _local_checker_points(pattern_size: Tuple[int, int], square_size: float) -> np.ndarray:
    cols, rows = pattern_size
    return np.array(
        [[c * square_size, r * square_size]
         for r in range(rows) for c in range(cols)],
        dtype=np.float64,
    )


def _zhang_v(H: np.ndarray, i: int, j: int) -> np.ndarray:
    hi = H[:, i]
    hj = H[:, j]
    return np.array([
        hi[0] * hj[0],
        hi[0] * hj[1] + hi[1] * hj[0],
        hi[1] * hj[1],
        hi[2] * hj[0] + hi[0] * hj[2],
        hi[2] * hj[1] + hi[1] * hj[2],
        hi[2] * hj[2],
    ], dtype=np.float64)


def _intrinsics_from_b(b: np.ndarray) -> Optional[np.ndarray]:
    B11, B12, B22, B13, B23, B33 = np.asarray(b, dtype=np.float64)
    denominator = B11 * B22 - B12 * B12
    if abs(B11) < 1e-15 or denominator <= 1e-18:
        return None
    v0 = (B12 * B13 - B11 * B23) / denominator
    lam = B33 - (
        B13 * B13 + v0 * (B12 * B13 - B11 * B23)
    ) / B11
    alpha2 = lam / B11
    beta2 = lam * B11 / denominator
    if alpha2 <= 0.0 or beta2 <= 0.0:
        return None
    alpha = math.sqrt(alpha2)
    beta = math.sqrt(beta2)
    gamma = -B12 * alpha * alpha * beta / lam
    u0 = gamma * v0 / beta - B13 * alpha * alpha / lam
    K = np.array([
        [alpha, gamma, u0],
        [0.0, beta, v0],
        [0.0, 0.0, 1.0],
    ])
    return K if np.all(np.isfinite(K)) else None


def zhang_intrinsics_from_homographies(
    homographies: Sequence[np.ndarray],
) -> Tuple[np.ndarray, Dict[str, object]]:
    """Recover full K=(fx, fy, skew, cx, cy) from three or more planes."""
    if len(homographies) < 3:
        raise ValueError("Full Zhang initialization requires three faces")
    rows = []
    for H in homographies:
        rows.append(_zhang_v(H, 0, 1))
        rows.append(_zhang_v(H, 0, 0) - _zhang_v(H, 1, 1))
    V = np.asarray(rows, dtype=np.float64)
    row_norms = np.linalg.norm(V, axis=1)
    Vn = V / np.maximum(row_norms[:, None], 1e-15)
    _, sv, vt = np.linalg.svd(Vn, full_matrices=False)
    b = vt[-1]

    candidates = []
    iac_projection = None
    for signed_b in (b, -b):
        K = _intrinsics_from_b(signed_b)
        if K is not None:
            candidates.append((0.0, K))
    if not candidates:
        # With only the minimum three planes, corner noise can move the linear
        # IAC just outside the positive-definite cone.  Projecting the symmetric
        # conic to its nearest SPD matrix preserves all six Zhang constraints
        # as closely as possible and supplies a valid nonlinear initializer.
        projected_candidates = []
        for sign in (1.0, -1.0):
            signed_b = sign * b
            B = np.array([
                [signed_b[0], signed_b[1], signed_b[3]],
                [signed_b[1], signed_b[2], signed_b[4]],
                [signed_b[3], signed_b[4], signed_b[5]],
            ])
            eigenvalues, eigenvectors = np.linalg.eigh(B)
            floor = max(float(np.max(np.abs(eigenvalues))) * 1e-6, 1e-12)
            clipped = np.maximum(eigenvalues, floor)
            B_spd = eigenvectors @ np.diag(clipped) @ eigenvectors.T
            correction = float(
                np.linalg.norm(B_spd - B) / max(np.linalg.norm(B), 1e-15)
            )
            projected_b = np.array([
                B_spd[0, 0], B_spd[0, 1], B_spd[1, 1],
                B_spd[0, 2], B_spd[1, 2], B_spd[2, 2],
            ])
            K = _intrinsics_from_b(projected_b)
            if K is not None:
                projected_candidates.append((correction, K, eigenvalues, clipped))
        if not projected_candidates:
            raise ValueError("Zhang IAC solution cannot be projected to a valid camera")
        correction, K_projected, eigenvalues, clipped = min(
            projected_candidates, key=lambda item: item[0],
        )
        candidates.append((correction, K_projected))
        iac_projection = {
            "used": True,
            "relative_correction": correction,
            "eigenvalues_before": eigenvalues.tolist(),
            "eigenvalues_after": clipped.tolist(),
        }

    # Both signs represent the same conic.  If numerical noise yields two
    # candidates, prefer the one with the more camera-like positive focal pair.
    _, K = min(
        candidates,
        key=lambda item: (
            item[0],
            abs(item[1][0, 1]) / max(item[1][0, 0], item[1][1, 1]),
        ),
    )
    diagnostics = {
        "constraint_singular_values": sv.tolist(),
        "constraint_null_ratio": float(sv[-2] / max(sv[-1], 1e-15)),
        "constraint_condition": float(sv[0] / max(sv[-2], 1e-15)),
        "iac_vector": b.tolist(),
        "iac_spd_projection": iac_projection or {"used": False},
    }
    return K, diagnostics


def _project_full(
    object_points: np.ndarray,
    K: np.ndarray,
    dist: np.ndarray,
    rvec: np.ndarray,
    tvec: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Project with full skew and OpenCV's five-coefficient distortion model."""
    R, _ = cv2.Rodrigues(np.asarray(rvec, dtype=np.float64).reshape(3, 1))
    camera = np.asarray(object_points, dtype=np.float64).reshape(-1, 3) @ R.T
    camera += np.asarray(tvec, dtype=np.float64).reshape(1, 3)
    z = camera[:, 2]
    z_safe = np.where(np.abs(z) > 1e-8, z, np.where(z >= 0.0, 1e-8, -1e-8))
    x = camera[:, 0] / z_safe
    y = camera[:, 1] / z_safe

    k1, k2, p1, p2, k3 = np.asarray(dist, dtype=np.float64).reshape(5)
    r2 = x * x + y * y
    radial = 1.0 + k1 * r2 + k2 * r2 * r2 + k3 * r2 * r2 * r2
    xd = x * radial + 2.0 * p1 * x * y + p2 * (r2 + 2.0 * x * x)
    yd = y * radial + p1 * (r2 + 2.0 * y * y) + 2.0 * p2 * x * y
    u = K[0, 0] * xd + K[0, 1] * yd + K[0, 2]
    v = K[1, 1] * yd + K[1, 2]
    return np.column_stack([u, v]), z


def _enumerate_physical_correspondence(
    detected_faces: Sequence[DetectedFace],
    face_definitions: Sequence[FaceDefinition],
    K: np.ndarray,
    allow_face_permutations: bool,
) -> Tuple[np.ndarray, np.ndarray, List[int], List[Dict[str, object]], np.ndarray, np.ndarray, float]:
    """Jointly resolve face assignment and row/column flips with pooled PnP."""
    n = len(detected_faces)
    all_img = np.vstack([
        np.asarray(face.image_points).reshape(-1, 2) for face in detected_faces
    ]).astype(np.float64)
    K_pnp = np.array(K, dtype=np.float64, copy=True)
    K_pnp[0, 1] = 0.0  # OpenCV's camera model has no skew term.

    best = None
    physical_indices = range(len(face_definitions))
    assignments = (
        itertools.permutations(physical_indices, n)
        if allow_face_permutations
        else [tuple(physical_indices)]
    )
    for assignment in assignments:
        if any(
            detected_faces[i].image_points.reshape(-1, 2).shape[0]
            != np.prod(face_definitions[assignment[i]].pattern_size)
            for i in range(n)
        ):
            continue
        orientation_options = list(itertools.product((False, True), repeat=2 * n))
        for flags in orientation_options:
            objects = []
            orientations = []
            for i, physical_index in enumerate(assignment):
                flip_x, flip_y = flags[2 * i:2 * i + 2]
                objects.append(object_points_for_face(
                    face_definitions[physical_index], flip_x, flip_y,
                ).reshape(-1, 3))
                orientations.append({
                    "detected_face": int(i),
                    "physical_face": int(physical_index),
                    "flip_x": bool(flip_x),
                    "flip_y": bool(flip_y),
                })
            all_obj = np.vstack(objects).astype(np.float64)
            try:
                ok, rvec, tvec = cv2.solvePnP(
                    all_obj, all_img, K_pnp, np.zeros(5),
                    flags=cv2.SOLVEPNP_ITERATIVE,
                )
            except cv2.error:
                continue
            if not ok:
                continue
            projected, depth = _project_full(
                all_obj, K, np.zeros(5), rvec.ravel(), tvec.ravel(),
            )
            positive_fraction = float(np.mean(depth > 0.0))
            negative_fraction = float(np.mean(depth < 0.0))
            if max(positive_fraction, negative_fraction) < 0.9:
                continue
            depth_sign = 1.0 if positive_fraction >= negative_fraction else -1.0
            rmse = float(np.sqrt(np.mean(np.sum((projected - all_img) ** 2, axis=1))))
            if best is None or rmse < best[0]:
                best = (rmse, all_obj, list(assignment), orientations,
                        rvec.ravel(), tvec.ravel(), depth_sign)

    if best is None:
        raise ValueError("No physically valid face assignment produced a PnP pose")
    _, all_obj, assignment, orientations, rvec, tvec, depth_sign = best
    return all_obj, all_img, assignment, orientations, rvec, tvec, depth_sign


def _pack_parameters(
    K: np.ndarray,
    dist: np.ndarray,
    rvec: np.ndarray,
    tvec: np.ndarray,
) -> np.ndarray:
    return np.array([
        math.log(K[0, 0]), math.log(K[1, 1]), K[0, 1], K[0, 2], K[1, 2],
        *np.asarray(dist, dtype=np.float64).reshape(5),
        *np.asarray(rvec, dtype=np.float64).reshape(3),
        *np.asarray(tvec, dtype=np.float64).reshape(3),
    ], dtype=np.float64)


def _unpack_parameters(params: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    p = np.asarray(params, dtype=np.float64)
    K = np.array([
        [math.exp(p[0]), p[2], p[3]],
        [0.0, math.exp(p[1]), p[4]],
        [0.0, 0.0, 1.0],
    ])
    return K, p[5:10].copy(), p[10:13].copy(), p[13:16].copy()


def _shared_axis_vanishing_residuals(
    K: np.ndarray,
    dist: np.ndarray,
    rvec: np.ndarray,
    line_corners: Sequence[np.ndarray],
    line_patterns: Sequence[Tuple[int, int]],
    image_size: Tuple[int, int],
) -> np.ndarray:
    """Incidence residuals for the X/Y/Z line pencils shared by two faces."""
    if len(line_corners) < 3 or len(line_patterns) < 3:
        return np.zeros(0, dtype=np.float64)
    rotation, _ = cv2.Rodrigues(
        np.asarray(rvec, dtype=np.float64).reshape(3, 1)
    )
    axis_pairs = ((0, 1), (0, 2), (1, 2))
    vanishing_points = []
    for axis in range(3):
        vp = rotation[:, axis]
        norm = float(np.linalg.norm(vp))
        if not np.isfinite(norm) or norm < 1e-12:
            return np.full(1, 1e3, dtype=np.float64)
        vanishing_points.append(vp / norm)

    def undistort_full_skew(points: np.ndarray) -> np.ndarray:
        pixels = np.asarray(points, dtype=np.float64).reshape(-1, 2)
        fy = float(K[1, 1])
        fx = float(K[0, 0])
        skew = float(K[0, 1])
        yd = (pixels[:, 1] - float(K[1, 2])) / fy
        xd = (
            pixels[:, 0] - float(K[0, 2]) - skew * yd
        ) / fx
        x = xd.copy()
        y = yd.copy()
        k1, k2, p1, p2, k3 = np.asarray(
            dist, dtype=np.float64,
        ).reshape(5)
        for _iteration in range(10):
            radius2 = x * x + y * y
            radial = (
                1.0 + k1 * radius2 + k2 * radius2 * radius2
                + k3 * radius2 * radius2 * radius2
            )
            radial = np.where(
                np.abs(radial) > 1e-9, radial, np.sign(radial) * 1e-9,
            )
            delta_x = 2.0 * p1 * x * y + p2 * (
                radius2 + 2.0 * x * x
            )
            delta_y = p1 * (radius2 + 2.0 * y * y) + 2.0 * p2 * x * y
            x = (xd - delta_x) / radial
            y = (yd - delta_y) / radial
        return np.column_stack([x, y])

    residuals = []

    def append_line(points: np.ndarray, vp: np.ndarray) -> None:
        if len(points) < 2:
            return
        homogeneous = np.column_stack([
            points,
            np.ones(len(points), dtype=np.float64),
        ])
        try:
            _u, _s, vt = np.linalg.svd(homogeneous, full_matrices=False)
        except np.linalg.LinAlgError:
            return
        line = vt[-1]
        line_norm = float(np.linalg.norm(line[:2]))
        if not np.isfinite(line_norm) or line_norm < 1e-12:
            return
        residuals.append(float((line / line_norm) @ vp))

    for face_index, (corners, pattern) in enumerate(zip(
        line_corners[:3], line_patterns[:3],
    )):
        cols, rows = int(pattern[0]), int(pattern[1])
        points = np.asarray(corners, dtype=np.float64).reshape(-1, 2)
        if len(points) != cols * rows:
            continue
        normalized = undistort_full_skew(points).reshape(rows, cols, 2)
        axis_x, axis_y = axis_pairs[face_index]
        for row in range(rows):
            append_line(normalized[row, :, :], vanishing_points[axis_x])
        for col in range(cols):
            append_line(normalized[:, col, :], vanishing_points[axis_y])
    return np.asarray(residuals, dtype=np.float64)


def _full_residuals(
    params: np.ndarray,
    object_points: np.ndarray,
    image_points: np.ndarray,
    depth_scale: float,
    depth_sign: float,
    high_order_reg_strength: float = 0.0,
    line_corners: Optional[Sequence[np.ndarray]] = None,
    line_patterns: Optional[Sequence[Tuple[int, int]]] = None,
    line_inlier_masks: Optional[Sequence[np.ndarray]] = None,
    line_weight: float = 0.0,
    intrinsic_prior: Optional[np.ndarray] = None,
    distortion_prior: Optional[np.ndarray] = None,
    image_size: Optional[Tuple[int, int]] = None,
    shared_axis_weight: float = 0.0,
) -> np.ndarray:
    K, dist, rvec, tvec = _unpack_parameters(params)
    projected, depth = _project_full(object_points, K, dist, rvec, tvec)
    image_residual = (projected - image_points).reshape(-1)
    # This is a physical feasibility term, not a camera prior: every observed
    # corner must remain in front of the camera during optimization.
    min_depth = max(1e-3, 0.01 * depth_scale)
    signed_depth = depth_sign * depth
    depth_penalty = 100.0 * np.maximum(0.0, min_depth - signed_depth) / depth_scale
    # Single-frame high-order distortion is weakly observable and otherwise
    # tends to absorb checker extraction errors.  Scale the regularizer with
    # point count so its meaning is stable across different board patterns.
    k1, k2, p1, p2, k3 = dist
    root_n = math.sqrt(len(object_points))
    high_order_regularization = high_order_reg_strength * root_n * np.array([
        0.75 * k2,
        16.00 * p1,
        16.00 * p2,
        0.75 * k3,
    ])
    residual_groups = [image_residual, depth_penalty, high_order_regularization]
    if line_weight > 0.0 and line_corners is not None and line_patterns is not None:
        residual_groups.append(
            line_weight * checker_line_residuals(
                dist, line_corners, line_patterns, K, line_inlier_masks,
            )
        )
    if (
        shared_axis_weight > 0.0
        and line_corners is not None
        and line_patterns is not None
        and image_size is not None
    ):
        residual_groups.append(
            shared_axis_weight * math.hypot(*image_size)
            * _shared_axis_vanishing_residuals(
                K, dist, rvec, line_corners, line_patterns, image_size,
            )
        )
    if intrinsic_prior is not None:
        if image_size is None:
            raise ValueError("image_size is required with an intrinsic prior")
        prior = np.asarray(intrinsic_prior, dtype=np.float64).reshape(3, 3)
        width, height = image_size
        diagonal = math.hypot(width, height)
        aspect = K[0, 0] / K[1, 1]
        prior_aspect = prior[0, 0] / prior[1, 1]
        mean_focal = math.sqrt(K[0, 0] * K[1, 1])
        prior_mean_focal = math.sqrt(prior[0, 0] * prior[1, 1])
        # A single frame needs a camera-shape prior, not an absolute focal
        # prior.  Keeping square-pixel ratio, skew, and principal point stable
        # still lets the cube perspective determine the common focal scale.
        intrinsic_regularization = root_n * np.array([
            2.0 * math.log(aspect / prior_aspect) / 0.08,
            2.0 * (K[0, 1] - prior[0, 1]) / (0.05 * diagonal),
            2.0 * (K[0, 2] - prior[0, 2]) / (0.12 * width),
            2.0 * (K[1, 2] - prior[1, 2]) / (0.12 * height),
            0.25 * math.log(mean_focal / prior_mean_focal) / 0.70,
        ])
        residual_groups.append(intrinsic_regularization)
    if distortion_prior is not None:
        prior_dist = np.asarray(distortion_prior, dtype=np.float64).reshape(5)
        distortion_regularization = 0.25 * root_n * np.array([
            (k1 - prior_dist[0]) / 0.25,
            (k2 - prior_dist[1]) / 0.12,
            (p1 - prior_dist[2]) / 0.015,
            (p2 - prior_dist[3]) / 0.015,
            (k3 - prior_dist[4]) / 0.12,
        ])
        residual_groups.append(distortion_regularization)
    return np.concatenate(residual_groups)


def _local_parameter_uncertainty(
    params: np.ndarray,
    jacobian: np.ndarray,
    cost: float,
    image_size: Tuple[int, int],
    target_span: float,
    observed_radius_px: float,
    active_indices: Optional[np.ndarray] = None,
) -> Dict[str, object]:
    """Approximate local posterior uncertainty from the final BA Jacobian."""
    packed = np.asarray(params, dtype=np.float64).reshape(16)
    jac = np.asarray(jacobian, dtype=np.float64)
    active = (
        np.arange(16, dtype=int)
        if active_indices is None
        else np.asarray(active_indices, dtype=int).reshape(-1)
    )
    singular_values = np.linalg.svd(jac, compute_uv=False)
    tolerance = (
        singular_values[0] * max(jac.shape) * np.finfo(np.float64).eps
        if len(singular_values) else math.inf
    )
    rank = int(np.sum(singular_values > tolerance))
    dof = max(int(jac.shape[0] - jac.shape[1]), 1)
    residual_variance = float(2.0 * cost / dof)
    active_covariance = residual_variance * np.linalg.pinv(
        jac.T @ jac, rcond=1e-12,
    )
    covariance = np.zeros((16, 16), dtype=np.float64)
    covariance[np.ix_(active, active)] = active_covariance
    diagonal = np.maximum(np.diag(covariance), 0.0)
    packed_std = np.sqrt(diagonal)
    K, dist, _rvec, _tvec = _unpack_parameters(packed)
    physical_std = np.array([
        K[0, 0] * packed_std[0],
        K[1, 1] * packed_std[1],
        packed_std[2], packed_std[3], packed_std[4],
        *packed_std[5:10], *packed_std[10:13], *packed_std[13:16],
    ], dtype=np.float64)
    names = [
        "fx", "fy", "skew", "cx", "cy",
        "k1", "k2", "p1", "p2", "k3",
        "rx", "ry", "rz", "tx", "ty", "tz",
    ]

    width, height = image_size
    image_diagonal = math.hypot(width, height)
    half_diagonal_radius_px = 0.5 * image_diagonal

    def distortion_effect(values: np.ndarray, radius_px: float) -> np.ndarray:
        camera, distortion, _rotation, _translation = _unpack_parameters(values)
        mean_focal = math.sqrt(camera[0, 0] * camera[1, 1])
        normalized_radius = radius_px / mean_focal
        radius2 = normalized_radius * normalized_radius
        k1, k2, p1, p2, k3 = distortion
        radial = k1 * radius2 + k2 * radius2 ** 2 + k3 * radius2 ** 3
        tangential = 3.0 * radius_px ** 2 * np.array([p1, p2]) / mean_focal
        return np.array([radial, tangential[0], tangential[1]])

    def effect_uncertainty(radius_px: float) -> np.ndarray:
        effect_jacobian = np.zeros((3, 16), dtype=np.float64)
        for index in range(16):
            step = 1e-6 * max(1.0, abs(float(packed[index])))
            plus = packed.copy()
            minus = packed.copy()
            plus[index] += step
            minus[index] -= step
            effect_jacobian[:, index] = (
                distortion_effect(plus, radius_px)
                - distortion_effect(minus, radius_px)
            ) / (2.0 * step)
        effect_covariance = effect_jacobian @ covariance @ effect_jacobian.T
        return np.sqrt(np.maximum(np.diag(effect_covariance), 0.0))

    observed_effect_std = effect_uncertainty(observed_radius_px)
    half_diagonal_effect_std = effect_uncertainty(half_diagonal_radius_px)

    denom = np.outer(packed_std, packed_std)
    correlation = np.divide(
        covariance,
        denom,
        out=np.zeros_like(covariance),
        where=denom > 1e-18,
    )
    np.fill_diagonal(correlation, 0.0)
    max_correlation = float(np.max(np.abs(correlation)))
    checks = {
        "full_rank": rank == len(active),
        "fx": physical_std[0] / max(K[0, 0], 1e-12) <= 0.20,
        "fy": physical_std[1] / max(K[1, 1], 1e-12) <= 0.20,
        "skew": physical_std[2] / image_diagonal <= 0.05,
        "principal_x": physical_std[3] / width <= 0.10,
        "principal_y": physical_std[4] / height <= 0.10,
        "radial_distortion_effect": observed_effect_std[0] <= 0.10,
        "tangential_distortion_effect": bool(
            (7 not in active and 8 not in active)
            or float(np.linalg.norm(observed_effect_std[1:])) <= 2.0
        ),
        "rotation": float(np.linalg.norm(physical_std[10:13])) <= 0.20,
        "translation": (
            float(np.linalg.norm(physical_std[13:16])) / max(target_span, 1.0)
            <= 0.50
        ),
    }
    checks = {name: bool(value) for name, value in checks.items()}
    return {
        "approximation": "soft-l1 local posterior from final joint BA Jacobian",
        "rank": rank,
        "parameter_count": int(len(active)),
        "active_parameter_indices": active.tolist(),
        "fixed_parameter_names": [
            names[index] for index in range(16) if index not in set(active.tolist())
        ],
        "residual_dof": dof,
        "residual_variance": residual_variance,
        "singular_values": singular_values.tolist(),
        "parameter_std_1sigma": {
            name: float(value) for name, value in zip(names, physical_std)
        },
        "observed_radius_px": float(observed_radius_px),
        "radial_scale_std_at_observed_radius": float(observed_effect_std[0]),
        "tangential_effect_std_px_at_observed_radius": float(
            np.linalg.norm(observed_effect_std[1:])
        ),
        "radial_scale_std_at_half_diagonal": float(half_diagonal_effect_std[0]),
        "tangential_effect_std_px_at_half_diagonal": float(
            np.linalg.norm(half_diagonal_effect_std[1:])
        ),
        "maximum_absolute_parameter_correlation": max_correlation,
        "checks": checks,
        "stable": bool(all(checks.values())),
    }


def _refine_full_parameters(
    K_init: np.ndarray,
    rvec_init: np.ndarray,
    tvec_init: np.ndarray,
    object_points: np.ndarray,
    image_points: np.ndarray,
    image_size: Tuple[int, int],
    depth_sign: float,
    dist_init: Optional[np.ndarray] = None,
    geometry_first: bool = True,
    line_corners: Optional[Sequence[np.ndarray]] = None,
    line_patterns: Optional[Sequence[Tuple[int, int]]] = None,
    line_inlier_masks: Optional[Sequence[np.ndarray]] = None,
    intrinsic_prior: Optional[np.ndarray] = None,
    distortion_prior: Optional[np.ndarray] = None,
    fix_tangential: bool = False,
    fix_high_order_radial: bool = False,
    shared_axis_weight: float = 0.0,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, float, Dict[str, object]]:
    width, height = image_size
    diagonal = math.hypot(width, height)
    target_span = float(np.linalg.norm(np.ptp(object_points, axis=0)))
    target_span = max(target_span, 1.0)
    initial_dist = (
        np.zeros(5, dtype=np.float64)
        if dist_init is None
        else np.asarray(dist_init, dtype=np.float64).reshape(5)
    )
    if fix_tangential:
        initial_dist = initial_dist.copy()
        initial_dist[2:4] = 0.0
    if fix_high_order_radial:
        initial_dist = initial_dist.copy()
        initial_dist[[1, 4]] = 0.0
    x0 = _pack_parameters(K_init, initial_dist, rvec_init, tvec_init)

    lower = np.array([
        math.log(0.30 * diagonal), math.log(0.30 * diagonal),
        -0.5 * diagonal, -0.25 * width, -0.25 * height,
        -0.8, -0.4, -0.05, -0.05, -0.3,
        -4.0 * math.pi, -4.0 * math.pi, -4.0 * math.pi,
        -np.inf, -np.inf, -np.inf,
    ])
    upper = np.array([
        math.log(5.0 * diagonal), math.log(5.0 * diagonal),
        0.5 * diagonal, 1.25 * width, 1.25 * height,
        0.8, 0.4, 0.05, 0.05, 0.3,
        4.0 * math.pi, 4.0 * math.pi, 4.0 * math.pi,
        np.inf, np.inf, np.inf,
    ])
    x0 = np.minimum(np.maximum(x0, lower + 1e-9), upper - 1e-9)

    # First settle K and pose with zero distortion, then release all five
    # distortion coefficients.  Both stages use only the same image evidence.
    geometry_indices = np.r_[0:5, 10:16]
    nfev_scale_raw = os.environ.get("CALIB_FULL_ZHANG_NFEV_SCALE", "1.0")
    try:
        nfev_scale = float(nfev_scale_raw)
    except ValueError:
        nfev_scale = 1.0
    if not math.isfinite(nfev_scale) or nfev_scale <= 0.0:
        nfev_scale = 1.0
    nfev_scale = float(np.clip(nfev_scale, 0.05, 1.0))
    tol_raw = os.environ.get("CALIB_FULL_ZHANG_OPT_TOL", "1e-11")
    try:
        opt_tol = float(tol_raw)
    except ValueError:
        opt_tol = 1e-11
    if not math.isfinite(opt_tol) or opt_tol <= 0.0:
        opt_tol = 1e-11

    def scaled_nfev(value: int) -> int:
        return max(25, int(math.ceil(float(value) * nfev_scale)))

    def solve_subset(
        base: np.ndarray,
        indices: np.ndarray,
        max_nfev: int,
        high_order_reg_strength: float = 0.0,
    ) -> Tuple[np.ndarray, object]:
        def residual_subset(values: np.ndarray) -> np.ndarray:
            full = base.copy()
            full[indices] = values
            return _full_residuals(
                full, object_points, image_points, target_span, depth_sign,
                high_order_reg_strength,
                line_corners=line_corners,
                line_patterns=line_patterns,
                line_inlier_masks=line_inlier_masks,
                line_weight=1.0,
                intrinsic_prior=intrinsic_prior,
                distortion_prior=distortion_prior,
                image_size=image_size,
                shared_axis_weight=shared_axis_weight,
            )

        result = least_squares(
            residual_subset,
            base[indices],
            bounds=(lower[indices], upper[indices]),
            method="trf",
            loss="soft_l1",
            f_scale=1.0,
            x_scale="jac",
            max_nfev=scaled_nfev(max_nfev),
            ftol=opt_tol,
            xtol=opt_tol,
            gtol=opt_tol,
        )
        updated = base.copy()
        updated[indices] = result.x
        return updated, result

    if geometry_first:
        stage1, first = solve_subset(x0, geometry_indices, 600)
    else:
        stage1, first = x0, None
    stage1 = stage1.copy()
    if geometry_first:
        stage1[6:10] = 0.0
    k1_indices = np.r_[0:6, 10:16]
    stage_k1, middle = solve_subset(stage1, k1_indices, 600)
    K_k1, dist_k1, rvec_k1, tvec_k1 = _unpack_parameters(stage_k1)
    projected_k1, _ = _project_full(
        object_points, K_k1, dist_k1, rvec_k1, tvec_k1,
    )
    k1_rmse = float(np.sqrt(np.mean(np.sum(
        (projected_k1 - image_points) ** 2, axis=1,
    ))))
    high_order_reg_strength = float(np.clip((k1_rmse - 0.25) / 2.0, 0.0, 1.0))
    radial_base = stage_k1.copy()
    radial_base[7:9] = 0.0
    if fix_high_order_radial:
        radial_base[[6, 9]] = 0.0
        radial_indices = np.r_[0:6, 10:16]
    else:
        radial_indices = np.r_[0:7, 9:16]
    stage_radial, radial = solve_subset(
        radial_base, radial_indices, 700, high_order_reg_strength,
    )
    K_radial, dist_radial, rvec_radial, tvec_radial = _unpack_parameters(
        stage_radial
    )
    projected_radial, _ = _project_full(
        object_points, K_radial, dist_radial, rvec_radial, tvec_radial,
    )
    radial_rmse = float(np.sqrt(np.mean(np.sum(
        (projected_radial - image_points) ** 2, axis=1,
    ))))
    fixed_indices = set()
    if fix_tangential:
        fixed_indices.update((7, 8))
    if fix_high_order_radial:
        fixed_indices.update((6, 9))
    final_indices = np.array([
        index for index in range(16) if index not in fixed_indices
    ], dtype=int)
    stage2, second = solve_subset(
        stage_radial, final_indices, 600, high_order_reg_strength,
    )
    K, dist, rvec, tvec = _unpack_parameters(stage2)
    projected, depth = _project_full(object_points, K, dist, rvec, tvec)
    rmse = float(np.sqrt(np.mean(np.sum((projected - image_points) ** 2, axis=1))))
    R, _ = cv2.Rodrigues(rvec.reshape(3, 1))
    final_line_rms = None
    if line_corners is not None and line_patterns is not None:
        final_line_rms = checker_line_rms(
            dist, line_corners, line_patterns, K, line_inlier_masks,
        )
    observed_radius_px = float(np.max(np.linalg.norm(
        image_points - np.array([K[0, 2], K[1, 2]]), axis=1,
    )))
    local_uncertainty = _local_parameter_uncertainty(
        stage2, second.jac, second.cost, image_size, target_span,
        observed_radius_px, active_indices=final_indices,
    )
    parameter_names = [
        "log_fx", "log_fy", "skew", "cx", "cy",
        "k1", "k2", "p1", "p2", "k3",
        "rx", "ry", "rz", "tx", "ty", "tz",
    ]
    parameters_near_bounds = []
    for index in final_indices:
        lo = float(lower[index])
        hi = float(upper[index])
        value = float(stage2[index])
        if np.isfinite(lo) and np.isfinite(hi):
            relative_margin = min(value - lo, hi - value) / max(hi - lo, 1e-12)
            if relative_margin <= 1e-4:
                parameters_near_bounds.append(parameter_names[index])
    local_uncertainty["parameters_near_active_bounds"] = parameters_near_bounds
    local_uncertainty["checks"]["active_parameter_bounds"] = bool(
        not parameters_near_bounds
    )
    local_uncertainty["stable"] = bool(
        all(local_uncertainty["checks"].values())
    )
    shared_axis_residuals = (
        _shared_axis_vanishing_residuals(
            K, dist, rvec, line_corners, line_patterns, image_size,
        )
        if line_corners is not None and line_patterns is not None
        else np.zeros(0, dtype=np.float64)
    )
    diagnostics = {
        "stage1_success": None if first is None else bool(first.success),
        "stage1_cost": None if first is None else float(first.cost),
        "stage1_nfev": 0 if first is None else int(first.nfev),
        "stage_k1_success": bool(middle.success),
        "stage_k1_cost": float(middle.cost),
        "stage_k1_nfev": int(middle.nfev),
        "stage_k1_rmse": k1_rmse,
        "stage_radial_success": bool(radial.success),
        "stage_radial_cost": float(radial.cost),
        "stage_radial_nfev": int(radial.nfev),
        "stage_radial_rmse": radial_rmse,
        "high_order_regularization_strength": high_order_reg_strength,
        "stage2_success": bool(second.success),
        "stage2_status": int(second.status),
        "stage2_cost": float(second.cost),
        "stage2_nfev": int(second.nfev),
        "stage2_message": str(second.message),
        "depth_sign": int(depth_sign),
        "minimum_depth": float(np.min(depth)),
        "maximum_depth": float(np.max(depth)),
        "minimum_signed_depth": float(np.min(depth_sign * depth)),
        "jacobian_condition": float(np.linalg.cond(second.jac)),
        "joint_checker_line_rms_px": final_line_rms,
        "intrinsic_soft_anchor_used": intrinsic_prior is not None,
        "distortion_soft_anchor_used": distortion_prior is not None,
        "tangential_fixed_by_observability": bool(fix_tangential),
        "high_order_radial_fixed_by_observability": bool(
            fix_high_order_radial
        ),
        "shared_axis_weight": float(shared_axis_weight),
        "shared_axis_line_count": int(len(shared_axis_residuals)),
        "nfev_scale": float(nfev_scale),
        "optimization_tolerance": float(opt_tol),
        "shared_axis_vp_rmse_px": (
            float(math.hypot(width, height) * np.sqrt(np.mean(
                shared_axis_residuals * shared_axis_residuals
            )))
            if len(shared_axis_residuals) else None
        ),
        "local_parameter_uncertainty": local_uncertainty,
    }
    return K, dist, R, tvec, rmse, diagnostics


def _camera_like_intrinsic_seed(
    K: np.ndarray,
    image_size: Tuple[int, int],
) -> bool:
    camera = np.asarray(K, dtype=np.float64).reshape(3, 3)
    width, height = image_size
    diagonal = math.hypot(width, height)
    fx, fy = float(camera[0, 0]), float(camera[1, 1])
    if not np.all(np.isfinite(camera)) or min(fx, fy) <= 0.0:
        return False
    aspect = max(fx, fy) / min(fx, fy)
    return bool(
        0.25 * diagonal <= min(fx, fy)
        and max(fx, fy) <= 3.0 * diagonal
        and aspect <= 1.35
        and abs(float(camera[0, 2]) - width / 2.0) <= 0.30 * width
        and abs(float(camera[1, 2]) - height / 2.0) <= 0.30 * height
        and abs(float(camera[0, 1])) <= 0.15 * min(fx, fy)
    )


def _multi_start_parameter_stability(
    anchored_solutions: Sequence[tuple],
    image_size: Tuple[int, int],
    apply_consensus_filter: bool = True,
) -> Dict[str, object]:
    """Summarize all-parameter convergence in physically comparable units."""
    width, height = image_size
    diagonal = math.hypot(width, height)
    half_diagonal_radius_px = 0.5 * diagonal
    count = len(anchored_solutions)
    if count == 0:
        return {
            "candidate_count": 0,
            "stable": False,
            "checks": {"candidate_count": False},
        }

    cameras = np.asarray([[
        float(item[2][0, 0]), float(item[2][1, 1]),
        float(item[2][0, 1]), float(item[2][0, 2]), float(item[2][1, 2]),
    ] for item in anchored_solutions], dtype=np.float64)
    distortions = np.asarray([
        np.asarray(item[3], dtype=np.float64).reshape(5)
        for item in anchored_solutions
    ])
    rotations = [np.asarray(item[4], dtype=np.float64).reshape(3, 3)
                 for item in anchored_solutions]
    translations = [np.asarray(item[5], dtype=np.float64).reshape(3)
                    for item in anchored_solutions]
    camera_positions = np.asarray([
        -rotation.T @ translation
        for rotation, translation in zip(rotations, translations)
    ])

    fx, fy, skew, cx, cy = cameras.T
    mean_focal = np.sqrt(fx * fy)
    aspect_log = np.log(fx / fy)
    k1, k2, p1, p2, k3 = distortions.T
    image_points = np.asarray(anchored_solutions[0][7], dtype=np.float64).reshape(-1, 2)
    consensus_center = np.array([np.median(cx), np.median(cy)])
    observed_radius_px = float(np.max(np.linalg.norm(
        image_points - consensus_center, axis=1,
    )))

    def distortion_effect(radius_px: float) -> Tuple[np.ndarray, np.ndarray]:
        normalized_radius = radius_px / mean_focal
        radius2 = normalized_radius * normalized_radius
        radial = k1 * radius2 + k2 * radius2 ** 2 + k3 * radius2 ** 3
        tangential = 3.0 * radius_px ** 2 * np.column_stack([
            p1 / mean_focal,
            p2 / mean_focal,
        ])
        return radial, tangential

    observed_radial_scale, observed_tangential_effect = distortion_effect(
        observed_radius_px,
    )
    half_radial_scale, half_tangential_effect = distortion_effect(
        half_diagonal_radius_px,
    )

    if apply_consensus_filter and count >= 4:
        features = np.column_stack([
            np.log(mean_focal) / 0.10,
            aspect_log / 0.05,
            skew / (0.01 * diagonal),
            cx / (0.02 * width),
            cy / (0.02 * height),
            observed_radial_scale / 0.10,
            observed_tangential_effect[:, 0] / 2.0,
            observed_tangential_effect[:, 1] / 2.0,
        ])
        distances = np.max(np.abs(
            features[:, None, :] - features[None, :, :]
        ), axis=2)
        medoid_index = int(np.argmin(np.median(distances, axis=1)))
        inlier_indices = np.flatnonzero(distances[medoid_index] <= 1.5)
        minimum_consensus = max(3, int(math.ceil(0.60 * count)))
        if minimum_consensus <= len(inlier_indices) < count:
            inlier_set = set(int(index) for index in inlier_indices)
            consensus = _multi_start_parameter_stability(
                [anchored_solutions[index] for index in inlier_indices],
                image_size,
                apply_consensus_filter=False,
            )
            consensus["total_candidate_count"] = int(count)
            consensus["consensus_candidate_count"] = int(len(inlier_indices))
            consensus["consensus_medoid_seed"] = str(
                anchored_solutions[medoid_index][1]
            )
            consensus["consensus_seed_names"] = [
                str(anchored_solutions[index][1]) for index in inlier_indices
            ]
            consensus["outlier_seed_names"] = [
                str(item[1]) for index, item in enumerate(anchored_solutions)
                if index not in inlier_set
            ]
            return consensus

    rotation_spread_deg = 0.0
    position_spread_mm = 0.0
    for first in range(count):
        for second in range(first + 1, count):
            relative = rotations[first] @ rotations[second].T
            cosine = np.clip((np.trace(relative) - 1.0) / 2.0, -1.0, 1.0)
            rotation_spread_deg = max(
                rotation_spread_deg, float(np.degrees(np.arccos(cosine))),
            )
            position_spread_mm = max(
                position_spread_mm,
                float(np.linalg.norm(
                    camera_positions[first] - camera_positions[second]
                )),
            )

    object_points = np.asarray(anchored_solutions[0][6], dtype=np.float64).reshape(-1, 3)
    target_span_mm = max(float(np.linalg.norm(np.ptp(object_points, axis=0))), 1.0)
    focal_relative_span = float(
        np.ptp(mean_focal) / max(float(np.median(mean_focal)), 1e-12)
    ) if count >= 2 else math.inf
    fx_relative_span = float(
        np.ptp(fx) / max(float(np.median(fx)), 1e-12)
    ) if count >= 2 else math.inf
    fy_relative_span = float(
        np.ptp(fy) / max(float(np.median(fy)), 1e-12)
    ) if count >= 2 else math.inf
    observed_radial_scale_span = (
        float(np.ptp(observed_radial_scale)) if count >= 2 else math.inf
    )

    def vector_span(values: np.ndarray) -> float:
        span = 0.0
        for first in range(count):
            for second in range(first + 1, count):
                span = max(
                    span, float(np.linalg.norm(values[first] - values[second])),
                )
        return span

    observed_tangential_effect_span = (
        vector_span(observed_tangential_effect) if count >= 2 else math.inf
    )
    half_radial_scale_span = (
        float(np.ptp(half_radial_scale)) if count >= 2 else math.inf
    )
    half_tangential_effect_span = (
        vector_span(half_tangential_effect) if count >= 2 else math.inf
    )

    checks = {
        "candidate_count": count >= 2,
        "fx": fx_relative_span <= 0.10,
        "fy": fy_relative_span <= 0.10,
        "aspect_ratio": float(np.ptp(aspect_log)) <= 0.05 if count >= 2 else False,
        "skew": float(np.ptp(skew) / diagonal) <= 0.01 if count >= 2 else False,
        "principal_x": float(np.ptp(cx) / width) <= 0.02 if count >= 2 else False,
        "principal_y": float(np.ptp(cy) / height) <= 0.02 if count >= 2 else False,
        "radial_distortion": observed_radial_scale_span <= 0.10,
        "tangential_distortion": observed_tangential_effect_span <= 2.0,
        "rotation": rotation_spread_deg <= 2.0,
        "camera_position": position_spread_mm / target_span_mm <= 0.25,
    }
    checks = {name: bool(value) for name, value in checks.items()}
    parameter_names = ["fx", "fy", "skew", "cx", "cy"]
    distortion_names = ["k1", "k2", "p1", "p2", "k3"]
    return {
        "candidate_count": int(count),
        "parameter_values": {
            **{name: cameras[:, index].tolist()
               for index, name in enumerate(parameter_names)},
            **{name: distortions[:, index].tolist()
               for index, name in enumerate(distortion_names)},
        },
        "parameter_ranges": {
            **{name: float(np.ptp(cameras[:, index]))
               for index, name in enumerate(parameter_names)},
            **{name: float(np.ptp(distortions[:, index]))
               for index, name in enumerate(distortion_names)},
        },
        "mean_focal_px": mean_focal.tolist(),
        "consensus_mean_focal_px": float(np.median(mean_focal)),
        "focal_relative_span": focal_relative_span,
        "fx_relative_span": fx_relative_span,
        "fy_relative_span": fy_relative_span,
        "aspect_log_span": float(np.ptp(aspect_log)) if count >= 2 else math.inf,
        "principal_x_span_px": float(np.ptp(cx)) if count >= 2 else math.inf,
        "principal_y_span_px": float(np.ptp(cy)) if count >= 2 else math.inf,
        "skew_span_px": float(np.ptp(skew)) if count >= 2 else math.inf,
        "observed_radius_px": observed_radius_px,
        "radial_scale_at_observed_radius": observed_radial_scale.tolist(),
        "radial_scale_span_at_observed_radius": observed_radial_scale_span,
        "tangential_effect_span_px_at_observed_radius": (
            observed_tangential_effect_span
        ),
        "radial_scale_at_half_diagonal": half_radial_scale.tolist(),
        "radial_scale_span_at_half_diagonal": half_radial_scale_span,
        "tangential_effect_span_px_at_half_diagonal": (
            half_tangential_effect_span
        ),
        "rotation_spread_deg": rotation_spread_deg if count >= 2 else math.inf,
        "camera_position_span_mm": position_spread_mm if count >= 2 else math.inf,
        "camera_position_relative_span": (
            position_spread_mm / target_span_mm if count >= 2 else math.inf
        ),
        "camera_positions_mm": camera_positions.tolist(),
        "checks": checks,
        "stable": bool(all(checks.values())),
    }


def calibrate_single_cube_zhang(
    detected_faces: Sequence[DetectedFace],
    image_size: Tuple[int, int],
    square_size: float = 25.0,
    face_definitions: Optional[Sequence[FaceDefinition]] = None,
    center_patterns_on_cube: bool = False,
    allow_face_permutations: bool = False,
    refinement_K_seeds: Optional[Sequence[np.ndarray]] = None,
    guard_refinement_K_seeds: bool = False,
    physical_parameter_seed: Optional[
        Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]
    ] = None,
    homography_image_points: Optional[Sequence[np.ndarray]] = None,
    shared_axis_weight: float = 0.04,
) -> SingleCubeZhangResult:
    """Calibrate all camera parameters from one visible three-face cube.

    Parameters
    ----------
    detected_faces:
        Exactly three row-major checker corner sets, one per visible face.
    image_size:
        ``(width, height)`` in pixels.
    square_size:
        The sole metric scale input.  Defaults to the project's 25 mm squares.
    face_definitions:
        Optional known checker placement on the three physical cube faces.
        If omitted, an orthogonal three-face target is constructed from the
        detected pattern dimensions.
    center_patterns_on_cube:
        When building the target automatically, infer centered placements from
        pattern extents while retaining square_size as the only metric input.
    allow_face_permutations:
        Search all physical face labels when the detector has not already
        normalized faces to XY/XZ/YZ.  Keep False when physical axis labels are
        known, because a cube's rotational symmetries otherwise relabel pose.
    refinement_K_seeds:
        Optional intrinsic initializers from earlier physical candidate
        recovery.  The Zhang solution is always retained as the first seed;
        these seeds only help the same unconstrained 16-parameter objective
        avoid a poor local minimum when checker placement was recovered first.
    guard_refinement_K_seeds:
        When True, externally supplied intrinsic seeds are treated as protected
        candidates: they may improve the result, but they are not allowed to
        redefine multi-start stability or replace an unguarded Zhang/camera
        seed unless reprojection quality is preserved.
    physical_parameter_seed:
        Optional ``(K, dist, R, t)`` from the existing physical-layout
        recovery cascade.  All 16 parameters are released immediately; this
        preserves earlier experimental gains without treating them as fixed.
    homography_image_points:
        Optional unmodified grid points used only for DLT/IAC initialization.
        This keeps extrapolated regular grids from being bent by a later local
        subpixel refinement; bundle adjustment still uses detected_faces.
    shared_axis_weight:
        Weight of the physical constraint that checker lines from two faces
        sharing X, Y, or Z must share one vanishing point.  The residual is
        normalized by image diagonal before this weight is applied.
    """
    if len(detected_faces) != 3:
        raise ValueError("A single-cube full calibration requires exactly three faces")
    valid_faces = [face for face in detected_faces if face.valid]
    if len(valid_faces) != 3:
        raise ValueError("All three cube faces must contain valid checker corners")
    if square_size <= 0.0:
        raise ValueError("square_size must be positive")

    if face_definitions is None:
        patterns = []
        for face in valid_faces:
            count = int(np.asarray(face.image_points).reshape(-1, 2).shape[0])
            # Existing detected faces carry object points in row-major order.
            # Prefer the common 9x6 board; otherwise infer from its 3-D layout.
            if count == 54:
                patterns.append((9, 6))
                continue
            obj = np.asarray(face.object_points).reshape(-1, 3)
            unique_counts = sorted(
                len(np.unique(np.round(obj[:, axis], decimals=5)))
                for axis in range(3)
                if len(np.unique(np.round(obj[:, axis], decimals=5))) > 1
            )
            if len(unique_counts) < 2 or unique_counts[-1] * unique_counts[-2] != count:
                raise ValueError(
                    "Cannot infer checker pattern; provide face_definitions explicitly"
                )
            patterns.append((unique_counts[-1], unique_counts[-2]))
        face_definitions = standard_three_face_target(
            square_size=square_size,
            face_patterns=patterns,
            n_faces=3,
            center_patterns_on_cube=center_patterns_on_cube,
        )
    else:
        face_definitions = list(face_definitions)
        if len(face_definitions) != 3:
            raise ValueError("face_definitions must contain three physical faces")

    homographies = []
    dlt_singular_values = []
    if homography_image_points is not None and len(homography_image_points) != 3:
        raise ValueError("homography_image_points must contain three faces")
    for face_index, (detected, definition) in enumerate(
        zip(valid_faces, face_definitions)
    ):
        local = _local_checker_points(definition.pattern_size, square_size)
        image_source = (
            detected.image_points
            if homography_image_points is None
            else homography_image_points[face_index]
        )
        image = np.asarray(image_source).reshape(-1, 2)
        if len(local) != len(image):
            raise ValueError("Detected corner count does not match face pattern")
        H, sv = normalized_dlt_homography(local, image)
        homographies.append(H)
        dlt_singular_values.append(sv.tolist())

    linear_K, zhang_diagnostics = zhang_intrinsics_from_homographies(homographies)
    width, height = image_size
    diagonal = math.hypot(width, height)
    linear_plausible = bool(
        0.1 * diagonal < linear_K[0, 0] < 10.0 * diagonal
        and 0.1 * diagonal < linear_K[1, 1] < 10.0 * diagonal
        and -width < linear_K[0, 2] < 2.0 * width
        and -height < linear_K[1, 2] < 2.0 * height
    )
    if not linear_plausible and not refinement_K_seeds:
        raise ValueError(f"Zhang initialization is numerically implausible: {linear_K}")

    seed_candidates = []
    if linear_plausible:
        seed_candidates.append(("zhang_linear", linear_K))
    for index, seed in enumerate(refinement_K_seeds or []):
        seed = np.asarray(seed, dtype=np.float64).reshape(3, 3)
        if (
            np.all(np.isfinite(seed))
            and 0.1 * diagonal < seed[0, 0] < 10.0 * diagonal
            and 0.1 * diagonal < seed[1, 1] < 10.0 * diagonal
        ):
            seed_candidates.append((f"physical_candidate_{index}", seed))
    replace_generic_sweep = (
        bool(refinement_K_seeds)
        and os.environ.get(
            "CALIB_ZHANG_VP_SEED_REPLACES_GENERIC_SWEEP", "0",
        ).strip().lower() in {"1", "true", "yes", "on"}
    )
    if not replace_generic_sweep:
        for index, focal_ratio in enumerate((0.35, 0.50, 0.70)):
            focal = float(focal_ratio * diagonal)
            sweep_seed = np.array([
                [focal, 0.0, width / 2.0],
                [0.0, focal, height / 2.0],
                [0.0, 0.0, 1.0],
            ])
            if all(
                abs(math.sqrt(existing[0, 0] * existing[1, 1]) - focal) > 25.0
                for _name, existing in seed_candidates
            ):
                seed_candidates.append((f"camera_shape_sweep_{index}", sweep_seed))
    if not seed_candidates:
        raise ValueError("No numerically usable intrinsic initializer")
    guarded_refinement_seed_names = {
        str(name) for name, _seed in seed_candidates
        if str(name).startswith("physical_candidate_")
    } if guard_refinement_K_seeds else set()

    plumbline_corners = [
        np.asarray(face.image_points).reshape(-1, 2) for face in valid_faces
    ]
    plumbline_patterns = [definition.pattern_size for definition in face_definitions]
    solutions = []
    attempt_diagnostics = []
    for seed_name, seed_K in seed_candidates:
        try:
            plumbline = estimate_checker_plumbline_distortion(
                plumbline_corners,
                plumbline_patterns,
                seed_K,
            )
            use_intrinsic_anchor = bool(
                seed_name != "zhang_linear"
                and _camera_like_intrinsic_seed(seed_K, image_size)
            )
            all_obj, all_img, assignment, orientations, rvec, tvec, depth_sign = (
                _enumerate_physical_correspondence(
                    valid_faces, face_definitions, seed_K,
                    allow_face_permutations,
                )
            )
            K, dist, R, t, rmse, refine_diagnostics = _refine_full_parameters(
                seed_K, rvec, tvec, all_obj, all_img, image_size, depth_sign,
                dist_init=plumbline.dist,
                line_corners=plumbline_corners,
                line_patterns=plumbline_patterns,
                line_inlier_masks=plumbline.line_inlier_masks,
                intrinsic_prior=seed_K if use_intrinsic_anchor else None,
                distortion_prior=(plumbline.dist if (
                    use_intrinsic_anchor and plumbline.success
                ) else None),
                shared_axis_weight=shared_axis_weight,
            )
            refine_diagnostics["plumbline_initialization"] = plumbline.to_dict()
            solutions.append((
                rmse, seed_name, K, dist, R, t, all_obj, all_img,
                assignment, orientations, refine_diagnostics,
            ))
            attempt_diagnostics.append({
                "seed": seed_name,
                "success": True,
                "rmse": float(rmse),
                "seed_K": seed_K.tolist(),
                "K": K.tolist(),
                "dist": dist.tolist(),
                "intrinsic_anchor_eligible": use_intrinsic_anchor,
                "plumbline": plumbline.to_dict(),
            })
        except Exception as exc:
            attempt_diagnostics.append({
                "seed": seed_name,
                "success": False,
                "error": str(exc),
            })

    if physical_parameter_seed is not None:
        try:
            seed_K, seed_dist, seed_R, seed_t = physical_parameter_seed
            seed_K = np.asarray(seed_K, dtype=np.float64).reshape(3, 3)
            seed_dist = np.asarray(seed_dist, dtype=np.float64).reshape(5)
            seed_R = np.asarray(seed_R, dtype=np.float64).reshape(3, 3)
            seed_t = np.asarray(seed_t, dtype=np.float64).reshape(3)
            plumbline = estimate_checker_plumbline_distortion(
                plumbline_corners,
                plumbline_patterns,
                seed_K,
            )
            use_intrinsic_anchor = _camera_like_intrinsic_seed(seed_K, image_size)
            physical_line_rms = checker_line_rms(
                seed_dist,
                plumbline_corners,
                plumbline_patterns,
                seed_K,
                plumbline.line_inlier_masks,
            )
            if (
                plumbline.success
                and plumbline.undistorted_rms_px + 1e-9 < physical_line_rms
            ):
                selected_seed_dist = plumbline.dist
                distortion_seed_source = "checker_plumbline"
            else:
                selected_seed_dist = seed_dist
                distortion_seed_source = "existing_physical_candidate"
            all_obj = np.vstack([
                np.asarray(face.object_points).reshape(-1, 3)
                for face in valid_faces
            ]).astype(np.float64)
            all_img = np.vstack([
                np.asarray(face.image_points).reshape(-1, 2)
                for face in valid_faces
            ]).astype(np.float64)
            seed_rvec, _ = cv2.Rodrigues(seed_R)
            _, seed_depth = _project_full(
                all_obj, seed_K, seed_dist, seed_rvec.ravel(), seed_t,
            )
            positive_fraction = float(np.mean(seed_depth > 0.0))
            negative_fraction = float(np.mean(seed_depth < 0.0))
            if max(positive_fraction, negative_fraction) < 0.9:
                raise ValueError("Physical seed has inconsistent corner depths")
            depth_sign = 1.0 if positive_fraction >= negative_fraction else -1.0
            K, dist, R, t, rmse, refine_diagnostics = _refine_full_parameters(
                seed_K, seed_rvec.ravel(), seed_t, all_obj, all_img,
                image_size, depth_sign, dist_init=selected_seed_dist,
                geometry_first=False,
                line_corners=plumbline_corners,
                line_patterns=plumbline_patterns,
                line_inlier_masks=plumbline.line_inlier_masks,
                intrinsic_prior=seed_K if use_intrinsic_anchor else None,
                distortion_prior=(selected_seed_dist if (
                    use_intrinsic_anchor and plumbline.success
                ) else None),
                shared_axis_weight=shared_axis_weight,
            )
            refine_diagnostics["plumbline_initialization"] = plumbline.to_dict()
            refine_diagnostics["distortion_seed_source"] = distortion_seed_source
            refine_diagnostics["existing_seed_line_rms_px"] = physical_line_rms
            assignment = list(range(3))
            orientations = [{
                "detected_face": int(i),
                "physical_face": int(i),
                "flip_x": None,
                "flip_y": None,
                "source": "existing_physical_correspondence",
            } for i in range(3)]
            solutions.append((
                rmse, "physical_parameter_seed", K, dist, R, t,
                all_obj, all_img, assignment, orientations,
                refine_diagnostics,
            ))
            attempt_diagnostics.append({
                "seed": "physical_parameter_seed",
                "success": True,
                "rmse": float(rmse),
                "seed_K": seed_K.tolist(),
                "K": K.tolist(),
                "dist": dist.tolist(),
                "intrinsic_anchor_eligible": use_intrinsic_anchor,
                "plumbline": plumbline.to_dict(),
                "distortion_seed_source": distortion_seed_source,
            })
        except Exception as exc:
            attempt_diagnostics.append({
                "seed": "physical_parameter_seed",
                "success": False,
                "error": str(exc),
            })
    if not solutions:
        details = "; ".join(
            f"{attempt.get('seed')}: {attempt.get('error', 'unknown error')}"
            for attempt in attempt_diagnostics
        )
        raise ValueError(f"All full-parameter refinement starts failed ({details})")

    anchored_solutions = [
        item for item in solutions
        if bool(item[10].get("intrinsic_soft_anchor_used", False))
    ]
    refinement_seed_guard = {
        "enabled": bool(guard_refinement_K_seeds),
        "guarded_seed_names": sorted(guarded_refinement_seed_names),
        "stability_reference": "all_anchored_seeds",
        "selection_action": "not_applicable",
    }
    stability_solutions = anchored_solutions
    if guarded_refinement_seed_names:
        unguarded_anchored_solutions = [
            item for item in anchored_solutions
            if str(item[1]) not in guarded_refinement_seed_names
        ]
        if len(unguarded_anchored_solutions) >= 2:
            stability_solutions = unguarded_anchored_solutions
            refinement_seed_guard["stability_reference"] = (
                "unguarded_anchored_seeds"
            )
            refinement_seed_guard["excluded_from_stability"] = [
                str(item[1]) for item in anchored_solutions
                if str(item[1]) in guarded_refinement_seed_names
            ]
        else:
            refinement_seed_guard["stability_reference"] = (
                "all_anchored_seeds_insufficient_unguarded_support"
            )
    multi_start_stability = _multi_start_parameter_stability(
        stability_solutions, image_size,
    )
    consensus_focal = multi_start_stability.get("consensus_mean_focal_px")
    consensus_outliers = set(
        multi_start_stability.get("outlier_seed_names", [])
    )

    def _solution_camera_like_and_score(item):
        rmse_value, _name, candidate_K, candidate_dist = item[:4]
        fx_value = float(candidate_K[0, 0])
        fy_value = float(candidate_K[1, 1])
        aspect = max(fx_value, fy_value) / max(min(fx_value, fy_value), 1e-9)
        center_offset = math.hypot(
            float(candidate_K[0, 2]) - width / 2.0,
            float(candidate_K[1, 2]) - height / 2.0,
        ) / diagonal
        skew_ratio = abs(float(candidate_K[0, 1])) / max(
            min(fx_value, fy_value), 1e-9,
        )
        camera_like = bool(
            aspect <= 1.35
            and abs(float(candidate_K[0, 2]) - width / 2.0) <= 0.30 * width
            and abs(float(candidate_K[1, 2]) - height / 2.0) <= 0.30 * height
            and skew_ratio <= 0.15
            and abs(float(candidate_dist[0])) < 0.95
            and abs(float(candidate_dist[1])) < 0.95
            and abs(float(candidate_dist[2])) < 0.095
            and abs(float(candidate_dist[3])) < 0.095
            and abs(float(candidate_dist[4])) < 0.95
        )
        stability_score = (
            float(rmse_value)
            + 5.0 * center_offset
            + 5.0 * abs(math.log(max(aspect, 1e-9)))
            + 5.0 * skew_ratio
        )
        if (
            consensus_focal is not None
            and bool(item[10].get("intrinsic_soft_anchor_used", False))
        ):
            candidate_mean_focal = math.sqrt(fx_value * fy_value)
            stability_score += 2.0 * abs(math.log(
                candidate_mean_focal / consensus_focal
            ))
        return camera_like, stability_score

    def _solution_rank(item):
        _rmse_value, _name, _candidate_K, _candidate_dist = item[:4]
        camera_like, stability_score = _solution_camera_like_and_score(item)
        consensus_outlier = str(_name) in consensus_outliers
        return (
            0 if camera_like and not consensus_outlier else
            1 if camera_like else 2,
            stability_score,
        )

    selected_solution = min(solutions, key=_solution_rank)
    if guarded_refinement_seed_names:
        refinement_seed_guard["selection_action"] = "selected_unguarded_seed"
        if str(selected_solution[1]) in guarded_refinement_seed_names:
            unguarded_solutions = [
                item for item in solutions
                if str(item[1]) not in guarded_refinement_seed_names
            ]
            tolerance = float(os.environ.get(
                "CALIB_REFINEMENT_K_SEED_MAX_RMSE_DEGRADATION_PX", "0.02",
            ))
            fallback_margin = float(os.environ.get(
                "CALIB_REFINEMENT_K_SEED_CAMERA_LIKE_MARGIN_PX", "0.50",
            ))
            refinement_seed_guard["max_rmse_degradation_px"] = float(tolerance)
            refinement_seed_guard["camera_like_margin_px"] = float(fallback_margin)
            refinement_seed_guard["selected_before_guard"] = str(
                selected_solution[1]
            )
            if unguarded_solutions:
                reference_solution = min(unguarded_solutions, key=_solution_rank)
                selected_camera_like, _selected_score = (
                    _solution_camera_like_and_score(selected_solution)
                )
                reference_camera_like, _reference_score = (
                    _solution_camera_like_and_score(reference_solution)
                )
                selected_rmse = float(selected_solution[0])
                reference_rmse = float(reference_solution[0])
                accept_guarded = bool(
                    selected_rmse <= reference_rmse + tolerance
                    or (
                        selected_camera_like
                        and not reference_camera_like
                        and selected_rmse <= reference_rmse + fallback_margin
                    )
                )
                refinement_seed_guard["reference_seed"] = str(
                    reference_solution[1]
                )
                refinement_seed_guard["reference_rmse_px"] = reference_rmse
                refinement_seed_guard["selected_before_guard_rmse_px"] = (
                    selected_rmse
                )
                refinement_seed_guard["reference_camera_like"] = bool(
                    reference_camera_like
                )
                refinement_seed_guard["selected_before_guard_camera_like"] = bool(
                    selected_camera_like
                )
                if accept_guarded:
                    refinement_seed_guard["selection_action"] = (
                        "accepted_guarded_seed"
                    )
                else:
                    selected_solution = reference_solution
                    refinement_seed_guard["selection_action"] = (
                        "reverted_to_unguarded_seed"
                    )
            else:
                refinement_seed_guard["selection_action"] = (
                    "kept_guarded_seed_no_unguarded_solution"
                )

    (
        rmse, selected_seed, K, dist, R, t, all_obj, all_img,
        assignment, orientations, refine_diagnostics,
    ) = selected_solution
    refinement_seed_guard["selected_after_guard"] = str(selected_seed)
    refinement_seed_guard["selected_after_guard_rmse_px"] = float(rmse)
    full_candidate = {
        "seed": str(selected_seed),
        "K": K.tolist(),
        "dist": dist.tolist(),
        "R": R.tolist(),
        "t": t.tolist(),
        "reproj_rmse": float(rmse),
        "local_parameter_uncertainty": refine_diagnostics.get(
            "local_parameter_uncertainty", {}
        ),
    }
    full_local_checks = refine_diagnostics.get(
        "local_parameter_uncertainty", {}
    ).get("checks", {})
    failed_full_local_checks = sorted(
        name for name, passed in full_local_checks.items() if not passed
    )
    multi_start_checks = multi_start_stability.get("checks", {})
    multi_start_core_stable = bool(
        multi_start_checks
        and all(
            passed for name, passed in multi_start_checks.items()
            if name != "tangential_distortion"
        )
    )
    full_model_confident = bool(
        multi_start_stability.get("stable", False)
        and refine_diagnostics.get("local_parameter_uncertainty", {}).get(
            "stable", False,
        )
    )
    selected_parameter_model = "full_16_parameter"
    observability_model_selection = {
        "full_candidate": full_candidate,
        "full_failed_local_checks": failed_full_local_checks,
        "multi_start_core_stable": multi_start_core_stable,
        "tangential_fixed_candidate_attempted": False,
        "tangential_fixed_candidate_accepted": False,
        "k1_only_candidate_attempted": False,
        "k1_only_candidate_accepted": False,
        "selection_reason": (
            "all_16_parameters_supported"
            if full_model_confident else "full_model_not_locally_identifiable"
        ),
    }

    # A weak p1/p2 pair must not be reported as measured merely because a
    # 16-parameter optimizer can assign it values.  If every other parameter
    # family is repeatable and the remaining local failure is tangential or
    # its coupled depth term, refit the same physical correspondences with
    # p1=p2 fixed to zero.
    radial_candidate_available = False
    radial_failed_local_checks: List[str] = []
    if (
        not full_model_confident
        and multi_start_core_stable
        and "tangential_distortion_effect" in failed_full_local_checks
    ):
        observability_model_selection["tangential_fixed_candidate_attempted"] = True
        try:
            radial_dist_init = np.asarray(dist, dtype=np.float64).reshape(5).copy()
            radial_dist_init[2:4] = 0.0
            selected_rvec, _ = cv2.Rodrigues(
                np.asarray(R, dtype=np.float64).reshape(3, 3)
            )
            radial_plumbline = estimate_checker_plumbline_distortion(
                plumbline_corners, plumbline_patterns, K,
            )
            (
                radial_K, radial_dist, radial_R, radial_t, radial_rmse,
                radial_diagnostics,
            ) = _refine_full_parameters(
                K, selected_rvec.ravel(), t, all_obj, all_img,
                image_size, float(refine_diagnostics["depth_sign"]),
                dist_init=radial_dist_init,
                geometry_first=False,
                line_corners=plumbline_corners,
                line_patterns=plumbline_patterns,
                line_inlier_masks=radial_plumbline.line_inlier_masks,
                intrinsic_prior=K,
                distortion_prior=radial_dist_init,
                fix_tangential=True,
                shared_axis_weight=shared_axis_weight,
            )
            radial_local = radial_diagnostics.get(
                "local_parameter_uncertainty", {}
            )
            radial_candidate_available = True
            radial_failed_local_checks = sorted(
                name for name, passed in radial_local.get("checks", {}).items()
                if not passed
            )
            radial_accepted = bool(
                radial_local.get("stable", False)
                and radial_diagnostics.get("minimum_signed_depth", -math.inf) > 0.0
                and np.isfinite(radial_rmse)
                and radial_rmse <= rmse + 0.5
            )
            observability_model_selection["tangential_fixed_candidate"] = {
                "K": radial_K.tolist(),
                "dist": radial_dist.tolist(),
                "R": radial_R.tolist(),
                "t": radial_t.tolist(),
                "reproj_rmse": float(radial_rmse),
                "rmse_increase_px": float(radial_rmse - rmse),
                "local_parameter_uncertainty": radial_local,
                "failed_local_checks": radial_failed_local_checks,
                "accepted": radial_accepted,
            }
            if radial_accepted:
                K, dist, R, t, rmse = (
                    radial_K, radial_dist, radial_R, radial_t, radial_rmse,
                )
                refine_diagnostics = radial_diagnostics
                selected_parameter_model = "tangential_fixed_14_parameter"
                observability_model_selection[
                    "tangential_fixed_candidate_accepted"
                ] = True
                observability_model_selection["selection_reason"] = (
                    "p1_p2_not_observable_fixed_to_zero"
                )
            else:
                observability_model_selection["selection_reason"] = (
                    "tangential_fixed_candidate_failed_confidence_gate"
                )
        except Exception as exc:
            observability_model_selection["tangential_fixed_error"] = str(exc)
            observability_model_selection["selection_reason"] = (
                "tangential_fixed_candidate_failed"
            )

    # If fixing p1/p2 leaves only the focal-depth direction weak, remove k2
    # and k3 as well.  A small target rarely spans enough image radius to
    # distinguish those powers from focal scale and camera depth.  k1 remains
    # estimated, so this is a 12-parameter camera-plus-pose model.
    if (
        radial_candidate_available
        and not observability_model_selection[
            "tangential_fixed_candidate_accepted"
        ]
    ):
        observability_model_selection["k1_only_candidate_attempted"] = True
        try:
            k1_dist_init = np.asarray(
                radial_dist, dtype=np.float64,
            ).reshape(5).copy()
            k1_dist_init[1:] = 0.0
            radial_rvec, _ = cv2.Rodrigues(
                np.asarray(radial_R, dtype=np.float64).reshape(3, 3)
            )
            (
                k1_K, k1_dist, k1_R, k1_t, k1_rmse, k1_diagnostics,
            ) = _refine_full_parameters(
                radial_K, radial_rvec.ravel(), radial_t, all_obj, all_img,
                image_size, float(radial_diagnostics["depth_sign"]),
                dist_init=k1_dist_init,
                geometry_first=False,
                line_corners=plumbline_corners,
                line_patterns=plumbline_patterns,
                line_inlier_masks=radial_plumbline.line_inlier_masks,
                intrinsic_prior=radial_K,
                distortion_prior=k1_dist_init,
                fix_tangential=True,
                fix_high_order_radial=True,
                shared_axis_weight=shared_axis_weight,
            )
            k1_local = k1_diagnostics.get("local_parameter_uncertainty", {})
            k1_failed_local_checks = sorted(
                name for name, passed in k1_local.get("checks", {}).items()
                if not passed
            )
            k1_accepted = bool(
                k1_local.get("stable", False)
                and k1_diagnostics.get("minimum_signed_depth", -math.inf) > 0.0
                and np.isfinite(k1_rmse)
                and k1_rmse <= full_candidate["reproj_rmse"] + 0.5
            )
            observability_model_selection["k1_only_candidate"] = {
                "K": k1_K.tolist(),
                "dist": k1_dist.tolist(),
                "R": k1_R.tolist(),
                "t": k1_t.tolist(),
                "reproj_rmse": float(k1_rmse),
                "rmse_increase_px": float(
                    k1_rmse - full_candidate["reproj_rmse"]
                ),
                "local_parameter_uncertainty": k1_local,
                "failed_local_checks": k1_failed_local_checks,
                "accepted": k1_accepted,
            }
            if k1_accepted:
                K, dist, R, t, rmse = k1_K, k1_dist, k1_R, k1_t, k1_rmse
                refine_diagnostics = k1_diagnostics
                selected_parameter_model = "k1_only_12_parameter"
                observability_model_selection["k1_only_candidate_accepted"] = True
                observability_model_selection["selection_reason"] = (
                    "p1_p2_k2_k3_not_observable_fixed_to_zero"
                )
            else:
                observability_model_selection["selection_reason"] = (
                    "k1_only_candidate_failed_confidence_gate"
                )
        except Exception as exc:
            observability_model_selection["k1_only_error"] = str(exc)
            observability_model_selection["selection_reason"] = (
                "k1_only_candidate_failed"
            )

    diagnostics = {
        **zhang_diagnostics,
        **refine_diagnostics,
        "linear_K_plausible": linear_plausible,
        "selected_refinement_seed": selected_seed,
        "refinement_seed_names": [str(name) for name, _seed in seed_candidates],
        "generic_sweep_replaced_by_refinement_seed": bool(replace_generic_sweep),
        "refinement_k_seed_guard": refinement_seed_guard,
        "refinement_attempts": attempt_diagnostics,
        "dlt_singular_values": dlt_singular_values,
        "corner_count": int(len(all_img)),
        "square_size": float(square_size),
        "image_size": [int(width), int(height)],
        "parameter_order": [
            "fx", "fy", "skew", "cx", "cy",
            "k1", "k2", "p1", "p2", "k3",
            "rx", "ry", "rz", "tx", "ty", "tz",
        ],
        "multi_start_stability": multi_start_stability,
        "shared_axis_weight": float(shared_axis_weight),
        "selected_parameter_model": selected_parameter_model,
        "observability_model_selection": observability_model_selection,
    }
    local_stable = bool(
        refine_diagnostics.get("local_parameter_uncertainty", {}).get(
            "stable", False,
        )
    )
    selected_model_confident = bool(
        full_model_confident
        if selected_parameter_model == "full_16_parameter"
        else multi_start_core_stable and local_stable
    )
    diagnostics["full_parameter_confidence"] = {
        "multi_start_stable": bool(multi_start_stability.get("stable", False)),
        "multi_start_core_stable": multi_start_core_stable,
        "local_identifiable": local_stable,
        "confident": selected_model_confident,
        "calibration_model_confident": selected_model_confident,
        "full_16_parameter_confident": full_model_confident,
        "selected_parameter_model": selected_parameter_model,
        "estimated_parameter_count": {
            "full_16_parameter": 16,
            "tangential_fixed_14_parameter": 14,
            "k1_only_12_parameter": 12,
        }[selected_parameter_model],
        "fixed_parameter_names": {
            "full_16_parameter": [],
            "tangential_fixed_14_parameter": ["p1", "p2"],
            "k1_only_12_parameter": ["k2", "p1", "p2", "k3"],
        }[selected_parameter_model],
        "status": (
            "full_parameter_confident"
            if full_model_confident
            else "core_parameter_confident_tangential_fixed"
            if selected_model_confident
            and selected_parameter_model == "tangential_fixed_14_parameter"
            else "core_parameter_confident_k1_only"
            if selected_model_confident
            and selected_parameter_model == "k1_only_12_parameter"
            else "regularized_full_candidate"
            if multi_start_core_stable
            else "unstable_full_candidate"
        ),
    }
    success = bool(
        np.all(np.isfinite(K))
        and np.all(np.isfinite(dist))
        and np.all(np.isfinite(R))
        and np.all(np.isfinite(t))
        and refine_diagnostics["minimum_signed_depth"] > 0.0
    )
    return SingleCubeZhangResult(
        K=K,
        dist=dist,
        R=R,
        t=t,
        reproj_rmse=rmse,
        linear_K=linear_K,
        homographies=homographies,
        face_assignment=assignment,
        face_orientations=orientations,
        object_points=all_obj,
        image_points=all_img,
        success=success,
        message=(
            "single-image cube calibration completed with k1-only distortion "
            "selected by observability"
            if success and selected_parameter_model == "k1_only_12_parameter"
            else
            "single-image cube calibration completed with p1/p2 fixed by "
            "observability"
            if success and selected_parameter_model == "tangential_fixed_14_parameter"
            else "full single-image cube Zhang calibration completed" if success
            else "optimization ended without a physically valid solution"
        ),
        diagnostics=diagnostics,
    )


def _run_npz_cli(path: str) -> None:
    data = np.load(path, allow_pickle=True)
    detected = [
        DetectedFace(image_points=img, object_points=obj, valid=True)
        for img, obj in zip(data["image_points"], data["object_points"])
    ]
    square_size = float(data["square_size"])
    cols = int(data["pattern_cols"])
    rows = int(data["pattern_rows"])
    definitions = standard_three_face_target(square_size, cols, rows)
    result = calibrate_single_cube_zhang(
        detected,
        image_size=(1920, 1080),
        square_size=square_size,
        face_definitions=definitions,
    )
    output = result.to_dict()
    if "K_gt" in data:
        output["ground_truth"] = {
            "K": data["K_gt"].tolist(),
            "dist": data["dist_gt"].tolist(),
            "R": data["R_gt"].tolist(),
            "t": data["t_gt"].tolist(),
        }
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Full Zhang calibration from one three-face cube image",
    )
    parser.add_argument("npz", nargs="?", default="test_calib_data.npz")
    args = parser.parse_args()
    _run_npz_cli(args.npz)
