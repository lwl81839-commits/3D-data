#!/usr/bin/env python3
"""Targeted SAM + rectification probe for missing XY 9x6 faces."""

from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import cv2
import numpy as np
import torch
from segment_anything import SamPredictor, sam_model_registry

from face_detector import (
    _cluster_dark_components,
    _cube_detection_best_offset_pnp_rmse,
    _cube_detection_geometry_rmse,
    _detect_cube_first,
    _label_cube_clusters,
    _normalize_face_axis_order,
    _rectified_face_variants,
)
from three_face_calib import preprocess_image


PATTERNS = [(9, 6), (6, 9)]
LABEL_ORDER = {"XY": 0, "XZ": 1, "YZ": 2}


def read_image(path: Path) -> np.ndarray:
    data = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError(f"failed to read image: {path}")
    return image


def load_rel_paths(path: Path):
    return [
        line.strip().replace("\\", "/")
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]


def expand_box(poly, shape, scale):
    h, w = shape[:2]
    pts = np.asarray(poly, dtype=np.float32).reshape(-1, 2)
    center = pts.mean(axis=0)
    pts = center + (pts - center) * float(scale)
    x1, y1 = pts.min(axis=0)
    x2, y2 = pts.max(axis=0)
    pad = max(8.0, 0.06 * max(x2 - x1, y2 - y1))
    return np.array([
        max(0.0, x1 - pad),
        max(0.0, y1 - pad),
        min(float(w - 1), x2 + pad),
        min(float(h - 1), y2 + pad),
    ], dtype=np.float32)


def mask_to_poly(mask):
    mask_u8 = (mask.astype(np.uint8) * 255)
    contours, _ = cv2.findContours(mask_u8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    contour = max(contours, key=cv2.contourArea)
    if cv2.contourArea(contour) < 150:
        return None
    hull = cv2.convexHull(contour).reshape(-1, 2).astype(np.float32)
    if len(hull) < 4:
        return None
    eps = 0.015 * cv2.arcLength(hull.reshape(-1, 1, 2), True)
    approx = cv2.approxPolyDP(hull.reshape(-1, 1, 2), eps, True).reshape(-1, 2)
    return approx.astype(np.float32) if len(approx) >= 4 else hull


def try_rectified(gray, poly, source):
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    attempts = []
    for idx, (rectified, h_inv) in enumerate(_rectified_face_variants(gray, poly)):
        for variant_name, work in (
            ("pre", preprocess_image(rectified)),
            ("eq", cv2.equalizeHist(rectified)),
            ("raw", rectified),
        ):
            for pat in PATTERNS:
                t0 = time.time()
                ok, corners = cv2.findChessboardCorners(work, pat, flags=flags)
                attempts.append((source, f"rect{idx}-{variant_name}", pat, ok, time.time() - t0))
                if ok and corners is not None:
                    mapped = cv2.perspectiveTransform(corners.astype(np.float32), h_inv)
                    return {
                        "found": True,
                        "source": source,
                        "method": f"rect{idx}-{variant_name}-classic",
                        "pattern": pat,
                        "corners": mapped.reshape(-1, 2).tolist(),
                        "attempts": attempts,
                    }
                if hasattr(cv2, "findChessboardCornersSB"):
                    t0 = time.time()
                    ok, corners = cv2.findChessboardCornersSB(
                        work, pat, flags=cv2.CALIB_CB_NORMALIZE_IMAGE)
                    attempts.append((source, f"rect{idx}-{variant_name}", pat, ok, time.time() - t0))
                    if ok and corners is not None:
                        mapped = cv2.perspectiveTransform(corners.astype(np.float32), h_inv)
                        return {
                            "found": True,
                            "source": source,
                            "method": f"rect{idx}-{variant_name}-SB",
                            "pattern": pat,
                            "corners": mapped.reshape(-1, 2).tolist(),
                            "attempts": attempts,
                        }
    return {"found": False, "attempts": attempts}


def pattern_exact(pattern, wanted):
    obs = (max(int(pattern[0]), int(pattern[1])),
           min(int(pattern[0]), int(pattern[1])))
    ref = (max(int(wanted[0]), int(wanted[1])),
           min(int(wanted[0]), int(wanted[1])))
    return obs == ref


def combo_stats(gray, xy_corners, xy_pattern, direct):
    sides = {}
    for corners, pat, label in direct:
        if label == "XZ" and pattern_exact(pat, (9, 6)):
            sides["XZ"] = (corners, pat, label)
        if label == "YZ" and pattern_exact(pat, (6, 6)):
            sides["YZ"] = (corners, pat, label)
    if "XZ" not in sides or "YZ" not in sides:
        return {
            "combo_status": "missing_side",
            "combo_sides": ",".join(sorted(sides)),
        }
    dets = [(xy_corners, xy_pattern, "XY"), sides["XZ"], sides["YZ"]]
    dets = _normalize_face_axis_order(dets)
    centered = _cube_detection_geometry_rmse(
        dets, gray.shape, n_faces=3, allow_sparse=False,
        assume_normalized=True)
    offset_rmse, offset, offset_dist = _cube_detection_best_offset_pnp_rmse(
        dets, gray.shape, n_faces=3, assume_normalized=True)
    return {
        "combo_status": "combo",
        "combo_patterns": ";".join(
            f"{label}:{pat[0]}x{pat[1]}"
            for _c, pat, label in sorted(dets, key=lambda d: LABEL_ORDER.get(d[2], 99))
        ),
        "combo_centered_pnp": float(centered) if np.isfinite(centered) else None,
        "combo_offset_pnp": float(offset_rmse) if np.isfinite(offset_rmse) else None,
        "combo_offset": str(offset),
        "combo_offset_dist": float(offset_dist) if np.isfinite(offset_dist) else None,
    }


def probe_one(path: Path, rel: str, predictor: SamPredictor, out_dir: Path):
    image = read_image(path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    direct = _detect_cube_first(gray, n_faces=3, verbose=False)
    direct_desc = ";".join(f"{label}:{pat[0]}x{pat[1]}" for _c, pat, label in direct)
    clusters = _label_cube_clusters(_cluster_dark_components(gray, n_faces=3, verbose=False))
    xy = next((face for face in clusters if face.get("label") == "XY"), None)
    if xy is None:
        return {"rel_path": rel, "status": "no_xy_cluster", "direct": direct_desc}

    polys = [("cluster", np.asarray(xy["poly"], dtype=np.float32))]
    predictor.set_image(rgb)
    for scale in (1.18, 1.42):
        box = expand_box(xy["poly"], gray.shape, scale)
        masks, scores, _ = predictor.predict(box=box, multimask_output=True)
        ranked = sorted(enumerate(zip(masks, scores)), key=lambda item: float(item[1][1]), reverse=True)[:2]
        for mask_idx, (mask, score) in ranked:
            poly = mask_to_poly(mask)
            if poly is not None:
                polys.append((f"sam{mask_idx}-s{scale:.2f}-{float(score):.3f}", poly))

    best_attempts = []
    for source, poly in polys:
        result = try_rectified(gray, poly, source)
        best_attempts.extend(result.get("attempts", []))
        if result.get("found"):
            overlay = image.copy()
            pts = np.asarray(result["corners"], dtype=np.float32)
            for x, y in pts:
                cv2.circle(overlay, (int(round(x)), int(round(y))), 2, (0, 220, 255), -1)
            out_name = rel.replace("/", "__").replace("\\", "__")
            (out_dir / "xy_overlays").mkdir(parents=True, exist_ok=True)
            cv2.imwrite(str(out_dir / "xy_overlays" / f"{out_name}.jpg"), overlay)
            row = {
                "rel_path": rel,
                "status": "found",
                "direct": direct_desc,
                "source": result["source"],
                "method": result["method"],
                "pattern": f"{result['pattern'][0]}x{result['pattern'][1]}",
                "attempts": len(best_attempts),
            }
            row.update(combo_stats(
                gray,
                np.asarray(result["corners"], dtype=np.float32).reshape(-1, 1, 2),
                result["pattern"],
                direct,
            ))
            return row
    return {
        "rel_path": rel,
        "status": "not_found",
        "direct": direct_desc,
        "polys": len(polys),
        "attempts": len(best_attempts),
        "positive_attempts": sum(1 for _s, _m, _p, ok, _dt in best_attempts if ok),
        "max_attempt_sec": max([dt for *_rest, dt in best_attempts], default=0.0),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--rel-list", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--model-type", default="vit_b")
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    sam = sam_model_registry[args.model_type](checkpoint=str(args.checkpoint))
    sam.to(device=device)
    predictor = SamPredictor(sam)
    rows = []
    for rel in load_rel_paths(args.rel_list):
        print(f"START {rel}", flush=True)
        try:
            row = probe_one(args.image_root / rel, rel, predictor, args.out_dir)
        except Exception as exc:
            row = {"rel_path": rel, "status": "error", "error": str(exc)}
        print(json.dumps(row, ensure_ascii=False), flush=True)
        rows.append(row)
    (args.out_dir / "sam_xy_deep_results.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    fields = sorted({key for row in rows for key in row})
    with (args.out_dir / "sam_xy_deep_results.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
