#!/usr/bin/env python3
"""SAM deep two-face physical calibration probe.

Offline experiment only.  This reuses the SAM + rectified face recovery path
from ``sam_three_face_deep_calibrate_probe.py``.  When a full three-face combo
is still unavailable, it checks whether any two recovered physical faces give a
stable single-view cube solution.  The result is diagnostic/review-only; it is
not a product acceptance gate.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

import cv2
import numpy as np
import torch
from segment_anything import SamPredictor, sam_model_registry

from best_calibration import (
    _single_view_k1_fallback,
    _single_view_zero_dist_fallback,
)
from face_detector import _detect_cube_first, estimate_cube_area_pct
from partial_offset_probe import _build_points, _intrinsics_from_vps
from sam_three_face_deep_calibrate_probe import (
    PHYSICAL_LABELS,
    add_direct_candidates,
    recover_needed_candidates,
)
from sam_xy_calibrate_probe import load_rel_paths, pattern_exact
from sam_xy_deep_probe import read_image


TARGET_PATTERNS = {"XY": (9, 6), "XZ": (9, 6), "YZ": (6, 6)}


def _jsonable(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return value


def _candidate_desc(candidates: Sequence[Tuple]) -> str:
    parts = []
    for _score, _corners, pat, label, source in candidates[:5]:
        parts.append(f"{label}:{int(pat[0])}x{int(pat[1])}:{source}")
    return ";".join(parts)


def _target_match(label: str, pattern: Tuple[int, int]) -> bool:
    return label in TARGET_PATTERNS and pattern_exact(pattern, TARGET_PATTERNS[label])


def _target_specs(labels: Sequence[str]) -> Dict[str, Dict[str, Tuple[int, int]]]:
    return {
        label: {"full_pattern": TARGET_PATTERNS[label], "offset": (0, 0)}
        for label in labels
    }


def _project_rmse(
    object_points: np.ndarray,
    image_points: np.ndarray,
    K: np.ndarray,
    dist: np.ndarray,
    R: np.ndarray,
    t: np.ndarray,
) -> float:
    rvec, _ = cv2.Rodrigues(R.astype(np.float64))
    proj, _ = cv2.projectPoints(
        object_points.reshape(-1, 1, 3).astype(np.float64),
        rvec,
        t.reshape(3, 1).astype(np.float64),
        K.astype(np.float64),
        dist.reshape(-1).astype(np.float64),
    )
    diff = proj.reshape(-1, 2) - image_points.reshape(-1, 2)
    return float(np.sqrt(np.mean(np.sum(diff * diff, axis=1))))


def _fit_two_face_models(
    dets: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    image_shape: Tuple[int, int],
    *,
    rmse_limit: float,
) -> List[Dict[str, Any]]:
    labels = [label for _corners, _pattern, label in dets]
    if len(dets) != 2 or len(set(labels)) != 2:
        return []
    if any(not _target_match(label, pattern) for _corners, pattern, label in dets):
        return []

    h, w = image_shape[:2]
    diag = float(np.hypot(w, h))
    focal_lo = 0.30 * diag
    focal_hi = 3.0 * diag
    try:
        K_seed = _intrinsics_from_vps(dets, (w, h))
    except Exception:
        K_seed = np.array(
            [[0.80 * diag, 0.0, w / 2.0],
             [0.0, 0.80 * diag, h / 2.0],
             [0.0, 0.0, 1.0]],
            dtype=np.float64,
        )

    specs = _target_specs(labels)
    flip_options = itertools.product(
        [(False, False), (True, False), (False, True), (True, True)],
        repeat=len(dets),
    )
    out: List[Dict[str, Any]] = []
    for flips in flip_options:
        object_points, image_points = _build_points(dets, specs, flips)
        for model, fn in (
            ("single-view-zero-dist", _single_view_zero_dist_fallback),
            ("single-view-k1", _single_view_k1_fallback),
        ):
            result = fn(
                object_points,
                image_points,
                (w, h),
                K_seed,
                focal_lo,
                focal_hi,
                rmse_limit,
            )
            if result is None:
                continue
            K, dist, R, t, rmse = result
            refined_rmse = _project_rmse(object_points, image_points, K, dist, R, t)
            rmse = min(float(rmse), refined_rmse)
            if not math.isfinite(rmse) or rmse > rmse_limit:
                continue
            k1 = float(dist.reshape(-1)[0]) if dist is not None and len(dist.reshape(-1)) else 0.0
            out.append({
                "model": model,
                "rmse_px": rmse,
                "fx_px": float(K[0, 0]),
                "fy_px": float(K[1, 1]),
                "cx_px": float(K[0, 2]),
                "cy_px": float(K[1, 2]),
                "k1": k1,
                "labels": ",".join(labels),
                "patterns": ",".join(f"{p[0]}x{p[1]}" for _c, p, _l in dets),
                "flips": [[bool(a), bool(b)] for a, b in flips],
                "specs": specs,
                "K": K.copy(),
                "dist": dist.reshape(-1).copy(),
                "R": R.copy(),
                "t": np.asarray(t, dtype=np.float64).reshape(3).copy(),
            })
    out.sort(key=lambda row: (
        float(row["rmse_px"]),
        0 if row["model"] == "single-view-zero-dist" else 1,
        abs(float(row["k1"])),
    ))
    return out


def _all_two_face_combos(by_label: Dict[str, List[Tuple]]) -> Iterable[List[Tuple]]:
    for label_a, label_b in itertools.combinations(PHYSICAL_LABELS, 2):
        for cand_a, cand_b in itertools.product(by_label[label_a], by_label[label_b]):
            raw = [cand_a, cand_b]
            dets = [(c, p, l) for _s, c, p, l, _src in raw]
            if all(_target_match(label, pattern) for _corners, pattern, label in dets):
                yield raw


def save_overlay(
    image: np.ndarray,
    rel: str,
    raw_combo: Sequence[Tuple],
    out_dir: Path,
) -> None:
    colors = {"XY": (0, 220, 255), "XZ": (0, 180, 0), "YZ": (255, 80, 0)}
    vis = image.copy()
    for _score, corners, pattern, label, source in raw_combo:
        color = colors.get(label, (255, 255, 255))
        pts = corners.reshape(-1, 2)
        for x, y in pts:
            cv2.circle(vis, (int(round(x)), int(round(y))), 2, color, -1)
        x1, y1 = np.floor(pts.min(axis=0)).astype(int)
        x2, y2 = np.ceil(pts.max(axis=0)).astype(int)
        cv2.rectangle(vis, (x1, y1), (x2, y2), color, 2)
        cv2.putText(
            vis,
            f"{label} {int(pattern[0])}x{int(pattern[1])}",
            (x1, max(20, y1 - 6)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            color,
            2,
        )
        cv2.putText(
            vis,
            str(source)[:40],
            (x1, min(vis.shape[0] - 8, y2 + 18)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.45,
            color,
            1,
        )
    out_dir.mkdir(parents=True, exist_ok=True)
    out_name = rel.replace("/", "__").replace("\\", "__")
    cv2.imwrite(str(out_dir / f"{out_name}.jpg"), vis)


def probe_one(
    image_root: Path,
    rel: str,
    predictor: SamPredictor,
    out_dir: Path,
    *,
    rmse_limit: float,
    ambiguity_gap_px: float,
) -> Dict[str, Any]:
    image_path = image_root / rel
    image = read_image(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    cube_area = float(estimate_cube_area_pct(gray, n_faces=3))
    direct = _detect_cube_first(gray, n_faces=3, verbose=False)
    direct_desc = ";".join(f"{label}:{int(pat[0])}x{int(pat[1])}" for _c, pat, label in direct)

    by_label = {label: [] for label in PHYSICAL_LABELS}
    add_direct_candidates(gray, by_label)
    recovered, attempts_total = recover_needed_candidates(image, gray, predictor, by_label)

    best = None
    tested = 0
    accepted = 0
    for raw in _all_two_face_combos(by_label):
        dets = [(c, p, l) for _s, c, p, l, _src in raw]
        fits = _fit_two_face_models(dets, gray.shape, rmse_limit=rmse_limit)
        tested += 1
        if not fits:
            continue
        accepted += len(fits)
        candidate = fits[0]
        candidate["raw_combo"] = raw
        candidate["all_fits"] = fits
        if best is None or float(candidate["rmse_px"]) < float(best["rmse_px"]):
            best = candidate

    row: Dict[str, Any] = {
        "rel_path": rel,
        "status": "no_two_face_candidate",
        "cube_area_pct": cube_area,
        "direct": direct_desc,
        "xy_candidates": _candidate_desc(by_label["XY"]),
        "xz_candidates": _candidate_desc(by_label["XZ"]),
        "yz_candidates": _candidate_desc(by_label["YZ"]),
        "recovered": json.dumps(recovered, ensure_ascii=False),
        "attempts": attempts_total,
        "two_face_combos_tested": tested,
        "two_face_model_count": accepted,
    }
    if best is None:
        return row

    close = [
        fit for fit in best["all_fits"]
        if float(fit["rmse_px"]) <= float(best["rmse_px"]) + ambiguity_gap_px
    ]
    fxs = [float(fit["fx_px"]) for fit in close if math.isfinite(float(fit["fx_px"]))]
    fx_spread = (
        (max(fxs) - min(fxs)) / max(abs(float(best["fx_px"])), 1.0)
        if len(fxs) >= 2 else 0.0
    )
    review_status = "review_only_stable_two_face"
    if len(close) > 6 or fx_spread > 0.15:
        review_status = "review_only_ambiguous_two_face"
    if abs(float(best["k1"])) > 0.8:
        review_status = "review_only_high_distortion_two_face"

    save_overlay(image, rel, best["raw_combo"], out_dir / "overlays")
    row.update({
        "status": review_status,
        "best_labels": best["labels"],
        "best_patterns": best["patterns"],
        "best_model": best["model"],
        "best_rmse_px": best["rmse_px"],
        "best_fx_px": best["fx_px"],
        "best_fy_px": best["fy_px"],
        "best_cx_px": best["cx_px"],
        "best_cy_px": best["cy_px"],
        "best_k1": best["k1"],
        "best_flips": json.dumps(best["flips"]),
        "best_specs": json.dumps(_jsonable(best["specs"]), ensure_ascii=False),
        "close_count": len(close),
        "close_fx_spread_pct": fx_spread * 100.0,
    })
    return row


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--rel-list", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--model-type", default="vit_b")
    parser.add_argument("--rmse-limit", type=float, default=18.0)
    parser.add_argument("--ambiguity-gap-px", type=float, default=1.0)
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    sam = sam_model_registry[args.model_type](checkpoint=str(args.checkpoint))
    sam.to(device=device)
    predictor = SamPredictor(sam)

    rows = []
    for rel in load_rel_paths(args.rel_list):
        print(f"START {rel}", flush=True)
        try:
            row = probe_one(
                args.image_root,
                rel,
                predictor,
                args.out_dir,
                rmse_limit=args.rmse_limit,
                ambiguity_gap_px=args.ambiguity_gap_px,
            )
        except Exception as exc:
            row = {"rel_path": rel, "status": "error", "error": str(exc)}
        print(json.dumps(row, ensure_ascii=False), flush=True)
        rows.append(row)

    (args.out_dir / "sam_two_face_physical_results.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    fields = sorted({key for row in rows for key in row.keys()})
    with (args.out_dir / "sam_two_face_physical_results.csv").open(
        "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
