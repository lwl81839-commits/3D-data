from __future__ import annotations

import argparse
import csv
import json
import os
import statistics
import subprocess
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parents[1]
BATCH_SCRIPT = ROOT / "batch_evaluate_current.py"
BASELINE_CSV = ROOT / "batch_results" / "full136_round5_fusion_20260718_v1" / "current_batch_results.csv"
OUT_ROOT = ROOT / "batch_results" / "ablation_suite_20260718"
REPORT_PATH = ROOT / "paper_drafts" / "ablation_suite_20260718_report.md"

UNUSABLE_KEYS = {("15.2_0.986", "t_5_14.jpg"), ("20_0.840", "t_3_00.jpg")}


@dataclass(frozen=True)
class AblationConfig:
    name: str
    description: str
    extra_args: tuple[str, ...]
    expected_if_component_matters: str
    priority: int


CONFIGS = {
    "baseline": AblationConfig(
        name="baseline",
        description="Frozen full ge2 single-frame cube pipeline.",
        extra_args=(),
        expected_if_component_matters="Reference result; should reproduce 98/98 real targets and 0/38 negative acceptances on the full set.",
        priority=0,
    ),
    "no_stability_manifest": AblationConfig(
        name="no_stability_manifest",
        description="Disable final stability-manifest replay/precomputed stable corners.",
        extra_args=("--ablation-disable-stability-manifest",),
        expected_if_component_matters="Pass rate should drop mainly on historically unstable or timeout-prone real targets; runtime may increase.",
        priority=1,
    ),
    "no_grid_recovery": AblationConfig(
        name="no_grid_recovery",
        description="Disable physical grid extrapolation/local recovery.",
        extra_args=("--ablation-disable-grid-recovery",),
        expected_if_component_matters="Small-target and partial-grid real targets should fail more often; runtime should decrease.",
        priority=1,
    ),
    "no_grid_first_small_target": AblationConfig(
        name="no_grid_first_small_target",
        description="Keep grid recovery but disable grid-first routing before the default detector for very small targets.",
        extra_args=("--ablation-disable-grid-first-small-target",),
        expected_if_component_matters="The 2-4% area band should lose recall while larger direct-detection cases should remain close.",
        priority=1,
    ),
    "area_ratio_gates_restored": AblationConfig(
        name="area_ratio_gates_restored",
        description="Restore earlier area-ratio acceptance gates instead of the current physical-quality gate.",
        extra_args=("--ablation-enable-area-ratio-gates",),
        expected_if_component_matters="Low-area real targets should be rejected again, showing why area should be a route hint rather than a hard stop.",
        priority=1,
    ),
    "no_component_label_permutations": AblationConfig(
        name="no_component_label_permutations",
        description="Disable guarded component label-permutation fallback inside grid recovery.",
        extra_args=("--ablation-disable-component-label-permutations",),
        expected_if_component_matters="Cases with ambiguous XY/XZ/YZ face labels should lose recall or show worse RMSE.",
        priority=2,
    ),
    "complete_geometry_only": AblationConfig(
        name="complete_geometry_only",
        description="Restrict grid recovery to the complete_geometry route.",
        extra_args=("--grid-recovery-route", "complete_geometry"),
        expected_if_component_matters="Gives a lower-bound estimate for the basic physical grid-completion route without local/component fallbacks.",
        priority=3,
    ),
    "local_partial_only": AblationConfig(
        name="local_partial_only",
        description="Restrict grid recovery to the local_partial route.",
        extra_args=("--grid-recovery-route", "local_partial"),
        expected_if_component_matters="Tests whether local partial recovery alone can support small or incomplete targets.",
        priority=3,
    ),
    "component_labelperm_only": AblationConfig(
        name="component_labelperm_only",
        description="Restrict grid recovery to component_labelperm_seed_only.",
        extra_args=("--grid-recovery-route", "component_labelperm_seed_only"),
        expected_if_component_matters="Tests the independent value of component-based face hypotheses plus label correction.",
        priority=3,
    ),
    "selected_full_zhang_only": AblationConfig(
        name="selected_full_zhang_only",
        description="Accept only final selected models whose model_grade is full_single_cube_zhang.",
        extra_args=("--ablation-accept-model-grade", "full_single_cube_zhang"),
        expected_if_component_matters="Small targets and recovered-grid cases that depend on bounded candidates should lose recall.",
        priority=3,
    ),
    "selected_bounded_only": AblationConfig(
        name="selected_bounded_only",
        description="Accept only final selected bounded model grades.",
        extra_args=(
            "--ablation-accept-model-grade", "bounded_focal_pose",
            "--ablation-accept-model-grade", "bounded_focal_scan",
            "--ablation-accept-model-grade", "bounded_single_view",
        ),
        expected_if_component_matters="Cases that depend on single-cube Zhang refinement should lose recall while bounded small-target cases remain available.",
        priority=3,
    ),
    "selected_bounded_focal_pose_only": AblationConfig(
        name="selected_bounded_focal_pose_only",
        description="Accept only final selected bounded_focal_pose models.",
        extra_args=("--ablation-accept-model-grade", "bounded_focal_pose"),
        expected_if_component_matters="The 2-3% area pocket should remain more available than full-Zhang-only, but scan/full cases should be rejected.",
        priority=4,
    ),
    "selected_bounded_focal_scan_only": AblationConfig(
        name="selected_bounded_focal_scan_only",
        description="Accept only final selected bounded_focal_scan models.",
        extra_args=("--ablation-accept-model-grade", "bounded_focal_scan"),
        expected_if_component_matters="Wide-offset focal-scan cases should be isolated; fixed-focal pose and Zhang cases should be rejected.",
        priority=4,
    ),
    "isolated_full_zhang_only": AblationConfig(
        name="isolated_full_zhang_only",
        description="Allow only full_single_cube_zhang candidates to update the accepted calibration state.",
        extra_args=("--ablation-isolate-model-grade", "full_single_cube_zhang"),
        expected_if_component_matters="Shows how much of the controlled sample can be solved without adopting bounded-pose or scan candidates.",
        priority=4,
    ),
    "isolated_bounded_only": AblationConfig(
        name="isolated_bounded_only",
        description="Allow only bounded candidates to update the accepted calibration state.",
        extra_args=(
            "--ablation-isolate-model-grade", "bounded_focal_pose",
            "--ablation-isolate-model-grade", "bounded_focal_scan",
            "--ablation-isolate-model-grade", "bounded_single_view",
        ),
        expected_if_component_matters="Shows whether bounded families can solve the controlled sample without final Zhang adoption.",
        priority=4,
    ),
    "isolated_bounded_focal_pose_only": AblationConfig(
        name="isolated_bounded_focal_pose_only",
        description="Allow only bounded_focal_pose candidates to update the accepted calibration state.",
        extra_args=("--ablation-isolate-model-grade", "bounded_focal_pose"),
        expected_if_component_matters="Isolates the fixed-focal pose family, especially the 2-3% pocket.",
        priority=5,
    ),
    "isolated_bounded_focal_scan_only": AblationConfig(
        name="isolated_bounded_focal_scan_only",
        description="Allow only bounded_focal_scan candidates to update the accepted calibration state.",
        extra_args=("--ablation-isolate-model-grade", "bounded_focal_scan"),
        expected_if_component_matters="Isolates wide-offset bounded focal-scan contributions.",
        priority=5,
    ),
}


def fnum(value: str | None) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except ValueError:
        return None


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_smoke_rel_paths(path: Path) -> list[str]:
    rows = read_csv(BASELINE_CSV)
    chosen: list[str] = []
    desired_gate = [
        "normal_quality_gate",
        "grid_recovered_calibration",
        "downstream_quality_gate",
        "final_manifest_calibration",
    ]
    for gate in desired_gate:
        row = next(
            (
                r for r in rows
                if r.get("status") == "ok"
                and r.get("calibration_status") == gate
                and r.get("rel_path") not in chosen
            ),
            None,
        )
        if row is not None:
            chosen.append(row["rel_path"])
    small = next(
        (
            r for r in rows
            if r.get("status") == "ok"
            and (fnum(r.get("cube_area_pct")) or 999.0) >= 2.0
            and (fnum(r.get("cube_area_pct")) or 999.0) < 3.0
            and r.get("rel_path") not in chosen
        ),
        None,
    )
    if small is not None:
        chosen.append(small["rel_path"])
    negative = next((r for r in rows if r.get("group") == "zhang"), None)
    if negative is not None:
        chosen.append(negative["rel_path"])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(chosen) + "\n", encoding="utf-8")
    return chosen


def command_for(
    config: AblationConfig,
    *,
    out_dir: Path,
    workers: int,
    per_image_timeout: float,
    rel_path_file: Path | None,
    limit: int | None,
) -> list[str]:
    cmd = [
        sys.executable,
        str(BATCH_SCRIPT),
        "--method-profile",
        "ge2_single_frame_cube",
        "--out-dir",
        str(out_dir),
        "--workers",
        str(workers),
        "--mode",
        "subprocess",
        "--per-image-timeout",
        str(float(per_image_timeout)),
    ]
    if rel_path_file is not None:
        cmd.extend(["--rel-path-file", str(rel_path_file)])
    if limit is not None:
        cmd.extend(["--limit", str(int(limit))])
    cmd.extend(config.extra_args)
    return cmd


def run_config(
    config: AblationConfig,
    *,
    suite_root: Path,
    workers: int,
    per_image_timeout: float,
    rel_path_file: Path | None,
    limit: int | None,
) -> int:
    out_dir = suite_root / config.name
    out_dir.mkdir(parents=True, exist_ok=True)
    grid_out = out_dir / "grid_recovery"
    cmd = command_for(
        config,
        out_dir=out_dir,
        workers=workers,
        per_image_timeout=per_image_timeout,
        rel_path_file=rel_path_file,
        limit=limit,
    )
    if "--ablation-disable-grid-recovery" not in config.extra_args:
        cmd.extend(["--grid-recovery-out-dir", str(grid_out)])

    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    started = subprocess.run(
        cmd,
        cwd=str(ROOT),
        env=env,
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=(out_dir / "run_stdout.log").open("w", encoding="utf-8"),
        stderr=(out_dir / "run_stderr.log").open("w", encoding="utf-8"),
    )
    (out_dir / "command.json").write_text(
        json.dumps({"cmd": cmd, "returncode": started.returncode}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return int(started.returncode)


def summarize_rows(rows: list[dict[str, str]]) -> dict[str, object]:
    zhang = [r for r in rows if r.get("group") == "zhang"]
    non_zhang = [r for r in rows if r.get("group") != "zhang"]
    unusable = [r for r in non_zhang if (r.get("group"), r.get("image")) in UNUSABLE_KEYS]
    real = [r for r in non_zhang if (r.get("group"), r.get("image")) not in UNUSABLE_KEYS]
    real_ok = [r for r in real if r.get("status") == "ok"]
    negative = zhang + unusable
    rmse = [v for v in (fnum(r.get("rmse_px")) for r in real_ok) if v is not None]
    wall = [v for v in (fnum(r.get("wall_elapsed_sec")) for r in real_ok) if v is not None]
    area_over_2 = [
        r for r in real
        if (fnum(r.get("cube_area_pct")) is None or (fnum(r.get("cube_area_pct")) or 0.0) >= 2.0)
    ]
    return {
        "images": len(rows),
        "real": len(real),
        "real_ok": len(real_ok),
        "real_ge2": len(area_over_2),
        "real_ge2_ok": sum(1 for r in area_over_2 if r.get("status") == "ok"),
        "negative": len(negative),
        "negative_ok": sum(1 for r in negative if r.get("status") == "ok"),
        "mean_rmse": sum(rmse) / len(rmse) if rmse else None,
        "median_rmse": statistics.median(rmse) if rmse else None,
        "p90_rmse": sorted(rmse)[max(0, min(len(rmse) - 1, int(0.9 * len(rmse)) - 1))] if rmse else None,
        "mean_wall": sum(wall) / len(wall) if wall else None,
        "status_counts": dict(Counter(r.get("status") or "" for r in rows)),
        "calibration_counts": dict(Counter(r.get("calibration_status") or "" for r in rows)),
        "model_grade_counts": dict(Counter(r.get("model_grade") or "" for r in rows if r.get("model_grade"))),
    }


def fmt(value: object, digits: int = 3) -> str:
    if value is None:
        return "-"
    if isinstance(value, float):
        return f"{value:.{digits}f}"
    return str(value)


def summarize_suite(config_names: Iterable[str], suite_root: Path, report_path: Path) -> None:
    lines: list[str] = []
    lines.append("# Ablation Suite 20260718")
    lines.append("")
    lines.append(f"Suite root: `{suite_root.relative_to(ROOT)}`")
    lines.append("")
    lines.append("## Configurations")
    lines.append("")
    lines.append("| config | priority | description | expected if component matters |")
    lines.append("|---|---:|---|---|")
    for name in config_names:
        cfg = CONFIGS[name]
        lines.append(f"| `{name}` | {cfg.priority} | {cfg.description} | {cfg.expected_if_component_matters} |")
    lines.append("")
    lines.append("## Results")
    lines.append("")
    lines.append("| config | images | real ok | real >=2% ok | negative accepted | mean RMSE px | P90 RMSE px | mean wall s | status counts |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---|")
    for name in config_names:
        csv_path = suite_root / name / "current_batch_results.csv"
        rows = read_csv(csv_path)
        if not rows:
            lines.append(f"| `{name}` | - | - | - | - | - | - | - | not run |")
            continue
        s = summarize_rows(rows)
        real_ok = f"{s['real_ok']}/{s['real']}"
        real_ge2_ok = f"{s['real_ge2_ok']}/{s['real_ge2']}"
        lines.append(
            f"| `{name}` | {s['images']} | {real_ok} | {real_ge2_ok} | "
            f"{s['negative_ok']}/{s['negative']} | {fmt(s['mean_rmse'])} | "
            f"{fmt(s['p90_rmse'])} | {fmt(s['mean_wall'], 1)} | `{s['status_counts']}` |"
        )
    lines.append("")
    lines.append("## Command Reproduction")
    lines.append("")
    for name in config_names:
        cmd_path = suite_root / name / "command.json"
        if not cmd_path.exists():
            continue
        cmd = json.loads(cmd_path.read_text(encoding="utf-8")).get("cmd", [])
        lines.append(f"`{name}`:")
        lines.append("")
        lines.append("```powershell")
        lines.append(" ".join(str(part) for part in cmd))
        lines.append("```")
        lines.append("")
    report_path.write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite-root", type=Path, default=OUT_ROOT)
    parser.add_argument("--report", type=Path, default=REPORT_PATH)
    parser.add_argument("--configs", default="baseline,no_stability_manifest,no_grid_recovery,no_grid_first_small_target,area_ratio_gates_restored")
    parser.add_argument("--run", action="store_true", help="Run selected configurations before summarizing.")
    parser.add_argument("--smoke", action="store_true", help="Run only a representative smoke subset.")
    parser.add_argument("--rel-path-file", type=Path, default=None, help="Use an explicit rel-path list instead of the full image set.")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--per-image-timeout", type=float, default=900.0)
    parser.add_argument("--dry-run", action="store_true", help="Print commands without running.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config_names = [name.strip() for name in args.configs.split(",") if name.strip()]
    missing = [name for name in config_names if name not in CONFIGS]
    if missing:
        raise SystemExit(f"Unknown config(s): {missing}")
    suite_root = args.suite_root.resolve()
    suite_root.mkdir(parents=True, exist_ok=True)
    rel_path_file = args.rel_path_file.resolve() if args.rel_path_file is not None else None
    if args.smoke:
        if rel_path_file is not None:
            raise SystemExit("--smoke and --rel-path-file are mutually exclusive")
        rel_path_file = suite_root / "smoke_rel_paths.txt"
        chosen = write_smoke_rel_paths(rel_path_file)
        print(f"Smoke rel-paths ({len(chosen)}): {', '.join(chosen)}")

    if args.dry_run:
        for name in config_names:
            cmd = command_for(
                CONFIGS[name],
                out_dir=suite_root / name,
                workers=args.workers,
                per_image_timeout=args.per_image_timeout,
                rel_path_file=rel_path_file,
                limit=args.limit,
            )
            print(" ".join(cmd))
        return 0

    if args.run:
        for name in config_names:
            print(f"Running {name}...")
            rc = run_config(
                CONFIGS[name],
                suite_root=suite_root,
                workers=args.workers,
                per_image_timeout=args.per_image_timeout,
                rel_path_file=rel_path_file,
                limit=args.limit,
            )
            print(f"{name}: returncode={rc}")
            if rc != 0:
                break

    summarize_suite(config_names, suite_root, args.report.resolve())
    print(args.report.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
