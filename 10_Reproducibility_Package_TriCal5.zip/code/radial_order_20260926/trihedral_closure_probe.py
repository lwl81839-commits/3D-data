#!/usr/bin/env python3
"""Probe whether three projected board outlines close at one cube corner.

This diagnostic is deliberately lighter than the SAM quad probe.  It starts
from the current cube-first checkerboard detections, enumerates possible
full-board patterns and integer in-face offsets, projects each full board
outline into the image, then scores whether the three outlines have a
consistent trihedral topology:

  XY shares one edge with XZ, XY shares one edge with YZ, and XZ shares one
  edge with YZ; the three implied face vertices should meet at one image point.

The script does not change product acceptance.  It is meant to test the
"three visible edges imply three faces" idea on boundary/held samples before
any production gate is loosened.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import cv2
import numpy as np

import face_detector as fd
from partial_offset_probe import _candidate_specs, _face_definition, _intrinsics_from_vps
from three_face_calib import DetectedFace, apply_best_face_orientations, object_points_for_face
from trihedral_boundary_probe import (
    _edge_distance_map,
    _poly_edge_support,
    _project_full_outer_quad,
)


IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
FACE_COLORS = {
    "XY": (60, 90, 255),
    "XZ": (70, 190, 70),
    "YZ": (255, 120, 40),
}
MARGIN_EDGE_VERTICES = {
    0: (3, 0),  # u = 0
    1: (1, 2),  # u = 1
    2: (0, 1),  # v = 0
    3: (2, 3),  # v = 1
}


def _maybe_float(value: Any) -> Optional[float]:
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    return out if math.isfinite(out) else None


def _read_csv(path: Path) -> List[Dict[str, Any]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def _write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    fieldnames = [
        "rel_path",
        "group",
        "image",
        "status",
        "decision",
        "cube_area_pct",
        "manual_source",
        "fx_gt",
        "n_faces",
        "patterns",
        "closure_status",
        "specs_tested",
        "valid_trihedral_specs",
        "best_rank",
        "best_pnp_rmse_px",
        "best_edge_support_mean",
        "best_edge_support_min",
        "best_pair_score",
        "best_max_pair_score",
        "best_angle_sum_deg",
        "best_vertex_spread_px",
        "best_vertex_spread_norm",
        "best_common_vertex_px",
        "best_usage",
        "best_specs",
        "best_issues",
        "gate_status",
        "gate_candidate_count",
        "gate_best_pnp_rmse_px",
        "gate_best_edge_support_min",
        "gate_best_vertex_spread_norm",
        "gate_best_specs",
    ]
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _clean_csv(row.get(key)) for key in fieldnames})


def _clean_csv(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, float):
        if not math.isfinite(value):
            return ""
        return f"{value:.10g}"
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(_jsonable(value), ensure_ascii=False, sort_keys=True)
    return value


def _jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, np.ndarray):
        return _jsonable(value.tolist())
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        out = float(value)
        return out if math.isfinite(out) else None
    return value


def _load_bgr(path: Path) -> np.ndarray:
    data = np.fromfile(str(path), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Cannot decode image: {path}")
    return img


def _line_from_points(p0: np.ndarray, p1: np.ndarray) -> np.ndarray:
    x0, y0 = np.asarray(p0, dtype=np.float32)
    x1, y1 = np.asarray(p1, dtype=np.float32)
    line = np.array([y0 - y1, x1 - x0, x0 * y1 - x1 * y0], dtype=np.float32)
    norm = float(np.hypot(line[0], line[1]))
    if norm <= 1e-6:
        return line
    return line / norm


def _point_segment_distance(point: np.ndarray, seg0: np.ndarray, seg1: np.ndarray) -> float:
    point = np.asarray(point, dtype=np.float32)
    seg0 = np.asarray(seg0, dtype=np.float32)
    seg1 = np.asarray(seg1, dtype=np.float32)
    vec = seg1 - seg0
    denom = float(np.dot(vec, vec))
    if denom <= 1e-6:
        return float(np.linalg.norm(point - seg0))
    t = float(np.clip(np.dot(point - seg0, vec) / denom, 0.0, 1.0))
    proj = seg0 + t * vec
    return float(np.linalg.norm(point - proj))


def _angle_delta_deg(angle_a: float, angle_b: float) -> float:
    delta = abs((float(angle_a) - float(angle_b) + 90.0) % 180.0 - 90.0)
    return float(delta)


def _segment_angle_delta_deg(
    a0: np.ndarray,
    a1: np.ndarray,
    b0: np.ndarray,
    b1: np.ndarray,
) -> float:
    va = np.asarray(a1, dtype=np.float32) - np.asarray(a0, dtype=np.float32)
    vb = np.asarray(b1, dtype=np.float32) - np.asarray(b0, dtype=np.float32)
    aa = math.degrees(math.atan2(float(va[1]), float(va[0])))
    bb = math.degrees(math.atan2(float(vb[1]), float(vb[0])))
    return _angle_delta_deg(aa, bb)


def _quad_margin_segments(quad: np.ndarray) -> Dict[int, Tuple[np.ndarray, np.ndarray]]:
    quad = np.asarray(quad, dtype=np.float32).reshape(4, 2)
    return {
        idx: (quad[i0], quad[i1])
        for idx, (i0, i1) in MARGIN_EDGE_VERTICES.items()
    }


def _segment_pair_metrics(
    seg_a: Tuple[np.ndarray, np.ndarray],
    seg_b: Tuple[np.ndarray, np.ndarray],
) -> Dict[str, float]:
    a0, a1 = [np.asarray(p, dtype=np.float32) for p in seg_a]
    b0, b1 = [np.asarray(p, dtype=np.float32) for p in seg_b]
    all_pts = np.vstack([a0, a1, b0, b1])
    diag = max(
        float(np.linalg.norm(np.max(all_pts, axis=0) - np.min(all_pts, axis=0))),
        1.0,
    )
    dist = 0.25 * (
        _point_segment_distance(a0, b0, b1)
        + _point_segment_distance(a1, b0, b1)
        + _point_segment_distance(b0, a0, a1)
        + _point_segment_distance(b1, a0, a1)
    )
    mid_dist = float(np.linalg.norm(0.5 * (a0 + a1) - 0.5 * (b0 + b1)))
    angle = _segment_angle_delta_deg(a0, a1, b0, b1)
    score = (dist / diag) + 0.35 * (angle / 90.0) + 0.20 * (mid_dist / diag)
    return {
        "score": float(score),
        "mean_distance_px": float(dist),
        "midpoint_distance_px": mid_dist,
        "angle_delta_deg": float(angle),
    }


def _shared_vertex_index(edge_a: int, edge_b: int) -> Optional[int]:
    verts_a = set(MARGIN_EDGE_VERTICES[int(edge_a)])
    verts_b = set(MARGIN_EDGE_VERTICES[int(edge_b)])
    common = sorted(verts_a & verts_b)
    if len(common) != 1:
        return None
    return int(common[0])


def _trihedral_vertex_metrics(
    items: Sequence[Dict[str, Any]],
    quad_by_label: Dict[str, np.ndarray],
) -> Dict[str, Any]:
    usage: Dict[str, List[int]] = {}
    for item in items:
        a, b = item["pair"]
        ia, ib = item["edge_indices"]
        usage.setdefault(str(a), []).append(int(ia))
        usage.setdefault(str(b), []).append(int(ib))

    issues: List[str] = []
    vertex_indices: Dict[str, int] = {}
    vertex_points: Dict[str, List[float]] = {}
    for label, edges in sorted(usage.items()):
        if len(edges) != 2:
            issues.append(f"{label}_does_not_have_two_shared_edges")
            continue
        if len(set(edges)) != 2:
            issues.append(f"{label}_reuses_edge_{edges[0]}")
            continue
        vertex_idx = _shared_vertex_index(edges[0], edges[1])
        if vertex_idx is None:
            issues.append(f"{label}_uses_opposite_edges_{edges[0]}_{edges[1]}")
            continue
        quad = quad_by_label.get(label)
        if quad is None:
            issues.append(f"{label}_missing_quad")
            continue
        point = np.asarray(quad, dtype=np.float32).reshape(4, 2)[vertex_idx]
        vertex_indices[label] = int(vertex_idx)
        vertex_points[label] = [float(point[0]), float(point[1])]

    if issues or len(vertex_points) != 3:
        return {
            "valid": False,
            "issues": issues or ["missing_trihedral_vertex"],
            "usage": {label: edges for label, edges in sorted(usage.items())},
            "per_face_vertex_indices": vertex_indices,
            "per_face_vertex_points_px": vertex_points,
        }

    all_quad_points = np.vstack([
        np.asarray(quad, dtype=np.float32).reshape(4, 2)
        for quad in quad_by_label.values()
    ])
    bbox_diag = max(
        float(np.linalg.norm(np.max(all_quad_points, axis=0) - np.min(all_quad_points, axis=0))),
        1.0,
    )
    points = np.asarray(list(vertex_points.values()), dtype=np.float32)
    center = np.mean(points, axis=0)
    dists = np.linalg.norm(points - center[None, :], axis=1)
    return {
        "valid": True,
        "issues": [],
        "usage": {label: edges for label, edges in sorted(usage.items())},
        "per_face_vertex_indices": vertex_indices,
        "per_face_vertex_points_px": vertex_points,
        "common_vertex_px": [float(center[0]), float(center[1])],
        "vertex_spread_mean_px": float(np.mean(dists)),
        "vertex_spread_max_px": float(np.max(dists)),
        "vertex_spread_mean_norm": float(np.mean(dists) / bbox_diag),
        "vertex_spread_max_norm": float(np.max(dists) / bbox_diag),
        "normalizer_bbox_diag_px": float(bbox_diag),
    }


def _infer_shared_edge_indices(
    quads: Dict[str, Dict[str, Any]],
    *,
    pair_top_k: int = 4,
) -> Dict[str, Any]:
    pairs = [("XY", "XZ"), ("XY", "YZ"), ("XZ", "YZ")]
    candidates_by_pair: Dict[str, List[Dict[str, Any]]] = {}
    quad_by_label: Dict[str, np.ndarray] = {}
    for a, b in pairs:
        qa_info = quads.get(a)
        qb_info = quads.get(b)
        if qa_info is None or qb_info is None:
            continue
        qa = np.asarray(qa_info.get("quad"), dtype=np.float32).reshape(4, 2)
        qb = np.asarray(qb_info.get("quad"), dtype=np.float32).reshape(4, 2)
        quad_by_label[a] = qa
        quad_by_label[b] = qb
        pair_candidates: List[Dict[str, Any]] = []
        for ia, sa in _quad_margin_segments(qa).items():
            for ib, sb in _quad_margin_segments(qb).items():
                metrics = _segment_pair_metrics(sa, sb)
                pair_candidates.append({
                    "pair": [a, b],
                    "edge_indices": [int(ia), int(ib)],
                    **metrics,
                })
        pair_candidates.sort(key=lambda row: row["score"])
        if pair_top_k > 0:
            pair_candidates = pair_candidates[:pair_top_k]
        candidates_by_pair[f"{a}-{b}"] = pair_candidates

    if len(candidates_by_pair) != len(pairs):
        return {
            "__valid__": False,
            "__issues__": ["missing_pair_candidates"],
            "__usage__": {},
        }

    best_valid = None
    best_distinct = None
    pair_keys = [f"{a}-{b}" for a, b in pairs]
    for combo in itertools.product(*(candidates_by_pair[key] for key in pair_keys)):
        usage: Dict[str, List[int]] = {}
        for item in combo:
            a, b = item["pair"]
            ia, ib = item["edge_indices"]
            usage.setdefault(str(a), []).append(int(ia))
            usage.setdefault(str(b), []).append(int(ib))
        if any(len(edges) >= 2 and len(set(edges)) < len(edges) for edges in usage.values()):
            continue
        total_score = float(sum(float(item["score"]) for item in combo))
        max_score = float(max(float(item["score"]) for item in combo))
        angle_sum = float(sum(float(item["angle_delta_deg"]) for item in combo))
        trihedral = _trihedral_vertex_metrics(combo, quad_by_label)
        distinct = {
            "items": combo,
            "total_score": total_score,
            "max_pair_score": max_score,
            "angle_sum_deg": angle_sum,
            "usage": usage,
            "trihedral": trihedral,
        }
        if best_distinct is None or (
            total_score,
            max_score,
            angle_sum,
        ) < (
            best_distinct["total_score"],
            best_distinct["max_pair_score"],
            best_distinct["angle_sum_deg"],
        ):
            best_distinct = distinct
        if not trihedral.get("valid", False):
            continue
        if best_valid is None or (
            total_score,
            max_score,
            angle_sum,
            float(trihedral["vertex_spread_max_norm"]),
        ) < (
            best_valid["total_score"],
            best_valid["max_pair_score"],
            best_valid["angle_sum_deg"],
            float(best_valid["trihedral"]["vertex_spread_max_norm"]),
        ):
            best_valid = distinct

    if best_valid is None:
        trihedral = (
            best_distinct["trihedral"]
            if best_distinct is not None
            else {"valid": False, "issues": ["no_distinct_topology"]}
        )
        return {
            "__valid__": False,
            "__issues__": trihedral.get("issues") or ["no_valid_topology"],
            "__usage__": (
                {label: edges for label, edges in sorted(best_distinct["usage"].items())}
                if best_distinct is not None else {}
            ),
            "__trihedral__": trihedral,
            "__total_pair_score__": (
                None if best_distinct is None else float(best_distinct["total_score"])
            ),
            "__max_pair_score__": (
                None if best_distinct is None else float(best_distinct["max_pair_score"])
            ),
            "__angle_sum_deg__": (
                None if best_distinct is None else float(best_distinct["angle_sum_deg"])
            ),
        }

    out: Dict[str, Any] = {
        "__valid__": True,
        "__issues__": [],
        "__usage__": {label: edges for label, edges in sorted(best_valid["usage"].items())},
        "__trihedral__": best_valid["trihedral"],
        "__total_pair_score__": float(best_valid["total_score"]),
        "__max_pair_score__": float(best_valid["max_pair_score"]),
        "__angle_sum_deg__": float(best_valid["angle_sum_deg"]),
    }
    for key, item in zip(pair_keys, best_valid["items"]):
        out[key] = {k: v for k, v in item.items() if k != "pair"}
    return out


def _spec_to_quads(
    detections: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    specs: Dict[str, Dict[str, Tuple[int, int]]],
) -> Optional[Dict[str, Dict[str, Any]]]:
    quads: Dict[str, Dict[str, Any]] = {}
    for corners, pattern, label in detections:
        spec = specs.get(label)
        if spec is None:
            return None
        full_pattern = tuple(int(v) for v in spec["full_pattern"])
        offset = tuple(int(v) for v in spec["offset"])
        poly = _project_full_outer_quad(corners, pattern, full_pattern, offset)
        if poly is None:
            return None
        quads[label] = {
            "quad": poly.astype(np.float32),
            "full_pattern": full_pattern,
            "offset": offset,
        }
    return quads


def _quad_edge_support_summary(
    quads: Dict[str, Dict[str, Any]],
    edge_dist: np.ndarray,
    image_shape: Tuple[int, int],
) -> Dict[str, Any]:
    diag = float(np.hypot(*image_shape[:2]))
    tol = max(2.0, 0.0025 * diag)
    by_face: Dict[str, Any] = {}
    means: List[float] = []
    mins: List[float] = []
    for label, info in sorted(quads.items()):
        support = _poly_edge_support(
            np.asarray(info["quad"], dtype=np.float32),
            edge_dist,
            tolerance_px=tol,
        )
        mean_support = _maybe_float(support.get("edge_support_mean"))
        min_support = _maybe_float(support.get("edge_support_min"))
        if mean_support is not None:
            means.append(mean_support)
        if min_support is not None:
            mins.append(min_support)
        by_face[label] = support
    return {
        "edge_support_mean": float(np.mean(means)) if means else None,
        "edge_support_min": float(min(mins)) if mins else None,
        "edge_support_by_face": by_face,
    }


def _patterns_text(detections: Sequence[Tuple[np.ndarray, Tuple[int, int], str]]) -> str:
    return "|".join(f"{label}:{pat[0]}x{pat[1]}" for _c, pat, label in detections)


def _specs_text(specs: Optional[Dict[str, Any]]) -> str:
    if specs is None:
        return ""
    return json.dumps(_jsonable(specs), ensure_ascii=False, sort_keys=True)


def _best_oriented_pnp_rmse(
    detections: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    specs: Dict[str, Dict[str, Tuple[int, int]]],
    K_seed: np.ndarray,
) -> Optional[float]:
    full_patterns = {
        label: tuple(int(v) for v in spec["full_pattern"])
        for label, spec in specs.items()
    }
    faces = []
    detected = []
    for corners, pattern, label in detections:
        spec = specs.get(label)
        if spec is None:
            return None
        face = _face_definition(
            label,
            pattern,
            full_patterns,
            tuple(int(v) for v in spec["offset"]),
        )
        faces.append(face)
        detected.append(DetectedFace(
            image_points=np.asarray(corners, dtype=np.float32),
            object_points=object_points_for_face(face),
            valid=True,
        ))
    try:
        orientations = apply_best_face_orientations(
            detected, faces, list(range(len(detected))), K_seed, None)
    except Exception:
        return None
    if not orientations:
        return None
    rmse = _maybe_float(orientations[0].get("rmse"))
    return rmse


def probe_image(
    image_path: Path,
    row: Dict[str, Any],
    *,
    max_specs: Optional[int] = None,
    pnp_gate_px: float = 9.0,
    min_edge_support: float = 0.35,
    max_spread_norm: float = 0.08,
    overlay_path: Optional[Path] = None,
) -> Dict[str, Any]:
    image = _load_bgr(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edge_dist = _edge_distance_map(gray)
    h_img, w_img = gray.shape[:2]
    detections = fd.detect_corner_cube_faces(gray, n_faces=3, verbose=False)
    labels = [label for _corners, _pattern, label in detections]
    out: Dict[str, Any] = {
        "rel_path": row.get("rel_path", ""),
        "group": row.get("group", ""),
        "image": row.get("image", image_path.name),
        "status": row.get("status", ""),
        "decision": row.get("decision", ""),
        "cube_area_pct": row.get("cube_area_pct", ""),
        "manual_source": row.get("manual_source", ""),
        "fx_gt": row.get("fx_gt", ""),
        "n_faces": len(detections),
        "patterns": _patterns_text(detections),
        "closure_status": "not_probed",
        "specs_tested": 0,
        "valid_trihedral_specs": 0,
        "gate_status": "not_probed",
        "gate_candidate_count": 0,
    }
    best: Optional[Dict[str, Any]] = None
    ranked: List[Dict[str, Any]] = []
    if len(detections) != 3 or len(set(labels)) != 3:
        out["closure_status"] = "invalid_face_set"
        if overlay_path is not None:
            _write_overlay(image, detections, None, out, overlay_path)
        return out
    if any(label not in {"XY", "XZ", "YZ"} for label in labels):
        out["closure_status"] = "unknown_label"
        if overlay_path is not None:
            _write_overlay(image, detections, None, out, overlay_path)
        return out

    try:
        K_seed = _intrinsics_from_vps(detections, (w_img, h_img))
    except Exception:
        K_seed = None

    for spec_idx, specs in enumerate(_candidate_specs(detections), 1):
        if max_specs is not None and spec_idx > max_specs:
            break
        quads = _spec_to_quads(detections, specs)
        if quads is None:
            continue
        edge_summary = _quad_edge_support_summary(quads, edge_dist, gray.shape)
        shared = _infer_shared_edge_indices(quads)
        tri = shared.get("__trihedral__", {})
        valid = bool(shared.get("__valid__") and tri.get("valid"))
        pnp_rmse = (
            _best_oriented_pnp_rmse(detections, specs, K_seed)
            if K_seed is not None else None
        )
        spread_norm = _maybe_float(tri.get("vertex_spread_max_norm"))
        spread_px = _maybe_float(tri.get("vertex_spread_max_px"))
        total_pair = _maybe_float(shared.get("__total_pair_score__"))
        max_pair = _maybe_float(shared.get("__max_pair_score__"))
        angle_sum = _maybe_float(shared.get("__angle_sum_deg__"))
        edge_mean = _maybe_float(edge_summary.get("edge_support_mean"))
        edge_min = _maybe_float(edge_summary.get("edge_support_min"))
        passes_gate = bool(
            valid
            and pnp_rmse is not None
            and pnp_rmse <= float(pnp_gate_px)
            and edge_min is not None
            and edge_min >= float(min_edge_support)
            and spread_norm is not None
            and spread_norm <= float(max_spread_norm)
        )
        rank_key = (
            0 if valid else 1,
            99.0 if pnp_rmse is None else pnp_rmse,
            99.0 if edge_min is None else -edge_min,
            99.0 if spread_norm is None else spread_norm,
            99.0 if total_pair is None else total_pair,
        )
        item = {
            "rank_key": rank_key,
            "valid": valid,
            "passes_gate": passes_gate,
            "specs": specs,
            "quads": quads,
            "shared": shared,
            "edge_summary": edge_summary,
            "pnp_rmse": pnp_rmse,
            "spread_norm": spread_norm,
            "spread_px": spread_px,
            "total_pair": total_pair,
            "max_pair": max_pair,
            "angle_sum": angle_sum,
            "edge_mean": edge_mean,
            "edge_min": edge_min,
        }
        ranked.append(item)

    ranked.sort(key=lambda item: item["rank_key"])
    out["specs_tested"] = len(ranked)
    out["valid_trihedral_specs"] = sum(1 for item in ranked if item["valid"])
    gate_candidates = [item for item in ranked if item.get("passes_gate")]
    out["gate_candidate_count"] = len(gate_candidates)
    out["gate_status"] = (
        "strict_edge_pnp_candidate" if gate_candidates
        else "no_strict_edge_pnp_candidate"
    )
    if gate_candidates:
        gate_best = gate_candidates[0]
        out.update({
            "gate_best_pnp_rmse_px": gate_best["pnp_rmse"],
            "gate_best_edge_support_min": gate_best["edge_min"],
            "gate_best_vertex_spread_norm": gate_best["spread_norm"],
            "gate_best_specs": gate_best["specs"],
        })
    if not ranked:
        out["closure_status"] = "no_projected_specs"
    else:
        best = ranked[0]
        tri = best["shared"].get("__trihedral__", {})
        out.update({
            "closure_status": (
                "valid_trihedral_closure"
                if best["valid"] else "no_valid_trihedral_closure"
            ),
            "best_rank": 1,
            "best_pnp_rmse_px": best["pnp_rmse"],
            "best_edge_support_mean": best["edge_mean"],
            "best_edge_support_min": best["edge_min"],
            "best_pair_score": best["total_pair"],
            "best_max_pair_score": best["max_pair"],
            "best_angle_sum_deg": best["angle_sum"],
            "best_vertex_spread_px": best["spread_px"],
            "best_vertex_spread_norm": best["spread_norm"],
            "best_common_vertex_px": tri.get("common_vertex_px"),
            "best_usage": best["shared"].get("__usage__", {}),
            "best_specs": best["specs"],
            "best_issues": best["shared"].get("__issues__", []),
        })

    if overlay_path is not None:
        _write_overlay(image, detections, best, out, overlay_path)
    return out


def _write_overlay(
    image: np.ndarray,
    detections: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    best: Optional[Dict[str, Any]],
    row: Dict[str, Any],
    path: Path,
) -> None:
    canvas = image.copy()
    for corners, _pattern, label in detections:
        color = FACE_COLORS.get(label, (240, 240, 240))
        pts = np.round(corners.reshape(-1, 2)).astype(np.int32)
        for x, y in pts:
            cv2.circle(canvas, (int(x), int(y)), 2, color, -1, cv2.LINE_AA)
        if len(pts):
            center = pts.mean(axis=0)
            cv2.putText(
                canvas,
                label,
                (int(center[0]), int(center[1])),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                color,
                2,
                cv2.LINE_AA,
            )

    if best is not None:
        quads = best.get("quads") or {}
        for label, info in quads.items():
            color = FACE_COLORS.get(label, (240, 240, 240))
            quad = np.round(np.asarray(info["quad"], dtype=np.float32)).astype(np.int32)
            cv2.polylines(canvas, [quad.reshape(-1, 1, 2)], True, color, 3, cv2.LINE_AA)
            anchor = quad.reshape(-1, 2).mean(axis=0)
            cv2.putText(
                canvas,
                f"{label} full={tuple(info['full_pattern'])} off={tuple(info['offset'])}",
                (int(anchor[0]), int(anchor[1])),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.45,
                color,
                1,
                cv2.LINE_AA,
            )
        tri = (best.get("shared") or {}).get("__trihedral__", {})
        if tri.get("valid") and tri.get("common_vertex_px"):
            vx, vy = [int(round(float(v))) for v in tri["common_vertex_px"]]
            cv2.circle(canvas, (vx, vy), 8, (255, 255, 255), -1, cv2.LINE_AA)
            cv2.circle(canvas, (vx, vy), 6, (0, 0, 0), 2, cv2.LINE_AA)
            for label, pt in (tri.get("per_face_vertex_points_px") or {}).items():
                color = FACE_COLORS.get(label, (240, 240, 240))
                px, py = [int(round(float(v))) for v in pt]
                cv2.circle(canvas, (px, py), 5, color, -1, cv2.LINE_AA)
                cv2.line(canvas, (vx, vy), (px, py), color, 2, cv2.LINE_AA)

    lines = [
        str(row.get("rel_path") or row.get("image") or ""),
        f"status: {row.get('closure_status', '')}",
        f"gate: {row.get('gate_status', '')} ({row.get('gate_candidate_count', '')})",
        f"valid/specs: {row.get('valid_trihedral_specs', '')}/{row.get('specs_tested', '')}",
        (
            f"pnp: {_fmt(row.get('best_pnp_rmse_px'))}, "
            f"edge: {_fmt(row.get('best_edge_support_min'))}, "
            f"spread: {_fmt(row.get('best_vertex_spread_norm'))}"
        ),
    ]
    _overlay_text(canvas, lines)
    path.parent.mkdir(parents=True, exist_ok=True)
    ok, buf = cv2.imencode(".jpg", canvas, [int(cv2.IMWRITE_JPEG_QUALITY), 92])
    if ok:
        buf.tofile(str(path))


def _overlay_text(canvas: np.ndarray, lines: Sequence[str]) -> None:
    if not lines:
        return
    font = cv2.FONT_HERSHEY_SIMPLEX
    scale = 0.62
    line_h = 24
    widths = []
    for line in lines:
        (tw, _th), _base = cv2.getTextSize(str(line), font, scale, 1)
        widths.append(tw)
    box_w = min(canvas.shape[1] - 8, max(widths, default=80) + 18)
    box_h = line_h * len(lines) + 14
    x, y = 8, 8
    cv2.rectangle(canvas, (x, y), (x + box_w, y + box_h), (255, 255, 255), -1)
    cv2.rectangle(canvas, (x, y), (x + box_w, y + box_h), (0, 0, 0), 1)
    for idx, line in enumerate(lines):
        cv2.putText(
            canvas,
            str(line),
            (x + 8, y + 22 + idx * line_h),
            font,
            scale,
            (0, 0, 0),
            1,
            cv2.LINE_AA,
        )


def _fmt(value: Any) -> str:
    try:
        f = float(value)
    except Exception:
        return "-"
    if not math.isfinite(f):
        return "-"
    return f"{f:.3f}"


def _write_markdown(path: Path, rows: List[Dict[str, Any]]) -> None:
    counts: Dict[str, int] = {}
    for row in rows:
        status = str(row.get("closure_status", ""))
        counts[status] = counts.get(status, 0) + 1
    lines = [
        "# Trihedral Closure Probe",
        "",
        f"- Images probed: {len(rows)}",
        f"- Closure status counts: `{counts}`",
        "",
        "| image | group | original status | closure | gate | cube area % | valid/specs | PnP RMSE | edge min | spread norm | specs |",
        "|---|---|---|---|---|---:|---:|---:|---:|---:|---|",
    ]
    for row in rows:
        valid = row.get("valid_trihedral_specs", "")
        total = row.get("specs_tested", "")
        specs = row.get("best_specs", "")
        lines.append(
            "| {image} | {group} | {status} | {closure} | {gate} | {area} | {valid}/{total} | {pnp} | {edge} | {spread} | `{specs}` |".format(
                image=row.get("image", ""),
                group=row.get("group", ""),
                status=row.get("status", ""),
                closure=row.get("closure_status", ""),
                gate=f"{row.get('gate_status', '')} ({row.get('gate_candidate_count', '')})",
                area=_fmt(row.get("cube_area_pct")),
                valid=valid,
                total=total,
                spread=_fmt(row.get("best_vertex_spread_norm")),
                pnp=_fmt(row.get("best_pnp_rmse_px")),
                edge=_fmt(row.get("best_edge_support_min")),
                specs=_specs_text(specs if isinstance(specs, dict) else None),
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _resolve_image(row: Dict[str, Any], image_root: Optional[Path]) -> Path:
    rel_path = str(row.get("rel_path") or "")
    if image_root is not None and rel_path:
        return image_root / rel_path
    workspace_path = str(row.get("workspace_path") or "")
    if workspace_path:
        return Path(workspace_path)
    raise FileNotFoundError(f"Cannot resolve image for row: {row}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch-csv", type=Path, required=True)
    parser.add_argument("--image-root", type=Path, default=None)
    parser.add_argument("--out-dir", type=Path, default=Path("batch_results/trihedral_closure_probe_v1"))
    parser.add_argument("--write-overlays", action="store_true")
    parser.add_argument(
        "--max-specs",
        type=int,
        default=0,
        help="Optional per-image cap for projected outline combinations.",
    )
    parser.add_argument("--pnp-gate-px", type=float, default=9.0)
    parser.add_argument("--min-edge-support", type=float, default=0.35)
    parser.add_argument("--max-spread-norm", type=float, default=0.08)
    args = parser.parse_args()

    rows = _read_csv(args.batch_csv)
    image_root = args.image_root.resolve() if args.image_root is not None else None
    out_rows: List[Dict[str, Any]] = []
    args.out_dir.mkdir(parents=True, exist_ok=True)
    for idx, row in enumerate(rows, 1):
        image_path = _resolve_image(row, image_root)
        overlay_path = None
        if args.write_overlays:
            safe_name = f"{row.get('group', '')}_{row.get('image', image_path.name)}".replace("/", "_")
            overlay_path = args.out_dir / "overlays" / f"{safe_name}_closure.jpg"
        result = probe_image(
            image_path,
            row,
            max_specs=(args.max_specs if args.max_specs > 0 else None),
            pnp_gate_px=args.pnp_gate_px,
            min_edge_support=args.min_edge_support,
            max_spread_norm=args.max_spread_norm,
            overlay_path=overlay_path,
        )
        out_rows.append(result)
        print(
            f"[{idx}/{len(rows)}] {result.get('rel_path')} "
            f"{result.get('closure_status')} {result.get('gate_status')} "
            f"valid={result.get('valid_trihedral_specs')}/"
            f"{result.get('specs_tested')}",
            flush=True,
        )

    csv_path = args.out_dir / "trihedral_closure_probe_results.csv"
    json_path = args.out_dir / "trihedral_closure_probe_results.json"
    md_path = args.out_dir / "trihedral_closure_probe_summary.md"
    _write_csv(csv_path, out_rows)
    json_path.write_text(
        json.dumps(_jsonable(out_rows), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    _write_markdown(md_path, out_rows)
    print(f"Wrote: {csv_path}")
    print(f"Wrote: {json_path}")
    print(f"Wrote: {md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
