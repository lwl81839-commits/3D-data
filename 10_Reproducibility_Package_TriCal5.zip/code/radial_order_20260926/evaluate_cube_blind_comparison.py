#!/usr/bin/env python3
"""Fair frozen-model comparison on non-development trihedral cube images."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from pathlib import Path
from statistics import median
from typing import Any

import cv2
import numpy as np

from evaluate_planar_blind_comparison import GROUPS, MODEL_PATHS, ZHANG
from evaluate_trained_camera_model import PoseSolution, face_ids, project_errors, stats, stratified_holdout
from face_detector import _normalize_face_axis_order, detect_corner_cube_faces
from trained_camera_model import (
    CORRESPONDENCE_CACHE_TAG,
    CorrespondenceSet,
    _geometric_inlier_filter,
    _repair_face_grid_association,
    extract_correspondences,
)


ROOT = Path(__file__).resolve().parent
IMAGE_DIRS = {group: ROOT / "image" / group for group in GROUPS}
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
FACE_NAMES = ("xoy_top", "xoz_front", "yoz_side")
DIRECT_THREE_FACE_CANDIDATES = {
    "20_0.870": {"t_1_11.jpg", "t_1_12.jpg", "t_1_13.jpg", "t_1_14.jpg", "t_1_15.jpg", "t_1_17.jpg"},
    "30_0.550": {"t_2_04.jpg", "t_2_09.jpg", "t_2_14.jpg", "t_2_15.jpg", "t_2_16.jpg", "t_2_17.jpg"},
    "45_0.870": {"t_3_08.jpg"},
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def blind_images(folder: Path, training_hashes: set[str]) -> list[Path]:
    return sorted(
        path.resolve() for path in folder.iterdir()
        if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES
        and not path.name.startswith("_")
        and "contact_sheet" not in path.stem.lower()
        and "roi_probe" not in path.stem.lower()
        and sha256_file(path).lower() not in training_hashes
    )


def finite(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): finite(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [finite(item) for item in value]
    if isinstance(value, np.ndarray):
        return finite(value.tolist())
    if isinstance(value, (np.floating, float)):
        result = float(value)
        return result if math.isfinite(result) else None
    if isinstance(value, (np.integer, int)):
        return int(value)
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    return value


def fmt(value: Any, digits: int = 3) -> str:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return "-"
    return f"{result:.{digits}f}" if math.isfinite(result) else "-"


def rotation_difference_deg(first: np.ndarray, second: np.ndarray) -> float:
    relative = first @ second.T
    cosine = float(np.clip((np.trace(relative) - 1.0) / 2.0, -1.0, 1.0))
    return float(np.degrees(np.arccos(cosine)))


def camera_center(pose: Any) -> np.ndarray:
    return -pose.R.T @ np.asarray(pose.tvec, np.float64).reshape(3)


def fast_common_extract(
    path: Path, square: float, K_mid: np.ndarray, dist_mid: np.ndarray,
    cache_path: Path, cube_hint: float | None,
) -> CorrespondenceSet:
    gray = cv2.imdecode(np.fromfile(str(path), np.uint8), cv2.IMREAD_GRAYSCALE)
    if gray is None:
        raise RuntimeError("image decode failed")
    detections = _normalize_face_axis_order(
        detect_corner_cube_faces(gray, n_faces=3, verbose=False)
    )
    if len(detections) < 3:
        raise RuntimeError(f"direct detector found only {len(detections)}/3 face groups")
    detections = detections[:3]
    image_groups = [
        np.asarray(corners, np.float64).reshape(-1, 2)
        for corners, _pattern, _label in detections
    ]
    patterns = tuple(tuple(int(value) for value in pattern) for _c, pattern, _l in detections)
    counts = tuple(len(group) for group in image_groups)
    raw = CorrespondenceSet(
        image_path=str(path), image_size=(gray.shape[1], gray.shape[0]),
        image_points=np.vstack(image_groups),
        object_points=np.zeros((sum(counts), 3), np.float64),
        K_seed=K_mid.copy(), dist_seed=dist_mid.copy(),
        R_seed=np.eye(3), t_seed=np.zeros(3),
        cube_area_pct=None, corner_quality=None,
        source_model="direct_face_detector_before_common_association",
        raw_corner_count=sum(counts), face_point_counts=counts,
        face_patterns=patterns,
    )
    repaired = _repair_face_grid_association(
        raw, K_mid, dist_mid, square,
        cube_side_squares=cube_hint,
        max_initial_rmse_px=50.0,
        max_initial_face_rmse_px=65.0,
    )
    if repaired is None:
        raise RuntimeError(f"common partial-grid association failed for patterns {patterns}")
    boundaries = np.cumsum([0, *(repaired.face_point_counts or ())])
    repaired_image_groups = [
        repaired.image_points[boundaries[index]:boundaries[index + 1]]
        for index in range(3)
    ]
    repaired_object_groups = [
        repaired.object_points[boundaries[index]:boundaries[index + 1]]
        for index in range(3)
    ]
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        cache_path,
        image_points=np.asarray(repaired_image_groups, dtype=object),
        object_points=np.asarray(repaired_object_groups, dtype=object),
        patterns=np.asarray(repaired.face_patterns, dtype=np.int32),
        image_size=np.asarray(repaired.image_size, dtype=np.int32),
        K_seed=K_mid, dist_seed=dist_mid,
        R_seed=np.eye(3), t_seed=np.zeros(3),
        image_path=np.asarray([str(path.resolve())]),
    )
    return _geometric_inlier_filter(
        repaired,
        focal_hint_px=float(0.5 * (K_mid[0, 0] + K_mid[1, 1])),
        k1_hint=float(dist_mid[0]), minimum_usable_faces=1,
        square_size_mm=square, cube_side_squares_hint=cube_hint,
        allow_independent_cube_search=True,
    )


def solve_pose(
    obj: np.ndarray, img: np.ndarray, indices: np.ndarray,
    K: np.ndarray, dist: np.ndarray,
) -> PoseSolution | None:
    """Deterministic all-inlier pose solve shared by both frozen models."""
    idx = np.asarray(indices, np.int32).reshape(-1)
    if len(idx) < 6:
        return None
    obj_use = np.ascontiguousarray(obj[idx], np.float64).reshape(-1, 1, 3)
    img_use = np.ascontiguousarray(img[idx], np.float64).reshape(-1, 1, 2)
    candidates: list[tuple[float, np.ndarray, np.ndarray, np.ndarray]] = []
    for flag in (cv2.SOLVEPNP_ITERATIVE, cv2.SOLVEPNP_EPNP):
        try:
            ok, rvec, tvec = cv2.solvePnP(obj_use, img_use, K, dist, flags=flag)
            if not ok:
                continue
            rvec, tvec = cv2.solvePnPRefineLM(obj_use, img_use, K, dist, rvec, tvec)
            R, _ = cv2.Rodrigues(rvec)
            depth = (obj[idx] @ R.T + tvec.reshape(1, 3))[:, 2]
            if float(np.mean(depth > 0.0)) < 0.99:
                continue
            projected, _ = cv2.projectPoints(obj_use, rvec, tvec, K, dist)
            delta = projected.reshape(-1, 2) - img[idx]
            rmse = float(np.sqrt(np.mean(np.sum(delta * delta, axis=1))))
            candidates.append((rmse, rvec.reshape(3), tvec.reshape(3), R))
        except cv2.error:
            continue
    if not candidates:
        return None
    _, rvec, tvec, R = min(candidates, key=lambda item: item[0])
    return PoseSolution(rvec=rvec, tvec=tvec, R=R, inlier_count=len(idx))


def evaluate_model(
    obj: np.ndarray,
    img: np.ndarray,
    ids: np.ndarray,
    K: np.ndarray,
    dist: np.ndarray,
    splits: list[tuple[np.ndarray, np.ndarray]],
) -> dict[str, Any]:
    all_idx = np.arange(len(obj), dtype=int)
    full_pose = solve_pose(obj, img, all_idx, K, dist)
    if full_pose is None:
        return {"pose_success": False}
    full_error = project_errors(obj, img, all_idx, full_pose, K, dist)
    holdout_values: list[float] = []
    for train_idx, held_idx in splits:
        pose = solve_pose(obj, img, train_idx, K, dist)
        if pose is None or len(held_idx) == 0:
            continue
        error = project_errors(obj, img, held_idx, pose, K, dist)
        holdout_values.append(float(np.sqrt(np.mean(error * error))))

    observed = sorted(int(value) for value in np.unique(ids))
    cross_face_rows: list[dict[str, Any]] = []
    if len(observed) >= 2:
        for held_face in observed:
            train_idx = np.flatnonzero(ids != held_face)
            test_idx = np.flatnonzero(ids == held_face)
            pose = solve_pose(obj, img, train_idx, K, dist)
            row: dict[str, Any] = {
                "held_face": FACE_NAMES[held_face],
                "n_train": len(train_idx), "n_test": len(test_idx),
                "success": pose is not None,
            }
            if pose is not None:
                error = project_errors(obj, img, test_idx, pose, K, dist)
                row["rmse_px"] = float(np.sqrt(np.mean(error * error)))
                row["median_px"] = float(np.median(error))
            cross_face_rows.append(row)

    single_face_poses: list[tuple[int, Any]] = []
    for face in observed:
        pose = solve_pose(obj, img, np.flatnonzero(ids == face), K, dist)
        if pose is not None:
            single_face_poses.append((face, pose))
    rotation_differences: list[float] = []
    center_differences: list[float] = []
    for index, (_, first) in enumerate(single_face_poses):
        for _, second in single_face_poses[index + 1:]:
            rotation_differences.append(rotation_difference_deg(first.R, second.R))
            center_differences.append(float(np.linalg.norm(camera_center(first) - camera_center(second))))

    cross_success = [row["rmse_px"] for row in cross_face_rows if row.get("success")]
    return {
        "pose_success": True,
        "full_reprojection_rmse_px": float(np.sqrt(np.mean(full_error * full_error))),
        "holdout_rmse_px": None if not holdout_values else float(median(holdout_values)),
        "holdout_successful_repeats": len(holdout_values),
        "cross_face_rmse_px": None if not cross_success else float(np.sqrt(np.mean(np.square(cross_success)))),
        "cross_face_rows": cross_face_rows,
        "single_face_pose_count": len(single_face_poses),
        "face_pose_rotation_difference_deg": (
            None if not rotation_differences else float(median(rotation_differences))
        ),
        "face_pose_camera_center_difference_mm": (
            None if not center_differences else float(median(center_differences))
        ),
    }


def summarize(rows: list[dict[str, Any]], group: str, model_name: str) -> dict[str, Any]:
    selected = [
        row for row in rows if row["group"] == group and row.get("model") == model_name
        and row.get("pose_success")
    ]
    strict = [row for row in selected if row.get("faces_used") == 3]
    multi = [row for row in selected if row.get("faces_used", 0) >= 2]
    return {
        "group": group, "model": model_name, "evaluated_images": len(selected),
        "strict_three_face_images": len(strict), "multi_face_images": len(multi),
        "full_reprojection_rmse_px": stats(
            row["full_reprojection_rmse_px"] for row in selected
        ),
        "holdout_rmse_px": stats(
            row["holdout_rmse_px"] for row in selected if row.get("holdout_rmse_px") is not None
        ),
        "strict_two_faces_predict_third_rmse_px": stats(
            row["cross_face_rmse_px"] for row in strict if row.get("cross_face_rmse_px") is not None
        ),
        "multi_face_cross_prediction_rmse_px": stats(
            row["cross_face_rmse_px"] for row in multi if row.get("cross_face_rmse_px") is not None
        ),
        "face_pose_rotation_difference_deg": stats(
            row["face_pose_rotation_difference_deg"] for row in multi
            if row.get("face_pose_rotation_difference_deg") is not None
        ),
        "face_pose_camera_center_difference_mm": stats(
            row["face_pose_camera_center_difference_mm"] for row in multi
            if row.get("face_pose_camera_center_difference_mm") is not None
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "image/cube_blind_comparison")
    parser.add_argument("--repeats", type=int, default=30)
    parser.add_argument("--holdout-fraction", type=float, default=0.20)
    parser.add_argument("--seed", type=int, default=20260810)
    parser.add_argument("--only-existing-cache", action="store_true")
    parser.add_argument("--direct-three-face-candidates", action="store_true")
    args = parser.parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    cache_dir = output / ".common_correspondence_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    manifests: dict[str, Any] = {}

    for group_index, group in enumerate(GROUPS):
        model_path = MODEL_PATHS[group].resolve()
        model = json.loads(model_path.read_text(encoding="utf-8"))
        training_hashes = {
            str(item.get("sha256") or "").lower() for item in model.get("training_images", [])
        }
        images = blind_images(IMAGE_DIRS[group].resolve(), training_hashes)
        if args.direct_three_face_candidates:
            images = [path for path in images if path.name in DIRECT_THREE_FACE_CANDIDATES[group]]
        manifests[group] = {
            "model": str(model_path), "blind_images": [path.name for path in images],
            "training_hash_count": len(training_hashes),
        }
        square = float(model["square_size_mm"])
        target = model.get("target_geometry", {})
        cube_hint = target.get("selected_cube_side_squares")
        K_ours = np.asarray(model["cameraMatrix"], np.float64).reshape(3, 3)
        dist_ours = np.asarray(model["distCoeffs"], np.float64).reshape(5)
        K_zhang = np.asarray(ZHANG[group]["K"], np.float64).reshape(3, 3)
        dist_zhang = np.asarray(ZHANG[group]["dist"], np.float64).reshape(5)
        for image_index, path in enumerate(images):
            print(f"[{group} {image_index + 1}/{len(images)}] {path.name}", flush=True)
            started = time.perf_counter()
            digest = sha256_file(path)
            square_tag = f"{square:.9g}".replace(".", "p")
            cache_path = cache_dir / f"{digest}_sq{square_tag}_{CORRESPONDENCE_CACHE_TAG}.npz"
            reusable_cache = (
                model_path.parent / ".trihedral_correspondence_cache"
                / f"{digest}_sq{square_tag}_{CORRESPONDENCE_CACHE_TAG}.npz"
            )
            extraction_cache = cache_path if cache_path.is_file() else reusable_cache
            if not extraction_cache.is_file():
                extraction_cache = cache_path
            if args.only_existing_cache and not extraction_cache.is_file():
                failures.append({
                    "group": group, "image": path.name,
                    "error": "common correspondence cache not available",
                    "elapsed_seconds": 0.0,
                })
                print("  skipped: common correspondence cache not available", flush=True)
                continue
            try:
                image = cv2.imdecode(np.fromfile(str(path), np.uint8), cv2.IMREAD_GRAYSCALE)
                if image is None:
                    raise RuntimeError("image decode failed")
                generic_focal = 0.25 * (
                    float(K_ours[0, 0]) + float(K_ours[1, 1])
                    + float(K_zhang[0, 0]) + float(K_zhang[1, 1])
                )
                generic_k1 = 0.5 * (float(dist_ours[0]) + float(dist_zhang[0]))
                K_mid = 0.5 * (K_ours + K_zhang)
                K_mid[2] = [0.0, 0.0, 1.0]
                dist_mid = 0.5 * (dist_ours + dist_zhang)
                if extraction_cache.is_file():
                    sample = extract_correspondences(
                        str(path), square,
                        focal_hint_px=generic_focal, k1_hint=generic_k1,
                        correspondence_cache_path=str(extraction_cache),
                        minimum_usable_faces=1,
                        cube_side_squares_hint=None if cube_hint is None else float(cube_hint),
                        allow_independent_cube_search=True,
                    )
                else:
                    sample = fast_common_extract(
                        path, square, K_mid, dist_mid, cache_path,
                        None if cube_hint is None else float(cube_hint),
                    )
                    extraction_cache = cache_path
                obj = np.asarray(sample.object_points, np.float64).reshape(-1, 3)
                img = np.asarray(sample.image_points, np.float64).reshape(-1, 2)
                ids = face_ids(obj)
                observed = sorted(int(value) for value in np.unique(ids))
                rng = np.random.default_rng(args.seed + group_index * 10000 + image_index)
                splits = []
                for _ in range(args.repeats):
                    train_idx, held_idx = stratified_holdout(ids, rng, args.holdout_fraction, 3)
                    splits.append((train_idx, held_idx))
                elapsed_extract = float(time.perf_counter() - started)
                for model_name, K, dist in (
                    ("ours", K_ours, dist_ours), ("zhang", K_zhang, dist_zhang)
                ):
                    result = evaluate_model(obj, img, ids, K, dist, splits)
                    result.update({
                        "group": group, "image": path.name, "model": model_name,
                        "points": len(obj), "faces_used": len(observed),
                        "observed_faces": [FACE_NAMES[index] for index in observed],
                        "face_inliers": list(sample.face_inlier_counts or (0, 0, 0)),
                        "extraction_seconds": elapsed_extract,
                        "common_correspondence_cache": str(extraction_cache),
                    })
                    rows.append(result)
                    print(
                        f"  {model_name}: faces={len(observed)} "
                        f"holdout={fmt(result.get('holdout_rmse_px'))} "
                        f"cross={fmt(result.get('cross_face_rmse_px'))}", flush=True,
                    )
            except Exception as exc:
                failures.append({
                    "group": group, "image": path.name, "error": str(exc),
                    "elapsed_seconds": float(time.perf_counter() - started),
                })
                print(f"  extraction failed: {exc}", flush=True)

    summaries = [
        summarize(rows, group, model_name)
        for group in GROUPS for model_name in ("ours", "zhang")
    ]
    payload = finite({
        "schema": "cube-blind-common-correspondence-comparison/v1",
        "no_development_images_used": True,
        "common_extraction_prior": "symmetric_midpoint_of_two_frozen_models_used_only_for_shared_discrete_association",
        "zhang_parameter_source": str((ROOT / "image/zhang/dataset_split/zhang.docx").resolve()),
        "manifests": manifests, "summaries": summaries, "rows": rows, "failures": failures,
    })
    (output / "cube_blind_comparison.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    keys = list(dict.fromkeys(key for row in rows for key in row))
    with (output / "image_metrics.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                key: json.dumps(value, ensure_ascii=False, separators=(",", ":"))
                if isinstance(value, (dict, list, tuple)) else value
                for key, value in row.items()
            })
    lines = [
        "# 三面立方体独立盲测：公共对应点比较", "",
        "所有开发图片均按模型SHA-256记录排除；每张盲测图只提取一次公共对应点。", "",
        "样本流转：原始非开发立方体图片29张；直接三面检测筛出13张候选；公共物理网格关联成功8张，其中严格三面1张、两面4张、单面3张，另5张关联失败。未进入候选的16张只检测到少于三面。", "",
        "| 姿态 | 模型 | 有效图 | 三面图 | 多面图 | 留出RMSE中位(px) | 两面预测第三面RMSE中位(px) | 多面跨面RMSE中位(px) | 面间旋转差中位(°) |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for item in summaries:
        lines.append(
            f"| {item['group']} | {item['model']} | {item['evaluated_images']} | "
            f"{item['strict_three_face_images']} | {item['multi_face_images']} | "
            f"{fmt(item['holdout_rmse_px']['median'])} | "
            f"{fmt(item['strict_two_faces_predict_third_rmse_px']['median'])} | "
            f"{fmt(item['multi_face_cross_prediction_rmse_px']['median'])} | "
            f"{fmt(item['face_pose_rotation_difference_deg']['median'])} |"
        )
    lines += ["", "## 提取失败", ""]
    if failures:
        lines.extend(f"- `{row['group']}/{row['image']}`：{row['error']}" for row in failures)
    else:
        lines.append("- 无")
    lines += [
        "", "## 解释", "",
        "- 严格三维主指标是两面求位姿后预测完全未参与求解的第三面。",
        "- 两面图只能做一面预测另一面；单面图不进入严格跨面评价。",
        "- 公共角点离散关联使用两套冻结模型参数的对称中点作为唯一提示，不偏向任意一方；最终点集完全相同。",
        "- 立方体尺寸参与目标坐标构建，因此本报告仍是三维目标内部预测，不代替独立实物真值。",
    ]
    (output / "CUBE_BLIND_COMPARISON.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Report: {output / 'CUBE_BLIND_COMPARISON.md'}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
