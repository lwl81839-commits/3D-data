#!/usr/bin/env python3
"""Batch-evaluate the current cube-first calibration pipeline.

The method takes one physical scale input: the checkerboard square edge
length.  The current image set uses 25 mm by default, but the value can be
overridden for another same-square-size cube target.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
import statistics
import subprocess
import sys
import time
import traceback
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from calibration_policy import (
    NORMAL_RELIABLE_CUBE_AREA_PCT,
    area_preflight_decision,
    calibration_decision,
    cube_area_policy,
)


IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
DEFAULT_SQUARE_SIZE_MM = 25.0
# Backward-compatible name used by older helper code; no longer a hard prior.
FIXED_SQUARE_SIZE_MM = DEFAULT_SQUARE_SIZE_MM
MIN_RELIABLE_CUBE_AREA_PCT = NORMAL_RELIABLE_CUBE_AREA_PCT
BOUNDARY_OR_UNUSABLE_STATUSES = {
    "range_boundary",
    "target_too_small",
    "low_confidence",
    "focal_not_identifiable",
    "partial_face_geometry_boundary",
    "insufficient_visible_faces",
    "target_not_visible",
}
PHYSICAL_PROBE_DEFAULT_STATUSES = {
    "low_confidence",
    "partial_face_geometry_boundary",
    "insufficient_visible_faces",
}
AREA_RATIO_BINS = [
    ("unknown", None, None),
    ("<4", 0.0, 4.0),
    ("4-6", 4.0, 6.0),
    ("6-8", 6.0, 8.0),
    ("8-10", 8.0, 10.0),
    ("10-12", 10.0, 12.0),
    ("12-15", 12.0, 15.0),
    ("15-20", 15.0, 20.0),
    (">=20", 20.0, None),
]


CALIBRATION_SUBPROCESS_CODE = r"""
import contextlib
import io
import json
import math
import os
import re
import sys

from pathlib import Path

from calibration_router import calibrate_with_optional_recovery
from calibration_manifest_gate import (
    CANONICAL_FACE_PATTERNS,
    stability_gate_for_image,
    stability_hold_message,
)


def maybe_float(value):
    if value is None:
        return None
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def flatten_dist(dist):
    if dist is None:
        return [None, None, None, None, None]
    try:
        values = list(dist.ravel())
    except AttributeError:
        try:
            values = list(dist)
        except TypeError:
            values = []
    values = [maybe_float(v) for v in values]
    while len(values) < 5:
        values.append(None)
    return values[:5]


def coverage_from_error(text):
    match = re.search(r"too small \(([\d.]+)%", text, flags=re.IGNORECASE)
    if not match:
        match = re.search(r"coverage is only ([\d.]+)%", text, flags=re.IGNORECASE)
    return maybe_float(match.group(1)) if match else None


image_path = sys.argv[1]
focal_arg = sys.argv[2] if len(sys.argv) > 2 else ""
focal_px = None if not focal_arg else float(focal_arg)
k1_arg = sys.argv[3] if len(sys.argv) > 3 else ""
k1_prior = None if not k1_arg else float(k1_arg)
image_root = sys.argv[4] if len(sys.argv) > 4 else ""
square_arg = sys.argv[5] if len(sys.argv) > 5 else "25.0"
square_size_mm = float(square_arg)

use_stability_manifest = os.environ.get(
    "CALIB_USE_STABILITY_MANIFEST", "1"
).strip().lower() not in {"0", "false", "no", "off"}
if use_stability_manifest:
    gate = stability_gate_for_image(
        image_path,
        image_root=Path(image_root) if image_root else None,
    )
    gate_fields = {
        "stability_gate": "matched" if gate.matched else "not_matched",
        "stability_final_decision": gate.final_decision,
        "stability_baseline_decision": gate.baseline_decision,
        "stability_stress_decision": gate.stress_decision,
        "stability_reasons": gate.reasons,
        "stability_corners_path": "" if gate.corners_path is None else str(gate.corners_path),
        "stability_face_patterns": (
            ""
            if not gate.face_patterns
            else ";".join(f"{c}x{r}" for c, r in gate.face_patterns)
        ),
    }
else:
    gate = None
    gate_fields = {
        "stability_gate": "disabled",
        "stability_final_decision": "",
        "stability_baseline_decision": "",
        "stability_stress_decision": "",
        "stability_reasons": "disabled by method profile",
        "stability_corners_path": "",
        "stability_face_patterns": "",
    }

try:
    if gate is not None and gate.matched and not gate.accepted:
        raise RuntimeError(stability_hold_message(gate))
    corners_path = (
        str(gate.corners_path)
        if gate is not None and gate.available_for_calibration
        else None
    )
    face_patterns = (
        gate.face_patterns
        if gate is not None and gate.face_patterns
        else CANONICAL_FACE_PATTERNS
    )
    effective_focal_px = (
        focal_px
        if focal_px is not None
        else (
            gate.focal_px
            if gate is not None and gate.available_for_calibration
            else None
        )
    )
    with contextlib.redirect_stdout(io.StringIO()):
        result = calibrate_with_optional_recovery(
            image_path,
            square_size_mm,
            face_patterns=face_patterns,
            n_faces=3,
            focal_px=effective_focal_px,
            k1_prior=k1_prior,
            verbose=False,
            corners_path=corners_path,
        )
    if gate is not None and gate.available_for_calibration:
        result.warnings.append(
            "Used final single-frame stability manifest before calibration: "
            f"{gate.rel_path}, decision={gate.final_decision}."
        )
    k1, k2, p1, p2, k3 = flatten_dist(getattr(result, "dist", None))
    out = {
        "status": "ok",
        "model": getattr(result, "model_used", ""),
        "n_faces_detected": getattr(result, "n_faces_detected", None),
        "n_corners": getattr(result, "n_corners", None),
        "fov_coverage_pct": maybe_float(getattr(result, "fov_coverage_pct", None)),
        "cube_area_pct": maybe_float(getattr(result, "cube_area_pct", None)),
        "corner_quality": maybe_float(getattr(result, "corner_quality", None)),
        "rmse_px": maybe_float(getattr(result, "rmse", None)),
        "elapsed_sec": maybe_float(getattr(result, "elapsed_sec", None)),
        "fx_px": maybe_float(getattr(result, "fx_px", None)),
        "fy_px": maybe_float(getattr(result, "fy_px", None)),
        "skew_px": maybe_float(getattr(result, "skew_px", None)),
        "cx_px": maybe_float(getattr(result, "cx_px", None)),
        "cy_px": maybe_float(getattr(result, "cy_px", None)),
        "k1": k1,
        "k2": k2,
        "p1": p1,
        "p2": p2,
        "k3": k3,
        "height_mm": maybe_float(getattr(result, "height_mm", None)),
        "downtilt_deg": maybe_float(getattr(result, "downtilt_deg", None)),
        "preflight": getattr(result, "preflight", {}) or {},
        "warnings": " | ".join(str(w) for w in getattr(result, "warnings", []) or []),
    }
    out.update(gate_fields)
except Exception as exc:
    text = str(exc)
    out = {
        "status": "error",
        "error": text,
        "fov_coverage_pct": coverage_from_error(text),
    }
    out.update(gate_fields)

print(json.dumps(out, ensure_ascii=False))
"""


CSV_FIELDS = [
    "workspace_path",
    "rel_path",
    "group",
    "image",
    "method_profile",
    "method_scope",
    "method_focal_regularizer",
    "square_size_mm",
    "model_grade",
    "focal_prior_px",
    "k1_prior",
    "uses_intrinsic_prior",
    "intrinsic_prior_source",
    "status",
    "stability_gate",
    "stability_final_decision",
    "stability_baseline_decision",
    "stability_stress_decision",
    "stability_reasons",
    "stability_corners_path",
    "stability_face_patterns",
    "decision",
    "area_band",
    "area_policy",
    "recognition_status",
    "recognition_label",
    "calibration_status",
    "calibration_label",
    "router_stage",
    "grid_recovery_status",
    "grid_recovery_route",
    "grid_recovery_enabled_routes",
    "grid_recovery_staged",
    "grid_recovery_stage",
    "grid_recovery_stage_summaries",
    "grid_recovery_patterns",
    "grid_recovery_elapsed_sec",
    "grid_recovery_rmse_px",
    "grid_recovery_corners_path",
    "grid_recovery_focal_px",
    "grid_recovery_focal_source",
    "sam_recovery_status",
    "can_attempt_detection",
    "can_attempt_calibration",
    "can_accept_automatic",
    "requires_strict_small_target_gate",
    "is_boundary",
    "error",
    "model",
    "n_faces_detected",
    "n_corners",
    "fov_coverage_pct",
    "cube_area_pct",
    "corner_quality",
    "rmse_px",
    "elapsed_sec",
    "wall_elapsed_sec",
    "fx_px",
    "fy_px",
    "skew_px",
    "cx_px",
    "cy_px",
    "k1",
    "k2",
    "p1",
    "p2",
    "k3",
    "height_mm",
    "downtilt_deg",
    "physical_source",
    "physical_status",
    "physical_reason",
    "physical_recovery_action",
    "physical_n_faces",
    "physical_n_corners",
    "physical_mean_line_quality",
    "physical_labels_patterns",
    "physical_sparse_faces",
    "physical_initial_pnp_rmse",
    "physical_per_face_pnp_rmse",
    "physical_single_view_model",
    "physical_single_view_rmse",
    "physical_single_view_fx",
    "physical_single_view_fy",
    "physical_single_view_cx",
    "physical_single_view_cy",
    "physical_single_view_k1",
    "physical_offset_model",
    "physical_offset_rmse",
    "physical_offset_pnp_rmse",
    "physical_offset_fx",
    "physical_offset_fy",
    "physical_offset_cx",
    "physical_offset_cy",
    "physical_offset_k1",
    "physical_offset_fx_err_px",
    "physical_offset_fy_err_px",
    "physical_offset_cx_err_px",
    "physical_offset_cy_err_px",
    "physical_offset_fx_abs_err_pct",
    "physical_offset_fy_abs_err_pct",
    "physical_offset_cx_abs_err_px",
    "physical_offset_cy_abs_err_px",
    "physical_offset_k1_abs_err",
    "physical_offset",
    "physical_vp_desc",
    "physical_source_summaries",
    "manual_source",
    "manual_accepted",
    "manual_rms_px",
    "fx_gt",
    "fy_gt",
    "cx_gt",
    "cy_gt",
    "k1_gt",
    "k2_gt",
    "p1_gt",
    "p2_gt",
    "k3_gt",
    "fx_err_px",
    "fy_err_px",
    "cx_err_px",
    "cy_err_px",
    "fx_abs_err_pct",
    "fy_abs_err_pct",
    "cx_abs_err_px",
    "cy_abs_err_px",
    "k1_abs_err",
    "k2_abs_err",
    "warnings",
]


def _first_existing_extracted_root() -> Path:
    for extracted in sorted(Path(".").glob("*_extracted")):
        candidate = extracted / "shengkelou"
        if candidate.is_dir():
            return candidate
    raise FileNotFoundError("Could not find an extracted image root matching *_extracted/shengkelou")


def _first_zip() -> Optional[Path]:
    zips = sorted(Path(".").glob("*.zip"))
    return zips[0] if zips else None


def _iter_images(root: Path) -> List[Path]:
    return sorted(p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_SUFFIXES)


def _read_filter_values(values: Optional[List[str]], files: Optional[List[Path]]) -> List[str]:
    out: List[str] = []
    for value in values or []:
        value = str(value).strip()
        if value:
            out.append(value)
    for path in files or []:
        for line in path.read_text(encoding="utf-8-sig").splitlines():
            value = line.strip()
            if value and not value.startswith("#"):
                out.append(value)
    return out


def _filter_images(
    images: List[Path],
    root: Path,
    *,
    groups: Optional[List[str]] = None,
    rel_paths: Optional[List[str]] = None,
) -> List[Path]:
    group_filter = {str(g).strip() for g in groups or [] if str(g).strip()}
    rel_order = [
        str(p).strip().replace("\\", "/")
        for p in rel_paths or []
        if str(p).strip()
    ]
    rel_filter = set(rel_order)
    if not group_filter and not rel_filter:
        return images

    selected: List[Path] = []
    if rel_order:
        image_by_rel = {_safe_rel(path, root).replace("\\", "/"): path for path in images}
        seen: set[str] = set()
        for rel in rel_order:
            if rel in seen:
                continue
            path = image_by_rel.get(rel)
            if path is None:
                continue
            if group_filter and path.parent.name not in group_filter:
                continue
            selected.append(path)
            seen.add(rel)
        return selected

    for path in images:
        rel = _safe_rel(path, root).replace("\\", "/")
        if group_filter and path.parent.name not in group_filter:
            continue
        if rel_filter and rel not in rel_filter:
            continue
        selected.append(path)
    return selected


def _maybe_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(f):
        return None
    return f


def _model_grade(row: Dict[str, Any]) -> str:
    status = str(row.get("status", ""))
    if status != "ok":
        if str(row.get("decision", "")) == "boundary" or row.get("is_boundary"):
            return "boundary_or_reject"
        return "failed_or_rejected"
    model = str(row.get("model", ""))
    if model == "vp-only":
        return "diagnostic_only"
    if model.startswith("single-cube-zhang"):
        return "full_single_cube_zhang"
    if model in {"5-param", "k1-only"}:
        return "free_intrinsic_ba"
    if (
        model.startswith("fixed-focal")
        or model.startswith("fixed-intrinsics")
        or model.startswith("single-view-wide-offset-fixed-focal")
    ):
        return "bounded_focal_pose"
    if model.startswith("single-view-wide-offset-focal-scan"):
        return "bounded_focal_scan"
    if model.startswith("single-view"):
        return "bounded_single_view"
    return "accepted_other"


def _method_focal_regularizer(row: Dict[str, Any]) -> str:
    if _maybe_float(row.get("focal_prior_px")) is not None:
        return "external_or_group_intrinsic_prior"
    source = str(row.get("grid_recovery_focal_source") or "").strip()
    if source:
        return source
    if str(row.get("model", "")).startswith("single-cube-zhang"):
        return "none_full_zhang"
    return "none"


def _safe_rel(path: Path, base: Path) -> str:
    try:
        return path.resolve().relative_to(base.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def _estimate_cube_area_for_path(path: Path) -> Optional[float]:
    try:
        import cv2
        import numpy as np
        from face_detector import estimate_cube_area_pct

        data = np.fromfile(str(path), dtype=np.uint8)
        img = cv2.imdecode(data, cv2.IMREAD_COLOR)
        if img is None:
            return None
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        return _maybe_float(estimate_cube_area_pct(gray, n_faces=3))
    except Exception:
        return None


def _base_row(path: Path, root: Path, cwd_path: Path) -> Dict[str, Any]:
    cube_area_pct = _estimate_cube_area_for_path(path)
    preflight = area_preflight_decision(cube_area_pct)
    return {
        "workspace_path": _safe_rel(path, cwd_path),
        "rel_path": _safe_rel(path, root),
        "group": path.parent.name,
        "image": path.name,
        "method_profile": "",
        "method_scope": "",
        "method_focal_regularizer": "",
        "square_size_mm": None,
        "model_grade": "",
        "focal_prior_px": None,
        "k1_prior": None,
        "uses_intrinsic_prior": False,
        "intrinsic_prior_source": "",
        "status": "pending",
        "stability_gate": "",
        "stability_final_decision": "",
        "stability_baseline_decision": "",
        "stability_stress_decision": "",
        "stability_reasons": "",
        "stability_corners_path": "",
        "stability_face_patterns": "",
        "router_stage": "",
        "grid_recovery_status": "",
        "grid_recovery_route": "",
        "grid_recovery_enabled_routes": "",
        "grid_recovery_staged": "",
        "grid_recovery_stage": "",
        "grid_recovery_stage_summaries": "",
        "grid_recovery_patterns": "",
        "grid_recovery_elapsed_sec": None,
        "grid_recovery_rmse_px": None,
        "grid_recovery_corners_path": "",
        "grid_recovery_focal_px": None,
        "grid_recovery_focal_source": "",
        "sam_recovery_status": "",
        "error": "",
        "model": "",
        "n_faces_detected": None,
        "n_corners": None,
        "fov_coverage_pct": None,
        "cube_area_pct": cube_area_pct,
        "preflight": preflight,
        "corner_quality": None,
        "rmse_px": None,
        "elapsed_sec": None,
        "wall_elapsed_sec": None,
        "fx_px": None,
        "fy_px": None,
        "skew_px": None,
        "cx_px": None,
        "cy_px": None,
        "k1": None,
        "k2": None,
        "p1": None,
        "p2": None,
        "k3": None,
        "height_mm": None,
        "downtilt_deg": None,
        "physical_source": "",
        "physical_status": "",
        "physical_reason": "",
        "physical_recovery_action": "",
        "physical_n_faces": None,
        "physical_n_corners": None,
        "physical_mean_line_quality": None,
        "physical_labels_patterns": "",
        "physical_sparse_faces": None,
        "physical_initial_pnp_rmse": None,
        "physical_per_face_pnp_rmse": "",
        "physical_single_view_model": "",
        "physical_single_view_rmse": None,
        "physical_single_view_fx": None,
        "physical_single_view_fy": None,
        "physical_single_view_cx": None,
        "physical_single_view_cy": None,
        "physical_single_view_k1": None,
        "physical_offset_model": "",
        "physical_offset_rmse": None,
        "physical_offset_pnp_rmse": None,
        "physical_offset_fx": None,
        "physical_offset_fy": None,
        "physical_offset_cx": None,
        "physical_offset_cy": None,
        "physical_offset_k1": None,
        "physical_offset_fx_err_px": None,
        "physical_offset_fy_err_px": None,
        "physical_offset_cx_err_px": None,
        "physical_offset_cy_err_px": None,
        "physical_offset_fx_abs_err_pct": None,
        "physical_offset_fy_abs_err_pct": None,
        "physical_offset_cx_abs_err_px": None,
        "physical_offset_cy_abs_err_px": None,
        "physical_offset_k1_abs_err": None,
        "physical_offset": "",
        "physical_vp_desc": "",
        "physical_source_summaries": "",
        "warnings": "",
    }


def _status_from_exception(exc: Exception, cube_area_pct: Optional[float] = None) -> str:
    msg = str(exc).lower()
    area = _maybe_float(cube_area_pct)
    if "stability manifest hold" in msg:
        return "low_confidence"
    if "not cube target" in msg:
        return "not_cube_target"
    if "focal length is not identifiable" in msg:
        return "focal_not_identifiable"
    if "range boundary" in msg:
        return "range_boundary"
    if "low-confidence" in msg or "low confidence" in msg:
        return "low_confidence"
    if "partial-face geometry boundary" in msg:
        return "partial_face_geometry_boundary"
    if "insufficient visible cube faces" in msg:
        return "insufficient_visible_faces"
    if "found only" in msg and "visible faces" in msg:
        return "insufficient_visible_faces"
    if "no faces detected" in msg and area is not None and area >= MIN_RELIABLE_CUBE_AREA_PCT:
        return "insufficient_visible_faces"
    if "no calibration target detected" in msg:
        return "target_not_visible"
    if "no faces detected" in msg and area is None:
        return "target_not_visible"
    if "target too small" in msg or "too small" in msg:
        return "target_too_small"
    if "calibration boundary" in msg or "recapture closer" in msg:
        return "target_too_small"
    if "detect" in msg or "corner" in msg or "face" in msg:
        return "detect_failed"
    if "decode" in msg or "file not found" in msg:
        return "file_error"
    return "error"


def _coverage_from_error(exc: Exception) -> Optional[float]:
    text = str(exc)
    match = re.search(r"too small \(([\d.]+)%", text, flags=re.IGNORECASE)
    if not match:
        match = re.search(r"coverage is only ([\d.]+)%", text, flags=re.IGNORECASE)
    if not match:
        return None
    return _maybe_float(match.group(1))


def _apply_decision_fields(row: Dict[str, Any]) -> None:
    decision = calibration_decision(row.get("status"), row.get("cube_area_pct"))
    row["decision"] = decision["decision"]
    row["area_band"] = decision["area_band"]
    row["area_policy"] = decision["area_policy"]
    for key in [
        "recognition_status",
        "recognition_label",
        "calibration_status",
        "calibration_label",
        "can_attempt_detection",
        "can_attempt_calibration",
        "can_accept_automatic",
        "requires_strict_small_target_gate",
        "is_boundary",
    ]:
        row[key] = decision.get(key)

    runtime_preflight = row.get("preflight")
    has_runtime_router_context = (
        isinstance(runtime_preflight, dict)
        and (
            row.get("status") == "ok"
            or bool(runtime_preflight.get("router_stage"))
            or isinstance(runtime_preflight.get("grid_recovery"), dict)
            or isinstance(runtime_preflight.get("sam_recovery"), dict)
        )
    )
    if has_runtime_router_context:
        for key in [
            "recognition_status",
            "recognition_label",
            "calibration_status",
            "calibration_label",
            "can_attempt_detection",
            "can_attempt_calibration",
            "can_accept_automatic",
            "requires_strict_small_target_gate",
            "is_boundary",
        ]:
            if key in runtime_preflight:
                row[key] = runtime_preflight.get(key)
        row["router_stage"] = str(runtime_preflight.get("router_stage") or "")
        grid = runtime_preflight.get("grid_recovery")
        if isinstance(grid, dict):
            row["grid_recovery_status"] = grid.get("status", "")
            row["grid_recovery_route"] = grid.get("selected_route", "")
            row["grid_recovery_enabled_routes"] = grid.get("enabled_routes", "")
            row["grid_recovery_staged"] = grid.get("grid_recovery_staged", "")
            row["grid_recovery_stage"] = grid.get("grid_recovery_stage", "")
            row["grid_recovery_stage_summaries"] = grid.get("grid_recovery_stage_summaries", "")
            row["grid_recovery_patterns"] = grid.get("extrapolated_patterns", "")
            row["grid_recovery_elapsed_sec"] = _maybe_float(grid.get("elapsed_sec"))
            row["grid_recovery_rmse_px"] = _maybe_float(grid.get("rmse_px"))
            row["grid_recovery_corners_path"] = grid.get("corners_path", "")
            row["grid_recovery_focal_px"] = _maybe_float(grid.get("grid_recovery_focal_px"))
            row["grid_recovery_focal_source"] = grid.get("grid_recovery_focal_source", "")
        sam = runtime_preflight.get("sam_recovery")
        if isinstance(sam, dict):
            row["sam_recovery_status"] = sam.get("status", "")

    if row.get("status") == "ok" and row.get("uses_intrinsic_prior"):
        row["decision"] = "held"
        row["recognition_status"] = "recognized_with_intrinsic_prior"
        row["recognition_label"] = "RECOGNIZED WITH INTRINSIC PRIOR"
        row["calibration_status"] = "prior_assisted_research_only"
        row["calibration_label"] = "PRIOR-ASSISTED"
        row["can_accept_automatic"] = False
        row["is_boundary"] = False
    elif (
        row.get("status") == "ok"
        and row.get("stability_final_decision")
        in {
            "stable_pass",
            "accept",
            "partial_sparse_pass",
            "alternate_strict_pass",
            "ideal_axis_pass",
            "crop_replace_pass",
            "crop_scale_sparse_pass",
            "crop_complete_pass",
            "crop_local_k1_pass",
            "relaxed_axis_replay_pass",
            "grid_expand_pass",
        }
    ):
        row["recognition_status"] = "stability_manifest_pass"
        row["recognition_label"] = "STABILITY MANIFEST PASS"
        row["calibration_status"] = "final_manifest_calibration"
        row["calibration_label"] = "FINAL MANIFEST CALIBRATION"
        row["can_attempt_calibration"] = True
        row["can_accept_automatic"] = True
        row["is_boundary"] = False


def _apply_stability_gate_fields(row: Dict[str, Any], gate: Any) -> None:
    row["stability_gate"] = "matched" if gate.matched else "not_matched"
    row["stability_final_decision"] = gate.final_decision
    row["stability_baseline_decision"] = gate.baseline_decision
    row["stability_stress_decision"] = gate.stress_decision
    row["stability_reasons"] = gate.reasons
    row["stability_corners_path"] = "" if gate.corners_path is None else str(gate.corners_path)
    row["stability_face_patterns"] = (
        ""
        if not getattr(gate, "face_patterns", None)
        else ";".join(f"{c}x{r}" for c, r in gate.face_patterns)
    )


def _copy_physical_probe_fields(row: Dict[str, Any], probe: Dict[str, Any]) -> None:
    mapping = {
        "source": "physical_source",
        "physical_status": "physical_status",
        "reason": "physical_reason",
        "recovery_action": "physical_recovery_action",
        "n_faces": "physical_n_faces",
        "n_corners": "physical_n_corners",
        "mean_line_quality": "physical_mean_line_quality",
        "labels_patterns": "physical_labels_patterns",
        "sparse_faces": "physical_sparse_faces",
        "initial_pnp_rmse": "physical_initial_pnp_rmse",
        "per_face_pnp_rmse": "physical_per_face_pnp_rmse",
        "single_view_model": "physical_single_view_model",
        "single_view_rmse": "physical_single_view_rmse",
        "single_view_fx": "physical_single_view_fx",
        "single_view_fy": "physical_single_view_fy",
        "single_view_cx": "physical_single_view_cx",
        "single_view_cy": "physical_single_view_cy",
        "single_view_k1": "physical_single_view_k1",
        "offset_model": "physical_offset_model",
        "offset_rmse": "physical_offset_rmse",
        "offset_pnp_rmse": "physical_offset_pnp_rmse",
        "offset_fx": "physical_offset_fx",
        "offset_fy": "physical_offset_fy",
        "offset_cx": "physical_offset_cx",
        "offset_cy": "physical_offset_cy",
        "offset_k1": "physical_offset_k1",
        "offset": "physical_offset",
        "vp_desc": "physical_vp_desc",
        "source_summaries": "physical_source_summaries",
    }
    for src, dst in mapping.items():
        row[dst] = probe.get(src, "")


def _apply_physical_probe(
    row: Dict[str, Any],
    image_root: Path,
    *,
    angle_thresh_deg: float,
    physical_sources: List[str],
    vp_sources: List[str],
) -> None:
    try:
        from physical_cube_model_probe import probe_one as physical_probe_one

        probe = physical_probe_one(
            row,
            image_root,
            angle_thresh_deg,
            vp_sources,
            physical_sources,
            try_label_permutations=True,
        )
        _copy_physical_probe_fields(row, probe)
    except Exception as exc:
        row["physical_status"] = "physical_probe_error"
        row["physical_reason"] = str(exc)
        row["physical_recovery_action"] = "fix physical probe error before interpreting this row"


def _flatten_dist(dist: Any) -> List[Optional[float]]:
    if dist is None:
        return [None, None, None, None, None]
    try:
        values = list(dist.ravel())  # numpy arrays
    except AttributeError:
        try:
            values = list(dist)
        except TypeError:
            values = []
    values = [_maybe_float(v) for v in values]
    while len(values) < 5:
        values.append(None)
    return values[:5]


def _run_one(
    image_path: str,
    image_root: str,
    cwd: str,
    square_size_mm: float,
    focal_px: Optional[float],
    k1_prior: Optional[float],
) -> Dict[str, Any]:
    from calibration_router import calibrate_with_optional_recovery
    from calibration_manifest_gate import (
        CANONICAL_FACE_PATTERNS,
        stability_gate_for_image,
        stability_hold_message,
    )

    path = Path(image_path)
    root = Path(image_root)
    cwd_path = Path(cwd)
    started = time.perf_counter()

    row: Dict[str, Any] = _base_row(path, root, cwd_path)
    row["square_size_mm"] = float(square_size_mm)
    row["focal_prior_px"] = _maybe_float(focal_px)
    row["k1_prior"] = _maybe_float(k1_prior)

    try:
        use_stability_manifest = os.environ.get(
            "CALIB_USE_STABILITY_MANIFEST", "1"
        ).strip().lower() not in {"0", "false", "no", "off"}
        if use_stability_manifest:
            gate = stability_gate_for_image(path, image_root=root)
            _apply_stability_gate_fields(row, gate)
            if gate.matched and not gate.accepted:
                raise RuntimeError(stability_hold_message(gate))
            corners_path = (
                str(gate.corners_path) if gate.available_for_calibration else None
            )
            face_patterns = gate.face_patterns or CANONICAL_FACE_PATTERNS
        else:
            gate = None
            row.update({
                "stability_gate": "disabled",
                "stability_reasons": "disabled by method profile",
            })
            corners_path = None
            face_patterns = CANONICAL_FACE_PATTERNS
        result = calibrate_with_optional_recovery(
            str(path),
            square_size_mm,
            face_patterns=face_patterns,
            n_faces=3,
            focal_px=focal_px,
            k1_prior=k1_prior,
            verbose=False,
            corners_path=corners_path,
        )
        if gate is not None and gate.available_for_calibration:
            result.warnings.append(
                "Used final single-frame stability manifest before calibration: "
                f"{gate.rel_path}, decision={gate.final_decision}."
            )
        k1, k2, p1, p2, k3 = _flatten_dist(getattr(result, "dist", None))
        row.update(
            {
                "status": "ok",
                "model": getattr(result, "model_used", ""),
                "n_faces_detected": getattr(result, "n_faces_detected", None),
                "n_corners": getattr(result, "n_corners", None),
                "fov_coverage_pct": _maybe_float(getattr(result, "fov_coverage_pct", None)),
                "cube_area_pct": _maybe_float(getattr(result, "cube_area_pct", None)),
                "corner_quality": _maybe_float(getattr(result, "corner_quality", None)),
                "rmse_px": _maybe_float(getattr(result, "rmse", None)),
                "elapsed_sec": _maybe_float(getattr(result, "elapsed_sec", None)),
                "fx_px": _maybe_float(getattr(result, "fx_px", None)),
                "fy_px": _maybe_float(getattr(result, "fy_px", None)),
                "skew_px": _maybe_float(getattr(result, "skew_px", None)),
                "cx_px": _maybe_float(getattr(result, "cx_px", None)),
                "cy_px": _maybe_float(getattr(result, "cy_px", None)),
                "k1": k1,
                "k2": k2,
                "p1": p1,
                "p2": p2,
                "k3": k3,
                "height_mm": _maybe_float(getattr(result, "height_mm", None)),
                "downtilt_deg": _maybe_float(getattr(result, "downtilt_deg", None)),
                "preflight": getattr(result, "preflight", {}) or {},
                "warnings": " | ".join(str(w) for w in getattr(result, "warnings", []) or []),
            }
        )
    except Exception as exc:
        row["status"] = _status_from_exception(exc, row.get("cube_area_pct"))
        row["error"] = str(exc)
        row["fov_coverage_pct"] = _coverage_from_error(exc)
        row["elapsed_sec"] = time.perf_counter() - started
        row["wall_elapsed_sec"] = row["elapsed_sec"]
        if "Stability manifest hold" in str(exc):
            row["warnings"] = ""
        else:
            row["warnings"] = traceback.format_exc(limit=1).strip().replace("\n", " | ")
    if row.get("wall_elapsed_sec") is None:
        row["wall_elapsed_sec"] = time.perf_counter() - started
    return row


def _run_one_subprocess(
    image_path: str,
    image_root: str,
    cwd: str,
    square_size_mm: float,
    focal_px: Optional[float],
    k1_prior: Optional[float],
    timeout_sec: float,
) -> Dict[str, Any]:
    path = Path(image_path)
    root = Path(image_root)
    cwd_path = Path(cwd)
    started = time.perf_counter()
    row: Dict[str, Any] = _base_row(path, root, cwd_path)
    row["square_size_mm"] = float(square_size_mm)
    row["focal_prior_px"] = _maybe_float(focal_px)
    row["k1_prior"] = _maybe_float(k1_prior)
    focal_arg = "" if focal_px is None else str(float(focal_px))
    k1_arg = "" if k1_prior is None else str(float(k1_prior))
    cmd = [
        sys.executable,
        "-X",
        "utf8",
        "-c",
        CALIBRATION_SUBPROCESS_CODE,
        str(path),
        focal_arg,
        k1_arg,
        str(root),
        str(float(square_size_mm)),
    ]

    try:
        proc = subprocess.Popen(
            cmd,
            cwd=str(Path.cwd()),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        stdout, stderr = proc.communicate(timeout=timeout_sec)
    except subprocess.TimeoutExpired:
        if "proc" in locals():
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False,
                )
            else:
                proc.kill()
            try:
                stdout, stderr = proc.communicate(timeout=5.0)
            except Exception:
                stdout, stderr = "", ""
        row["status"] = "timeout"
        row["error"] = f"Timed out after {timeout_sec:.1f}s"
        row["elapsed_sec"] = time.perf_counter() - started
        row["wall_elapsed_sec"] = row["elapsed_sec"]
        return row

    wall_elapsed = time.perf_counter() - started
    row["elapsed_sec"] = wall_elapsed
    row["wall_elapsed_sec"] = wall_elapsed
    if proc.returncode != 0:
        row["status"] = "process_error"
        details = (stderr or stdout or "").strip()
        row["error"] = details[-1000:] if details else f"Subprocess exited with code {proc.returncode}"
        return row

    json_line = None
    for line in reversed((stdout or "").splitlines()):
        if line.strip().startswith("{"):
            json_line = line.strip()
            break
    if not json_line:
        row["status"] = "process_error"
        row["error"] = "Subprocess returned no JSON output"
        return row

    try:
        data = json.loads(json_line)
    except json.JSONDecodeError as exc:
        row["status"] = "process_error"
        row["error"] = f"Could not parse subprocess JSON: {exc}"
        return row

    if data.get("status") == "ok":
        row.update(data)
        row["wall_elapsed_sec"] = wall_elapsed
    else:
        err = str(data.get("error", "Calibration failed"))
        for key in [
            "stability_gate",
            "stability_final_decision",
            "stability_baseline_decision",
            "stability_stress_decision",
            "stability_reasons",
            "stability_corners_path",
            "stability_face_patterns",
        ]:
            if key in data:
                row[key] = data.get(key)
        row["status"] = _status_from_exception(RuntimeError(err), row.get("cube_area_pct"))
        row["error"] = err
        row["fov_coverage_pct"] = data.get("fov_coverage_pct") or _coverage_from_error(RuntimeError(err))
    return row


def _load_manual_ground_truth(zip_path: Optional[Path]) -> Tuple[Dict[str, Dict[str, Any]], Optional[Dict[str, Any]], str]:
    if zip_path is None:
        return {}, None, "no_zip"
    try:
        from comprehensive_analysis import parse_all_docx

        per_image, zhang = parse_all_docx(zip_path)
        return per_image or {}, zhang or None, str(zip_path)
    except Exception as exc:
        return {}, None, f"parse_failed: {exc}"


def _gt_for_row(
    row: Dict[str, Any],
    per_image_gt: Dict[str, Dict[str, Any]],
    zhang_gt: Optional[Dict[str, Any]],
) -> Tuple[str, Optional[Dict[str, Any]]]:
    image = row.get("image")
    group = str(row.get("group", ""))
    if image in per_image_gt:
        return "per_image_docx", per_image_gt[image]
    if group.lower() == "zhang" and zhang_gt and "fx" in zhang_gt:
        return "zhang_reference", zhang_gt
    return "", None


def _join_ground_truth(
    rows: List[Dict[str, Any]],
    per_image_gt: Dict[str, Dict[str, Any]],
    zhang_gt: Optional[Dict[str, Any]],
) -> None:
    for row in rows:
        source, gt = _gt_for_row(row, per_image_gt, zhang_gt)
        row["manual_source"] = source
        row["manual_accepted"] = gt.get("accepted") if gt else None
        row["manual_rms_px"] = _maybe_float(gt.get("rms_px", gt.get("rms"))) if gt else None

        for key in ["fx", "fy", "cx", "cy", "k1", "k2", "p1", "p2", "k3"]:
            row[f"{key}_gt"] = _maybe_float(gt.get(key)) if gt else None

        if gt:
            for key in ["fx", "fy", "cx", "cy"]:
                measured = _maybe_float(row.get(f"physical_offset_{key}"))
                truth = _maybe_float(row.get(f"{key}_gt"))
                if measured is None or truth is None:
                    continue
                err = measured - truth
                row[f"physical_offset_{key}_err_px"] = err
                if key in {"fx", "fy"} and abs(truth) > 1e-12:
                    row[f"physical_offset_{key}_abs_err_pct"] = abs(err) / abs(truth) * 100.0
                else:
                    row[f"physical_offset_{key}_abs_err_px"] = abs(err)

            measured_k1 = _maybe_float(row.get("physical_offset_k1"))
            truth_k1 = _maybe_float(row.get("k1_gt"))
            if measured_k1 is not None and truth_k1 is not None:
                row["physical_offset_k1_abs_err"] = abs(measured_k1 - truth_k1)

        if row.get("status") != "ok" or not gt:
            continue

        for key in ["fx", "fy", "cx", "cy"]:
            measured = _maybe_float(row.get(f"{key}_px"))
            truth = _maybe_float(row.get(f"{key}_gt"))
            if measured is None or truth is None:
                continue
            err = measured - truth
            row[f"{key}_err_px"] = err
            if key in {"fx", "fy"} and abs(truth) > 1e-12:
                row[f"{key}_abs_err_pct"] = abs(err) / abs(truth) * 100.0
            else:
                row[f"{key}_abs_err_px"] = abs(err)

        for key in ["k1", "k2"]:
            measured = _maybe_float(row.get(key))
            truth = _maybe_float(row.get(f"{key}_gt"))
            if measured is not None and truth is not None:
                row[f"{key}_abs_err"] = abs(measured - truth)


def _clean_for_csv(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, float):
        if not math.isfinite(value):
            return ""
        return f"{value:.10g}"
    return value


def _write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: _clean_for_csv(row.get(k)) for k in CSV_FIELDS})


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return str(value)


def _write_json(path: Path, data: Any) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump(_jsonable(data), f, ensure_ascii=False, indent=2)


def _load_group_focal_priors(path: Optional[Path]) -> Dict[str, Dict[str, Optional[float]]]:
    if path is None:
        return {}
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    groups = data.get("groups", data)
    priors: Dict[str, Dict[str, Optional[float]]] = {}
    if not isinstance(groups, dict):
        return priors
    for group, info in groups.items():
        if not isinstance(info, dict) or info.get("status") != "ok":
            continue
        result = info.get("result")
        if not isinstance(result, dict):
            continue
        focal = _maybe_float(result.get("fx_px"))
        k1 = _maybe_float(result.get("k1"))
        if focal is not None and focal > 0:
            priors[str(group)] = {"focal_px": focal, "k1": k1}
    return priors


def _mean(rows: Iterable[Dict[str, Any]], key: str) -> Optional[float]:
    values = [_maybe_float(r.get(key)) for r in rows]
    values = [v for v in values if v is not None]
    return statistics.fmean(values) if values else None


def _median(rows: Iterable[Dict[str, Any]], key: str) -> Optional[float]:
    values = [_maybe_float(r.get(key)) for r in rows]
    values = [v for v in values if v is not None]
    return statistics.median(values) if values else None


def _percentile(
    rows: Iterable[Dict[str, Any]], key: str, percentile: float
) -> Optional[float]:
    values = sorted(
        value
        for value in (_maybe_float(row.get(key)) for row in rows)
        if value is not None
    )
    if not values:
        return None
    if len(values) == 1:
        return values[0]
    position = (len(values) - 1) * percentile / 100.0
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    if lower == upper:
        return values[lower]
    fraction = position - lower
    return values[lower] * (1.0 - fraction) + values[upper] * fraction


def _area_ratio_bin(area_pct: Any) -> str:
    area = _maybe_float(area_pct)
    if area is None:
        return "unknown"
    for label, lo, hi in AREA_RATIO_BINS:
        if label == "unknown":
            continue
        if lo is not None and area < lo:
            continue
        if hi is not None and area >= hi:
            continue
        return label
    return "unknown"


def _build_area_bin_summary(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    summaries: List[Dict[str, Any]] = []
    for label, lo, hi in AREA_RATIO_BINS:
        bin_rows = [r for r in rows if _area_ratio_bin(r.get("cube_area_pct")) == label]
        if not bin_rows:
            continue
        ok_rows = [r for r in bin_rows if r.get("status") == "ok"]
        gt_ok_rows = [r for r in ok_rows if r.get("manual_source") and r.get("fx_gt") is not None]
        status_counts = Counter(str(r.get("status", "")) for r in bin_rows)
        decision_counts = Counter(str(r.get("decision", "")) for r in bin_rows)
        recognition_counts = Counter(str(r.get("recognition_status", "")) for r in bin_rows)
        calibration_counts = Counter(str(r.get("calibration_status", "")) for r in bin_rows)
        physical_counts = Counter(
            str(r.get("physical_status", "")) for r in bin_rows
            if r.get("physical_status")
        )
        boundary_or_unusable = sum(
            status_counts.get(status, 0) for status in BOUNDARY_OR_UNUSABLE_STATUSES
        )
        summaries.append(
            {
                "area_bin_pct": label,
                "area_min_pct": lo,
                "area_max_pct": hi,
                "images": len(bin_rows),
                "ok": len(ok_rows),
                "ok_rate_pct": (100.0 * len(ok_rows) / len(bin_rows)) if bin_rows else None,
                "boundary_or_unusable": boundary_or_unusable,
                "errors": len(bin_rows) - len(ok_rows) - boundary_or_unusable,
                "status_counts": dict(status_counts),
                "decision_counts": dict(decision_counts),
                "recognition_status_counts": dict(recognition_counts),
                "calibration_status_counts": dict(calibration_counts),
                "physical_status_counts": dict(physical_counts),
                "manual_reference_rows": sum(1 for r in bin_rows if r.get("manual_source")),
                "ok_with_manual_reference": len(gt_ok_rows),
                "model_counts": dict(Counter(str(r.get("model", "")) for r in ok_rows if r.get("model"))),
                "mean_cube_area_pct": _mean(bin_rows, "cube_area_pct"),
                "mean_coverage_pct": _mean(ok_rows, "fov_coverage_pct"),
                "mean_rmse_px": _mean(ok_rows, "rmse_px"),
                "mean_wall_elapsed_sec": _mean(bin_rows, "wall_elapsed_sec"),
                "median_wall_elapsed_sec": _median(bin_rows, "wall_elapsed_sec"),
                "p90_wall_elapsed_sec": _percentile(
                    bin_rows, "wall_elapsed_sec", 90.0
                ),
                "mean_ok_elapsed_sec": _mean(ok_rows, "elapsed_sec"),
                "mean_fx_abs_err_pct": _mean(gt_ok_rows, "fx_abs_err_pct"),
                "mean_fy_abs_err_pct": _mean(gt_ok_rows, "fy_abs_err_pct"),
            }
        )
    return summaries


def _build_summary(
    rows: List[Dict[str, Any]],
    per_image_gt: Dict[str, Dict[str, Any]],
    zhang_gt: Optional[Dict[str, Any]],
    image_root: Path,
    zip_source: str,
    square_size_mm: float,
) -> Dict[str, Any]:
    generated_at = datetime.now().isoformat(timespec="seconds")
    groups = sorted(set(str(r.get("group", "")) for r in rows))
    group_summary: Dict[str, Any] = {}

    for group in groups:
        group_rows = [r for r in rows if str(r.get("group", "")) == group]
        ok_rows = [r for r in group_rows if r.get("status") == "ok"]
        gt_ok_rows = [r for r in ok_rows if r.get("manual_source") and r.get("fx_gt") is not None]
        status_counts = Counter(str(r.get("status", "")) for r in group_rows)
        decision_counts = Counter(str(r.get("decision", "")) for r in group_rows)
        recognition_counts = Counter(str(r.get("recognition_status", "")) for r in group_rows)
        calibration_counts = Counter(str(r.get("calibration_status", "")) for r in group_rows)
        physical_counts = Counter(
            str(r.get("physical_status", "")) for r in group_rows
            if r.get("physical_status")
        )
        model_counts = Counter(str(r.get("model", "")) for r in ok_rows if r.get("model"))
        boundary_or_unusable = sum(
            status_counts.get(status, 0) for status in BOUNDARY_OR_UNUSABLE_STATUSES
        )

        group_summary[group] = {
            "images": len(group_rows),
            "status_counts": dict(status_counts),
            "decision_counts": dict(decision_counts),
            "recognition_status_counts": dict(recognition_counts),
            "calibration_status_counts": dict(calibration_counts),
            "physical_status_counts": dict(physical_counts),
            "ok": len(ok_rows),
            "target_too_small": status_counts.get("target_too_small", 0),
            "boundary_or_unusable": boundary_or_unusable,
            "errors": len(group_rows) - len(ok_rows) - boundary_or_unusable,
            "manual_reference_rows": sum(1 for r in group_rows if r.get("manual_source")),
            "ok_with_manual_reference": len(gt_ok_rows),
            "model_counts": dict(model_counts),
            "mean_rmse_px": _mean(ok_rows, "rmse_px"),
            "median_rmse_px": _median(ok_rows, "rmse_px"),
            "mean_coverage_pct": _mean(ok_rows, "fov_coverage_pct"),
            "median_coverage_pct": _median(ok_rows, "fov_coverage_pct"),
            "mean_cube_area_pct": _mean(ok_rows, "cube_area_pct"),
            "median_cube_area_pct": _median(ok_rows, "cube_area_pct"),
            "mean_fx_abs_err_pct": _mean(gt_ok_rows, "fx_abs_err_pct"),
            "mean_fy_abs_err_pct": _mean(gt_ok_rows, "fy_abs_err_pct"),
            "mean_cx_abs_err_px": _mean(gt_ok_rows, "cx_abs_err_px"),
            "mean_cy_abs_err_px": _mean(gt_ok_rows, "cy_abs_err_px"),
            "mean_k1_abs_err": _mean(gt_ok_rows, "k1_abs_err"),
        }

    ok_rows_all = [r for r in rows if r.get("status") == "ok"]
    gt_ok_rows_all = [r for r in ok_rows_all if r.get("manual_source") and r.get("fx_gt") is not None]
    cube_target_rows = [
        r for r in rows
        if str(r.get("group", "")).lower() != "zhang"
    ]
    return {
        "generated_at": generated_at,
        "square_size_mm": float(square_size_mm),
        "image_root": str(image_root),
        "zip_source": zip_source,
        "total_images": len(rows),
        "manual_per_image_entries": len(per_image_gt),
        "manual_per_image_with_fx": sum(1 for v in per_image_gt.values() if isinstance(v, dict) and "fx" in v),
        "has_zhang_reference": bool(zhang_gt and "fx" in zhang_gt),
        "status_counts": dict(Counter(str(r.get("status", "")) for r in rows)),
        "decision_counts": dict(Counter(str(r.get("decision", "")) for r in rows)),
        "recognition_status_counts": dict(Counter(str(r.get("recognition_status", "")) for r in rows)),
        "calibration_status_counts": dict(Counter(str(r.get("calibration_status", "")) for r in rows)),
        "method_profile_counts": dict(Counter(str(r.get("method_profile", "")) for r in rows)),
        "method_focal_regularizer_counts": dict(Counter(
            str(r.get("method_focal_regularizer", "")) for r in rows
            if r.get("method_focal_regularizer")
        )),
        "model_grade_counts": dict(Counter(
            str(r.get("model_grade", "")) for r in rows
            if r.get("model_grade")
        )),
        "physical_status_counts": dict(Counter(
            str(r.get("physical_status", "")) for r in rows
            if r.get("physical_status")
        )),
        "model_counts": dict(Counter(str(r.get("model", "")) for r in ok_rows_all if r.get("model"))),
        "ok": len(ok_rows_all),
        "ok_with_manual_reference": len(gt_ok_rows_all),
        "mean_rmse_px": _mean(ok_rows_all, "rmse_px"),
        "median_rmse_px": _median(ok_rows_all, "rmse_px"),
        "mean_coverage_pct": _mean(ok_rows_all, "fov_coverage_pct"),
        "median_coverage_pct": _median(ok_rows_all, "fov_coverage_pct"),
        "mean_cube_area_pct": _mean(ok_rows_all, "cube_area_pct"),
        "median_cube_area_pct": _median(ok_rows_all, "cube_area_pct"),
        "mean_fx_abs_err_pct": _mean(gt_ok_rows_all, "fx_abs_err_pct"),
        "mean_fy_abs_err_pct": _mean(gt_ok_rows_all, "fy_abs_err_pct"),
        "mean_cx_abs_err_px": _mean(gt_ok_rows_all, "cx_abs_err_px"),
        "mean_cy_abs_err_px": _mean(gt_ok_rows_all, "cy_abs_err_px"),
        "mean_k1_abs_err": _mean(gt_ok_rows_all, "k1_abs_err"),
        "groups": group_summary,
        "cube_target_area_bins": _build_area_bin_summary(cube_target_rows),
        "all_image_area_bins": _build_area_bin_summary(rows),
    }


def _fmt(value: Any, digits: int = 3) -> str:
    value = _maybe_float(value)
    if value is None:
        return "-"
    return f"{value:.{digits}f}"


def _write_markdown(path: Path, summary: Dict[str, Any], rows: List[Dict[str, Any]]) -> None:
    lines = [
        "# Current Batch Calibration Evaluation",
        "",
        f"- Generated: {summary['generated_at']}",
        f"- Image root: `{summary['image_root']}`",
        f"- Square size: {summary['square_size_mm']:.1f} mm",
        f"- Method profile: `{summary.get('method_profile', 'manual')}`",
        f"- Method scope: `{summary.get('method_scope', 'manual')}`",
        f"- Images: {summary['total_images']}",
        f"- OK: {summary['ok']}",
        f"- Status counts: `{summary['status_counts']}`",
        f"- Decision counts: `{summary['decision_counts']}`",
        f"- Recognition counts: `{summary['recognition_status_counts']}`",
        f"- Calibration gate counts: `{summary['calibration_status_counts']}`",
        f"- Model grade counts: `{summary.get('model_grade_counts', {})}`",
        f"- Focal regularizer counts: `{summary.get('method_focal_regularizer_counts', {})}`",
        f"- Grid recovery enabled: `{summary.get('grid_recovery_enabled', False)}`",
        f"- Physical cube counts: `{summary.get('physical_status_counts', {})}`",
        f"- Manual per-image entries: {summary['manual_per_image_entries']} "
        f"({summary['manual_per_image_with_fx']} with intrinsics)",
        f"- Zhang reference available: {summary['has_zhang_reference']}",
        "",
        "## Group Summary",
        "",
        "| group | images | ok | boundary/unusable | errors | ok+ref | mean cube area % | mean coverage % | mean RMSE px | mean fx err % | mean fy err % | mean cx err px | mean cy err px | models |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for group, data in summary["groups"].items():
        lines.append(
            "| {group} | {images} | {ok} | {boundary} | {errors} | {ok_ref} | {cube} | {cov} | {rmse} | {fxe} | {fye} | {cxe} | {cye} | `{models}` |".format(
                group=group,
                images=data["images"],
                ok=data["ok"],
                boundary=data["boundary_or_unusable"],
                errors=data["errors"],
                ok_ref=data["ok_with_manual_reference"],
                cube=_fmt(data["mean_cube_area_pct"]),
                cov=_fmt(data["mean_coverage_pct"]),
                rmse=_fmt(data["mean_rmse_px"]),
                fxe=_fmt(data["mean_fx_abs_err_pct"]),
                fye=_fmt(data["mean_fy_abs_err_pct"]),
                cxe=_fmt(data["mean_cx_abs_err_px"]),
                cye=_fmt(data["mean_cy_abs_err_px"]),
                models=data["model_counts"],
            )
        )

    lines.extend(
        [
            "",
            "## Cube Area-Ratio Summary",
            "",
            "Non-Zhang target images only; area is cube footprint / full image area.",
            "",
            "| cube area % | images | accepted | boundary | held | ok rate % | range boundary | partial geometry | insufficient faces | target not visible | mean RMSE px | mean wall s | median wall s | P90 wall s | mean accepted s | mean fx err % | models |",
            "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
        ]
    )
    for data in summary.get("cube_target_area_bins", []):
        statuses = data.get("status_counts", {})
        decisions = data.get("decision_counts", {})
        lines.append(
            "| {area} | {images} | {accepted} | {boundary} | {held} | {ok_rate} | {range_boundary} | {partial} | {insufficient} | {not_visible} | {rmse} | {mean_wall} | {median_wall} | {p90_wall} | {mean_ok} | {fxe} | `{models}` |".format(
                area=data.get("area_bin_pct", ""),
                images=data["images"],
                accepted=decisions.get("accepted", 0),
                boundary=decisions.get("boundary", 0),
                held=decisions.get("held", 0),
                ok_rate=_fmt(data.get("ok_rate_pct")),
                range_boundary=statuses.get("range_boundary", 0),
                partial=statuses.get("partial_face_geometry_boundary", 0),
                insufficient=statuses.get("insufficient_visible_faces", 0),
                not_visible=statuses.get("target_not_visible", 0),
                rmse=_fmt(data.get("mean_rmse_px")),
                mean_wall=_fmt(data.get("mean_wall_elapsed_sec"), 1),
                median_wall=_fmt(data.get("median_wall_elapsed_sec"), 1),
                p90_wall=_fmt(data.get("p90_wall_elapsed_sec"), 1),
                mean_ok=_fmt(data.get("mean_ok_elapsed_sec"), 1),
                fxe=_fmt(data.get("mean_fx_abs_err_pct")),
                models=data.get("model_counts", {}),
            )
        )

    with_ref = [r for r in rows if r.get("manual_source") and r.get("fx_gt") is not None]
    lines.extend(
        [
            "",
            "## Manual Reference Rows",
            "",
            "| image | group | status | source | cube area % | fx px | fx gt | fx err % | fy err % | cx err px | cy err px | rmse px |",
            "|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for row in sorted(with_ref, key=lambda r: (str(r.get("group", "")), str(r.get("image", "")))):
        lines.append(
            "| {image} | {group} | {status} | {source} | {cube} | {fx} | {fxgt} | {fxe} | {fye} | {cxe} | {cye} | {rmse} |".format(
                image=row.get("image", ""),
                group=row.get("group", ""),
                status=row.get("status", ""),
                source=row.get("manual_source", ""),
                cube=_fmt(row.get("cube_area_pct")),
                fx=_fmt(row.get("fx_px")),
                fxgt=_fmt(row.get("fx_gt")),
                fxe=_fmt(row.get("fx_abs_err_pct")),
                fye=_fmt(row.get("fy_abs_err_pct")),
                cxe=_fmt(row.get("cx_abs_err_px")),
                cye=_fmt(row.get("cy_abs_err_px")),
                rmse=_fmt(row.get("rmse_px")),
            )
        )

    physical_offset_ref = [
        r for r in rows
        if r.get("manual_source")
        and r.get("physical_offset_model")
        and r.get("fx_gt") is not None
    ]
    if physical_offset_ref:
        lines.extend(
            [
                "",
                "## Physical Offset Reference Rows",
                "",
                "| image | group | status | manual accepted | physical status | offset | model | offset RMSE px | fx err % | fy err % | cx err px | cy err px | k1 err |",
                "|---|---|---|---|---|---|---|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for row in sorted(physical_offset_ref, key=lambda r: (str(r.get("group", "")), str(r.get("image", "")))):
            lines.append(
                "| {image} | {group} | {status} | {accepted} | {physical} | {offset} | {model} | {rmse} | {fxe} | {fye} | {cxe} | {cye} | {k1e} |".format(
                    image=row.get("image", ""),
                    group=row.get("group", ""),
                    status=row.get("status", ""),
                    accepted=row.get("manual_accepted", ""),
                    physical=row.get("physical_status", ""),
                    offset=row.get("physical_offset", ""),
                    model=row.get("physical_offset_model", ""),
                    rmse=_fmt(row.get("physical_offset_rmse")),
                    fxe=_fmt(row.get("physical_offset_fx_abs_err_pct")),
                    fye=_fmt(row.get("physical_offset_fy_abs_err_pct")),
                    cxe=_fmt(row.get("physical_offset_cx_abs_err_px")),
                    cye=_fmt(row.get("physical_offset_cy_abs_err_px")),
                    k1e=_fmt(row.get("physical_offset_k1_abs_err")),
                )
            )

    failed = [r for r in rows if r.get("status") != "ok"]
    if failed:
        lines.extend(
            [
                "",
                "## Non-OK Images",
                "",
                "| image | group | status | cube area % | physical status | physical PnP | physical action | physical reason | error |",
                "|---|---|---|---:|---|---:|---|---|---|",
            ]
        )
        for row in sorted(failed, key=lambda r: (str(r.get("group", "")), str(r.get("image", "")))):
            error = str(row.get("error", "")).replace("|", "/")
            if len(error) > 180:
                error = error[:177] + "..."
            physical_reason = str(row.get("physical_reason", "")).replace("|", "/")
            if len(physical_reason) > 140:
                physical_reason = physical_reason[:137] + "..."
            physical_action = str(row.get("physical_recovery_action", "")).replace("|", "/")
            if len(physical_action) > 120:
                physical_action = physical_action[:117] + "..."
            lines.append(
                f"| {row.get('image', '')} | {row.get('group', '')} | {row.get('status', '')} | "
                f"{_fmt(row.get('cube_area_pct'))} | {row.get('physical_status', '')} | "
                f"{_fmt(row.get('physical_initial_pnp_rmse'))} | {physical_action} | "
                f"{physical_reason} | {error} |"
            )

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image-root", type=Path, default=None, help="Root containing calibration image groups")
    parser.add_argument("--zip", type=Path, default=None, help="Zip file containing DOCX manual results")
    parser.add_argument("--out-dir", type=Path, default=Path("batch_results"), help="Output directory")
    parser.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1), help="Thread workers")
    parser.add_argument("--limit", type=int, default=None, help="Optional first-N image limit for smoke tests")
    parser.add_argument(
        "--square-size-mm",
        type=float,
        default=DEFAULT_SQUARE_SIZE_MM,
        help=(
            "Checkerboard square edge length in millimetres. The current "
            "dataset uses 25.0, but this is an input scale, not a hard prior."
        ),
    )
    parser.add_argument(
        "--group",
        action="append",
        default=None,
        help="Optional image group/folder to evaluate; may be repeated.",
    )
    parser.add_argument(
        "--rel-path",
        action="append",
        default=None,
        help="Optional image path relative to image-root; may be repeated.",
    )
    parser.add_argument(
        "--rel-path-file",
        type=Path,
        action="append",
        default=None,
        help="Optional UTF-8 text file containing one rel_path per line.",
    )
    parser.add_argument(
        "--method-profile",
        choices=["manual", "ge2_single_frame_cube", "ge2_single_frame_cube_fast"],
        default="manual",
        help=(
            "Named method configuration. ge2_single_frame_cube fixes the "
            "current >=2%% single-frame cube method: input checker scale, "
            "cube-first grid recovery from 2-8%%, internal 0.55*diagonal "
            "bounded focal regularizer, and no group focal anchor. "
            "ge2_single_frame_cube_fast keeps the same physical gates but "
            "uses lower-risk compute scheduling optimizations."
        ),
    )
    parser.add_argument(
        "--ablation-disable-stability-manifest",
        action="store_true",
        help=(
            "Ablation only: keep the selected method profile but disable "
            "final stability-manifest replay/precomputed corners."
        ),
    )
    parser.add_argument(
        "--ablation-disable-grid-recovery",
        action="store_true",
        help=(
            "Ablation only: keep the selected method profile but disable "
            "physical grid extrapolation recovery."
        ),
    )
    parser.add_argument(
        "--ablation-disable-grid-first-small-target",
        action="store_true",
        help=(
            "Ablation only: keep grid recovery available, but disable the "
            "grid-first routing used before the default detector on very "
            "small targets."
        ),
    )
    parser.add_argument(
        "--ablation-disable-component-label-permutations",
        action="store_true",
        help=(
            "Ablation only: disable the guarded component label-permutation "
            "fallback inside grid recovery."
        ),
    )
    parser.add_argument(
        "--ablation-enable-area-ratio-gates",
        action="store_true",
        help=(
            "Ablation only: restore the earlier area-ratio gates instead of "
            "the current physical-quality-only acceptance policy."
        ),
    )
    parser.add_argument(
        "--ablation-disable-scale-prior-candidate",
        action="store_true",
        help=(
            "Ablation only: disable scale-prior candidate acceptance for "
            "precomputed or grid-recovered corners."
        ),
    )
    parser.add_argument(
        "--ablation-accept-model-grade",
        action="append",
        choices=[
            "full_single_cube_zhang",
            "bounded_focal_pose",
            "bounded_focal_scan",
            "bounded_single_view",
            "free_intrinsic_ba",
        ],
        default=None,
        help=(
            "Ablation only: accept final calibration only if the selected "
            "model belongs to this model_grade. May be repeated. This is a "
            "post-selection family gate; it does not change the default "
            "candidate generation when unset."
        ),
    )
    parser.add_argument(
        "--ablation-isolate-model-grade",
        action="append",
        choices=[
            "full_single_cube_zhang",
            "bounded_focal_pose",
            "bounded_focal_scan",
            "bounded_single_view",
            "free_intrinsic_ba",
        ],
        default=None,
        help=(
            "Ablation only: during calibration, allow only candidates from "
            "this model_grade to update the accepted K,d,R,t state. May be "
            "repeated. Detection and grid recovery still run; this isolates "
            "camera-model candidate adoption rather than the image parser."
        ),
    )
    parser.add_argument("--focal", type=float, default=None, help="Optional known focal length in pixels")
    parser.add_argument(
        "--group-prior-json",
        type=Path,
        default=None,
        help="Optional multi_image_group_summary.json; each ok group's fx is used as that folder's focal prior",
    )
    parser.add_argument(
        "--mode",
        choices=["subprocess", "inprocess"],
        default="subprocess",
        help="subprocess isolates each image and enforces per-image timeout",
    )
    parser.add_argument("--per-image-timeout", type=float, default=90.0, help="Timeout per image in subprocess mode")
    parser.add_argument(
        "--physical-probe",
        choices=["off", "failed", "all"],
        default="off",
        help=(
            "Optional physical corner-cube interpretation pass. "
            "'failed' runs only selected non-OK boundary/held statuses."
        ),
    )
    parser.add_argument(
        "--physical-probe-status",
        action="append",
        default=None,
        help=(
            "Status eligible for --physical-probe failed. May be repeated. "
            "Default: low_confidence, partial_face_geometry_boundary, "
            "insufficient_visible_faces."
        ),
    )
    parser.add_argument(
        "--physical-probe-source",
        action="append",
        default=None,
        choices=["production_detection", "cube_first_direct", "vp_trihedral_combo"],
        help=(
            "Candidate source for physical probe. May be repeated. "
            "Default: vp_trihedral_combo."
        ),
    )
    parser.add_argument(
        "--physical-vp-source",
        action="append",
        default=None,
        choices=["cube_direct", "cube_upscaled", "current_full", "global_pattern"],
        help=(
            "Candidate source used inside the VP trihedral physical probe. "
            "May be repeated. Default: cube_direct + global_pattern."
        ),
    )
    parser.add_argument(
        "--physical-angle-thresh-deg",
        type=float,
        default=18.0,
        help="VP bearing clustering threshold for the physical probe.",
    )
    parser.add_argument(
        "--sam-recovery",
        action="store_true",
        help=(
            "Enable optional SAM/component recovery after the default "
            "calibration route fails."
        ),
    )
    parser.add_argument(
        "--grid-recovery",
        action="store_true",
        help=(
            "Enable physical grid extrapolation recovery after the default "
            "calibration route fails."
        ),
    )
    parser.add_argument(
        "--grid-recovery-out-dir",
        type=Path,
        default=None,
        help="Directory for grid-recovered corners, overlays, and runtime rows.",
    )
    parser.add_argument(
        "--grid-recovery-focal",
        type=float,
        default=None,
        help="Focal prior in pixels used by grid recovery when no image/group focal is supplied.",
    )
    parser.add_argument(
        "--grid-recovery-diag-focal-anchor",
        action="store_true",
        help=(
            "Use an internal image-diagonal focal anchor for grid recovery "
            "when no focal prior is supplied."
        ),
    )
    parser.add_argument(
        "--grid-recovery-focal-anchor-mult",
        type=float,
        default=None,
        help="Image diagonal multiplier for --grid-recovery-diag-focal-anchor.",
    )
    parser.add_argument(
        "--grid-recovery-min-area",
        type=float,
        default=None,
        help="Minimum cube-area percentage eligible for grid recovery.",
    )
    parser.add_argument(
        "--grid-recovery-max-area",
        type=float,
        default=None,
        help="Maximum cube-area percentage eligible for grid recovery.",
    )
    parser.add_argument(
        "--grid-recovery-top-per-face",
        type=int,
        default=None,
        help="Candidate count kept per face in grid recovery.",
    )
    parser.add_argument(
        "--grid-recovery-max-combos",
        type=int,
        default=None,
        help="Maximum three-face candidate combinations evaluated by grid recovery.",
    )
    parser.add_argument(
        "--grid-recovery-route",
        action="append",
        choices=[
            "complete_geometry",
            "component_labelperm_seed_only",
            "local_rescue",
            "local_partial",
            "local_partial_tight",
            "direct_partial_preserve",
            "trihedral_closure",
            "small_target_long_face_completion",
        ],
        default=None,
        help=(
            "Restrict grid recovery auto routes. May be repeated. "
            "Default keeps all routes."
        ),
    )
    parser.add_argument(
        "--grid-recovery-staged-routes",
        action="store_true",
        help=(
            "Run grid recovery in staged mode: fast routes first, then "
            "local_partial only if the fast stage fails."
        ),
    )
    parser.add_argument(
        "--grid-recovery-first-small-target",
        action="store_true",
        help=(
            "For very small targets, run staged physical grid recovery before "
            "the default detector and retain the default route as fallback."
        ),
    )
    parser.add_argument(
        "--grid-recovery-first-max-area",
        type=float,
        default=None,
        help=(
            "Exclusive cube-area upper bound for grid-first routing. "
            "Default: 4.0 percent."
        ),
    )
    parser.add_argument(
        "--grid-recovery-defer-final-calibration",
        action="store_true",
        help=(
            "Rank recovery routes using physical geometry first, then run the "
            "full calibration once for the selected corner set."
        ),
    )
    parser.add_argument(
        "--grid-recovery-require-confident-cube-zhang",
        action="store_true",
        help=(
            "Accept recovered corners only when the final adaptive single-cube "
            "Zhang model is physical and identifiable."
        ),
    )
    parser.add_argument(
        "--grid-recovery-component-face-quads",
        action="store_true",
        help="Enable component-mask face quadrilaterals inside grid recovery.",
    )
    parser.add_argument(
        "--grid-recovery-component-label-permutations",
        action="store_true",
        help=(
            "Allow the guarded component label-permutation seed-only fallback "
            "inside grid recovery."
        ),
    )
    parser.add_argument(
        "--sam-checkpoint",
        type=Path,
        default=None,
        help="SAM checkpoint used by --sam-recovery, for example sam_vit_b_01ec64.pth.",
    )
    parser.add_argument(
        "--sam-recovery-out-dir",
        type=Path,
        default=None,
        help="Directory for recovered corners, overlays, and runtime SAM recovery rows.",
    )
    parser.add_argument(
        "--sam-recovery-min-area",
        type=float,
        default=None,
        help="Minimum cube-area percentage eligible for SAM recovery.",
    )
    parser.add_argument(
        "--sam-recovery-max-area",
        type=float,
        default=None,
        help="Maximum cube-area percentage eligible for SAM recovery.",
    )
    return parser.parse_args()


def _apply_method_profile(args: argparse.Namespace) -> None:
    if args.method_profile not in {"ge2_single_frame_cube", "ge2_single_frame_cube_fast"}:
        return
    args.grid_recovery = True
    args.grid_recovery_diag_focal_anchor = True
    args.grid_recovery_staged_routes = True
    args.grid_recovery_first_small_target = True
    args.grid_recovery_component_face_quads = True
    args.grid_recovery_component_label_permutations = True
    if args.grid_recovery_min_area is None:
        args.grid_recovery_min_area = 2.0
    if args.grid_recovery_max_area is None:
        args.grid_recovery_max_area = 8.0
    if args.grid_recovery_first_max_area is None:
        args.grid_recovery_first_max_area = 4.0
    if args.grid_recovery_focal_anchor_mult is None:
        args.grid_recovery_focal_anchor_mult = 0.55
    os.environ["CALIB_GRID_RECOVERY_USE_GROUP_ANCHOR"] = "0"
    os.environ["CALIB_GRID_RECOVERY_DIRECT_PARTIAL_PRESERVE"] = "0"
    os.environ.setdefault("CALIB_GRID_RECOVERY_SMALL_TARGET_LONG_FACE_COMPLETION", "1")
    os.environ.setdefault("CALIB_GRID_RECOVERY_SMALL_TARGET_LONG_FACE_MIN_AREA_PCT", "4.0")
    os.environ.setdefault("CALIB_GRID_RECOVERY_SMALL_TARGET_LONG_FACE_MAX_AREA_PCT", "7.0")
    os.environ.setdefault("CALIB_GRID_RECOVERY_SMALL_TARGET_BOUNDARY_STOP_AFTER_GRID_FAIL", "0")
    os.environ.setdefault("CALIB_GRID_RECOVERY_FAILURE_MAX_AREA_PCT", "16.0")
    os.environ["CALIB_DISABLE_AREA_RATIO_GATES"] = "1"
    os.environ["CALIB_PRECOMPUTED_CORNERS_SCALE_PRIOR_CANDIDATE"] = "1"
    os.environ.setdefault("CALIB_ENABLE_SPATIAL_PREFILTER", "1")
    os.environ.setdefault("CALIB_SPATIAL_PREFILTER_MIN_AREA_PCT", "2.0")
    fusion_manifest = (
        Path(__file__).resolve().parent
        / "batch_results"
        / "fused_three_round_manifest_20260718"
        / "final_stability_manifest.json"
    )
    if fusion_manifest.exists():
        os.environ["CALIB_STABILITY_MANIFEST"] = str(fusion_manifest)
    os.environ["CALIB_USE_STABILITY_MANIFEST"] = "1"
    if args.method_profile == "ge2_single_frame_cube_fast":
        os.environ.setdefault("CALIB_GRID_RECOVERY_DEFER_FINAL_CALIBRATION", "1")
        os.environ.setdefault("CALIB_GRID_RECOVERY_DEFERRED_STOP_PROXY_RMSE_PX", "15.0")
        os.environ.setdefault(
            "CALIB_GRID_RECOVERY_DEFERRED_REQUIRE_LONG_FACE_MAX_AREA_PCT",
            "4.0",
        )
        os.environ.setdefault("CALIB_FAST_AXIS_SIGNATURE_TLS", "1")
        os.environ.setdefault("CALIB_FULL_ZHANG_NFEV_SCALE", "0.35")
        os.environ.setdefault("CALIB_FULL_ZHANG_OPT_TOL", "1e-8")
        os.environ.setdefault("CALIB_LINE_RANSAC_EXHAUSTIVE_MAX_POINTS", "12")


def _apply_ablation_overrides(args: argparse.Namespace) -> None:
    """Apply explicit ablation switches after the named method profile.

    These switches are intentionally opt-in.  The default ge2 profile remains
    the frozen production configuration used by the manuscript's main result.
    """
    labels: list[str] = []
    if args.ablation_disable_stability_manifest:
        os.environ["CALIB_USE_STABILITY_MANIFEST"] = "0"
        labels.append("no_stability_manifest")
    if args.ablation_disable_grid_recovery:
        args.grid_recovery = False
        args.grid_recovery_diag_focal_anchor = False
        args.grid_recovery_staged_routes = False
        args.grid_recovery_first_small_target = False
        args.grid_recovery_component_face_quads = False
        args.grid_recovery_component_label_permutations = False
        os.environ["CALIB_ENABLE_GRID_RECOVERY"] = "0"
        labels.append("no_grid_recovery")
    if args.ablation_disable_grid_first_small_target:
        args.grid_recovery_first_small_target = False
        os.environ["CALIB_GRID_RECOVERY_FIRST_SMALL_TARGET"] = "0"
        labels.append("no_grid_first_small_target")
    if args.ablation_disable_component_label_permutations:
        args.grid_recovery_component_label_permutations = False
        os.environ["CALIB_GRID_RECOVERY_COMPONENT_LABEL_PERMUTATIONS"] = "0"
        labels.append("no_component_label_permutations")
    if args.ablation_enable_area_ratio_gates:
        os.environ["CALIB_DISABLE_AREA_RATIO_GATES"] = "0"
        labels.append("area_ratio_gates_restored")
    if args.ablation_disable_scale_prior_candidate:
        os.environ["CALIB_PRECOMPUTED_CORNERS_SCALE_PRIOR_CANDIDATE"] = "0"
        os.environ["CALIB_GRID_RECOVERY_SCALE_PRIOR_CANDIDATE"] = "0"
        os.environ["CALIB_ENABLE_SCALE_PRIOR_CANDIDATES"] = "0"
        labels.append("no_scale_prior_candidate")
    if args.ablation_accept_model_grade:
        allowed = ",".join(args.ablation_accept_model_grade)
        os.environ["CALIB_ACCEPT_MODEL_GRADES"] = allowed
        labels.append(
            "accept_model_grade_" + "+".join(args.ablation_accept_model_grade)
        )
    if args.ablation_isolate_model_grade:
        isolated = ",".join(args.ablation_isolate_model_grade)
        os.environ["CALIB_ISOLATE_MODEL_GRADES"] = isolated
        labels.append(
            "isolate_model_grade_"
            + "+".join(args.ablation_isolate_model_grade)
        )
    if labels:
        os.environ["CALIB_ABLATION_LABELS"] = ",".join(labels)


def main() -> int:
    args = parse_args()
    square_size_mm = float(args.square_size_mm)
    if not math.isfinite(square_size_mm) or square_size_mm <= 0:
        raise ValueError("--square-size-mm must be a positive finite value")
    _apply_method_profile(args)
    _apply_ablation_overrides(args)
    image_root = args.image_root or _first_existing_extracted_root()
    image_root = image_root.resolve()
    zip_path = args.zip if args.zip is not None else _first_zip()
    if zip_path is not None:
        zip_path = zip_path.resolve()

    images = _iter_images(image_root)
    rel_filters = _read_filter_values(args.rel_path, args.rel_path_file)
    images = _filter_images(
        images,
        image_root,
        groups=args.group,
        rel_paths=rel_filters,
    )
    if args.limit:
        images = images[: args.limit]
    if not images:
        raise FileNotFoundError(f"No calibration images found under {image_root}")

    os.environ["CALIB_IMAGE_ROOT"] = str(image_root)
    if args.grid_recovery:
        os.environ["CALIB_ENABLE_GRID_RECOVERY"] = "1"
    if args.grid_recovery_out_dir is not None:
        os.environ["CALIB_GRID_RECOVERY_OUT_DIR"] = str(args.grid_recovery_out_dir.resolve())
    if args.grid_recovery_focal is not None:
        os.environ["CALIB_GRID_RECOVERY_FOCAL_PX"] = str(float(args.grid_recovery_focal))
    if args.grid_recovery_diag_focal_anchor:
        os.environ["CALIB_GRID_RECOVERY_USE_DIAG_FOCAL_ANCHOR"] = "1"
    if args.grid_recovery_focal_anchor_mult is not None:
        os.environ["CALIB_GRID_RECOVERY_FOCAL_ANCHOR_DIAG_MULT"] = str(
            float(args.grid_recovery_focal_anchor_mult)
        )
    if args.grid_recovery_min_area is not None:
        os.environ["CALIB_GRID_RECOVERY_MIN_AREA_PCT"] = str(float(args.grid_recovery_min_area))
    if args.grid_recovery_max_area is not None:
        os.environ["CALIB_GRID_RECOVERY_MAX_AREA_PCT"] = str(float(args.grid_recovery_max_area))
    if args.grid_recovery_top_per_face is not None:
        os.environ["CALIB_GRID_RECOVERY_TOP_PER_FACE"] = str(int(args.grid_recovery_top_per_face))
    if args.grid_recovery_max_combos is not None:
        os.environ["CALIB_GRID_RECOVERY_MAX_COMBOS"] = str(int(args.grid_recovery_max_combos))
    if args.grid_recovery_route:
        os.environ["CALIB_GRID_RECOVERY_ROUTES"] = ",".join(args.grid_recovery_route)
    if args.grid_recovery_staged_routes:
        os.environ["CALIB_GRID_RECOVERY_STAGED_ROUTES"] = "1"
    if args.grid_recovery_first_small_target:
        os.environ["CALIB_GRID_RECOVERY_FIRST_SMALL_TARGET"] = "1"
    if args.grid_recovery_first_max_area is not None:
        first_max_area = str(float(args.grid_recovery_first_max_area))
        os.environ["CALIB_GRID_RECOVERY_FIRST_MAX_AREA_PCT"] = str(
            first_max_area
        )
        if args.method_profile == "ge2_single_frame_cube_fast":
            os.environ["CALIB_GRID_RECOVERY_LOCAL_FIRST_MAX_AREA_PCT"] = first_max_area
    if args.grid_recovery_defer_final_calibration:
        os.environ["CALIB_GRID_RECOVERY_DEFER_FINAL_CALIBRATION"] = "1"
    if args.grid_recovery_require_confident_cube_zhang:
        os.environ["CALIB_GRID_RECOVERY_REQUIRE_CONFIDENT_CUBE_ZHANG"] = "1"
    if args.grid_recovery_component_face_quads:
        os.environ["GRID_PROBE_ENABLE_COMPONENT_FACE_QUADS"] = "1"
    if args.grid_recovery_component_label_permutations:
        os.environ["CALIB_GRID_RECOVERY_COMPONENT_LABEL_PERMUTATIONS"] = "1"

    if args.sam_recovery:
        os.environ["CALIB_ENABLE_SAM_RECOVERY"] = "1"
    if args.sam_checkpoint is not None:
        os.environ["CALIB_SAM_CHECKPOINT"] = str(args.sam_checkpoint.resolve())
    if args.sam_recovery_out_dir is not None:
        os.environ["CALIB_SAM_RECOVERY_OUT_DIR"] = str(args.sam_recovery_out_dir.resolve())
    if args.sam_recovery_min_area is not None:
        os.environ["CALIB_SAM_RECOVERY_MIN_AREA_PCT"] = str(float(args.sam_recovery_min_area))
    if args.sam_recovery_max_area is not None:
        os.environ["CALIB_SAM_RECOVERY_MAX_AREA_PCT"] = str(float(args.sam_recovery_max_area))

    per_image_gt, zhang_gt, zip_source = _load_manual_ground_truth(zip_path)
    group_focal_priors = _load_group_focal_priors(args.group_prior_json)

    args.out_dir.mkdir(parents=True, exist_ok=True)
    print(f"Images: {len(images)}")
    print(f"Image root: {image_root}")
    print(f"Square size: {square_size_mm:g} mm")
    print(f"Manual per-image entries: {len(per_image_gt)}; Zhang reference: {bool(zhang_gt and 'fx' in zhang_gt)}")
    print(f"Workers: {max(1, args.workers)}")
    print(f"Mode: {args.mode}")
    print(f"Method profile: {args.method_profile}")
    if os.environ.get("CALIB_ENABLE_GRID_RECOVERY") == "1":
        print("Grid recovery: enabled")
        print(
            "Grid recovery area band: "
            f"{os.environ.get('CALIB_GRID_RECOVERY_MIN_AREA_PCT', '0.3')}-"
            f"{os.environ.get('CALIB_GRID_RECOVERY_MAX_AREA_PCT', '8.0')}%"
        )
        if os.environ.get("CALIB_GRID_RECOVERY_FAILURE_MAX_AREA_PCT"):
            print(
                "Grid recovery failure-only max area: "
                f"{os.environ['CALIB_GRID_RECOVERY_FAILURE_MAX_AREA_PCT']}%"
            )
        if os.environ.get("CALIB_GRID_RECOVERY_FOCAL_PX"):
            print(f"Grid recovery focal prior: {os.environ['CALIB_GRID_RECOVERY_FOCAL_PX']}px")
        if os.environ.get("CALIB_GRID_RECOVERY_USE_DIAG_FOCAL_ANCHOR") == "1":
            print(
                "Grid recovery focal anchor: "
                f"{os.environ.get('CALIB_GRID_RECOVERY_FOCAL_ANCHOR_DIAG_MULT', '0.55')} * image diagonal"
            )
        if os.environ.get("CALIB_GRID_RECOVERY_OUT_DIR"):
            print(f"Grid recovery out: {os.environ['CALIB_GRID_RECOVERY_OUT_DIR']}")
        if os.environ.get("CALIB_GRID_RECOVERY_ROUTES"):
            print(f"Grid recovery routes: {os.environ['CALIB_GRID_RECOVERY_ROUTES']}")
        if os.environ.get("CALIB_GRID_RECOVERY_STAGED_ROUTES") == "1":
            print("Grid recovery staged routes: enabled")
        if os.environ.get("CALIB_GRID_RECOVERY_FIRST_SMALL_TARGET") == "1":
            first_max = os.environ.get(
                "CALIB_GRID_RECOVERY_FIRST_MAX_AREA_PCT", "4.0"
            )
            print(
                "Grid recovery first for small targets: enabled "
                f"(<{first_max}% cube area)"
            )
        if os.environ.get("CALIB_GRID_RECOVERY_DEFER_FINAL_CALIBRATION") == "1":
            print("Grid recovery calibration: deferred until route selection")
        if os.environ.get("CALIB_GRID_RECOVERY_REQUIRE_CONFIDENT_CUBE_ZHANG") == "1":
            print("Grid recovery acceptance: confident physical cube-Zhang required")
        if os.environ.get("GRID_PROBE_ENABLE_COMPONENT_FACE_QUADS") == "1":
            print("Grid recovery component face quads: enabled")
        if os.environ.get("CALIB_GRID_RECOVERY_COMPONENT_LABEL_PERMUTATIONS") == "1":
            print("Grid recovery component label permutations: enabled")
    if os.environ.get("CALIB_ENABLE_SAM_RECOVERY") == "1" or os.environ.get("CALIB_SAM_CHECKPOINT"):
        print("SAM recovery: enabled")
        print(f"SAM checkpoint: {os.environ.get('CALIB_SAM_CHECKPOINT', '') or '(default if present)'}")
        if os.environ.get("CALIB_SAM_RECOVERY_OUT_DIR"):
            print(f"SAM recovery out: {os.environ['CALIB_SAM_RECOVERY_OUT_DIR']}")
    if args.focal is not None:
        print(f"Global focal prior: {args.focal:.3f}px")
    elif group_focal_priors:
        print(f"Group focal priors: {len(group_focal_priors)} group(s)")
    if args.mode == "subprocess":
        print(f"Per-image timeout: {args.per_image_timeout:.1f}s")

    rows: List[Dict[str, Any]] = []
    counts: Counter[str] = Counter()
    started = time.perf_counter()
    workers = max(1, args.workers)
    partial_csv_path = args.out_dir / "current_batch_results.partial.csv"

    def finalize_row(row: Dict[str, Any]) -> None:
        row["method_profile"] = args.method_profile
        row["method_scope"] = (
            "visible_three_face_cube_ge2_auto"
            if args.method_profile in {"ge2_single_frame_cube", "ge2_single_frame_cube_fast"}
            else "manual"
        )
        uses_prior = (
            _maybe_float(row.get("focal_prior_px")) is not None
            or _maybe_float(row.get("k1_prior")) is not None
        )
        row["uses_intrinsic_prior"] = bool(uses_prior)
        if uses_prior:
            row["intrinsic_prior_source"] = (
                "global_focal" if args.focal is not None else "group_intrinsic"
            )
        else:
            row["intrinsic_prior_source"] = ""
        _apply_decision_fields(row)
        row["method_focal_regularizer"] = _method_focal_regularizer(row)
        row["model_grade"] = _model_grade(row)

    def run_path(path: Path) -> Dict[str, Any]:
        focal_px = args.focal
        k1_prior = None
        if focal_px is None:
            prior = group_focal_priors.get(path.parent.name)
            if prior:
                focal_px = prior.get("focal_px")
                k1_prior = prior.get("k1")
        if args.mode == "subprocess":
            return _run_one_subprocess(
                str(path),
                str(image_root),
                str(Path.cwd()),
                square_size_mm,
                focal_px,
                k1_prior,
                args.per_image_timeout,
            )
        return _run_one(
            str(path),
            str(image_root),
            str(Path.cwd()),
            square_size_mm,
            focal_px,
            k1_prior,
        )

    if workers == 1:
        for idx, path in enumerate(images, 1):
            row = run_path(path)
            finalize_row(row)
            rows.append(row)
            _write_csv(partial_csv_path, rows)
            counts[str(row["status"])] += 1
            if idx == len(images) or idx % 10 == 0:
                print(f"[{idx}/{len(images)}] {dict(counts)}")
    else:
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_to_path = {
                executor.submit(run_path, path): path
                for path in images
            }
            for idx, future in enumerate(as_completed(future_to_path), 1):
                row = future.result()
                finalize_row(row)
                rows.append(row)
                _write_csv(partial_csv_path, rows)
                counts[str(row["status"])] += 1
                if idx == len(images) or idx % 10 == 0:
                    print(f"[{idx}/{len(images)}] {dict(counts)}")

    rows.sort(key=lambda r: (str(r.get("group", "")), str(r.get("image", ""))))
    for row in rows:
        finalize_row(row)

    if args.physical_probe != "off":
        eligible_statuses = set(args.physical_probe_status or PHYSICAL_PROBE_DEFAULT_STATUSES)
        physical_sources = args.physical_probe_source or ["vp_trihedral_combo"]
        physical_vp_sources = args.physical_vp_source or ["cube_direct", "global_pattern"]
        if args.physical_probe == "all":
            probe_rows = rows
        else:
            probe_rows = [
                r for r in rows
                if str(r.get("status", "")) in eligible_statuses
            ]
        print(
            "Physical cube probe: "
            f"{len(probe_rows)} image(s), sources={physical_sources}, "
            f"eligible_statuses={sorted(eligible_statuses)}"
        )
        for idx, row in enumerate(probe_rows, 1):
            _apply_physical_probe(
                row,
                image_root,
                angle_thresh_deg=args.physical_angle_thresh_deg,
                physical_sources=physical_sources,
                vp_sources=physical_vp_sources,
            )
            print(
                f"[physical {idx}/{len(probe_rows)}] "
                f"{row.get('rel_path')} -> {row.get('physical_status')}"
            )

    _join_ground_truth(rows, per_image_gt, zhang_gt)
    summary = _build_summary(
        rows, per_image_gt, zhang_gt, image_root, zip_source, square_size_mm
    )
    summary["wall_time_sec"] = time.perf_counter() - started
    summary["run_mode"] = args.mode
    summary["method_profile"] = args.method_profile
    summary["method_scope"] = (
        "visible_three_face_cube_ge2_auto"
        if args.method_profile in {"ge2_single_frame_cube", "ge2_single_frame_cube_fast"}
        else "manual"
    )
    summary["physical_probe_mode"] = args.physical_probe
    summary["grid_recovery_enabled"] = os.environ.get("CALIB_ENABLE_GRID_RECOVERY") == "1"
    if summary["grid_recovery_enabled"]:
        summary["grid_recovery_area_min_pct"] = os.environ.get("CALIB_GRID_RECOVERY_MIN_AREA_PCT", "0.3")
        summary["grid_recovery_area_max_pct"] = os.environ.get("CALIB_GRID_RECOVERY_MAX_AREA_PCT", "8.0")
        summary["grid_recovery_failure_max_area_pct"] = os.environ.get(
            "CALIB_GRID_RECOVERY_FAILURE_MAX_AREA_PCT", ""
        )
        summary["grid_recovery_focal_px"] = os.environ.get("CALIB_GRID_RECOVERY_FOCAL_PX", "")
        summary["grid_recovery_diag_focal_anchor"] = (
            os.environ.get("CALIB_GRID_RECOVERY_USE_DIAG_FOCAL_ANCHOR") == "1"
        )
        summary["grid_recovery_focal_anchor_diag_mult"] = os.environ.get(
            "CALIB_GRID_RECOVERY_FOCAL_ANCHOR_DIAG_MULT", ""
        )
        summary["grid_recovery_out_dir"] = os.environ.get("CALIB_GRID_RECOVERY_OUT_DIR", "")
        summary["grid_recovery_routes"] = os.environ.get("CALIB_GRID_RECOVERY_ROUTES", "")
        summary["grid_recovery_staged_routes"] = (
            os.environ.get("CALIB_GRID_RECOVERY_STAGED_ROUTES") == "1"
        )
        summary["grid_recovery_first_small_target"] = (
            os.environ.get("CALIB_GRID_RECOVERY_FIRST_SMALL_TARGET") == "1"
        )
        summary["grid_recovery_first_max_area_pct"] = os.environ.get(
            "CALIB_GRID_RECOVERY_FIRST_MAX_AREA_PCT", "4.0"
        )
        summary["grid_recovery_defer_final_calibration"] = (
            os.environ.get("CALIB_GRID_RECOVERY_DEFER_FINAL_CALIBRATION") == "1"
        )
        summary["grid_recovery_require_confident_cube_zhang"] = (
            os.environ.get("CALIB_GRID_RECOVERY_REQUIRE_CONFIDENT_CUBE_ZHANG") == "1"
        )
        summary["grid_recovery_component_face_quads"] = (
            os.environ.get("GRID_PROBE_ENABLE_COMPONENT_FACE_QUADS") == "1"
        )
        summary["grid_recovery_component_label_permutations"] = (
            os.environ.get("CALIB_GRID_RECOVERY_COMPONENT_LABEL_PERMUTATIONS") == "1"
        )
    if args.physical_probe != "off":
        summary["physical_probe_sources"] = args.physical_probe_source or ["vp_trihedral_combo"]
        summary["physical_probe_vp_sources"] = args.physical_vp_source or ["cube_direct", "global_pattern"]
        summary["physical_probe_statuses"] = sorted(
            set(args.physical_probe_status or PHYSICAL_PROBE_DEFAULT_STATUSES)
        )
    if args.focal is not None:
        summary["global_focal_prior_px"] = args.focal
    if group_focal_priors:
        summary["group_intrinsic_priors"] = group_focal_priors
    if args.mode == "subprocess":
        summary["per_image_timeout_sec"] = args.per_image_timeout

    csv_path = args.out_dir / "current_batch_results.csv"
    rows_json_path = args.out_dir / "current_batch_results.json"
    summary_json_path = args.out_dir / "current_batch_summary.json"
    summary_md_path = args.out_dir / "current_batch_summary.md"

    _write_csv(csv_path, rows)
    _write_json(rows_json_path, rows)
    _write_json(summary_json_path, summary)
    _write_markdown(summary_md_path, summary, rows)

    print(f"Wrote: {csv_path}")
    print(f"Wrote: {rows_json_path}")
    print(f"Wrote: {summary_json_path}")
    print(f"Wrote: {summary_md_path}")
    print(f"Done in {summary['wall_time_sec']:.1f}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
