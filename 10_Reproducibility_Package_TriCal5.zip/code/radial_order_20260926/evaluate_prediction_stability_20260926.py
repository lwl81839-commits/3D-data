"""Corrected planar pose solver and paired projection displacement on fixed screen."""
import sys,hashlib,time,os,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import cv2
import trained_camera_model as t
import evaluate_trained_camera_model as ev
import evaluate_planar_blind_comparison as ep
from evaluate_planar_per_pose_controlled import image_dir
from run_stability_verification_20260914 import ROOT,BASE,SPLIT,POSES
from analyze_existing_predictions_20260926 import OUT,read,save,stats
OLD=ROOT/'output/stability_verification_20260914'
def run(pose):
    cv2.setNumThreads(1);cv2.setRNGSeed(20260912)
    pi=POSES.index(pose);samples=[];selection=[];failures=[]
    for kind in ['2D','3D']:
        folder=image_dir(SPLIT,pose) if kind=='2D' else SPLIT/'test'/pose/'3D'
        paths=sorted(folder.glob('*.jpg'))
        for n in np.unique(np.linspace(0,len(paths)-1,min(12,len(paths)),dtype=int)):
            p=paths[n];selection.append(dict(kind=kind,image=str(p)))
            try:
                if kind=='2D':
                    im,det=ep.detect_checker(p)
                    if im is None:raise ValueError(det)
                    obj=ep.object_points(25);ids=np.zeros(len(obj),int)
                else:
                    h=hashlib.sha256(p.read_bytes()).hexdigest();cs=list((BASE/'test_correspondence_cache'/pose).glob(h+'_sq25_*.npz'));assert len(cs)==1
                    cv2.setRNGSeed(20260912)
                    s=t.extract_correspondences(str(p),25,correspondence_cache_path=str(cs[0]),minimum_usable_faces=1)
                    obj,im=s.object_points,s.image_points;ids=ev.face_ids(obj)
                rng=np.random.default_rng(914000+pi*1000+int(n))
                splits=[ev.stratified_holdout(ids,rng,.2,4) for _ in range(5)]
                samples.append((kind,p.name,obj,im,ids,splits,int(n)))
            except Exception as e:failures.append(dict(image=str(p),error=str(e)))
    dirs=[d for d in sorted((OLD/'models'/pose).iterdir()) if (d/'status.json').exists() and read(d/'status.json')['completed']]
    dirs.sort(key=lambda d:(d.name!='ratio_base',d.name))
    baseline={};rows=[];parameters=[]
    for d in dirs:
        m=read(d/'trained_camera_model.json');K=np.asarray(m['cameraMatrix'],float);dist=np.asarray(m['distCoeffs'],float)
        parameters.append(dict(model=d.name,accepted=m['accepted'],K=K.tolist(),dist=dist.tolist()))
        for kind,name,obj,im,ids,splits,n in samples:
            solver=ep if kind=='2D' else ev
            errors=[];displacements=[];success=paired=0
            for r,(tr,te) in enumerate(splits):
                key=(kind,name,r);cv2.setRNGSeed(914000+pi*1000+n*10+r)
                pose_fit=solver.solve_pose(obj,im,tr,K,dist)
                if pose_fit is None or not len(te):continue
                rv,tv=pose_fit if kind=='2D' else (pose_fit.rvec,pose_fit.tvec)
                predicted,_=cv2.projectPoints(np.ascontiguousarray(obj[te],np.float64),rv,tv,K,dist)
                predicted=predicted.reshape(-1,2)
                if not np.all(np.isfinite(predicted)):continue
                success+=1;errors.extend(np.linalg.norm(predicted-im[te].reshape(-1,2),axis=1).tolist())
                if d.name=='ratio_base':baseline[key]=predicted.copy()
                if key in baseline:
                    paired+=1;displacements.extend(np.linalg.norm(predicted-baseline[key],axis=1).tolist())
            rows.append(dict(model=d.name,accepted=m['accepted'],kind=kind,image=name,faces=len(np.unique(ids)),successful_trials=success,paired_trials=paired,total_trials=5,rmse=float(np.sqrt(np.mean(np.square(errors)))) if errors else None,displacement_rmse=float(np.sqrt(np.mean(np.square(displacements)))) if displacements else None))
        print(pose,d.name,'evaluated',flush=True)
    save(OUT/'stability'/pose/'results.json',dict(selection=selection,failures=failures,parameters=parameters,rows=rows,scope='12 filename-spaced test images per type, five shared splits; diagnostic subset, not whole-set performance. Correct planar IPPE/iterative solver. Each model refits pose on identical training corners. Held-out prediction displacement relative to ratio_base measures pose-conditioned prediction sensitivity, not fixed-world camera-ray identity. Includes rejected candidates.'))

def launch(pose):
    if (OUT/'stability'/pose/'results.json').exists():return
    logs=OUT/'logs';logs.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONIOENCODING='utf-8')
    with (logs/(pose+'.log')).open('w',encoding='utf-8') as f:
        p=subprocess.run([sys.executable,__file__,pose],stdout=f,stderr=subprocess.STDOUT,env=env)
    print(pose,'return',p.returncode,flush=True)
if __name__=='__main__':
    if len(sys.argv)>1:run(sys.argv[1])
    else:
        save(OUT/'stability_protocol.json',dict(source='frozen models from stability_verification_20260914',source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),poses=POSES,refitting=False,zhang_training=False,scope='corrected diagnostic subset screen; no new acquisition'))
        with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(launch,POSES))
