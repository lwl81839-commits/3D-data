#!/usr/bin/env python3
"""Run the frozen-model paper evaluation with per-image process isolation.

Each blind image is evaluated in a child Python process.  A detector hang or
crash therefore cannot corrupt the collection.  The normal time limit is a
soft threshold: a valid result produced after it is still successful, but is
explicitly marked as slow.  An optional hard timeout is available only as a
last-resort watchdog.
Training duplicates are excluded by SHA-256 before any evaluation is launched.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from statistics import median
from typing import Any


ROOT = Path(__file__).resolve().parent
EVALUATOR = ROOT / "evaluate_trained_camera_model.py"
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
DEFAULT_CONFIGS = {
    "20_0.870": {
        "model": ROOT / "image/development_20_0.870/trained_camera_model_20_0.870.json",
        "images": ROOT / "image/20_0.870",
    },
    "30_0.550": {
        "model": ROOT / "image/development_30_0.550/trained_camera_model.json",
        "images": ROOT / "image/30_0.550",
    },
    "45_0.870": {
        "model": ROOT / "image/development_45_0.870/trained_camera_model_45_0.870.json",
        "images": ROOT / "image/45_0.870",
    },
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def images_in(folder: Path) -> list[Path]:
    return sorted(
        path.resolve()
        for path in folder.iterdir()
        if path.is_file()
        and path.suffix.lower() in IMAGE_SUFFIXES
        and not path.name.startswith("_")
        and "contact_sheet" not in path.stem.lower()
        and "roi_probe" not in path.stem.lower()
    )


def number(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def metric_median(summary: dict[str, Any], key: str) -> float | None:
    return number((summary.get(key) or {}).get("median"))


def classify(faces: int, extracted: bool) -> str:
    if not extracted:
        return "D"
    if faces >= 3:
        return "A"
    if faces == 2:
        return "B"
    if faces == 1:
        return "C"
    return "D"


def evaluate_one(
    group: str,
    image: Path,
    model_path: Path,
    output_root: Path,
    repeats: int,
    slow_threshold_seconds: float,
    hard_timeout_seconds: float | None,
    actual_square_mm: float | None,
    camera_override: Path | None,
) -> dict[str, Any]:
    image_out = output_root / group / "per_image" / image.stem
    image_out.mkdir(parents=True, exist_ok=True)
    command = [
        sys.executable,
        str(EVALUATOR),
        "--model", str(model_path),
        "--images", str(image),
        "--output-dir", str(image_out),
        "--repeats", str(repeats),
    ]
    if actual_square_mm is not None:
        command += ["--actual-square-mm", str(actual_square_mm)]
    if camera_override is not None:
        command += ["--camera-override-json", str(camera_override)]
    result_path = image_out / "evaluation.json"
    started_wall_ns = time.time_ns()
    started = time.perf_counter()
    try:
        completed = subprocess.run(
            command,
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=hard_timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        return {
            "group": group,
            "image": image.name,
            "image_path": str(image),
            "grade": "D",
            "status": "timeout",
            "faces_used": 0,
            "elapsed_seconds": float(time.perf_counter() - started),
            "reason": f"hard watchdog timeout after {hard_timeout_seconds:g} s",
            "slow": True,
            "slow_threshold_seconds": slow_threshold_seconds,
            "stdout_tail": (exc.stdout or "")[-1000:] if isinstance(exc.stdout, str) else "",
        }

    elapsed = float(time.perf_counter() - started)
    slow = elapsed > slow_threshold_seconds
    result_is_current = (
        result_path.is_file()
        and result_path.stat().st_mtime_ns >= started_wall_ns
    )
    if not result_is_current:
        return {
            "group": group,
            "image": image.name,
            "image_path": str(image),
            "grade": "D",
            "status": "crash",
            "faces_used": 0,
            "elapsed_seconds": elapsed,
            "reason": f"evaluator exit {completed.returncode} without evaluation.json",
            "slow": slow,
            "slow_threshold_seconds": slow_threshold_seconds,
            "stdout_tail": completed.stdout[-1000:],
            "stderr_tail": completed.stderr[-1000:],
        }

    payload = json.loads(result_path.read_text(encoding="utf-8"))
    summary = payload.get("summary", {})
    images = payload.get("images", [])
    failures = payload.get("failures", [])
    extracted = bool(images)
    image_row = images[0] if extracted else {}
    faces = int(image_row.get("faces_used") or 0)
    grade = classify(faces, extracted)
    reason = ""
    if failures:
        reason = str(failures[0].get("error") or "")
    return {
        "group": group,
        "image": image.name,
        "image_path": str(image),
        "grade": grade,
        "status": (
            "slow_success" if extracted and slow else
            "ok" if extracted else
            "slow_rejected" if slow else "rejected"
        ),
        "slow": slow,
        "slow_threshold_seconds": slow_threshold_seconds,
        "faces_used": faces,
        "n_points": int(image_row.get("n_points") or 0),
        "face_inliers": image_row.get("face_inliers") or [],
        "holdout_rmse_px": metric_median(summary, "holdout_error_px"),
        "holdout_object_point_rmse_mm": metric_median(
            summary, "holdout_object_point_rmse_mm"
        ),
        "holdout_length_relative_error_pct": metric_median(
            summary, "holdout_length_relative_error_pct"
        ),
        "cross_face_prediction_rmse_px": metric_median(
            summary, "cross_face_prediction_rmse_px"
        ),
        "undistorted_line_rms_px": metric_median(
            summary, "undistorted_line_rms_px"
        ),
        "radius_coverage_max": number(image_row.get("radius_coverage_max")),
        "elapsed_seconds": elapsed,
        "reason": reason,
        "child_exit_code": completed.returncode,
        "result_json": str(result_path),
    }


def stats(values: list[float | None]) -> dict[str, float | int | None]:
    vals = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    if not vals:
        return {"n": 0, "median": None, "mean": None, "p95": None, "max": None}
    ordered = sorted(vals)
    pos = 0.95 * (len(ordered) - 1)
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    p95 = ordered[lo] if lo == hi else ordered[lo] * (hi - pos) + ordered[hi] * (pos - lo)
    return {
        "n": len(vals),
        "median": float(median(vals)),
        "mean": float(sum(vals) / len(vals)),
        "p95": float(p95),
        "max": float(max(vals)),
    }


def summarize_group(group: str, rows: list[dict[str, Any]], training_count: int) -> dict[str, Any]:
    grades = {letter: sum(row["grade"] == letter for row in rows) for letter in "ABCD"}
    total = len(rows)
    return {
        "group": group,
        "training_images": training_count,
        "blind_images": total,
        "grade_counts": grades,
        "strict_A_rate_pct": 100.0 * grades["A"] / max(1, total),
        "A_plus_B_rate_pct": 100.0 * (grades["A"] + grades["B"]) / max(1, total),
        "usable_A_B_C_rate_pct": 100.0 * (grades["A"] + grades["B"] + grades["C"]) / max(1, total),
        "slow_success_count": sum(row["status"] == "slow_success" for row in rows),
        "slow_count": sum(bool(row.get("slow")) for row in rows),
        "hard_timeout_count": sum(row["status"] == "timeout" for row in rows),
        "holdout_rmse_px": stats([row.get("holdout_rmse_px") for row in rows]),
        "holdout_object_point_rmse_mm": stats([
            row.get("holdout_object_point_rmse_mm") for row in rows
        ]),
        "holdout_length_relative_error_pct": stats([
            row.get("holdout_length_relative_error_pct") for row in rows
        ]),
        "cross_face_prediction_rmse_px": stats([
            row.get("cross_face_prediction_rmse_px") for row in rows
        ]),
        "undistorted_line_rms_px": stats([
            row.get("undistorted_line_rms_px") for row in rows
        ]),
        "elapsed_seconds": stats([row.get("elapsed_seconds") for row in rows]),
    }


def fmt(value: Any, digits: int = 3) -> str:
    value = number(value)
    return "-" if value is None else f"{value:.{digits}f}"


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    keys: list[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                key: json.dumps(value, ensure_ascii=False, separators=(",", ":"))
                if isinstance(value, (dict, list, tuple)) else value
                for key, value in row.items()
            })


def _write_report_legacy(
    path: Path, summaries: list[dict[str, Any]], rows: list[dict[str, Any]],
    timeout: float, parameter_source: str,
) -> None:
    lines = [
        "# 三面少样本相机模型论文评价总表",
        "",
        f"相机参数来源：{parameter_source}。训练图按SHA-256排除，所有剩余图片均进入分母。",
        "",
        f"单图超时上限：{timeout:g} s。超时、拒绝和崩溃均记为D级。",
        "",
        "## A/B/C/D端到端结果",
        "",
        "| 配置 | 开发图 | 盲测图 | A三面 | B两面 | C单面 | D失败 | A率 | A+B率 | 可用率 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for item in summaries:
        g = item["grade_counts"]
        lines.append(
            f"| {item['group']} | {item['training_images']} | {item['blind_images']} | "
            f"{g['A']} | {g['B']} | {g['C']} | {g['D']} | "
            f"{fmt(item['strict_A_rate_pct'])}% | {fmt(item['A_plus_B_rate_pct'])}% | "
            f"{fmt(item['usable_A_B_C_rate_pct'])}% |"
        )
    slow_rows = [row for row in rows if row.get("status") == "slow_success"]
    lines += ["", "## 慢速成功图片", ""]
    if slow_rows:
        for row in slow_rows:
            lines.append(
                f"- `{row['group']}/{row['image']}`：{row['grade']}级，"
                f"faces={row.get('faces_used', 0)}，"
                f"elapsed={fmt(row.get('elapsed_seconds'))} s。"
            )
    else:
        lines.append("- 无")
    lines += [
        "",
        "## 盲测精度（只统计成功产生指标的图片）",
        "",
        "| 配置 | 留出RMSE中位px | 留出RMSE P95 | 空间点RMSE中位mm | 长度误差中位% | 跨面RMSE中位px | 直线残差中位px | 时间中位s |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for item in summaries:
        lines.append(
            f"| {item['group']} | {fmt(item['holdout_rmse_px']['median'])} | "
            f"{fmt(item['holdout_rmse_px']['p95'])} | "
            f"{fmt(item['holdout_object_point_rmse_mm']['median'])} | "
            f"{fmt(item['holdout_length_relative_error_pct']['median'])} | "
            f"{fmt(item['cross_face_prediction_rmse_px']['median'])} | "
            f"{fmt(item['undistorted_line_rms_px']['median'])} | "
            f"{fmt(item['elapsed_seconds']['median'])} |"
        )
    lines += [
        "",
        "## 逐图失败与降级",
        "",
    ]
    problem_rows = [row for row in rows if row["grade"] != "A"]
    if problem_rows:
        for row in problem_rows:
            reason = str(row.get("reason") or "").replace("\n", " ")
            if len(reason) > 240:
                reason = reason[:237] + "..."
            lines.append(
                f"- `{row['group']}/{row['image']}`：{row['grade']}级，"
                f"faces={row.get('faces_used', 0)}，{row['status']}。{reason}"
            )
    else:
        lines.append("- 无")
    lines += [
        "",
        "## 解释边界",
        "",
        "- A级是严格三面证据；B级是两面一致性；C级仅是冻结内参下的单面姿态；D级为端到端失败。",
        "- 标称25 mm产生的长度误差属于目标内部留出一致性，不是独立物体绝对计量真值。",
        "- 本总表首先回答鲁棒性和盲测几何预测问题；张正友同任务对照应在本方法结果冻结后追加。",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_report(
    path: Path,
    summaries: list[dict[str, Any]],
    rows: list[dict[str, Any]],
    slow_threshold: float,
    parameter_source: str,
) -> None:
    lines = [
        "# 三面少样本相机模型评测总表",
        "",
        f"相机参数来源：`{parameter_source}`。训练图片按 SHA-256 排除。",
        "",
        f"慢速阈值：{slow_threshold:g} s。超过阈值但最终产生有效结果时仍计为成功，并标记为 `slow_success`。",
        "",
        "## A/B/C/D 端到端结果",
        "",
        "| 配置 | 开发图 | 盲测图 | A三面 | B两面 | C单面 | D失败 | 慢速成功 | A率 | A+B率 | 可用率 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for item in summaries:
        grades = item["grade_counts"]
        lines.append(
            f"| {item['group']} | {item['training_images']} | {item['blind_images']} | "
            f"{grades['A']} | {grades['B']} | {grades['C']} | {grades['D']} | "
            f"{item['slow_success_count']} | {fmt(item['strict_A_rate_pct'])}% | "
            f"{fmt(item['A_plus_B_rate_pct'])}% | "
            f"{fmt(item['usable_A_B_C_rate_pct'])}% |"
        )
    lines += [
        "",
        "## 盲测精度（只统计成功产生指标的图片）",
        "",
        "| 配置 | 留出RMSE中位px | 留出RMSE P95 | 空间点RMSE中位mm | 长度误差中位% | 跨面RMSE中位px | 直线残差中位px | 时间中位s |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for item in summaries:
        lines.append(
            f"| {item['group']} | {fmt(item['holdout_rmse_px']['median'])} | "
            f"{fmt(item['holdout_rmse_px']['p95'])} | "
            f"{fmt(item['holdout_object_point_rmse_mm']['median'])} | "
            f"{fmt(item['holdout_length_relative_error_pct']['median'])} | "
            f"{fmt(item['cross_face_prediction_rmse_px']['median'])} | "
            f"{fmt(item['undistorted_line_rms_px']['median'])} | "
            f"{fmt(item['elapsed_seconds']['median'])} |"
        )
    lines += ["", "## 逐图非A级结果", ""]
    problem_rows = [row for row in rows if row["grade"] != "A"]
    if problem_rows:
        for row in problem_rows:
            reason = str(row.get("reason") or "").replace("\n", " ")
            if len(reason) > 240:
                reason = reason[:237] + "..."
            lines.append(
                f"- `{row['group']}/{row['image']}`：{row['grade']}级，"
                f"faces={row.get('faces_used', 0)}，status={row['status']}，"
                f"elapsed={fmt(row.get('elapsed_seconds'))} s。{reason}"
            )
    else:
        lines.append("- 无")
    lines += [
        "",
        "## 解释边界",
        "",
        "- A级为严格三面证据，B级为两面一致性，C级为冻结内参下的单面姿态，D级才是最终未得到有效结果。",
        "- `slow_success` 属于 A/B/C 成功结果，只表示运行时间超过目标阈值，不会降为D级。",
        "- `timeout` 仅表示触发可选的硬看门狗；默认关闭硬超时，慢图会计算到得到结果或算法自行拒绝。",
        "- 标称25 mm产生的长度误差属于目标内部留出一致性，不是独立物体绝对测量真值。",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "image/paper_evaluation_suite")
    parser.add_argument("--groups", nargs="*", choices=sorted(DEFAULT_CONFIGS), default=sorted(DEFAULT_CONFIGS))
    parser.add_argument("--repeats", type=int, default=10)
    parser.add_argument(
        "--timeout-seconds", type=float, default=90.0,
        help="Soft runtime threshold. Results remain valid and are marked slow.",
    )
    parser.add_argument(
        "--hard-timeout-seconds", type=float, default=0.0,
        help="Last-resort process watchdog; 0 disables forced termination (default).",
    )
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--actual-square-mm", type=float, default=None)
    parser.add_argument(
        "--camera-override-dir", type=Path, default=None,
        help="Directory containing GROUP.json evaluation-only camera overrides",
    )
    parser.add_argument(
        "--successful-images-from", type=Path, default=None,
        help="Restrict to A/B/C images in a previous paper_evaluation.json",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    allowed_images: set[tuple[str, str]] | None = None
    if args.successful_images_from is not None:
        previous = json.loads(
            args.successful_images_from.resolve().read_text(encoding="utf-8")
        )
        allowed_images = {
            (str(row["group"]), str(row["image"]))
            for row in previous.get("rows", [])
            if str(row.get("grade")) in {"A", "B", "C"}
        }
    jobs: list[tuple[str, Path, Path]] = []
    training_counts: dict[str, int] = {}
    manifests: dict[str, dict[str, Any]] = {}
    for group in args.groups:
        config = DEFAULT_CONFIGS[group]
        model_path = Path(config["model"]).resolve()
        image_dir = Path(config["images"]).resolve()
        model = json.loads(model_path.read_text(encoding="utf-8"))
        training_hashes = {
            str(item.get("sha256") or "").lower()
            for item in model.get("training_images", [])
        }
        all_images = images_in(image_dir)
        blind = [path for path in all_images if sha256_file(path).lower() not in training_hashes]
        if allowed_images is not None:
            blind = [path for path in blind if (group, path.name) in allowed_images]
        excluded = [path for path in all_images if sha256_file(path).lower() in training_hashes]
        training_counts[group] = len(excluded)
        manifests[group] = {
            "model": str(model_path),
            "image_dir": str(image_dir),
            "training_duplicates_excluded": [path.name for path in excluded],
            "blind_images": [path.name for path in blind],
        }
        jobs.extend((group, path, model_path) for path in blind)
    (output / "blind_manifest.json").write_text(
        json.dumps(manifests, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    hard_timeout = (
        None if float(args.hard_timeout_seconds) <= 0.0
        else float(args.hard_timeout_seconds)
    )
    print(
        f"Paper evaluation jobs: {len(jobs)}, workers={args.workers}, "
        f"slow_threshold={args.timeout_seconds:g}s, "
        f"hard_timeout={'disabled' if hard_timeout is None else f'{hard_timeout:g}s'}"
    )
    rows: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=max(1, int(args.workers))) as executor:
        future_map = {
            executor.submit(
                evaluate_one, group, image, model, output, int(args.repeats),
                float(args.timeout_seconds), hard_timeout, args.actual_square_mm,
                (
                    None
                    if args.camera_override_dir is None
                    else args.camera_override_dir.resolve() / f"{group}.json"
                ),
            ): (group, image.name)
            for group, image, model in jobs
        }
        for future in as_completed(future_map):
            group, name = future_map[future]
            try:
                row = future.result()
            except Exception as exc:
                row = {
                    "group": group, "image": name, "grade": "D",
                    "status": "suite_error", "faces_used": 0,
                    "reason": str(exc), "elapsed_seconds": None,
                }
            rows.append(row)
            print(
                f"[{len(rows)}/{len(jobs)}] {group}/{name}: "
                f"grade={row['grade']} status={row['status']} "
                f"faces={row.get('faces_used', 0)} elapsed={row.get('elapsed_seconds')}",
                flush=True,
            )
    rows.sort(key=lambda row: (row["group"], row["image"]))
    summaries = [
        summarize_group(
            group, [row for row in rows if row["group"] == group], training_counts[group]
        )
        for group in args.groups
    ]
    payload = {
        "schema": "trihedral-paper-evaluation-suite/v1",
        "camera_parameter_source": (
            "few_shot_trained_model"
            if args.camera_override_dir is None else str(args.camera_override_dir.resolve())
        ),
        "timeout_seconds": args.timeout_seconds,
        "timeout_policy": "soft_threshold_valid_results_count_as_success",
        "hard_timeout_seconds": hard_timeout,
        "repeats": args.repeats,
        "summaries": summaries,
        "rows": rows,
        "manifests": manifests,
    }
    (output / "paper_evaluation.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_csv(output / "paper_evaluation_rows.csv", rows)
    write_report(
        output / "PAPER_EVALUATION_REPORT.md", summaries, rows,
        args.timeout_seconds,
        "few_shot_trained_model" if args.camera_override_dir is None else str(args.camera_override_dir.resolve()),
    )
    print(f"Report: {output / 'PAPER_EVALUATION_REPORT.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
