from __future__ import annotations

import argparse
import csv
import json
import shutil
import statistics
import subprocess
import sys
from collections import Counter
from pathlib import Path
from typing import Any

from PIL import Image, ImageEnhance, ImageFilter


ROOT = Path(__file__).resolve().parents[1]
BASELINE_CSV = (
    ROOT
    / "batch_results"
    / "full136_round5_fusion_20260718_v1"
    / "current_batch_results.csv"
)
WORK_ROOT = ROOT / "paper_drafts" / "full_image_degradation_20260719"
IMAGE_ROOT = WORK_ROOT / "images"
REL_PATH_FILE = ROOT / "paper_drafts" / "full_image_degradation_relpaths_20260719.txt"
RESULT_ROOT = ROOT / "batch_results" / "full_image_degradation_20260719"
REPORT_PATH = ROOT / "paper_drafts" / "full_image_degradation_robustness_20260719.md"
SUMMARY_CSV = ROOT / "paper_drafts" / "full_image_degradation_summary_20260719.csv"
MATRIX_CSV = ROOT / "paper_drafts" / "full_image_degradation_matrix_20260719.csv"

UNUSABLE_KEYS = {("15.2_0.986", "t_5_14.jpg"), ("20_0.840", "t_3_00.jpg")}

VARIANTS = [
    {
        "name": "brightness_m20",
        "label": "brightness -20%",
        "description": "Mild under-exposure stress.",
    },
    {
        "name": "jpeg_q60",
        "label": "JPEG quality 60",
        "description": "Moderate compression stress.",
    },
    {
        "name": "blur_sigma1",
        "label": "Gaussian blur radius 1 px",
        "description": "Mild defocus or motion-blur stress.",
    },
]


def fnum(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def fmt(value: float | None, digits: int = 3) -> str:
    if value is None:
        return "-"
    return f"{value:.{digits}f}"


def rel(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(ROOT.resolve()))
    except ValueError:
        return str(path)


def find_extracted_root() -> Path:
    matches = [
        p for p in ROOT.iterdir()
        if p.is_dir() and p.name.endswith("_extracted")
    ]
    if len(matches) != 1:
        raise RuntimeError(f"Expected one *_extracted directory, found {matches}")
    return matches[0]


def read_baseline_rows() -> list[dict[str, str]]:
    with BASELINE_CSV.open("r", encoding="utf-8-sig", newline="") as fp:
        return list(csv.DictReader(fp))


def row_kind(row: dict[str, str]) -> str:
    if row.get("group") == "zhang":
        return "negative_zhang"
    if (row.get("group"), row.get("image")) in UNUSABLE_KEYS:
        return "negative_unusable_nonzhang"
    return "real_target"


def area_ge2(row: dict[str, str]) -> bool:
    area = fnum(row.get("cube_area_pct"))
    return area is None or area >= 2.0


def write_image(img: Image.Image, dst: Path, *, quality: int = 95) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.suffix.lower() in {".jpg", ".jpeg"}:
        img.convert("RGB").save(dst, quality=quality, optimize=True)
    else:
        img.save(dst)


def variant_image(src: Path, dst: Path, variant: str) -> None:
    with Image.open(src) as im:
        img = im.convert("RGB")
        if variant == "brightness_m20":
            write_image(ImageEnhance.Brightness(img).enhance(0.80), dst, quality=95)
        elif variant == "jpeg_q60":
            write_image(img, dst, quality=60)
        elif variant == "blur_sigma1":
            write_image(img.filter(ImageFilter.GaussianBlur(radius=1.0)), dst, quality=95)
        else:
            raise ValueError(f"Unknown variant: {variant}")


def prepare_images(rows: list[dict[str, str]], selected_variants: list[dict[str, str]]) -> None:
    source_root = find_extracted_root() / "shengkelou"
    if IMAGE_ROOT.exists():
        image_root_resolved = IMAGE_ROOT.resolve()
        work_root_resolved = WORK_ROOT.resolve()
        if work_root_resolved not in image_root_resolved.parents:
            raise RuntimeError(f"Refusing to remove unexpected path: {IMAGE_ROOT}")
        shutil.rmtree(IMAGE_ROOT)
    IMAGE_ROOT.mkdir(parents=True, exist_ok=True)
    rel_paths = []
    for row in rows:
        rel_path = row.get("rel_path") or f"{row.get('group')}/{row.get('image')}"
        rel_paths.append(rel_path)
        src = source_root / Path(rel_path)
        if not src.exists():
            raise FileNotFoundError(src)
        for variant in selected_variants:
            variant_image(src, IMAGE_ROOT / variant["name"] / Path(rel_path), variant["name"])
    REL_PATH_FILE.write_text("\n".join(rel_paths) + "\n", encoding="utf-8")


def run_variant(variant: dict[str, str], *, workers: int, timeout: float) -> None:
    variant_root = IMAGE_ROOT / variant["name"]
    out_dir = RESULT_ROOT / variant["name"]
    out_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable,
        "-u",
        "-X",
        "utf8",
        "batch_evaluate_current.py",
        "--method-profile",
        "ge2_single_frame_cube",
        "--image-root",
        str(variant_root),
        "--out-dir",
        str(out_dir),
        "--workers",
        str(workers),
        "--mode",
        "subprocess",
        "--per-image-timeout",
        str(float(timeout)),
        "--rel-path-file",
        str(REL_PATH_FILE),
        "--ablation-disable-stability-manifest",
        "--grid-recovery-out-dir",
        str(out_dir / "grid_recovery"),
    ]
    (out_dir / "command.json").write_text(
        json.dumps({"cmd": cmd}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    stdout = (out_dir / "run_stdout.log").open("w", encoding="utf-8")
    stderr = (out_dir / "run_stderr.log").open("w", encoding="utf-8")
    try:
        subprocess.run(cmd, cwd=ROOT, check=True, text=True, stdout=stdout, stderr=stderr)
    finally:
        stdout.close()
        stderr.close()


def read_variant_rows(variant: str) -> list[dict[str, str]]:
    path = RESULT_ROOT / variant / "current_batch_results.csv"
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as fp:
        return list(csv.DictReader(fp))


def summarize_variant(
    variant: str,
    rows: list[dict[str, str]],
    baseline_by_rel: dict[str, dict[str, str]],
) -> dict[str, Any]:
    for row in rows:
        base = baseline_by_rel.get(row.get("rel_path", ""), {})
        row["_kind"] = row_kind(base) if base else "unknown"
        row["_baseline_ge2"] = "1" if base and area_ge2(base) else "0"

    real = [r for r in rows if r.get("_kind") == "real_target"]
    real_ge2 = [r for r in real if r.get("_baseline_ge2") == "1"]
    negative = [r for r in rows if r.get("_kind", "").startswith("negative")]
    real_ok = [r for r in real if r.get("status") == "ok"]
    real_ge2_ok = [r for r in real_ge2 if r.get("status") == "ok"]
    negative_ok = [r for r in negative if r.get("status") == "ok"]
    rmses = [v for v in (fnum(r.get("rmse_px")) for r in real_ok) if v is not None]
    walls = [v for v in (fnum(r.get("wall_elapsed_sec")) for r in rows) if v is not None]
    return {
        "variant": variant,
        "images": len(rows),
        "completed": len(rows) == len(baseline_by_rel),
        "real": len(real),
        "real_ok": len(real_ok),
        "real_ge2": len(real_ge2),
        "real_ge2_ok": len(real_ge2_ok),
        "negative": len(negative),
        "negative_ok": len(negative_ok),
        "timeouts": sum(1 for r in rows if r.get("status") == "timeout"),
        "mean_real_rmse_px": statistics.fmean(rmses) if rmses else None,
        "median_wall_sec": statistics.median(walls) if walls else None,
        "status_counts": dict(Counter(r.get("status") or "" for r in rows)),
        "calibration_counts": dict(Counter(r.get("calibration_status") or "" for r in rows)),
        "model_grade_counts": dict(Counter(r.get("model_grade") or "" for r in rows if r.get("model_grade"))),
    }


def write_summary_csv(summaries: list[dict[str, Any]]) -> None:
    fields = [
        "variant",
        "images",
        "completed",
        "real",
        "real_ok",
        "real_ge2",
        "real_ge2_ok",
        "negative",
        "negative_ok",
        "timeouts",
        "mean_real_rmse_px",
        "median_wall_sec",
        "status_counts",
        "calibration_counts",
        "model_grade_counts",
    ]
    with SUMMARY_CSV.open("w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.DictWriter(fp, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in summaries:
            out = dict(row)
            for key in ["status_counts", "calibration_counts", "model_grade_counts"]:
                out[key] = json.dumps(out.get(key, {}), ensure_ascii=False, sort_keys=True)
            writer.writerow(out)


def write_matrix_csv(
    variants: list[dict[str, str]],
    baseline_rows: list[dict[str, str]],
) -> None:
    fields = [
        "rel_path",
        "kind",
        "baseline_status",
        "baseline_area_pct",
    ]
    for variant in variants:
        fields.extend([
            f"{variant['name']}_status",
            f"{variant['name']}_calibration_status",
            f"{variant['name']}_model_grade",
            f"{variant['name']}_rmse_px",
        ])
    variant_maps = {
        variant["name"]: {row.get("rel_path", ""): row for row in read_variant_rows(variant["name"])}
        for variant in variants
    }
    with MATRIX_CSV.open("w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.DictWriter(fp, fieldnames=fields)
        writer.writeheader()
        for base in baseline_rows:
            rel_path = base.get("rel_path") or f"{base.get('group')}/{base.get('image')}"
            out = {
                "rel_path": rel_path,
                "kind": row_kind(base),
                "baseline_status": base.get("status", ""),
                "baseline_area_pct": base.get("cube_area_pct", ""),
            }
            for variant in variants:
                row = variant_maps[variant["name"]].get(rel_path, {})
                out[f"{variant['name']}_status"] = row.get("status", "")
                out[f"{variant['name']}_calibration_status"] = row.get("calibration_status", "")
                out[f"{variant['name']}_model_grade"] = row.get("model_grade", "")
                out[f"{variant['name']}_rmse_px"] = row.get("rmse_px", "")
            writer.writerow(out)


def write_report(
    variants: list[dict[str, str]],
    summaries: list[dict[str, Any]],
    *,
    timeout: float,
) -> None:
    by_name = {variant["name"]: variant for variant in variants}
    lines = [
        "# Full-image degradation robustness rerun (2026-07-19)",
        "",
        f"Baseline CSV: `{rel(BASELINE_CSV)}`",
        f"Prepared image root: `{rel(IMAGE_ROOT)}`",
        f"Rel-path file: `{rel(REL_PATH_FILE)}`",
        f"Result root: `{rel(RESULT_ROOT)}`",
        f"Summary CSV: `{rel(SUMMARY_CSV)}`",
        f"Status matrix CSV: `{rel(MATRIX_CSV)}`",
        "",
        f"This full-set stress test applies pre-declared image degradations to all 136 frozen input images and reruns the same `ge2_single_frame_cube` method profile with the stability manifest disabled. The per-image timeout is {timeout:.1f} s. Disabling the manifest prevents degraded images from being accepted by replaying original-image stable corners, so this test is stricter than the frozen baseline.",
        "",
        "## Variants",
        "",
        "| variant | label | description |",
        "|---|---|---|",
    ]
    for variant in variants:
        lines.append(f"| `{variant['name']}` | {variant['label']} | {variant['description']} |")
    lines.extend([
        "",
        "## Summary",
        "",
        "| variant | completed | real ok | real >=2% ok | negative accepted | timeouts | mean real RMSE px | median wall s | status counts |",
        "|---|---|---:|---:|---:|---:|---:|---:|---|",
    ])
    for summary in summaries:
        lines.append(
            f"| `{summary['variant']}` | {summary['completed']} ({summary['images']}/136) | "
            f"{summary['real_ok']}/{summary['real']} | {summary['real_ge2_ok']}/{summary['real_ge2']} | "
            f"{summary['negative_ok']}/{summary['negative']} | {summary['timeouts']} | "
            f"{fmt(summary['mean_real_rmse_px'])} | {fmt(summary['median_wall_sec'], 1)} | "
            f"`{summary['status_counts']}` |"
        )
    lines.extend([
        "",
        "## Interpretation boundary",
        "",
        "These rows measure full-pipeline robustness to input degradation under a fixed operational timeout, not the best possible result after adding new enhancement candidates. Any failures here belong to the robustness boundary of the frozen model. Because the stability manifest is disabled, the numbers should be compared with the no-leakage perturbation setting, not directly with the frozen baseline that may use stable-corner replay on original images.",
        "",
    ])
    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")
    print(REPORT_PATH)


def selected_variants(names: list[str] | None) -> list[dict[str, str]]:
    if not names:
        return VARIANTS
    wanted = set(names)
    variants = [variant for variant in VARIANTS if variant["name"] in wanted]
    missing = sorted(wanted - {variant["name"] for variant in variants})
    if missing:
        raise ValueError(f"Unknown variant(s): {missing}")
    return variants


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--skip-run", action="store_true")
    parser.add_argument("--variant", action="append", default=None)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--timeout", type=float, default=120.0)
    args = parser.parse_args()

    baseline = read_baseline_rows()
    variants = selected_variants(args.variant)
    prepare_images(baseline, variants)
    if args.prepare_only:
        print(REL_PATH_FILE)
        return
    if not args.skip_run:
        for variant in variants:
            print(f"[full-degrade] running {variant['name']}")
            run_variant(variant, workers=args.workers, timeout=args.timeout)
    baseline_by_rel = {
        (row.get("rel_path") or f"{row.get('group')}/{row.get('image')}"): row
        for row in baseline
    }
    summaries = [
        summarize_variant(variant["name"], read_variant_rows(variant["name"]), baseline_by_rel)
        for variant in variants
    ]
    write_summary_csv(summaries)
    write_matrix_csv(variants, baseline)
    write_report(variants, summaries, timeout=args.timeout)


if __name__ == "__main__":
    main()
