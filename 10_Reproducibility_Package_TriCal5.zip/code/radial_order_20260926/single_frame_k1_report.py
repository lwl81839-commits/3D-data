from pathlib import Path
import json,csv,time
from dataclasses import replace
import numpy as np
import trained_camera_model as tm
from single_frame_k1_experiment import OUT,VAL,median,dump

models=json.loads((OUT/'single_models.json').read_text(encoding='utf-8'))
audit=json.loads((OUT/'training_three_face_audit.json').read_text(encoding='utf-8'))
diagnostics=[]
for m in models:
    row=next(r for r in audit if r['image']==m['training_image'])
    s=tm.extract_correspondences(row['image'],25,correspondence_cache_path=row['cache'],minimum_usable_faces=3)
    ids=np.argmin(np.abs(s.object_points),axis=1); rng=np.random.default_rng(4301)
    vals=[]
    for rep in range(20):
        keep=np.concatenate([rng.choice(np.flatnonzero(ids==i),max(8,int(.8*np.sum(ids==i))),replace=False) for i in range(3)])
        small=replace(s,object_points=s.object_points[keep],image_points=s.image_points[keep])
        K,d,_,dg=tm._fit_shared_model([small],radial_order=1)
        vals.append([K[0,0],K[1,1],K[0,2],K[1,2],d[0]])
    vals=np.array(vals)
    w,h=s.image_size; cap=tm.PRINCIPAL_POINT_MAX_OFFSET_SHORT_SIDE_FRACTION*min(w,h); K=np.array(m['cameraMatrix'])
    diag={'name':m['name'],'corner_subsample_repetitions':20,'columns':['fx','fy','cx','cy','k1'],'p05':np.percentile(vals,5,axis=0).tolist(),'p95':np.percentile(vals,95,axis=0).tolist(),'principal_point_at_boundary':bool(abs(K[0,2]-w/2)>=cap-.01 or abs(K[1,2]-h/2)>=cap-.01),'interpretation':'Within-image sensitivity only, not an independent-image confidence interval.'}
    diagnostics.append(diag)
dump('within_image_sensitivity.json',diagnostics)

summary=json.loads((OUT/'summary.json').read_text(encoding='utf-8'))
rows=json.loads((OUT/'per_image.json').read_text(encoding='utf-8'))
lines=['# 单张三面 k1 标定初步测试','',
'## 测试设置','',
'从原有五组、共25张三维开发图中，按固定的严格三面门限筛选，3张通过，来自2个配置。每面至少12个几何内点且至少覆盖4行4列。不要求每面全部角点完整。没有根据测试误差选训练图。',
'每个候选只使用自身一张图的三维物点/二维像点估计 fx、fy、cx、cy、k1 和一个共同刚体位姿；k2、p1、p2、k3均固定为0。使用原代码的主点及像素纵横比先验，3个通用焦距初值。缓存中的K、畸变和位姿不用于参数初始化；Zhang和五张模型仅在测试阶段加载。',
'复用现有角点与几何关联缓存，因此这是给定已通过门限的三面对应点时的求解实验，未证明原始图片只靠单张检测即可完整自动运行。已知标定物尺寸与贴板偏移也参与求解。',
'本次单张采用共同刚体位姿的联合拟合；现有五张模型采用分阶段局部单应/径向估计，故比较同时包含样本量与求解方式差异，不是严格控制求解器的样本量消融。',
'测试使用独立原始划分，按内容哈希排除开发图。所有参数组使用完全相同的检测点、20次角点划分及随机种子。先用部分角点求位姿，再评价未参与位姿拟合的角点。表中为每张图20次RMSE中位数、再跨图取中位数；与旧论文按汇总点误差的口径有所不同，不宜混填旧表。','',
'## 参数与时间','',
'|单张训练图|三面内点数|fx / fy (px)|cx / cy (px)|k1|训练RMSE(px)|拟合时间(s)|','|---|---|---|---|---|---|---|']
for m in models:
    K=np.array(m['cameraMatrix']); lines.append(f"|{m['name']}|{m['training_faces']}|{K[0,0]:.2f} / {K[1,1]:.2f}|{K[0,2]:.2f} / {K[1,2]:.2f}|{m['distCoeffs'][0]:.5f}|{m['diagnostics']['joint_reprojection_rmse_px']:.3f}|{m['elapsed_fit_s']:.3f}|")
lines+=['','时间包括3个初值的参数求解和已有缓存的门限复核；不包含原始图像检测、测试或端到端GUI运行时间。','',
'## 独立测试','',
'|配置|测试类型|模型|图数|留出RMSE(px)|物点RMSE(mm)|25mm格长误差(%)|≤2px图数|',
'|---|---|---|---|---|---|---|---|']
def f(v): return '-' if v is None else f'{v:.3f}'
for r in summary:
    if r['subset']!='all': continue
    lines.append(f"|{r['pose']}|{r['kind']}|{r['method']}|{r['images']}|{f(r['holdout_rmse_px'])}|{f(r['object_rmse_mm'])}|{f(r['square25_error_pct'])}|{r['images_below_2px']}|")
lines+=['','25mm格长只统计名义相邻格的边长，不能把25/50/100mm混合长度绝对误差当成25mm格长误差。尺寸评价复用同一标定物，尚非独立计量真值。','',
'## 多面子集','',
'|配置|模型|有效多面图数|留出RMSE(px)|物点RMSE(mm)|','|---|---|---|---|---|']
for r in summary:
    if r['subset']=='multi_face': lines.append(f"|{r['pose']}|{r['method']}|{r['images']}|{f(r['holdout_rmse_px'])}|{f(r['object_rmse_mm'])}|")
lines+=['','## 面内角点子采样敏感性','',
'每张图重复20次、每面随机保留80%角点。以下为重估参数的5%至95%分位范围，仅用于敏感性分析，并非独立图像置信区间。','',
'|训练图|fx范围(px)|k1范围|主点是否碰边界|','|---|---|---|---|']
for d in diagnostics:
    lines.append(f"|{d['name']}|{d['p05'][0]:.1f}–{d['p95'][0]:.1f}|{d['p05'][4]:.4f}–{d['p95'][4]:.4f}|{d['principal_point_at_boundary']}|")
lines+=['','## 使用边界','',
'本次三维全体测试的单张模型表现说明，低阶模型有可能满足特定场景的粗粒度几何任务。但是否满足实际需求仍取决于用户规定的容许误差和失败率。≤1/2/3像素的逐图数量在summary.csv中，可按应用标准判断，不能只看中位数。',
'30_0.827单张模型cx达到1019.4px硬边界，k1为正；这是参数补偿或几何/模型误差的警示，不能据此断言镜头真实k1为正。45_1.155两张图得到的焦距、k1也不同，因此任务误差接近不代表内参和畸变已准确辨识。',
'多面独立测试仅4张和7张，其余为单面有效。单面位姿可补偿部分参数误差，因此仍需跨面预测和独立物体测量才能支持更强的实际精度结论。',
'无法对只有一张开发图的模型做留一图验证。本实验不将它标记成通过原五图质量门限的正式模型，也未覆盖原模型。',
'单张k1不是先估计k1+k2再自动触发退化的完整策略；本次直接固定k2=0测试低阶可行性。自动退化规则及与同一单张k1+k2的稳定性比较需另做控制实验。','',
'## 可复现文件','',
'single_frame_k1_experiment.py：audit / train / test；single_frame_k1_report.py：生成诊断和汇总。',
'training_three_face_audit.json：25张全部筛选结果。single_models.json及单独模型JSON：单张参数、初值与时间。per_image.csv：逐图指标。summary.csv：整体和多面子集。within_image_sensitivity.json：20次面内80%角点子采样敏感性，不能解释为独立图像置信区间。']
(OUT/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print('Report generated',OUT,flush=True)
