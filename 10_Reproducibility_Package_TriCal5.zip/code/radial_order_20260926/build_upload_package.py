from pathlib import Path
import shutil, zipfile, hashlib, json, ast
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.pagesizes import A4
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
PAPER=ROOT/'output/paper_draft'
OUT=ROOT.parent.parent/'TriCal5_Submission_20260910'
OUT.mkdir(exist_ok=True)
TITLE='Few-Shot Camera Calibration with a Measured Trihedral Checkerboard Target under Fixed Imaging Configurations'

def write(path, text):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(text,encoding='utf-8')

def doc(name,title,paras):
    d=Document(); s=d.sections[0]
    s.page_width=Inches(8.5); s.page_height=Inches(11)
    s.top_margin=s.bottom_margin=Inches(.85)
    s.left_margin=s.right_margin=Inches(.9)
    for n in ['Normal','Title','Heading 1']:
        d.styles[n].font.name='Times New Roman'; d.styles[n].font.color.rgb=RGBColor(0,0,0)
    d.styles['Normal'].font.size=Pt(11)
    d.styles['Normal'].paragraph_format.space_after=Pt(9)
    d.add_paragraph(title,'Title')
    for p in paras: d.add_paragraph(p)
    for node in list(d.styles.element.xpath('.//w:pBdr')) + list(d.element.xpath('.//w:pBdr')):
        node.getparent().remove(node)
    d.save(OUT/(name+'.docx'))

def pdf(name,title,paras):
    ss=getSampleStyleSheet(); ss['BodyText'].fontName='Times-Roman'; ss['BodyText'].fontSize=11; ss['BodyText'].leading=15
    story=[Paragraph(title,ss['Title']),Spacer(1,18)]
    for p in paras: story += [Paragraph(p,ss['BodyText']),Spacer(1,10)]
    SimpleDocTemplate(str(OUT/(name+'.pdf')),pagesize=A4,rightMargin=55,leftMargin=55,topMargin=55,bottomMargin=55).build(story)

# Preserve the verified manuscript and make the source archive relocatable.
shutil.copy2(PAPER/'main.pdf',OUT/'02_Main_Manuscript_TriCal5.pdf')
src=OUT/'09_LaTeX_Source_TriCal5'; src.mkdir(exist_ok=True)
for n in ['main.tex','references.bib','README.md','LATEST_DATASET_BINDING.md']:
    shutil.copy2(PAPER/n,src/n)
shutil.copytree(PAPER/'figures',src/'figures',dirs_exist_ok=True)
shutil.copy2(PAPER/'data_snapshot/dual_coefficient_technical_report.pdf',OUT/'04_Supplementary_Appendix.pdf')

cover=[
'Dear Editor,',
'Please consider our manuscript, "'+TITLE+'", for publication in [journal name].',
'We investigate calibration from five images of a measured trihedral checkerboard target. Partial checker lattices initialize intrinsics, followed by regularized estimation of two radial coefficients. The fitted camera model is then frozen for pose estimation and prediction on independent images. Zhang reference parameters are excluded from estimation.',
'The primary experiment comprises five camera configurations and paired planar and cuboid tests. An external experiment repeats camera-specific estimation on two additional cameras at 30 and 45 degrees. The two 30-degree configurations provide encouraging cuboid results, while the 45-degree results expose model rejection and limited detection coverage. All four external configurations are reported. Zhang remains superior on external planar tests.',
'The contribution is a transparent, data-efficient estimation procedure with explicit conditional accuracy and coefficient-identifiability limits. We believe it is relevant to readers studying geometric calibration and practical metrology.',
'[Authors must confirm originality, absence of simultaneous submission, approval by all authors, and compliance with the selected journal before submitting this letter.]',
'Sincerely,<br/>[Corresponding author]<br/>[Affiliation]<br/>[Email]']
pdf('06_Cover_Letter_TriCal5','Cover letter',cover)
write(OUT/'06_Cover_Letter_TriCal5.txt','\n\n'.join(x.replace('<br/>','\n') for x in cover))
highlights=[
'Five trihedral images estimate a camera-specific model with two radial coefficients.',
'Partial checker lattices provide intrinsic constraints without synthetic corners.',
'Frozen models are compared on paired independent planar and cuboid images.',
'Two new cameras test the procedure with fresh five-image calibration.',
'Prediction accuracy and radial coefficient identifiability are assessed separately.']
assert all(len(h)<=85 for h in highlights)
write(OUT/'07_Highlights_TriCal5.txt','\n'.join(highlights)+'\n')
doc('01_Title_Page_AUTHOR_INPUT_REQUIRED','Title page',[TITLE,'Authors: [Full names and affiliation superscripts]','Affiliations: [Department, institution, city, postal code, country]','Corresponding author: [Name, postal address and email]','ORCID identifiers: [Add where applicable]','Author details must be completed before submission.'])
doc('12_Declarations_AUTHOR_CONFIRMATION_REQUIRED','Declarations',[
'Manuscript: '+TITLE,
'Funding: [Specify funder names and grant numbers, or confirm that no external funding was received.]',
'Competing interests: [Declare relevant financial and non-financial interests, or confirm that none exist.]',
'Data and code availability: The prepared package includes source code, split records and processed results. [Add a public repository or DOI and confirm access conditions for the original images.]',
'Author contributions: [Assign CRediT roles to named authors.]',
'Ethics and consent: The described experiments image calibration targets. [Confirm whether any identifiable people or restricted locations appear in released images and state any applicable requirements.]',
'Originality and author approval: [Confirm the work is original, not under consideration elsewhere, and approved by all authors.]'])
doc('13_Generative_AI_Declaration_AUTHOR_REVIEW_REQUIRED','Declaration of generative AI use',[
'Suggested statement for author review',
'During preparation of this work, the authors used OpenAI ChatGPT and Codex to assist with manuscript drafting and editing, code development, data organization, and generation of tables and figures. The authors must review the outputs, verify the reported methods and results, and take responsibility for the final submitted content.',
'Before submission, revise this statement to describe the actual scope of use and completed human review, following the selected journal policy. Do not state that all results have been independently verified unless that review has been completed.'])

# Publication graphic: vector text and simple process boxes, using standard plotting.
im=Image.new('RGB',(3600,1380),'white'); draw=ImageDraw.Draw(im)
def label(x,y,text,size=42,color='#163047'):
    font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',size)
    draw.multiline_text((x,y),text,font=font,fill=color,spacing=22)
label(90,70,'TriCal-5: five-image geometric camera calibration',64)
boxes=[(.35,'5 development images','Measured trihedral target\nPartial observed corners'),(4.3,'Estimate shared camera model','Intrinsics + k1 + k2\nIndependent target poses'),(8.25,'Use on a new single image','Freeze camera parameters\nEstimate pose; score held-out points')]
for x,t,b in boxes:
    px=int(x*300)
    draw.rectangle((px,330,px+1005,885),fill='#edf3f6',outline='#436579',width=4)
    label(px+36,385,t,42); label(px+36,550,b,37)
for x in [1125,2310]:
    draw.line((x,615,x+135,615),fill='#436579',width=8)
    draw.polygon([(x+135,615),(x+103,593),(x+103,637)],fill='#436579')
label(120,1000,'Paired independent tests: identical detected corners for TriCal-5 and Zhang',43)
label(120,1120,'External cameras: fresh five-image calibration for each configuration',40)
label(120,1240,'Conditional accuracy is reported with detection coverage and rejection outcomes.',37,'#555555')
im.save(OUT/'08_Graphical_Abstract_TriCal5.png',dpi=(300,300))
im=Image.open(OUT/'08_Graphical_Abstract_TriCal5.png').convert('RGB'); im.save(OUT/'08_Graphical_Abstract_TriCal5.tiff',compression='tiff_lzw',dpi=(300,300))

code=OUT/'10_Reproducibility_Package_TriCal5'; code.mkdir(exist_ok=True)
shutil.copytree(PAPER/'code_snapshot',code/'code',dirs_exist_ok=True)
# Resolve static local imports recursively using the frozen snapshot first.
pending=list((code/'code').rglob('*.py')); seen=set()
while pending:
    f=pending.pop()
    if f in seen: continue
    seen.add(f)
    try: tree=ast.parse(f.read_text(encoding='utf-8-sig'))
    except (SyntaxError,UnicodeError): continue
    mods=[]
    for n in ast.walk(tree):
        if isinstance(n,ast.Import): mods += [a.name.split('.')[0] for a in n.names]
        elif isinstance(n,ast.ImportFrom) and n.module: mods.append(n.module.split('.')[0])
    for m in mods:
        local=ROOT/(m+'.py'); dest=code/'code'/(m+'.py')
        if local.exists() and not dest.exists(): shutil.copy2(local,dest); pending.append(dest)
write(code/'README.md','# Reproducibility package\n\nPython 3.12 is the experiment target. Frozen code is under code/. Static local imports missing from the snapshot were copied from the current workspace; file hashes identify the packaged versions. Scripts contain original dataset paths and require path configuration on another machine. The image collection is not embedded. This is a source/evidence package, not a tested one-command clean-machine installer.\n\nSee the processed-data package for splits, model summaries and data locations. Zhang parameters are evaluation inputs only.\n')
data=OUT/'11_Processed_Data_TriCal5'; shutil.copytree(PAPER/'data_snapshot',data,dirs_exist_ok=True)
shutil.copytree(PAPER/'tables',data/'paper_tables',dirs_exist_ok=True)
shutil.copy2(PAPER/'LATEST_DATASET_BINDING.md',data/'LATEST_DATASET_BINDING.md')
ext=Path('E:/Data_image_3d/data_3D_20260909/dataset_split/evaluation_ours_vs_zhang')
for name in ['FINAL_CONTROLLED_COMPARISON.json','planar_test_summary.json','three_d_test_summary.json']:
    if (ext/name).exists(): shutil.copy2(ext/name,data/'external_20260909'/name)
write(data/'README.md','# Processed evidence\n\nPrimary five-configuration results and external four-configuration results are separate. The supplementary radial-identifiability PDF concerns the primary experiment. Original camera images remain in the locations listed in LATEST_DATASET_BINDING.md. JSON files retain per-image results and diagnostic failures; they are not independent metrology ground truth.\n')
for folder in [src,code,data]:
    with zipfile.ZipFile(OUT/(folder.name+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(folder.rglob('*')):
            if f.is_file(): z.write(f,f.relative_to(folder))
write(OUT/'00_README_投稿文件说明.txt','''TriCal-5 首次投稿文件包

按投稿系统上传项整理，基于现有论文和0909结果。原项目保留。
01 作者页：需填写作者和单位。
02 主稿 PDF：当前已核对的 LaTeX 稿，仍有红色作者/设备等待填信息。
04 补充材料：已有双系数径向畸变与可辨识性技术报告。
06 投稿信 PDF/TXT：目标期刊及作者确认项待填写。
07 Highlights：5条英文要点，每条不超过85字符。
08 图形摘要：PNG与TIFF，300 dpi。
09 LaTeX源文件夹及ZIP：main.tex、references.bib和figures，路径可随包迁移。
10 复现代码文件夹及ZIP：冻结代码及静态本地依赖；其他电脑需调整数据路径与环境。
11 处理后数据文件夹及ZIP：原实验和0909结果、划分与模型摘要；未重复复制全部原图。
12 声明：作者确认后使用。
13 AI使用声明：如实列出辅助范围，作者审阅后按期刊要求提交。

这是首次投稿结构，没有审稿意见，故不生成Response to Reviewers和marked稿。
编号沿用截图常见项目，03和05为返修文件保留，不代表文件缺失。
当前尚非可直接点击提交的终稿：请填写期刊、作者、相机型号和成像协议，核实声明。
主稿中关于预先确定门限及两组30度“主要证据”的表述也需核对实验记录；若为观察结果后选定，应改为探索性分析。
文件SHA256清单用于核对文件传输完整性。原始工程不需要整体上传。
''')
manifest=[{'path':str(f.relative_to(OUT)).replace('\\','/'),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(OUT.rglob('*')) if f.is_file() and f.name!='file_manifest.json']
write(OUT/'file_manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
print(str(OUT)); print('Files:',len(manifest))
