"""Fixed diagnostic subset for prediction sensitivity; no model selection."""
import numpy as np
import cv2,hashlib,sys
from run_stability_verification_20260914 import OUT,BASE,SPLIT,POSES,read,save
import trained_camera_model as t
import evaluate_trained_camera_model as ev
import evaluate_planar_blind_comparison as ep
from evaluate_planar_per_pose_controlled import image_dir
def run(pose):
    cv2.setNumThreads(1);cv2.setRNGSeed(914)
    pi=POSES.index(pose);samples=[];failures=[];selected=[]
    for kind in ['2D','3D']:
        directory=image_dir(SPLIT,pose) if kind=='2D' else SPLIT/'test'/pose/kind
        paths=sorted(directory.glob('*.jpg'));assert paths,(pose,kind,directory)
        for n in np.unique(np.linspace(0,len(paths)-1,min(12,len(paths)),dtype=int)):
            p=paths[n];h=hashlib.sha256(p.read_bytes()).hexdigest();selected.append(dict(kind=kind,image=str(p),sha256=h))
            try:
                if kind=='2D':
                    img,det=ep.detect_checker(p)
                    if img is None:raise ValueError(det)
                    obj=ep.object_points(25);ids=np.zeros(len(obj),dtype=int)
                else:
                    cs=list((BASE/'test_correspondence_cache'/pose).glob(h+'_sq25_*.npz'));assert len(cs)==1
                    s=t.extract_correspondences(str(p),25,correspondence_cache_path=str(cs[0]),minimum_usable_faces=1)
                    obj=s.object_points;img=s.image_points;ids=ev.face_ids(obj)
                rng=np.random.default_rng(914000+pi*1000+int(n));splits=[ev.stratified_holdout(ids,rng,.2,4) for _ in range(5)]
                samples.append((kind,p.name,obj,img,ids,splits,int(n)))
            except Exception as e:failures.append(dict(image=str(p),error=str(e)))
    rows=[]
    for d in sorted((OUT/'models'/pose).iterdir()):
        if not (d/'status.json').exists() or not read(d/'status.json')['completed']:continue
        m=read(d/'trained_camera_model.json');K=np.array(m['cameraMatrix']);dist=np.array(m['distCoeffs'])
        for kind,name,obj,img,ids,splits,n in samples:
            vals=[]
            for r,(tr,te) in enumerate(splits):
                cv2.setRNGSeed(914000+pi*1000+n*10+r)
                p=ev.solve_pose(obj,img,tr,K,dist)
                if p is not None and len(te):vals.append(float(np.sqrt(np.mean(ev.project_errors(obj,img,te,p,K,dist)**2))))
            rows.append(dict(model=d.name,accepted=m['accepted'],kind=kind,image=name,faces=len(np.unique(ids)),successful_trials=len(vals),median_rmse_px=float(np.median(vals)) if vals else None))
    summary=[]
    for name,kind in sorted({(r['model'],r['kind']) for r in rows}):
        group=[r for r in rows if r['model']==name and r['kind']==kind];vals=[r['median_rmse_px'] for r in group if r['median_rmse_px'] is not None]
        summary.append(dict(model=name,kind=kind,images=len(group),successful_trials=sum(r['successful_trials'] for r in group),total_trials=5*len(group),median_rmse_px=float(np.median(vals)) if vals else None))
    save(OUT/'prediction_screen'/pose/'results.json',dict(scope='fixed filename-spaced test subset, 12 images per type before extraction; 5 paired point splits; diagnostic not new blind test or replacement for full baseline evaluation',selection=selected,extraction_failures=failures,rows=rows,summary=summary))
    print(pose,len(rows),'screen rows',flush=True)
if __name__=='__main__':run(sys.argv[1])
