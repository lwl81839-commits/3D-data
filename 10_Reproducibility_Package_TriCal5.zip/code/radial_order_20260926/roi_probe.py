"""Diagnostic probe for isolating the trihedral checker cube from a grid background."""

from __future__ import annotations

import sys
import itertools
from dataclasses import replace
from pathlib import Path

import cv2
import numpy as np

from trained_camera_model import CorrespondenceSet, _fit_model_candidate, _load_cache


def _read(path: Path) -> np.ndarray:
    data = np.fromfile(path, dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError(f"Cannot read {path}")
    return image


def solid_square_components(image: np.ndarray) -> list[dict]:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    mask = np.uint8(gray < 78) * 255
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    count, labels, stats, centers = cv2.connectedComponentsWithStats(mask, 8)
    height, width = gray.shape
    components: list[dict] = []
    for label in range(1, count):
        x, y, w, h, area = map(int, stats[label])
        if not (55 <= area <= 0.008 * width * height):
            continue
        if w < 5 or h < 5 or w > 0.10 * width or h > 0.14 * height:
            continue
        ratio = w / max(h, 1)
        fill = area / max(w * h, 1)
        if not (0.35 <= ratio <= 2.8 and fill >= 0.60):
            continue
        components.append({
            "center": np.asarray(centers[label], dtype=np.float64),
            "box": (x, y, w, h),
            "area": area,
            "size": float(np.sqrt(area)),
        })
    return components


def dense_cube_component(components: list[dict]) -> list[dict]:
    if len(components) < 12:
        return []
    centers = np.asarray([item["center"] for item in components])
    sizes = np.asarray([item["size"] for item in components])
    distances = np.linalg.norm(centers[:, None, :] - centers[None, :, :], axis=2)

    # Checker squares in one face have comparable projected sizes.  Connect
    # nearby components only when both their spacing and scale agree.  Sparse
    # black fragments from the background grid then remain isolated.
    adjacency = np.zeros((len(components), len(components)), dtype=bool)
    for i in range(len(components)):
        for j in range(i + 1, len(components)):
            scale_ratio = max(sizes[i], sizes[j]) / max(min(sizes[i], sizes[j]), 1.0)
            limit = 4.25 * max(sizes[i], sizes[j])
            if scale_ratio <= 4.0 and distances[i, j] <= limit:
                adjacency[i, j] = adjacency[j, i] = True

    groups: list[list[int]] = []
    unseen = set(range(len(components)))
    while unseen:
        root = unseen.pop()
        group = [root]
        stack = [root]
        while stack:
            current = stack.pop()
            neighbours = np.flatnonzero(adjacency[current])
            for neighbour in neighbours:
                neighbour = int(neighbour)
                if neighbour in unseen:
                    unseen.remove(neighbour)
                    group.append(neighbour)
                    stack.append(neighbour)
        groups.append(group)

    # The cube checker faces contribute by far the largest connected family.
    # A tiny isolated blob must never win merely because its bounding area is
    # near zero.
    best = max(groups, key=len)
    return [components[index] for index in best] if len(best) >= 10 else []


def cube_box(cluster: list[dict], shape: tuple[int, ...]) -> tuple[int, int, int, int]:
    height, width = shape[:2]
    boxes = np.asarray([item["box"] for item in cluster], dtype=np.float64)
    # A few floor-grid blobs can bridge into the component graph.  Robust
    # percentiles keep those isolated extremes from stretching the cube box.
    left = float(np.percentile(boxes[:, 0], 4.0))
    top = float(np.percentile(boxes[:, 1], 4.0))
    right = float(np.percentile(boxes[:, 0] + boxes[:, 2], 96.0))
    bottom = float(np.percentile(boxes[:, 1] + boxes[:, 3], 96.0))
    pad_x = max(14.0, 0.14 * (right - left))
    pad_y = max(14.0, 0.14 * (bottom - top))
    x0 = max(0, int(round(left - pad_x)))
    y0 = max(0, int(round(top - pad_y)))
    x1 = min(width, int(round(right + pad_x)))
    y1 = min(height, int(round(bottom + pad_y)))
    return x0, y0, x1 - x0, y1 - y0


def face_rois(cluster: list[dict], shape: tuple[int, ...]) -> tuple[tuple[int, int, int, int], ...]:
    x, y, w, h = cube_box(cluster, shape)
    # Deliberately overlap around the three cube edges.  The requested grid
    # dimensions, rather than a brittle hard segmentation boundary, select the
    # actual checker face inside each crop.
    top = (x, y, w, max(20, int(round(0.62 * h))))
    left = (x, y + int(round(0.12 * h)), int(round(0.66 * w)), int(round(0.88 * h)))
    right = (
        x + int(round(0.34 * w)), y + int(round(0.12 * h)),
        int(round(0.66 * w)), int(round(0.88 * h)),
    )
    return top, left, right


def _board_found(gray: np.ndarray, roi: tuple[int, int, int, int], pattern: tuple[int, int]) -> bool:
    x, y, w, h = roi
    crop = gray[y:y + h, x:x + w]
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH | cv2.CALIB_CB_NORMALIZE_IMAGE
    ok, _ = cv2.findChessboardCorners(crop, pattern, flags=flags)
    if ok:
        return True
    if hasattr(cv2, "findChessboardCornersSB"):
        try:
            ok, _ = cv2.findChessboardCornersSB(
                crop, pattern, flags=cv2.CALIB_CB_NORMALIZE_IMAGE,
            )
        except cv2.error:
            ok = False
    return bool(ok)


def main() -> None:
    source = Path(sys.argv[1])
    output = Path(sys.argv[2])
    paths = sorted(source.glob("*.jpg"))
    thumbs = []
    for path in paths:
        image = _read(path)
        components = solid_square_components(image)
        cluster = dense_cube_component(components)
        canvas = image.copy()
        for item in components:
            x, y, w, h = item["box"]
            cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 220, 220), 1)
        for item in cluster:
            x, y, w, h = item["box"]
            cv2.rectangle(canvas, (x, y), (x + w, y + h), (255, 0, 255), 2)
        if cluster:
            x, y, w, h = cube_box(cluster, canvas.shape)
            cv2.rectangle(canvas, (x, y), (x + w, y + h), (0, 0, 255), 4)
            top, left, right = face_rois(cluster, canvas.shape)
            for roi, color in zip((top, left, right), ((255, 80, 0), (0, 255, 0), (0, 80, 255))):
                rx, ry, rw, rh = roi
                cv2.rectangle(canvas, (rx, ry), (rx + rw, ry + rh), color, 2)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            found_top = _board_found(gray, top, (9, 6))
            found_lr = (
                _board_found(gray, left, (9, 6)) and _board_found(gray, right, (6, 6))
            ) or (
                _board_found(gray, right, (9, 6)) and _board_found(gray, left, (6, 6))
            )
            status = f" boards={int(found_top)}/{int(found_lr)}"
        else:
            status = " boards=0/0"
        print(f"{path.name}: components={len(components)}, dense={len(cluster)},{status.strip()}")
        cv2.putText(
            canvas, f"{path.name}: all={len(components)} dense={len(cluster)}{status}",
            (16, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 5,
        )
        cv2.putText(
            canvas, f"{path.name}: all={len(components)} dense={len(cluster)}{status}",
            (16, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2,
        )
        thumbs.append(cv2.resize(canvas, (640, 360)))
    blank = np.zeros_like(thumbs[0])
    rows = []
    for start in range(0, len(thumbs), 3):
        rows.append(np.hstack(thumbs[start:start + 3] + [blank] * (3 - len(thumbs[start:start + 3]))))
    sheet = np.vstack(rows)
    output.parent.mkdir(parents=True, exist_ok=True)
    ok, encoded = cv2.imencode(output.suffix, sheet)
    if not ok:
        raise RuntimeError("Could not encode diagnostic sheet")
    encoded.tofile(output)


def report_cached_pnp(source: Path, cache_dir: Path) -> None:
    width, height = 1920, 1080
    diagonal = float(np.hypot(width, height))
    camera = np.asarray(
        [[0.70 * diagonal, 0.0, width / 2.0],
         [0.0, 0.70 * diagonal, height / 2.0],
         [0.0, 0.0, 1.0]], dtype=np.float64,
    )
    distortion = np.zeros(5, dtype=np.float64)
    for path in sorted(source.glob("*.jpg")):
        import hashlib
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        cache = cache_dir / f"{digest}_sq25.npz"
        if not cache.exists():
            continue
        sample: CorrespondenceSet = _load_cache(str(cache), str(path.resolve()), None)
        with np.load(cache, allow_pickle=True) as raw_cache:
            group_lengths = [
                len(np.asarray(group).reshape(-1, 2))
                for group in raw_cache["image_points"]
            ]
        obj = sample.object_points.reshape(-1, 1, 3)
        img = sample.image_points.reshape(-1, 1, 2)
        ok, rvec, tvec, inliers = cv2.solvePnPRansac(
            obj, img, camera, distortion,
            iterationsCount=3000, reprojectionError=5.0,
            confidence=0.999, flags=cv2.SOLVEPNP_EPNP,
        )
        if not ok or inliers is None:
            print(path.name, "PnP failed")
            continue
        indices = inliers.reshape(-1)
        rvec, tvec = cv2.solvePnPRefineLM(
            obj[indices], img[indices], camera, distortion, rvec, tvec,
        )
        projected, _ = cv2.projectPoints(obj, rvec, tvec, camera, distortion)
        error = np.linalg.norm(projected.reshape(-1, 2) - sample.image_points, axis=1)
        boundaries = np.cumsum([0] + group_lengths)
        face_inliers = [
            int(np.sum((indices >= boundaries[i]) & (indices < boundaries[i + 1])))
            for i in range(3)
        ]
        print(
            f"{path.name}: pnp_inliers={len(indices)}/{len(error)}, "
            f"faces={face_inliers}/{group_lengths}, "
            f"inlier_rmse={np.sqrt(np.mean(error[indices] ** 2)):.3f}, "
            f"all_rmse={np.sqrt(np.mean(error ** 2)):.3f}"
        )

        # Diagnose whether the extracted grids are right but one or more face
        # axes were mirrored during automatic association.
        best = None
        axes = ((0, 1), (0, 2), (1, 2))
        for bits in itertools.product((0, 1), repeat=6):
            candidate = sample.object_points.copy()
            offset = 0
            for face_index, length in enumerate(group_lengths):
                for local_axis, world_axis in enumerate(axes[face_index]):
                    if bits[2 * face_index + local_axis]:
                        candidate[offset:offset + length, world_axis] = (
                            250.0 - candidate[offset:offset + length, world_axis]
                        )
                offset += length
            candidate_obj = candidate.reshape(-1, 1, 3)
            ok2, rv2, tv2, in2 = cv2.solvePnPRansac(
                candidate_obj, img, camera, distortion,
                iterationsCount=600, reprojectionError=5.0,
                confidence=0.995, flags=cv2.SOLVEPNP_EPNP,
            )
            if not ok2 or in2 is None:
                continue
            idx2 = in2.reshape(-1)
            counts2 = [
                int(np.sum((idx2 >= boundaries[i]) & (idx2 < boundaries[i + 1])))
                for i in range(3)
            ]
            key = (min(counts2), sum(count > 5 for count in counts2), len(idx2))
            if best is None or key > best[0]:
                best = (key, bits, counts2)
        if best is not None:
            print(f"  best_reflection: score={best[0]}, bits={best[1]}, faces={best[2]}")


def train_filtered_probe(source: Path, cache_dir: Path) -> None:
    width, height = 1920, 1080
    focal = 0.70 * float(np.hypot(width, height))
    camera = np.asarray(
        [[focal, 0.0, width / 2.0], [0.0, focal, height / 2.0], [0.0, 0.0, 1.0]],
        dtype=np.float64,
    )
    distortion = np.zeros(5, dtype=np.float64)
    samples = []
    for path in sorted(source.glob("*.jpg")):
        import hashlib
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        cache = cache_dir / f"{digest}_sq25.npz"
        if not cache.exists():
            continue
        sample = _load_cache(str(cache), str(path.resolve()), None)
        with np.load(cache, allow_pickle=True) as raw_cache:
            lengths = [len(np.asarray(group).reshape(-1, 2)) for group in raw_cache["image_points"]]
        boundaries = np.cumsum([0] + lengths)
        cv2.setRNGSeed(20260723)
        ok, rvec, tvec, inliers = cv2.solvePnPRansac(
            sample.object_points.reshape(-1, 1, 3),
            sample.image_points.reshape(-1, 1, 2), camera, distortion,
            iterationsCount=4000, reprojectionError=5.0, confidence=0.999,
            flags=cv2.SOLVEPNP_EPNP,
        )
        if not ok or inliers is None:
            continue
        indices = inliers.reshape(-1)
        face_counts = [
            int(np.sum((indices >= boundaries[i]) & (indices < boundaries[i + 1])))
            for i in range(3)
        ]
        valid_faces = [i for i, count in enumerate(face_counts) if count >= 6]
        if len(valid_faces) < 2:
            print(path.name, "rejected", face_counts)
            continue
        keep = np.asarray([
            index for index in indices
            if any(boundaries[i] <= index < boundaries[i + 1] for i in valid_faces)
        ], dtype=int)
        samples.append(replace(
            sample,
            image_points=sample.image_points[keep].copy(),
            object_points=sample.object_points[keep].copy(),
            source_model="three_face_ransac_inliers",
        ))
        print(path.name, "kept", len(keep), "faces", face_counts)
    print("training samples", len(samples))
    flags = (
        cv2.CALIB_USE_INTRINSIC_GUESS
        | cv2.CALIB_ZERO_TANGENT_DIST
        | cv2.CALIB_FIX_K3
        | cv2.CALIB_FIX_K4
        | cv2.CALIB_FIX_K5
        | cv2.CALIB_FIX_K6
    )
    rms_cv, K_cv, dist_cv, _rv, _tv = cv2.calibrateCamera(
        [sample.object_points.astype(np.float32) for sample in samples],
        [sample.image_points.astype(np.float32) for sample in samples],
        (width, height), camera.copy(), np.zeros(5, dtype=np.float64),
        flags=flags,
    )
    print("opencv_free_intrinsics", rms_cv, K_cv, dist_cv.reshape(-1))
    for radial_order in (1, 2):
        candidate = _fit_model_candidate(samples, radial_order=radial_order, progress=None)
        print("radial_order", radial_order, "accepted", candidate["accepted"])
        print("K", candidate["K"])
        print("dist", candidate["dist"])
        print("diagnostics", candidate["diagnostics"])
        print("cv", candidate["cross_validation"])
        print("stability", candidate["k2_stability"])
        print("per_image", [(Path(x["image"]).name, x["reprojection_rmse_px"]) for x in candidate["per_image"]])


if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] == "--cached-pnp":
        report_cached_pnp(Path(sys.argv[2]), Path(sys.argv[3]))
    elif len(sys.argv) >= 2 and sys.argv[1] == "--train-filtered":
        train_filtered_probe(Path(sys.argv[2]), Path(sys.argv[3]))
    else:
        main()
