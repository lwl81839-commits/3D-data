"""Single-image k1 diagnostic. Keeps existing models and splits untouched."""
from pathlib import Path
import json, hashlib, time, sys
import numpy as np
import cv2
import trained_camera_model as tm
from dataclasses import replace
import evaluate_trained_camera_model as ev
import evaluate_planar_blind_comparison as ep
import csv

ROOT=Path(__file__).resolve().parent
SPLIT=Path('E:/Data_image_3d/data_3D_0820_split_model_3D5_Zhang2D20_each_pose_quality_gated')
VAL=SPLIT/'validation_ours_vs_zhang'
OUT=ROOT/'output/single_frame_k1_experiment'
OUT.mkdir(parents=True,exist_ok=True)

def dump(name,data):
    (OUT/name).write_text(json.dumps(tm._finite_json_value(data),ensure_ascii=False,indent=2),encoding='utf-8')

def audit():
    rows=[]
    for pose_dir in sorted((SPLIT/'train').iterdir()):
        if not pose_dir.is_dir(): continue
        caches=VAL/'per_pose_models'/pose_dir.name/'.trihedral_correspondence_cache'
        for im in sorted((pose_dir/'3D').glob('*.jpg')):
            start=time.perf_counter(); h=tm._sha256(str(im)); found=list(caches.glob(h+'_sq25_*.npz'))
            row={'pose':pose_dir.name,'image':str(im),'sha256':h,'cache':str(found[0]) if found else None}
            try:
                if not found: raise RuntimeError('no_cache')
                s=tm.extract_correspondences(str(im),25,correspondence_cache_path=str(found[0]),minimum_usable_faces=3)
                row.update(strict_three_face=True,inliers=list(s.face_inlier_counts),spans=s.face_grid_spans)
                np.savez(OUT/(pose_dir.name+'_'+im.stem+'.npz'),image_points=s.image_points,object_points=s.object_points,image_size=s.image_size,face_inliers=s.face_inlier_counts,face_spans=s.face_grid_spans)
            except Exception as e: row.update(strict_three_face=False,error=str(e))
            row['elapsed_s']=time.perf_counter()-start; rows.append(row); dump('training_three_face_audit.json',rows)
            print(pose_dir.name,im.name,row['strict_three_face'],row.get('inliers',row.get('error','')[:90]),flush=True)
    return rows

def train():
    rows=json.loads((OUT/'training_three_face_audit.json').read_text(encoding='utf-8'))
    models=[]
    for row in rows:
        if not row['strict_three_face']: continue
        st=time.perf_counter()
        s=tm.extract_correspondences(row['image'],25,correspondence_cache_path=row['cache'],minimum_usable_faces=3)
        trials=[]
        # Camera-generic initializations only; never use cached calibration seeds.
        for mult in [.5,.7,1.0]:
            w,h=s.image_size; k=tm._camera_matrix(mult*np.hypot(w,h),w/2,h/2)
            K,d,per,diag=tm._fit_shared_model([s],radial_order=1,initial_K=k,initial_dist=np.zeros(5))
            trials.append({'cameraMatrix':K.tolist(),'distCoeffs':d.tolist(),'per_image':per,'diagnostics':diag,'initial_focal_diagonal_fraction':mult})
        best=min(trials,key=lambda x:x['diagnostics']['joint_reprojection_rmse_px'])
        key=row['pose']+'_'+Path(row['image']).stem
        model={'name':key,'pose':row['pose'],'training_images_used':1,'training_image':row['image'],'sha256':row['sha256'],'image_size':list(s.image_size),'square_size_mm':25,'no_zhang_reference_used':True,'no_five_image_parameters_used':True,'k2_fixed_zero':True,'cached_correspondences_used':True,'scope':'conditional_on_existing_three_face_correspondences','training_faces':list(s.face_inlier_counts),'elapsed_fit_s':time.perf_counter()-st,'multistart':trials,**best}
        model['training_physical_gate']=bool(best['diagnostics']['optimizer_success'] and best['per_image'][0]['positive_depth_fraction']>=.99)
        model['formal_few_shot_accepted']=False
        model['note']='Single-image research model; multi-image leave-one-out validation not applicable. No claim of automatic standalone detector validation.'
        dump(key+'_model.json',model); models.append(model)
        print('FIT',key,'k1',best['distCoeffs'][0],'RMSE',best['diagnostics']['joint_reprojection_rmse_px'],'seconds',model['elapsed_fit_s'],flush=True)
    dump('single_models.json',models)
    return models

def median(x):
    a=np.asarray([v for v in x if v is not None and np.isfinite(v)],float)
    return float(np.median(a)) if len(a) else None

def score3d(s,K,d,seed):
    obj=s.object_points; img=s.image_points; ids=ev.face_ids(obj)
    rng=np.random.default_rng(seed); px=[]; mm=[]; lengths=[]; rel25=[]; line=ev.line_residuals(s,K,d)
    for rep in range(20):
        tr,te=ev.stratified_holdout(ids,rng,.2,3); cv2.setRNGSeed(seed+rep)
        p=ev.solve_pose(obj,img,tr,K,d)
        if p is None: continue
        e=ev.project_errors(obj,img,te,p,K,d); o,l=ev.object_space_metrics(obj,img,te,ids,p,K,d,25,25)
        px.append(float(np.sqrt(np.mean(e*e)))); mm.append(float(np.sqrt(np.mean(np.square(o)))) if o else None)
        lengths.extend(v['absolute_error_mm'] for v in l)
        rel25.extend(v['relative_error_pct'] for v in l if v['nominal_length_mm']==25)
    return {'successful_trials':len(px),'holdout_rmse_px':median(px),'object_rmse_mm':median(mm),'length_abs_mm':median(lengths),'square25_error_pct':median(rel25),'line_rms_px':median(line)}

def evaluate():
    single=json.loads((OUT/'single_models.json').read_text(encoding='utf-8'))
    allrows=json.loads((OUT/'per_image.json').read_text(encoding='utf-8')) if (OUT/'per_image.json').exists() else []
    failures=[]
    for pose in sorted({m['pose'] for m in single}):
        ms=[m for m in single if m['pose']==pose]
        base=json.loads((VAL/'per_pose_models'/pose/'trained_camera_model.json').read_text(encoding='utf-8'))
        z=json.loads((VAL/'final_test_evaluation/fixed_zhang_overrides'/(pose+'.json')).read_text(encoding='utf-8'))
        methods={m['name']:(np.array(m['cameraMatrix']),np.array(m['distCoeffs']).reshape(5)) for m in ms}
        methods['five_image_k1_k2']=(np.array(base['cameraMatrix']),np.array(base['distCoeffs']).reshape(5))
        methods['zhang_20']=(np.array(z['cameraMatrix']),np.array(z['distCoeffs']).reshape(5))
        trainhash={m['sha256'] for m in ms}
        for kind in ['3D','2D']:
            folder=SPLIT/'test'/pose/kind
            if kind=='2D' and not folder.exists(): folder=SPLIT/'test'/pose/'zhang_2d'
            paths=sorted(folder.glob('*.jpg'))
            if not paths: raise RuntimeError('Empty test folder: '+str(folder))
            for idx,im in enumerate(paths):
                if all(any(r['pose']==pose and r['kind']==kind and r['image']==im.name and r['method']==m for r in allrows) for m in methods): continue
                h=tm._sha256(str(im)); assert h not in trainhash
                seed=20261000+idx
                try:
                    if kind=='3D':
                        cache=VAL/'test_correspondence_cache'/pose/(h+'_sq25_'+tm.CORRESPONDENCE_CACHE_TAG+'.npz')
                        if not cache.exists(): raise RuntimeError('no_cached_correspondences')
                        s=tm.extract_correspondences(str(im),25,correspondence_cache_path=str(cache),minimum_usable_faces=1)
                        for name,(K,d) in methods.items():
                            r=score3d(s,K,d,seed)
                            allrows.append({'pose':pose,'kind':kind,'image':im.name,'sha256':h,'method':name,'faces':ev.usable_faces(s),**r})
                    else:
                        cd=OUT/'planar_cache'; cd.mkdir(exist_ok=True); cp=cd/(h+'.npy')
                        if cp.exists(): corners=np.load(cp)
                        else:
                            corners,det=ep.detect_checker(im)
                            if corners is None: raise RuntimeError(det)
                            np.save(cp,corners)
                        obj=ep.object_points(25); full=np.arange(len(obj)); rng=np.random.default_rng(seed)
                        held=[np.sort(rng.choice(len(obj),11,replace=False)) for _ in range(20)]
                        for name,(K,d) in methods.items():
                            px=[]; mm=[]
                            for te in held:
                                p=ep.solve_pose(obj,corners,np.setdiff1d(full,te),K,d)
                                if p is None: continue
                                e=ep.project_errors(obj,corners,te,p,K,d); o=ep.backproject_object_errors(obj,corners,te,p,K,d)
                                px.append(float(np.sqrt(np.mean(e*e)))); mm.append(float(np.sqrt(np.mean(o*o))))
                            allrows.append({'pose':pose,'kind':kind,'image':im.name,'sha256':h,'method':name,'faces':1,'successful_trials':len(px),'holdout_rmse_px':median(px),'object_rmse_mm':median(mm),'length_abs_mm':None,'square25_error_pct':None,'line_rms_px':float(ep.line_rms(corners,K,d))})
                except Exception as e: failures.append({'pose':pose,'kind':kind,'image':im.name,'error':str(e)})
                if idx%10==0:
                    print('TEST',pose,kind,idx,'rows',len(allrows),'failed',len(failures),flush=True)
                    dump('per_image.json',allrows); dump('failures.json',failures)
    dump('per_image.json',allrows); dump('failures.json',failures)
    with (OUT/'per_image.csv').open('w',newline='',encoding='utf-8-sig') as f:
        wr=csv.DictWriter(f,fieldnames=list(allrows[0])); wr.writeheader(); wr.writerows(allrows)
    summary=[]
    for pose,kind,method in sorted({(r['pose'],r['kind'],r['method']) for r in allrows}):
        rows=[r for r in allrows if (r['pose'],r['kind'],r['method'])==(pose,kind,method)]
        for sub in ['all','multi_face'] if kind=='3D' else ['all']:
            group=[r for r in rows if sub=='all' or r['faces']>=2]
            vals={k:median([r[k] for r in group]) for k in ['holdout_rmse_px','object_rmse_mm','length_abs_mm','square25_error_pct','line_rms_px']}
            vals.update({f'images_below_{t}px':sum(r['holdout_rmse_px'] is not None and r['holdout_rmse_px']<=t for r in group) for t in [1,2,3]})
            summary.append({'pose':pose,'kind':kind,'method':method,'subset':sub,'images':len(group),**vals})
    dump('summary.json',summary)
    with (OUT/'summary.csv').open('w',newline='',encoding='utf-8-sig') as f:
        wr=csv.DictWriter(f,fieldnames=list(summary[0])); wr.writeheader(); wr.writerows(summary)
    print('SUMMARY',json.dumps(summary),flush=True)

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'audit'
    if mode=='audit': audit()
    elif mode=='train': train()
    elif mode=='test': evaluate()
