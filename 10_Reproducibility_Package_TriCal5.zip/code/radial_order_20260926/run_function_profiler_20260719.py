from __future__ import annotations

import argparse
import csv
import io
import json
import os
import pstats
import runpy
import sys
import time
from cProfile import Profile
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
BASELINE_CSV = (
    ROOT
    / "batch_results"
    / "full136_round5_fusion_20260718_v1"
    / "current_batch_results.csv"
)
OUT_ROOT = ROOT / "paper_drafts" / "function_profiler_20260719"
BATCH_OUT_ROOT = ROOT / "batch_results" / "function_profiler_20260719"
REPORT_PATH = ROOT / "paper_drafts" / "function_profiler_20260719.md"
SUMMARY_CSV = ROOT / "paper_drafts" / "function_profiler_summary_20260719.csv"
TOP_FUNCTIONS_CSV = ROOT / "paper_drafts" / "function_profiler_top_functions_20260719.csv"


CASE_SPECS = [
    {
        "case": "direct_normal_fast",
        "selector": "normal_quality_gate",
        "description": "A direct accepted calibration row, chosen as the fastest normal-quality representative.",
    },
    {
        "case": "manifest_replay_fast",
        "selector": "final_manifest_calibration",
        "description": "A stable-manifest accepted row, chosen as the fastest manifest representative.",
    },
    {
        "case": "grid_recovery_fast",
        "selector": "grid_recovered_calibration",
        "description": "A grid-recovered accepted row, chosen as the fastest recovered-grid representative.",
    },
    {
        "case": "negative_reject_fast",
        "selector": "not_ok",
        "description": "A non-accepted row, chosen as the fastest negative or unusable representative.",
    },
]


def fnum(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def fmt(value: float | None, digits: int = 3) -> str:
    if value is None:
        return "-"
    return f"{value:.{digits}f}"


def read_rows() -> list[dict[str, str]]:
    with BASELINE_CSV.open("r", encoding="utf-8-sig", newline="") as fp:
        return list(csv.DictReader(fp))


def choose_cases(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    selected: list[dict[str, str]] = []
    used: set[str] = set()
    for spec in CASE_SPECS:
        selector = spec["selector"]
        if selector == "not_ok":
            candidates = [row for row in rows if row.get("status") != "ok"]
        else:
            candidates = [
                row for row in rows
                if row.get("status") == "ok"
                and row.get("calibration_status") == selector
            ]
        candidates = [
            row for row in candidates
            if (row.get("rel_path") or f"{row.get('group')}/{row.get('image')}") not in used
        ]
        if not candidates:
            continue
        candidates.sort(key=lambda r: fnum(r.get("wall_elapsed_sec")) or 10**9)
        chosen = dict(candidates[0])
        chosen["_case"] = spec["case"]
        chosen["_description"] = spec["description"]
        used.add(chosen.get("rel_path") or f"{chosen.get('group')}/{chosen.get('image')}")
        selected.append(chosen)
    return selected


def set_argv_for_case(case: dict[str, str], out_dir: Path) -> list[str]:
    rel_path = case.get("rel_path") or f"{case.get('group')}/{case.get('image')}"
    return [
        "batch_evaluate_current.py",
        "--method-profile",
        "ge2_single_frame_cube",
        "--out-dir",
        str(out_dir),
        "--workers",
        "1",
        "--mode",
        "inprocess",
        "--rel-path",
        rel_path,
    ]


def run_profile(case: dict[str, str], *, disable_stability: bool) -> dict[str, Any]:
    case_name = case["_case"]
    out_dir = BATCH_OUT_ROOT / case_name
    out_dir.mkdir(parents=True, exist_ok=True)
    argv = set_argv_for_case(case, out_dir)
    if disable_stability:
        argv.append("--ablation-disable-stability-manifest")
    profile_path = OUT_ROOT / f"{case_name}.prof"
    stats_txt_path = OUT_ROOT / f"{case_name}_top.txt"
    old_argv = sys.argv[:]
    old_cwd = Path.cwd()
    old_env = os.environ.copy()
    old_sys_path = sys.path[:]
    started = time.perf_counter()
    profiler = Profile()
    try:
        os.chdir(ROOT)
        if str(ROOT) not in sys.path:
            sys.path.insert(0, str(ROOT))
        sys.argv = argv
        profiler.enable()
        try:
            runpy.run_path(str(ROOT / "batch_evaluate_current.py"), run_name="__main__")
        except SystemExit as exc:
            if exc.code not in (0, None):
                raise
        finally:
            profiler.disable()
    finally:
        elapsed = time.perf_counter() - started
        sys.argv = old_argv
        sys.path[:] = old_sys_path
        os.chdir(old_cwd)
        os.environ.clear()
        os.environ.update(old_env)

    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    profiler.dump_stats(str(profile_path))
    buffer = io.StringIO()
    pstats.Stats(profiler, stream=buffer).strip_dirs().sort_stats("cumtime").print_stats(40)
    stats_txt_path.write_text(buffer.getvalue(), encoding="utf-8")
    row_path = out_dir / "current_batch_results.csv"
    result_rows = []
    if row_path.exists():
        with row_path.open("r", encoding="utf-8-sig", newline="") as fp:
            result_rows = list(csv.DictReader(fp))
    result = result_rows[0] if result_rows else {}
    return {
        "case": case_name,
        "rel_path": case.get("rel_path") or f"{case.get('group')}/{case.get('image')}",
        "description": case["_description"],
        "baseline_status": case.get("status", ""),
        "baseline_gate": case.get("calibration_status", ""),
        "baseline_wall_sec": fnum(case.get("wall_elapsed_sec")),
        "profile_wall_sec": elapsed,
        "profile_status": result.get("status", ""),
        "profile_gate": result.get("calibration_status", ""),
        "profile_rmse_px": fnum(result.get("rmse_px")),
        "profile_path": str(profile_path),
        "stats_txt_path": str(stats_txt_path),
        "batch_out_dir": str(out_dir),
        "disable_stability": disable_stability,
    }


def top_functions(profile_path: Path, *, case_name: str, limit: int) -> list[dict[str, Any]]:
    stats = pstats.Stats(str(profile_path))
    rows = []
    for (filename, line, func), values in stats.stats.items():
        primitive_calls, total_calls, total_time, cumulative_time, _ = values
        rows.append({
            "case": case_name,
            "file": Path(filename).name,
            "line": line,
            "function": func,
            "primitive_calls": primitive_calls,
            "total_calls": total_calls,
            "total_time_sec": total_time,
            "cumulative_time_sec": cumulative_time,
        })
    rows.sort(key=lambda r: r["cumulative_time_sec"], reverse=True)
    return rows[:limit]


def write_csvs(summaries: list[dict[str, Any]], top_rows: list[dict[str, Any]]) -> None:
    with SUMMARY_CSV.open("w", encoding="utf-8-sig", newline="") as fp:
        fields = [
            "case",
            "rel_path",
            "baseline_status",
            "baseline_gate",
            "baseline_wall_sec",
            "profile_wall_sec",
            "profile_status",
            "profile_gate",
            "profile_rmse_px",
            "disable_stability",
            "profile_path",
            "stats_txt_path",
            "batch_out_dir",
        ]
        writer = csv.DictWriter(fp, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in summaries:
            writer.writerow(row)

    with TOP_FUNCTIONS_CSV.open("w", encoding="utf-8-sig", newline="") as fp:
        fields = [
            "case",
            "file",
            "line",
            "function",
            "primitive_calls",
            "total_calls",
            "total_time_sec",
            "cumulative_time_sec",
        ]
        writer = csv.DictWriter(fp, fieldnames=fields)
        writer.writeheader()
        for row in top_rows:
            writer.writerow(row)


def is_wrapper_function(row: dict[str, Any]) -> bool:
    file_name = str(row.get("file", ""))
    func = str(row.get("function", ""))
    if file_name == "runpy.py":
        return True
    if func in {"<module>", "<built-in method builtins.exec>"}:
        return True
    if file_name == "batch_evaluate_current.py" and func in {
        "main",
        "run_path",
        "_run_one",
    }:
        return True
    return False


def write_report(summaries: list[dict[str, Any]], top_rows: list[dict[str, Any]]) -> None:
    top_by_case: dict[str, list[dict[str, Any]]] = {}
    for row in top_rows:
        top_by_case.setdefault(row["case"], []).append(row)

    lines = [
        "# Function-level profiler (2026-07-19)",
        "",
        f"Summary CSV: `{SUMMARY_CSV.relative_to(ROOT)}`",
        f"Top-functions CSV: `{TOP_FUNCTIONS_CSV.relative_to(ROOT)}`",
        f"Profile artifacts: `{OUT_ROOT.relative_to(ROOT)}`",
        "",
        "The profiler runs representative single-image cases through `batch_evaluate_current.py` in in-process mode under `cProfile`. It is a function-level runtime attribution tool, not a pass-rate experiment. Cases are chosen from the frozen 136-image result table by route, preferring the fastest available row in each route so that profiling can finish locally.",
        "",
        "## Case summary",
        "",
        "| case | rel path | baseline gate | baseline wall s | profiled status | profiled gate | profiled wall s | RMSE px |",
        "|---|---|---|---:|---|---|---:|---:|",
    ]
    for row in summaries:
        lines.append(
            f"| `{row['case']}` | `{row['rel_path']}` | `{row['baseline_gate']}` | "
            f"{fmt(row['baseline_wall_sec'], 1)} | `{row['profile_status']}` | "
            f"`{row['profile_gate']}` | {fmt(row['profile_wall_sec'], 1)} | "
            f"{fmt(row['profile_rmse_px'])} |"
        )

    lines.extend([
        "",
        "## Top cumulative functions",
        "",
    ])
    for row in summaries:
        case = row["case"]
        lines.append(f"### {case}")
        lines.append("")
        lines.append("| rank | file:line | function | cumulative s | self s | calls |")
        lines.append("|---:|---|---|---:|---:|---:|")
        meaningful = [
            item for item in top_by_case.get(case, [])
            if not is_wrapper_function(item)
        ]
        for idx, item in enumerate(meaningful[:12], 1):
            lines.append(
                f"| {idx} | `{item['file']}:{item['line']}` | `{item['function']}` | "
                f"{fmt(item['cumulative_time_sec'], 3)} | {fmt(item['total_time_sec'], 3)} | "
                f"{item['total_calls']} |"
            )
        lines.append("")

    lines.extend([
        "## Interpretation boundary",
        "",
        "This profiler complements the earlier CSV-based stage timing. It attributes wall time to Python functions for selected representative routes, while full-set runtime statistics remain in the batch CSV and degradation reports. Expensive OpenCV kernels may appear as time inside their Python caller because `cProfile` cannot break down native C++ internals.",
        "",
    ])
    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")
    print(REPORT_PATH)


def read_summary_csv() -> list[dict[str, Any]]:
    if not SUMMARY_CSV.exists():
        return []
    numeric = {"baseline_wall_sec", "profile_wall_sec", "profile_rmse_px"}
    rows: list[dict[str, Any]] = []
    with SUMMARY_CSV.open("r", encoding="utf-8-sig", newline="") as fp:
        for row in csv.DictReader(fp):
            for key in numeric:
                row[key] = fnum(row.get(key))
            rows.append(row)
    return rows


def read_top_functions_csv() -> list[dict[str, Any]]:
    if not TOP_FUNCTIONS_CSV.exists():
        return []
    numeric_float = {"total_time_sec", "cumulative_time_sec"}
    numeric_int = {"line", "primitive_calls", "total_calls"}
    rows: list[dict[str, Any]] = []
    with TOP_FUNCTIONS_CSV.open("r", encoding="utf-8-sig", newline="") as fp:
        for row in csv.DictReader(fp):
            for key in numeric_float:
                row[key] = fnum(row.get(key)) or 0.0
            for key in numeric_int:
                try:
                    row[key] = int(row.get(key) or 0)
                except ValueError:
                    row[key] = 0
            rows.append(row)
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", action="append", default=None, help="Optional profiler case name.")
    parser.add_argument("--disable-stability", action="store_true")
    parser.add_argument("--skip-run", action="store_true", help="Regenerate report from existing profiler CSV files.")
    parser.add_argument("--top", type=int, default=40)
    args = parser.parse_args()

    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    if args.skip_run:
        summaries = read_summary_csv()
        top_rows = read_top_functions_csv()
        if not summaries or not top_rows:
            raise RuntimeError("Existing profiler CSV files are missing; run without --skip-run first.")
        write_report(summaries, top_rows)
        return

    cases = choose_cases(read_rows())
    if args.case:
        wanted = set(args.case)
        cases = [case for case in cases if case["_case"] in wanted]
        missing = wanted - {case["_case"] for case in cases}
        if missing:
            raise ValueError(f"Unknown or unavailable case(s): {sorted(missing)}")

    summaries = []
    top_rows = []
    for case in cases:
        print(f"[profile] running {case['_case']} -> {case.get('rel_path')}")
        summary = run_profile(case, disable_stability=args.disable_stability)
        summaries.append(summary)
        top_rows.extend(
            top_functions(Path(summary["profile_path"]), case_name=summary["case"], limit=args.top)
        )

    write_csvs(summaries, top_rows)
    write_report(summaries, top_rows)


if __name__ == "__main__":
    main()
