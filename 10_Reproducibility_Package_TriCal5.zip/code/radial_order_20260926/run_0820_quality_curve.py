"""Matched validation comparison: exclude zero-homography training images only."""
from pathlib import Path
import os,sys,shutil,hashlib
ROOT=Path(__file__).resolve().parent
ORIGINAL=ROOT/'output/experiment_0820_stability_curve'
os.environ['STABILITY_CURVE_OUTPUT']=str(ROOT/'output/experiment_0820_quality_curve')
import run_0820_stability_curve as r
import numpy as np
def prepare():
    r.OUT.mkdir(exist_ok=True)
    shutil.copytree(ORIGINAL/'code',r.OUT/'code',dirs_exist_ok=True)
    evidence=r.read(ORIGINAL/'local_homography_evidence.json');old=r.read(ORIGINAL/'protocol.json');jobs=[];splits=[]
    for pi,split in enumerate(old['splits']):
        pose=split['pose']
        if pose=='15_0.528':continue # no zero-homography image; existing results are identical policy control
        full=split['pool'];pool=[x for x in full if evidence[x['sha256']]['usable_local_homographies']>=1]
        allowed={x['sha256'] for x in pool};maximum=min(10,len(pool));sizes=sorted(set(n for n in [2,3,4,5,7,10,maximum] if n<=maximum))
        splits.append(dict(**{k:v for k,v in split.items() if k not in ['pool','sizes']},pool=pool,sizes=sizes,excluded_zero_homography=[x for x in full if x['sha256'] not in allowed]))
        shutil.copytree(ORIGINAL/'validation'/pose,r.OUT/'validation'/pose,dirs_exist_ok=True)
        for rep in range(3):
            order=np.random.default_rng(20260912+pi*100+rep+10).permutation(len(full))
            ranked=[full[i] for i in order if full[i]['sha256'] in allowed]
            for n in sizes:
                name=f'n{n:02d}_r{rep+1:02d}';selected=ranked[:n];d=r.OUT/'models'/pose/name;cache=d/'.trihedral_correspondence_cache';cache.mkdir(parents=True,exist_ok=True)
                for x in selected:shutil.copy2(x['cache'],cache/Path(x['cache']).name)
                j=dict(pose=pose,name=name,n=n,repeat=rep+1,selected=selected,seed=20260912+pi*100+rep+10)
                r.save(d/'selection.json',j);jobs.append(j)
    protocol={**old,'splits':splits,'jobs':jobs,'selection_policy':'exclude zero usable local homographies, preserve original random-order subsequence; identical validation images; no validation errors used for selection','compared_to':str(ORIGINAL),'unchanged_control':'15_0.528 has no zero-homography image and is not rerun'}
    r.save(r.OUT/'protocol.json',protocol)
    return jobs
if __name__=='__main__':
    if len(sys.argv)>1:r.train(sys.argv[2],sys.argv[3])
    else:
        r.prepare=prepare
        # Original main uses its own __file__ for workers; inherited output env routes them correctly.
        r.main()
