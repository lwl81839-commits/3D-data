#!/usr/bin/env python3
"""Summarize the full136 fast-v2 composite evidence.

The 98 positive targets were already rerun with the current fast-v2 profile.
This script combines those rows with the fresh 38 negative/unusable rows run
under the same profile and compares positive-target RMSE/time against the
frozen round5 baseline.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path
from statistics import mean, median


ROOT = Path(__file__).resolve().parents[1]
POS_CSV = ROOT / "batch_results" / "compute_optimized_20260719" / "positive98_fast_v2_profile_900" / "current_batch_results.csv"
NEG_CSV = ROOT / "batch_results" / "compute_optimized_20260719" / "negative38_fast_v2_profile_900" / "current_batch_results.csv"
BASE_CSV = ROOT / "batch_results" / "full136_round5_fusion_20260718_v1" / "current_batch_results.csv"
OUT_CSV = ROOT / "paper_drafts" / "full136_fast_v2_composite_20260720.csv"
OUT_MD = ROOT / "paper_drafts" / "full136_fast_v2_composite_20260720.md"


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def fnum(row: dict[str, str], key: str) -> float:
    try:
        value = float(row.get(key, ""))
    except ValueError:
        return float("nan")
    return value if math.isfinite(value) else float("nan")


def stats(values: list[float]) -> dict[str, float]:
    vals = sorted(v for v in values if math.isfinite(v))
    if not vals:
        return {"n": 0, "mean": math.nan, "median": math.nan, "p90": math.nan, "max": math.nan, "sum": 0.0}
    p90_idx = min(len(vals) - 1, math.ceil(0.9 * len(vals)) - 1)
    return {
        "n": len(vals),
        "mean": mean(vals),
        "median": median(vals),
        "p90": vals[p90_idx],
        "max": vals[-1],
        "sum": sum(vals),
    }


def counts(rows: list[dict[str, str]], key: str) -> dict[str, int]:
    out: dict[str, int] = {}
    for row in rows:
        value = row.get(key, "") or "(empty)"
        out[value] = out.get(value, 0) + 1
    return dict(sorted(out.items()))


def fmt(x: float, nd: int = 3) -> str:
    return "-" if not math.isfinite(x) else f"{x:.{nd}f}"


def main() -> None:
    pos = read_rows(POS_CSV)
    neg = read_rows(NEG_CSV)
    base = read_rows(BASE_CSV)
    rows = pos + neg
    base_by_rel = {r["rel_path"]: r for r in base}

    for row in rows:
        row["fast_v2_composite_role"] = "positive_target" if row in pos else "negative_or_unusable"

    fieldnames = list(rows[0].keys())
    if "fast_v2_composite_role" not in fieldnames:
        fieldnames.append("fast_v2_composite_role")
    with OUT_CSV.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

    ok_pos = [r for r in pos if r.get("status") == "ok"]
    accepted_neg = [r for r in neg if r.get("status") == "ok"]
    rmse_pos = [fnum(r, "rmse_px") for r in ok_pos]
    wall_pos = [fnum(r, "wall_elapsed_sec") for r in ok_pos]
    wall_neg = [fnum(r, "wall_elapsed_sec") for r in neg]
    wall_all = [fnum(r, "wall_elapsed_sec") for r in rows]

    drift_rows = []
    for r in ok_pos:
        b = base_by_rel.get(r["rel_path"])
        if not b or b.get("status") != "ok":
            continue
        fast_rmse = fnum(r, "rmse_px")
        base_rmse = fnum(b, "rmse_px")
        fast_wall = fnum(r, "wall_elapsed_sec")
        base_wall = fnum(b, "wall_elapsed_sec")
        drift_rows.append({
            "rel_path": r["rel_path"],
            "fast_rmse": fast_rmse,
            "base_rmse": base_rmse,
            "rmse_delta": fast_rmse - base_rmse,
            "fast_wall": fast_wall,
            "base_wall": base_wall,
            "speedup": base_wall / fast_wall if math.isfinite(base_wall) and math.isfinite(fast_wall) and fast_wall > 0 else math.nan,
        })
    abs_drift = [abs(d["rmse_delta"]) for d in drift_rows]
    speedups = [d["speedup"] for d in drift_rows]
    worst_rmse = sorted(drift_rows, key=lambda d: abs(d["rmse_delta"]), reverse=True)[:5]
    slow_neg = sorted(neg, key=lambda r: fnum(r, "wall_elapsed_sec"), reverse=True)[:5]

    pos_stats = stats(rmse_pos)
    wall_pos_stats = stats(wall_pos)
    wall_neg_stats = stats(wall_neg)
    wall_all_stats = stats(wall_all)
    abs_drift_stats = stats(abs_drift)
    speed_stats = stats(speedups)

    lines = [
        "# Full136 Fast V2 Composite Evidence 2026-07-20",
        "",
        "## Scope",
        "",
        "This report combines two runs using the same current `ge2_single_frame_cube_fast` profile and `--square-size-mm 25`: the 98 known positive cube-target images from `positive98_fast_v2_profile_900` and the 38 negative/unusable images from `negative38_fast_v2_profile_900`. It is a composite full136 evidence package, not a single uninterrupted batch wall-clock measurement.",
        "",
        "## Main Result",
        "",
        f"- Total images: {len(rows)}",
        f"- Positive cube targets: {len(pos)}",
        f"- Positive OK: {len(ok_pos)}/{len(pos)}",
        f"- Negative/unusable images: {len(neg)}",
        f"- Negative false accepts: {len(accepted_neg)}/{len(neg)}",
        f"- Overall OK rows: {sum(1 for r in rows if r.get('status') == 'ok')}/{len(rows)}",
        f"- Positive mean RMSE: {fmt(pos_stats['mean'])} px",
        f"- Positive median RMSE: {fmt(pos_stats['median'])} px",
        f"- Positive P90 RMSE: {fmt(pos_stats['p90'])} px",
        f"- Positive max RMSE: {fmt(pos_stats['max'])} px",
        f"- Positive mean wall time: {fmt(wall_pos_stats['mean'])} s",
        f"- Positive median wall time: {fmt(wall_pos_stats['median'])} s",
        f"- Positive P90 wall time: {fmt(wall_pos_stats['p90'])} s",
        f"- Positive max wall time: {fmt(wall_pos_stats['max'])} s",
        f"- Negative mean wall time: {fmt(wall_neg_stats['mean'])} s",
        f"- Negative median wall time: {fmt(wall_neg_stats['median'])} s",
        f"- Negative max wall time: {fmt(wall_neg_stats['max'])} s",
        f"- Composite row wall-time sum: {fmt(wall_all_stats['sum'])} s",
        "",
        "## Status Counts",
        "",
        f"- Composite: `{counts(rows, 'status')}`",
        f"- Positive: `{counts(pos, 'status')}`",
        f"- Negative/unusable: `{counts(neg, 'status')}`",
        "",
        "## Calibration Gate Counts",
        "",
        f"- Positive gates: `{counts(ok_pos, 'calibration_status')}`",
        f"- Negative/unusable gates: `{counts(neg, 'calibration_status')}`",
        "",
        "## RMSE Drift Versus Frozen Baseline",
        "",
        f"- Shared positive OK rows compared: {len(drift_rows)}",
        f"- Mean absolute RMSE drift: {fmt(abs_drift_stats['mean'], 6)} px",
        f"- Median absolute RMSE drift: {fmt(abs_drift_stats['median'], 6)} px",
        f"- P90 absolute RMSE drift: {fmt(abs_drift_stats['p90'], 6)} px",
        f"- Max absolute RMSE drift: {fmt(abs_drift_stats['max'], 6)} px",
        f"- Median row-level speedup over baseline positives: {fmt(speed_stats['median'])}x",
        "",
        "| rel path | baseline RMSE | fast V2 RMSE | delta | baseline wall s | fast wall s | speedup |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for d in worst_rmse:
        lines.append(
            f"| `{d['rel_path']}` | {fmt(d['base_rmse'])} | {fmt(d['fast_rmse'])} | "
            f"{fmt(d['rmse_delta'])} | {fmt(d['base_wall'])} | {fmt(d['fast_wall'])} | {fmt(d['speedup'])} |"
        )
    lines += [
        "",
        "## Slowest Negative/Unusable Rows",
        "",
        "| rel path | status | calibration gate | wall s |",
        "|---|---|---|---:|",
    ]
    for r in slow_neg:
        lines.append(
            f"| `{r['rel_path']}` | `{r.get('status', '')}` | `{r.get('calibration_status', '')}` | {fmt(fnum(r, 'wall_elapsed_sec'))} |"
        )
    lines += [
        "",
        "## Interpretation Boundary",
        "",
        "The composite result supports the deployment-side claim that the current fast-v2 profile preserves 98/98 positive-target calibration and 0/38 negative false acceptance in the frozen full136 image set. Because positives and negatives were run in two separate batches, the row-level wall-time sum and per-row statistics are valid, while a single-batch wall-clock should still be reported if required for strict deployment benchmarking.",
        "",
        f"Combined CSV: `{OUT_CSV.relative_to(ROOT)}`",
    ]
    OUT_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {OUT_CSV}")
    print(f"Wrote {OUT_MD}")


if __name__ == "__main__":
    main()
