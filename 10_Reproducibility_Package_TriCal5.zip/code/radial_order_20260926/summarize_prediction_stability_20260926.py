from pathlib import Path
import numpy as np
from analyze_existing_predictions_20260926 import OUT,read,save,stats
def run():
    summaries=[];lines=['# Corrected prediction-sensitivity screen','','Fixed 12 images per geometry and configuration, selected by filename spacing before evaluation. Five shared splits; poses refitted per model. Differences are held-out pixel prediction differences, not fixed-world ray discrepancies. Include rejected candidates; accepted-only summaries retained in JSON. Not a new blind test.','','|Configuration|Variant|Perturbation|Models|Test|Median prediction-displacement range px|Median actual-RMSE range px|','|---|---|---|---|---|---|---|']
    for f in sorted((OUT/'stability').glob('*/results.json')):
        data=read(f);pose=f.parent.name
        for variant in ['ratio','no_ratio']:
            for group in ['base','noise0.1','noise0.3','omit']:
                models=[p for p in data['parameters'] if p['model'].startswith(variant+'_'+group)]
                for accepted_only in [False,True]:
                    selected=[m for m in models if not accepted_only or m['accepted']]
                    for kind in ['2D','3D']:
                        values=[]
                        for m in selected:
                            rr=[r for r in data['rows'] if r['model']==m['model'] and r['kind']==kind]
                            actual=[r['rmse'] for r in rr if r['rmse'] is not None]
                            disp=[r['displacement_rmse'] for r in rr if r['displacement_rmse'] is not None]
                            values.append(dict(model=m['model'],accepted=m['accepted'],prediction_error=stats(actual),prediction_displacement=stats(disp),success=sum(r['successful_trials'] for r in rr),paired=sum(r['paired_trials'] for r in rr),total=5*len(rr)))
                        summaries.append(dict(pose=pose,variant=variant,group=group,accepted_only=accepted_only,kind=kind,models=values))
                        if accepted_only or not values:continue
                        def span(key):
                            nums=[v[key]['median'] for v in values if v[key]['n']]
                            return f'{min(nums):.4f}--{max(nums):.4f}' if nums else 'NA'
                        lines.append(f'|{pose}|{variant}|{group}|{len(values)}|{kind}|{span("prediction_displacement")}|{span("prediction_error")}|')
    save(OUT/'stability_summary.json',summaries)
    (OUT/'STABILITY_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    print('poses',len(list((OUT/'stability').glob('*/results.json'))),'summary cells',len(summaries))
if __name__=='__main__':run()
