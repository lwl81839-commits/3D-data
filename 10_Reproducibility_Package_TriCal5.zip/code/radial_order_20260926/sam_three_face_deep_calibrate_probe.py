#!/usr/bin/env python3
"""Deep rectified recovery for all three visible cube faces.

Offline probe only. This extends the successful XY rectification idea to the
side faces: candidate face regions are rectified first, then searched for the
physically valid checkerboards. Physical side labels are assigned by board
pattern (9x6 -> XZ, 6x6 -> YZ), then the existing cube calibration stack and
strict small-target gate decide acceptance.
"""

from __future__ import annotations

import argparse
import csv
import json
import time
from itertools import product
from pathlib import Path

import cv2
import numpy as np
import torch
from segment_anything import SamPredictor, sam_model_registry

from best_calibration import (
    MAX_SMALL_TARGET_CORNER_QUALITY_PX,
    MAX_SMALL_TARGET_INITIAL_PNP_RMSE_PX,
    MAX_SMALL_TARGET_RMSE_PX,
    MIN_SMALL_TARGET_CORNERS,
    SMALL_TARGET_MAX_FOV_COVERAGE_PCT,
    SMALL_TARGET_PATTERN_REPAIR_MAX_OFFSET_PNP_RMSE_PX,
    SMALL_TARGET_VALIDATED_ACCEPT_MAX_AREA_PCT,
    SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT,
    calibrate_best,
)
from face_detector import (
    _cluster_dark_components,
    _cube_detection_best_offset_pnp_rmse,
    _cube_detection_geometry_rmse,
    _dedupe_face_candidates,
    _detect_cube_first,
    _detections_have_excessive_overlap,
    _label_cube_clusters,
    _normalize_face_axis_order,
    _rectified_face_variants,
    _score_face_upgrade_candidate,
    estimate_cube_area_pct,
)
from sam_xy_calibrate_probe import (
    TARGET_FACE_PATTERNS,
    load_rel_paths,
    object_corners_array,
    pattern_exact,
)
from sam_xy_deep_probe import expand_box, mask_to_poly, read_image
from three_face_calib import preprocess_image


MAX_RECOVERED_CORNER_OFFSET_PNP_RMSE_PX = min(
    MAX_SMALL_TARGET_INITIAL_PNP_RMSE_PX,
    SMALL_TARGET_PATTERN_REPAIR_MAX_OFFSET_PNP_RMSE_PX,
)
PHYSICAL_LABELS = ("XY", "XZ", "YZ")
LABEL_ORDER = {"XY": 0, "XZ": 1, "YZ": 2}


def strict_failures(result, offset_rmse):
    failures = []
    if result.cube_area_pct is None or not (
        SMALL_TARGET_VALIDATED_ACCEPT_MIN_AREA_PCT
        <= result.cube_area_pct
        <= SMALL_TARGET_VALIDATED_ACCEPT_MAX_AREA_PCT
    ):
        failures.append("area")
    if result.fov_coverage_pct > SMALL_TARGET_MAX_FOV_COVERAGE_PCT:
        failures.append("coverage")
    if result.n_corners < MIN_SMALL_TARGET_CORNERS:
        failures.append("corners")
    if result.corner_quality > MAX_SMALL_TARGET_CORNER_QUALITY_PX:
        failures.append("line_quality")
    if result.rmse > MAX_SMALL_TARGET_RMSE_PX:
        failures.append("rmse")
    if (
        not np.isfinite(offset_rmse)
        or offset_rmse > MAX_RECOVERED_CORNER_OFFSET_PNP_RMSE_PX
    ):
        failures.append("offset_pnp")
    return failures


def candidate_key(corners):
    pts = corners.reshape(-1, 2)
    center = pts.mean(axis=0)
    span = pts.max(axis=0) - pts.min(axis=0)
    return tuple(np.round(np.r_[center, span], 1))


def add_candidate(by_label, corners, pat, physical_label, source):
    score = _score_face_upgrade_candidate(corners, pat, source)
    by_label[physical_label].append((score, corners, pat, physical_label, source))


def add_direct_candidates(gray, by_label):
    direct = _detect_cube_first(gray, n_faces=3, verbose=False)
    for corners, pat, label in direct:
        if label == "XY" and pattern_exact(pat, (9, 6)):
            add_candidate(by_label, corners, pat, "XY", "direct-XY")
        elif label in ("XZ", "YZ") and pattern_exact(pat, (9, 6)):
            add_candidate(by_label, corners, pat, "XZ", f"direct-{label}->XZ")
        elif label in ("XZ", "YZ") and pattern_exact(pat, (6, 6)):
            add_candidate(by_label, corners, pat, "YZ", f"direct-{label}->YZ")
    return direct


def try_rectified_patterns(gray, poly, patterns, source):
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    attempts = []
    seen = set()
    for idx, (rectified, h_inv) in enumerate(_rectified_face_variants(gray, poly)):
        variants = [
            ("pre", preprocess_image(rectified)),
            ("eq", cv2.equalizeHist(rectified)),
            ("raw", rectified),
        ]
        for variant_name, work in variants:
            for pat in patterns:
                if pat in seen and pat == (6, 6):
                    pass
                t0 = time.time()
                ok, corners = cv2.findChessboardCorners(work, pat, flags=flags)
                attempts.append((source, f"rect{idx}-{variant_name}", pat, ok, time.time() - t0))
                if ok and corners is not None:
                    mapped = cv2.perspectiveTransform(corners.astype(np.float32), h_inv)
                    return {
                        "found": True,
                        "source": source,
                        "method": f"rect{idx}-{variant_name}-classic",
                        "pattern": pat,
                        "corners": mapped.reshape(-1, 1, 2),
                        "attempts": attempts,
                    }
                if hasattr(cv2, "findChessboardCornersSB"):
                    t0 = time.time()
                    ok, corners = cv2.findChessboardCornersSB(
                        work, pat, flags=cv2.CALIB_CB_NORMALIZE_IMAGE)
                    attempts.append((source, f"rect{idx}-{variant_name}", pat, ok, time.time() - t0))
                    if ok and corners is not None:
                        mapped = cv2.perspectiveTransform(corners.astype(np.float32), h_inv)
                        return {
                            "found": True,
                            "source": source,
                            "method": f"rect{idx}-{variant_name}-SB",
                            "pattern": pat,
                            "corners": mapped.reshape(-1, 1, 2),
                            "attempts": attempts,
                        }
        seen.update(patterns)
    return {"found": False, "attempts": attempts}


def physical_label_for_result(result, image_label):
    pat = result["pattern"]
    if image_label == "XY" and pattern_exact(pat, (9, 6)):
        return "XY"
    if image_label in ("XZ", "YZ") and pattern_exact(pat, (9, 6)):
        return "XZ"
    if image_label in ("XZ", "YZ") and pattern_exact(pat, (6, 6)):
        return "YZ"
    return None


def needed_patterns_for_image_label(image_label, by_label):
    patterns = []
    if image_label == "XY" and not by_label["XY"]:
        patterns.extend([(9, 6), (6, 9)])
    if image_label in ("XZ", "YZ"):
        if not by_label["XZ"]:
            patterns.extend([(9, 6), (6, 9)])
        if not by_label["YZ"]:
            patterns.append((6, 6))
    return patterns


def recover_needed_candidates(image, gray, predictor, by_label):
    clusters = _label_cube_clusters(
        _cluster_dark_components(gray, n_faces=3, verbose=False))
    rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    predictor.set_image(rgb)

    recovered = []
    attempts_total = 0
    for face in clusters:
        image_label = face.get("label")
        if image_label not in PHYSICAL_LABELS:
            continue
        patterns = needed_patterns_for_image_label(image_label, by_label)
        if not patterns:
            continue

        base_poly = np.asarray(face["poly"], dtype=np.float32)
        polys = [(f"{image_label}-cluster", base_poly)]
        for scale in (1.18, 1.42):
            box = expand_box(base_poly, gray.shape, scale)
            masks, scores, _ = predictor.predict(box=box, multimask_output=True)
            ranked = sorted(
                enumerate(zip(masks, scores)),
                key=lambda item: float(item[1][1]),
                reverse=True,
            )[:2]
            for mask_idx, (mask, score) in ranked:
                poly = mask_to_poly(mask)
                if poly is not None:
                    polys.append((
                        f"{image_label}-sam{mask_idx}-s{scale:.2f}-{float(score):.3f}",
                        poly,
                    ))

        for source, poly in polys:
            patterns = needed_patterns_for_image_label(image_label, by_label)
            if not patterns:
                break
            result = try_rectified_patterns(gray, poly, patterns, source)
            attempts_total += len(result.get("attempts", []))
            if not result.get("found"):
                continue
            physical_label = physical_label_for_result(result, image_label)
            if physical_label is None:
                continue
            corners = np.asarray(result["corners"], dtype=np.float32).reshape(-1, 1, 2)
            key = candidate_key(corners)
            existing = {
                candidate_key(c)
                for _s, c, _p, _l, _src in by_label[physical_label]
            }
            if key not in existing:
                add_candidate(
                    by_label,
                    corners,
                    result["pattern"],
                    physical_label,
                    f"{result['source']}:{result['method']}",
                )
                recovered.append({
                    "image_label": image_label,
                    "physical_label": physical_label,
                    "pattern": f"{result['pattern'][0]}x{result['pattern'][1]}",
                    "source": result["source"],
                    "method": result["method"],
                })
            if not needed_patterns_for_image_label(image_label, by_label):
                break

    for label in PHYSICAL_LABELS:
        by_label[label] = _dedupe_face_candidates(by_label[label])[:8]
    return recovered, attempts_total


def choose_combo(by_label, image_shape):
    if any(not by_label[label] for label in PHYSICAL_LABELS):
        return None
    best = None
    for xy, xz, yz in product(by_label["XY"], by_label["XZ"], by_label["YZ"]):
        raw = [xy, xz, yz]
        dets = [(c, p, l) for _s, c, p, l, _src in raw]
        if _detections_have_excessive_overlap(dets, threshold=0.80):
            continue
        dets = _normalize_face_axis_order(dets)
        centered = _cube_detection_geometry_rmse(
            dets, image_shape, n_faces=3, allow_sparse=False,
            assume_normalized=True)
        offset_rmse, offset, offset_dist = _cube_detection_best_offset_pnp_rmse(
            dets, image_shape, n_faces=3, assume_normalized=True)
        if not (np.isfinite(centered) and np.isfinite(offset_rmse)):
            continue
        score = (
            float(offset_rmse)
            + 0.10 * float(centered)
            + 0.05 * float(offset_dist)
            + 0.005 * sum(float(s) for s, _c, _p, _l, _src in raw)
        )
        if best is None or score < best["score"]:
            best = {
                "score": score,
                "dets": dets,
                "centered_pnp": float(centered),
                "offset_pnp": float(offset_rmse),
                "offset": offset,
                "offset_dist": float(offset_dist),
                "sources": ";".join(src for _s, _c, _p, _l, src in raw),
            }
    return best


def save_overlay(image, rel, dets, out_dir):
    colors = {"XY": (0, 220, 255), "XZ": (0, 180, 0), "YZ": (255, 80, 0)}
    vis = image.copy()
    for corners, pat, label in dets:
        color = colors.get(label, (255, 255, 255))
        pts = corners.reshape(-1, 2)
        for x, y in pts:
            cv2.circle(vis, (int(round(x)), int(round(y))), 2, color, -1)
        x1, y1 = np.floor(pts.min(axis=0)).astype(int)
        x2, y2 = np.ceil(pts.max(axis=0)).astype(int)
        cv2.rectangle(vis, (x1, y1), (x2, y2), color, 2)
        cv2.putText(
            vis, f"{label} {pat[0]}x{pat[1]}",
            (x1, max(20, y1 - 6)),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2,
        )
    out_dir.mkdir(parents=True, exist_ok=True)
    out_name = rel.replace("/", "__").replace("\\", "__")
    cv2.imwrite(str(out_dir / f"{out_name}.jpg"), vis)


def probe_one(image_root: Path, rel: str, predictor: SamPredictor, out_dir: Path):
    image_path = image_root / rel
    image = read_image(image_path)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    cube_area = float(estimate_cube_area_pct(gray, n_faces=3))
    by_label = {"XY": [], "XZ": [], "YZ": []}
    direct = add_direct_candidates(gray, by_label)
    direct_desc = ";".join(f"{label}:{pat[0]}x{pat[1]}" for _c, pat, label in direct)

    recovered, attempts_total = recover_needed_candidates(image, gray, predictor, by_label)
    best = choose_combo(by_label, gray.shape)
    if best is None:
        return {
            "rel_path": rel,
            "status": "no_combo",
            "cube_area_pct": cube_area,
            "direct": direct_desc,
            "xy_candidates": len(by_label["XY"]),
            "xz_candidates": len(by_label["XZ"]),
            "yz_candidates": len(by_label["YZ"]),
            "recovered": json.dumps(recovered, ensure_ascii=False),
            "attempts": attempts_total,
        }

    corners_dir = out_dir / "corners"
    corners_dir.mkdir(parents=True, exist_ok=True)
    stem = rel.replace("/", "__").replace("\\", "__").rsplit(".", 1)[0]
    corners_path = corners_dir / f"{stem}_sam_three_face_deep.npz"
    np.savez(corners_path, corners=object_corners_array(best["dets"]))
    save_overlay(image, rel, best["dets"], out_dir / "overlays")

    try:
        result = calibrate_best(
            str(image_path),
            25.0,
            face_patterns=TARGET_FACE_PATTERNS,
            corners_path=str(corners_path),
            verbose=False,
        )
        failures = strict_failures(result, best["offset_pnp"])
        return {
            "rel_path": rel,
            "status": "calibrated",
            "strict_like": "pass" if not failures else "fail:" + ",".join(failures),
            "cube_area_pct": result.cube_area_pct,
            "fov_coverage_pct": result.fov_coverage_pct,
            "n_corners": result.n_corners,
            "corner_quality": result.corner_quality,
            "rmse_px": result.rmse,
            "fx_px": result.fx_px,
            "fy_px": result.fy_px,
            "cx_px": result.cx_px,
            "cy_px": result.cy_px,
            "model": result.model_used,
            "centered_pnp": best["centered_pnp"],
            "offset_pnp": best["offset_pnp"],
            "offset": str(best["offset"]),
            "offset_dist": best["offset_dist"],
            "direct": direct_desc,
            "sources": best["sources"],
            "recovered": json.dumps(recovered, ensure_ascii=False),
            "attempts": attempts_total,
            "corners_path": str(corners_path),
            "warnings": " | ".join(result.warnings or []),
        }
    except Exception as exc:
        return {
            "rel_path": rel,
            "status": "calibration_error",
            "error": str(exc),
            "cube_area_pct": cube_area,
            "direct": direct_desc,
            "centered_pnp": best["centered_pnp"],
            "offset_pnp": best["offset_pnp"],
            "sources": best["sources"],
            "recovered": json.dumps(recovered, ensure_ascii=False),
            "corners_path": str(corners_path),
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--rel-list", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--model-type", default="vit_b")
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    sam = sam_model_registry[args.model_type](checkpoint=str(args.checkpoint))
    sam.to(device=device)
    predictor = SamPredictor(sam)

    rows = []
    for rel in load_rel_paths(args.rel_list):
        print(f"START {rel}", flush=True)
        try:
            row = probe_one(args.image_root, rel, predictor, args.out_dir)
        except Exception as exc:
            row = {"rel_path": rel, "status": "error", "error": str(exc)}
        print(json.dumps(row, ensure_ascii=False), flush=True)
        rows.append(row)

    (args.out_dir / "sam_three_face_deep_results.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    accepted = [
        {
            "rel_path": row["rel_path"],
            "corners_path": row.get("corners_path"),
            "face_patterns": TARGET_FACE_PATTERNS,
            "model": row.get("model"),
            "cube_area_pct": row.get("cube_area_pct"),
            "fov_coverage_pct": row.get("fov_coverage_pct"),
            "n_corners": row.get("n_corners"),
            "corner_quality": row.get("corner_quality"),
            "rmse_px": row.get("rmse_px"),
            "fx_px": row.get("fx_px"),
            "fy_px": row.get("fy_px"),
            "offset_pnp": row.get("offset_pnp"),
            "sources": row.get("sources"),
            "recovered": row.get("recovered"),
        }
        for row in rows
        if row.get("status") == "calibrated"
        and row.get("strict_like") == "pass"
    ]
    (args.out_dir / "sam_three_face_deep_manifest.json").write_text(
        json.dumps({
            "face_patterns": TARGET_FACE_PATTERNS,
            "accepted_count": len(accepted),
            "accepted": accepted,
        }, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    fields = sorted({key for row in rows for key in row})
    with (args.out_dir / "sam_three_face_deep_results.csv").open(
        "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
