from __future__ import annotations

import argparse
import csv
import json
import math
import os
import random
import statistics
import subprocess
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
BASELINE_CSV = (
    ROOT
    / "batch_results"
    / "full136_round5_fusion_20260718_v1"
    / "current_batch_results.csv"
)
IMAGE_ROOT = ROOT / "材料_extracted" / "shengkelou"
RESULT_ROOT = ROOT / "batch_results" / "train_test_split_70_30_20260719"
PAPER_ROOT = ROOT / "paper_drafts"

SPLIT_CSV = PAPER_ROOT / "train_test_split_70_30_20260719.csv"
TRAIN_REL_PATHS = PAPER_ROOT / "train_relpaths_70_30_20260719.txt"
TEST_REL_PATHS = PAPER_ROOT / "test_relpaths_70_30_20260719.txt"
SUMMARY_CSV = PAPER_ROOT / "train_test_split_summary_70_30_20260719.csv"
MATRIX_CSV = PAPER_ROOT / "train_test_split_matrix_70_30_20260719.csv"
REPORT_PATH = PAPER_ROOT / "train_test_split_70_30_20260719.md"
TIMEOUT_VERIFY_CSV = (
    RESULT_ROOT
    / "test_timeout_verify_no_stability"
    / "current_batch_results.csv"
)

UNUSABLE_KEYS = {
    ("15.2_0.986", "t_5_14.jpg"),
    ("20_0.840", "t_3_00.jpg"),
}

AREA_BINS = ["<2%", "2-3%", "3-6%", "6-10%", ">=10%", "unknown"]
RUN_DEFINITIONS = [
    {
        "name": "train_current",
        "split": "train",
        "label": "训练集：当前冻结配置",
        "extra_args": [],
        "leakage_note": "使用当前冻结稳定清单；用于复跑一致性，不作为独立泛化证据。",
    },
    {
        "name": "test_current",
        "split": "test",
        "label": "测试集：当前冻结配置",
        "extra_args": [],
        "leakage_note": "使用当前冻结稳定清单；测试侧会命中冻结清单，不能单独作为无泄漏泛化结论。",
    },
    {
        "name": "test_no_stability",
        "split": "test",
        "label": "测试集：禁用稳定清单",
        "extra_args": ["--ablation-disable-stability-manifest"],
        "leakage_note": "禁用稳定清单；用于检查测试侧无泄漏边界。",
    },
]


def fnum(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def fmt(value: float | None, digits: int = 3) -> str:
    if value is None or (isinstance(value, float) and not math.isfinite(value)):
        return "-"
    return f"{value:.{digits}f}"


def pct(num: int, den: int) -> str:
    if den <= 0:
        return "-"
    return f"{100.0 * num / den:.1f}%"


def rel(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(ROOT.resolve()))
    except ValueError:
        return str(path)


def normalize_rel_path(value: str) -> str:
    return str(value or "").replace("\\", "/")


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as fp:
        return list(csv.DictReader(fp))


def write_csv_rows(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.DictWriter(fp, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def row_kind(row: dict[str, str]) -> str:
    group = row.get("group", "")
    image = row.get("image", "")
    if group == "zhang":
        return "negative_zhang"
    if (group, image) in UNUSABLE_KEYS:
        return "negative_unusable"
    return "real_target"


def area_bin(row: dict[str, str]) -> str:
    area = fnum(row.get("cube_area_pct"))
    if area is None:
        return "unknown"
    if area < 2.0:
        return "<2%"
    if area < 3.0:
        return "2-3%"
    if area < 6.0:
        return "3-6%"
    if area < 10.0:
        return "6-10%"
    return ">=10%"


def split_stratum(row: dict[str, str]) -> str:
    kind = row_kind(row)
    group = row.get("group", "")
    if kind == "real_target":
        return f"real|{group}|{area_bin(row)}"
    if kind == "negative_zhang":
        return "negative|zhang"
    return f"negative|unusable|{group}"


def baseline_rel_path(row: dict[str, str]) -> str:
    rel_path = normalize_rel_path(row.get("rel_path", ""))
    if rel_path:
        return rel_path
    return normalize_rel_path(f"{row.get('group', '')}/{row.get('image', '')}")


def apportion_train_counts(
    strata: dict[str, list[dict[str, Any]]],
    target_train: int,
) -> dict[str, int]:
    total = sum(len(rows) for rows in strata.values())
    if total <= 0:
        return {key: 0 for key in strata}
    target_train = max(0, min(target_train, total))
    quota_rows: list[tuple[str, int, float, float]] = []
    floors: dict[str, int] = {}
    for key, rows in strata.items():
        quota = len(rows) * target_train / total
        floor = int(math.floor(quota))
        floors[key] = floor
        quota_rows.append((key, len(rows), quota, quota - floor))
    remaining = target_train - sum(floors.values())
    for key, _size, _quota, _rem in sorted(
        quota_rows,
        key=lambda item: (-item[3], -item[1], item[0]),
    )[:remaining]:
        floors[key] += 1
    return floors


def split_group(
    rows: list[dict[str, Any]],
    target_train: int,
    rng: random.Random,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    strata: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        strata[row["stratum"]].append(row)
    train_counts = apportion_train_counts(strata, target_train)
    train_rows: list[dict[str, Any]] = []
    test_rows: list[dict[str, Any]] = []
    for key in sorted(strata):
        shuffled = list(strata[key])
        rng.shuffle(shuffled)
        n_train = train_counts.get(key, 0)
        train_rows.extend(shuffled[:n_train])
        test_rows.extend(shuffled[n_train:])
    return train_rows, test_rows


def build_split(seed: int, train_ratio: float) -> list[dict[str, Any]]:
    baseline = read_csv_rows(BASELINE_CSV)
    prepared: list[dict[str, Any]] = []
    for idx, row in enumerate(baseline, 1):
        kind = row_kind(row)
        ab = area_bin(row)
        prepared.append(
            {
                **row,
                "baseline_order": idx,
                "rel_path": baseline_rel_path(row),
                "kind": kind,
                "area_bin": ab,
                "stratum": split_stratum(row),
            }
        )

    by_kind: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in prepared:
        by_kind[row["kind"]].append(row)

    rng = random.Random(seed)
    train_rows: list[dict[str, Any]] = []
    test_rows: list[dict[str, Any]] = []
    for kind in sorted(by_kind):
        rows = by_kind[kind]
        target_train = int(round(len(rows) * train_ratio))
        group_train, group_test = split_group(rows, target_train, rng)
        train_rows.extend(group_train)
        test_rows.extend(group_test)

    for row in train_rows:
        row["split"] = "train"
    for row in test_rows:
        row["split"] = "test"

    split_rows = sorted(train_rows + test_rows, key=lambda row: int(row["baseline_order"]))
    for idx, row in enumerate(split_rows, 1):
        row["split_order"] = idx
    return split_rows


def write_split_artifacts(split_rows: list[dict[str, Any]]) -> None:
    fields = [
        "split_order",
        "baseline_order",
        "split",
        "kind",
        "stratum",
        "area_bin",
        "rel_path",
        "group",
        "image",
        "status",
        "model_grade",
        "calibration_status",
        "cube_area_pct",
        "rmse_px",
        "wall_elapsed_sec",
        "warnings",
    ]
    write_csv_rows(SPLIT_CSV, fields, split_rows)
    for split, path in [("train", TRAIN_REL_PATHS), ("test", TEST_REL_PATHS)]:
        rels = [
            row["rel_path"]
            for row in sorted(split_rows, key=lambda item: int(item["baseline_order"]))
            if row["split"] == split
        ]
        path.write_text("\n".join(rels) + "\n", encoding="utf-8")


def result_csv_for_run(name: str) -> Path:
    return RESULT_ROOT / name / "current_batch_results.csv"


def rel_file_for_split(split: str) -> Path:
    if split == "train":
        return TRAIN_REL_PATHS
    if split == "test":
        return TEST_REL_PATHS
    raise ValueError(f"Unknown split: {split}")


def run_batch(run_def: dict[str, Any], workers: int, timeout: float) -> None:
    out_dir = RESULT_ROOT / run_def["name"]
    out_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable,
        "-u",
        "-X",
        "utf8",
        "batch_evaluate_current.py",
        "--method-profile",
        "ge2_single_frame_cube",
        "--image-root",
        str(IMAGE_ROOT),
        "--out-dir",
        str(out_dir),
        "--workers",
        str(int(workers)),
        "--mode",
        "subprocess",
        "--per-image-timeout",
        str(float(timeout)),
        "--rel-path-file",
        str(rel_file_for_split(run_def["split"])),
        "--grid-recovery-out-dir",
        str(out_dir / "grid_recovery"),
    ]
    cmd.extend(run_def.get("extra_args", []))
    (out_dir / "command.json").write_text(
        json.dumps(
            {
                "cmd": cmd,
                "label": run_def["label"],
                "leakage_note": run_def["leakage_note"],
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    with (out_dir / "run_stdout.log").open("w", encoding="utf-8") as stdout, (
        out_dir / "run_stderr.log"
    ).open("w", encoding="utf-8") as stderr:
        subprocess.run(
            cmd,
            cwd=ROOT,
            check=True,
            text=True,
            stdout=stdout,
            stderr=stderr,
            env=env,
        )


def run_definitions(include_no_stability_test: bool) -> list[dict[str, Any]]:
    if include_no_stability_test:
        return list(RUN_DEFINITIONS)
    return [item for item in RUN_DEFINITIONS if item["name"] != "test_no_stability"]


def load_result_rows(run_name: str) -> dict[str, dict[str, str]]:
    path = result_csv_for_run(run_name)
    if not path.exists():
        return {}
    return {normalize_rel_path(row.get("rel_path", "")): row for row in read_csv_rows(path)}


def enriched_records(
    split_rows: list[dict[str, Any]],
    run_def: dict[str, Any],
) -> list[dict[str, Any]]:
    result_by_rel = load_result_rows(run_def["name"])
    expected = [row for row in split_rows if row["split"] == run_def["split"]]
    records: list[dict[str, Any]] = []
    for base in expected:
        result = result_by_rel.get(base["rel_path"])
        if result is None:
            merged = {
                **base,
                "run_name": run_def["name"],
                "run_label": run_def["label"],
                "run_status": "missing",
                "run_calibration_status": "",
                "run_model_grade": "",
                "run_rmse_px": "",
                "run_wall_elapsed_sec": "",
                "run_error": "missing result row",
            }
        else:
            merged = {
                **base,
                "run_name": run_def["name"],
                "run_label": run_def["label"],
                "run_status": result.get("status", ""),
                "run_calibration_status": result.get("calibration_status", ""),
                "run_model_grade": result.get("model_grade", ""),
                "run_rmse_px": result.get("rmse_px", ""),
                "run_wall_elapsed_sec": result.get("wall_elapsed_sec", ""),
                "run_error": result.get("error", ""),
                "run_router_stage": result.get("router_stage", ""),
                "run_grid_recovery_stage": result.get("grid_recovery_stage", ""),
                "run_grid_recovery_route": result.get("grid_recovery_route", ""),
                "run_cube_area_pct": result.get("cube_area_pct", ""),
            }
        records.append(merged)
    return records


def summarize_records(records: list[dict[str, Any]], run_def: dict[str, Any]) -> dict[str, Any]:
    real = [row for row in records if row["kind"] == "real_target"]
    negative = [row for row in records if row["kind"].startswith("negative")]
    real_ge2 = [
        row
        for row in real
        if (fnum(row.get("cube_area_pct")) is None or fnum(row.get("cube_area_pct")) >= 2.0)
    ]
    real_ok = [row for row in real if row.get("run_status") == "ok"]
    real_ge2_ok = [row for row in real_ge2 if row.get("run_status") == "ok"]
    negative_ok = [row for row in negative if row.get("run_status") == "ok"]
    rmses = [v for v in (fnum(row.get("run_rmse_px")) for row in real_ok) if v is not None]
    walls = [
        v for v in (fnum(row.get("run_wall_elapsed_sec")) for row in records) if v is not None
    ]
    return {
        "run_name": run_def["name"],
        "split": run_def["split"],
        "label": run_def["label"],
        "leakage_note": run_def["leakage_note"],
        "expected": len(records),
        "completed": sum(1 for row in records if row.get("run_status") != "missing"),
        "real": len(real),
        "real_ok": len(real_ok),
        "real_ok_rate": pct(len(real_ok), len(real)),
        "real_ge2": len(real_ge2),
        "real_ge2_ok": len(real_ge2_ok),
        "real_ge2_ok_rate": pct(len(real_ge2_ok), len(real_ge2)),
        "negative": len(negative),
        "negative_false_accepts": len(negative_ok),
        "negative_false_accept_rate": pct(len(negative_ok), len(negative)),
        "timeouts": sum(1 for row in records if row.get("run_status") == "timeout"),
        "missing": sum(1 for row in records if row.get("run_status") == "missing"),
        "mean_real_rmse_px": statistics.fmean(rmses) if rmses else None,
        "median_real_rmse_px": statistics.median(rmses) if rmses else None,
        "mean_wall_sec": statistics.fmean(walls) if walls else None,
        "median_wall_sec": statistics.median(walls) if walls else None,
        "status_counts": dict(Counter(row.get("run_status") or "" for row in records)),
        "calibration_counts": dict(
            Counter(row.get("run_calibration_status") or "" for row in records)
        ),
        "model_grade_counts": dict(
            Counter(row.get("run_model_grade") or "" for row in records if row.get("run_model_grade"))
        ),
    }


def area_summary(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    real = [row for row in records if row["kind"] == "real_target"]
    for ab in AREA_BINS:
        subset = [row for row in real if row["area_bin"] == ab]
        if not subset:
            continue
        ok_rows = [row for row in subset if row.get("run_status") == "ok"]
        rmses = [v for v in (fnum(row.get("run_rmse_px")) for row in ok_rows) if v is not None]
        walls = [
            v
            for v in (fnum(row.get("run_wall_elapsed_sec")) for row in subset)
            if v is not None
        ]
        rows.append(
            {
                "area_bin": ab,
                "n": len(subset),
                "ok": len(ok_rows),
                "ok_rate": pct(len(ok_rows), len(subset)),
                "mean_rmse_px": statistics.fmean(rmses) if rmses else None,
                "median_wall_sec": statistics.median(walls) if walls else None,
                "status_counts": dict(Counter(row.get("run_status") or "" for row in subset)),
            }
        )
    return rows


def write_summary_csv(summaries: list[dict[str, Any]]) -> None:
    fields = [
        "run_name",
        "split",
        "expected",
        "completed",
        "real",
        "real_ok",
        "real_ok_rate",
        "real_ge2",
        "real_ge2_ok",
        "real_ge2_ok_rate",
        "negative",
        "negative_false_accepts",
        "negative_false_accept_rate",
        "timeouts",
        "missing",
        "mean_real_rmse_px",
        "median_real_rmse_px",
        "mean_wall_sec",
        "median_wall_sec",
        "status_counts",
        "calibration_counts",
        "model_grade_counts",
        "leakage_note",
    ]
    rows = []
    for summary in summaries:
        out = dict(summary)
        for key in ["status_counts", "calibration_counts", "model_grade_counts"]:
            out[key] = json.dumps(out.get(key, {}), ensure_ascii=False, sort_keys=True)
        rows.append(out)
    write_csv_rows(SUMMARY_CSV, fields, rows)


def write_matrix_csv(all_records: list[dict[str, Any]]) -> None:
    fields = [
        "run_name",
        "split",
        "kind",
        "area_bin",
        "stratum",
        "rel_path",
        "group",
        "image",
        "baseline_status",
        "baseline_rmse_px",
        "baseline_wall_elapsed_sec",
        "run_status",
        "run_calibration_status",
        "run_model_grade",
        "run_rmse_px",
        "run_wall_elapsed_sec",
        "run_router_stage",
        "run_grid_recovery_stage",
        "run_grid_recovery_route",
        "run_error",
    ]
    rows = []
    for row in all_records:
        out = dict(row)
        out["baseline_status"] = row.get("status", "")
        out["baseline_rmse_px"] = row.get("rmse_px", "")
        out["baseline_wall_elapsed_sec"] = row.get("wall_elapsed_sec", "")
        rows.append(out)
    write_csv_rows(MATRIX_CSV, fields, rows)


def split_distribution(split_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for split in ["train", "test"]:
        subset = [row for row in split_rows if row["split"] == split]
        for kind in ["real_target", "negative_zhang", "negative_unusable"]:
            kind_rows = [row for row in subset if row["kind"] == kind]
            if not kind_rows:
                continue
            rows.append(
                {
                    "split": split,
                    "kind": kind,
                    "n": len(kind_rows),
                    "area_counts": dict(Counter(row["area_bin"] for row in kind_rows)),
                    "group_counts": dict(Counter(row["group"] for row in kind_rows)),
                }
            )
    return rows


def write_report(
    split_rows: list[dict[str, Any]],
    run_defs: list[dict[str, Any]],
    summaries: list[dict[str, Any]],
    all_records: list[dict[str, Any]],
    workers: int,
    timeout: float,
    seed: int,
    train_ratio: float,
) -> None:
    by_run = {summary["run_name"]: summary for summary in summaries}
    records_by_run: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in all_records:
        records_by_run[row["run_name"]].append(row)
    original_by_run_rel = {
        (row["run_name"], row["rel_path"]): row
        for row in all_records
    }
    split_by_rel = {row["rel_path"]: row for row in split_rows}

    lines = [
        "# 7:3 train/test rerun (2026-07-19)",
        "",
        "## 口径",
        "",
        f"本轮按固定随机种子 `{seed}` 和训练比例 `{train_ratio:.2f}` 重建 7:3 划分，总样本为冻结 136 张图像。划分时先按物理角色区分真实三面立方体目标、平面 Zhang 负样本和两张不可用/无目标负样本；真实目标再按组别与面积段分层。",
        "",
        f"批处理入口为 `batch_evaluate_current.py --method-profile ge2_single_frame_cube`，workers={workers}，单图 timeout={timeout:.1f}s。当前冻结配置复跑用于检查可重复性；测试集禁用稳定清单的结果用于检查无泄漏边界。",
        "",
        "## 数据划分",
        "",
        "| split | kind | n | area counts | group counts |",
        "|---|---|---:|---|---|",
    ]
    for row in split_distribution(split_rows):
        lines.append(
            f"| {row['split']} | {row['kind']} | {row['n']} | "
            f"`{json.dumps(row['area_counts'], ensure_ascii=False, sort_keys=True)}` | "
            f"`{json.dumps(row['group_counts'], ensure_ascii=False, sort_keys=True)}` |"
        )

    lines.extend(
        [
            "",
            "## 复跑结果",
            "",
            "| run | split | completed | real ok | real >=2% ok | negative false accepts | timeouts | mean RMSE px | median RMSE px | median wall s | note |",
            "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---|",
        ]
    )
    for run_def in run_defs:
        summary = by_run.get(run_def["name"])
        if not summary:
            continue
        lines.append(
            f"| {run_def['name']} | {summary['split']} | "
            f"{summary['completed']}/{summary['expected']} | "
            f"{summary['real_ok']}/{summary['real']} ({summary['real_ok_rate']}) | "
            f"{summary['real_ge2_ok']}/{summary['real_ge2']} ({summary['real_ge2_ok_rate']}) | "
            f"{summary['negative_false_accepts']}/{summary['negative']} ({summary['negative_false_accept_rate']}) | "
            f"{summary['timeouts']} | {fmt(summary['mean_real_rmse_px'])} | "
            f"{fmt(summary['median_real_rmse_px'])} | {fmt(summary['median_wall_sec'])} | "
            f"{summary['leakage_note']} |"
        )

    if TIMEOUT_VERIFY_CSV.exists():
        verify_rows = read_csv_rows(TIMEOUT_VERIFY_CSV)
        lines.extend(
            [
                "",
                "## Timeout 复核",
                "",
                "对 900 秒主测试中真实目标超时的样本，使用相同 `ge2_single_frame_cube` 方法、禁用稳定清单、低并发 workers=3、单图 timeout=1800s 复跑。该复核只改变运行资源上限，不改变标定算法和物理约束。",
                "",
                "| rel path | area bin | current 900s | no-stability 900s | verify status | calibration | model | RMSE px | wall s |",
                "|---|---|---|---|---|---|---|---:|---:|",
            ]
        )
        for row in verify_rows:
            rel_path = normalize_rel_path(row.get("rel_path", ""))
            split_meta = split_by_rel.get(rel_path, {})
            current = original_by_run_rel.get(("test_current", rel_path), {})
            no_stability = original_by_run_rel.get(("test_no_stability", rel_path), {})
            lines.append(
                f"| `{rel_path}` | {split_meta.get('area_bin', '')} | "
                f"{current.get('run_status', '-') or '-'} | "
                f"{no_stability.get('run_status', '-') or '-'} | "
                f"{row.get('status', '')} | {row.get('calibration_status', '')} | "
                f"{row.get('model_grade', '')} | {fmt(fnum(row.get('rmse_px')))} | "
                f"{fmt(fnum(row.get('wall_elapsed_sec')))} |"
            )
        ok_verify = sum(1 for row in verify_rows if row.get("status") == "ok")
        max_wall = max(
            [v for v in (fnum(row.get("wall_elapsed_sec")) for row in verify_rows) if v is not None],
            default=None,
        )
        lines.extend(
            [
                "",
                f"复核结果为 {ok_verify}/{len(verify_rows)} 通过，最长耗时 {fmt(max_wall)}s。因此，这三个样本不应归因为几何不可标定；它们暴露的是 900 秒运行上限和候选调度效率问题。若论文声明“快速标定”，必须以 900 秒主结果为边界；若声明“可标定性”，则可引用 1800 秒复核作为补充证据。",
            ]
        )

    lines.extend(["", "## 面积分段", ""])
    for run_def in run_defs:
        records = records_by_run.get(run_def["name"], [])
        if not records:
            continue
        lines.extend(
            [
                f"### {run_def['name']}",
                "",
                "| area bin | n | ok | ok rate | mean RMSE px | median wall s | status counts |",
                "|---|---:|---:|---:|---:|---:|---|",
            ]
        )
        for row in area_summary(records):
            lines.append(
                f"| {row['area_bin']} | {row['n']} | {row['ok']} | {row['ok_rate']} | "
                f"{fmt(row['mean_rmse_px'])} | {fmt(row['median_wall_sec'])} | "
                f"`{json.dumps(row['status_counts'], ensure_ascii=False, sort_keys=True)}` |"
            )
        lines.append("")

    lines.extend(
        [
            "## 状态统计",
            "",
            "| run | status counts | calibration counts | model grade counts |",
            "|---|---|---|---|",
        ]
    )
    for run_def in run_defs:
        summary = by_run.get(run_def["name"])
        if not summary:
            continue
        lines.append(
            f"| {run_def['name']} | "
            f"`{json.dumps(summary['status_counts'], ensure_ascii=False, sort_keys=True)}` | "
            f"`{json.dumps(summary['calibration_counts'], ensure_ascii=False, sort_keys=True)}` | "
            f"`{json.dumps(summary['model_grade_counts'], ensure_ascii=False, sort_keys=True)}` |"
        )

    lines.extend(
        [
            "",
            "## 输出文件",
            "",
            f"- Split CSV: `{rel(SPLIT_CSV)}`",
            f"- Train rel paths: `{rel(TRAIN_REL_PATHS)}`",
            f"- Test rel paths: `{rel(TEST_REL_PATHS)}`",
            f"- Summary CSV: `{rel(SUMMARY_CSV)}`",
            f"- Matrix CSV: `{rel(MATRIX_CSV)}`",
            f"- Result root: `{rel(RESULT_ROOT)}`",
            "",
            "## 结论边界",
            "",
            "当前冻结配置下的 train/test 复跑只能说明冻结流程在新划分上的复现情况。若测试集仍使用全量稳定清单，则它不是严格的泛化测试；禁用稳定清单的测试结果才可作为无泄漏边界证据。若后续要把稳定清单也作为训练产物，应只用训练集重建清单，再在测试集上评估。",
            "",
        ]
    )
    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")


def run_and_summarize(args: argparse.Namespace) -> None:
    if not BASELINE_CSV.exists():
        raise FileNotFoundError(BASELINE_CSV)
    if not IMAGE_ROOT.exists():
        raise FileNotFoundError(IMAGE_ROOT)

    split_rows = build_split(seed=args.seed, train_ratio=args.train_ratio)
    write_split_artifacts(split_rows)

    include_no_stability = not args.skip_no_stability_test
    run_defs = run_definitions(include_no_stability)

    if not args.skip_run and not args.split_only:
        RESULT_ROOT.mkdir(parents=True, exist_ok=True)
        for run_def in run_defs:
            print(f"[run] {run_def['name']} -> {RESULT_ROOT / run_def['name']}", flush=True)
            run_batch(run_def, workers=args.workers, timeout=args.timeout)

    all_records: list[dict[str, Any]] = []
    summaries: list[dict[str, Any]] = []
    for run_def in run_defs:
        records = enriched_records(split_rows, run_def)
        all_records.extend(records)
        summaries.append(summarize_records(records, run_def))

    write_summary_csv(summaries)
    write_matrix_csv(all_records)
    write_report(
        split_rows,
        run_defs,
        summaries,
        all_records,
        workers=args.workers,
        timeout=args.timeout,
        seed=args.seed,
        train_ratio=args.train_ratio,
    )

    print(f"[done] split_csv={SPLIT_CSV}", flush=True)
    print(f"[done] report={REPORT_PATH}", flush=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=20260719)
    parser.add_argument("--train-ratio", type=float, default=0.70)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--timeout", type=float, default=900.0)
    parser.add_argument("--split-only", action="store_true")
    parser.add_argument("--skip-run", action="store_true")
    parser.add_argument(
        "--skip-no-stability-test",
        action="store_true",
        help="Only run/summarize train_current and test_current.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    run_and_summarize(args)


if __name__ == "__main__":
    main()
