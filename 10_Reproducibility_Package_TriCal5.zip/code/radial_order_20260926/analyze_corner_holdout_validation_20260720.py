#!/usr/bin/env python3
"""Fixed-intrinsic corner holdout validation for saved trihedral corners."""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import Counter
from pathlib import Path
from statistics import mean, median
from typing import Any

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
PAPER_DIR = ROOT / "paper_drafts"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if str(PAPER_DIR) not in sys.path:
    sys.path.insert(0, str(PAPER_DIR))

from analyze_corner_noise_robustness_20260718 import (  # noqa: E402
    DEFAULT_JSON,
    build_points,
    camera_from_row,
    choose_corner_source,
    fnum,
    load_face_corners,
    percentile,
    valid_real_ok,
)


DEFAULT_OUT_DIR = PAPER_DIR / "corner_holdout_validation_20260720"
DEFAULT_REPORT = PAPER_DIR / "corner_holdout_validation_20260720.md"


def fmt(value: float | None, ndigits: int = 3) -> str:
    if value is None or not math.isfinite(float(value)):
        return "-"
    return f"{float(value):.{ndigits}f}"


def rmse_for_indices(
    obj: np.ndarray,
    img: np.ndarray,
    indices: np.ndarray,
    K: np.ndarray,
    dist: np.ndarray,
    rvec: np.ndarray,
    tvec: np.ndarray,
) -> float:
    proj, _ = cv2.projectPoints(
        obj[indices].reshape(-1, 1, 3),
        rvec.reshape(3, 1),
        tvec.reshape(3, 1),
        K,
        dist,
    )
    diff = proj.reshape(-1, 2) - img[indices].reshape(-1, 2)
    return float(np.sqrt(np.mean(np.sum(diff * diff, axis=1))))


def solve_train_pose(
    obj: np.ndarray,
    img: np.ndarray,
    train_idx: np.ndarray,
    K: np.ndarray,
    dist: np.ndarray,
) -> tuple[bool, np.ndarray | None, np.ndarray | None]:
    try:
        ok, rvec, tvec = cv2.solvePnP(
            obj[train_idx].reshape(-1, 1, 3),
            img[train_idx].reshape(-1, 1, 2),
            K,
            dist,
            flags=cv2.SOLVEPNP_ITERATIVE,
        )
    except cv2.error:
        return False, None, None
    if not ok:
        return False, None, None
    return True, rvec.reshape(3), tvec.reshape(3)


def split_indices_by_face(
    counts: list[int],
    rng: np.random.Generator,
    *,
    holdout_frac: float,
    min_holdout_per_face: int,
) -> tuple[np.ndarray, np.ndarray]:
    train_parts: list[np.ndarray] = []
    holdout_parts: list[np.ndarray] = []
    start = 0
    for count in counts:
        local = np.arange(start, start + count)
        rng.shuffle(local)
        n_hold = max(min_holdout_per_face, int(round(count * holdout_frac)))
        n_hold = min(max(1, n_hold), count - 6)
        holdout_parts.append(np.sort(local[:n_hold]))
        train_parts.append(np.sort(local[n_hold:]))
        start += count
    return np.concatenate(train_parts), np.concatenate(holdout_parts)


def summarize(values: list[float]) -> dict[str, float | None]:
    vals = [v for v in values if math.isfinite(v)]
    if not vals:
        return {"mean": None, "median": None, "p90": None, "max": None}
    return {
        "mean": mean(vals),
        "median": median(vals),
        "p90": percentile(vals, 0.90),
        "max": max(vals),
    }


def area_bin(area: float | None) -> str:
    if area is None:
        return "unknown"
    if area < 2:
        return "<2%"
    if area < 3:
        return "2-3%"
    if area < 6:
        return "3-6%"
    if area < 10:
        return "6-10%"
    return ">=10%"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", type=Path, default=DEFAULT_JSON)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    parser.add_argument("--report", type=Path, default=DEFAULT_REPORT)
    parser.add_argument("--repeats", type=int, default=30)
    parser.add_argument("--holdout-frac", type=float, default=0.20)
    parser.add_argument("--min-holdout-per-face", type=int, default=6)
    parser.add_argument("--seed", type=int, default=20260720)
    args = parser.parse_args()

    rows = json.loads(args.json.resolve().read_text(encoding="utf-8"))
    rng = np.random.default_rng(args.seed)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    trial_csv = args.out_dir / "corner_holdout_trials.csv"
    sample_json = args.out_dir / "corner_holdout_samples.json"

    eligible: list[dict[str, Any]] = []
    skipped: list[tuple[str, str]] = []
    for row in rows:
        if not valid_real_ok(row):
            continue
        source = choose_corner_source(row)
        if source is None:
            continue
        source_name, corners_path, patterns = source
        if not corners_path.exists():
            skipped.append((str(row.get("rel_path") or ""), "missing corners path"))
            continue
        copy = dict(row)
        copy["corner_source"] = source_name
        copy["chosen_corners_path"] = str(corners_path)
        copy["chosen_patterns"] = patterns
        copy["area_bin"] = area_bin(fnum(row.get("cube_area_pct")))
        eligible.append(copy)

    trials: list[dict[str, Any]] = []
    samples: list[dict[str, Any]] = []
    for row in sorted(eligible, key=lambda r: str(r.get("rel_path") or "")):
        rel = str(row.get("rel_path") or "")
        try:
            corners = load_face_corners(Path(str(row["chosen_corners_path"])))
            counts = [int(np.asarray(face).reshape(-1, 2).shape[0]) for face in corners]
            obj, img, _orientation = build_points(row, corners, list(row["chosen_patterns"]))
            K, dist = camera_from_row(row)
            full_idx = np.arange(img.shape[0])
        except Exception as exc:
            skipped.append((rel, str(exc)))
            continue

        samples.append(
            {
                "rel_path": rel,
                "corner_source": row["corner_source"],
                "area_bin": row["area_bin"],
                "cube_area_pct": fnum(row.get("cube_area_pct")),
                "calibration_status": row.get("calibration_status"),
                "model_grade": row.get("model_grade"),
                "frozen_rmse_px": fnum(row.get("rmse_px")),
                "n_corners": int(img.shape[0]),
                "face_corner_counts": counts,
            }
        )

        for repeat in range(args.repeats):
            train_idx, holdout_idx = split_indices_by_face(
                counts,
                rng,
                holdout_frac=args.holdout_frac,
                min_holdout_per_face=args.min_holdout_per_face,
            )
            ok, rvec, tvec = solve_train_pose(obj, img, train_idx, K, dist)
            record: dict[str, Any] = {
                "rel_path": rel,
                "corner_source": row["corner_source"],
                "area_bin": row["area_bin"],
                "cube_area_pct": fmt(fnum(row.get("cube_area_pct")), 6),
                "calibration_status": row.get("calibration_status") or "",
                "model_grade": row.get("model_grade") or "",
                "repeat": repeat,
                "success": 1 if ok else 0,
                "n_total": int(len(full_idx)),
                "n_train": int(len(train_idx)),
                "n_holdout": int(len(holdout_idx)),
                "frozen_rmse_px": fmt(fnum(row.get("rmse_px")), 6),
                "train_rmse_px": "",
                "holdout_rmse_px": "",
                "all_rmse_px": "",
                "holdout_minus_train_px": "",
                "holdout_minus_frozen_px": "",
            }
            if ok and rvec is not None and tvec is not None:
                train_rmse = rmse_for_indices(obj, img, train_idx, K, dist, rvec, tvec)
                holdout_rmse = rmse_for_indices(obj, img, holdout_idx, K, dist, rvec, tvec)
                all_rmse = rmse_for_indices(obj, img, full_idx, K, dist, rvec, tvec)
                frozen_rmse = fnum(row.get("rmse_px"))
                record.update(
                    {
                        "train_rmse_px": fmt(train_rmse, 6),
                        "holdout_rmse_px": fmt(holdout_rmse, 6),
                        "all_rmse_px": fmt(all_rmse, 6),
                        "holdout_minus_train_px": fmt(holdout_rmse - train_rmse, 6),
                        "holdout_minus_frozen_px": fmt(
                            holdout_rmse - frozen_rmse if frozen_rmse is not None else math.nan,
                            6,
                        ),
                    }
                )
            trials.append(record)

    with trial_csv.open("w", encoding="utf-8", newline="") as f:
        fieldnames = [
            "rel_path",
            "corner_source",
            "area_bin",
            "cube_area_pct",
            "calibration_status",
            "model_grade",
            "repeat",
            "success",
            "n_total",
            "n_train",
            "n_holdout",
            "frozen_rmse_px",
            "train_rmse_px",
            "holdout_rmse_px",
            "all_rmse_px",
            "holdout_minus_train_px",
            "holdout_minus_frozen_px",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(trials)
    sample_json.write_text(json.dumps(samples, ensure_ascii=False, indent=2), encoding="utf-8")

    ok_trials = [r for r in trials if str(r["success"]) == "1"]
    holdout = [float(r["holdout_rmse_px"]) for r in ok_trials if r["holdout_rmse_px"]]
    train = [float(r["train_rmse_px"]) for r in ok_trials if r["train_rmse_px"]]
    all_rmse = [float(r["all_rmse_px"]) for r in ok_trials if r["all_rmse_px"]]
    gap = [float(r["holdout_minus_train_px"]) for r in ok_trials if r["holdout_minus_train_px"]]
    frozen_gap = [float(r["holdout_minus_frozen_px"]) for r in ok_trials if r["holdout_minus_frozen_px"]]
    holdout_stats = summarize(holdout)
    train_stats = summarize(train)
    all_stats = summarize(all_rmse)
    gap_stats = summarize(gap)
    frozen_gap_stats = summarize(frozen_gap)

    source_counts = Counter(s["corner_source"] for s in samples)
    area_counts = Counter(s["area_bin"] for s in samples)
    lines = [
        "# Corner Holdout Validation 2026-07-20",
        "",
        f"Source JSON: `{args.json.resolve().relative_to(ROOT)}`",
        f"Trial CSV: `{trial_csv.relative_to(ROOT)}`",
        f"Sample JSON: `{sample_json.relative_to(ROOT)}`",
        "",
        "## Scope",
        "",
        "This experiment uses saved three-face corner files from the frozen full136 result. It keeps the calibrated intrinsics and distortion coefficients fixed, estimates only the frame pose from a stratified 80% subset of corners on each face, and evaluates reprojection RMSE on the withheld 20% corners. It tests internal geometric consistency of the recovered trihedral correspondences, not external physical ground truth.",
        "",
        f"- eligible saved-corner real targets: {len(samples)}",
        f"- repeats per image: {args.repeats}",
        f"- total holdout trials: {len(trials)}",
        f"- successful PnP trials: {len(ok_trials)}/{len(trials)}",
        f"- corner source counts: `{dict(source_counts)}`",
        f"- area-bin counts: `{dict(area_counts)}`",
        f"- skipped samples: {len(skipped)}",
        "",
        "## Overall Results",
        "",
        "| metric | mean px | median px | P90 px | max px |",
        "|---|---:|---:|---:|---:|",
        f"| Train RMSE | {fmt(train_stats['mean'])} | {fmt(train_stats['median'])} | {fmt(train_stats['p90'])} | {fmt(train_stats['max'])} |",
        f"| Holdout RMSE | {fmt(holdout_stats['mean'])} | {fmt(holdout_stats['median'])} | {fmt(holdout_stats['p90'])} | {fmt(holdout_stats['max'])} |",
        f"| All-corner RMSE after train-pose fit | {fmt(all_stats['mean'])} | {fmt(all_stats['median'])} | {fmt(all_stats['p90'])} | {fmt(all_stats['max'])} |",
        f"| Holdout minus train | {fmt(gap_stats['mean'])} | {fmt(gap_stats['median'])} | {fmt(gap_stats['p90'])} | {fmt(gap_stats['max'])} |",
        f"| Holdout minus frozen reported RMSE | {fmt(frozen_gap_stats['mean'])} | {fmt(frozen_gap_stats['median'])} | {fmt(frozen_gap_stats['p90'])} | {fmt(frozen_gap_stats['max'])} |",
        "",
        "## By Corner Source",
        "",
        "| source | images | trials | holdout mean px | holdout P90 px | holdout-train mean px |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for source in sorted(source_counts):
        subset = [r for r in ok_trials if r["corner_source"] == source]
        vals = [float(r["holdout_rmse_px"]) for r in subset if r["holdout_rmse_px"]]
        gaps = [float(r["holdout_minus_train_px"]) for r in subset if r["holdout_minus_train_px"]]
        st = summarize(vals)
        gs = summarize(gaps)
        lines.append(
            f"| `{source}` | {source_counts[source]} | {len(subset)} | {fmt(st['mean'])} | {fmt(st['p90'])} | {fmt(gs['mean'])} |"
        )
    lines += [
        "",
        "## By Area Bin",
        "",
        "| area bin | images | trials | holdout mean px | holdout P90 px | holdout-train mean px |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for band in ["<2%", "2-3%", "3-6%", "6-10%", ">=10%", "unknown"]:
        if area_counts[band] == 0:
            continue
        subset = [r for r in ok_trials if r["area_bin"] == band]
        vals = [float(r["holdout_rmse_px"]) for r in subset if r["holdout_rmse_px"]]
        gaps = [float(r["holdout_minus_train_px"]) for r in subset if r["holdout_minus_train_px"]]
        st = summarize(vals)
        gs = summarize(gaps)
        lines.append(
            f"| `{band}` | {area_counts[band]} | {len(subset)} | {fmt(st['mean'])} | {fmt(st['p90'])} | {fmt(gs['mean'])} |"
        )
    lines += [
        "",
        "## Interpretation Boundary",
        "",
        "A small holdout gap indicates that the recovered trihedral geometry is not merely fitting the points used for pose estimation. Because this test fixes the intrinsics and distortion from the frozen calibration, it should be cited as internal reprojection-consistency evidence for saved three-face correspondences, not as independent physical truth for absolute camera intrinsics.",
    ]
    if skipped:
        lines += ["", "## Skipped Samples", "", "| rel path | reason |", "|---|---|"]
        for rel, reason in skipped:
            lines.append(f"| `{rel}` | {reason} |")
    args.report.resolve().write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {trial_csv}")
    print(f"Wrote {sample_json}")
    print(f"Wrote {args.report.resolve()}")


if __name__ == "__main__":
    main()
