#!/usr/bin/env python3
"""Classical mask/quad probe for the three visible cube faces.

This diagnostic tries the next recovery direction without requiring a SAM
checkpoint: build a cube-local mask from dark checker components, split that
mask by the three face seeds, and fit one quadrilateral per physical face.
It is intentionally a probe; calibration promotion still belongs behind a
separate gate after visual and geometric validation.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

import cv2
import numpy as np

import face_detector as fd
from partial_offset_probe import _load_gray


FACE_COLORS = {
    "XY": (0, 0, 255),
    "XZ": (0, 210, 0),
    "YZ": (255, 80, 0),
}


def _jsonable(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    return str(value)


def _load_rel_paths(path: Path) -> list[str]:
    return [
        line.strip().replace("\\", "/")
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]


def _bbox_from_boxes(boxes: list[tuple[int, int, int, int]]) -> tuple[int, int, int, int]:
    x1 = min(x for x, _y, _w, _h in boxes)
    y1 = min(y for _x, y, _w, _h in boxes)
    x2 = max(x + w for x, _y, w, _h in boxes)
    y2 = max(y + h for _x, y, _w, h in boxes)
    return int(x1), int(y1), int(x2), int(y2)


def _clip_box(box: tuple[int, int, int, int], shape: tuple[int, int]) -> tuple[int, int, int, int]:
    h, w = shape[:2]
    x1, y1, x2, y2 = box
    return (
        max(0, min(w - 1, int(x1))),
        max(0, min(h - 1, int(y1))),
        max(1, min(w, int(x2))),
        max(1, min(h, int(y2))),
    )


def _order_quad(pts: np.ndarray) -> np.ndarray:
    pts = np.asarray(pts, dtype=np.float32).reshape(4, 2)
    c = pts.mean(axis=0)
    ang = np.arctan2(pts[:, 1] - c[1], pts[:, 0] - c[0])
    out = pts[np.argsort(ang)]
    start = int(np.argmin(out[:, 0] + out[:, 1]))
    return np.roll(out, -start, axis=0).astype(np.float32)


def _quad_from_mask(mask: np.ndarray) -> tuple[np.ndarray | None, dict[str, Any]]:
    contours, _ = cv2.findContours(
        mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None, {"status": "no_contour"}
    cnt = max(contours, key=cv2.contourArea)
    area = float(cv2.contourArea(cnt))
    if area < 50.0:
        return None, {"status": "small_contour", "area": area}
    hull = cv2.convexHull(cnt)
    best = None
    best_score = float("inf")
    for eps_frac in (0.015, 0.025, 0.040, 0.060, 0.090):
        eps = eps_frac * cv2.arcLength(hull, True)
        approx = cv2.approxPolyDP(hull, eps, True).reshape(-1, 2)
        if len(approx) < 4:
            continue
        if len(approx) == 4:
            quad = _order_quad(approx)
        else:
            rect = cv2.minAreaRect(hull)
            quad = _order_quad(cv2.boxPoints(rect))
        q_area = abs(float(cv2.contourArea(quad.astype(np.float32))))
        if q_area < 50.0:
            continue
        fill = area / max(q_area, 1.0)
        score = abs(1.0 - fill) + 0.03 * abs(len(approx) - 4)
        if score < best_score:
            best_score = score
            best = (quad, {
                "status": "ok",
                "mask_area": area,
                "quad_area": q_area,
                "fill": fill,
                "approx_vertices": int(len(approx)),
            })
    if best is not None:
        return best
    rect = cv2.minAreaRect(cnt)
    quad = _order_quad(cv2.boxPoints(rect))
    return quad, {
        "status": "min_area_rect",
        "mask_area": area,
        "quad_area": abs(float(cv2.contourArea(quad.astype(np.float32)))),
    }


def _expand_quad(quad: np.ndarray, scale: float, shape: tuple[int, int]) -> np.ndarray:
    h, w = shape[:2]
    center = quad.reshape(-1, 2).mean(axis=0)
    out = center + (quad.reshape(-1, 2) - center) * float(scale)
    out[:, 0] = np.clip(out[:, 0], 0, w - 1)
    out[:, 1] = np.clip(out[:, 1], 0, h - 1)
    return out.astype(np.float32)


def build_component_target_mask(gray: np.ndarray) -> tuple[np.ndarray, dict[str, Any]]:
    filtered, components = fd._dark_square_components(gray)
    if len(components) < 8:
        return np.zeros_like(gray, dtype=np.uint8), {"status": "too_few_components"}

    crop_box = fd._cube_crop_from_clusters(gray, n_faces=3)
    if crop_box is not None:
        x1, y1, x2, y2 = [int(v) for v in crop_box]
    else:
        boxes = [tuple(int(v) for v in comp["bbox"]) for comp in components]
        x1, y1, x2, y2 = _bbox_from_boxes(boxes)
        span = max(x2 - x1, y2 - y1, 1)
        pad = max(25, int(round(0.22 * span)))
        x1, y1, x2, y2 = _clip_box((x1 - pad, y1 - pad, x2 + pad, y2 + pad), gray.shape)

    mask = np.zeros_like(gray, dtype=np.uint8)
    for comp in components:
        x, y, w, h = [int(v) for v in comp["bbox"]]
        if x + w < x1 or x > x2 or y + h < y1 or y > y2:
            continue
        mask[max(0, y):min(gray.shape[0], y + h),
             max(0, x):min(gray.shape[1], x + w)] = 255

    sizes = [max(int(comp["bbox"][2]), int(comp["bbox"][3])) for comp in components]
    median_size = float(np.median(sizes)) if sizes else 9.0
    k = int(round(max(11.0, min(41.0, median_size * 2.6))))
    if k % 2 == 0:
        k += 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    mask = cv2.dilate(mask, kernel, iterations=2)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

    crop_mask = np.zeros_like(mask)
    crop_mask[y1:y2, x1:x2] = 255
    mask = cv2.bitwise_and(mask, crop_mask)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if contours:
        largest = max(contours, key=cv2.contourArea)
        clean = np.zeros_like(mask)
        cv2.drawContours(clean, [largest], -1, 255, -1)
        mask = clean

    return mask, {
        "status": "ok",
        "crop": (x1, y1, x2, y2),
        "components": len(components),
        "kernel": k,
        "mask_area": int(np.count_nonzero(mask)),
    }


def split_mask_by_trihedral_sectors(
    gray: np.ndarray,
    target_mask: np.ndarray,
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    try:
        from trihedral_boundary_probe import _edge_regions_from_layout
    except Exception as exc:
        return {}, {"status": "import_failed", "error": str(exc)}
    try:
        layout_source, regions = _edge_regions_from_layout(gray)
    except Exception as exc:
        return {}, {"status": "layout_failed", "error": str(exc)}
    if not regions:
        return {}, {"status": "no_trihedral_regions", "source": layout_source}

    yy, xx = np.indices(target_mask.shape[:2])
    rel_x = xx.astype(np.float32)
    rel_y = yy.astype(np.float32)
    masks: dict[str, np.ndarray] = {}
    trace_regions: dict[str, Any] = {}
    for label, region in regions.items():
        if label not in {"XY", "XZ", "YZ"}:
            continue
        vertex = np.asarray(region["vertex"], dtype=np.float32).reshape(2)
        angles = (
            np.arctan2(rel_y - float(vertex[1]), rel_x - float(vertex[0]))
            + 2.0 * np.pi
        ) % (2.0 * np.pi)
        sector = fd._angles_in_sector(
            angles,
            float(region["sector_start"]),
            float(region["sector_end"]),
        )
        mask = np.where((target_mask > 0) & sector, 255, 0).astype(np.uint8)
        if np.count_nonzero(mask) < 80:
            continue
        small = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, small, iterations=1)
        masks[label] = mask
        trace_regions[label] = {
            "source": region.get("source"),
            "sector_idx": region.get("sector_idx"),
            "count": int(region.get("count", 0)),
            "area": int(np.count_nonzero(mask)),
        }
    if len(masks) < 3:
        return {}, {
            "status": "incomplete_trihedral_split",
            "source": layout_source,
            "regions": trace_regions,
        }
    return masks, {
        "status": "ok",
        "source": layout_source,
        "regions": trace_regions,
    }


def split_mask_by_face_seeds(
    gray: np.ndarray,
    target_mask: np.ndarray,
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    clusters = fd._cluster_dark_components(gray, n_faces=3, verbose=False)
    labeled = fd._label_cube_clusters(clusters) if len(clusters) >= 3 else []
    seeds = {
        str(face["label"]): np.asarray(face["center"], dtype=np.float32)
        for face in labeled
        if face.get("label") in {"XY", "XZ", "YZ"}
    }
    if len(seeds) < 3:
        return {}, {"status": "missing_seeds", "seed_count": len(seeds)}

    ys, xs = np.nonzero(target_mask > 0)
    if len(xs) == 0:
        return {}, {"status": "empty_target_mask"}
    pts = np.column_stack([xs, ys]).astype(np.float32)
    labels = list(seeds.keys())
    centers = np.vstack([seeds[label] for label in labels]).astype(np.float32)
    dists = np.linalg.norm(pts[:, None, :] - centers[None, :, :], axis=2)
    assign = np.argmin(dists, axis=1)

    masks = {label: np.zeros_like(target_mask, dtype=np.uint8) for label in labels}
    for idx, label in enumerate(labels):
        selected = assign == idx
        masks[label][ys[selected], xs[selected]] = 255

    small = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
    for label in labels:
        masks[label] = cv2.morphologyEx(masks[label], cv2.MORPH_CLOSE, small, iterations=1)

    return masks, {
        "status": "ok",
        "seeds": {label: seeds[label].tolist() for label in labels},
    }


def analyze_one(rel: str, image_root: Path, out_dir: Path) -> dict[str, Any]:
    image_path = image_root / rel
    row: dict[str, Any] = {"rel_path": rel, "image_path": str(image_path)}
    if not image_path.exists():
        row["status"] = "missing_image"
        return row

    gray = _load_gray(image_path)
    bgr = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    target_mask, mask_trace = build_component_target_mask(gray)
    split_mode = "trihedral" if getattr(analyze_one, "split_mode", "seed") == "trihedral" else "seed"
    if split_mode == "trihedral":
        face_masks, split_trace = split_mask_by_trihedral_sectors(gray, target_mask)
        if not face_masks:
            face_masks, fallback_trace = split_mask_by_face_seeds(gray, target_mask)
            split_trace = {
                "status": "trihedral_failed_seed_fallback",
                "trihedral": split_trace,
                "fallback": fallback_trace,
            }
    else:
        face_masks, split_trace = split_mask_by_face_seeds(gray, target_mask)
    row.update({
        "mask_status": mask_trace.get("status"),
        "split_status": split_trace.get("status"),
        "split_mode": split_mode,
        "mask_trace": json.dumps(mask_trace, ensure_ascii=False, default=_jsonable),
        "split_trace": json.dumps(split_trace, ensure_ascii=False, default=_jsonable),
    })
    if not face_masks:
        row["status"] = "failed"
        return row

    overlay = bgr.copy()
    contours, _ = cv2.findContours(target_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(overlay, contours, -1, (255, 255, 255), 2)

    quad_records = []
    for label in ("XY", "XZ", "YZ"):
        mask = face_masks.get(label)
        if mask is None:
            continue
        quad, qtrace = _quad_from_mask(mask)
        if quad is None:
            quad_records.append({"label": label, **qtrace})
            continue
        quad = _expand_quad(quad, 1.08, gray.shape)
        color = FACE_COLORS.get(label, (255, 255, 255))
        pts = quad.reshape(-1, 1, 2).astype(np.int32)
        cv2.polylines(overlay, [pts], True, color, 3, cv2.LINE_AA)
        center = quad.mean(axis=0)
        cv2.putText(
            overlay,
            label,
            (int(center[0]), int(center[1])),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            color,
            2,
            cv2.LINE_AA,
        )
        quad_records.append({
            "label": label,
            "quad": quad,
            **qtrace,
        })

    out_dir.mkdir(parents=True, exist_ok=True)
    overlay_dir = out_dir / "overlays"
    overlay_dir.mkdir(parents=True, exist_ok=True)
    stem = rel.replace("/", "__").replace("\\", "__").rsplit(".", 1)[0]
    overlay_path = overlay_dir / f"{stem}_component_face_quads.jpg"
    cv2.imwrite(str(overlay_path), overlay)
    row.update({
        "status": "ok" if len(quad_records) >= 3 else "partial",
        "quad_count": sum(1 for item in quad_records if item.get("quad") is not None),
        "quad_records": json.dumps(quad_records, ensure_ascii=False, default=_jsonable),
        "overlay_path": str(overlay_path),
    })
    return row


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image-root", type=Path, required=True)
    parser.add_argument("--rel-list", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--split-mode", choices=["seed", "trihedral"], default="seed")
    args = parser.parse_args()
    analyze_one.split_mode = args.split_mode

    rows = []
    for rel in _load_rel_paths(args.rel_list):
        row = analyze_one(rel, args.image_root, args.out_dir)
        rows.append(row)
        print(json.dumps({
            "rel_path": rel,
            "status": row.get("status"),
            "quad_count": row.get("quad_count"),
            "overlay_path": row.get("overlay_path"),
        }, ensure_ascii=False), flush=True)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(args.out_dir / "component_face_quad_probe.csv", rows)
    (args.out_dir / "component_face_quad_probe.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2, default=_jsonable),
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
