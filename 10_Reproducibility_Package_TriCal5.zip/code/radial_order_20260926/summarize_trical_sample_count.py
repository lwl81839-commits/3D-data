from experiment_0820_trical_sample_count import OUT,POSES,ROOT,BASE,read,save
from pathlib import Path
import numpy as np,hashlib
rows=[];totals=[]
for pose in POSES:
    planar=read(OUT/'planar_evaluations'/pose/'evaluation.json')
    for folder in sorted((OUT/'models'/pose).iterdir()):
        if not folder.is_dir():continue
        spec=read(folder/'selection.json');s=read(folder/'status.json')
        row=dict(pose=pose,name=folder.name,n=spec['n'],omitted=Path(spec['held_development_image']).name if spec['held_development_image'] else None,**s)
        if s['completed']:
            m=read(folder/'trained_camera_model.json');c=m['candidate_comparison']['k1_k2']
            row.update(k1=m['distCoeffs'][0],k2=m['distCoeffs'][1],K=m['cameraMatrix'],base_quality_accepted=c['base_quality_accepted'],stability=c['k2_stability'],radial_coverage=c['radial_coverage'],homographies=c['local_homography_seed']['homography_count'],image_evidence=m['training_images'],cv=m['cross_validation'])
            for kind in ['3D_test','development_holdout']:
                p=OUT/'evaluations'/pose/folder.name/kind/'evaluation.json'
                if p.exists():row[kind]=read(p)['summary']
            row['planar_test']=planar['summaries'].get(folder.name)
        rows.append(row)
    subset=[x for x in rows if x['pose']==pose and x['n']==4]
    totals.append(dict(pose=pose,n4_completed=sum(x['completed'] for x in subset),n4_accepted=sum(x['accepted'] for x in subset),n4_requested=5,n5_accepted=next(x['accepted'] for x in rows if x['pose']==pose and x['n']==5)))
save(OUT/'analysis.json',dict(count_summary=totals,models=rows))
def num(v):return '-' if v is None else f'{v:.4f}'
lines=['# 0820 TriCal image-count and image-evidence study','',
'Only the existing five-image development pool per configuration is used. All five four-image subsets are enumerated, and the full five-image model is retrained. Ratio priors, optimizer and release gates are unchanged. No MATLAB calibration is retrained or read during training. The five-image baseline has only ONE training subset per configuration, so this is a deletion sensitivity study, not a proof that five images are sufficient across acquisitions.','',
'Two/three-image formal fits are not implemented by the present public training entry (minimum four); this is a software limit, not a theoretical lower bound. Seven/ten-image fits require a larger development pool, not reassignment of frozen test images. Each four-image model additionally undergoes nested development validation; its omitted fifth image is a separate development holdout. Test results are exploratory confirmation, not a basis for selecting the preferred omitted image. No application-specific minimum accuracy was supplied, so no new pass threshold or minimum sufficient sample count is inferred.','',
'## Acceptance under existing gates','', '|Configuration|Four-image numerical fits|Four-image accepted|Five-image accepted|','|---|---|---|---|']
for x in totals:lines.append(f"|{x['pose']}|{x['n4_completed']}/5|{x['n4_accepted']}/5|{x['n5_accepted']}|")
lines+=['','## Per-subset results','', '|Configuration|Model|Omitted image|Accepted|Development holdout px|2D test px|3D test px|','|---|---|---|---|---|---|---|']
for x in rows:
    def metric(k):return x.get(k,{}).get('holdout_error_px',{}).get('median')
    p=x.get('planar_test') or {}
    lines.append(f"|{x['pose']}|{x['name']}|{x['omitted'] or '-'}|{x['accepted']}|{num(metric('development_holdout'))}|{num(p.get('holdout_rmse_px',{}).get('median'))}|{num(metric('3D_test'))}|")
lines+=['','3D values retain the original median across trial RMSEs; planar values are medians of per-image median trial RMSEs. Rejected models are diagnostic only. A single omitted image cannot establish generalization by itself.','',
'## Image-evidence diagnostics','', '|Configuration|Model|Homographies|Used corner count for radius|Normalized radius p95|Fraction r>0.4|k2|','|---|---|---|---|---|---|---|']
for x in rows:
    if not x['completed']:continue
    r=x['radial_coverage'];lines.append(f"|{x['pose']}|{x['name']}|{x['homographies']}|{r['point_count']}|{num(r['radius_p95'])}|{num(r['fraction_radius_gt_0_4'])}|{num(x['k2'])}|")
lines+=['','These optical normalized radii use each fitted K and accepted points. Raw image-center/half-diagonal radius summaries in development_geometry are a DIFFERENT metric. Raw cached points do not equal final inliers. The full analysis.json records face counts, grid spans, rejected-image reasons and optical coverage; no image-quality or radial cutoff is inferred solely from this small experiment.','',
'## Reasons for rejected fits','']
for x in rows:
    if not x['accepted']:lines.append(f"- {x['pose']} {x['name']}: "+(x.get('error') or f"base_quality={x['base_quality_accepted']}; {x['stability']['reason']}"))
(OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
drift=[]
lines+=['','## Five-image rerun reproducibility check','', 'The table above uses freshly retrained five-image baselines, not silently substituted historical parameters. Differences below are recorded without attributing them to sample count; solver initialization/randomness and execution details require a separate audit.','', '|Config.|Historical k1|Rerun k1|Historical k2|Rerun k2|','|---|---|---|---|---|']
for pose in POSES:
    a=read(BASE/'per_pose_models'/pose/'trained_camera_model.json');b=read(OUT/'models'/pose/'n05_full/trained_camera_model.json')
    drift.append(dict(pose=pose,old_dist=a['distCoeffs'],new_dist=b['distCoeffs'],max_K_change=float(np.max(abs(np.asarray(a['cameraMatrix'])-np.asarray(b['cameraMatrix']))))))
    lines.append(f"|{pose}|{num(a['distCoeffs'][0])}|{num(b['distCoeffs'][0])}|{num(a['distCoeffs'][1])}|{num(b['distCoeffs'][1])}|")
save(OUT/'baseline_rerun_comparison.json',drift)
(OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
assert hashlib.sha256((ROOT/'trained_camera_model.py').read_bytes()).hexdigest()==read(OUT/'protocol.json')['source_sha256']
print(totals)
