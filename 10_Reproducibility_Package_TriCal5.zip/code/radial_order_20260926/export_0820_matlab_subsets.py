"""Copy frozen budget subsets for MATLAB; never reselect or modify originals."""
from pathlib import Path
import json,hashlib,shutil

ROOT=Path(__file__).resolve().parent
SOURCE=Path('E:/Data_image_3d/data_3D_0820_split_model_3D5_Zhang2D20_each_pose_quality_gated')
MODELS=ROOT/'output/experiment_0820_planar_budget/models'
DEST=Path('E:/Data_image_3d/0820_MATLAB_2D_5_10_20_split_20260912')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    if DEST.exists():raise RuntimeError(f'Destination already exists; refusing to overwrite: {DEST}')
    DEST.mkdir()
    rows=[];summary=[];text=['0820：MATLAB二维标定图片数量对照数据集','',
    '此包仅为已冻结图片子集，不包含任何冒充MATLAB结果的OpenCV参数。原图未移动、未改名。',
    'train_2D/姿态/05_images/repeat_01..05：每组5张；10_images同理；20_images只有repeat_01。',
    '同一姿态、同一repeat编号的5张包含在10张中；所有训练图来自原20张二维训练池。组间允许重叠。',
    'test/姿态/2D：原二维测试集；test/姿态/3D：原三维测试集，仅供后续评估。',
    '每次在MATLAB新建一次独立标定，仅导入一个repeat文件夹内的图片；不要同时导入多个组或测试集。',
    '棋盘格方格边长25 mm。为了与既有参考统一，请核对原MATLAB设置（两项径向系数、切向畸变和skew选项），并记录MATLAB版本。',
    '如有MATLAB检测失败，请记录失败图片及实际使用数量，不要从测试集补图或按测试效果替换图片。',
    '建议结果按姿态、图片数、repeat编号分别命名保存；本脚本不执行MATLAB标定。',
    '0909不在此包内。manifest.json记录每份复制的源路径、目标路径和SHA-256。','', '训练图片清单：']
    def copy(src,rel,role,pose,expected=None):
        digest=sha(src)
        if expected is not None:assert digest==expected,(src,'source changed since experiment')
        target=DEST/rel;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,target);assert sha(target)==digest
        rows.append(dict(source=str(src),relative_path=rel.as_posix(),role=role,pose=pose,sha256=digest,bytes=target.stat().st_size))
    for directory in sorted(MODELS.iterdir()):
        if not directory.is_dir():continue
        pose=directory.name; trainhash=set();members={}
        for f in sorted(directory.glob('planar_*.json')):
            m=json.loads(f.read_text(encoding='utf-8'));n=m['requested'];repeat=m['repeat']
            selected=m['training_images'];assert len(selected)==n
            members[n,repeat]={x['sha256'] for x in selected}
            rel=Path('train_2D')/pose/f'{n:02d}_images'/f'repeat_{repeat:02d}'
            for item in selected:
                src=Path(item['image']);copy(src,rel/src.name,'train_2D',pose,item['sha256']);trainhash.add(item['sha256'])
            summary.append(dict(pose=pose,images=n,repeat=repeat,relative_directory=rel.as_posix(),files=[Path(x['image']).name for x in selected]))
            text.append(f'{pose} / {n:02d}张 / 第{repeat}组：'+', '.join(Path(x['image']).name for x in selected))
        assert len(members)==11 and len(trainhash)==20
        for r in range(1,6):assert members[5,r]<=members[10,r]<=members[20,1]
        for kind in ['2D','3D']:
            folder=SOURCE/'test'/pose/kind
            if not folder.exists() and kind=='2D':folder=SOURCE/'test'/pose/'zhang_2d'
            images=sorted(folder.glob('*.jpg'));assert images
            for src in images:
                assert sha(src) not in trainhash,('train/test overlap',src)
                copy(src,Path('test')/pose/kind/src.name,'test_'+kind,pose)
    counts={role:sum(r['role']==role for r in rows) for role in ['train_2D','test_2D','test_3D']}
    assert counts=={'train_2D':475,'test_2D':273,'test_3D':330},counts
    (DEST/'manifest.json').write_text(json.dumps(dict(source_dataset=str(SOURCE),counts=counts,all_copies_sha256_verified=True,train_test_disjoint=True,files=rows),ensure_ascii=False,indent=2),encoding='utf-8')
    (DEST/'training_groups.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    (DEST/'00_README_使用说明.txt').write_text('\n'.join(text),encoding='utf-8-sig')
    shutil.copy2(Path(__file__),DEST/'export_0820_matlab_subsets.py')
    print(json.dumps(dict(destination=str(DEST),groups=len(summary),counts=counts,verified=True),ensure_ascii=False))
if __name__=='__main__':main()
