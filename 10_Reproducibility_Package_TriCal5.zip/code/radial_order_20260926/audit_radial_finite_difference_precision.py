"""Read-only numerical diagnostic of projection dtype and finite differences."""
from pathlib import Path
import json,hashlib
import numpy as np,cv2
from ablate_0820_ratio_prior import ROOT,BASE,SPLIT,POSES
from trained_camera_model import _load_cache,_local_face_observations
out=ROOT/'output/experiment_0820_stability_curve'
rows=[]
for pose in POSES:
    m=json.loads((BASE/'per_pose_models'/pose/'trained_camera_model.json').read_text());K=np.array(m['cameraMatrix']);dist=np.array(m['distCoeffs']);obs=[]
    for p in sorted((SPLIT/'train'/pose/'3D').glob('*.jpg')):
        h=hashlib.sha256(p.read_bytes()).hexdigest();cache=next((BASE/'per_pose_models'/pose/'.trihedral_correspondence_cache').glob(h+'_sq25_*.npz'))
        obs+=_local_face_observations([_load_cache(str(cache),str(p),None)],25)
    observation=obs[0];cols,nrows=observation['pattern'];obj=np.array([[c*25,r*25,0] for r in range(nrows) for c in range(cols)],float);img=np.asarray(observation['points'],float)
    ok,rv,tv=cv2.solvePnP(obj,img,K,dist);assert ok
    for dtype in [np.float32,np.float64]:
        points,jac=cv2.projectPoints(obj.astype(dtype),rv,tv,K,dist)
        for k in [0,1]:
            h=np.sqrt(np.finfo(float).eps)*max(1,abs(dist[k]));d=dist.copy();d[k]+=h
            pert,_=cv2.projectPoints(obj.astype(dtype),rv,tv,K,d)
            numerical=(pert.astype(float)-points.astype(float)).ravel()/h
            analytical=jac[:,10+k]
            rows.append(dict(pose=pose,coefficient='k'+str(k+1),object_dtype=np.dtype(dtype).name,projection_dtype=str(points.dtype),step=h,zero_fraction=float(np.mean(numerical==0)),relative_jacobian_error=float(np.linalg.norm(numerical-analytical)/np.linalg.norm(analytical))))
(out/'finite_difference_precision.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print(json.dumps(rows,indent=2))
