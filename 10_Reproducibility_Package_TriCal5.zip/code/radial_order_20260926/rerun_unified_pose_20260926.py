"""Frozen uniform pose routing, all existing 0820 test images; no model refit."""
from pathlib import Path
import sys,os,subprocess,hashlib
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import cv2
import trained_camera_model as t
import evaluate_trained_camera_model as ev
import evaluate_planar_blind_comparison as ep
from evaluate_planar_per_pose_controlled import image_dir
from run_stability_verification_20260914 import ROOT,SPLIT,BASE,POSES,read,save
OUT=ROOT/'output/unified_pose_evaluation_20260926'
OLD=ROOT/'output/stability_verification_20260914/models'
INFO=ROOT/'output/information_budget_20260915'
def run(pose):
    cv2.setNumThreads(1);pi=POSES.index(pose)
    models=[]
    p=INFO/pose/'subset_01234.json';models.append(('ratio_base',read(p),p))
    for name in ['production_ratio','no_ratio_base','zhang_reference']:
        p=OLD/pose/('ratio_base' if name=='production_ratio' else name)/'trained_camera_model.json';models.append((name,read(p),p))
    manifest=read(INFO/pose/'test_manifest.json')
    if pose=='45_1.155':
        for i,tr in enumerate(manifest['training']):
            name=Path(tr['image']).name
            if name in ['t_4_10.jpg','t_4_17.jpg']:
                p=INFO/pose/f'subset_{i}.json';models.append((name,read(p),p))
    rows=[];failures=[];inputs=[];regression=[]
    legacy={}
    for name,m,p in models:
        if name=='ratio_base':previous=read(INFO/pose/'subset_01234.json')
        elif name.endswith('.jpg'):previous=m
        else:continue
        legacy[name]={(r['kind'],r['image']):r for r in previous['evaluation']}
    for kind in ['2D','3D']:
        folder=image_dir(SPLIT,pose) if kind=='2D' else SPLIT/'test'/pose/'3D'
        for n,p in enumerate(sorted(folder.glob('*.jpg'))):
            try:
                if kind=='2D':
                    im,det=ep.detect_checker(p)
                    if im is None:raise ValueError(det)
                    obj=ep.object_points(25);ids=np.zeros(len(obj),int)
                else:
                    h=hashlib.sha256(p.read_bytes()).hexdigest();cs=list((BASE/'test_correspondence_cache'/pose).glob(h+'_sq25_*.npz'));assert len(cs)==1
                    cv2.setRNGSeed(20260912);s=t.extract_correspondences(str(p),25,correspondence_cache_path=str(cs[0]),minimum_usable_faces=1)
                    obj,im=s.object_points,s.image_points;ids=ev.face_ids(obj)
                faces=len(np.unique(ids));planar=kind=='2D' or faces==1
                local=obj
                if kind=='3D' and planar:
                    axes=np.argsort(np.ptp(obj,axis=0))[-2:];local=np.zeros_like(obj);local[:,:2]=obj[:,axes]
                bins=np.digitize(np.linalg.norm((im.reshape(-1,2)-[960,540])/[960,540],axis=1),[.4,.7])
                rng=np.random.default_rng(915000+pi*1000+n);splits=[ev.stratified_holdout(ids,rng,.2,4) for _ in range(5)]
                inputs.append(dict(kind=kind,image=p.name,faces=faces,points=len(obj),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),route='plane' if planar else 'rigid'))
            except Exception as e:failures.append(dict(kind=kind,image=p.name,error=str(e)));continue
            for name,m,source in models:
                K=np.array(m['cameraMatrix']);dist=np.array(m['distCoeffs']);groups=[[],[],[]];old=[];new=[];success=0
                for r,(tr,te) in enumerate(splits):
                    cv2.setRNGSeed(915000+r)
                    solver=ep if planar else ev
                    fit=solver.solve_pose(local,im,tr,K,dist)
                    if fit is not None:
                        err=solver.project_errors(local,im,te,fit,K,dist)
                        if np.all(np.isfinite(err)):
                            success+=1;new.extend(err.tolist())
                            for b in range(3):groups[b].extend(err[bins[te]==b].tolist())
                    if kind=='3D' and planar:
                        cv2.setRNGSeed(915000+r);q=ev.solve_pose(obj,im,tr,K,dist)
                        if q is not None:old.extend(ev.project_errors(obj,im,te,q,K,dist).tolist())
                rm=lambda a:float(np.sqrt(np.mean(np.square(a)))) if a else None
                oldrm=rm(old) if kind=='3D' and planar else rm(new)
                rows.append(dict(model=name,accepted=m.get('accepted'),kind=kind,image=p.name,faces=faces,route='plane' if planar else 'rigid',rmse=rm(new),old_rmse=oldrm,successful_trials=success,total_trials=5,regions=[dict(bin=b,n=len(g),rmse=rm(g)) for b,g in enumerate(groups)]))
                if name in legacy and (kind,p.name) in legacy[name]:
                    rr=legacy[name][(kind,p.name)];gg=[q for q in rr['regions'] if q['n'] and q['rmse'] is not None]
                    val=float(np.sqrt(sum(q['n']*q['rmse']**2 for q in gg)/sum(q['n'] for q in gg))) if gg else None
                    if val is not None and oldrm is not None:regression.append(abs(val-oldrm))
    save(OUT/pose/'results.json',dict(inputs=inputs,failures=failures,models=[dict(name=n,source=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),accepted=m.get('accepted')) for n,m,p in models],rows=rows,legacy_regression_max_abs=max(regression) if regression else None))
    print(pose,len(rows),'rows; legacy maxdiff',max(regression) if regression else None,flush=True)
def launch(pose):
    env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONIOENCODING='utf-8')
    with (OUT/(pose+'.log')).open('w',encoding='utf-8') as log:
        r=subprocess.run([sys.executable,__file__,pose],env=env,stdout=log,stderr=subprocess.STDOUT)
    print(pose,r.returncode,flush=True)
if __name__=='__main__':
    if len(sys.argv)>1:run(sys.argv[1])
    else:
        save(OUT/'protocol.json',dict(rule='2D or exactly one valid 3D face: local metric plane and IPPE/iterative candidate solver; >=2 faces: unchanged rigid solver; candidate selection only on pose-training points',repeats=5,seed='915000+pose_index*1000+filename_index',models='5 matched diagnostic five-image ratio_base models; 5 production_ratio models; 5 no-ratio baselines including rejected diagnostics; 5 MATLAB references; 2 successful strict-three-face single fits',scope='post-hoc evaluator revision after error audit; no new data/model training; do not overwrite historical scores; diagnostic and production source identities kept distinct',source_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
        with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(launch,POSES))
