import numpy as np
from rerun_unified_pose_20260926 import OUT,POSES,read,save
from analyze_existing_predictions_20260926 import stats
from deepen_evidence_20260926 import bootstrap
summaries=[];paired=[];lines=['# 0820统一位姿评价复核','','规则：单面使用局部平面IPPE/迭代候选，多面保留刚体求解；候选只按位姿训练角点评分。全部模型用相同点和五次留出划分。未训练或改变相机模型。规则来自事后审计，本轮不是新盲测。','','|配置|模型|类型|图数|新中位数|旧中位数|新P95|旧P95|新最大|<=2px %|<=3px %|','|---|---|---|---|---|---|---|---|---|---|---|']
for pose in POSES:
    p=OUT/pose/'results.json'
    if not p.exists():continue
    d=read(p)
    for name in sorted({r['model'] for r in d['rows']}):
        for kind in ['2D','3D']:
            rows=[r for r in d['rows'] if r['model']==name and r['kind']==kind]
            a=stats([r['rmse'] for r in rows if r['rmse'] is not None]);b=stats([r['old_rmse'] for r in rows if r['old_rmse'] is not None])
            summaries.append(dict(pose=pose,model=name,kind=kind,new=a,old=b,successful_trials=sum(r['successful_trials'] for r in rows),total_trials=sum(r['total_trials'] for r in rows)))
            q=a['threshold_percent'];lines.append(f"|{pose}|{name}|{kind}|{a['n']}|{a['median']:.3f}|{b['median']:.3f}|{a['p95']:.3f}|{b['p95']:.3f}|{a['maximum']:.3f}|{q['2']:.1f}|{q['3']:.1f}|")
            if name!='ratio_base':
                ref={r['image']:r for r in d['rows'] if r['model']=='ratio_base' and r['kind']==kind};aa=[];bb=[]
                for r in rows:
                    if r['rmse'] is not None and ref[r['image']]['rmse'] is not None:aa.append(r['rmse']);bb.append(ref[r['image']]['rmse'])
                pair=bootstrap(aa,bb);pair['direction']='named model minus ratio_base; negative favors named model'
                paired.append(dict(pose=pose,model=name,kind=kind,**pair))
    for name in sorted({r['model'] for r in d['rows']}):
        for faces in [1,2,3]:
            rr=[r for r in d['rows'] if r['kind']=='3D' and r['model']==name and r['faces']==faces]
            summaries.append(dict(pose=pose,model=name,kind='3D',faces=faces,new=stats([r['rmse'] for r in rr if r['rmse'] is not None])))
save(OUT/'summary.json',dict(summary=summaries,paired=paired))
lines+=['','## 配对差值与区间','','差值=该模型减ratio_base；按图片10000次配对bootstrap。跨零不代表等效，未作多重比较校正。','','|配置|模型|类型|差值中位数|95%区间|','|---|---|---|---|---|']
for r in paired:lines.append(f"|{r['pose']}|{r['model']}|{r['kind']}|{r['median_paired_difference']:.4f}|[{r['ci95'][0]:.4f},{r['ci95'][1]:.4f}]|")
lines+=['','新旧对比采用相同五次划分与逐图合并角点RMSE，不与历史20次试验中位数混用。no_ratio中包括未通过发布门限的模型，仅作为诊断。逐图、分区域、有效面数、求解成功次数均保存在各配置results.json。']
(OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8');print('\n'.join(lines[:27]))
