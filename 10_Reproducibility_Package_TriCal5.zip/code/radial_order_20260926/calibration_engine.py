"""
Calibration Engine — wraps three_face_calib and computes derived parameters.

Derived parameters in the calibration system (标定体系):
  1. Variable focal length: fx, fy (pixels) — from K
  2. Installation height: camera height above ground (mm) — from t
  3. Downtilt angle: angle between optical axis and horizontal plane (deg)
  4. Error-compensation polynomial: 2D bivariate fit of residual errors
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import cv2
import numpy as np
from scipy.optimize import least_squares

# Import from the core calibration module
from three_face_calib import (
    FaceDefinition, DetectedFace, CalibrationResult, VanishingPoint,
    standard_three_face_target, fit_line_tls,
    lines_from_chessboard_corners, estimate_vanishing_point,
    calibrate_intrinsics_from_vps, calibrate_extrinsics,
    estimate_distortion_from_lines, bundle_adjust,
    preprocess_image, get_vp_labels, compute_corner_sharpness,
    estimate_blur_level, adaptive_subpix_window, detect_corners_multiscale,
    object_points_for_face, apply_best_face_orientations,
)


# ──────────────────────────── Derived Parameters ────────────────────────────

DEFAULT_SQUARE_SIZE_MM = 25.0
# Backward-compatible alias for older probes; this is a dataset default, not
# a hard calibration prior.
FIXED_SQUARE_SIZE_MM = DEFAULT_SQUARE_SIZE_MM


@dataclass
class SystemParams:
    """The calibration-system parameters derived from (K, R, t, dist)."""
    # Focal lengths
    fx_px: float
    fy_px: float
    # Principal point
    cx_px: float
    cy_px: float
    # Distortion
    k1: float; k2: float; p1: float; p2: float; k3: float
    # Installation height (mm) — Y component of camera position in world frame
    install_height_mm: float
    # Downtilt angle (degrees) — angle between optical axis and horizontal plane
    downtilt_deg: float
    # Camera position in world frame (mm)
    cam_x_mm: float; cam_y_mm: float; cam_z_mm: float
    # Reprojection RMSE
    reproj_rmse_px: float
    # Polynomial coefficients for error compensation (if fitted)
    poly_degree: int = 2
    poly_coeffs_u: Optional[np.ndarray] = None  # for u-error surface
    poly_coeffs_v: Optional[np.ndarray] = None  # for v-error surface
    poly_rmse_u: float = 0.0
    poly_rmse_v: float = 0.0


def compute_system_params(
    result: CalibrationResult,
    image_points: np.ndarray,
    object_points: np.ndarray,
    poly_degree: int = 3,
) -> SystemParams:
    """Compute the calibration-system parameters from a CalibrationResult.

    Parameters
    ----------
    result : CalibrationResult from calibrate()
    image_points : (N, 2) detected corner positions
    object_points : (N, 3) corresponding world points
    poly_degree : degree for error-compensation polynomial (0 = skip)

    Returns
    -------
    SystemParams
    """
    K = result.K
    R = result.R
    t = result.t
    dist = result.dist if len(result.dist) >= 5 else np.zeros(5)

    # ── 1. Focal lengths ──
    fx_px = float(K[0, 0])
    fy_px = float(K[1, 1])
    cx_px = float(K[0, 2])
    cy_px = float(K[1, 2])

    # ── 2. Installation height ──
    # Camera position in world frame: C = -Rᵀ·t
    cam_pos = -R.T @ t
    install_height_mm = float(cam_pos[1])  # Y is up in world frame

    # ── 3. Downtilt angle ──
    # Optical axis in world frame = Rᵀ · [0, 0, 1]ᵀ = third column of Rᵀ = third row of R
    # Actually: camera looks along -Z in camera frame.
    # Direction in world: d_world = Rᵀ · [0, 0, -1]ᵀ  (forward is -Z)
    optical_axis_cam = np.array([0., 0., -1.])  # OpenCV convention: camera looks down -Z
    optical_axis_world = R.T @ optical_axis_cam
    # Downtilt: angle between optical axis and horizontal plane (XZ plane)
    # horizontal component magnitude of optical axis
    horiz_norm = np.hypot(optical_axis_world[0], optical_axis_world[2])
    downtilt_rad = np.arctan2(-optical_axis_world[1], horiz_norm)
    downtilt_deg = float(np.rad2deg(downtilt_rad))

    # ── 4. Error-compensation polynomial ──
    poly_coeffs_u, poly_coeffs_v = None, None
    poly_rmse_u, poly_rmse_v = 0.0, 0.0

    if poly_degree > 0 and image_points.shape[0] >= 6:
        # Compute reprojected points to get residuals
        img_pts = image_points.reshape(-1, 2).astype(np.float64)
        obj_pts = object_points.reshape(-1, 3).astype(np.float64)

        proj, _ = cv2.projectPoints(
            obj_pts.reshape(-1, 1, 3),
            cv2.Rodrigues(R)[0], t, K, dist,
        )
        proj = proj.reshape(-1, 2)

        residuals_u = img_pts[:, 0] - proj[:, 0]
        residuals_v = img_pts[:, 1] - proj[:, 1]

        poly_coeffs_u, poly_rmse_u = _fit_bivariate_polynomial(
            img_pts[:, 0], img_pts[:, 1], residuals_u, poly_degree,
        )
        poly_coeffs_v, poly_rmse_v = _fit_bivariate_polynomial(
            img_pts[:, 0], img_pts[:, 1], residuals_v, poly_degree,
        )

    return SystemParams(
        fx_px=fx_px, fy_px=fy_px,
        cx_px=cx_px, cy_px=cy_px,
        k1=float(dist[0]), k2=float(dist[1]),
        p1=float(dist[2]), p2=float(dist[3]), k3=float(dist[4]),
        install_height_mm=install_height_mm,
        downtilt_deg=downtilt_deg,
        cam_x_mm=float(cam_pos[0]),
        cam_y_mm=float(cam_pos[1]),
        cam_z_mm=float(cam_pos[2]),
        reproj_rmse_px=result.reproj_error,
        poly_degree=poly_degree,
        poly_coeffs_u=poly_coeffs_u,
        poly_coeffs_v=poly_coeffs_v,
        poly_rmse_u=poly_rmse_u,
        poly_rmse_v=poly_rmse_v,
    )


def _poly_basis_matrix(x: np.ndarray, y: np.ndarray, degree: int) -> np.ndarray:
    """Build design matrix for bivariate polynomial of given degree.

    Columns: 1, x, y, x², xy, y², x³, x²y, xy², y³, ...
    """
    N = len(x)
    terms = []
    for d in range(degree + 1):
        for i in range(d + 1):
            j = d - i
            terms.append((x ** i) * (y ** j))
    return np.column_stack(terms)


def _term_labels(degree: int) -> List[str]:
    """Human-readable labels for polynomial terms."""
    labels = []
    for d in range(degree + 1):
        for i in range(d + 1):
            j = d - i
            if i == 0 and j == 0:
                labels.append("1")
            elif i == 0:
                labels.append(f"y^{j}" if j > 1 else "y")
            elif j == 0:
                labels.append(f"x^{i}" if i > 1 else "x")
            else:
                labels.append(f"x^{i}y^{j}" if i > 1 else f"xy^{j}" if j > 1 else f"xy")
    return labels


def _fit_bivariate_polynomial(
    x: np.ndarray, y: np.ndarray, z: np.ndarray, degree: int,
) -> Tuple[np.ndarray, float]:
    """Least-squares fit of a 2D polynomial z = P(x, y).

    Returns (coeffs, rmse).
    """
    A = _poly_basis_matrix(x, y, degree)
    coeffs, residuals, rank, singular = np.linalg.lstsq(A, z, rcond=None)
    z_pred = A @ coeffs
    rmse = float(np.sqrt(np.mean((z - z_pred) ** 2)))
    return coeffs, rmse


def apply_error_correction(
    u: np.ndarray, v: np.ndarray,
    sys_params: SystemParams,
) -> Tuple[np.ndarray, np.ndarray]:
    """Apply the error-compensation polynomial to correct image coordinates.

    u_corrected = u + P_u(u, v)
    v_corrected = v + P_v(u, v)
    """
    if sys_params.poly_coeffs_u is None or sys_params.poly_coeffs_v is None:
        return u.copy(), v.copy()
    A = _poly_basis_matrix(u, v, sys_params.poly_degree)
    du = A @ sys_params.poly_coeffs_u
    dv = A @ sys_params.poly_coeffs_v
    return u + du, v + dv


# ──────────────────────── Full Pipeline Wrapper ────────────────────────────

def run_full_calibration(
    image_path: str,
    square_size_mm: float = DEFAULT_SQUARE_SIZE_MM,
    pattern_cols: int = 9,
    pattern_rows: int = 6,
    poly_degree: int = 3,
    verbose: bool = True,
    face_patterns: Optional[List[Tuple[int, int]]] = None,
    n_faces: int = 3,
    auto_orient_faces: bool = True,
) -> Tuple[Optional[CalibrationResult], Optional[SystemParams], dict]:
    """Run the complete calibration pipeline and compute system parameters.

    Parameters
    ----------
    face_patterns : optional list of 3 (cols, rows), one per face [A, B, C].

    Returns (calib_result, system_params, diagnostics).
    """
    diagnostics = {
        'status': 'pending', 'message': '', 'warnings': [],
        'detection': {}, 'timing': {},
    }

    # ── Load image (Unicode-safe) ──
    square_size_mm = float(square_size_mm)
    if not np.isfinite(square_size_mm) or square_size_mm <= 0:
        diagnostics['status'] = 'error'
        diagnostics['message'] = (
            'square_size_mm must be a positive finite checkerboard square '
            'edge length in physical units, e.g. millimetres.'
        )
        return None, None, diagnostics

    if not os.path.exists(image_path):
        diagnostics['status'] = 'error'
        diagnostics['message'] = f'File not found: {image_path}'
        return None, None, diagnostics
    with open(image_path, 'rb') as f:
        data = np.frombuffer(f.read(), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        diagnostics['status'] = 'error'
        diagnostics['message'] = f'Cannot decode: {image_path}'
        return None, None, diagnostics

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h_img, w_img = gray.shape[:2]

    # ── Build target definition ──
    faces = standard_three_face_target(
        square_size=square_size_mm, cols=pattern_cols, rows=pattern_rows,
        face_patterns=face_patterns, n_faces=n_faces,
        center_patterns_on_cube=True,
    )
    vp_labels = get_vp_labels(n_faces)

    # ── Step 0: CLAHE preprocessing ──
    gray_enhanced = preprocess_image(gray)
    images_to_try = [("enhanced", gray_enhanced), ("original", gray)]

    # ── Step 1: Corner detection ──
    detected_faces: List[DetectedFace] = []
    detection_info = []
    cube_first = []
    if n_faces >= 2:
        try:
            from face_detector import detect_corner_cube_faces
            cube_first = detect_corner_cube_faces(gray, n_faces=n_faces, verbose=verbose)
        except Exception as exc:
            diagnostics['warnings'].append(f'Cube-first detector failed: {exc}')

    if len(cube_first) >= n_faces:
        detected_patterns = [pat for _corners, pat, _label in cube_first[:n_faces]]
        faces = standard_three_face_target(
            square_size=square_size_mm, cols=pattern_cols, rows=pattern_rows,
            face_patterns=detected_patterns, n_faces=n_faces,
            center_patterns_on_cube=True,
        )
        vp_labels = get_vp_labels(n_faces)
        diagnostics['warnings'].append(
            'Used cube-first face detection (cube -> visible faces -> grids).'
        )

        for fi, ((best_corners, pat, label), face) in enumerate(zip(cube_first, faces)):
            cols, rows = face.pattern_size
            blur_score = estimate_blur_level(gray, best_corners)
            win_w, win_h = adaptive_subpix_window(blur_score)
            corners_sub = cv2.cornerSubPix(
                gray, best_corners.astype(np.float32), (win_w, win_h), (-1, -1),
                (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-6),
            )

            obj_pts = object_points_for_face(face)

            detected_faces.append(DetectedFace(
                image_points=corners_sub, object_points=obj_pts, valid=True,
            ))
            detection_info.append({
                'face': fi, 'status': 'ok',
                'corners': len(corners_sub), 'source': 'cube-first',
                'label': label, 'pattern': pat,
            })

    elif cube_first:
        diagnostics['warnings'].append(
            f'Cube-first found only {len(cube_first)}/{n_faces} faces; '
            'falling back to direct pattern detection.'
        )
    for fi, face in enumerate([] if detected_faces else faces):
        cols, rows = face.pattern_size
        best_corners = None
        best_src = ""
        for src_name, src_img in images_to_try:
            ok, corners = cv2.findChessboardCorners(
                src_img, (cols, rows),
                flags=cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE,
            )
            if ok:
                best_corners = corners
                best_src = src_name
                break

        # Multi-scale fallback for blurry faces
        if best_corners is None:
            ms_corners = detect_corners_multiscale(gray_enhanced, (cols, rows))
            if ms_corners is not None:
                best_corners = ms_corners
                best_src = "enhanced"

        if best_corners is None:
            detection_info.append({'face': fi, 'status': 'not_found'})
            detected_faces.append(DetectedFace(
                image_points=np.zeros((0, 1, 2), dtype=np.float32),
                object_points=np.zeros((0, 1, 3), dtype=np.float32),
                valid=False,
            ))
            continue

        ref_img = gray_enhanced if best_src == "enhanced" else gray
        blur_score = estimate_blur_level(ref_img, best_corners)
        win_w, win_h = adaptive_subpix_window(blur_score)
        corners_sub = cv2.cornerSubPix(
            ref_img, best_corners, (win_w, win_h), (-1, -1),
            (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-6),
        )

        obj_pts = object_points_for_face(face)

        detected_faces.append(DetectedFace(
            image_points=corners_sub, object_points=obj_pts, valid=True,
        ))
        detection_info.append({
            'face': fi, 'status': 'ok',
            'corners': len(corners_sub), 'source': best_src,
        })

    # ── Compute per-point sharpness weights ──
    corner_weights = []
    for df in detected_faces:
        if df.valid and df.image_points.shape[0] > 0:
            corner_weights.append(compute_corner_sharpness(gray, df.image_points))

    diagnostics['detection'] = detection_info
    valid_idx = [i for i, df in enumerate(detected_faces) if df.valid]
    n_valid = len(valid_idx)

    if n_valid < 1:
        diagnostics['status'] = 'error'
        diagnostics['message'] = f'No faces detected.'
        return None, None, diagnostics

    all_detected_pts = np.vstack([
        detected_faces[i].image_points.reshape(-1, 2) for i in valid_idx
    ])
    x_span = float(all_detected_pts[:, 0].max() - all_detected_pts[:, 0].min())
    y_span = float(all_detected_pts[:, 1].max() - all_detected_pts[:, 1].min())
    target_coverage_pct = x_span * y_span / float(w_img * h_img) * 100.0
    diagnostics['target_coverage_pct'] = target_coverage_pct
    min_target_coverage_pct = 2.0
    warn_target_coverage_pct = 4.0
    if target_coverage_pct < min_target_coverage_pct:
        diagnostics['status'] = 'error'
        diagnostics['message'] = (
            f'Calibration target too small ({target_coverage_pct:.2f}% of image). '
            f'Minimum is {min_target_coverage_pct:.1f}%; move the camera closer '
            f'or use this distance as the calibration boundary.'
        )
        diagnostics['warnings'].append(diagnostics['message'])
        return None, None, diagnostics
    if target_coverage_pct < warn_target_coverage_pct:
        diagnostics['warnings'].append(
            f'Target coverage is only {target_coverage_pct:.2f}% of image; '
            f'{warn_target_coverage_pct:.1f}%+ is recommended for stable calibration.'
        )

    if n_valid < n_faces:
        diagnostics['warnings'].append(f'Only {n_valid}/{n_faces} faces detected.')

    # ── Step 2: Vanishing points ──
    vp_per_face = []
    for fi, df in enumerate(detected_faces):
        if not df.valid:
            vp_per_face.append({})
            continue
        face = faces[fi]
        cols, rows = face.pattern_size
        row_lines, col_lines, rq, cq = lines_from_chessboard_corners(
            df.image_points, (cols, rows), use_ransac=True,
        )
        if max(rq, cq) > 1.0:
            diagnostics['warnings'].append(
                f'Face {fi}: line-fit RMS r={rq:.2f} c={cq:.2f} px'
            )
        # rows contain points with varying column index, i.e. face.axis_x;
        # columns contain points with varying row index, i.e. face.axis_y.
        vp_axis_x = estimate_vanishing_point(np.array(row_lines))
        vp_axis_y = estimate_vanishing_point(np.array(col_lines))
        vp_axis_x.direction_label = vp_labels[fi][0]
        vp_axis_y.direction_label = vp_labels[fi][1]
        vp_per_face.append({vp_labels[fi][0]: vp_axis_x,
                            vp_labels[fi][1]: vp_axis_y})

    vp_avg: dict = {}
    for label in ["X", "Y", "Z"]:
        V = np.array([vp.v for fv in vp_per_face
                      for l, vp in fv.items() if l == label])
        if len(V) == 0:
            continue
        vm = np.median(V, axis=0)
        if abs(vm[2]) > 1e-6:
            vm /= vm[2]
        vp_avg[label] = VanishingPoint(v=vm, direction_label=label)

    # ── Step 3: IAC intrinsic calibration (must precede distortion est.) ──
    labels_ordered = sorted(vp_avg.keys())
    vp_list = [vp_avg[l] for l in labels_ordered]
    label_to_idx = {l: i for i, l in enumerate(labels_ordered)}
    ortho_pairs = [(label_to_idx[a], label_to_idx[b])
                   for a, b in [("X", "Y"), ("Y", "Z"), ("Z", "X")]
                   if a in label_to_idx and b in label_to_idx]

    K_init = calibrate_intrinsics_from_vps(
        vp_list, ortho_pairs,
        assume_zero_skew=True,
        assume_square_pixels=True,
        fix_principal_point=(w_img / 2, h_img / 2),
    )

    # ── Step 4: Distortion estimation (uses K_init from IAC) ──
    dist_est = estimate_distortion_from_lines(
        detected_faces, faces, K_init, verbose=False,
    )

    # ── Step 5: PnP ──
    if auto_orient_faces:
        orientations = apply_best_face_orientations(
            detected_faces, faces, valid_idx, K_init, None,
        )
        flipped = [o for o in orientations if o['flip_x'] or o['flip_y']]
        if flipped:
            desc = ', '.join(
                f"face {o['face']}:"
                f"{'x' if o['flip_x'] else ''}{'y' if o['flip_y'] else ''}"
                for o in flipped
            )
            diagnostics['warnings'].append(
                f"Auto-selected physical grid orientation ({desc}); "
                f"PnP RMSE {orientations[0]['rmse']:.2f}px before BA."
            )

    all_obj = np.vstack([detected_faces[i].object_points for i in valid_idx])
    all_img = np.vstack([detected_faces[i].image_points for i in valid_idx])

    R_init, t_init = calibrate_extrinsics(all_obj, all_img, K_init)

    # ── Step 6: Bundle adjustment (with k2 regularisation) ──
    all_weights = np.concatenate(corner_weights) if corner_weights else None
    K_opt, dist_opt, R_opt, t_opt, err_final = bundle_adjust(
        K_init, R_init, t_init,
        all_obj.reshape(-1, 3), all_img.reshape(-1, 2),
        dist_init=dist_est,
        with_distortion=True,
        full_distortion=True,
        k2_reg_weight=0.05,  # prevent k2 overfitting
        weights=all_weights,
    )

    def _projection_rmse(K, dist, R, t):
        proj, _ = cv2.projectPoints(
            all_obj.reshape(-1, 1, 3).astype(np.float64),
            cv2.Rodrigues(R)[0], t, K, dist,
        )
        diff = proj.reshape(-1, 2) - all_img.reshape(-1, 2)
        return float(np.sqrt(np.mean(np.sum(diff * diff, axis=1))))

    def _ba_result_is_sane(K, err):
        fx, fy = float(K[0, 0]), float(K[1, 1])
        cx, cy = float(K[0, 2]), float(K[1, 2])
        if not np.all(np.isfinite(K)) or not np.isfinite(err):
            return False
        if fx <= 0 or fy <= 0:
            return False
        if max(fx, fy) / max(min(fx, fy), 1e-6) > 1.15:
            return False
        if cx < -0.25 * w_img or cx > 1.25 * w_img:
            return False
        if cy < -0.25 * h_img or cy > 1.25 * h_img:
            return False
        if err > 5.0:
            return False
        return True

    used_vp_only_fallback = False
    if not _ba_result_is_sane(K_opt, err_final):
        used_vp_only_fallback = True
        diagnostics['warnings'].append(
            'Bundle adjustment was rejected by the physical sanity gate; '
            'using VP-only intrinsics. Extrinsics/height remain approximate; '
            'target layout is inferred from checkerboard square size only.'
        )
        K_opt = K_init.copy()
        dist_opt = np.zeros(5, dtype=np.float64)
        R_opt = R_init.copy()
        t_opt = t_init.copy()
        err_final = _projection_rmse(K_opt, dist_opt, R_opt, t_opt)

    result = CalibrationResult(
        K=K_opt, dist=dist_opt, R=R_opt, t=t_opt,
        reproj_error=err_final,
        vanishing_points={l: vp.v for l, vp in vp_avg.items()},
    )

    # ── Compute system parameters ──
    sys_params = compute_system_params(
        result,
        all_img.reshape(-1, 2),
        all_obj.reshape(-1, 3),
        poly_degree=0 if used_vp_only_fallback else poly_degree,
    )

    diagnostics['status'] = 'ok'
    diagnostics['message'] = f'Calibration OK — RMSE {err_final:.4f} px'

    if used_vp_only_fallback:
        diagnostics['message'] = (
            f'VP-only intrinsic calibration OK; full 3D BA was rejected. '
            f'Projection RMSE with current target layout is {err_final:.4f} px.'
        )
    else:
        diagnostics['message'] = f'Calibration OK - RMSE {err_final:.4f} px'

    if verbose:
        print(f"Calibration complete: RMSE={err_final:.4f} px")
        print(f"  K = [{K_opt[0,0]:.1f}, {K_opt[1,1]:.1f}, "
              f"({K_opt[0,2]:.1f},{K_opt[1,2]:.1f})]")
        print(f"  dist = [{dist_opt[0]:.5f}, {dist_opt[1]:.5f}, "
              f"{dist_opt[2]:.5f}, {dist_opt[3]:.5f}, {dist_opt[4]:.5f}]")
        print(f"  t = [{t_opt[0]:.1f}, {t_opt[1]:.1f}, {t_opt[2]:.1f}] mm")
        print(f"  height = {sys_params.install_height_mm:.1f} mm")
        print(f"  downtilt = {sys_params.downtilt_deg:.2f}°")

    return result, sys_params, diagnostics


# ──────────────────────── Quick CLI ────────────────────────────────────────

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python calibration_engine.py <image_path> [square_size_mm] [cols] [rows]")
        sys.exit(1)

    path = sys.argv[1]
    ss = float(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_SQUARE_SIZE_MM
    c = int(sys.argv[3]) if len(sys.argv) > 3 else 9
    r = int(sys.argv[4]) if len(sys.argv) > 4 else 6

    result, sys_params, diag = run_full_calibration(path, ss, c, r, verbose=True)

    if result is None:
        print(f"ERROR: {diag['message']}")
        sys.exit(1)

    print(f"\n=== 标定体系参数 ===")
    print(f"  可变焦距:  fx={sys_params.fx_px:.2f} px  fy={sys_params.fy_px:.2f} px")
    print(f"  主点:      cx={sys_params.cx_px:.2f} px  cy={sys_params.cy_px:.2f} px")
    print(f"  安装高度:  {sys_params.install_height_mm:.2f} mm")
    print(f"  下倾角:    {sys_params.downtilt_deg:.3f}°")
    print(f"  摄像机位置: ({sys_params.cam_x_mm:.1f}, {sys_params.cam_y_mm:.1f}, {sys_params.cam_z_mm:.1f}) mm")
    print(f"  重投影RMSE: {sys_params.reproj_rmse_px:.4f} px")
    if sys_params.poly_coeffs_u is not None:
        print(f"  误差补偿多项式 ({sys_params.poly_degree}阶):")
        labels = _term_labels(sys_params.poly_degree)
        print(f"    du 拟合 RMSE = {sys_params.poly_rmse_u:.4f} px")
        print(f"    dv 拟合 RMSE = {sys_params.poly_rmse_v:.4f} px")
