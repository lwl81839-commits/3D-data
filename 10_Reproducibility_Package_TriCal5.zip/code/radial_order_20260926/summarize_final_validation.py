from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


POSES = ("15_0.528", "30_0.827", "45_0.827", "45_1.155", "60_1.155")
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def fmt(value: Any, digits: int = 3) -> str:
    return "-" if value is None else f"{float(value):.{digits}f}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--original-root", type=Path, required=True)
    parser.add_argument("--split-root", type=Path, required=True)
    args = parser.parse_args()
    original = args.original_root.resolve()
    split = args.split_root.resolve()
    validation = split / "validation_ours_vs_zhang"
    selection = json.loads(
        (validation / "reselection_exact_gate_v2" / "final_selection.json").read_text(
            encoding="utf-8"
        )
    )
    comparison = json.loads(
        (validation / "final_test_evaluation" / "comparison_summary.json").read_text(
            encoding="utf-8"
        )
    )
    comparison_rows = comparison["rows"]
    selected_by_pose = {
        pose: sorted(
            [row for row in selection if row["pose"] == pose],
            key=lambda row: int(row["image_index"]),
        )
        for pose in POSES
    }

    summaries: list[dict[str, Any]] = []
    all_hashes_match = True
    for pose in POSES:
        frame_key = lambda path: int(path.stem.rsplit("_", 1)[1])
        train3d = sorted((split / "train" / pose / "3D").glob("*.jpg"), key=frame_key)
        test3d = sorted((split / "test" / pose / "3D").glob("*.jpg"), key=frame_key)
        two_d_dirs = [split / "train" / pose / "2D", split / "train" / pose / "zhang_2d"]
        two_d_dir = next(path for path in two_d_dirs if path.is_dir())
        train2d = [
            path for path in two_d_dir.iterdir()
            if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES
        ]
        original3d = {path.name: path for path in (original / pose / "3D").glob("*.jpg")}
        mismatches = [
            str(path)
            for path in train3d + test3d
            if path.name not in original3d or sha256(path) != sha256(original3d[path.name])
        ]
        all_hashes_match = all_hashes_match and not mismatches

        model = json.loads(
            (validation / "per_pose_models" / pose / "trained_camera_model.json").read_text(
                encoding="utf-8"
            )
        )
        diagnostic = model["diagnostics"]
        cv = model["cross_validation"]
        selected = selected_by_pose[pose]
        if model["accepted"]:
            gate_note = "强制 k1+k2 模型通过全部训练质量门控。"
        else:
            candidate = model.get("candidate_comparison", {}).get("k1_k2", {})
            reasons = []
            folds_ok = int(cv.get("successful_folds") or 0)
            folds_total = int(cv.get("folds") or len(train3d))
            if folds_ok != folds_total:
                reasons.append(f"留一验证仅 {folds_ok}/{folds_total} 折成功")
            stability = candidate.get("k2_stability", {})
            if not stability.get("stable", False):
                reasons.append("k2 留一估计不稳定或接近优化边界")
            plausibility = candidate.get("intrinsic_plausibility", {})
            if not plausibility.get("accepted", False):
                reasons.append(
                    "主点或焦距纵横比未通过物理合理性门限"
                )
            if not reasons:
                reasons.append("未通过联合重投影或正深度质量门限")
            gate_note = "强制 k1+k2 模型已求解；" + "；".join(reasons) + "。"
        ours = next(
            row for row in comparison_rows
            if row["pose"] == pose and row["method"] == "ours_3d_5_images"
        )
        zhang = next(
            row for row in comparison_rows
            if row["pose"] == pose and row["method"] == "zhang_matlab_20_images"
        )
        summaries.append(
            {
                "pose": pose,
                "train_3d_images": [path.name for path in train3d],
                "train_3d_count": len(train3d),
                "all_selected_training_images_have_three_face_detection": all(
                    bool(row.get("three_faces_detected")) for row in selected
                ),
                "train_2d_count": len(train2d),
                "test_3d_count": len(test3d),
                "split_hash_mismatches": mismatches,
                "model_accepted": bool(model["accepted"]),
                "model_gate_note": gate_note,
                "training_joint_rmse_px": diagnostic.get("joint_reprojection_rmse_px"),
                "training_planar_face_observations": diagnostic.get("planar_face_observations"),
                "loo_successful_folds": cv.get("successful_folds"),
                "loo_folds": cv.get("folds"),
                "loo_median_rmse_px": cv.get("median_reprojection_rmse_px"),
                "ours_test": ours,
                "zhang_test": zhang,
            }
        )

    output = {
        "schema": "final-per-pose-validation-summary/v1",
        "original_root": str(original),
        "split_root": str(split),
        "all_split_3d_hashes_match_original": all_hashes_match,
        "training_rule": "five 3-D images with all three faces detected per pose",
        "test_rule": "use all formally usable detected faces: one, two, or three",
        "zhang_rule": "use existing MATLAB built-in calibration; no recalculation",
        "poses": summaries,
    }
    (validation / "FINAL_VALIDATION_SUMMARY.json").write_text(
        json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    lines = [
        "# 最终分姿态标定与测试报告",
        "",
        "## 执行口径",
        "",
        "- 每个姿态的三维训练集固定为 5 张，且 5 张均有三个面的检测证据。",
        "- 测试图检测到 1、2 或 3 个正式可用面，就使用相应的全部面。",
        "- Zhang 对照直接使用已有 MATLAB 内置算法结果（每姿态 20 张二维图），未重新标定。",
        "- 两种方法共用完全相同的测试角点、留出划分和随机种子。",
        f"- 分割后的全部三维图片与原图 SHA-256 一致：{'是' if all_hashes_match else '否'}。",
        "",
        "## 数据、训练与门控",
        "",
        "| 姿态 | 三维训练图 | 二维训练数 | 三维测试数 | 训练RMSE(px) | LOO成功 | LOO中位RMSE(px) | 发布门控 |",
        "|---|---|---:|---:|---:|---:|---:|---|",
    ]
    for item in summaries:
        lines.append(
            f"| {item['pose']} | {', '.join(item['train_3d_images'])} "
            f"| {item['train_2d_count']} | {item['test_3d_count']} "
            f"| {fmt(item['training_joint_rmse_px'])} "
            f"| {item['loo_successful_folds']}/{item['loo_folds']} "
            f"| {fmt(item['loo_median_rmse_px'])} "
            f"| {'通过' if item['model_accepted'] else '未通过'} |"
        )
    lines.extend([
        "",
        "说明：`45_0.827` 与 `60_1.155` 均已成功求出参数并完成测试，但未通过附加发布门控：",
        "",
        "- `45_0.827`：主点 x 偏移 104.435 px，超过 59.4 px 门限。",
        "- `60_1.155`：留一交叉验证仅 3/5 折成功。",
        "",
        "## 测试对比",
        "",
        "| 姿态 | 方法 | 成功图/总图 | 面数(1/2/3) | 留出RMSE(px) | 物点RMSE(mm) | 长度相对误差(%) | 跨面RMSE(px) | 直线RMS(px) |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ])
    for item in summaries:
        for label, key in (("三维5图", "ours_test"), ("Zhang二维20图", "zhang_test")):
            row = item[key]
            lines.append(
                f"| {item['pose']} | {label} "
                f"| {row['test_images_extracted']}/{row['test_images_attempted']} "
                f"| {row['one_face_images']}/{row['two_face_images']}/{row['three_face_images']} "
                f"| {fmt(row['holdout_rmse_px_median'])} "
                f"| {fmt(row['object_point_rmse_mm_median'])} "
                f"| {fmt(row['length_rel_error_pct_median'])} "
                f"| {fmt(row['cross_face_prediction_rmse_px_median'])} "
                f"| {fmt(row['undistorted_line_rms_px_median'])} |"
            )
    lines.extend([
        "",
        "跨面 RMSE 只在测试图含 3 个正式可用面时定义；显示 `-` 的姿态没有这样的测试图。",
    ])
    (validation / "FINAL_VALIDATION_REPORT.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    return 0 if all_hashes_match else 2


if __name__ == "__main__":
    raise SystemExit(main())
