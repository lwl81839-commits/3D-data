# Version-matched radial-order experiment (2026-09-26)

This experiment supersedes `k1_vs_k1k2_0820_20260926`, whose two branches used different solver versions. Both model orders here were freshly trained with the same float64-corrected source and identical five-image sets. Do not combine results from the two folders.

The isolated source snapshot is `10_Reproducibility_Package_TriCal5/code/radial_order_20260926`. The older code at the package root is historical and must not be substituted. Exact package versions and source hashes are in `environment_and_source_hashes.json`.

## Inputs

Use the original 0820 split: `train/<configuration>/3D/*.jpg` (five images each), `test/<configuration>/2D/*.jpg`, and `test/<configuration>/3D/*.jpg`. Preserve original image bytes and names. The dataset contains five configurations, 273 planar and 330 cuboid test images. Original images are supplied through the study's dataset release, not duplicated here.

Copy the supplied `test_correspondence_cache` folder into `<split-root>/validation_ours_vs_zhang/test_correspondence_cache`. It contains the cached 3D observations used in this experiment. Training caches are preserved under each `models_k1/<configuration>/.trihedral_correspondence_cache` and `models_k1_k2/<configuration>/.trihedral_correspondence_cache` directory. To reuse them, start with a copy of this experiment output folder; use a separate output folder if retaining the archived results is important. Do not delete or overwrite the original observations.

## Commands

From the isolated source snapshot, with the recorded scientific Python environment:

```powershell
python output/radial_order_matched_0820_20260926.py --split-root "PATH_TO_0820_SPLIT" --output-root "PATH_TO_WORKING_COPY_OF_EXPERIMENT"
```

This retrains both model orders and tests both. For scoring only, add `--evaluate-only`; both model families must already exist under the output root. The script accepts explicit roots rather than requiring the original E drive. The table-generation helper still points to the author's manuscript folder and is a local authoring aid, not needed for numerical reproduction.

One planar image fails complete-lattice detection; this remains a failure. All 272 detected planar and all 330 cached cuboid images completed five paired pose trials per model. The experiment measures conditional prediction on available correspondences, not end-to-end detection success. Bootstrap intervals are image-resampling intervals, not measurement uncertainty. No Zhang parameters enter either training branch.
