"""Regression checks and isolated production-source retraining after dtype fix."""
from pathlib import Path
import json, hashlib, shutil
import numpy as np
import cv2
import trained_camera_model as t
from ablate_0820_ratio_prior import ROOT, BASE, SPLIT, POSES
OUT=ROOT/'output/precision_fix_20260912'
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False),encoding='utf-8')
cv2.setNumThreads(1);cv2.setRNGSeed(20260912)
K=np.array([[1500.,0,960],[0,1480,540],[0,0,1]])
obj=np.array([[25*c,25*r,0] for r in range(7) for c in range(9)],np.float32)
rv=np.array([.4,-.3,.1]);tv=np.array([180.,90.,700.]);dist=np.array([-.2,.06,0,0,0])
img=cv2.projectPoints(obj.astype(float),rv,tv,K,dist)[0].reshape(-1,2).astype(np.float32)
real=t.least_squares;checks=[]
def checked(fun,x0,**kw):
    y=fun(x0);assert y.dtype==np.float64
    step=np.sqrt(np.finfo(float).eps);x=x0.copy();x[1]+=step
    num=(fun(x)-y)[:2*len(obj)]/step
    d=np.array([x0[0],x0[1],0,0,0]);jac=cv2.projectPoints(obj.astype(float),x0[2:5],x0[5:8],K,d)[1][:,11]
    relative=float(np.linalg.norm(num-jac)/np.linalg.norm(jac))
    assert relative<.001,relative
    checks.append(dict(dtype=str(y.dtype),k2_relative_derivative_error=relative))
    return real(fun,x0,**kw)
t.least_squares=checked
fitted,_,_,diag=t._refine_fixed_intrinsics_planar_radial([obj],[img],K,dist,[rv],[tv],2)
t.least_squares=real
assert diag['projection_residual_dtype']=='float64'
results=[]
for pose in POSES:
    d=OUT/'models'/pose;cache=d/'.trihedral_correspondence_cache';cache.mkdir(parents=True,exist_ok=True)
    paths=sorted((SPLIT/'train'/pose/'3D').glob('*.jpg'))
    for p in paths:
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        c=next((BASE/'per_pose_models'/pose/'.trihedral_correspondence_cache').glob(h+'_sq25_*.npz'));shutil.copy2(c,cache/c.name)
    cv2.setRNGSeed(20260912)
    m=t.train_camera_model([str(p) for p in paths],25,str(d/'trained_camera_model.json'),distortion_model='k1_k2')
    previous=json.loads((ROOT/'output/experiment_0820_precision_test/models'/pose/'float64/trained_camera_model.json').read_text())
    kd=float(np.max(np.abs(np.array(m['cameraMatrix'])-previous['cameraMatrix'])))
    dd=float(np.max(np.abs(np.array(m['distCoeffs'])-previous['distCoeffs'])))
    # Independent process/library state can alter terminal solver rounding.
    # This tolerance is a numerical regression bound, not accuracy acceptance.
    assert kd<1e-5 and dd<1e-5,(pose,kd,dd)
    results.append(dict(pose=pose,accepted=m['accepted'],K_max_difference=kd,dist_max_difference=dd,model=str(d/'trained_camera_model.json')))
    print(results[-1],flush=True)
save(OUT/'regression.json',dict(synthetic_checks=checks,training=results,source_sha256=hashlib.sha256((ROOT/'trained_camera_model.py').read_bytes()).hexdigest(),all_priors_unchanged=True,old_models_untouched=True))
