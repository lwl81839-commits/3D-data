"""Data-only local sensitivity and radial multistarts, conditional on cached patches."""
import sys,time
import numpy as np
import cv2
from run_stability_verification_20260914 import OUT,POSES,read,save
def run(pose,variant):
    sys.path.insert(0,str(OUT/'code'/variant));import trained_camera_model as t
    cv2.setNumThreads(1);cv2.setRNGSeed(20260912)
    job=read(OUT/'models'/pose/(variant+'_base')/'job.json')
    raw=[t._load_cache(x['cache'],x['image'],None) for x in job['selected']]
    real=t.least_squares;records=[]
    def fit_start(start):
        def wrapped(fun,x0,**kw):
            radial=len(x0)>8 and (len(x0)-2)%6==0
            if radial and start is not None:
                x0=x0.copy();x0[:2]=start
                lo,hi=kw['bounds'];x0=np.clip(x0,np.asarray(lo)+1e-7,np.asarray(hi)-1e-7)
            opt=real(fun,x0,**kw)
            if radial:
                c=dict(zip(fun.__code__.co_freevars,[x.cell_contents for x in fun.__closure__]))
                og=c['object_groups'];ig=c['image_groups'];K=c['K'];n=sum(len(x) for x in og)
                J=np.zeros((2*n,6+6*len(og)));off=0
                dist=np.array([*opt.x[:2],0,0,0.]);errors=[]
                for k,(o,im) in enumerate(zip(og,ig)):
                    sl=slice(off,off+2*len(o));ps=2+6*k
                    pr,j=cv2.projectPoints(o,opt.x[ps:ps+3],opt.x[ps+3:ps+6],K,dist)
                    J[sl,:2]=j[:,10:12];J[sl,2:6]=j[:,6:10];J[sl,6+6*k:12+6*k]=j[:,:6]
                    errors.extend((pr.reshape(-1,2)-im.reshape(-1,2)).ravel());off+=2*len(o)
                A=J[:,:2];N=J[:,2:];Ap=A-N@np.linalg.lstsq(N,A,rcond=1e-10)[0]
                sv=np.linalg.svd(Ap,compute_uv=False);norm=np.linalg.norm(Ap,axis=0)
                corr=float(Ap[:,0]@Ap[:,1]/np.prod(norm)) if np.prod(norm)>0 else None
                cov=np.linalg.pinv(Ap.T@Ap,rcond=1e-12)
                records.append(dict(start=start,solution=opt.x[:2].tolist(),data_component_rmse_px=float(np.sqrt(np.mean(np.square(errors)))),optimizer_success=bool(opt.success),n_points=n,projected_radial_column_correlation=corr,projected_singular_values=sv.tolist(),condition_number=float(sv[0]/sv[-1]) if sv[-1]>0 else None,unit_pixel_noise_linearized_std=np.sqrt(np.diag(cov)).tolist(),nuisance='fx,fy,cx,cy and independent local-plane poses; data-only unweighted Jacobian; no prior rows',scope='local diagnostic, not global confidence interval'))
            return opt
        t.least_squares=wrapped
        K,d,diag=t._fit_partial_planar_model(raw,25,2)
        t.least_squares=real
        records[-1]['K']=K.tolist();return d
    for start in [None,[-.6,.3],[.6,-.3]]:fit_start(start)
    save(OUT/'identifiability'/pose/(variant+'.json'),dict(pose=pose,variant=variant,trials=records,scope='fixed cached local patches; radial starting points varied after initialization clipping; not full production acceptance or independent acquisitions'))
    print(pose,variant,'done',flush=True)
if __name__=='__main__':run(*sys.argv[1:3])
