"""Summarize all outcomes, including rejected/failed fits. No threshold tuning."""
import csv,hashlib
import numpy as np
from run_stability_verification_20260914 import ROOT,OUT,POSES,read,save
def span(a):
    a=np.asarray(a,float);return dict(min=float(a.min()),max=float(a.max()),std=float(a.std()),range=float(np.ptp(a))) if a.size else None
def main():
    protocol=read(OUT/'protocol.json');rows=[];baseline=[];groups=[];ids=[]
    planar={p['pose']:p for p in read(OUT/'planar_summary.json')} if (OUT/'planar_summary.json').exists() else {}
    for j in protocol['jobs']:
        d=OUT/'models'/j['pose']/j['name'];status=read(d/'status.json') if (d/'status.json').exists() else dict(completed=False,pending=True)
        r={k:j[k] for k in ['pose','name','variant','tag','sigma','rep','omit']};r.update(status)
        if status['completed']:
            m=read(d/'trained_camera_model.json');K=np.array(m['cameraMatrix']);dist=np.array(m['distCoeffs']).ravel()
            r.update(fx=K[0,0],fy=K[1,1],cx=K[0,2],cy=K[1,2],k1=dist[0],k2=dist[1],loo=m['cross_validation'],gates=m['quality_gates'])
            r['training_face_counts']=[x.get('face_inlier_counts') for x in m['training_images']]
        rows.append(r)
    for pose in POSES:
        for v in ['ratio','no_ratio']:
            b=next(r for r in rows if r['pose']==pose and r['name']==v+'_base')
            z=dict(b)
            p=OUT/'evaluations'/pose/(v+'_base')/'evaluation.json'
            if p.exists():z['cuboid']=read(p)['summary']
            if pose in planar:z['planar']=planar[pose]['summaries']['ours_3d_5_images' if v=='ratio' else 'no_ratio']
            baseline.append(z)
            for group in ['noise0.1','noise0.3','omit']:
                g=[r for r in rows if r['pose']==pose and r['variant']==v and r['tag'].startswith(group)]
                complete=[r for r in g if r['completed']]
                groups.append(dict(pose=pose,variant=v,group=group,requested=len(g),completed=len(complete),accepted=sum(r.get('accepted',False) for r in g),pending=sum(r.get('pending',False) for r in g),parameters={k:span([r[k] for r in complete]) for k in ['fx','fy','cx','cy','k1','k2']},accepted_parameters={k:span([r[k] for r in complete if r['accepted']]) for k in ['fx','fy','cx','cy','k1','k2']}))
            p=OUT/'identifiability'/pose/(v+'.json')
            if p.exists():
                q=read(p);tr=q['trials'];ids.append(dict(pose=pose,variant=v,k1=span([x['solution'][0] for x in tr]),k2=span([x['solution'][1] for x in tr]),data_rmse=span([x['data_component_rmse_px'] for x in tr]),default=tr[0]))
    save(OUT/'verification_summary.json',dict(planned=len(rows),completed=sum(r['completed'] for r in rows),failed=sum(not r['completed'] and not r.get('pending',False) for r in rows),pending=sum(r.get('pending',False) for r in rows),baseline=baseline,sensitivity=groups,identifiability=ids,all_runs=rows))
    fields=['pose','name','variant','tag','completed','accepted','pending','fx','fy','cx','cy','k1','k2','elapsed_s','error']
    with (OUT/'parameter_runs.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
    lines=['# 0820 修正版稳定性复核（2026-09-14）','','本轮是已有数据上的复核，不是新盲测。原五张划分、模型、原始角点缓存不覆盖。所有失败和拒绝均保留。','',f"拟合任务 {len(rows)}；完成 {sum(r['completed'] for r in rows)}；执行失败 {sum(not r['completed'] and not r.get('pending',False) for r in rows)}；待完成 {sum(r.get('pending',False) for r in rows)}。",'','## 修正版完整基线与比例消融','','ratio保留经验比例先验；no_ratio移除比例初始化裁剪和比例惩罚，保留其他先验、数值边界和单调性惩罚。','二维为逐图留出RMSE中位数再跨图取中位数；三维沿用原评估器跨成功试验的中位数，不能混合成同一总体分数。','','|配置|版本|accepted|k1|k2|二维px|三维px|','|---|---|---|---|---|---|---|']
    for b in baseline:
        lines.append(f"|{b['pose']}|{b['variant']}|{b.get('accepted')}|{b.get('k1',float('nan')):.6f}|{b.get('k2',float('nan')):.6f}|{b.get('planar',{}).get('holdout_rmse_px',{}).get('median',float('nan')):.4f}|{b.get('cuboid',{}).get('holdout_error_px',{}).get('median',float('nan')):.4f}|")
    lines += ['','### MATLAB参考（相同完整测试集）','','|配置|二维px|三维px|','|---|---|---|']
    for pose in POSES:
        zp=OUT/'evaluations'/pose/'zhang_reference/evaluation.json'
        if zp.exists():
            z=read(zp)['summary'];pv=planar[pose]['summaries']['zhang_matlab_20_images']['holdout_rmse_px']['median']
            lines.append(f"|{pose}|{pv:.4f}|{z['holdout_error_px']['median']:.4f}|")
    lines += ['','## 角点扰动和删除图片','','每个sigma各3个固定随机种子；这是初步敏感性扫描，不是充分的统计置信区间。Gaussian sigma=0.1/0.3 px为假设扰动量，不是实测检测噪声。对应点组被保留，但重新筛选可能改变有效面；因此包含门限/关联敏感性。删除一张得到四张子集，不等于不同独立五张集合。','','|配置|版本|扰动|完成/任务|接受/任务|fx范围px|cx范围px|k1范围|k2范围|','|---|---|---|---|---|---|---|---|---|']
    for g in groups:
        def fmt(k):
            x=g['parameters'][k];return '-' if x is None else f"{x['min']:.4f}..{x['max']:.4f}"
        lines.append(f"|{g['pose']}|{g['variant']}|{g['group']}|{g['completed']}/{g['requested']}|{g['accepted']}/{g['requested']}|{fmt('fx')}|{fmt('cx')}|{fmt('k1')}|{fmt('k2')}|")
    lines += ['','范围包含成功求解但未通过门限的诊断模型；JSON另存仅接受模型的范围，避免幸存者偏差。','','## 固定局部平面观测的数据约束与多初值','','每个版本使用默认、(-0.6,0.3)、(0.6,-0.3)三个径向起点，局部观测固定。数据Jacobian去掉先验行，并投影掉内参四项和各面位姿列。这里只是局部一阶、未加权敏感性，不能当成全局置信区间。多初值一致也不能证明真值准确。','','|配置|版本|三起点k2范围|投影列相关|投影条件数|单位像素噪声k2线性尺度|','|---|---|---|---|---|---|']
    for x in ids:
        a=x['default'];lines.append(f"|{x['pose']}|{x['variant']}|{x['k2']['min']:.5f}..{x['k2']['max']:.5f}|{a['projected_radial_column_correlation']:.4f}|{a['condition_number']:.2f}|{a['unit_pixel_noise_linearized_std'][1]:.4f}|")
    lines += ['','## 解释边界','','- 门限通过并不等于参数真实或跨采集稳定。','- 比例先验可能稳定数值，也可能使解集中在比例边界；必须结合无比例组和独立测试判断。','- 三面对应点缓存并不保证每张原开发图都通过严格三面门限；本轮不声称“任意五张合格三面图”验证。','- 只重新求解，不使用MATLAB参数训练。MATLAB仅通过评估器的camera-override接口参与三维对照。','- 不生成应用达标结论，也不把名义25mm目标当独立计量真值。','- prediction_screen为固定文件名间隔选取每配置每类型12张的诊断子集，每图5次划分；不替代完整基线测试。']
    lines += ['','## 固定子集上的预测敏感性','','以下各范围是每个模型在同一个诊断子集上的误差中位数范围，不是总体测试集成绩。包含未接受但可求解模型。','','|配置|类型|ratio基线px|0.1px扰动后的范围px|0.3px扰动后的范围px|','|---|---|---|---|---|']
    for pose in POSES:
        p=OUT/'prediction_screen'/pose/'results.json'
        if not p.exists():continue
        sm=read(p)['summary']
        for kind in ['2D','3D']:
            base=next((x['median_rmse_px'] for x in sm if x['model']=='ratio_base' and x['kind']==kind),None)
            ranges=[]
            for tag in ['ratio_noise0.1','ratio_noise0.3']:
                vals=[x['median_rmse_px'] for x in sm if x['kind']==kind and x['model'].startswith(tag) and x['median_rmse_px'] is not None]
                ranges.append(f'{min(vals):.4f}..{max(vals):.4f}' if vals else '-')
            bs='pending' if base is None else f'{base:.4f}'
            lines.append(f"|{pose}|{kind}|{bs}|{ranges[0]}|{ranges[1]}|")
    lines += ['','## 本轮结论','','1. 修正版所选五张基线均通过门限，但扰动、删图和多初值结果不支持“全部参数均稳定”。','2. 比例约束对15、30和45_1.155的系数与门限结果有明显影响；45_0.827和60默认基线基本不受影响。','3. 30无比例组k2抵达0.75数值上界。边界集中不是数据充分或真实系数稳定的证据。','4. 15与45_1.155存在门限敏感性；60存在明显焦距扰动敏感性。应同时报告参数范围、接受率和预测误差。','5. 60径向多初值存在更差的局部解（默认数据分量RMSE约0.650px，另一ratio起点约2.692px）。不是两个同样好的等价解；提示优化需检查多初值，不能仅看optimizer_success。','6. 现有数据能够开展上述复核，但不能证明普遍最少图片数、任意五张严格三面输入稳定或绝对内参真值。','7. 本轮未修改论文、生产算法或放宽门限。']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'.join(lines[:25]),flush=True)
if __name__=='__main__':main()
