"""Selected worst-case solver diagnostic; do not replace full-test scores."""
import hashlib
import numpy as np
import cv2
import trained_camera_model as t
import evaluate_trained_camera_model as ev
import evaluate_planar_blind_comparison as ep
from deepen_evidence_20260926 import DEST,read,save,SRC,SPLIT,BASE,POSES
d=read(DEST/'results.json');out=[]
cv2.setNumThreads(1)
for a in d['worst_cases']:
    if a['faces']!=1:continue
    pose=a['pose'];manifest=read(SRC/pose/'test_manifest.json')
    ix='01234' if a['model']=='five' else str(next(i for i,tr in enumerate(manifest['training']) if tr['image'].endswith(a['model'])))
    m=read(SRC/pose/f'subset_{ix}.json');K=np.array(m['cameraMatrix']);dist=np.array(m['distCoeffs'])
    p=SPLIT/'test'/pose/'3D'/a['image'];h=hashlib.sha256(p.read_bytes()).hexdigest();cs=list((BASE/'test_correspondence_cache'/pose).glob(h+'_sq25_*.npz'))
    cv2.setRNGSeed(20260912);s=t.extract_correspondences(str(p),25,correspondence_cache_path=str(cs[0]),minimum_usable_faces=1)
    obj,im=s.object_points,s.image_points;ids=ev.face_ids(obj);axes=np.argsort(np.ptp(obj,axis=0))[-2:];local=np.zeros_like(obj);local[:,:2]=obj[:,axes]
    n=sorted((SPLIT/'test'/pose/'3D').glob('*.jpg')).index(p);rng=np.random.default_rng(915000+POSES.index(pose)*1000+n);splits=[ev.stratified_holdout(ids,rng,.2,4) for _ in range(5)]
    orig=[];alt=[]
    for r,(tr,te) in enumerate(splits):
        cv2.setRNGSeed(915000+r);fit=ev.solve_pose(obj,im,tr,K,dist)
        if fit is not None:orig.extend(ev.project_errors(obj,im,te,fit,K,dist).tolist())
        plane=ep.solve_pose(local,im,tr,K,dist)
        if plane is not None:alt.extend(ep.project_errors(local,im,te,plane,K,dist).tolist())
    rm=lambda x:float(np.sqrt(np.mean(np.square(x)))) if x else None
    assert abs(rm(orig)-a['heldout_rmse'])<1e-4,(pose,p,rm(orig),a['heldout_rmse'])
    out.append(dict(pose=pose,model=a['model'],image=a['image'],original_rmse=rm(orig),plane_candidate_rmse=rm(alt),scored_points_original=len(orig),scored_points_alternative=len(alt)))
save(DEST/'planar_tail_diagnostic.json',dict(scope='Post-hoc selected worst cases. Identical camera parameters, points and splits; local metric plane coordinates with IPPE/iterative pose selection. No calibration retraining. Must not replace full-test scores or infer global improvement.',rows=out))
lines=['# 单面大误差：相同留出划分下的位姿求解诊断','','只对事后选出的14个最差案例进行，不能作为全测试集改进成绩。原有相机参数、点和划分保持一致，仅改变平面位姿候选求解方法。原始误差已逐项复现。','','|配置|模型|图片|原留出RMSE|平面候选留出RMSE|','|---|---|---|---|---|']
for r in out:lines.append(f"|{r['pose']}|{r['model']}|{r['image']}|{r['original_rmse']:.3f}|{r['plane_candidate_rmse']:.3f}|")
(DEST/'PLANAR_TAIL_REPORT.md').write_text('\n'.join(lines),encoding='utf-8');print('\n'.join(lines))
