"""Frozen-pool sample-count experiment. Never move test images into development."""
from pathlib import Path
import sys,os,json,shutil,hashlib,time,subprocess,traceback
from concurrent.futures import ThreadPoolExecutor,as_completed
import numpy as np
from ablate_0820_ratio_prior import ROOT,BASE,SPLIT,POSES
OUT=ROOT/'output/experiment_0820_trical_sample_count'
OUT.mkdir(exist_ok=True)
def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def prepare():
    code=OUT/'code';code.mkdir(exist_ok=True)
    shutil.copy2(ROOT/'trained_camera_model.py',code/'trained_camera_model.py')
    jobs=[]
    for pose in POSES:
        images=sorted((SPLIT/'train'/pose/'3D').glob('*.jpg'));assert len(images)==5
        testhash={hashlib.sha256(p.read_bytes()).hexdigest() for p in (SPLIT/'test'/pose).rglob('*.jpg')}
        full=[]
        for p in images:
            digest=hashlib.sha256(p.read_bytes()).hexdigest();assert digest not in testhash
            caches=list((BASE/'per_pose_models'/pose/'.trihedral_correspondence_cache').glob(digest+'_sq25_*.npz'));assert len(caches)==1
            d=np.load(caches[0],allow_pickle=True);pts=np.concatenate(list(d['image_points'])).reshape(-1,2);w,h=d['image_size']
            radius=np.linalg.norm((pts-np.array([w/2,h/2]))/np.hypot(w/2,h/2),axis=1)
            full.append(dict(image=str(p),sha256=digest,cache=str(caches[0]),cache_sha256=hashlib.sha256(caches[0].read_bytes()).hexdigest(),raw_face_points=[len(a) for a in d['image_points']],raw_patterns=d['patterns'].tolist(),raw_centroid_normalized=(pts.mean(axis=0)/[w,h]).tolist(),raw_image_radius_p95=float(np.percentile(radius,95)),raw_outer_half_fraction=float(np.mean(radius>.5))))
        save(OUT/'development_geometry'/f'{pose}.json',full)
        for omit in [-1,0,1,2,3,4]:
            name='n05_full' if omit==-1 else f'n04_omit{omit+1:02d}'
            selected=[x for i,x in enumerate(full) if i!=omit]
            modeldir=OUT/'models'/pose/name;cache=modeldir/'.trihedral_correspondence_cache';cache.mkdir(parents=True,exist_ok=True)
            for x in selected:shutil.copy2(x['cache'],cache/Path(x['cache']).name)
            spec=dict(pose=pose,name=name,n=len(selected),selected=selected,held_development_image=None if omit==-1 else full[omit]['image'])
            save(modeldir/'selection.json',spec);jobs.append(spec)
    save(OUT/'protocol.json',dict(dataset=str(SPLIT),main_method_unchanged=True,source_sha256=hashlib.sha256((ROOT/'trained_camera_model.py').read_bytes()).hexdigest(),sizes=[4,5],four_image_subsets='all five deletions from each frozen five-image development pool',unavailable_sizes={'2_3':'current formal trainer minimum is four; no gates lowered','7_10':'only five frozen development images; test images not repurposed'},no_zhang_training=True,exploratory_tests_not_used_to_select_models=True,geometry_metrics='raw cached corners before final gates; image-center radius normalized by half diagonal, not optical normalized radius',jobs=jobs))
    return jobs
def train(pose,name):
    sys.path.insert(0,str(OUT/'code'))
    from trained_camera_model import train_camera_model
    target=OUT/'models'/pose/name;spec=read(target/'selection.json');start=time.perf_counter()
    try:
        m=train_camera_model([x['image'] for x in spec['selected']],25,str(target/'trained_camera_model.json'),distortion_model='k1_k2',progress=lambda s:print(s,flush=True))
        save(target/'status.json',dict(completed=True,accepted=m['accepted'],elapsed_s=time.perf_counter()-start))
    except Exception as e:save(target/'status.json',dict(completed=False,accepted=False,error=str(e),traceback=traceback.format_exc(),elapsed_s=time.perf_counter()-start))
def run(name,args):
    logs=OUT/'logs';logs.mkdir(exist_ok=True);env=os.environ.copy();env.update(PYTHONPATH=str(ROOT),PYTHONIOENCODING='utf-8',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    with (logs/(name+'.log')).open('w',encoding='utf-8') as f:p=subprocess.run([sys.executable,*map(str,args)],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    r=dict(job=name,returncode=p.returncode);print(r,flush=True);return r
def main():
    jobs=prepare()
    with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(lambda j:run('train_'+j['pose']+'_'+j['name'],[__file__,'train',j['pose'],j['name']]),jobs))
    tasks=[]
    for j in jobs:
        pose,name=j['pose'],j['name'];directory=OUT/'models'/pose/name
        if not read(directory/'status.json')['completed']:continue
        for kind,images,cache in [('3D_test',SPLIT/'test'/pose/'3D',BASE/'test_correspondence_cache'/pose),('development_holdout',j['held_development_image'],BASE/'per_pose_models'/pose/'.trihedral_correspondence_cache')]:
            if images is None:continue
            tasks.append((kind+'_'+pose+'_'+name,[ROOT/'evaluate_trained_camera_model.py','--model',directory/'trained_camera_model.json','--images',images,'--output-dir',OUT/'evaluations'/pose/name/kind,'--correspondence-cache-dir',cache,'--only-existing-cache','--allow-unaccepted-model','--repeats','20']))
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(run,n,a) for n,a in tasks];statuses=[f.result() for f in as_completed(futures)]
    save(OUT/'evaluation_jobs.json',statuses)
if __name__=='__main__':
    if len(sys.argv)>1:train(sys.argv[2],sys.argv[3])
    else:main()
