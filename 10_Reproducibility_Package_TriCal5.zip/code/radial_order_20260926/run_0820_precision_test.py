"""Matched frozen five-image training with float32 vs float64 refinement residuals."""
from pathlib import Path
import os,sys,shutil,time,hashlib,traceback
from concurrent.futures import ThreadPoolExecutor,as_completed
import run_0820_stability_curve as r
from ablate_0820_ratio_prior import ROOT,BASE,SPLIT,POSES
OUT=ROOT/'output/experiment_0820_precision_test'
r.OUT=OUT
def prepare():
    OUT.mkdir(exist_ok=True);original=(ROOT/'trained_camera_model.py').read_text(encoding='utf-8')
    for variant in ['float32','float64']:
        s=original
        if variant=='float64':
            start=s.index('    fx, fy = float(K[0, 0]), float(K[1, 1])',s.index('def _refine_fixed_intrinsics_planar_radial'))
            s=s[:start]+'''    object_groups = [np.asarray(obj, dtype=np.float64) for obj in object_groups]
    image_groups = [np.asarray(img, dtype=np.float64) for img in image_groups]
    K = np.asarray(K, dtype=np.float64)
'''+s[start:]
        d=OUT/'code'/variant;d.mkdir(parents=True,exist_ok=True);(d/'trained_camera_model.py').write_text(s,encoding='utf-8')
    selections=[]
    for pose in POSES:
        selected=[]
        for p in sorted((SPLIT/'train'/pose/'3D').glob('*.jpg')):
            h=hashlib.sha256(p.read_bytes()).hexdigest();cache=next((BASE/'per_pose_models'/pose/'.trihedral_correspondence_cache').glob(h+'_sq25_*.npz'));selected.append(dict(image=str(p),sha256=h,cache=str(cache)))
        for variant in ['float32','float64']:
            d=OUT/'models'/pose/variant;cache=d/'.trihedral_correspondence_cache';cache.mkdir(parents=True,exist_ok=True)
            for x in selected:shutil.copy2(x['cache'],cache/Path(x['cache']).name)
            r.save(d/'selection.json',selected)
        selections.append(dict(pose=pose,selected=selected))
    r.save(OUT/'protocol.json',dict(change='Only cast object/image arrays and K to float64 within radial refinement residual evaluation',all_priors_and_bounds_unchanged=True,opencv_rng_seed=20260912,training_images=selections,source_sha256=hashlib.sha256(original.encode()).hexdigest(),scope='paired diagnostic; no production model replacement'))
def train(pose,variant):
    sys.path.insert(0,str(OUT/'code'/variant));import cv2
    cv2.setNumThreads(1);cv2.setRNGSeed(20260912)
    from trained_camera_model import train_camera_model
    d=OUT/'models'/pose/variant;start=time.perf_counter()
    try:
        m=train_camera_model([x['image'] for x in r.read(d/'selection.json')],25,str(d/'trained_camera_model.json'),distortion_model='k1_k2',progress=lambda s:print(s,flush=True))
        r.save(d/'status.json',dict(completed=True,accepted=m['accepted'],elapsed_s=time.perf_counter()-start))
    except Exception as e:r.save(d/'status.json',dict(completed=False,error=str(e),traceback=traceback.format_exc(),elapsed_s=time.perf_counter()-start))
def main():
    prepare()
    with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(lambda j:r.run('train_'+j[0]+'_'+j[1],[__file__,'train',*j]),[(p,v) for p in POSES for v in ['float32','float64']]))
    tasks=[]
    for pose in POSES:
        for v in ['float32','float64']:
            d=OUT/'models'/pose/v
            if not r.read(d/'status.json')['completed']:continue
            tasks.append((pose+'_'+v,[ROOT/'evaluate_trained_camera_model.py','--model',d/'trained_camera_model.json','--images',SPLIT/'test'/pose/'3D','--output-dir',OUT/'evaluations'/pose/v,'--correspondence-cache-dir',BASE/'test_correspondence_cache'/pose,'--only-existing-cache','--allow-unaccepted-model','--repeats','20']))
    with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(lambda j:r.run(*j),tasks))
    r.save(OUT/'evaluation_jobs.json',results)
if __name__=='__main__':
    if len(sys.argv)>1:train(sys.argv[2],sys.argv[3])
    else:main()
