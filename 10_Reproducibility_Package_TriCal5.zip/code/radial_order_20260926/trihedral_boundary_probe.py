#!/usr/bin/env python3
"""Probe whether trihedral cube edges can disambiguate sparse face grids.

The production pipeline rejects sparse local checkerboards because their
physical offset on a printed cube face is ambiguous from image points alone.
This diagnostic adds one more image-only cue: detect the three cube edge rays,
project each candidate full-board outline back into the image, and score how
well that outline fits the corresponding trihedral face sector.

It does not change calibration acceptance.  It produces evidence for whether
edge/outline constraints are strong enough to promote a partial sample later.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import cv2
import numpy as np

import face_detector as fd
from partial_offset_probe import _candidate_specs, _intrinsics_from_vps, _pnp_rmse


def _maybe_float(value: Any) -> Optional[float]:
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def _load_gray(path: Path) -> np.ndarray:
    data = np.fromfile(str(path), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Cannot decode image: {path}")
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def _read_csv(path: Path) -> List[Dict[str, Any]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def _grid_points(
    pattern: Tuple[int, int],
    offset: Tuple[int, int],
) -> np.ndarray:
    cols, rows = pattern
    ox, oy = offset
    return np.array(
        [[ox + c, oy + r] for r in range(rows) for c in range(cols)],
        dtype=np.float32,
    )


def _homography_from_grid(
    corners: np.ndarray,
    pattern: Tuple[int, int],
    offset: Tuple[int, int],
) -> Optional[np.ndarray]:
    src = _grid_points(pattern, offset)
    dst = corners.reshape(-1, 2).astype(np.float32)
    H, _mask = cv2.findHomography(src, dst, method=0)
    if H is None or not np.all(np.isfinite(H)):
        return None
    return H


def _project_full_outer_quad(
    corners: np.ndarray,
    pattern: Tuple[int, int],
    full_pattern: Tuple[int, int],
    offset: Tuple[int, int],
) -> Optional[np.ndarray]:
    H = _homography_from_grid(corners, pattern, offset)
    if H is None:
        return None
    full_cols, full_rows = full_pattern
    # Inner corners run 0..full_cols-1 and 0..full_rows-1.  The printed
    # checkerboard outer border is one square beyond the first and last inner
    # corner in both directions.
    outer = np.array(
        [[-1, -1], [full_cols, -1], [full_cols, full_rows], [-1, full_rows]],
        dtype=np.float32,
    ).reshape(-1, 1, 2)
    projected = cv2.perspectiveTransform(outer, H).reshape(-1, 2)
    if not np.all(np.isfinite(projected)):
        return None
    if abs(cv2.contourArea(projected.astype(np.float32))) < 25.0:
        return None
    return projected.astype(np.float32)


def _sector_fraction(poly: np.ndarray, region: Dict[str, Any]) -> float:
    pts = np.asarray(poly, dtype=np.float32).reshape(-1, 2)
    samples = [pts.mean(axis=0)]
    for i in range(len(pts)):
        samples.append(pts[i])
        samples.append(0.5 * (pts[i] + pts[(i + 1) % len(pts)]))
    samples = np.asarray(samples, dtype=np.float32)
    rel = samples - region["vertex"].reshape(1, 2).astype(np.float32)
    angles = (np.arctan2(rel[:, 1], rel[:, 0]) + 2.0 * np.pi) % (2.0 * np.pi)
    inside = fd._angles_in_sector(  # diagnostic use of detector primitive
        angles,
        region["sector_start"],
        region["sector_end"],
    )
    return float(inside.mean()) if len(inside) else 0.0


def _component_containment(
    poly: np.ndarray,
    centers: np.ndarray,
    tolerance_px: float,
) -> float:
    if centers is None or len(centers) == 0:
        return 0.0
    contour = poly.astype(np.float32)
    inside = 0
    for center in centers:
        if cv2.pointPolygonTest(
            contour, (float(center[0]), float(center[1])), False
        ) >= -float(tolerance_px):
            inside += 1
    return float(inside) / float(len(centers))


def _find_trihedral_edge_layout_for_probe(
    gray: np.ndarray,
    *,
    min_gap_deg: float = 24.0,
    max_gap_deg: float = 188.0,
) -> Optional[Dict[str, Any]]:
    """Diagnostic trihedral layout finder with tunable sector-gap gates."""
    h, w = gray.shape[:2]
    max_dim = max(h, w)
    segments = fd._extract_edge_segments_for_trihedral(gray)
    if len(segments) < 3:
        return None

    _filtered, components = fd._dark_square_components(gray)
    comp_pts = np.array([c["center"] for c in components], dtype=np.float64)
    comp_boxes = np.array([c["bbox"] for c in components], dtype=np.int32)
    if len(comp_pts) < 12:
        return None

    spread_tol = max(20.0, 0.038 * max_dim)
    min_ray = max(70.0, 0.13 * max_dim)
    min_sector = 3 if len(comp_pts) < 24 else 4
    min_gap_rad = np.deg2rad(float(min_gap_deg))
    max_gap_rad = np.deg2rad(float(max_gap_deg))
    best = None

    for s1, s2, s3 in itertools.combinations(segments, 3):
        segs = (s1, s2, s3)
        if any(
            fd._cos_sim(a["dir"], b["dir"]) > 0.955
            for a, b in itertools.combinations(segs, 2)
        ):
            continue

        intersections = []
        ok = True
        for a, b in itertools.combinations(segs, 2):
            p = fd._line_intersection(a["line"], b["line"])
            if p is None:
                ok = False
                break
            intersections.append(p)
        if not ok:
            continue

        vertex = np.mean(np.vstack(intersections), axis=0)
        spread = max(float(np.linalg.norm(p - vertex)) for p in intersections)
        if spread > spread_tol:
            continue
        margin = 0.10 * max_dim
        if not (-margin <= vertex[0] <= w + margin and -margin <= vertex[1] <= h + margin):
            continue

        ray_dirs = []
        ray_lengths = []
        for seg in segs:
            d1 = np.linalg.norm(seg["p1"] - vertex)
            d2 = np.linalg.norm(seg["p2"] - vertex)
            far = seg["p1"] if d1 >= d2 else seg["p2"]
            ray = far - vertex
            ray_len = float(np.linalg.norm(ray))
            if ray_len < min_ray:
                ok = False
                break
            ray_dirs.append(ray / max(ray_len, 1e-12))
            ray_lengths.append(ray_len)
        if not ok:
            continue

        ray_angles = sorted(
            (np.arctan2(d[1], d[0]) + 2.0 * np.pi) % (2.0 * np.pi)
            for d in ray_dirs
        )
        gaps = [
            fd._angle_diff_positive(ray_angles[i], ray_angles[(i + 1) % 3])
            for i in range(3)
        ]
        if min(gaps) < min_gap_rad or max(gaps) > max_gap_rad:
            continue

        counts, masks = fd._trihedral_sector_counts(comp_pts, vertex, ray_angles)
        if min(counts) < min_sector:
            continue

        balance = max(counts) / float(max(min(counts), 1))
        angular_balance = sum(abs(g - (2.0 * np.pi / 3.0)) for g in gaps)
        score = (
            sum(s["length"] for s in segs)
            + 35.0 * sum(np.sqrt(counts))
            - 80.0 * np.log(max(balance, 1.0))
            - 5.0 * spread
            - 28.0 * angular_balance
        )
        if best is None or score > best["score"]:
            best = {
                "score": float(score),
                "vertex": vertex.astype(np.float32),
                "ray_angles": [float(a) for a in ray_angles],
                "counts": counts,
                "component_points": comp_pts.astype(np.float32),
                "component_boxes": comp_boxes,
                "component_masks": masks,
                "gap_degrees": [float(np.rad2deg(g)) for g in gaps],
            }

    return best


def _crop_target_attempts(
    crop_target_dim: float,
    extra_crop_target_dims: Optional[Sequence[float]],
) -> List[float]:
    targets: List[float] = []
    for value in [crop_target_dim, *(extra_crop_target_dims or [])]:
        try:
            target = float(value)
        except (TypeError, ValueError):
            continue
        if not math.isfinite(target) or target <= 0:
            continue
        if not any(abs(target - existing) < 1e-6 for existing in targets):
            targets.append(target)
    return targets


def _edge_regions_from_layout(
    gray: np.ndarray,
    *,
    crop_target_dim: float = 950.0,
    extra_crop_target_dims: Optional[Sequence[float]] = None,
    crop_max_scale: float = 4.0,
    crop_min_scale: float = 1.05,
    layout_min_gap_deg: float = 24.0,
    layout_max_gap_deg: float = 188.0,
) -> Tuple[Optional[str], Dict[str, Dict[str, Any]]]:
    """Return trihedral face regions in original-image coordinates."""
    attempts: List[Tuple[str, np.ndarray, float, np.ndarray]] = [
        ("full", gray, 1.0, np.array([0.0, 0.0], dtype=np.float32))
    ]

    crop_box = fd._cube_crop_from_clusters(gray, n_faces=3)
    if crop_box is not None:
        x1, y1, x2, y2 = crop_box
        crop = gray[y1:y2, x1:x2]
        ch, cw = crop.shape[:2]
        for target_dim in _crop_target_attempts(crop_target_dim, extra_crop_target_dims):
            scale = min(
                float(crop_max_scale),
                float(target_dim) / float(max(cw, ch, 1)),
            )
            if scale >= float(crop_min_scale):
                up_w = int(round(cw * scale))
                up_h = int(round(ch * scale))
                upscaled = cv2.resize(
                    crop, (up_w, up_h), interpolation=cv2.INTER_CUBIC)
                attempts.append((
                    f"crop_upscaled_{int(round(target_dim))}",
                    upscaled,
                    scale,
                    np.array([x1, y1], dtype=np.float32),
                ))

    for source, work_gray, scale, offset in attempts:
        layout = _find_trihedral_edge_layout_for_probe(
            work_gray,
            min_gap_deg=layout_min_gap_deg,
            max_gap_deg=layout_max_gap_deg,
        )
        if layout is None:
            continue
        regions = fd._trihedral_face_regions(work_gray, layout)
        if len(regions) < 3:
            continue

        vertex = layout["vertex"].astype(np.float32) / scale + offset
        out: Dict[str, Dict[str, Any]] = {}
        for region in regions:
            label = region.get("label")
            if label is None:
                continue
            mapped = dict(region)
            mapped["poly"] = (
                region["poly"].astype(np.float32) / scale + offset
            )
            mapped["vertex"] = vertex
            mapped["component_centers"] = (
                layout["component_points"][layout["component_masks"][region["sector_idx"]]]
                .astype(np.float32)
                / scale
                + offset
            )
            mapped["source"] = source
            out[str(label)] = mapped
        if len(out) >= 3:
            return source, out

    return None, {}


def _score_face_outline(
    poly: np.ndarray,
    region: Dict[str, Any],
    image_shape: Tuple[int, int],
) -> Dict[str, float]:
    h, w = image_shape[:2]
    diag = float(np.hypot(w, h))
    tol = max(3.0, 0.004 * diag)
    contain = _component_containment(
        poly, region.get("component_centers"), tolerance_px=tol)
    sector = _sector_fraction(poly, region)

    poly_area = abs(float(cv2.contourArea(poly.astype(np.float32))))
    region_area = abs(float(cv2.contourArea(
        np.asarray(region["poly"], dtype=np.float32))))
    area_ratio = poly_area / max(region_area, 1.0)
    area_penalty = abs(math.log(max(area_ratio, 1e-6)))

    poly_center = poly.reshape(-1, 2).mean(axis=0)
    region_center = np.asarray(region["poly"], dtype=np.float32).reshape(-1, 2).mean(axis=0)
    region_span = max(
        float(np.ptp(region["poly"][:, 0])),
        float(np.ptp(region["poly"][:, 1])),
        1.0,
    )
    center_norm = float(np.linalg.norm(poly_center - region_center) / region_span)

    in_image = float(np.mean(
        (poly[:, 0] >= -0.05 * w)
        & (poly[:, 0] <= 1.05 * w)
        & (poly[:, 1] >= -0.05 * h)
        & (poly[:, 1] <= 1.05 * h)
    ))
    score = (
        6.0 * contain
        + 2.4 * sector
        + 0.8 * in_image
        - 0.85 * area_penalty
        - 1.25 * center_norm
    )
    return {
        "score": float(score),
        "component_containment": float(contain),
        "sector_fraction": float(sector),
        "area_ratio": float(area_ratio),
        "center_norm": float(center_norm),
        "in_image_fraction": float(in_image),
    }


def _edge_distance_map(gray: np.ndarray) -> np.ndarray:
    enhanced = fd.preprocess_image(gray)
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    edges_a = cv2.Canny(blur, 45, 135, apertureSize=3)
    edges_b = cv2.Canny(enhanced, 60, 180, apertureSize=3)
    edges = cv2.bitwise_or(edges_a, edges_b)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    edges = cv2.dilate(edges, kernel, iterations=1)
    non_edge = np.where(edges > 0, 0, 255).astype(np.uint8)
    return cv2.distanceTransform(non_edge, cv2.DIST_L2, 3)


def _poly_edge_support(
    poly: np.ndarray,
    edge_dist: np.ndarray,
    *,
    tolerance_px: float,
    sample_step_px: float = 2.5,
) -> Dict[str, Any]:
    h, w = edge_dist.shape[:2]
    pts = np.asarray(poly, dtype=np.float32).reshape(-1, 2)
    per_edge = []
    for i in range(len(pts)):
        a = pts[i]
        b = pts[(i + 1) % len(pts)]
        length = float(np.linalg.norm(b - a))
        n = max(8, int(round(length / max(sample_step_px, 1.0))))
        hits = 0
        total = 0
        for t in np.linspace(0.0, 1.0, n):
            p = a * (1.0 - t) + b * t
            x = int(round(float(p[0])))
            y = int(round(float(p[1])))
            if x < -2 or x > w + 1 or y < -2 or y > h + 1:
                continue
            x = min(max(x, 0), w - 1)
            y = min(max(y, 0), h - 1)
            total += 1
            if float(edge_dist[y, x]) <= tolerance_px:
                hits += 1
        per_edge.append(float(hits) / float(max(total, 1)))
    return {
        "edge_support_mean": float(np.mean(per_edge)) if per_edge else 0.0,
        "edge_support_min": float(min(per_edge)) if per_edge else 0.0,
        "edge_support_per_edge": per_edge,
    }


def _project_board_points(H: np.ndarray, points: Sequence[Tuple[float, float]]) -> np.ndarray:
    arr = np.asarray(points, dtype=np.float32).reshape(-1, 1, 2)
    return cv2.perspectiveTransform(arr, H).reshape(-1, 2)


def _sample_gray_values(
    gray: np.ndarray,
    points: np.ndarray,
    *,
    radius: int = 1,
) -> Tuple[np.ndarray, np.ndarray]:
    h, w = gray.shape[:2]
    values: List[float] = []
    valid: List[bool] = []
    r = max(0, int(radius))
    for point in np.asarray(points, dtype=np.float32).reshape(-1, 2):
        x = int(round(float(point[0])))
        y = int(round(float(point[1])))
        if x < r or x >= w - r or y < r or y >= h - r:
            values.append(float("nan"))
            valid.append(False)
            continue
        patch = gray[y - r:y + r + 1, x - r:x + r + 1]
        values.append(float(np.median(patch)))
        valid.append(True)
    return np.asarray(values, dtype=np.float32), np.asarray(valid, dtype=bool)


def _parity_contrast(values: np.ndarray, valid: np.ndarray, parities: np.ndarray) -> Tuple[float, int, Optional[int]]:
    mask0 = valid & (parities == 0)
    mask1 = valid & (parities == 1)
    if int(mask0.sum()) < 3 or int(mask1.sum()) < 3:
        return 0.0, int(valid.sum()), None
    mean0 = float(np.mean(values[mask0]))
    mean1 = float(np.mean(values[mask1]))
    dark_parity = 0 if mean0 < mean1 else 1
    return float(abs(mean0 - mean1) / 255.0), int(valid.sum()), dark_parity


def _printed_checker_evidence(
    gray: np.ndarray,
    corners: np.ndarray,
    pattern: Tuple[int, int],
    full_pattern: Tuple[int, int],
    offset: Tuple[int, int],
) -> Dict[str, Any]:
    """Score whether a projected full board looks like printed checkerboard.

    The score is intentionally diagnostic.  It uses only image evidence: square
    center parity contrast and expected dark-square transitions at the projected
    outer board border.
    """
    H = _homography_from_grid(corners, pattern, offset)
    if H is None:
        return {
            "print_evidence_score": 0.0,
            "print_checker_contrast": 0.0,
            "print_ring_contrast": 0.0,
            "print_border_transition": 0.0,
            "print_border_outside_brightness": 0.0,
            "print_border_outside_uniformity": 0.0,
            "print_samples": 0,
            "print_border_samples": 0,
        }

    full_cols, full_rows = [int(v) for v in full_pattern]
    centers: List[Tuple[float, float]] = []
    parities: List[int] = []
    ring_mask: List[bool] = []
    for j in range(full_rows + 1):
        for i in range(full_cols + 1):
            centers.append((float(i) - 0.5, float(j) - 0.5))
            parities.append((i + j) & 1)
            ring_mask.append(i in {0, full_cols} or j in {0, full_rows})

    projected = _project_board_points(H, centers)
    values, valid = _sample_gray_values(gray, projected, radius=1)
    parities_arr = np.asarray(parities, dtype=np.int32)
    ring_arr = np.asarray(ring_mask, dtype=bool)
    checker_contrast, sample_count, dark_parity = _parity_contrast(
        values, valid, parities_arr)
    ring_contrast, _ring_count, ring_dark = _parity_contrast(
        values, valid & ring_arr, parities_arr)
    if dark_parity is None:
        dark_parity = ring_dark

    inside_pts: List[Tuple[float, float]] = []
    outside_pts: List[Tuple[float, float]] = []
    border_parities: List[int] = []
    for j in range(full_rows + 1):
        inside_pts.append((-0.84, float(j) - 0.5))
        outside_pts.append((-1.18, float(j) - 0.5))
        border_parities.append((0 + j) & 1)
        inside_pts.append((float(full_cols) - 0.16, float(j) - 0.5))
        outside_pts.append((float(full_cols) + 0.18, float(j) - 0.5))
        border_parities.append((full_cols + j) & 1)
    for i in range(full_cols + 1):
        inside_pts.append((float(i) - 0.5, -0.84))
        outside_pts.append((float(i) - 0.5, -1.18))
        border_parities.append((i + 0) & 1)
        inside_pts.append((float(i) - 0.5, float(full_rows) - 0.16))
        outside_pts.append((float(i) - 0.5, float(full_rows) + 0.18))
        border_parities.append((i + full_rows) & 1)

    inside_img = _project_board_points(H, inside_pts)
    outside_img = _project_board_points(H, outside_pts)
    inside_values, inside_valid = _sample_gray_values(gray, inside_img, radius=1)
    outside_values, outside_valid = _sample_gray_values(gray, outside_img, radius=1)
    pair_valid = inside_valid & outside_valid
    border_parities_arr = np.asarray(border_parities, dtype=np.int32)
    if dark_parity is not None:
        pair_valid = pair_valid & (border_parities_arr == int(dark_parity))

    border_samples = int(pair_valid.sum())
    if border_samples:
        diff = outside_values[pair_valid] - inside_values[pair_valid]
        border_transition = float(np.mean(np.clip(diff / 80.0, 0.0, 1.0)))
        outside = outside_values[pair_valid]
        outside_brightness = float(np.mean(outside) / 255.0)
        outside_uniformity = float(np.clip(1.0 - np.std(outside) / 80.0, 0.0, 1.0))
    else:
        border_transition = 0.0
        outside_brightness = 0.0
        outside_uniformity = 0.0

    score = (
        2.00 * checker_contrast
        + 1.20 * ring_contrast
        + 1.25 * border_transition
        + 0.35 * outside_brightness
        + 0.25 * outside_uniformity
    )
    return {
        "print_evidence_score": float(score),
        "print_checker_contrast": float(checker_contrast),
        "print_ring_contrast": float(ring_contrast),
        "print_border_transition": float(border_transition),
        "print_border_outside_brightness": float(outside_brightness),
        "print_border_outside_uniformity": float(outside_uniformity),
        "print_samples": int(sample_count),
        "print_border_samples": int(border_samples),
    }


def _overlay_text(
    image: np.ndarray,
    lines: Sequence[str],
    *,
    origin: Tuple[int, int] = (18, 28),
) -> None:
    x, y = origin
    font = cv2.FONT_HERSHEY_SIMPLEX
    scale = 0.58
    line_h = 22
    if not lines:
        return
    widths = []
    for line in lines:
        (tw, _th), _base = cv2.getTextSize(line, font, scale, 1)
        widths.append(tw)
    box_w = min(image.shape[1] - x - 8, max(widths, default=0) + 18)
    box_h = line_h * len(lines) + 12
    cv2.rectangle(
        image,
        (x - 8, y - 18),
        (x - 8 + box_w, y - 18 + box_h),
        (255, 255, 255),
        thickness=-1,
    )
    cv2.rectangle(
        image,
        (x - 8, y - 18),
        (x - 8 + box_w, y - 18 + box_h),
        (20, 20, 20),
        thickness=1,
    )
    for idx, line in enumerate(lines):
        cv2.putText(
            image,
            line,
            (x, y + idx * line_h),
            font,
            scale,
            (20, 20, 20),
            1,
            cv2.LINE_AA,
        )


def _write_boundary_overlay(
    gray: np.ndarray,
    detections: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    regions: Dict[str, Dict[str, Any]],
    best: Optional[Dict[str, Any]],
    row: Dict[str, Any],
    path: Path,
) -> None:
    colors = {
        "XY": (60, 80, 255),
        "XZ": (60, 190, 60),
        "YZ": (255, 120, 50),
    }
    canvas = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    shaded = canvas.copy()

    for label, region in regions.items():
        color = colors.get(label, (220, 160, 40))
        poly = np.asarray(region.get("poly"), dtype=np.float32)
        if poly.size:
            pts = np.round(poly).astype(np.int32).reshape(-1, 1, 2)
            cv2.fillPoly(shaded, [pts], color)
            cv2.polylines(canvas, [pts], True, color, 2, cv2.LINE_AA)
            center = poly.reshape(-1, 2).mean(axis=0)
            cv2.putText(
                canvas,
                f"{label} sector",
                (int(center[0]), int(center[1])),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.62,
                color,
                2,
                cv2.LINE_AA,
            )
        vertex = region.get("vertex")
        if vertex is not None:
            v = np.round(np.asarray(vertex, dtype=np.float32)).astype(int)
            cv2.circle(canvas, (int(v[0]), int(v[1])), 6, (255, 255, 255), -1)
            cv2.circle(canvas, (int(v[0]), int(v[1])), 6, color, 2)

    canvas = cv2.addWeighted(shaded, 0.22, canvas, 0.78, 0)

    for corners, pattern, label in detections:
        color = colors.get(label, (220, 160, 40))
        pts = corners.reshape(-1, 2).astype(np.float32)
        for p in pts:
            cv2.circle(canvas, (int(round(p[0])), int(round(p[1]))), 2, color, -1)
        if len(pts):
            c = pts.mean(axis=0)
            cv2.putText(
                canvas,
                f"{label} {pattern[0]}x{pattern[1]}",
                (int(c[0]), int(c[1])),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.56,
                (0, 0, 0),
                3,
                cv2.LINE_AA,
            )
            cv2.putText(
                canvas,
                f"{label} {pattern[0]}x{pattern[1]}",
                (int(c[0]), int(c[1])),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.56,
                color,
                1,
                cv2.LINE_AA,
            )

    if best is not None:
        for label, poly in best.get("face_polys", {}).items():
            color = colors.get(label, (220, 160, 40))
            pts = np.round(np.asarray(poly, dtype=np.float32)).astype(np.int32).reshape(-1, 1, 2)
            cv2.polylines(canvas, [pts], True, color, 4, cv2.LINE_AA)
            spec = best.get("specs", {}).get(label, {})
            region_label = best.get("region_labels", {}).get(label, "?")
            text = (
                f"{label}->{region_label} "
                f"full={tuple(spec.get('full_pattern', ()))}, "
                f"off={tuple(spec.get('offset', ()))}"
            )
            center = np.asarray(poly, dtype=np.float32).reshape(-1, 2).mean(axis=0)
            cv2.putText(
                canvas,
                text,
                (int(center[0]), int(center[1]) + 18),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.48,
                (0, 0, 0),
                3,
                cv2.LINE_AA,
            )
            cv2.putText(
                canvas,
                text,
                (int(center[0]), int(center[1]) + 18),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.48,
                color,
                1,
                cv2.LINE_AA,
            )

    lines = [
        f"{row.get('group', '')}/{row.get('image', '')}",
        f"status: {row.get('boundary_status', '')}",
        f"layout: {row.get('layout_source', '') or 'none'}",
        f"candidates: {row.get('boundary_candidates', '')}",
        f"gap: {_fmt(row.get('boundary_score_gap'))}, close: {row.get('close_boundary_candidates', '')}",
        f"min sector: {_fmt(row.get('best_min_sector_fraction'))}, min edge: {_fmt(row.get('best_min_edge_support'))}",
        f"pnp: {row.get('pnp_status', '')}, best: {_fmt(row.get('best_pnp_rmse_px'))}, close: {row.get('close_pnp_candidates', '')}",
        f"print: {row.get('print_status', '')}, gap: {_fmt(row.get('print_score_gap'))}, close: {row.get('close_print_candidates', '')}",
    ]
    _overlay_text(canvas, lines)

    path.parent.mkdir(parents=True, exist_ok=True)
    ok, encoded = cv2.imencode(".jpg", canvas, [int(cv2.IMWRITE_JPEG_QUALITY), 92])
    if ok:
        encoded.tofile(str(path))


def probe_image(
    image_path: Path,
    *,
    boundary_gap: float,
    edge_top_candidates: int,
    pnp_top_candidates: int = 600,
    pnp_gap_px: float = 1.0,
    pnp_max_rmse_px: float = 12.0,
    print_top_candidates: int = 600,
    print_gap: float = 0.35,
    print_min_score: float = 1.25,
    match_region_permutations: bool = False,
    max_spec_candidates: Optional[int] = None,
    crop_target_dim: float = 950.0,
    extra_crop_target_dims: Optional[Sequence[float]] = None,
    crop_max_scale: float = 4.0,
    crop_min_scale: float = 1.05,
    layout_min_gap_deg: float = 24.0,
    layout_max_gap_deg: float = 188.0,
    strict_min_component: float = 0.90,
    strict_min_sector: float = 0.55,
    strict_min_edge: float = 0.45,
    overlay_path: Optional[Path] = None,
) -> Dict[str, Any]:
    gray = _load_gray(image_path)
    h, w = gray.shape[:2]
    detections = fd.detect_corner_cube_faces(gray, n_faces=3, verbose=False)
    row: Dict[str, Any] = {
        "image": image_path.name,
        "n_faces": len(detections),
        "patterns": json.dumps(
            [(label, pattern) for _c, pattern, label in detections]
        ),
        "boundary_status": "not_probed",
    }

    if len(detections) != 3 or len({label for _c, _p, label in detections}) != 3:
        row["boundary_status"] = "invalid_face_set"
        if overlay_path is not None:
            _write_boundary_overlay(gray, detections, {}, None, row, overlay_path)
        return row
    if all(min(pattern) >= 5 for _c, pattern, _label in detections):
        row["boundary_status"] = "not_partial"
        if overlay_path is not None:
            _write_boundary_overlay(gray, detections, {}, None, row, overlay_path)
        return row
    try:
        K_seed = _intrinsics_from_vps(detections, (w, h))
    except Exception:
        K_seed = None

    layout_source, regions = _edge_regions_from_layout(
        gray,
        crop_target_dim=crop_target_dim,
        extra_crop_target_dims=extra_crop_target_dims,
        crop_max_scale=crop_max_scale,
        crop_min_scale=crop_min_scale,
        layout_min_gap_deg=layout_min_gap_deg,
        layout_max_gap_deg=layout_max_gap_deg,
    )
    row["layout_source"] = layout_source or ""
    if not regions:
        row["boundary_status"] = "no_trihedral_layout"
        if overlay_path is not None:
            _write_boundary_overlay(gray, detections, {}, None, row, overlay_path)
        return row

    candidates = []
    spec_candidates_seen = 0
    spec_limit_exceeded = False
    region_items = list(regions.items())
    region_permutations: List[Tuple[Tuple[str, Dict[str, Any]], ...]] = []
    if match_region_permutations and len(region_items) >= len(detections):
        region_permutations = list(itertools.permutations(region_items, len(detections)))

    for specs in _candidate_specs(detections):
        spec_candidates_seen += 1
        if max_spec_candidates and spec_candidates_seen > int(max_spec_candidates):
            spec_limit_exceeded = True
            break
        projected_by_label = {}
        ok = True
        for corners, pattern, label in detections:
            spec = specs[label]
            poly = _project_full_outer_quad(
                corners,
                pattern,
                spec["full_pattern"],
                spec["offset"],
            )
            if poly is None:
                ok = False
                break
            projected_by_label[label] = poly
        if not ok:
            continue

        if not region_permutations:
            fixed = []
            for _corners, _pattern, label in detections:
                region = regions.get(label)
                if region is None:
                    ok = False
                    break
                fixed.append((label, region))
            if not ok:
                continue
            region_iter = [tuple(fixed)]
        else:
            region_iter = region_permutations

        for region_combo in region_iter:
            total = 0.0
            min_contain = 1.0
            min_sector = 1.0
            face_metrics = {}
            face_polys = {}
            region_labels = {}
            ok = True
            for (_corners, _pattern, label), (region_label, region) in zip(
                detections, region_combo
            ):
                spec = specs[label]
                poly = projected_by_label[label]
                metrics = _score_face_outline(poly, region, (h, w))
                total += metrics["score"]
                min_contain = min(min_contain, metrics["component_containment"])
                min_sector = min(min_sector, metrics["sector_fraction"])
                face_polys[label] = poly
                region_labels[label] = region_label
                face_metrics[label] = {
                    "full_pattern": spec["full_pattern"],
                    "offset": spec["offset"],
                    "region_label": region_label,
                    **metrics,
                }
            if ok:
                candidates.append({
                    "score": float(total),
                    "min_component_containment": float(min_contain),
                    "min_sector_fraction": float(min_sector),
                    "specs": specs,
                    "face_metrics": face_metrics,
                    "face_polys": face_polys,
                    "region_labels": region_labels,
                })

    candidates.sort(key=lambda c: c["score"], reverse=True)
    row["boundary_spec_candidates_seen"] = spec_candidates_seen
    row["boundary_spec_limit_exceeded"] = spec_limit_exceeded
    row["boundary_candidates"] = len(candidates)
    if not candidates:
        row["boundary_status"] = "no_boundary_candidate"
        if overlay_path is not None:
            _write_boundary_overlay(gray, detections, regions, None, row, overlay_path)
        return row

    edge_dist = _edge_distance_map(gray)
    edge_tol = max(2.0, 0.0025 * float(np.hypot(w, h)))
    edge_pool = candidates[:max(1, int(edge_top_candidates))]
    for candidate in edge_pool:
        min_edge = 1.0
        mean_edges = []
        for label, poly in candidate["face_polys"].items():
            support = _poly_edge_support(
                poly, edge_dist, tolerance_px=edge_tol)
            candidate["face_metrics"][label].update(support)
            min_edge = min(min_edge, support["edge_support_min"])
            mean_edges.append(support["edge_support_mean"])
        candidate["mean_edge_support"] = (
            float(np.mean(mean_edges)) if mean_edges else 0.0)
        candidate["min_edge_support"] = float(min_edge)
        candidate["final_score"] = float(
            candidate["score"]
            + 4.0 * candidate["mean_edge_support"]
            + 2.0 * candidate["min_edge_support"]
        )
    for candidate in candidates[len(edge_pool):]:
        candidate["mean_edge_support"] = None
        candidate["min_edge_support"] = None
        candidate["final_score"] = candidate["score"]

    candidates.sort(key=lambda c: c["final_score"], reverse=True)

    strict_candidates = [
        c for c in candidates
        if float(c.get("min_component_containment", 0.0)) >= float(strict_min_component)
        and float(c.get("min_sector_fraction", 0.0)) >= float(strict_min_sector)
        and c.get("min_edge_support") is not None
        and float(c.get("min_edge_support", 0.0)) >= float(strict_min_edge)
    ]
    strict_candidates.sort(key=lambda c: c["final_score"], reverse=True)
    strict_best = strict_candidates[0] if strict_candidates else None
    strict_second_score = (
        None if len(strict_candidates) < 2
        else float(strict_candidates[1]["final_score"])
    )
    strict_close = []
    if strict_best is not None:
        strict_close = [
            c for c in strict_candidates
            if float(c["final_score"]) >= float(strict_best["final_score"]) - float(boundary_gap)
        ]

    strict_pnp_candidates = []
    if K_seed is not None and np.all(np.isfinite(K_seed)):
        for rank, candidate in enumerate(strict_candidates, 1):
            if "pnp_rmse_px" not in candidate or candidate.get("pnp_rmse_px") is None:
                pnp_rmse = _pnp_rmse(detections, candidate["specs"], K_seed)
                candidate["pnp_rmse_px"] = pnp_rmse
            candidate["strict_rank"] = rank
            pnp_rmse = candidate.get("pnp_rmse_px")
            if pnp_rmse is not None and math.isfinite(float(pnp_rmse)):
                strict_pnp_candidates.append(candidate)
    strict_pnp_candidates.sort(
        key=lambda c: (float(c["pnp_rmse_px"]), -float(c["final_score"]))
    )
    strict_best_pnp = strict_pnp_candidates[0] if strict_pnp_candidates else None
    strict_close_pnp = []
    strict_second_pnp = None
    strict_pnp_status = "no_strict_pnp_candidate"
    if strict_best_pnp is not None:
        strict_second_pnp = (
            None if len(strict_pnp_candidates) < 2
            else float(strict_pnp_candidates[1]["pnp_rmse_px"])
        )
        strict_best_pnp_rmse = float(strict_best_pnp["pnp_rmse_px"])
        strict_close_pnp = [
            c for c in strict_pnp_candidates
            if float(c["pnp_rmse_px"]) <= strict_best_pnp_rmse + float(pnp_gap_px)
        ]
        if strict_best_pnp_rmse > float(pnp_max_rmse_px):
            strict_pnp_status = "strict_pnp_too_high"
        elif len(strict_close_pnp) == 1:
            strict_pnp_status = "unique_strict_pnp_candidate"
        else:
            strict_pnp_status = "ambiguous_strict_pnp_candidate"

    if strict_best is None:
        strict_status = "no_strict_candidate"
    elif len(strict_close) == 1:
        strict_status = "unique_strict_boundary_candidate"
    else:
        strict_status = "ambiguous_strict_boundary_candidate"

    pnp_pool = candidates if int(pnp_top_candidates) <= 0 else candidates[:max(1, int(pnp_top_candidates))]
    pnp_candidates = []
    if K_seed is not None and np.all(np.isfinite(K_seed)):
        for rank, candidate in enumerate(pnp_pool, 1):
            pnp_rmse = _pnp_rmse(detections, candidate["specs"], K_seed)
            candidate["pnp_rmse_px"] = pnp_rmse
            candidate["boundary_rank"] = rank
            if pnp_rmse is not None and math.isfinite(float(pnp_rmse)):
                pnp_candidates.append(candidate)
    for candidate in candidates[len(pnp_pool):]:
        if "pnp_rmse_px" not in candidate:
            candidate["pnp_rmse_px"] = None
        if "boundary_rank" not in candidate:
            candidate["boundary_rank"] = None

    pnp_candidates.sort(key=lambda c: (float(c["pnp_rmse_px"]), -float(c["final_score"])))
    best_pnp = pnp_candidates[0] if pnp_candidates else None
    close_pnp = []
    second_pnp = None
    pnp_status = "no_pnp_candidate"
    if best_pnp is not None:
        second_pnp = (
            float(pnp_candidates[1]["pnp_rmse_px"])
            if len(pnp_candidates) > 1 else None
        )
        best_pnp_rmse = float(best_pnp["pnp_rmse_px"])
        close_pnp = [
            c for c in pnp_candidates
            if float(c["pnp_rmse_px"]) <= best_pnp_rmse + float(pnp_gap_px)
        ]
        if best_pnp_rmse > float(pnp_max_rmse_px):
            pnp_status = "pnp_too_high"
        elif len(close_pnp) == 1:
            pnp_status = "unique_pnp_candidate"
        else:
            pnp_status = "ambiguous_pnp_candidate"

    print_pool = candidates if int(print_top_candidates) <= 0 else candidates[:max(1, int(print_top_candidates))]
    print_candidates = []
    for rank, candidate in enumerate(print_pool, 1):
        print_scores = []
        checker_contrasts = []
        ring_contrasts = []
        border_transitions = []
        border_samples = []
        for corners, pattern, label in detections:
            spec = candidate["specs"].get(label)
            if spec is None:
                continue
            evidence = _printed_checker_evidence(
                gray,
                corners,
                pattern,
                spec["full_pattern"],
                spec["offset"],
            )
            candidate["face_metrics"][label].update(evidence)
            print_scores.append(float(evidence["print_evidence_score"]))
            checker_contrasts.append(float(evidence["print_checker_contrast"]))
            ring_contrasts.append(float(evidence["print_ring_contrast"]))
            border_transitions.append(float(evidence["print_border_transition"]))
            border_samples.append(int(evidence["print_border_samples"]))
        if print_scores:
            candidate["print_rank_input"] = rank
            candidate["print_evidence_score"] = float(np.mean(print_scores))
            candidate["print_evidence_min_score"] = float(min(print_scores))
            candidate["print_checker_contrast_min"] = float(min(checker_contrasts))
            candidate["print_ring_contrast_min"] = float(min(ring_contrasts))
            candidate["print_border_transition_min"] = float(min(border_transitions))
            candidate["print_border_samples_min"] = int(min(border_samples))
            candidate["print_augmented_score"] = float(
                candidate["final_score"]
                + 2.0 * candidate["print_evidence_score"]
                + 1.0 * candidate["print_evidence_min_score"]
            )
            print_candidates.append(candidate)
    for candidate in candidates[len(print_pool):]:
        candidate["print_evidence_score"] = None
        candidate["print_augmented_score"] = None

    print_candidates.sort(
        key=lambda c: (
            -float(c["print_augmented_score"]),
            -float(c["print_evidence_min_score"]),
            -float(c["final_score"]),
        )
    )
    best_print = print_candidates[0] if print_candidates else None
    second_print_score = None
    close_print = []
    print_status = "no_print_candidate"
    if best_print is not None:
        second_print_score = (
            float(print_candidates[1]["print_augmented_score"])
            if len(print_candidates) > 1 else None
        )
        best_print_score = float(best_print["print_augmented_score"])
        close_print = [
            c for c in print_candidates
            if float(c["print_augmented_score"]) >= best_print_score - float(print_gap)
        ]
        if float(best_print["print_evidence_min_score"]) < float(print_min_score):
            print_status = "print_evidence_weak"
        elif len(close_print) == 1:
            print_status = "unique_print_candidate"
        else:
            print_status = "ambiguous_print_candidate"
        pnp_rmse = best_print.get("pnp_rmse_px")
        if (
            print_status == "unique_print_candidate"
            and pnp_rmse is not None
            and math.isfinite(float(pnp_rmse))
            and float(pnp_rmse) > float(pnp_max_rmse_px)
        ):
            print_status = "print_pnp_too_high"

    best = candidates[0]
    second_score = candidates[1]["final_score"] if len(candidates) > 1 else None
    score_gap = None if second_score is None else best["final_score"] - second_score
    close = [
        c for c in candidates
        if c["final_score"] >= best["final_score"] - boundary_gap
    ]
    unique = (
        len(close) == 1
        and best["min_component_containment"] >= 0.90
        and best["min_sector_fraction"] >= 0.55
        and best["min_edge_support"] is not None
        and best["min_edge_support"] >= 0.45
    )
    row.update({
        "boundary_status": (
            "unique_boundary_candidate"
            if unique else "ambiguous_boundary_candidate"
        ),
        "best_boundary_score": best["final_score"],
        "best_boundary_base_score": best["score"],
        "second_boundary_score": second_score,
        "boundary_score_gap": score_gap,
        "close_boundary_candidates": len(close),
        "best_min_component_containment": best["min_component_containment"],
        "best_min_sector_fraction": best["min_sector_fraction"],
        "best_mean_edge_support": best["mean_edge_support"],
        "best_min_edge_support": best["min_edge_support"],
        "strict_status": strict_status,
        "strict_min_component": float(strict_min_component),
        "strict_min_sector": float(strict_min_sector),
        "strict_min_edge": float(strict_min_edge),
        "strict_candidates": len(strict_candidates),
        "strict_close_boundary_candidates": len(strict_close),
        "strict_best_boundary_score": (
            None if strict_best is None else float(strict_best["final_score"])
        ),
        "strict_second_boundary_score": strict_second_score,
        "strict_boundary_score_gap": (
            None if strict_best is None or strict_second_score is None
            else float(float(strict_best["final_score"]) - strict_second_score)
        ),
        "strict_pnp_status": strict_pnp_status,
        "strict_pnp_candidates_scored": len(strict_pnp_candidates),
        "strict_best_pnp_rmse_px": (
            None if strict_best_pnp is None else float(strict_best_pnp["pnp_rmse_px"])
        ),
        "strict_second_pnp_rmse_px": strict_second_pnp,
        "strict_pnp_rmse_gap": (
            None if strict_best_pnp is None or strict_second_pnp is None
            else float(strict_second_pnp - float(strict_best_pnp["pnp_rmse_px"]))
        ),
        "strict_close_pnp_candidates": len(strict_close_pnp),
        "strict_best_specs": (
            "" if strict_best is None
            else json.dumps(strict_best["specs"], sort_keys=True)
        ),
        "strict_best_pnp_specs": (
            "" if strict_best_pnp is None
            else json.dumps(strict_best_pnp["specs"], sort_keys=True)
        ),
        "pnp_status": pnp_status,
        "pnp_candidates_scored": len(pnp_candidates),
        "best_pnp_rmse_px": (
            None if best_pnp is None else float(best_pnp["pnp_rmse_px"])
        ),
        "second_pnp_rmse_px": second_pnp,
        "pnp_rmse_gap": (
            None if best_pnp is None or second_pnp is None
            else float(second_pnp - float(best_pnp["pnp_rmse_px"]))
        ),
        "close_pnp_candidates": len(close_pnp),
        "best_pnp_boundary_rank": (
            None if best_pnp is None else int(best_pnp.get("boundary_rank") or 0)
        ),
        "best_pnp_boundary_score": (
            None if best_pnp is None else float(best_pnp["final_score"])
        ),
        "best_pnp_min_edge_support": (
            None if best_pnp is None else best_pnp.get("min_edge_support")
        ),
        "best_pnp_specs": (
            "" if best_pnp is None
            else json.dumps(best_pnp["specs"], sort_keys=True)
        ),
        "print_status": print_status,
        "print_candidates_scored": len(print_candidates),
        "best_print_augmented_score": (
            None if best_print is None else float(best_print["print_augmented_score"])
        ),
        "second_print_augmented_score": second_print_score,
        "print_score_gap": (
            None if best_print is None or second_print_score is None
            else float(float(best_print["print_augmented_score"]) - second_print_score)
        ),
        "close_print_candidates": len(close_print),
        "best_print_evidence_score": (
            None if best_print is None else float(best_print["print_evidence_score"])
        ),
        "best_print_evidence_min_score": (
            None if best_print is None else float(best_print["print_evidence_min_score"])
        ),
        "best_print_checker_contrast_min": (
            None if best_print is None else float(best_print["print_checker_contrast_min"])
        ),
        "best_print_ring_contrast_min": (
            None if best_print is None else float(best_print["print_ring_contrast_min"])
        ),
        "best_print_border_transition_min": (
            None if best_print is None else float(best_print["print_border_transition_min"])
        ),
        "best_print_border_samples_min": (
            None if best_print is None else int(best_print["print_border_samples_min"])
        ),
        "best_print_pnp_rmse_px": (
            None if best_print is None else best_print.get("pnp_rmse_px")
        ),
        "best_print_boundary_rank": (
            None if best_print is None else int(best_print.get("boundary_rank") or 0)
        ),
        "best_print_specs": (
            "" if best_print is None
            else json.dumps(best_print["specs"], sort_keys=True)
        ),
        "best_boundary_specs": json.dumps(best["specs"], sort_keys=True),
        "best_region_match": json.dumps(best["region_labels"], sort_keys=True),
        "best_face_metrics": json.dumps(best["face_metrics"], sort_keys=True),
    })
    if overlay_path is not None:
        _write_boundary_overlay(gray, detections, regions, best, row, overlay_path)
    return row


def _fmt(value: Any) -> str:
    f = _maybe_float(value)
    return "-" if f is None else f"{f:.3f}"


def _write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    fields = [
        "workspace_path", "rel_path", "group", "image", "status",
        "cube_area_pct", "manual_source", "fx_gt", "boundary_status",
        "layout_source", "n_faces", "patterns", "boundary_candidates",
        "best_boundary_score", "best_boundary_base_score",
        "second_boundary_score", "boundary_score_gap",
        "close_boundary_candidates", "best_min_component_containment",
        "best_min_sector_fraction", "best_mean_edge_support",
        "best_min_edge_support", "boundary_spec_candidates_seen",
        "boundary_spec_limit_exceeded", "strict_status",
        "strict_min_component", "strict_min_sector", "strict_min_edge",
        "strict_candidates", "strict_close_boundary_candidates",
        "strict_best_boundary_score", "strict_second_boundary_score",
        "strict_boundary_score_gap", "strict_pnp_status",
        "strict_pnp_candidates_scored", "strict_best_pnp_rmse_px",
        "strict_second_pnp_rmse_px", "strict_pnp_rmse_gap",
        "strict_close_pnp_candidates", "strict_best_specs",
        "strict_best_pnp_specs", "pnp_status",
        "pnp_candidates_scored", "best_pnp_rmse_px",
        "second_pnp_rmse_px", "pnp_rmse_gap",
        "close_pnp_candidates", "best_pnp_boundary_rank",
        "best_pnp_boundary_score", "best_pnp_min_edge_support",
        "best_pnp_specs", "print_status", "print_candidates_scored",
        "best_print_augmented_score", "second_print_augmented_score",
        "print_score_gap", "close_print_candidates",
        "best_print_evidence_score", "best_print_evidence_min_score",
        "best_print_checker_contrast_min", "best_print_ring_contrast_min",
        "best_print_border_transition_min", "best_print_border_samples_min",
        "best_print_pnp_rmse_px", "best_print_boundary_rank",
        "best_print_specs", "best_boundary_specs", "best_region_match",
        "best_face_metrics",
    ]
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _write_markdown(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    counts: Dict[str, int] = {}
    for row in rows:
        status = str(row.get("boundary_status", ""))
        counts[status] = counts.get(status, 0) + 1

    lines = [
        "# Trihedral Boundary Probe",
        "",
        f"- Images probed: {len(rows)}",
        f"- Boundary status counts: `{counts}`",
        "",
        "| image | group | original status | boundary status | strict status | strict PnP | PnP status | print status | layout | cube area % | candidates | strict cand | boundary close | strict close | PnP RMSE | strict PnP RMSE | print gap | print close | min sector | min edge |",
        "|---|---|---|---|---|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            "| {image} | {group} | {status} | {bstatus} | {sstatus} | {spstatus} | {pstatus} | {prstatus} | {layout} | "
            "{cube} | {cand} | {strict_cand} | {close} | {strict_close} | {pnp} | {strict_pnp} | {pgap} | {pclose} | "
            "{sector} | {min_edge} |".format(
                image=row.get("image", ""),
                group=row.get("group", ""),
                status=row.get("status", ""),
                bstatus=row.get("boundary_status", ""),
                sstatus=row.get("strict_status", ""),
                spstatus=row.get("strict_pnp_status", ""),
                pstatus=row.get("pnp_status", ""),
                prstatus=row.get("print_status", ""),
                layout=row.get("layout_source", ""),
                cube=_fmt(row.get("cube_area_pct")),
                cand=row.get("boundary_candidates", ""),
                strict_cand=row.get("strict_candidates", ""),
                close=row.get("close_boundary_candidates", ""),
                strict_close=row.get("strict_close_boundary_candidates", ""),
                pnp=_fmt(row.get("best_pnp_rmse_px")),
                strict_pnp=_fmt(row.get("strict_best_pnp_rmse_px")),
                pgap=_fmt(row.get("print_score_gap")),
                pclose=row.get("close_print_candidates", ""),
                sector=_fmt(row.get("best_min_sector_fraction")),
                min_edge=_fmt(row.get("best_min_edge_support")),
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--batch-csv",
        type=Path,
        default=Path("batch_results/auto_merge_dense_only_v18/current_batch_results.csv"),
    )
    parser.add_argument("--image-root", type=Path, default=None)
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("batch_results/trihedral_boundary_probe_v1"),
    )
    parser.add_argument("--boundary-gap", type=float, default=0.35)
    parser.add_argument(
        "--edge-top-candidates",
        type=int,
        default=600,
        help="Number of fast boundary candidates to rescore with edge support",
    )
    parser.add_argument(
        "--pnp-top-candidates",
        type=int,
        default=600,
        help="Number of boundary-ranked candidates to rescore with initial PnP; <=0 scores all.",
    )
    parser.add_argument(
        "--pnp-gap-px",
        type=float,
        default=1.0,
        help="Candidates within this RMSE of the best PnP candidate are treated as close.",
    )
    parser.add_argument(
        "--pnp-max-rmse-px",
        type=float,
        default=12.0,
        help="Best PnP RMSE must be at or below this value to be considered usable.",
    )
    parser.add_argument(
        "--print-top-candidates",
        type=int,
        default=600,
        help="Number of boundary-ranked candidates to score with printed checker/border evidence; <=0 scores all.",
    )
    parser.add_argument(
        "--print-gap",
        type=float,
        default=0.35,
        help="Candidates within this augmented score gap are treated as print-close.",
    )
    parser.add_argument(
        "--print-min-score",
        type=float,
        default=1.25,
        help="Minimum per-face printed evidence score for a unique print candidate.",
    )
    parser.add_argument(
        "--write-overlays",
        action="store_true",
        help="Write visual overlays for each probed image",
    )
    parser.add_argument(
        "--match-region-permutations",
        action="store_true",
        help="Try all assignments between detected face labels and trihedral sectors",
    )
    parser.add_argument(
        "--max-spec-candidates",
        type=int,
        default=0,
        help="Optional per-image cap for offset/full-pattern combinations before sector permutations",
    )
    parser.add_argument(
        "--crop-target-dim",
        type=float,
        default=950.0,
        help="Longest side of the optional upscaled cube crop used for trihedral layout.",
    )
    parser.add_argument(
        "--extra-crop-target-dim",
        type=float,
        action="append",
        default=None,
        help="Additional crop-upscale target dimension to try; may be repeated.",
    )
    parser.add_argument(
        "--crop-max-scale",
        type=float,
        default=4.0,
        help="Maximum scale for the optional upscaled cube crop.",
    )
    parser.add_argument(
        "--crop-min-scale",
        type=float,
        default=1.05,
        help="Skip crop-upscaled trihedral layout below this scale.",
    )
    parser.add_argument(
        "--layout-min-gap-deg",
        type=float,
        default=24.0,
        help="Minimum angle between adjacent trihedral rays for this diagnostic.",
    )
    parser.add_argument(
        "--layout-max-gap-deg",
        type=float,
        default=188.0,
        help="Maximum angle between adjacent trihedral rays for this diagnostic.",
    )
    parser.add_argument(
        "--strict-min-component",
        type=float,
        default=0.90,
        help="Diagnostic strict-filter minimum component containment.",
    )
    parser.add_argument(
        "--strict-min-sector",
        type=float,
        default=0.55,
        help="Diagnostic strict-filter minimum projected-board sector fraction.",
    )
    parser.add_argument(
        "--strict-min-edge",
        type=float,
        default=0.45,
        help="Diagnostic strict-filter minimum projected-board edge support.",
    )
    parser.add_argument(
        "--rel-path",
        action="append",
        default=None,
        help="Optional rel_path to probe; may be repeated.",
    )
    parser.add_argument("--area-min", type=float, default=None)
    parser.add_argument("--area-max", type=float, default=None)
    args = parser.parse_args()

    rows = _read_csv(args.batch_csv)
    if args.image_root is None:
        roots = sorted(Path(".").glob("*_extracted/shengkelou"))
        image_root = roots[0].resolve() if roots else None
    else:
        image_root = args.image_root.resolve()

    rel_filter = set(str(p).replace("\\", "/") for p in (args.rel_path or []))
    selected = []
    for row in rows:
        rel = str(row.get("rel_path") or "").replace("\\", "/")
        try:
            area = float(row.get("cube_area_pct") or "nan")
        except ValueError:
            area = float("nan")
        if row.get("group") == "zhang":
            continue
        if row.get("status") not in {
            "partial_face_geometry_boundary",
            "low_confidence",
        }:
            continue
        if rel_filter and rel not in rel_filter:
            continue
        if args.area_min is not None and (not math.isfinite(area) or area < args.area_min):
            continue
        if args.area_max is not None and (not math.isfinite(area) or area > args.area_max):
            continue
        selected.append(row)
    out_rows: List[Dict[str, Any]] = []
    for idx, row in enumerate(selected, 1):
        rel_path = str(row.get("rel_path") or "")
        image_path = (
            image_root / rel_path
            if image_root is not None
            else Path(str(row.get("workspace_path", "")))
        )
        overlay_path = None
        if args.write_overlays:
            safe_name = f"{row.get('group', '')}_{row.get('image', '')}".replace("/", "_")
            overlay_path = args.out_dir / "overlays" / f"{safe_name}_trihedral.jpg"
        probe = probe_image(
            image_path,
            boundary_gap=args.boundary_gap,
            edge_top_candidates=args.edge_top_candidates,
            pnp_top_candidates=args.pnp_top_candidates,
            pnp_gap_px=args.pnp_gap_px,
            pnp_max_rmse_px=args.pnp_max_rmse_px,
            print_top_candidates=args.print_top_candidates,
            print_gap=args.print_gap,
            print_min_score=args.print_min_score,
            match_region_permutations=args.match_region_permutations,
            max_spec_candidates=(
                args.max_spec_candidates if args.max_spec_candidates > 0 else None
            ),
            crop_target_dim=args.crop_target_dim,
            extra_crop_target_dims=args.extra_crop_target_dim,
            crop_max_scale=args.crop_max_scale,
            crop_min_scale=args.crop_min_scale,
            layout_min_gap_deg=args.layout_min_gap_deg,
            layout_max_gap_deg=args.layout_max_gap_deg,
            strict_min_component=args.strict_min_component,
            strict_min_sector=args.strict_min_sector,
            strict_min_edge=args.strict_min_edge,
            overlay_path=overlay_path,
        )
        merged = dict(row)
        merged.update(probe)
        out_rows.append(merged)
        print(
            f"[{idx}/{len(selected)}] {row.get('group')} "
            f"{row.get('image')} {merged.get('boundary_status')}"
        )

    args.out_dir.mkdir(parents=True, exist_ok=True)
    csv_path = args.out_dir / "trihedral_boundary_probe_results.csv"
    md_path = args.out_dir / "trihedral_boundary_probe_summary.md"
    json_path = args.out_dir / "trihedral_boundary_probe_results.json"
    _write_csv(csv_path, out_rows)
    _write_markdown(md_path, out_rows)
    json_path.write_text(
        json.dumps(out_rows, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Wrote: {csv_path}")
    print(f"Wrote: {md_path}")
    print(f"Wrote: {json_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
