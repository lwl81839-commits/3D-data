"""Paired single-frame radial fits: free coefficients versus magnitude soft prior."""
from pathlib import Path
import json,sys,time,shutil
import numpy as np
import cv2
from scipy.optimize import least_squares
import trained_camera_model as tm
import single_frame_k1_experiment as prev

OLD=prev.OUT
OUT=OLD.parent/'single_frame_k1k2_experiment'
OUT.mkdir(exist_ok=True)

def dump(name,x):
    (OUT/name).write_text(json.dumps(tm._finite_json_value(x),ensure_ascii=False,indent=2),encoding='utf-8')

def fit(s,soft,mult):
    w,h=s.image_size; diag=np.hypot(w,h)
    K=tm._camera_matrix(mult*diag,w/2,h/2)
    rv,tv=tm._initial_pose(s,K,np.zeros(5))
    x=np.r_[np.log(K[0,0]),np.log(K[1,1]),w/2,h/2,0.,0.,rv,tv]
    cap=tm.PRINCIPAL_POINT_MAX_OFFSET_SHORT_SIDE_FRACTION*min(w,h)
    lo=np.r_[np.log(.2*diag),np.log(.2*diag),w/2-cap,h/2-cap,-np.inf,-np.inf,[-2*np.pi]*3,-10000,-10000,1]
    hi=np.r_[np.log(3*diag),np.log(3*diag),w/2+cap,h/2+cap,np.inf,np.inf,[2*np.pi]*3,10000,10000,20000]
    x=np.clip(x,lo+1e-6,hi-1e-6)
    def residual(x):
        K,d,poses=tm._unpack_parameters(x,1,s.image_size,2); r,t=poses[0]
        p,_=cv2.projectPoints(s.object_points,r,t,K,d)
        R,_=cv2.Rodrigues(r); depth=(s.object_points@R.T+t)[:,2]
        out=[(p.reshape(-1,2)-s.image_points).ravel(),25*np.maximum(0,1-depth)/max(float(np.median(abs(depth))),100),np.array([
            np.log(K[0,0]/K[1,1])/tm.ASPECT_LOG_RATIO_SIGMA,
            (K[0,2]-w/2)/(tm.PRINCIPAL_POINT_PRIOR_SIGMA_SHORT_SIDE_FRACTION*min(w,h)),
            (K[1,2]-h/2)/(tm.PRINCIPAL_POINT_PRIOR_SIGMA_SHORT_SIDE_FRACTION*min(w,h))])]
        if soft: out.append(np.array([max(0,abs(d[1])-.5*abs(d[0]))/tm.K2_COEFFICIENT_HINGE_SIGMA]))
        return np.concatenate(out)
    opt=least_squares(residual,x,bounds=(lo,hi),loss='soft_l1',f_scale=2,max_nfev=800,xtol=1e-10,ftol=1e-10,gtol=1e-10)
    K,d,poses=tm._unpack_parameters(opt.x,1,s.image_size,2); r,t=poses[0]
    p,_=cv2.projectPoints(s.object_points,r,t,K,d)
    R,_=cv2.Rodrigues(r); depth=(s.object_points@R.T+t)[:,2]
    norm=cv2.undistortPoints(s.image_points.reshape(-1,1,2),K,np.zeros(5)).reshape(-1,2)
    rmax=float(np.max(np.linalg.norm(norm,axis=1)))
    rr=np.linspace(0,rmax,100)
    return dict(cameraMatrix=K.tolist(),distCoeffs=d.tolist(),optimizer_success=bool(opt.success),nfev=opt.nfev,objective=float(opt.cost),training_rmse_px=float(np.sqrt(np.mean(np.sum((p.reshape(-1,2)-s.image_points)**2,axis=1)))),positive_depth_fraction=float(np.mean(depth>0)),min_radial_derivative_observed=float(np.min(1+3*d[0]*rr**2+5*d[1]*rr**4)),principal_point_at_boundary=bool(abs(K[0,2]-w/2)>cap-.01 or abs(K[1,2]-h/2)>cap-.01),initial_focal_fraction=mult)

def train():
    rows=json.loads((OLD/'training_three_face_audit.json').read_text(encoding='utf-8')); models=[]
    for row in rows:
        if not row['strict_three_face']: continue
        s=tm.extract_correspondences(row['image'],25,correspondence_cache_path=row['cache'],minimum_usable_faces=3)
        for soft in [False,True]:
            st=time.perf_counter(); trials=[fit(s,soft,m) for m in [.5,.7,1.]]
            best=min(trials,key=lambda x:x['objective'])
            name=row['pose']+'_'+Path(row['image']).stem+('_soft' if soft else '_free')
            model=dict(name=name,pose=row['pose'],training_image=row['image'],sha256=row['sha256'],training_images_used=1,training_faces=list(s.face_inlier_counts),image_size=list(s.image_size),square_size_mm=25,coefficient_prior='abs(k2)<=0.5*abs(k1)' if soft else 'none',coefficient_prior_sigma=tm.K2_COEFFICIENT_HINGE_SIGMA if soft else None,radial_coefficient_bounds='unbounded for both coefficients',monotonicity_penalty=False,k2_fixed=False,no_zhang_reference_used=True,no_five_image_parameters_used=True,cached_correspondences_used=True,elapsed_fit_s=time.perf_counter()-st,multistart=trials,**best)
            models.append(model); dump(name+'_model.json',model)
            print(name,best['distCoeffs'][:2],best['training_rmse_px'],flush=True)
    dump('single_models.json',models)

def report():
    models=json.loads((OUT/'single_models.json').read_text(encoding='utf-8'))
    summary=json.loads((OUT/'summary.json').read_text(encoding='utf-8'))
    per=json.loads((OUT/'per_image.json').read_text(encoding='utf-8'))
    lines=['# 单张三面 k1+k2 两组实验','',
    '三张训练图分别独立拟合，两组均自由估计k1、k2，不固定k2为0。free组不使用径向系数边界、比例或单调性惩罚；soft组只增加 max(0,|k2|-0.5|k1|)/0.001 残差，经过相同soft_l1鲁棒损失。两组保留相同焦距/主点范围、主点和纵横比先验、正深度约束。软约束允许违反比例。',
    '每张图使用三个通用初值，按包括先验在内的目标函数选择，不按测试误差选择。三面点缓存与刚才k1实验一致。没有使用Zhang或五图模型参数训练。',
    '测试沿用独立154张三维、118张二维图，所有方法相同点和20次划分。复用旧测试代码。模型为研究诊断，不标为通过原五图训练质量门限。','',
    '|模型|k1|k2|训练RMSE(px)|主点碰边界|观测半径内最小径向导数|','|---|---|---|---|---|---|']
    for m in models: lines.append(f"|{m['name']}|{m['distCoeffs'][0]:.6f}|{m['distCoeffs'][1]:.6f}|{m['training_rmse_px']:.3f}|{m['principal_point_at_boundary']}|{m['min_radial_derivative_observed']:.3f}|")
    lines+=['','|配置|类型|模型|子集|图数|留出RMSE(px)|物点RMSE(mm)|25mm误差(%)|','|---|---|---|---|---|---|---|---|']
    fmt=lambda x:'-' if x is None else f'{x:.3f}'
    for r in summary: lines.append(f"|{r['pose']}|{r['kind']}|{r['method']}|{r['subset']}|{r['images']}|{fmt(r['holdout_rmse_px'])}|{fmt(r['object_rmse_mm'])}|{fmt(r['square25_error_pct'])}|")
    lines+=['','## 测试成功率','',
    '误差中位数只计有效返回值，必须结合以下失败数量解读，不能把无法求出位姿的试验当成低误差。','',
    '|模型|类型|图片数|20次全部成功图片|部分失败图片|全部失败图片|','|---|---|---|---|---|---|']
    for name,kind in sorted({(r['method'],r['kind']) for r in per}):
        rr=[r for r in per if r['method']==name and r['kind']==kind]
        lines.append(f"|{name}|{kind}|{len(rr)}|{sum(r['successful_trials']==20 for r in rr)}|{sum(0<r['successful_trials']<20 for r in rr)}|{sum(r['successful_trials']==0 for r in rr)}|")
    lines+=['','注意：小的训练重投影误差和非零k2不证明系数可辨识。完整参数及三个初值结果在single_models.json。尺寸误差基于同一标定物，非独立计量真值。两组只有径向系数比例惩罚不同，适合比较该经验先验对单张拟合的影响。']
    (OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='train': train()
    elif mode=='test':
        shutil.copytree(OLD/'planar_cache',OUT/'planar_cache',dirs_exist_ok=True)
        prev.OUT=OUT; prev.evaluate(); report()
