#!/usr/bin/env python3
"""Run and summarize repeatability for a representative fast-v2 subset."""

from __future__ import annotations

import csv
import math
import subprocess
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, median, pstdev


ROOT = Path(__file__).resolve().parents[1]
REL_FILE = ROOT / "paper_drafts" / "repeat20_relpaths_20260720.txt"
OUT_ROOT = ROOT / "batch_results" / "repeatability_20260720" / "repeat20_fast_v2"
SUMMARY_CSV = ROOT / "paper_drafts" / "repeat20_fast_v2_nondeterminism_20260720.csv"
SUMMARY_MD = ROOT / "paper_drafts" / "repeat20_fast_v2_nondeterminism_20260720.md"


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def fnum(row: dict[str, str], key: str) -> float:
    try:
        value = float(row.get(key, ""))
    except ValueError:
        return float("nan")
    return value if math.isfinite(value) else float("nan")


def fmt(value: float, ndigits: int = 4) -> str:
    return "" if not math.isfinite(value) else f"{value:.{ndigits}f}"


def stat(values: list[float]) -> dict[str, float]:
    vals = [v for v in values if math.isfinite(v)]
    if not vals:
        return {"mean": math.nan, "median": math.nan, "std": math.nan, "min": math.nan, "max": math.nan}
    return {
        "mean": mean(vals),
        "median": median(vals),
        "std": pstdev(vals) if len(vals) > 1 else 0.0,
        "min": min(vals),
        "max": max(vals),
    }


def run_round(round_idx: int, *, workers: int, timeout: float) -> Path:
    out_dir = OUT_ROOT / f"round_{round_idx:02d}"
    csv_path = out_dir / "current_batch_results.csv"
    if csv_path.exists():
        print(f"[round {round_idx}] reuse {csv_path}", flush=True)
        return csv_path
    out_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable,
        str(ROOT / "batch_evaluate_current.py"),
        "--method-profile",
        "ge2_single_frame_cube_fast",
        "--rel-path-file",
        str(REL_FILE),
        "--out-dir",
        str(out_dir),
        "--workers",
        str(workers),
        "--mode",
        "subprocess",
        "--per-image-timeout",
        str(timeout),
        "--square-size-mm",
        "25",
    ]
    print(f"[round {round_idx}] start", flush=True)
    t0 = time.time()
    subprocess.run(cmd, cwd=str(ROOT), check=True)
    print(f"[round {round_idx}] done in {time.time() - t0:.1f}s", flush=True)
    return csv_path


def summarize(csv_paths: list[Path], *, workers: int, timeout: float) -> None:
    rows: list[dict[str, str]] = []
    for idx, path in enumerate(csv_paths, 1):
        for row in read_rows(path):
            row = dict(row)
            row["repeat_round"] = str(idx)
            rows.append(row)

    by_rel: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        by_rel[row["rel_path"]].append(row)

    fieldnames = [
        "rel_path",
        "group",
        "kind",
        "n",
        "ok_count",
        "status_set",
        "calibration_status_set",
        "model_grade_set",
        "negative_false_accepts",
        "rmse_mean",
        "rmse_std",
        "rmse_range",
        "fx_mean",
        "fx_std",
        "fy_mean",
        "fy_std",
        "cx_std",
        "cy_std",
        "k1_std",
        "wall_mean",
        "wall_max",
    ]
    summary_rows: list[dict[str, str]] = []
    for rel, subset in sorted(by_rel.items()):
        statuses = sorted({r.get("status", "") for r in subset})
        cal_statuses = sorted({r.get("calibration_status", "") for r in subset})
        grades = sorted({r.get("model_grade", "") for r in subset})
        is_negative = all(r.get("group") == "zhang" or r.get("status") != "ok" for r in subset) and not any(
            r.get("status") == "ok" and r.get("group") != "zhang" for r in subset
        )
        ok_rows = [r for r in subset if r.get("status") == "ok"]
        rmse_s = stat([fnum(r, "rmse_px") for r in ok_rows])
        fx_s = stat([fnum(r, "fx_px") for r in ok_rows])
        fy_s = stat([fnum(r, "fy_px") for r in ok_rows])
        cx_s = stat([fnum(r, "cx_px") for r in ok_rows])
        cy_s = stat([fnum(r, "cy_px") for r in ok_rows])
        k1_s = stat([fnum(r, "k1") for r in ok_rows])
        wall_s = stat([fnum(r, "wall_elapsed_sec") for r in subset])
        summary_rows.append(
            {
                "rel_path": rel,
                "group": subset[0].get("group", ""),
                "kind": "negative_or_unusable" if subset[0].get("group") == "zhang" or rel in {"15.2_0.986/t_5_14.jpg", "20_0.840/t_3_00.jpg"} else "positive",
                "n": str(len(subset)),
                "ok_count": str(len(ok_rows)),
                "status_set": ";".join(statuses),
                "calibration_status_set": ";".join(cal_statuses),
                "model_grade_set": ";".join(grades),
                "negative_false_accepts": str(sum(1 for r in subset if r.get("group") == "zhang" and r.get("status") == "ok")),
                "rmse_mean": fmt(rmse_s["mean"], 6),
                "rmse_std": fmt(rmse_s["std"], 6),
                "rmse_range": fmt(rmse_s["max"] - rmse_s["min"], 6),
                "fx_mean": fmt(fx_s["mean"], 6),
                "fx_std": fmt(fx_s["std"], 6),
                "fy_mean": fmt(fy_s["mean"], 6),
                "fy_std": fmt(fy_s["std"], 6),
                "cx_std": fmt(cx_s["std"], 6),
                "cy_std": fmt(cy_s["std"], 6),
                "k1_std": fmt(k1_s["std"], 10),
                "wall_mean": fmt(wall_s["mean"], 3),
                "wall_max": fmt(wall_s["max"], 3),
            }
        )

    with SUMMARY_CSV.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(summary_rows)

    positive = [r for r in summary_rows if r["kind"] == "positive"]
    negative = [r for r in summary_rows if r["kind"] == "negative_or_unusable"]
    stable_status = sum(1 for r in summary_rows if ";" not in r["status_set"])
    positive_full_ok = sum(1 for r in positive if r["ok_count"] == r["n"])
    pos_with_fail = [r for r in positive if r["ok_count"] != r["n"]]
    neg_false = sum(int(r["negative_false_accepts"]) for r in negative)
    fx_std_vals = [float(r["fx_std"]) for r in positive if r["fx_std"]]
    rmse_std_vals = [float(r["rmse_std"]) for r in positive if r["rmse_std"]]
    wall_max_vals = [float(r["wall_max"]) for r in summary_rows if r["wall_max"]]
    status_counts = Counter((r.get("status") or "") for r in rows)
    cal_counts = Counter((r.get("calibration_status") or "") for r in rows)

    lines = [
        "# Repeat20 Fast V2 Nondeterminism 2026-07-20",
        "",
        f"Rel-path file: `{REL_FILE.relative_to(ROOT)}`",
        f"Output root: `{OUT_ROOT.relative_to(ROOT)}`",
        f"Summary CSV: `{SUMMARY_CSV.relative_to(ROOT)}`",
        "",
        "## Scope",
        "",
        f"- representative images: {len(by_rel)}",
        f"- repeats per image: {len(csv_paths)}",
        f"- workers per round: {workers}",
        f"- per-image timeout: {timeout:g} s",
        f"- total rows: {len(rows)}",
        "",
        "## Main Result",
        "",
        f"- status-stable images: {stable_status}/{len(by_rel)}",
        f"- positive images full OK: {positive_full_ok}/{len(positive)}",
        f"- positive images with at least one non-OK repeat: {len(pos_with_fail)}",
        f"- negative false accepts: {neg_false}/{sum(int(r['n']) for r in negative)}",
        f"- status counts: `{dict(status_counts)}`",
        f"- calibration gate counts: `{dict(cal_counts)}`",
        f"- median positive fx std: {fmt(stat(fx_std_vals)['median'], 6)} px",
        f"- max positive fx std: {fmt(stat(fx_std_vals)['max'], 6)} px",
        f"- median positive RMSE std: {fmt(stat(rmse_std_vals)['median'], 6)} px",
        f"- max positive RMSE std: {fmt(stat(rmse_std_vals)['max'], 6)} px",
        f"- max row wall time: {fmt(max(wall_max_vals) if wall_max_vals else math.nan, 3)} s",
        "",
        "## Per-image Summary",
        "",
        "| rel path | kind | ok | status set | gate set | RMSE std | fx std | wall max s |",
        "|---|---|---:|---|---|---:|---:|---:|",
    ]
    for r in summary_rows:
        lines.append(
            f"| `{r['rel_path']}` | {r['kind']} | {r['ok_count']}/{r['n']} | "
            f"`{r['status_set']}` | `{r['calibration_status_set']}` | "
            f"{r['rmse_std'] or '-'} | {r['fx_std'] or '-'} | {r['wall_max'] or '-'} |"
        )
    if pos_with_fail:
        lines += [
            "",
            "## Positive Non-OK Repeats",
            "",
            "| rel path | ok | status set | gate set |",
            "|---|---:|---|---|",
        ]
        for r in pos_with_fail:
            lines.append(
                f"| `{r['rel_path']}` | {r['ok_count']}/{r['n']} | `{r['status_set']}` | `{r['calibration_status_set']}` |"
            )
    lines += [
        "",
        "## Interpretation Boundary",
        "",
        "This repeatability test uses the current fast-v2 profile on a deliberately mixed 20-image subset. It evaluates operational nondeterminism under repeated batch scheduling, including difficult small targets and negative/unusable inputs. It should not be interpreted as a full136 repeatability test.",
    ]
    SUMMARY_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    repeats = 5
    workers = 8
    timeout = 900.0
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    paths = [run_round(i, workers=workers, timeout=timeout) for i in range(1, repeats + 1)]
    summarize(paths, workers=workers, timeout=timeout)
    print(f"Wrote {SUMMARY_CSV}")
    print(f"Wrote {SUMMARY_MD}")


if __name__ == "__main__":
    main()
