"""Summarize isolated follow-up experiments without changing primary results."""
from pathlib import Path
import json, hashlib
import numpy as np
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/experiment_0820_precision_test'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
rows=[]
for d in sorted((OUT/'models').glob('*/*')):
    pose,variant=d.parent.name,d.name
    m=read(d/'trained_camera_model.json')
    e=read(OUT/'evaluations'/pose/variant/'evaluation.json')['summary']
    p=read(OUT/'planar_evaluations'/pose/'evaluation.json')['summaries'][variant]
    rows.append(dict(pose=pose,variant=variant,accepted=m['accepted'],K=m['cameraMatrix'],dist=m['distCoeffs'],train_rmse=m['diagnostics']['joint_reprojection_rmse_px'],planar_rmse=p['holdout_rmse_px']['median'],cuboid_rmse=e['holdout_error_px']['median'],cuboid_p95=e['holdout_error_px']['p95'],length_median_pct=e['holdout_length_relative_error_pct']['median'],length_p95_pct=e['holdout_length_relative_error_pct']['p95'],face_histogram=e['face_evidence_histogram'],refinement=m['diagnostics']['radial_regularization'],cross_validation=m['cross_validation']))
save(OUT/'analysis.json',rows)
lines=['# 0820 后续诊断实验汇总','',
'本轮不更改主程序、原始训练/测试划分、主模型或论文。训练均未使用 MATLAB/张正友参考参数。所有失败与诊断性拒绝保留。','',
'## 1. 双精度残差配对实验','',
'五个配置各使用原来的同一组五张训练图；仅将径向精修中的三维点、图像点和 K 转为 float64。初值、软约束、门限及测试图不变。每个版本每配置训练一次；每张测试图重复角点留出 20 次，不代表 20 次独立采集。',
'','|配置|版本|训练 RMSE/px|2D 留出 RMSE 中位数/px|3D 留出 RMSE 中位数/px|3D 留出 RMSE P95/px|k1|k2|通过原门限|','|---|---|---|---|---|---|---|---|---|']
for r in rows:lines.append(f"|{r['pose']}|{r['variant']}|{r['train_rmse']:.4f}|{r['planar_rmse']:.4f}|{r['cuboid_rmse']:.4f}|{r['cuboid_p95']:.4f}|{r['dist'][0]:.6f}|{r['dist'][1]:.6f}|{r['accepted']}|")
lines+=['','2D 汇总为逐图留出试验中位数的图间中位数；3D 汇总为原评估器所有留出试验的中位数，二者不是同一聚合定义。比较仅在同一数据类型、同一配置内进行。3D 图可以只有一个有效面，这些误差不能一概称为三面几何验证。长度指标依赖既有棋盘格和已知平面，不是独立外部计量真值。','',
'有限差分审计见 ../experiment_0820_stability_curve/finite_difference_precision.json：对每配置一个面，默认差分步长下 float32 的 k2 导数有 96%–100% 分量为零；float64 与 OpenCV 解析导数比较恢复了灵敏度。此结果证明被测残差的数值问题，不证明所有历史参数错误，也不保证修复后每张测试图改善。','',
'## 2. 不完整但已索引角点的利用','',
'与扩展样本数实验中完全相同的五张图子集配对，只扩展局部平面观测接口。允许满足格点、唯一性、至少 12 点、至少四行四列及原单应性门限的稀疏观测；不生成缺失角点。以下旧/新均来自同一探索性划分，不与上面的原主划分混合比较。','',
'|配置|旧：完成/通过|稀疏支持：完成/通过|旧 2D/3D RMSE 中位数/px|稀疏支持 2D/3D RMSE 中位数/px|','|---|---|---|---|---|']
A=ROOT/'output/experiment_0820_stability_curve'
C=ROOT/'output/experiment_0820_sparse_observation_test'
old=read(A/'analysis.json')['groups'];sparse=[]
for split in read(C/'protocol.json')['splits']:
    pose=split['pose']; rr=[]
    for d in sorted((C/'models'/pose).iterdir()):
        st=read(d/'status.json'); row=dict(pose=pose,name=d.name,**st)
        assert read(d/'selection.json')['selected']==read(A/'models'/pose/d.name/'selection.json')['selected']
        if st['completed']:
            m=read(d/'trained_camera_model.json');e=read(C/'evaluations'/pose/d.name/'evaluation.json')['summary'];p=read(C/'planar_evaluations'/pose/'evaluation.json')['summaries'][d.name]
            row.update(planar_rmse=p['holdout_rmse_px']['median'],cuboid_rmse=e['holdout_error_px']['median'],diagnostics=m['diagnostics'],dist=m['distCoeffs'])
        rr.append(row)
    sparse.extend(rr);g=next(g for g in old if g['pose']==pose and g['n']==5)
    new2=np.median([r['planar_rmse'] for r in rr if r['completed']]);new3=np.median([r['cuboid_rmse'] for r in rr if r['completed']])
    lines.append(f"|{pose}|{g['completed']}/3，{g['accepted']}/3|{sum(r['completed'] for r in rr)}/3，{sum(r['accepted'] for r in rr)}/3|{g['2D']['median']:.4f} / {g['3D']['median']:.4f}|{new2:.4f} / {new3:.4f}|")
save(C/'matched_analysis.json',sparse)
lines+=['','误差包含已完成但未通过门限的模型；旧版不完整运行不能当作低误差成功。仅比较完成项的汇总有选择效应，逐次结果在 matched_analysis.json。','',
'## 3. 样本数量与图片要求','',
'完整预算实验见 ../experiment_0820_stability_curve/REPORT.md；按训练观测可用性筛选的对照见 ../experiment_0820_quality_curve/REPORT.md。它们使用事先固定的三组嵌套随机顺序及固定验证集，未按验证误差选图；但使用过往已经检查的图，因此属于探索性开发，不能作为全新最终盲测。',
'','不能据此宣称所有配置五张足够。配置 30_0.827 筛选后五张是局部稳定候选，但只有三次重复且下一预算六张使用相同全池，证据有限。其他配置仍有子集敏感、误差变差或门限未通过。数值精度问题应先排除，再复核样本数曲线。',
'','## 建议优先级','',
'1. 优先保证精修残差/导数的数值正确性；不能靠调强先验掩盖导数问题。',
'2. 稀疏观测应显式传递局部格点坐标，单独检查点序和面内坐标一致性；完成率提升不等于精度改善。',
'3. 在修正后的冻结实现上重复样本预算实验，报告子集波动、完整失败率、测试误差与径向映射稳定性；k1/k2 单个数值稳定性不能替代实际预测。',
'4. 若新方案需持续调参，应另留未参与开发的最终数据。现阶段不修改论文中的主结果或以诊断结果替换正式结果。']
assert hashlib.sha256((ROOT/'trained_camera_model.py').read_text(encoding='utf-8').encode()).hexdigest()==read(OUT/'protocol.json')['source_sha256']
(OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
print('\n'.join(lines))
