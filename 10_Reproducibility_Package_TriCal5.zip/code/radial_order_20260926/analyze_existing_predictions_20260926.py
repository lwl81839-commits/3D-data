"""Image-level tails and matched single/five comparisons; no refitting."""
from pathlib import Path
import json
import numpy as np
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'output/information_budget_20260915'
OUT=ROOT/'output/predictive_utility_20260926'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def stats(values):
    x=np.asarray(values,float)
    if not len(x):return dict(n=0)
    return dict(n=len(x),median=float(np.median(x)),p90=float(np.quantile(x,.9)),p95=float(np.quantile(x,.95)),maximum=float(np.max(x)),threshold_percent={str(t):float(100*np.mean(x<=t)) for t in [1,2,3,5]})
def score(r,b):
    if b is not None:return r['regions'][b]['rmse']
    g=[q for q in r['regions'] if q['n'] and q['rmse'] is not None]
    return float(np.sqrt(sum(q['n']*q['rmse']**2 for q in g)/sum(q['n'] for q in g))) if g else None
def run():
    audit=read(ROOT/'output/single_frame_k1_experiment/training_three_face_audit.json')
    strict={(a['pose'],Path(a['image']).name) for a in audit if a.get('strict_three_face')}
    rows=[];pairs=[];models=[]
    for folder in sorted(SRC.iterdir()):
        if not folder.is_dir() or not (folder/'test_manifest.json').exists():continue
        manifest=read(folder/'test_manifest.json');five=read(folder/'subset_01234.json')
        selected=[('five',five)]
        for i,tr in enumerate(manifest['training']):
            name=Path(tr['image']).name
            if (folder.name,name) in strict:
                m=read(folder/f'subset_{i}.json')
                if m['completed']:selected.append((name,m))
        for label,m in selected:
            if not m['completed']:continue
            models.append(dict(pose=folder.name,label=label,K=m['cameraMatrix'],dist=m['distCoeffs']))
            for kind in ['2D','3D']:
                rr=[r for r in m['evaluation'] if r['kind']==kind]
                for b,region in [(None,'all'),(0,'center'),(1,'middle'),(2,'outer')]:
                    vals=[score(r,b) for r in rr];vals=[v for v in vals if v is not None]
                    rows.append(dict(pose=folder.name,model=label,kind=kind,region=region,images=len(rr),successful_trials=sum(r['successful_trials'] for r in rr),total_trials=sum(r['total_trials'] for r in rr),**stats(vals)))
                    if label=='five':continue
                    ref={r['image']:r for r in five['evaluation'] if r['kind']==kind}
                    delta=[]
                    for r in rr:
                        a=score(r,b);z=score(ref[r['image']],b)
                        if a is not None and z is not None:delta.append(a-z)
                    pairs.append(dict(pose=folder.name,model=label,kind=kind,region=region,n=len(delta),single_better=sum(v<0 for v in delta),five_better=sum(v>0 for v in delta),median_single_minus_five=float(np.median(delta)) if delta else None))
    save(OUT/'image_tail_summary.json',dict(rows=rows,paired=pairs,models=models,scope='Existing 0820 tests reused. Per-image pooled held-out RMSE across five splits; all-region RMSE reconstructed by point-count weighting. Thresholds are descriptive, not application standards. Regional image sets overlap. Conditional successful models only; no overall detection/fit success claim.'))
    lines=['# Existing-data predictive utility analysis','','No new acquisition or refitting. All scores below are IMAGE-level RMSE distributions, not corner-error percentiles. Thresholds are descriptive; test sets have already been consulted.','','## Full-image tails','','|Configuration|Model|Test|Images|Median|P95|Max|<=1 px %|<=2 px %|<=3 px %|<=5 px %|','|---|---|---|---|---|---|---|---|---|---|---|']
    for r in rows:
        if r['region']!='all' or not r['n']:continue
        q=r['threshold_percent'];lines.append(f"|{r['pose']}|{r['model']}|{r['kind']}|{r['n']}|{r['median']:.3f}|{r['p95']:.3f}|{r['maximum']:.3f}|{q['1']:.1f}|{q['2']:.1f}|{q['3']:.1f}|{q['5']:.1f}|")
    lines+=['','## Regional tails (successful strict-three-face single fits and matched five-image model)','','|Model|Test|Region|Images|Median|P95|<=2 px %|<=3 px %|','|---|---|---|---|---|---|---|---|']
    for r in rows:
        if r['pose']!='45_1.155' or r['region']=='all' or not r['n']:continue
        q=r['threshold_percent'];lines.append(f"|{r['model']}|{r['kind']}|{r['region']}|{r['n']}|{r['median']:.3f}|{r['p95']:.3f}|{q['2']:.1f}|{q['3']:.1f}|")
    lines+=['','## Paired comparisons','','|Single image|Test|Region|Paired images|Single wins|Five wins|Median single-minus-five px|','|---|---|---|---|---|---|---|']
    for r in pairs:lines.append(f"|{r['model']}|{r['kind']}|{r['region']}|{r['n']}|{r['single_better']}|{r['five_better']}|{r['median_single_minus_five']:.4f}|")
    lines+=['','Five-image models use the same diagnostic staged fit, priors, observations and random splits as single-image models. They are not substituted with another historical model. The five training images are not all strict-three-face qualified; this is an operational matched comparison, not a uniformly qualified image-count law. A regional result covers observed points only, not all pixels. Maxima and percentile estimates are finite-sample descriptors.']
    (OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    print('\n'.join(lines[:22]))
if __name__=='__main__':run()
