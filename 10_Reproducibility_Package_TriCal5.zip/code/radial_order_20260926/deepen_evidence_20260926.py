"""Paired image bootstrap, face stratification, ray differences, worst-case audits."""
from pathlib import Path
import hashlib,shutil
import numpy as np
import cv2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import trained_camera_model as t
import evaluate_trained_camera_model as ev
import evaluate_planar_blind_comparison as ep
from run_stability_verification_20260914 import SPLIT,BASE,POSES
from analyze_existing_predictions_20260926 import ROOT,SRC,OUT,read,save,score,stats
DEST=OUT/'evidence_audit'
def bootstrap(a,b,seed=926):
    a,b=np.asarray(a),np.asarray(b);n=len(a)
    if not n:return None
    rng=np.random.default_rng(seed);ix=rng.integers(0,n,(10000,n));delta=a-b
    md=np.median(delta[ix],axis=1)
    return dict(n=n,median_paired_difference=float(np.median(delta)),ci95=np.quantile(md,[.025,.975]).tolist(),resamples=10000,unit='image',direction='single minus five; negative favors single',equivalence_claim=False)
def rays(points,K,d):
    xy=cv2.undistortPointsIter(np.asarray(points,float).reshape(-1,1,2),K,d,None,None,(cv2.TERM_CRITERIA_COUNT|cv2.TERM_CRITERIA_EPS,100,1e-12)).reshape(-1,2)
    v=np.c_[xy,np.ones(len(xy))];v/=np.linalg.norm(v,axis=1)[:,None]
    # Verify inverse by redistorting; exclude failed inverse points explicitly.
    pred,_=cv2.projectPoints(np.c_[xy,np.ones(len(xy))],np.zeros(3),np.zeros(3),K,d)
    ok=np.all(np.isfinite(xy),axis=1)&(np.linalg.norm(pred.reshape(-1,2)-points,axis=1)<.01)
    return xy,v,ok
def run():
    cv2.setNumThreads(1);DEST.mkdir(parents=True,exist_ok=True)
    allmodels=[];paired=[];strata=[];mapping=[];audits=[];extraction=[]
    for pose in POSES:
        manifest=read(SRC/pose/'test_manifest.json')
        models=[('five',read(SRC/pose/'subset_01234.json'))]
        if pose=='45_1.155':
            for i,tr in enumerate(manifest['training']):
                name=Path(tr['image']).name
                if name in ['t_4_10.jpg','t_4_17.jpg']:models.append((name,read(SRC/pose/f'subset_{i}.json')))
        samples={}
        for item in manifest['images']:
            if item['kind']!='3D':continue
            p=SPLIT/'test'/pose/'3D'/item['image'];h=hashlib.sha256(p.read_bytes()).hexdigest()
            try:
                caches=list((BASE/'test_correspondence_cache'/pose).glob(h+'_sq25_*.npz'));assert len(caches)==1
                cv2.setRNGSeed(20260912)
                s=t.extract_correspondences(str(p),25,correspondence_cache_path=str(caches[0]),minimum_usable_faces=1)
                samples[p.name]=(p,s,ev.face_ids(s.object_points))
            except Exception as e:extraction.append(dict(pose=pose,image=str(p),error=str(e)))
        five=models[0][1]
        for label,m in models:
            K=np.array(m['cameraMatrix']);d=np.array(m['distCoeffs'])
            for kind in ['2D','3D']:
                for b,region in [(None,'all'),(0,'center'),(1,'middle'),(2,'outer')]:
                    rr=[r for r in m['evaluation'] if r['kind']==kind]
                    if label!='five':
                        ref={r['image']:r for r in five['evaluation'] if r['kind']==kind};aa=[];bb=[]
                        for r in rr:
                            a,z=score(r,b),score(ref[r['image']],b)
                            if a is not None and z is not None:aa.append(a);bb.append(z)
                        paired.append(dict(model=label,kind=kind,region=region,**bootstrap(aa,bb)))
            for facecount in [1,2,3]:
                rr=[r for r in m['evaluation'] if r['kind']=='3D' and r['image'] in samples and len(np.unique(samples[r['image']][2]))==facecount]
                vals=[score(r,None) for r in rr if score(r,None) is not None]
                strata.append(dict(pose=pose,model=label,faces=facecount,**stats(vals),raw_image_scores=[dict(image=r['image'],rmse=score(r,None)) for r in rr]))
            worst=sorted([r for r in m['evaluation'] if r['kind']=='3D' and score(r,None) is not None],key=lambda r:score(r,None),reverse=True)[:2]
            for rr in worst:
                if rr['image'] not in samples:continue
                path,s,ids=samples[rr['image']];obj,im=s.object_points,s.image_points;idx=np.arange(len(obj))
                cv2.setRNGSeed(926);fit=ev.solve_pose(obj,im,idx,K,d)
                record=dict(pose=pose,model=label,image=path.name,heldout_rmse=score(rr,None),faces=len(np.unique(ids)),per_face=[],scope='diagnostic all-point refit, not held-out score; high-error selection disclosed')
                if fit is None:record['refit_failed']=True;audits.append(record);continue
                pred,_=cv2.projectPoints(obj,fit.rvec,fit.tvec,K,d);pred=pred.reshape(-1,2)
                for face in np.unique(ids):
                    ix=np.flatnonzero(ids==face);coords=obj[ix];axes=np.argsort(np.ptp(coords,axis=0))[-2:];local=np.zeros_like(coords);local[:,:2]=coords[:,axes]
                    p=ep.solve_pose(local,im[ix],np.arange(len(ix)),K,d)
                    independent=ep.project_errors(local,im[ix],np.arange(len(ix)),p,K,d) if p is not None else None
                    record['per_face'].append(dict(face=int(face),points=len(ix),rigid_rmse=float(np.sqrt(np.mean(np.sum((pred[ix]-im[ix])**2,axis=1)))),independent_plane_rmse=float(np.sqrt(np.mean(independent**2))) if independent is not None else None,duplicate_image_points=len(ix)-len(np.unique(np.round(im[ix],4),axis=0))))
                image=cv2.imdecode(np.fromfile(path,dtype=np.uint8),cv2.IMREAD_COLOR)
                fig,ax=plt.subplots(figsize=(10,5.8));ax.imshow(cv2.cvtColor(image,cv2.COLOR_BGR2RGB))
                ax.scatter(im[:,0],im[:,1],s=12,facecolors='none',edgecolors='lime',label='Observed');ax.scatter(pred[:,0],pred[:,1],s=12,c='red',marker='x',label='Rigid projection')
                for a,z in zip(im,pred):ax.plot([a[0],z[0]],[a[1],z[1]],color='yellow',lw=.6)
                ax.set_title(f'{pose} / {label} / {path.name}\nheld-out RMSE {score(rr,None):.2f}px; displayed: all-point diagnostic fit');ax.legend(fontsize=8);ax.axis('off');fig.tight_layout()
                fname=pose+'_'+label.replace('.jpg','')+'_'+path.stem+'.png';fig.savefig(DEST/fname,dpi=130);plt.close(fig);record['figure']=fname;audits.append(record)
        # No pose estimation: compare camera rays for identical observed test pixels.
        points=np.concatenate([s.image_points for _,s,_ in samples.values()]);K0=np.array(five['cameraMatrix']);d0=np.array(five['distCoeffs']);xy0,v0,ok0=rays(points,K0,d0)
        candidates=[(label,m) for label,m in models if label!='five']
        for folder in sorted((ROOT/'output/stability_verification_20260914/models'/pose).iterdir()):
            if folder.name.startswith('ratio_') and (folder/'status.json').exists() and read(folder/'status.json')['completed']:
                candidates.append((folder.name,read(folder/'trained_camera_model.json')))
        for label,m in candidates:
            K=np.array(m['cameraMatrix']);d=np.array(m['distCoeffs']);xy,v,ok=rays(points,K,d);valid=ok&ok0
            angle=np.degrees(np.arccos(np.clip(np.sum(v[valid]*v0[valid],axis=1),-1,1)))
            pix=np.linalg.norm((xy[valid]-xy0[valid])*[K0[0,0],K0[1,1]],axis=1)
            mapping.append(dict(pose=pose,model=label,accepted=m.get('accepted'),observed_points=len(points),valid_inverse_points=int(valid.sum()),ray_angle_degrees=stats(angle.tolist()),common_reference_pixels=stats(pix.tolist()),scope='same observed pixels; no pose refit; reference is same-diagnostic-five model, not ground truth; pixel distance uses fixed reference K'))
        print(pose,'done',flush=True)
    save(DEST/'results.json',dict(paired_bootstrap=paired,face_strata=strata,ray_mapping=mapping,worst_cases=audits,extraction_failures=extraction))
    shutil.copy2(__file__,DEST/Path(__file__).name)
if __name__=='__main__':run()
