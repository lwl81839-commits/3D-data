"""Matched five-image experiment: retain observed sparse planar lattices."""
from pathlib import Path
import os,sys,shutil,hashlib
ROOT=Path(__file__).resolve().parent
ORIGINAL=ROOT/'output/experiment_0820_stability_curve'
os.environ['STABILITY_CURVE_OUTPUT']=str(ROOT/'output/experiment_0820_sparse_observation_test')
import run_0820_stability_curve as r
def prepare():
    r.OUT.mkdir(exist_ok=True);shutil.copytree(ORIGINAL/'code',r.OUT/'code',dirs_exist_ok=True)
    target=r.OUT/'code/trained_camera_model.py';s=target.read_text(encoding='utf-8')
    start=s.index('            if len(points) != cols * rows:\n',s.index('def _local_face_observations'))
    end=s.index('            H, mask = cv2.findHomography',start)
    s=s[:start]+'''            sparse = len(points) != cols * rows
            if sparse:
                # Use only already observed, indexed checker points; never fill holes.
                obj = np.asarray(sample.object_points[boundaries[face_index]:boundaries[face_index + 1]], dtype=np.float64)
                if len(obj) != len(points) or len(obj) < 12 or not np.all(np.isfinite(obj)):
                    continue
                spans = np.ptp(obj, axis=0)
                axes = np.where(spans > 1e-5)[0]
                if len(axes) != 2:
                    continue
                local = obj[:, axes] - np.min(obj[:, axes], axis=0)
                grid = local / square_size_mm
                if np.max(np.abs(grid - np.rint(grid))) > 1e-4:
                    continue
                cells = np.rint(grid).astype(int)
                if len(np.unique(cells, axis=0)) != len(cells):
                    continue
                if any(len(np.unique(cells[:, a])) < 4 for a in [0, 1]):
                    continue
            else:
                local = np.asarray([[c * square_size_mm, r * square_size_mm] for r in range(rows) for c in range(cols)], dtype=np.float64)
'''+s[end:]
    needle='                "pattern": (cols, rows),'
    assert s.count(needle)==1
    s=s.replace(needle,needle+'\n                "local_object_points": np.column_stack([local, np.zeros(len(local))]),\n                "observed_sparse_lattice": sparse,')
    start=s.index('        cols, rows = observation["pattern"]',s.index('def _fit_partial_planar_model'))
    end=s.index('        object_groups.append(object_points)',start)
    s=s[:start]+'''        object_points = np.asarray(observation["local_object_points"], dtype=np.float32)
'''+s[end:]
    target.write_text(s,encoding='utf-8')
    old=r.read(ORIGINAL/'protocol.json');jobs=[];splits=[]
    for split in old['splits']:
        pose=split['pose']
        if pose=='15_0.528':continue
        splits.append({**split,'sizes':[5]});shutil.copytree(ORIGINAL/'validation'/pose,r.OUT/'validation'/pose,dirs_exist_ok=True)
        for j in old['jobs']:
            if j['pose']!=pose or j['n']!=5:continue
            cache=r.OUT/'models'/pose/j['name']/'.trihedral_correspondence_cache';cache.mkdir(parents=True,exist_ok=True)
            for x in j['selected']:shutil.copy2(x['cache'],cache/Path(x['cache']).name)
            r.save(cache.parent/'selection.json',j);jobs.append(j)
    r.save(r.OUT/'protocol.json',{**old,'splits':splits,'jobs':jobs,'selection_policy':'IDENTICAL five-image subsets and validation to unfiltered A; change only sparse local planar observation support','sparse_change':'For incomplete grids use existing corresponding 3D plane coordinates projected to two varying axes, translated to local origin; check lattice, duplicate points, >=12 points and >=4 unique rows/columns; original homography RMSE/inlier gates retained. No synthesized corners.','experimental_source_sha256':hashlib.sha256(s.encode()).hexdigest()})
    return jobs
if __name__=='__main__':
    if len(sys.argv)>1:r.train(sys.argv[2],sys.argv[3])
    else:r.prepare=prepare;r.main()
