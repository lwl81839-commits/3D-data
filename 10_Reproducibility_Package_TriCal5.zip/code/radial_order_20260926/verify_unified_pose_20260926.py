import hashlib,shutil
from rerun_unified_pose_20260926 import OUT,POSES,ROOT,read,save
checks=[]
for pose in POSES:
    d=read(OUT/pose/'results.json');names={m['name'] for m in d['models']}
    assert names==({'ratio_base','production_ratio','no_ratio_base','zhang_reference'}|({'t_4_10.jpg','t_4_17.jpg'} if pose=='45_1.155' else set()))
    assert d['legacy_regression_max_abs']<.01,(pose,d['legacy_regression_max_abs'])
    for m in d['models']:assert hashlib.sha256(__import__('pathlib').Path(m['source']).read_bytes()).hexdigest()==m['sha256']
    keys={n:{(r['kind'],r['image']) for r in d['rows'] if r['model']==n} for n in names}
    assert all(v==keys['ratio_base'] for v in keys.values())
    assert all(abs(r['rmse']-r['old_rmse'])<1e-10 for r in d['rows'] if r['rmse'] is not None and (r['kind']=='2D' or r['faces']>=2))
    checks.append(dict(pose=pose,models=len(names),rows=len(d['rows']),trials=sum(r['total_trials'] for r in d['rows']),success=sum(r['successful_trials'] for r in d['rows']),legacy_maxdiff=d['legacy_regression_max_abs'],extraction_failures=d['failures']))
for name in ['rerun_unified_pose_20260926.py','summarize_unified_pose_20260926.py','verify_unified_pose_20260926.py']:
    shutil.copy2(ROOT/name,OUT/name)
save(OUT/'verification.json',dict(checks=checks,unchanged_model_hashes=True,identical_image_membership=True,unchanged_two_dimensional_and_multiface_scores=True,legacy_tolerance_px=.01,legacy_note='Small numerical rerun differences recorded; no bitwise reproducibility claim. Old and new within this run share the exact same camera and observations.'))
print(checks)
