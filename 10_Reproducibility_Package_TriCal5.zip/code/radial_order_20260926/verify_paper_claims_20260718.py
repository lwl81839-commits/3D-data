from __future__ import annotations

import csv
import math
import statistics
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CSV_PATH = ROOT / "batch_results" / "full136_round5_fusion_20260718_v1" / "current_batch_results.csv"
CONTROLLED_BASELINE_CSV = (
    ROOT
    / "batch_results"
    / "ablation_controlled_20260718"
    / "baseline"
    / "current_batch_results.csv"
)
SELECTED_GATE_ROOT = ROOT / "batch_results" / "ablation_suite_20260718"
FULL_DEGRADATION_SUMMARY = ROOT / "paper_drafts" / "full_image_degradation_summary_20260719.csv"
NEW_IMAGE_CENSUS_CSV = ROOT / "paper_drafts" / "new_image_census_20260719.csv"
NEW_IMAGE_RERUN_CSV = ROOT / "batch_results" / "new_image_rerun_20260719" / "current_batch_results.csv"
FUNCTION_PROFILER_SUMMARY = ROOT / "paper_drafts" / "function_profiler_summary_20260719.csv"
FUNCTION_PROFILER_TOP = ROOT / "paper_drafts" / "function_profiler_top_functions_20260719.csv"
TRAIN_TEST_SPLIT_CSV = ROOT / "paper_drafts" / "train_test_split_70_30_20260719.csv"
TEST_CURRENT_CSV = (
    ROOT
    / "batch_results"
    / "train_test_split_70_30_20260719"
    / "test_current"
    / "current_batch_results.csv"
)
TEST_NO_STABILITY_CSV = (
    ROOT
    / "batch_results"
    / "train_test_split_70_30_20260719"
    / "test_no_stability"
    / "current_batch_results.csv"
)
TEST_FAST_CSV = (
    ROOT
    / "batch_results"
    / "compute_optimized_20260719"
    / "test_fast_900"
    / "current_batch_results.csv"
)
TEST_FAST_NO_STABILITY_CSV = (
    ROOT
    / "batch_results"
    / "compute_optimized_20260719"
    / "test_fast_no_stability_900"
    / "current_batch_results.csv"
)
CONTROLLED_FAST_CSV = (
    ROOT
    / "batch_results"
    / "compute_optimized_20260719"
    / "controlled16_fast"
    / "current_batch_results.csv"
)
OUT_PATH = ROOT / "paper_drafts" / "claim_verification_20260718.txt"


def fnum(value: str):
    if value is None or value == "":
        return None
    try:
        return float(value)
    except ValueError:
        return None


def pearson(xs, ys):
    pairs = [(x, y) for x, y in zip(xs, ys) if x is not None and y is not None]
    mx = sum(x for x, _ in pairs) / len(pairs)
    my = sum(y for _, y in pairs) / len(pairs)
    num = sum((x - mx) * (y - my) for x, y in pairs)
    denx = math.sqrt(sum((x - mx) ** 2 for x, _ in pairs))
    deny = math.sqrt(sum((y - my) ** 2 for _, y in pairs))
    return num / (denx * deny)


def percentile(values, p):
    vals = sorted(values)
    if not vals:
        return None
    idx = max(0, min(len(vals) - 1, math.floor(p * len(vals)) - 1))
    return vals[idx]


def area_bin(area):
    if area is None:
        return "unknown"
    if area < 2:
        return "<2%"
    if area < 3:
        return "2-3%"
    if area < 6:
        return "3-6%"
    if area < 10:
        return "6-10%"
    return ">=10%"


def controlled_summary(path: Path, unusable_keys: set[tuple[str, str]]) -> dict[str, int]:
    if not path.exists():
        return {
            "total": 0,
            "completed": 0,
            "real": 0,
            "real_ok": 0,
            "real_ge2": 0,
            "real_ge2_ok": 0,
            "negative": 0,
            "negative_ok": 0,
            "gate_reject": 0,
            "isolation_reject": 0,
            "timeout": 0,
        }
    rows = list(csv.DictReader(path.open("r", encoding="utf-8-sig", newline="")))
    real = [
        r for r in rows
        if r["group"] != "zhang" and (r["group"], r["image"]) not in unusable_keys
    ]
    negative = [
        r for r in rows
        if r["group"] == "zhang" or (r["group"], r["image"]) in unusable_keys
    ]
    real_ge2 = [
        r for r in real
        if fnum(r.get("cube_area_pct")) is None or (fnum(r.get("cube_area_pct")) or 0.0) >= 2.0
    ]
    return {
        "total": len(rows),
        "completed": int(len(rows) == 16),
        "real": len(real),
        "real_ok": sum(1 for r in real if r["status"] == "ok"),
        "real_ge2": len(real_ge2),
        "real_ge2_ok": sum(1 for r in real_ge2 if r["status"] == "ok"),
        "negative": len(negative),
        "negative_ok": sum(1 for r in negative if r["status"] == "ok"),
        "gate_reject": sum(
            1
            for r in rows
            if "Candidate-family ablation gate rejected" in (r.get("error") or "")
        ),
        "isolation_reject": sum(
            1
            for r in rows
            if (
                "Candidate-family isolation gate rejected" in (r.get("error") or "")
                or "Model-grade isolation skipped" in (r.get("warnings") or "")
            )
        ),
        "timeout": sum(1 for r in rows if r["status"] == "timeout"),
    }


def read_csv_rows(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    return list(csv.DictReader(path.open("r", encoding="utf-8-sig", newline="")))


def as_int(row: dict[str, str], field: str) -> int:
    value = row.get(field)
    if value in (None, ""):
        return -1
    try:
        return int(value)
    except ValueError:
        try:
            return int(float(value))
        except ValueError:
            return -1


def as_bool_int(row: dict[str, str], field: str) -> int:
    value = (row.get(field) or "").strip().lower()
    return 1 if value == "true" else 0


def bool_field(row: dict[str, str], field: str) -> bool:
    return (row.get(field) or "").strip().lower() == "true"


def top_function_present(rows: list[dict[str, str]], case: str, function: str) -> int:
    return int(any(row.get("case") == case and row.get("function") == function for row in rows))


def norm_rel(value: str) -> str:
    return (value or "").replace("\\", "/")


def batch_summary(
    path: Path,
    kind_by_rel: dict[str, str],
    unusable_keys: set[tuple[str, str]],
) -> dict[str, object]:
    rows = read_csv_rows(path)
    real = []
    negative = []
    for row in rows:
        rel = norm_rel(row.get("rel_path") or row.get("relative_path") or row.get("image") or "")
        kind = kind_by_rel.get(rel)
        is_real = (
            kind == "real_target"
            if kind is not None
            else row.get("group") != "zhang" and (row.get("group"), row.get("image")) not in unusable_keys
        )
        if is_real:
            real.append(row)
        else:
            negative.append(row)
    real_ok = [r for r in real if r.get("status") == "ok"]
    walls = [fnum(r.get("wall_elapsed_sec")) for r in rows]
    walls = [v for v in walls if v is not None]
    real_ok_walls = [fnum(r.get("wall_elapsed_sec")) for r in real_ok]
    real_ok_walls = [v for v in real_ok_walls if v is not None]
    real_ok_rmses = [fnum(r.get("rmse_px")) for r in real_ok]
    real_ok_rmses = [v for v in real_ok_rmses if v is not None]
    return {
        "rows": rows,
        "n": len(rows),
        "real": len(real),
        "real_ok": len(real_ok),
        "negative": len(negative),
        "negative_ok": sum(1 for r in negative if r.get("status") == "ok"),
        "timeouts": sum(1 for r in rows if r.get("status") == "timeout"),
        "total_wall": sum(walls),
        "median_real_ok_wall": statistics.median(real_ok_walls) if real_ok_walls else None,
        "mean_rmse": sum(real_ok_rmses) / len(real_ok_rmses) if real_ok_rmses else None,
        "median_rmse": statistics.median(real_ok_rmses) if real_ok_rmses else None,
    }


def shared_ok_speedup(
    before: dict[str, object],
    after: dict[str, object],
    kind_by_rel: dict[str, str],
) -> dict[str, float]:
    before_rows = {norm_rel(r.get("rel_path") or r.get("image") or ""): r for r in before["rows"]}
    after_rows = {norm_rel(r.get("rel_path") or r.get("image") or ""): r for r in after["rows"]}
    shared = [
        rel
        for rel, row in before_rows.items()
        if rel in after_rows
        and kind_by_rel.get(rel) == "real_target"
        and row.get("status") == "ok"
        and after_rows[rel].get("status") == "ok"
    ]
    before_walls = [fnum(before_rows[rel].get("wall_elapsed_sec")) or 0.0 for rel in shared]
    after_walls = [fnum(after_rows[rel].get("wall_elapsed_sec")) or 0.0 for rel in shared]
    deltas = [
        abs((fnum(after_rows[rel].get("rmse_px")) or 0.0) - (fnum(before_rows[rel].get("rmse_px")) or 0.0))
        for rel in shared
    ]
    return {
        "shared": len(shared),
        "speedup": sum(before_walls) / sum(after_walls),
        "before_median": statistics.median(before_walls),
        "after_median": statistics.median(after_walls),
        "max_rmse_delta": max(deltas) if deltas else 0.0,
    }


def main():
    rows = list(csv.DictReader(CSV_PATH.open("r", encoding="utf-8-sig", newline="")))
    zhang = [r for r in rows if r["group"] == "zhang"]
    non_zhang = [r for r in rows if r["group"] != "zhang"]
    unusable_keys = {("15.2_0.986", "t_5_14.jpg"), ("20_0.840", "t_3_00.jpg")}
    split_rows = read_csv_rows(TRAIN_TEST_SPLIT_CSV)
    kind_by_rel = {norm_rel(r.get("rel_path", "")): r.get("kind", "") for r in split_rows}
    unusable = [r for r in non_zhang if (r["group"], r["image"]) in unusable_keys]
    real_targets = [r for r in non_zhang if (r["group"], r["image"]) not in unusable_keys]
    real_ok = [r for r in real_targets if r["status"] == "ok"]
    negative = zhang + unusable

    status_counts = Counter(r["status"] for r in rows)
    group_counts = Counter(r["group"] for r in rows)
    gate_counts = Counter(r["calibration_status"] for r in real_ok)
    model_grade_counts = Counter(r["model_grade"] for r in real_ok)
    stability_counts = Counter(r["stability_final_decision"] for r in real_ok if r["stability_final_decision"])

    areas = [fnum(r["cube_area_pct"]) for r in real_ok]
    rmses = [fnum(r["rmse_px"]) for r in real_ok]
    walls = [fnum(r["wall_elapsed_sec"]) for r in real_ok]
    rmse_vals = [v for v in rmses if v is not None]
    wall_vals = [v for v in walls if v is not None]

    area_bins = Counter(area_bin(a) for a in areas)
    area_grade_counts = Counter((area_bin(fnum(r["cube_area_pct"])), r["model_grade"]) for r in real_ok)
    area_bin_rmse = {}
    area_bin_wall = {}
    for name in ["<2%", "2-3%", "3-6%", "6-10%", ">=10%"]:
        subset = [r for r, a in zip(real_ok, areas) if area_bin(a) == name]
        bin_rmses = [fnum(r["rmse_px"]) for r in subset if fnum(r["rmse_px"]) is not None]
        bin_walls = [fnum(r["wall_elapsed_sec"]) for r in subset if fnum(r["wall_elapsed_sec"]) is not None]
        if bin_rmses:
            area_bin_rmse[name] = (sum(bin_rmses) / len(bin_rmses), max(bin_rmses))
        if bin_walls:
            area_bin_wall[name] = (statistics.median(bin_walls), sum(bin_walls) / len(bin_walls), max(bin_walls))

    checks = [
        ("total_images", len(rows), 136),
        ("real_targets", len(real_targets), 98),
        ("real_targets_ok", len(real_ok), 98),
        ("negative_images", len(negative), 38),
        ("negative_accepted", sum(1 for r in negative if r["status"] == "ok"), 0),
        ("zhang_images", len(zhang), 36),
        ("zhang_accepted", sum(1 for r in zhang if r["status"] == "ok"), 0),
        ("unusable_images", len(unusable), 2),
        ("unusable_accepted", sum(1 for r in unusable if r["status"] == "ok"), 0),
        ("full_single_cube_zhang_ok", model_grade_counts["full_single_cube_zhang"], 44),
        ("bounded_focal_pose_ok", model_grade_counts["bounded_focal_pose"], 27),
        ("bounded_focal_scan_ok", model_grade_counts["bounded_focal_scan"], 24),
        ("bounded_single_view_ok", model_grade_counts["bounded_single_view"], 3),
        (
            "bounded_candidate_family_ok",
            model_grade_counts["bounded_focal_pose"]
            + model_grade_counts["bounded_focal_scan"]
            + model_grade_counts["bounded_single_view"],
            54,
        ),
        ("area_2_3_bounded_focal_pose_ok", area_grade_counts[("2-3%", "bounded_focal_pose")], 5),
    ]

    selected_gate_specs = [
        ("controlled_baseline", CONTROLLED_BASELINE_CSV, 13, 12, 0, 0, 0),
        (
            "selected_full_zhang_only",
            SELECTED_GATE_ROOT / "selected_full_zhang_only" / "current_batch_results.csv",
            3,
            3,
            0,
            3,
            9,
        ),
        (
            "selected_bounded_only",
            SELECTED_GATE_ROOT / "selected_bounded_only" / "current_batch_results.csv",
            8,
            7,
            0,
            3,
            4,
        ),
        (
            "selected_bounded_focal_pose_only",
            SELECTED_GATE_ROOT / "selected_bounded_focal_pose_only" / "current_batch_results.csv",
            5,
            4,
            0,
            6,
            4,
        ),
        (
            "selected_bounded_focal_scan_only",
            SELECTED_GATE_ROOT / "selected_bounded_focal_scan_only" / "current_batch_results.csv",
            2,
            2,
            0,
            4,
            9,
        ),
    ]
    selected_gate_summaries = {}
    for name, path, real_ok_exp, real_ge2_ok_exp, neg_ok_exp, gate_exp, timeout_exp in selected_gate_specs:
        summary = controlled_summary(path, unusable_keys)
        selected_gate_summaries[name] = summary
        checks.extend([
            (f"{name}_real_images", summary["real"], 13),
            (f"{name}_real_ok", summary["real_ok"], real_ok_exp),
            (f"{name}_real_ge2_images", summary["real_ge2"], 12),
            (f"{name}_real_ge2_ok", summary["real_ge2_ok"], real_ge2_ok_exp),
            (f"{name}_negative_images", summary["negative"], 3),
            (f"{name}_negative_accepted", summary["negative_ok"], neg_ok_exp),
            (f"{name}_gate_rejects", summary["gate_reject"], gate_exp),
            (f"{name}_timeouts", summary["timeout"], timeout_exp),
        ])

    isolated_specs = [
        (
            "isolated_full_zhang_only",
            SELECTED_GATE_ROOT / "isolated_full_zhang_only" / "current_batch_results.csv",
            1,
            1,
            0,
            1,
            11,
            1,
        ),
        (
            "isolated_bounded_only",
            SELECTED_GATE_ROOT / "isolated_bounded_only" / "current_batch_results.csv",
            10,
            9,
            0,
            10,
            5,
            1,
        ),
        (
            "isolated_bounded_focal_pose_only",
            SELECTED_GATE_ROOT / "isolated_bounded_focal_pose_only" / "current_batch_results.csv",
            8,
            7,
            0,
            8,
            4,
            1,
        ),
        (
            "isolated_bounded_focal_scan_only",
            SELECTED_GATE_ROOT / "isolated_bounded_focal_scan_only" / "current_batch_results.csv",
            6,
            5,
            0,
            6,
            9,
            1,
        ),
    ]
    isolated_summaries = {}
    for name, path, real_ok_exp, real_ge2_ok_exp, neg_ok_exp, reject_exp, timeout_exp, completed_exp in isolated_specs:
        summary = controlled_summary(path, unusable_keys)
        isolated_summaries[name] = summary
        if completed_exp:
            checks.extend([
                (f"{name}_completed", summary["completed"], completed_exp),
                (f"{name}_real_images", summary["real"], 13),
                (f"{name}_real_ok", summary["real_ok"], real_ok_exp),
                (f"{name}_real_ge2_images", summary["real_ge2"], 12),
                (f"{name}_real_ge2_ok", summary["real_ge2_ok"], real_ge2_ok_exp),
                (f"{name}_negative_images", summary["negative"], 3),
                (f"{name}_negative_accepted", summary["negative_ok"], neg_ok_exp),
                (f"{name}_isolation_rejects", summary["isolation_reject"], reject_exp),
                (f"{name}_timeouts", summary["timeout"], timeout_exp),
            ])
        else:
            checks.append((f"{name}_completed", summary["completed"], completed_exp))

    degradation_rows = {r.get("variant", ""): r for r in read_csv_rows(FULL_DEGRADATION_SUMMARY)}
    degradation_specs = [
        ("brightness_m20", 136, 1, 98, 14, 97, 14, 38, 0, 86),
        ("jpeg_q60", 136, 1, 98, 19, 97, 19, 38, 0, 85),
        ("blur_sigma1", 136, 1, 98, 19, 97, 19, 38, 0, 77),
    ]
    for variant, images_exp, completed_exp, real_exp, real_ok_exp, real_ge2_exp, real_ge2_ok_exp, negative_exp, negative_ok_exp, timeout_exp in degradation_specs:
        row = degradation_rows.get(variant, {})
        checks.extend([
            (f"degradation_{variant}_images", as_int(row, "images"), images_exp),
            (f"degradation_{variant}_completed", as_bool_int(row, "completed"), completed_exp),
            (f"degradation_{variant}_real", as_int(row, "real"), real_exp),
            (f"degradation_{variant}_real_ok", as_int(row, "real_ok"), real_ok_exp),
            (f"degradation_{variant}_real_ge2", as_int(row, "real_ge2"), real_ge2_exp),
            (f"degradation_{variant}_real_ge2_ok", as_int(row, "real_ge2_ok"), real_ge2_ok_exp),
            (f"degradation_{variant}_negative", as_int(row, "negative"), negative_exp),
            (f"degradation_{variant}_negative_ok", as_int(row, "negative_ok"), negative_ok_exp),
            (f"degradation_{variant}_timeouts", as_int(row, "timeouts"), timeout_exp),
        ])

    census_rows = read_csv_rows(NEW_IMAGE_CENSUS_CSV)
    census_materials = [r for r in census_rows if r.get("origin") == "materials_extracted"]
    census_top = [r for r in census_rows if r.get("origin") == "workspace_top_level"]
    census_material_nonduplicates = [
        r for r in census_materials
        if not bool_field(r, "is_baseline_duplicate")
    ]
    census_top_nonduplicates = [
        r for r in census_top
        if not bool_field(r, "is_baseline_duplicate")
    ]
    census_selected = [
        r for r in census_rows
        if bool_field(r, "selected_for_rerun")
    ]
    checks.extend([
        ("new_image_census_rows", len(census_rows), 140),
        ("new_image_census_materials_images", len(census_materials), 139),
        ("new_image_census_materials_nonduplicates", len(census_material_nonduplicates), 0),
        ("new_image_census_top_nonduplicates", len(census_top_nonduplicates), 1),
        ("new_image_census_selected", len(census_selected), 1),
        (
            "new_image_census_selected_negative_role",
            sum(1 for r in census_selected if r.get("role") == "external_nonchecker_cuboid_negative"),
            1,
        ),
    ])

    new_image_rows = read_csv_rows(NEW_IMAGE_RERUN_CSV)
    checks.extend([
        ("new_image_rerun_rows", len(new_image_rows), 1),
        ("new_image_rerun_accepted", sum(1 for r in new_image_rows if r.get("status") == "ok"), 0),
        ("new_image_rerun_timeouts", sum(1 for r in new_image_rows if r.get("status") == "timeout"), 1),
        ("new_image_rerun_nonempty_fx", sum(1 for r in new_image_rows if r.get("fx_px")), 0),
    ])

    profiler_rows = read_csv_rows(FUNCTION_PROFILER_SUMMARY)
    profiler_top_rows = read_csv_rows(FUNCTION_PROFILER_TOP)
    profiler_by_case = {r.get("case", ""): r for r in profiler_rows}
    profiler_specs = [
        ("direct_normal_fast", "ok", "normal_quality_gate"),
        ("manifest_replay_fast", "ok", "final_manifest_calibration"),
        ("grid_recovery_fast", "ok", "grid_recovered_calibration"),
        ("negative_reject_fast", "not_cube_target", "blocked_not_cube_target"),
    ]
    checks.append(("function_profiler_rows", len(profiler_rows), 4))
    for case, status_exp, gate_exp in profiler_specs:
        row = profiler_by_case.get(case, {})
        checks.extend([
            (f"function_profiler_{case}_present", 1 if row else 0, 1),
            (f"function_profiler_{case}_status", row.get("profile_status"), status_exp),
            (f"function_profiler_{case}_gate", row.get("profile_gate"), gate_exp),
        ])
    profiler_top_specs = [
        ("direct_normal_fast", "calibrate_single_cube_zhang"),
        ("direct_normal_fast", "approx_derivative"),
        ("manifest_replay_fast", "calibrate_single_cube_zhang"),
        ("manifest_replay_fast", "approx_derivative"),
        ("grid_recovery_fast", "_run_grid_recovery"),
        ("grid_recovery_fast", "region_seed_faces"),
        ("grid_recovery_fast", "robust_fit_line_ransac"),
        ("grid_recovery_fast", "<solvePnP>"),
        ("negative_reject_fast", "_run_grid_recovery"),
        ("negative_reject_fast", "<findChessboardCorners>"),
        ("negative_reject_fast", "strict_rectified_face_candidates"),
    ]
    checks.append(("function_profiler_top_rows_min", int(len(profiler_top_rows) >= 40), 1))
    for case, function in profiler_top_specs:
        checks.append((
            f"function_profiler_top_{case}_{function}",
            top_function_present(profiler_top_rows, case, function),
            1,
        ))

    compute_paths = {
        "test_current": TEST_CURRENT_CSV,
        "test_fast_900": TEST_FAST_CSV,
        "test_no_stability": TEST_NO_STABILITY_CSV,
        "test_fast_no_stability_900": TEST_FAST_NO_STABILITY_CSV,
        "controlled_baseline": CONTROLLED_BASELINE_CSV,
        "controlled_fast": CONTROLLED_FAST_CSV,
    }
    compute_summaries = {
        name: batch_summary(path, kind_by_rel, unusable_keys)
        for name, path in compute_paths.items()
    }
    compute_expected = [
        ("test_current", 41, 29, 28, 12, 0, 1),
        ("test_fast_900", 41, 29, 29, 12, 0, 0),
        ("test_no_stability", 41, 29, 26, 12, 0, 3),
        ("test_fast_no_stability_900", 41, 29, 29, 12, 0, 0),
        ("controlled_baseline", 16, 13, 13, 3, 0, 0),
        ("controlled_fast", 16, 13, 13, 3, 0, 0),
    ]
    for name, n_exp, real_exp, real_ok_exp, neg_exp, neg_ok_exp, timeout_exp in compute_expected:
        summary = compute_summaries[name]
        checks.extend([
            (f"compute_{name}_rows", summary["n"], n_exp),
            (f"compute_{name}_real", summary["real"], real_exp),
            (f"compute_{name}_real_ok", summary["real_ok"], real_ok_exp),
            (f"compute_{name}_negative", summary["negative"], neg_exp),
            (f"compute_{name}_negative_accepted", summary["negative_ok"], neg_ok_exp),
            (f"compute_{name}_timeouts", summary["timeouts"], timeout_exp),
        ])
    compute_speedups = {
        "test_current_to_fast": shared_ok_speedup(
            compute_summaries["test_current"],
            compute_summaries["test_fast_900"],
            kind_by_rel,
        ),
        "test_no_stability_to_fast": shared_ok_speedup(
            compute_summaries["test_no_stability"],
            compute_summaries["test_fast_no_stability_900"],
            kind_by_rel,
        ),
        "controlled_to_fast": shared_ok_speedup(
            compute_summaries["controlled_baseline"],
            compute_summaries["controlled_fast"],
            kind_by_rel,
        ),
    }
    checks.extend([
        (
            "compute_test_current_to_fast_speedup_milli",
            int(round(compute_speedups["test_current_to_fast"]["speedup"] * 1000)),
            2234,
        ),
        (
            "compute_test_no_stability_to_fast_speedup_milli",
            int(round(compute_speedups["test_no_stability_to_fast"]["speedup"] * 1000)),
            2395,
        ),
        (
            "compute_controlled_to_fast_speedup_milli",
            int(round(compute_speedups["controlled_to_fast"]["speedup"] * 1000)),
            1772,
        ),
    ])

    lines = []
    lines.append("Claim verification for V11 manuscript")
    lines.append(f"Source CSV: {CSV_PATH.relative_to(ROOT)}")
    lines.append("")
    lines.append("Core pass/fail checks")
    for name, observed, expected in checks:
        ok = "PASS" if observed == expected else "FAIL"
        lines.append(f"- {name}: observed={observed}, expected={expected}, {ok}")
    lines.append("")
    lines.append(f"Status counts: {dict(status_counts)}")
    lines.append(f"Group counts: {dict(group_counts)}")
    lines.append(f"Calibration gate counts for real ok targets: {dict(gate_counts)}")
    lines.append(f"Model-grade counts for real ok targets: {dict(model_grade_counts)}")
    lines.append(f"Stable replay subcounts: {dict(stability_counts)}")
    lines.append("")
    lines.append("Candidate-family selected-gate ablation checks")
    for name, summary in selected_gate_summaries.items():
        lines.append(
            f"- {name}: real_ok={summary['real_ok']}/{summary['real']}, "
            f"real_ge2_ok={summary['real_ge2_ok']}/{summary['real_ge2']}, "
            f"negative_ok={summary['negative_ok']}/{summary['negative']}, "
            f"gate_rejects={summary['gate_reject']}, timeouts={summary['timeout']}"
        )
    lines.append("")
    lines.append("Candidate-family adoption-isolation ablation checks")
    for name, summary in isolated_summaries.items():
        lines.append(
            f"- {name}: completed={summary['completed']}, "
            f"real_ok={summary['real_ok']}/{summary['real']}, "
            f"real_ge2_ok={summary['real_ge2_ok']}/{summary['real_ge2']}, "
            f"negative_ok={summary['negative_ok']}/{summary['negative']}, "
            f"isolation_rejects={summary['isolation_reject']}, "
            f"timeouts={summary['timeout']}"
        )
    lines.append("")
    lines.append("No-leakage full image degradation checks")
    for variant, *_ in degradation_specs:
        row = degradation_rows.get(variant, {})
        lines.append(
            f"- {variant}: images={row.get('images')}, completed={row.get('completed')}, "
            f"real_ok={row.get('real_ok')}/{row.get('real')}, "
            f"real_ge2_ok={row.get('real_ge2_ok')}/{row.get('real_ge2')}, "
            f"negative_ok={row.get('negative_ok')}/{row.get('negative')}, "
            f"timeouts={row.get('timeouts')}"
        )
    lines.append("")
    lines.append("New-image rerun audit checks")
    lines.append(
        f"- census rows={len(census_rows)}, materials_images={len(census_materials)}, "
        f"materials_nonduplicates={len(census_material_nonduplicates)}, "
        f"top_nonduplicates={len(census_top_nonduplicates)}, selected={len(census_selected)}"
    )
    lines.append(
        f"- rows={len(new_image_rows)}, accepted={sum(1 for r in new_image_rows if r.get('status') == 'ok')}, "
        f"timeouts={sum(1 for r in new_image_rows if r.get('status') == 'timeout')}"
    )
    for r in new_image_rows:
        lines.append(f"- {r.get('rel_path')}: status={r.get('status')}, decision={r.get('decision')}, gate={r.get('calibration_status')}")
    lines.append("")
    lines.append("Function profiler checks")
    for case, *_ in profiler_specs:
        row = profiler_by_case.get(case, {})
        lines.append(
            f"- {case}: status={row.get('profile_status')}, gate={row.get('profile_gate')}, "
            f"profile_wall_sec={row.get('profile_wall_sec')}"
        )
    lines.append("- top-function expectations:")
    for case, function in profiler_top_specs:
        lines.append(
            f"  - {case}: `{function}` present="
            f"{top_function_present(profiler_top_rows, case, function)}"
        )
    lines.append("")
    lines.append("Compute-side optimization checks")
    for name in [
        "test_current",
        "test_fast_900",
        "test_no_stability",
        "test_fast_no_stability_900",
        "controlled_baseline",
        "controlled_fast",
    ]:
        summary = compute_summaries[name]
        lines.append(
            f"- {name}: real_ok={summary['real_ok']}/{summary['real']}, "
            f"negative_ok={summary['negative_ok']}/{summary['negative']}, "
            f"timeouts={summary['timeouts']}, total_wall={summary['total_wall']:.3f}s, "
            f"median_real_ok_wall={summary['median_real_ok_wall']:.3f}s, "
            f"mean_rmse={summary['mean_rmse']:.3f}px, median_rmse={summary['median_rmse']:.3f}px"
        )
    for name, summary in compute_speedups.items():
        lines.append(
            f"- {name}: shared_ok={summary['shared']}, "
            f"speedup={summary['speedup']:.3f}x, "
            f"median_wall={summary['before_median']:.3f}s->{summary['after_median']:.3f}s, "
            f"max_rmse_delta={summary['max_rmse_delta']:.6f}px"
        )
    lines.append("")
    lines.append("RMSE statistics for 98 real ok targets")
    lines.append(f"- mean={sum(rmse_vals)/len(rmse_vals):.6f} px")
    lines.append(f"- median={statistics.median(rmse_vals):.6f} px")
    lines.append(f"- p90={percentile(rmse_vals, 0.90):.6f} px")
    lines.append(f"- max={max(rmse_vals):.6f} px")
    lines.append("")
    lines.append("Runtime statistics for 98 real ok targets")
    lines.append(f"- mean={sum(wall_vals)/len(wall_vals):.6f} s")
    lines.append(f"- median={statistics.median(wall_vals):.6f} s")
    lines.append(f"- p90={percentile(wall_vals, 0.90):.6f} s")
    lines.append(f"- max={max(wall_vals):.6f} s")
    lines.append("")
    lines.append("Area-bin counts")
    for name in ["<2%", "2-3%", "3-6%", "6-10%", ">=10%"]:
        rmse_pair = area_bin_rmse.get(name)
        wall_tuple = area_bin_wall.get(name)
        if rmse_pair and wall_tuple:
            lines.append(
                f"- {name}: n={area_bins[name]}, mean_rmse={rmse_pair[0]:.3f}, "
                f"max_rmse={rmse_pair[1]:.3f}, median_wall={wall_tuple[0]:.1f}, "
                f"mean_wall={wall_tuple[1]:.1f}, max_wall={wall_tuple[2]:.1f}"
            )
    lines.append("")
    lines.append(f"Pearson area vs RMSE: {pearson(areas, rmses):.6f}")
    lines.append(f"Pearson area vs runtime: {pearson(areas, walls):.6f}")
    lines.append("")
    lines.append("Unusable/non-target non-Zhang images")
    for r in unusable:
        lines.append(f"- {r['group']}/{r['image']}: status={r['status']}, decision={r['decision']}")

    OUT_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(OUT_PATH)


if __name__ == "__main__":
    main()
