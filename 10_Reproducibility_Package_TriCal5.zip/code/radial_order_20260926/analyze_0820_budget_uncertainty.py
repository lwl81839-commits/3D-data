"""Image-level paired bootstrap and accepted-face stratification."""
from experiment_0820_planar_budget import OUT,POSES
from pathlib import Path
import json,numpy as np
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def bootstrap(a,b,seed):
    a=np.array(a,float);b=np.array(b,float); mask=np.isfinite(a)&np.isfinite(b);a=a[mask];b=b[mask]
    d=a-b;n=len(d)
    if not n:return dict(n=0)
    rng=np.random.default_rng(seed); samples=np.median(d[rng.integers(0,n,size=(2000,n))],axis=1)
    return dict(n=n,ours_median=float(np.median(a)),baseline_median=float(np.median(b)),paired_median_delta=float(np.median(d)),ci95_percentile=np.percentile(samples,[2.5,97.5]).tolist(),ours_wins=int(np.sum(d<0)),ties=int(np.sum(abs(d)<1e-10)),small_stratum=n<10)
result=[]
for pi,pose in enumerate(POSES):
    planar=read(OUT/'tests'/pose/'2D/evaluation.json')
    ours3=read(OUT.parent/'ablation_0820_no_ratio_constraint/final_test_evaluation'/pose/'with_ratio_prior/evaluation.json')
    orig={Path(x['image']).name:x for x in ours3['images']}
    for n in [5,10,20]:
        names=[f'planar_{n:02d}_r{r+1:02d}' for r in range(5 if n<20 else 1)]
        a=[];b=[]
        for row in planar['images']:
            av=row.get('ours_3d_5_images',{}).get('holdout_rmse_px')
            bv=[row.get(name,{}).get('holdout_rmse_px') for name in names]
            if av is not None and all(v is not None for v in bv):a.append(av);b.append(float(np.mean(bv)))
        result.append(dict(pose=pose,budget=n,kind='2D',faces='all',**bootstrap(a,b,20260911+pi*100+n)))
        models=[{Path(x['image']).name:x for x in read(OUT/'tests'/pose/'3D'/name/'evaluation.json')['images']} for name in names]
        for group in ['all',1,2,3]:
            a=[];b=[]
            for key,x in orig.items():
                if group!='all' and x['faces_used']!=group:continue
                if not all(key in m for m in models):continue
                assert all(m[key]['faces_used']==x['faces_used'] for m in models)
                av=x['holdout_error_px']['rmse'];bv=[m[key]['holdout_error_px']['rmse'] for m in models]
                if av is not None and all(v is not None for v in bv):a.append(av);b.append(float(np.mean(bv)))
            result.append(dict(pose=pose,budget=n,kind='3D',faces=group,**bootstrap(a,b,20260911+pi*100+n)))
(OUT/'paired_image_bootstrap.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
lines=['# Image-level uncertainty and face-stratified analysis','',
'Difference is TriCal5 minus planar baseline; negative favors TriCal5. For budgets 5/10 the baseline is the arithmetic mean of each image metric across the five fitted subsets, NOT a camera-parameter ensemble. The bootstrap resamples paired test images 2,000 times and takes the median of paired differences. Intervals are exploratory percentile intervals, conditional on these selected training subsets, without multiplicity correction. They do not quantify population-wide training uncertainty.','',
'2D metric: per-image median trial RMSE. 3D metric: per-image pooled held-out point RMSE, different from the historical trial-median headline. Small strata (<10 images) must not support strong inference.','',
'|Config.|Budget|Test|Faces|n|Median paired delta (px)|95% interval|','|---|---|---|---|---|---|---|']
for r in result:
    if not r['n']:continue
    lo,hi=r['ci95_percentile']; interval='not reported: n<10' if r['small_stratum'] else f'[{lo:.4f}, {hi:.4f}]'
    lines.append(f"|{r['pose']}|{r['budget']}|{r['kind']}|{r['faces']}|{r['n']}|{r['paired_median_delta']:.4f}|{interval}|")
(OUT/'UNCERTAINTY_AND_FACES.md').write_text('\n'.join(lines),encoding='utf-8')
print('Saved',len(result),'comparisons')
