#!/usr/bin/env python3
"""Calibration routing: default first, optional heavy recovery second.

The production path stays lightweight by default.  Physical grid extrapolation
and SAM/component recovery run only when explicitly enabled by environment.
"""

from __future__ import annotations

import json
import itertools
import math
import os
from pathlib import Path
from typing import Any, List, Optional, Tuple

import cv2
import numpy as np

from best_calibration import DEFAULT_SQUARE_SIZE_MM, BestResult, calibrate_best
from calibration_manifest_gate import CANONICAL_FACE_PATTERNS
from calibration_policy import (
    SMALL_TARGET_ATTEMPT_MIN_AREA_PCT,
    extract_cube_area_pct,
)


_PREDICTOR_CACHE: dict[tuple[str, str], Any] = {}


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        value = float(raw)
    except ValueError:
        return default
    return value if math.isfinite(value) else default


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        value = int(float(raw))
    except ValueError:
        return default
    return value if value > 0 else default


def _split_route_names(raw: str) -> set[str]:
    return {
        item.strip()
        for item in raw.replace(";", ",").split(",")
        if item.strip()
    }


def _finite_row_value(
    row: dict[str, Any],
    key: str,
    default: float = float("inf"),
) -> float:
    try:
        value = float(row.get(key))
    except (TypeError, ValueError):
        return default
    return value if math.isfinite(value) else default


def _pattern_signature_from_text(raw: Any) -> Optional[list[tuple[int, int]]]:
    if raw is None:
        return None
    patterns: list[tuple[int, int]] = []
    for part in str(raw).replace(",", ";").split(";"):
        if ":" not in part or "x" not in part.lower():
            continue
        _label, dims = part.split(":", 1)
        dims = dims.strip().lower()
        try:
            cols_s, rows_s = dims.split("x", 1)
            cols, rows = int(cols_s), int(rows_s)
        except ValueError:
            continue
        patterns.append((max(cols, rows), min(cols, rows)))
    if not patterns:
        return None
    return sorted(patterns)


def _has_canonical_seeded_patterns(row: dict[str, Any]) -> bool:
    signature = _pattern_signature_from_text(row.get("seeded_patterns"))
    canonical = sorted(
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in CANONICAL_FACE_PATTERNS
    )
    return signature == canonical


def _deferred_small_target_needs_long_face_challenge(row: dict[str, Any]) -> bool:
    """Keep probing when a deferred small-target candidate lacks long-face evidence."""
    max_area = _env_float(
        "CALIB_GRID_RECOVERY_DEFERRED_REQUIRE_LONG_FACE_MAX_AREA_PCT", 0.0
    )
    if max_area <= 0:
        return False
    stage_name = str(row.get("grid_recovery_stage") or "")
    if "local_partial" in stage_name:
        return False
    area_pct = _finite_row_value(row, "cube_area_pct")
    if not math.isfinite(area_pct) or area_pct >= max_area:
        return False
    signature = _pattern_signature_from_text(row.get("extrapolated_patterns"))
    if not signature:
        return False
    required_long = _env_float(
        "CALIB_GRID_RECOVERY_DEFERRED_MIN_LONG_FACE_COLS", 9.0
    )
    return max(max(cols, rows) for cols, rows in signature) < required_long


def _small_target_adaptive_fallback_stages(
    local_row: dict[str, Any],
) -> list[tuple[str, set[str]]]:
    """Choose the second small-target stage from local physical consistency."""
    component_first_rmse = _env_float(
        "CALIB_GRID_RECOVERY_SMALL_TARGET_COMPONENT_FIRST_RMSE_PX",
        18.0,
    )
    local_geom = min(
        _finite_row_value(local_row, "joint_fixed_focal_rmse"),
        _finite_row_value(local_row, "seed_fixed_focal_rmse"),
        _finite_row_value(local_row, "extrapolated_centered_pnp"),
    )
    component_first = (
        not _has_canonical_seeded_patterns(local_row)
        or local_geom > component_first_rmse
    )
    if component_first:
        return [
            ("component_labelperm_seed_only", {"component_labelperm_seed_only"}),
            ("complete_geometry", {"complete_geometry"}),
        ]
    return [
        ("complete_geometry", {"complete_geometry"}),
        ("component_labelperm_seed_only", {"component_labelperm_seed_only"}),
    ]


def _grid_recovery_route_stages(
    area_pct: Optional[float] = None,
) -> Optional[list[tuple[str, set[str]]]]:
    """Optional staged route plan for fast-first, slow-on-failure recovery."""
    raw_stage_plan = os.environ.get("CALIB_GRID_RECOVERY_ROUTE_STAGES", "").strip()
    if raw_stage_plan:
        stages: list[tuple[str, set[str]]] = []
        for idx, raw_stage in enumerate(raw_stage_plan.split("|"), 1):
            names = _split_route_names(raw_stage)
            if names:
                stages.append((f"stage_{idx}", names))
        return stages or None

    if not _env_bool("CALIB_GRID_RECOVERY_STAGED_ROUTES", True):
        return None
    if os.environ.get("CALIB_GRID_RECOVERY_ROUTES", "").strip():
        return None
    if (
        area_pct is not None
        and math.isfinite(float(area_pct))
        and _env_bool("CALIB_GRID_RECOVERY_SMALL_TARGET_LONG_FACE_COMPLETION", True)
    ):
        small_min = _env_float(
            "CALIB_GRID_RECOVERY_SMALL_TARGET_LONG_FACE_MIN_AREA_PCT",
            4.0,
        )
        small_max = _env_float(
            "CALIB_GRID_RECOVERY_SMALL_TARGET_LONG_FACE_MAX_AREA_PCT",
            7.0,
        )
        if small_min <= float(area_pct) < small_max:
            return [
                ("complete_geometry", {"complete_geometry"}),
                ("local_partial", {"local_partial"}),
                (
                    "component_labelperm_seed_only",
                    {"component_labelperm_seed_only"},
                ),
                (
                    "small_target_long_face_completion",
                    {"small_target_long_face_completion"},
                ),
                ("trihedral_closure", {"trihedral_closure"}),
            ]
    local_first_max_area = _env_float(
        "CALIB_GRID_RECOVERY_LOCAL_FIRST_MAX_AREA_PCT", 3.0)
    small_target_direct_preserve = _env_bool(
        "CALIB_GRID_RECOVERY_SMALL_TARGET_DIRECT_PARTIAL_PRESERVE", False)
    preserve_stages = []
    if _env_bool("CALIB_GRID_RECOVERY_DIRECT_PARTIAL_PRESERVE", True):
        preserve_stages.append((
            "direct_partial_preserve",
            {"direct_partial_preserve"},
        ))
    if (
        area_pct is not None
        and math.isfinite(float(area_pct))
        and float(area_pct) < local_first_max_area
    ):
        small_preserve_stages = preserve_stages if small_target_direct_preserve else []
        return small_preserve_stages + [
            ("local_partial", {"local_partial"}),
            ("small_target_adaptive_fallback", set()),
            ("trihedral_closure", {"trihedral_closure"}),
        ]
    return preserve_stages + [
        ("component_labelperm_seed_only", {"component_labelperm_seed_only"}),
        ("complete_geometry", {"complete_geometry"}),
        ("local_partial", {"local_partial"}),
        ("trihedral_closure", {"trihedral_closure"}),
    ]


def _grid_stage_rank(row: dict[str, Any]) -> tuple[int, float, float]:
    def finite_value(name: str, default: float = float("inf")) -> float:
        try:
            value = float(row.get(name))
        except (TypeError, ValueError):
            return default
        return value if math.isfinite(value) else default

    if row.get("status") in {"calibrated", "not_cube_target"}:
        return (0, finite_value("rmse_px"), finite_value("joint_fixed_focal_rmse"))
    if row.get("corners_path"):
        return (
            1,
            min(
                finite_value("joint_fixed_focal_rmse"),
                finite_value("extrapolated_centered_pnp"),
                finite_value("seed_fixed_focal_rmse"),
            ),
            finite_value("joint_photometric"),
        )
    return (2, float("inf"), float("inf"))


def _grid_stage_should_stop(row: dict[str, Any]) -> bool:
    status = row.get("status")
    if status == "not_cube_target":
        return True
    if (
        status == "geometry_recovered"
        and row.get("corners_path")
        and _env_bool("CALIB_GRID_RECOVERY_DEFER_FINAL_CALIBRATION", False)
    ):
        proxy_limit = _env_float(
            "CALIB_GRID_RECOVERY_DEFERRED_STOP_PROXY_RMSE_PX", 15.0
        )
        proxies = []
        for key in (
            "joint_fixed_focal_rmse",
            "extrapolated_centered_pnp",
            "seed_fixed_focal_rmse",
        ):
            try:
                value = float(row.get(key))
            except (TypeError, ValueError):
                continue
            if math.isfinite(value):
                proxies.append(value)
        local_partial_proxy_raw = os.environ.get(
            "CALIB_GRID_RECOVERY_DEFERRED_LOCAL_PARTIAL_STOP_PROXY_RMSE_PX"
        )
        if row.get("grid_recovery_stage") == "local_partial" and local_partial_proxy_raw:
            proxy_limit = min(
                proxy_limit,
                _env_float(
                    "CALIB_GRID_RECOVERY_DEFERRED_LOCAL_PARTIAL_STOP_PROXY_RMSE_PX",
                    12.0,
                ),
            )
        if _deferred_small_target_needs_long_face_challenge(row):
            return False
        return bool(proxies and min(proxies) <= proxy_limit)
    if status != "calibrated":
        return False

    challenge_rmse = _env_float("CALIB_GRID_RECOVERY_STAGE_CHALLENGE_RMSE_PX", 12.0)
    if row.get("grid_recovery_stage") == "direct_partial_preserve":
        challenge_rmse = min(
            challenge_rmse,
            _env_float(
                "CALIB_GRID_RECOVERY_DIRECT_PRESERVE_STOP_RMSE_PX",
                8.0,
            ),
        )
    if challenge_rmse <= 0:
        return True
    try:
        rmse = float(row.get("rmse_px"))
    except (TypeError, ValueError):
        return False
    return math.isfinite(rmse) and rmse <= challenge_rmse


def _is_canonical(face_patterns: Optional[List[Tuple[int, int]]]) -> bool:
    if face_patterns is None:
        return True
    return [tuple(map(int, pat)) for pat in face_patterns] == CANONICAL_FACE_PATTERNS


def _read_gray(image_path: str) -> Optional[np.ndarray]:
    try:
        data = np.fromfile(image_path, dtype=np.uint8)
        gray = cv2.imdecode(data, cv2.IMREAD_GRAYSCALE)
    except Exception:
        return None
    return gray


def _estimate_cube_area_pct(image_path: str, fallback_message: str) -> Optional[float]:
    parsed = extract_cube_area_pct(fallback_message)
    if parsed is not None:
        return parsed
    gray = _read_gray(image_path)
    if gray is None:
        return None
    try:
        from face_detector import estimate_cube_area_pct

        return float(estimate_cube_area_pct(gray, n_faces=3))
    except Exception:
        return None


def _grid_recovery_effective_focal(
    image_path: str,
    focal_px: Optional[float],
) -> tuple[Optional[float], dict[str, Any]]:
    if focal_px is not None and math.isfinite(float(focal_px)) and float(focal_px) > 0:
        return float(focal_px), {"source": "external_argument"}
    env_focal = _env_float("CALIB_GRID_RECOVERY_FOCAL_PX", float("nan"))
    if math.isfinite(env_focal) and env_focal > 0:
        return float(env_focal), {"source": "env_fixed_focal"}
    anchor_path_raw = os.environ.get(
        "CALIB_GRID_RECOVERY_GROUP_ANCHOR_FILE",
        "batch_results/group_scale_anchors_20260716_v1/group_focal_anchors.json",
    ).strip()
    if (
        anchor_path_raw
        and _env_bool("CALIB_GRID_RECOVERY_USE_GROUP_ANCHOR", False)
    ):
        anchor_path = Path(anchor_path_raw).expanduser()
        if anchor_path.exists():
            try:
                from group_scale_anchor import resolve_group_anchor

                anchor = resolve_group_anchor(image_path, anchor_path)
            except Exception:
                anchor = None
            if anchor:
                focal = float(anchor["focal_px"])
                return focal, {
                    "source": "group_scale_anchor",
                    "group": anchor.get("group"),
                    "anchor_file": str(anchor_path),
                    "count": anchor.get("count"),
                    "confidence": anchor.get("confidence"),
                    "mad_px": anchor.get("mad_px"),
                    "diag_mult": anchor.get("diag_mult"),
                }
    if not _env_bool("CALIB_GRID_RECOVERY_USE_DIAG_FOCAL_ANCHOR", False):
        return None, {"source": "none"}
    gray = _read_gray(image_path)
    if gray is None:
        return None, {"source": "none", "reason": "image_read_failed"}
    h, w = gray.shape[:2]
    mult = _env_float("CALIB_GRID_RECOVERY_FOCAL_ANCHOR_DIAG_MULT", 0.55)
    focal = float(mult) * float(np.hypot(w, h))
    if math.isfinite(focal) and focal > 0:
        return focal, {"source": "image_diag_anchor", "diag_mult": float(mult)}
    return None, {"source": "none", "reason": "invalid_diag_anchor"}


def _checkpoint_from_env() -> Optional[Path]:
    raw = os.environ.get("CALIB_SAM_CHECKPOINT", "").strip()
    if raw:
        return Path(raw).expanduser()
    if not _env_bool("CALIB_ENABLE_SAM_RECOVERY", False):
        return None
    default = Path(__file__).resolve().parent / "checkpoints" / "sam_vit_b_01ec64.pth"
    return default if default.exists() else None


def _sam_recovery_enabled() -> bool:
    checkpoint = _checkpoint_from_env()
    return checkpoint is not None and checkpoint.exists()


def _grid_recovery_enabled() -> bool:
    return _env_bool("CALIB_ENABLE_GRID_RECOVERY", False)


def _precomputed_corners_scale_prior_candidate(corners_path: Optional[str]) -> bool:
    return bool(
        corners_path is not None
        and _env_bool("CALIB_PRECOMPUTED_CORNERS_SCALE_PRIOR_CANDIDATE", False)
    )


def _grid_recovery_first_area(image_path: str) -> Optional[float]:
    """Return the small-target area when grid recovery should run first."""
    if not (
        _grid_recovery_enabled()
        and _env_bool("CALIB_GRID_RECOVERY_FIRST_SMALL_TARGET", False)
    ):
        return None
    area = _estimate_cube_area_pct(image_path, "")
    if area is None or not math.isfinite(float(area)):
        return None
    min_area = _env_float(
        "CALIB_GRID_RECOVERY_MIN_AREA_PCT",
        SMALL_TARGET_ATTEMPT_MIN_AREA_PCT,
    )
    max_area = min(
        _env_float("CALIB_GRID_RECOVERY_MAX_AREA_PCT", 8.0),
        _env_float("CALIB_GRID_RECOVERY_FIRST_MAX_AREA_PCT", 4.0),
    )
    return float(area) if min_area <= float(area) < max_area else None


def _small_target_stop_after_grid_first_failure(
    area_pct: Optional[float],
    error: Exception,
) -> Optional[str]:
    if not _env_bool(
        "CALIB_GRID_RECOVERY_SMALL_TARGET_BOUNDARY_STOP_AFTER_GRID_FAIL",
        False,
    ):
        return None
    if area_pct is None or not math.isfinite(float(area_pct)):
        return None
    min_area = _env_float(
        "CALIB_GRID_RECOVERY_SMALL_TARGET_LONG_FACE_MIN_AREA_PCT",
        4.0,
    )
    max_area = _env_float(
        "CALIB_GRID_RECOVERY_SMALL_TARGET_LONG_FACE_MAX_AREA_PCT",
        7.0,
    )
    area = float(area_pct)
    if not (min_area <= area < max_area):
        return None
    message = str(error)
    boundary_needles = (
        "Grid/extrapolation recovery did not produce usable corners",
        "small_target_long_face_completion",
        "direct_partial_preserve",
        "joint_recovery_failed",
        "no_canonical_joint_combo",
        "strict small-target gate",
        "Range boundary:",
    )
    if not any(needle in message for needle in boundary_needles):
        return None
    return (
        "Range boundary: small-target physical recovery stopped before the "
        "default heavy route because cube image area is "
        f"{area:.2f}% and the bounded long-face completion route did not "
        "recover a canonical three-face checker layout. "
        "Keep this image as the current 4-7% small-target/candidate-budget "
        f"boundary. Grid-first failure: {message}"
    )


def _eligible_for_grid_recovery(
    image_path: str,
    default_error: Exception,
    *,
    n_faces: int,
    face_patterns: Optional[List[Tuple[int, int]]],
    corners_path: Optional[str],
    manual_face_rois: Optional[List[Tuple[int, int, int, int]]],
) -> tuple[bool, Optional[float], str]:
    if corners_path is not None:
        return False, None, "precomputed corners already supplied"
    if manual_face_rois is not None:
        return False, None, "manual ROIs already supplied"
    if int(n_faces) != 3:
        return False, None, "grid recovery is only defined for the trihedral target"
    if not _is_canonical(face_patterns):
        return False, None, "grid recovery is only validated for canonical cube-target faces"

    message = str(default_error)
    if "Not cube target:" in message:
        return False, None, "input is not the three-visible-face cube/cuboid target"

    recovery_needles = (
        "Range boundary:",
        "Partial-face geometry boundary",
        "partial-face geometry boundary",
        "strict small-target gate",
        "visible grid pattern",
        "only ",
        "cube-first found only",
        "Insufficient visible cube faces:",
        "No calibration target detected:",
        "Calibration target too small",
        "Low-confidence calibration",
        "low-confidence calibration",
        "Focal length is not identifiable",
        "focal length is not identifiable",
        "Invalid ",
        "checker topology",
        "duplicate or collapsed",
    )
    recoverable_failure = any(needle in message for needle in recovery_needles)

    area = _estimate_cube_area_pct(image_path, message)
    min_area = _env_float(
        "CALIB_GRID_RECOVERY_MIN_AREA_PCT",
        SMALL_TARGET_ATTEMPT_MIN_AREA_PCT,
    )
    max_area = _env_float("CALIB_GRID_RECOVERY_MAX_AREA_PCT", 8.0)
    failure_max_area = _env_float(
        "CALIB_GRID_RECOVERY_FAILURE_MAX_AREA_PCT",
        max_area,
    )
    if area is not None and not _env_bool("CALIB_DISABLE_AREA_RATIO_GATES", False):
        if area < min_area:
            return False, area, (
                f"cube area {area:.2f}% outside grid recovery band "
                f"{min_area:.2f}-{max_area:.2f}%"
            )
        if area > max_area and (
            not recoverable_failure or area > failure_max_area
        ):
            return False, area, (
                f"cube area {area:.2f}% outside grid recovery band "
                f"{min_area:.2f}-{max_area:.2f}% "
                f"(failure-only max {failure_max_area:.2f}%)"
            )

    if not recoverable_failure:
        return False, area, "default failure is not a recoverable face/grid evidence failure"
    return True, area, ""


def _eligible_for_sam_recovery(
    image_path: str,
    default_error: Exception,
    *,
    n_faces: int,
    face_patterns: Optional[List[Tuple[int, int]]],
    corners_path: Optional[str],
    manual_face_rois: Optional[List[Tuple[int, int, int, int]]],
) -> tuple[bool, Optional[float], str]:
    if corners_path is not None:
        return False, None, "precomputed corners already supplied"
    if manual_face_rois is not None:
        return False, None, "manual ROIs already supplied"
    if int(n_faces) != 3:
        return False, None, "SAM recovery is only defined for the trihedral target"
    if not _is_canonical(face_patterns):
        return False, None, "SAM recovery is only validated for canonical 9x6, 9x6, 6x6 faces"

    message = str(default_error)
    if "Not cube target:" in message:
        return False, None, "input is not the three-visible-face cube/cuboid target"
    area = _estimate_cube_area_pct(image_path, message)
    min_area = _env_float("CALIB_SAM_RECOVERY_MIN_AREA_PCT", 3.0)
    max_area = _env_float("CALIB_SAM_RECOVERY_MAX_AREA_PCT", 8.0)
    if area is not None and (area < min_area or area > max_area):
        return False, area, f"cube area {area:.2f}% outside SAM recovery band {min_area:.2f}-{max_area:.2f}%"

    recovery_needles = (
        "Range boundary:",
        "strict small-target gate",
        "visible grid pattern",
        "only ",
        "cube-first found only",
        "Insufficient visible cube faces:",
        "No calibration target detected:",
    )
    if not any(needle in message for needle in recovery_needles):
        return False, area, "default failure is not a recoverable face/grid evidence failure"
    return True, area, ""


def _image_root_and_rel(image_path: str) -> tuple[Path, str]:
    path = Path(image_path).resolve()
    candidates: list[Path] = []
    raw_root = os.environ.get("CALIB_IMAGE_ROOT", "").strip()
    if raw_root:
        candidates.append(Path(raw_root).expanduser())
    base = Path(__file__).resolve().parent
    candidates.extend(
        [
            base / "材料_extracted" / "shengkelou",
            base / "鏉愭枡_extracted" / "shengkelou",
            Path.cwd() / "材料_extracted" / "shengkelou",
            Path.cwd() / "鏉愭枡_extracted" / "shengkelou",
        ]
    )
    candidates.extend(
        [
            base / "材料_extracted" / "shengkelou",
            Path.cwd() / "材料_extracted" / "shengkelou",
        ]
    )
    for root in candidates:
        try:
            resolved_root = root.resolve()
            rel = path.relative_to(resolved_root)
            return resolved_root, rel.as_posix()
        except Exception:
            continue
    return path.parent, path.name


def _grid_face_patterns(row: dict[str, Any]) -> list[tuple[int, int]]:
    raw = str(row.get("extrapolated_patterns") or "").strip()
    patterns: list[tuple[int, int]] = []
    for item in raw.split(";"):
        item = item.strip()
        if not item:
            continue
        _label, _sep, pattern_text = item.partition(":")
        cols_text, sep, rows_text = pattern_text.lower().partition("x")
        if not sep:
            continue
        try:
            cols = int(cols_text)
            rows = int(rows_text)
        except ValueError:
            continue
        patterns.append((cols, rows))
    if len(patterns) != 3:
        raise RuntimeError(
            "Grid recovery did not report three extrapolated face patterns: "
            f"{raw or '(empty)'}"
        )
    return patterns


def _grid_template_target(face_index: int, pattern: tuple[int, int]) -> tuple[int, int]:
    cols, rows = tuple(map(int, pattern))
    if face_index == 1:
        return (min(cols, 6), min(rows, 6))
    candidates = [(9, 6), (6, 9)]
    feasible = [
        candidate for candidate in candidates
        if candidate[0] <= cols and candidate[1] <= rows
    ]
    if feasible:
        return min(
            feasible,
            key=lambda item: (cols - item[0]) + (rows - item[1]),
        )
    return (cols, rows)


def _parse_grid_template_targets(
    raw: str,
    n_faces: int,
) -> Optional[list[tuple[int, int]]]:
    targets: list[tuple[int, int]] = []
    for item in raw.replace(",", ";").split(";"):
        item = item.strip()
        if not item:
            continue
        if ":" in item:
            _label, item = item.split(":", 1)
            item = item.strip()
        cols_text, sep, rows_text = item.lower().partition("x")
        if not sep:
            return None
        try:
            targets.append((int(cols_text), int(rows_text)))
        except ValueError:
            return None
    return targets if len(targets) == n_faces else None


def _grid_template_targets(
    patterns: list[tuple[int, int]],
) -> list[tuple[int, int]]:
    raw_targets = os.environ.get(
        "CALIB_GRID_RECOVERY_TEMPLATE_TARGETS", "",
    ).strip()
    configured = (
        _parse_grid_template_targets(raw_targets, len(patterns))
        if raw_targets else None
    )
    if configured is not None:
        return configured
    return [
        _grid_template_target(index, pattern)
        for index, pattern in enumerate(patterns)
    ]


def _grid_template_trim_options(
    face_corners: np.ndarray,
    pattern: tuple[int, int],
    target: tuple[int, int],
) -> list[tuple[np.ndarray, tuple[int, int]]]:
    cols, rows = tuple(map(int, pattern))
    target_cols, target_rows = tuple(map(int, target))
    if target_cols > cols or target_rows > rows:
        return []
    grid = np.asarray(face_corners, dtype=np.float32).reshape(rows, cols, 2)
    options: list[tuple[np.ndarray, tuple[int, int]]] = []
    for y0 in range(rows - target_rows + 1):
        for x0 in range(cols - target_cols + 1):
            trimmed = grid[
                y0:y0 + target_rows,
                x0:x0 + target_cols,
                :,
            ].reshape(-1, 2)
            options.append((trimmed, (x0, y0)))
    return options


def _grid_template_clamp_results(
    image_path: str,
    corners_path: str,
    patterns: list[tuple[int, int]],
    *,
    square_size_mm: float,
    pattern_cols: int,
    pattern_rows: int,
    auto_orient_faces: bool,
    k1_only: bool,
    focal_px: Optional[float],
    k1_prior: Optional[float],
    verbose: bool,
    scale_prior_candidate: bool,
) -> list[BestResult]:
    targets = _grid_template_targets(patterns)
    if targets == patterns:
        return []
    data = np.load(corners_path, allow_pickle=True)
    try:
        corners = [
            np.asarray(face, dtype=np.float32).reshape(-1, 2)
            for face in data["corners"]
        ]
    finally:
        data.close()
    per_face_options = [
        _grid_template_trim_options(face_corners, pattern, target)
        for face_corners, pattern, target in zip(corners, patterns, targets)
    ]
    if any(not options for options in per_face_options):
        return []
    max_combos = _env_int("CALIB_GRID_RECOVERY_TEMPLATE_CLAMP_MAX_COMBOS", 8)
    out_dir = Path(corners_path).parent / "template_clamped"
    out_dir.mkdir(parents=True, exist_ok=True)
    results: list[BestResult] = []
    stem = Path(corners_path).stem
    for combo_index, combo in enumerate(itertools.product(*per_face_options)):
        if combo_index >= max_combos:
            break
        combo_corners = np.array([item[0] for item in combo], dtype=object)
        trim_offsets = [item[1] for item in combo]
        clamped_path = out_dir / f"{stem}_clamp_{combo_index:02d}.npz"
        np.savez_compressed(clamped_path, corners=combo_corners)
        try:
            result = calibrate_best(
                image_path,
                square_size_mm,
                pattern_cols,
                pattern_rows,
                face_patterns=targets,
                n_faces=3,
                auto_orient_faces=auto_orient_faces,
                k1_only=k1_only,
                focal_px=focal_px,
                k1_prior=k1_prior,
                verbose=verbose,
                corners_path=str(clamped_path),
                scale_prior_candidate=scale_prior_candidate,
            )
        except Exception:
            continue
        result.preflight["grid_template_clamp"] = {
            "applied": True,
            "source_corners_path": str(corners_path),
            "clamped_corners_path": str(clamped_path),
            "source_patterns": [list(p) for p in patterns],
            "clamped_patterns": [list(p) for p in targets],
            "trim_offsets": [list(offset) for offset in trim_offsets],
            "combo_index": int(combo_index),
        }
        result.warnings.append(
            "Clamped recovered checker grid to the fixed cube physical "
            f"template ({patterns} -> {targets}, trims={trim_offsets})."
        )
        results.append(result)
    return results


def _short_grid_row(row: dict[str, Any]) -> dict[str, Any]:
    keys = [
        "rel_path",
        "status",
        "selected_route",
        "direct_faces",
        "direct_patterns",
        "seeded_patterns",
        "extrapolated_patterns",
        "rmse_px",
        "elapsed_sec",
        "enabled_routes",
        "not_cube_reason",
        "error",
    ]
    return {key: row.get(key) for key in keys if key in row}


def _grid_row_has_usable_corners(row: dict[str, Any]) -> bool:
    return bool(
        row.get("status") in {"calibrated", "geometry_recovered"}
        and row.get("corners_path")
    )


def _has_confident_cube_zhang_result(result: BestResult) -> bool:
    preflight = getattr(result, "preflight", {}) or {}
    final = preflight.get("single_cube_zhang_final") or {}
    diagnostics = final.get("diagnostics") or {}
    confidence = diagnostics.get("full_parameter_confidence") or {}
    return bool(
        str(getattr(result, "model_used", "")).startswith("single-cube-zhang")
        and final.get("success")
        and final.get("physical_candidate")
        and confidence.get("calibration_model_confident")
    )


def _run_grid_recovery(
    image_path: str,
    *,
    default_error: Exception,
    focal_px: Optional[float],
    out_dir: Optional[Path] = None,
) -> tuple[dict[str, Any], Path]:
    if out_dir is None:
        raw_out = os.environ.get("CALIB_GRID_RECOVERY_OUT_DIR", "").strip()
        out_dir = Path(raw_out).expanduser() if raw_out else (
            Path.cwd() / "batch_results" / "runtime_grid_recovery"
        )
    out_dir.mkdir(parents=True, exist_ok=True)

    image_root, rel = _image_root_and_rel(image_path)
    raw_cache = os.environ.get("CALIB_GRID_RECOVERY_DETECT_CACHE_DIR", "").strip()
    detect_cache_dir = (
        Path(raw_cache).expanduser()
        if raw_cache
        else Path.cwd() / "batch_results" / "grid_probe_detection_cache"
    )
    focal_px, focal_source = _grid_recovery_effective_focal(image_path, focal_px)

    from grid_extrapolate_recovery_probe import probe_auto_seed_routes

    common = {
        "top_per_face": _env_int("CALIB_GRID_RECOVERY_TOP_PER_FACE", 6),
        "max_combos": _env_int("CALIB_GRID_RECOVERY_MAX_COMBOS", 800),
        "run_calibration": not _env_bool(
            "CALIB_GRID_RECOVERY_DEFER_FINAL_CALIBRATION", False
        ),
        "fast_geometry": not _env_bool("CALIB_GRID_RECOVERY_SLOW_GEOMETRY", False),
        "focal_px": focal_px,
        "enable_phase_grid": _env_bool("CALIB_GRID_RECOVERY_PHASE_GRID", False),
        "enable_dark_square_grid": _env_bool("CALIB_GRID_RECOVERY_DARK_GRID", True),
        "enable_component_face_quads": _env_bool(
            "CALIB_GRID_RECOVERY_COMPONENT_FACE_QUADS", True),
        "enable_crop_trihedral": _env_bool("CALIB_GRID_RECOVERY_CROP_TRIHEDRAL", True),
        "augment_seed_alternatives": _env_bool("CALIB_GRID_RECOVERY_AUGMENT_SEEDS", True),
        "allow_seed_only_fallback": _env_bool("CALIB_GRID_RECOVERY_SEED_ONLY_FALLBACK", True),
        "fixed_focal_joint_refine": _env_bool("CALIB_GRID_RECOVERY_FIXED_FOCAL_REFINE", True),
        "enable_component_label_permutations": _env_bool(
            "CALIB_GRID_RECOVERY_COMPONENT_LABEL_PERMUTATIONS", True),
        "detect_cache_dir": detect_cache_dir,
    }

    recovery_area = _estimate_cube_area_pct(image_path, str(default_error))
    route_stages = _grid_recovery_route_stages(recovery_area)
    stage_rows: list[dict[str, Any]] = []
    if route_stages:
        def run_grid_stage(stage_name: str, route_names: set[str]) -> dict[str, Any]:
            stage_row = probe_auto_seed_routes(
                rel,
                image_root,
                out_dir,
                route_names=route_names,
                **common,
            )
            stage_row["grid_recovery_stage"] = stage_name
            if recovery_area is not None:
                stage_row["cube_area_pct"] = float(recovery_area)
            stage_rows.append(stage_row)
            return stage_row

        for stage_name, route_names in route_stages:
            if stage_name == "small_target_adaptive_fallback":
                local_row = stage_rows[-1] if stage_rows else {}
                for fallback_name, fallback_routes in (
                    _small_target_adaptive_fallback_stages(local_row)
                ):
                    stage_row = run_grid_stage(
                        f"small_fallback_{fallback_name}",
                        fallback_routes,
                    )
                    if _grid_stage_should_stop(stage_row):
                        break
                if stage_rows and _grid_stage_should_stop(stage_rows[-1]):
                    break
                continue

            stage_row = run_grid_stage(stage_name, route_names)
            if _grid_stage_should_stop(stage_row):
                break
        row = min(stage_rows, key=_grid_stage_rank)
        row = dict(row)
        row["grid_recovery_staged"] = True
        stage_summaries = []
        for stage_row in stage_rows:
            summary = _short_grid_row(stage_row)
            summary["grid_recovery_stage"] = stage_row.get("grid_recovery_stage")
            stage_summaries.append(summary)
        row["grid_recovery_stage_summaries"] = json.dumps(
            stage_summaries,
            ensure_ascii=False,
            default=str,
        )
        row["elapsed_sec"] = sum(float(stage_row.get("elapsed_sec") or 0.0) for stage_row in stage_rows)
    else:
        row = probe_auto_seed_routes(
            rel,
            image_root,
            out_dir,
            **common,
        )
    if focal_px is not None:
        row["grid_recovery_focal_px"] = float(focal_px)
        row["grid_recovery_focal_source"] = focal_source.get("source", "")
        row["grid_recovery_focal_source_detail"] = json.dumps(
            focal_source,
            ensure_ascii=False,
            default=str,
        )
    row["default_error"] = str(default_error)
    row_path = out_dir / "runtime_grid_recovery_rows.jsonl"
    with row_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
    return row, out_dir


def _load_sam_predictor(checkpoint: Path, model_type: str):
    key = (str(checkpoint.resolve()), model_type)
    cached = _PREDICTOR_CACHE.get(key)
    if cached is not None:
        return cached

    from sam_pose_guided_missing_face_probe import SamPredictor, sam_model_registry, torch

    device = "cuda" if torch.cuda.is_available() else "cpu"
    sam = sam_model_registry[model_type](checkpoint=str(checkpoint))
    sam.to(device=device)
    predictor = SamPredictor(sam)
    _PREDICTOR_CACHE[key] = predictor
    return predictor


def _run_sam_component_recovery(
    image_path: str,
    *,
    default_error: Exception,
    out_dir: Optional[Path] = None,
) -> tuple[dict[str, Any], Path]:
    checkpoint = _checkpoint_from_env()
    if checkpoint is None or not checkpoint.exists():
        raise RuntimeError("CALIB_SAM_CHECKPOINT is missing or does not exist")

    model_type = os.environ.get("CALIB_SAM_MODEL_TYPE", "vit_b").strip() or "vit_b"
    if out_dir is None:
        raw_out = os.environ.get("CALIB_SAM_RECOVERY_OUT_DIR", "").strip()
        out_dir = Path(raw_out).expanduser() if raw_out else (
            Path.cwd() / "batch_results" / "runtime_sam_component_recovery"
        )
    out_dir.mkdir(parents=True, exist_ok=True)

    image_root, rel = _image_root_and_rel(image_path)
    from sam_pose_guided_missing_face_probe import probe_one

    predictor = _load_sam_predictor(checkpoint, model_type)
    row = probe_one(
        image_root,
        rel,
        predictor,
        out_dir,
        two_face_rmse_limit=_env_float("CALIB_SAM_TWO_FACE_RMSE_LIMIT", 18.0),
        max_pose_candidates=int(_env_float("CALIB_SAM_MAX_POSE_CANDIDATES", 12.0)),
    )
    row["default_error"] = str(default_error)
    row_path = out_dir / "runtime_sam_component_recovery_rows.jsonl"
    with row_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")
    return row, out_dir


def _result_from_grid_recovered_corners(
    image_path: str,
    row: dict[str, Any],
    *,
    square_size_mm: float,
    pattern_cols: int,
    pattern_rows: int,
    auto_orient_faces: bool,
    k1_only: bool,
    focal_px: Optional[float],
    k1_prior: Optional[float],
    verbose: bool,
) -> BestResult:
    corners_path = str(row.get("corners_path") or "")
    if not corners_path:
        raise RuntimeError("Grid recovery did not produce a corners_path")
    if not Path(corners_path).exists():
        raise RuntimeError(f"Grid recovery corners_path does not exist: {corners_path}")
    patterns = _grid_face_patterns(row)
    focal_px, focal_source = _grid_recovery_effective_focal(image_path, focal_px)
    scale_prior_candidate = _env_bool(
        "CALIB_GRID_RECOVERY_SCALE_PRIOR_CANDIDATE", True)

    candidate_results: list[tuple[str, BestResult]] = []
    original_error: Optional[Exception] = None
    try:
        original_result = calibrate_best(
            image_path,
            square_size_mm,
            pattern_cols,
            pattern_rows,
            face_patterns=patterns,
            n_faces=3,
            auto_orient_faces=auto_orient_faces,
            k1_only=k1_only,
            focal_px=focal_px,
            k1_prior=k1_prior,
            verbose=verbose,
            corners_path=corners_path,
            scale_prior_candidate=scale_prior_candidate,
        )
        candidate_results.append(("recovered_grid", original_result))
    except Exception as exc:
        original_error = exc

    clamp_mode = os.environ.get(
        "CALIB_GRID_RECOVERY_TEMPLATE_CLAMP_MODE", "compete",
    ).strip().lower()
    clamp_competes = clamp_mode not in {
        "0", "false", "off", "no", "fallback", "failure", "on_failure",
    }
    try_template_clamp = bool(
        _env_bool("CALIB_GRID_RECOVERY_TEMPLATE_CLAMP", True)
        and (original_error is not None or clamp_competes)
    )
    clamped_results: list[BestResult] = []
    if try_template_clamp:
        clamped_results = _grid_template_clamp_results(
            image_path,
            corners_path,
            patterns,
            square_size_mm=square_size_mm,
            pattern_cols=pattern_cols,
            pattern_rows=pattern_rows,
            auto_orient_faces=auto_orient_faces,
            k1_only=k1_only,
            focal_px=focal_px,
            k1_prior=k1_prior,
            verbose=verbose,
            scale_prior_candidate=scale_prior_candidate,
        )
        candidate_results.extend(
            (f"template_clamp_{index}", item)
            for index, item in enumerate(clamped_results)
        )
    if not candidate_results:
        if original_error is not None:
            raise original_error
        raise RuntimeError("Grid recovery produced no usable calibration candidates")

    def _grid_candidate_rank(item: tuple[str, BestResult]) -> tuple[int, float]:
        _source, candidate = item
        try:
            rmse_value = float(candidate.rmse)
        except (TypeError, ValueError):
            rmse_value = float("inf")
        if not math.isfinite(rmse_value):
            rmse_value = float("inf")
        return (0 if math.isfinite(rmse_value) else 1, rmse_value)

    selected_candidate_source, result = min(
        candidate_results, key=_grid_candidate_rank,
    )
    result.preflight["grid_template_candidate_selection"] = {
        "template_clamp_enabled": bool(
            _env_bool("CALIB_GRID_RECOVERY_TEMPLATE_CLAMP", True)
        ),
        "template_clamp_mode": clamp_mode or "compete",
        "template_clamp_competed": bool(try_template_clamp),
        "selected_source": selected_candidate_source,
        "original_error": None if original_error is None else str(original_error),
        "candidates": [
            {
                "source": source,
                "model": str(getattr(candidate, "model_used", "")),
                "rmse_px": float(getattr(candidate, "rmse", float("nan"))),
            }
            for source, candidate in candidate_results
        ],
    }
    if (
        _env_bool("CALIB_GRID_RECOVERY_REQUIRE_CONFIDENT_CUBE_ZHANG", False)
        and not _has_confident_cube_zhang_result(result)
    ):
        final = (getattr(result, "preflight", {}) or {}).get(
            "single_cube_zhang_final", {}
        ) or {}
        diagnostics = final.get("diagnostics") or {}
        confidence = diagnostics.get("full_parameter_confidence") or {}
        raise RuntimeError(
            "Grid recovery full-parameter gate failed: selected model "
            f"{getattr(result, 'model_used', '')!r}, "
            f"physical_candidate={bool(final.get('physical_candidate'))}, "
            "calibration_model_confident="
            f"{bool(confidence.get('calibration_model_confident'))}."
        )
    route = row.get("selected_route") or "grid"
    result.warnings.append(
        "Default automatic route failed; accepted after physical grid "
        f"extrapolation recovery ({route})."
    )
    result.preflight.update(
        {
            "recognition_status": "grid_recovery_pass",
            "recognition_label": "GRID RECOVERY PASS",
            "recognition_summary": (
                "Default cube/face detection was insufficient; crop-trihedral "
                "face recovery plus physical checker-grid extrapolation "
                "produced all three cube-face grids."
            ),
            "calibration_status": "grid_recovered_calibration",
            "calibration_label": "RECOVERED GRID CALIBRATION",
            "calibration_summary": (
                "Calibration used recovered XY/XZ/YZ checkerboard corners and "
                "then passed the single-frame geometry gate."
            ),
            "can_attempt_calibration": True,
            "can_accept_automatic": True,
            "requires_strict_small_target_gate": True,
            "router_stage": "grid_extrapolation_recovery",
            "grid_recovery": {
                key: row.get(key)
                for key in [
                    "rel_path",
                    "status",
                    "selected_route",
                    "enabled_routes",
                    "grid_recovery_staged",
                    "grid_recovery_stage",
                    "grid_recovery_stage_summaries",
                    "direct_faces",
                    "direct_patterns",
                    "seeded_patterns",
                    "extrapolated_patterns",
                    "rmse_px",
                    "elapsed_sec",
                    "selected_route_elapsed_sec",
                    "joint_fixed_focal_rmse",
                    "seed_fixed_focal_rmse",
                    "joint_max_overlap",
                    "grid_recovery_focal_px",
                    "grid_recovery_focal_source",
                    "grid_recovery_focal_source_detail",
                    "corners_path",
                    "overlay_path",
                ]
                if key in row
            },
            "grid_recovery_focal": {
                "focal_px": None if focal_px is None else float(focal_px),
                **focal_source,
            },
        }
    )
    return result


def _result_from_recovered_corners(
    image_path: str,
    row: dict[str, Any],
    *,
    square_size_mm: float,
    pattern_cols: int,
    pattern_rows: int,
    auto_orient_faces: bool,
    k1_only: bool,
    focal_px: Optional[float],
    k1_prior: Optional[float],
    verbose: bool,
) -> BestResult:
    corners_path = str(row.get("corners_path") or "")
    if not corners_path:
        raise RuntimeError("SAM recovery did not produce a corners_path")
    if not Path(corners_path).exists():
        raise RuntimeError(f"SAM recovery corners_path does not exist: {corners_path}")

    result = calibrate_best(
        image_path,
        square_size_mm,
        pattern_cols,
        pattern_rows,
        face_patterns=CANONICAL_FACE_PATTERNS,
        n_faces=3,
        auto_orient_faces=auto_orient_faces,
        k1_only=k1_only,
        focal_px=focal_px,
        k1_prior=k1_prior,
        verbose=verbose,
        corners_path=corners_path,
    )
    result.warnings.append(
        "Default automatic route failed; accepted after SAM/component "
        f"three-face recovery ({row.get('pose_idx', 'unknown route')})."
    )
    result.preflight.update(
        {
            "recognition_status": "sam_component_recovery_pass",
            "recognition_label": "SAM COMPONENT RECOVERY PASS",
            "recognition_summary": (
                "Default cube/grid evidence was insufficient; a SAM-guided "
                "face-region and component recovery route produced all three "
                "physical face grids."
            ),
            "calibration_status": "sam_component_recovered_calibration",
            "calibration_label": "RECOVERED THREE-FACE CALIBRATION",
            "calibration_summary": (
                "Calibration used recovered XY/XZ/YZ checkerboard corners and "
                "then passed the single-frame geometry gate."
            ),
            "can_attempt_calibration": True,
            "can_accept_automatic": True,
            "requires_strict_small_target_gate": True,
            "router_stage": "sam_component_recovery",
            "sam_recovery": {
                key: row.get(key)
                for key in [
                    "rel_path",
                    "status",
                    "strict_like",
                    "pose_idx",
                    "centered_pnp",
                    "offset_pnp",
                    "offset",
                    "rmse_px",
                    "model",
                    "sources",
                    "corners_path",
                    "component_retry_reason",
                ]
                if key in row
            },
        }
    )
    return result


def calibrate_with_optional_recovery(
    image_path: str,
    square_size_mm: float = DEFAULT_SQUARE_SIZE_MM,
    pattern_cols: int = 9,
    pattern_rows: int = 6,
    *,
    face_patterns: Optional[List[Tuple[int, int]]] = None,
    n_faces: int = 3,
    auto_orient_faces: bool = True,
    k1_only: bool = False,
    focal_px: Optional[float] = None,
    k1_prior: Optional[float] = None,
    verbose: bool = True,
    corners_path: Optional[str] = None,
    manual_face_rois: Optional[List[Tuple[int, int, int, int]]] = None,
    recovery_out_dir: Optional[Path] = None,
) -> BestResult:
    """Run default calibration, then optional SAM/component recovery on failure."""
    grid_first_attempted = False
    grid_first_error: Optional[Exception] = None
    grid_first_area = _grid_recovery_first_area(image_path)
    grid_first_eligible = bool(
        grid_first_area is not None
        and corners_path is None
        and manual_face_rois is None
        and int(n_faces) == 3
        and _is_canonical(face_patterns)
    )
    if grid_first_eligible:
        grid_first_attempted = True
        synthetic_boundary = RuntimeError(
            "Range boundary: cube image area is "
            f"{float(grid_first_area):.2f}% of the full image; "
            "small-target physical grid recovery was prioritized."
        )
        try:
            row, _out_dir = _run_grid_recovery(
                image_path,
                default_error=synthetic_boundary,
                focal_px=focal_px,
                out_dir=recovery_out_dir,
            )
            if row.get("status") == "not_cube_target":
                reason_text = str(row.get("not_cube_reason") or "").strip()
                raise RuntimeError(
                    "Not cube target: "
                    + (
                        reason_text
                        or "grid recovery could not recover a trihedral cube layout"
                    )
                )
            if not _grid_row_has_usable_corners(row):
                raise RuntimeError(
                    "Grid/extrapolation recovery did not produce usable corners: "
                    + json.dumps(
                        _short_grid_row(row),
                        ensure_ascii=False,
                        default=str,
                    )
                )
            result = _result_from_grid_recovered_corners(
                image_path,
                row,
                square_size_mm=square_size_mm,
                pattern_cols=pattern_cols,
                pattern_rows=pattern_rows,
                auto_orient_faces=auto_orient_faces,
                k1_only=k1_only,
                focal_px=focal_px,
                k1_prior=k1_prior,
                verbose=verbose,
            )
            result.preflight["router_order"] = "grid_recovery_then_default"
            result.preflight["grid_recovery_first_area_pct"] = float(
                grid_first_area
            )
            result.warnings.append(
                "Prioritized physical grid recovery before the default route "
                f"because cube area was {float(grid_first_area):.2f}%."
            )
            return result
        except Exception as recovery_error:
            if "Not cube target:" in str(recovery_error):
                raise
            grid_first_error = recovery_error
            boundary_message = _small_target_stop_after_grid_first_failure(
                grid_first_area,
                recovery_error,
            )
            if boundary_message:
                raise RuntimeError(boundary_message) from recovery_error

    try:
        result = calibrate_best(
            image_path,
            square_size_mm,
            pattern_cols,
            pattern_rows,
            face_patterns=face_patterns,
            n_faces=n_faces,
            auto_orient_faces=auto_orient_faces,
            k1_only=k1_only,
            focal_px=focal_px,
            k1_prior=k1_prior,
            verbose=verbose,
            corners_path=corners_path,
            manual_face_rois=manual_face_rois,
            scale_prior_candidate=_precomputed_corners_scale_prior_candidate(
                corners_path
            ),
        )
        result.preflight.setdefault("router_stage", "default")
        if grid_first_attempted:
            result.preflight["router_order"] = "grid_recovery_then_default"
            result.preflight["grid_recovery_first_area_pct"] = float(
                grid_first_area
            )
            result.preflight["grid_recovery_first_fallback"] = str(
                grid_first_error
            )
            result.warnings.append(
                "Small-target grid-first recovery was not accepted; the "
                "existing default calibration route succeeded instead."
            )
        return result
    except Exception as default_error:
        grid_error: Optional[Exception] = grid_first_error
        if _grid_recovery_enabled() and not grid_first_attempted:
            eligible, _area, reason = _eligible_for_grid_recovery(
                image_path,
                default_error,
                n_faces=n_faces,
                face_patterns=face_patterns,
                corners_path=corners_path,
                manual_face_rois=manual_face_rois,
            )
            if not eligible:
                if verbose:
                    print(f"Grid recovery skipped: {reason}")
            else:
                try:
                    row, _out_dir = _run_grid_recovery(
                        image_path,
                        default_error=default_error,
                        focal_px=focal_px,
                        out_dir=recovery_out_dir,
                    )
                    if row.get("status") == "not_cube_target":
                        reason_text = str(row.get("not_cube_reason") or "").strip()
                        raise RuntimeError(
                            "Not cube target: "
                            + (
                                reason_text
                                or "grid recovery could not recover a trihedral cube layout"
                            )
                        )
                    if not _grid_row_has_usable_corners(row):
                        raise RuntimeError(
                            "Grid/extrapolation recovery did not produce usable corners: "
                            + json.dumps(
                                _short_grid_row(row),
                                ensure_ascii=False,
                                default=str,
                            )
                        )
                    return _result_from_grid_recovered_corners(
                        image_path,
                        row,
                        square_size_mm=square_size_mm,
                        pattern_cols=pattern_cols,
                        pattern_rows=pattern_rows,
                        auto_orient_faces=auto_orient_faces,
                        k1_only=k1_only,
                        focal_px=focal_px,
                        k1_prior=k1_prior,
                        verbose=verbose,
                    )
                except Exception as recovery_error:
                    if "Not cube target:" in str(recovery_error):
                        raise
                    grid_error = recovery_error

        if not _sam_recovery_enabled():
            if grid_error is not None:
                raise RuntimeError(
                    f"{default_error} Grid/extrapolation recovery attempted "
                    f"but not accepted: {grid_error}"
                ) from default_error
            raise
        eligible, _area, reason = _eligible_for_sam_recovery(
            image_path,
            default_error,
            n_faces=n_faces,
            face_patterns=face_patterns,
            corners_path=corners_path,
            manual_face_rois=manual_face_rois,
        )
        if not eligible:
            if verbose:
                print(f"SAM recovery skipped: {reason}")
            if grid_error is not None:
                raise RuntimeError(
                    f"{default_error} Grid/extrapolation recovery attempted "
                    f"but not accepted: {grid_error}"
                ) from default_error
            raise

        try:
            row, _out_dir = _run_sam_component_recovery(
                image_path,
                default_error=default_error,
                out_dir=recovery_out_dir,
            )
            if row.get("status") != "calibrated" or row.get("strict_like") != "pass":
                raise RuntimeError(
                    "SAM/component recovery did not pass strict-like gate: "
                    + json.dumps(row, ensure_ascii=False)
                )
            return _result_from_recovered_corners(
                image_path,
                row,
                square_size_mm=square_size_mm,
                pattern_cols=pattern_cols,
                pattern_rows=pattern_rows,
                auto_orient_faces=auto_orient_faces,
                k1_only=k1_only,
                focal_px=focal_px,
                k1_prior=k1_prior,
                verbose=verbose,
            )
        except Exception as recovery_error:
            grid_clause = (
                f" Grid/extrapolation recovery attempted but not accepted: {grid_error}."
                if grid_error is not None
                else ""
            )
            raise RuntimeError(
                f"{default_error}{grid_clause} SAM/component recovery attempted but not "
                f"accepted: {recovery_error}"
            ) from default_error
