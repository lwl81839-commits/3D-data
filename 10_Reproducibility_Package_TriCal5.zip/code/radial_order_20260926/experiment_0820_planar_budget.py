"""Frozen planar training-budget experiment; no test-guided selection."""
from pathlib import Path
import os,sys,json,hashlib,subprocess,time
from concurrent.futures import ThreadPoolExecutor,as_completed
import numpy as np
import cv2
from evaluate_planar_blind_comparison import detect_checker,object_points
from ablate_0820_ratio_prior import SPLIT,BASE,POSES,ROOT
OUT=ROOT/'output/experiment_0820_planar_budget'
OUT.mkdir(exist_ok=True)
def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def folder(pose):
    return next(p for p in [SPLIT/'train'/pose/'2D',SPLIT/'train'/pose/'zhang_2d'] if p.is_dir())
def train(pose):
    cv2.setNumThreads(1)
    paths=sorted(folder(pose).glob('*.jpg'),key=lambda p:int(p.stem.rsplit('_',1)[1]))
    assert len(paths)==20,(pose,len(paths))
    testhash={hashlib.sha256(p.read_bytes()).hexdigest() for p in (SPLIT/'test'/pose).rglob('*.jpg')}
    observations=[]; metadata=[]; size=None
    for p in paths:
        digest=hashlib.sha256(p.read_bytes()).hexdigest(); assert digest not in testhash
        corners,detector=detect_checker(p)
        gray=cv2.imdecode(np.fromfile(str(p),np.uint8),0)
        current=(gray.shape[1],gray.shape[0]); assert size is None or size==current; size=current
        observations.append(corners)
        metadata.append(dict(image=str(p),sha256=digest,detector=detector,detected=corners is not None))
    seed=20260911+POSES.index(pose)*1000
    permutations=[np.random.default_rng(seed+r).permutation(20) for r in range(5)]
    jobs=[(n,r,perm[:n]) for r,perm in enumerate(permutations) for n in [5,10]]+[(20,0,np.arange(20))]
    save(OUT/'models'/pose/'training_pool.json',metadata)
    results=[]
    for n,r,indices in jobs:
        name=f'planar_{n:02d}_r{r+1:02d}'
        chosen=[metadata[i] for i in indices]
        m=dict(source='OpenCV Zhang-style planar calibration; fixed k3 and zero tangential distortion',is_zhang_reference=True,training_images=chosen,requested=n,repeat=r+1,seed=seed+r,image_size=size,flags=['CALIB_FIX_K3','CALIB_ZERO_TANGENT_DIST'],parameter_ratio_prior=False)
        try:
            if any(observations[i] is None for i in indices): raise RuntimeError('Selected training image detection failed; no replacement from tests')
            start=time.perf_counter()
            rms,K,d,rv,tv=cv2.calibrateCamera([object_points(25).astype(np.float32) for i in indices],[observations[i].astype(np.float32) for i in indices],size,None,None,flags=cv2.CALIB_FIX_K3|cv2.CALIB_ZERO_TANGENT_DIST,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,200,1e-12))
            assert np.isfinite(K).all() and np.isfinite(d).all()
            m.update(completed=True,cameraMatrix=K.tolist(),distCoeffs=d.ravel()[:5].tolist(),training_rmse_px=float(rms),elapsed_s=time.perf_counter()-start)
        except Exception as e: m.update(completed=False,error=str(e))
        save(OUT/'models'/pose/(name+'.json'),m);results.append(dict(name=name,completed=m['completed']))
    save(OUT/'models'/pose/'status.json',results)
    return results
def job(name,args):
    env=os.environ.copy();env.update(PYTHONPATH=str(ROOT),PYTHONIOENCODING='utf-8',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    path=OUT/'logs'/(name+'.log');path.parent.mkdir(exist_ok=True)
    with path.open('w',encoding='utf-8') as f:
        p=subprocess.run([sys.executable,*map(str,args)],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    result=dict(job=name,returncode=p.returncode);print(result,flush=True);return result
def prepare_planar():
    s=(ROOT/'evaluate_planar_per_pose_controlled.py').read_text(encoding='utf-8')
    s=s.replace('for pose_index, pose in enumerate(POSES):','for pose_index, pose in enumerate(POSES):\n        if pose != __import__("os").environ["BUDGET_POSE"]: continue')
    needle='models = {"ours_3d_5_images": (ours_K, ours_dist), "zhang_matlab_20_images": (zhang_K, zhang_dist)}'
    s=s.replace(needle,needle+'\n        for mp in Path('+repr(str(OUT/'models'))+').joinpath(pose).glob("planar_*.json"):\n            m = json.loads(mp.read_text(encoding="utf-8"))\n            if m["completed"]: models[mp.stem] = (np.array(m["cameraMatrix"]), np.array(m["distCoeffs"]))')
    s=s.replace('out = validation / "final_test_evaluation" / pose / "planar_2d_controlled"','out = Path('+repr(str(OUT))+') / "tests" / pose / "2D"')
    # Redirect any global summary outputs, never overwrite reference files.
    s=s.replace('validation / "final_test_evaluation" / "PLANAR_2D_CONTROLLED_SUMMARY.json"','Path('+repr(str(OUT))+') / ("PLANAR_" + __import__("os").environ["BUDGET_POSE"] + ".json")')
    p=OUT/'evaluate_planar_budget.py';p.write_text(s,encoding='utf-8');return p
def main():
    save(OUT/'protocol.json',dict(dataset=str(SPLIT),sizes=[5,10,20],subset_repetitions=5,nested_5_in_10=True,seed=20260911,test_selection_used=False,estimator='OpenCV calibrateCamera',opencv=cv2.__version__,flags=['CALIB_FIX_K3','CALIB_ZERO_TANGENT_DIST'],comparison='Existing selected TriCal5 versus random planar subsets; not a matched selection algorithm comparison',test_repeats=20))
    with ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(train,POSES))
    planar=prepare_planar()
    tasks=[]
    for pose in POSES:
        tasks.append((pose+'_2D',[__file__,'planar',pose]))
        for p in (OUT/'models'/pose).glob('planar_*.json'):
            if not json.loads(p.read_text())['completed']:continue
            tasks.append((pose+'_'+p.stem,[ROOT/'evaluate_trained_camera_model.py','--model',BASE/'per_pose_models'/pose/'trained_camera_model.json','--camera-override-json',p,'--images',SPLIT/'test'/pose/'3D','--output-dir',OUT/'tests'/pose/'3D'/p.stem,'--correspondence-cache-dir',BASE/'test_correspondence_cache'/pose,'--only-existing-cache','--repeats','20']))
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(job,n,a) for n,a in tasks]
        statuses=[f.result() for f in as_completed(futures)]
    save(OUT/'test_jobs.json',statuses)
if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='planar':
        os.environ['BUDGET_POSE']=sys.argv[2]
        import runpy
        sys.argv=[str(OUT/'evaluate_planar_budget.py'),'--split-root',str(SPLIT),'--repeats','20']
        runpy.run_path(sys.argv[0],run_name='__main__')
    else: main()
