#!/usr/bin/env python3
"""Build and resolve per-group focal anchors from trusted cube calibrations."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any, Optional

import cv2
import numpy as np


DEFAULT_INPUT_CSV = Path("batch_results/v67_full_regression/current_batch_results.csv")
DEFAULT_OUT_DIR = Path("batch_results/group_scale_anchors_20260716_v1")


def _maybe_float(value: Any) -> Optional[float]:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _read_gray(path: Path) -> Optional[np.ndarray]:
    try:
        data = np.fromfile(str(path), dtype=np.uint8)
        return cv2.imdecode(data, cv2.IMREAD_GRAYSCALE)
    except Exception:
        return None


def _image_diag_from_row(row: dict[str, Any], root: Path) -> Optional[float]:
    for key in ("workspace_path", "image_path", "path"):
        raw = str(row.get(key) or "").strip()
        if not raw:
            continue
        path = Path(raw)
        if not path.is_absolute():
            path = root / path
        img = _read_gray(path)
        if img is not None:
            h_img, w_img = img.shape[:2]
            return float(math.hypot(w_img, h_img))
    return None


def _group_from_image_path(image_path: str) -> Optional[str]:
    path = Path(image_path)
    parts = path.parts
    for index, part in enumerate(parts):
        if part == "shengkelou" and index + 1 < len(parts):
            return parts[index + 1]
    if len(parts) >= 2:
        return parts[-2]
    return None


def build_group_anchors(
    input_csv: Path,
    *,
    root: Path,
    min_count: int = 1,
) -> dict[str, Any]:
    rows = []
    with input_csv.open("r", encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            if str(row.get("decision") or "").strip() != "accepted":
                continue
            if str(row.get("status") or "").strip() not in {"ok", "accepted"}:
                continue
            group = str(row.get("group") or "").strip()
            if not group or group.lower() == "zhang":
                continue
            fx = _maybe_float(row.get("fx_px"))
            fy = _maybe_float(row.get("fy_px"))
            rmse = _maybe_float(row.get("rmse_px"))
            n_faces = _maybe_float(row.get("n_faces_detected"))
            n_corners = _maybe_float(row.get("n_corners"))
            if fx is None or fy is None or fx <= 0 or fy <= 0:
                continue
            if rmse is not None and rmse > 12.0:
                continue
            if n_faces is not None and n_faces < 3:
                continue
            if n_corners is not None and n_corners < 120:
                continue
            focal = 0.5 * (fx + fy)
            diag = _image_diag_from_row(row, root)
            rows.append({
                "group": group,
                "rel_path": row.get("rel_path") or "",
                "focal_px": focal,
                "fx_px": fx,
                "fy_px": fy,
                "rmse_px": rmse,
                "cube_area_pct": _maybe_float(row.get("cube_area_pct")),
                "diag_px": diag,
                "diag_mult": None if diag is None else focal / diag,
                "model": row.get("model") or "",
            })

    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(str(row["group"]), []).append(row)

    anchors: dict[str, Any] = {}
    for group, group_rows in sorted(groups.items()):
        if len(group_rows) < min_count:
            continue
        focals = sorted(float(row["focal_px"]) for row in group_rows)
        n = len(focals)
        median = focals[n // 2] if n % 2 else 0.5 * (focals[n // 2 - 1] + focals[n // 2])
        deviations = sorted(abs(value - median) for value in focals)
        mad = deviations[n // 2] if n % 2 else 0.5 * (
            deviations[n // 2 - 1] + deviations[n // 2]
        )
        diag_mults = [
            float(row["diag_mult"])
            for row in group_rows
            if row.get("diag_mult") is not None
        ]
        diag_mult = None
        if diag_mults:
            diag_mults_sorted = sorted(diag_mults)
            m = len(diag_mults_sorted)
            diag_mult = (
                diag_mults_sorted[m // 2]
                if m % 2 else
                0.5 * (diag_mults_sorted[m // 2 - 1] + diag_mults_sorted[m // 2])
            )
        anchors[group] = {
            "focal_px": float(median),
            "diag_mult": diag_mult,
            "count": int(n),
            "mad_px": float(mad),
            "min_px": float(focals[0]),
            "max_px": float(focals[-1]),
            "evidence_rel_paths": [row["rel_path"] for row in group_rows],
            "evidence": group_rows,
            "confidence": "group_median" if n >= 3 else "low_count_group_anchor",
        }

    return {
        "source_csv": str(input_csv),
        "min_count": int(min_count),
        "anchor_type": "median_fx_fy_from_accepted_cube_calibrations",
        "groups": anchors,
    }


def load_anchor_file(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def resolve_group_anchor(
    image_path: str,
    anchor_file: Path,
) -> Optional[dict[str, Any]]:
    data = load_anchor_file(anchor_file)
    group = _group_from_image_path(image_path)
    if not group:
        return None
    anchor = (data.get("groups") or {}).get(group)
    if not isinstance(anchor, dict):
        return None
    focal = _maybe_float(anchor.get("focal_px"))
    if focal is None or focal <= 0:
        return None
    out = dict(anchor)
    out["group"] = group
    out["anchor_file"] = str(anchor_file)
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-csv", type=Path, default=DEFAULT_INPUT_CSV)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    parser.add_argument("--min-count", type=int, default=1)
    args = parser.parse_args()

    payload = build_group_anchors(
        args.input_csv,
        root=Path.cwd(),
        min_count=int(args.min_count),
    )
    args.out_dir.mkdir(parents=True, exist_ok=True)
    out_json = args.out_dir / "group_focal_anchors.json"
    out_json.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    rows = []
    for group, anchor in (payload.get("groups") or {}).items():
        rows.append({
            "group": group,
            "focal_px": anchor.get("focal_px"),
            "diag_mult": anchor.get("diag_mult"),
            "count": anchor.get("count"),
            "mad_px": anchor.get("mad_px"),
            "min_px": anchor.get("min_px"),
            "max_px": anchor.get("max_px"),
            "confidence": anchor.get("confidence"),
        })
    with (args.out_dir / "group_focal_anchors.csv").open(
        "w", encoding="utf-8-sig", newline=""
    ) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "group",
                "focal_px",
                "diag_mult",
                "count",
                "mad_px",
                "min_px",
                "max_px",
                "confidence",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({
        "out_json": str(out_json),
        "groups": len(rows),
        "group_names": [row["group"] for row in rows],
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
