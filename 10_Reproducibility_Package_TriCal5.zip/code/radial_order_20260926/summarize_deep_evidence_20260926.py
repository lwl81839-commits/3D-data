from deepen_evidence_20260926 import DEST,read
d=read(DEST/'results.json')
lines=['# 现有数据严谨性补充分析','','未新增采集或训练。区间为10000次图片级配对bootstrap的百分位区间；测试图片可能存在同一采集序列相关性，因此仍属条件性描述，不是跨采集总体保证。未做多重检验校正，不将区间跨零解释为等效。','','## 单张减五张：逐图RMSE差值的中位数及95%区间','','|模型|类型|区域|图数|差值px|95%区间|','|---|---|---|---|---|---|']
for r in d['paired_bootstrap']:
    lines.append(f"|{r['model']}|{r['kind']}|{r['region']}|{r['n']}|{r['median_paired_difference']:.4f}|[{r['ci95'][0]:.4f}, {r['ci95'][1]:.4f}]|")
lines+=['','## 有效面数分层','','面数由同一测试缓存和相同通用筛选得到。三面小样本仅描述原始值，不作总体推断。','','|配置|模型|面数|图片数|中位数px|P95 px|','|---|---|---|---|---|---|']
for r in d['face_strata']:
    if r['n']:lines.append(f"|{r['pose']}|{r['model']}|{r['faces']}|{r['n']}|{r['median']:.3f}|{r['p95']:.3f}|")
lines+=['','## 不重新估计位姿的射线与映射差异','','下表比较相同测试像素映射出的射线，与同配置五图诊断模型对比。共同参考像素差是在同一参考内参平面中表示的差异，不是观测误差或真实精度。只覆盖实际观测像素；逆畸变重投影误差超过0.01px的点明确排除。','','|配置|模型|有效/总点|角度中位数°|共同像素差中位数|共同像素差P95|','|---|---|---|---|---|---|']
for r in d['ray_mapping']:
    a,b=r['ray_angle_degrees'],r['common_reference_pixels']
    if a['n']:lines.append(f"|{r['pose']}|{r['model']}|{r['valid_inverse_points']}/{r['observed_points']}|{a['median']:.4f}|{b['median']:.3f}|{b['p95']:.3f}|")
lines+=['','## 大误差图片审计','','每个模型按既有三维留出RMSE选最差两张，不删除样本。图中为全部有效点的诊断拟合，不是原留出预测。独立面拟合具有更多自由度，低误差只提示面间一致性或共同位姿问题，不能单独证明编号或物体装配错误。','','|配置|模型|图片|面数|原留出RMSE|各面：刚体RMSE / 独立平面RMSE|','|---|---|---|---|---|---|']
for r in d['worst_cases']:
    vals='; '.join(f"face{q['face']}: {q['rigid_rmse']:.2f}/"+(f"{q['independent_plane_rmse']:.2f}" if q['independent_plane_rmse'] is not None else 'failed') for q in r['per_face'])
    lines.append(f"|{r['pose']}|{r['model']}|{r['image']}|{r['faces']}|{r['heldout_rmse']:.2f}|{vals}|")
lines+=['','所有数值及三面逐图原始值见results.json；诊断覆盖图保存在同目录。对视觉清晰度、拓扑误配和实体尺寸偏差未进行独立人工真值标注，不作唯一根因断言。']
(DEST/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
print('\n'.join(lines))
