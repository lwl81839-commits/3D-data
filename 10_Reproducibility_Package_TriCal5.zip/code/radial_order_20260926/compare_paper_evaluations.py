#!/usr/bin/env python3
"""Create a paired comparison from two paper-evaluation JSON files."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from statistics import mean, median
from typing import Any


METRICS = {
    "holdout_rmse_px": "留出RMSE（px）",
    "holdout_object_point_rmse_mm": "空间点RMSE（mm）",
    "holdout_length_relative_error_pct": "长度相对误差（%）",
    "cross_face_prediction_rmse_px": "跨面预测RMSE（px）",
    "undistorted_line_rms_px": "去畸变直线残差（px）",
}


def num(value: Any) -> float | None:
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def fmt(value: Any) -> str:
    value = num(value)
    return "-" if value is None else f"{value:.3f}"


def exact_two_sided_sign_p(wins: int, losses: int) -> float | None:
    n = wins + losses
    if n == 0:
        return None
    tail = min(wins, losses)
    probability = 2.0 * sum(math.comb(n, k) for k in range(tail + 1)) / (2.0 ** n)
    return min(1.0, float(probability))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ours", type=Path, required=True)
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    ours_payload = json.loads(args.ours.resolve().read_text(encoding="utf-8"))
    baseline_payload = json.loads(args.baseline.resolve().read_text(encoding="utf-8"))
    ours = {(r["group"], r["image"]): r for r in ours_payload["rows"]}
    baseline = {(r["group"], r["image"]): r for r in baseline_payload["rows"]}
    common = sorted(set(ours) & set(baseline))
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)

    paired: list[dict[str, Any]] = []
    for group, image in common:
        for key, label in METRICS.items():
            ours_value = num(ours[(group, image)].get(key))
            base_value = num(baseline[(group, image)].get(key))
            if ours_value is None or base_value is None:
                continue
            delta = ours_value - base_value
            paired.append({
                "group": group,
                "image": image,
                "metric": key,
                "metric_label": label,
                "ours": ours_value,
                "baseline": base_value,
                "ours_minus_baseline": delta,
                "ours_better": delta < 0.0,
                "relative_delta_pct": 100.0 * delta / base_value if base_value else None,
            })

    summaries: list[dict[str, Any]] = []
    for key, label in METRICS.items():
        rows = [r for r in paired if r["metric"] == key]
        if not rows:
            continue
        deltas = [float(r["ours_minus_baseline"]) for r in rows]
        summaries.append({
            "metric": key,
            "metric_label": label,
            "paired_images": len(rows),
            "ours_median": median(float(r["ours"]) for r in rows),
            "baseline_median": median(float(r["baseline"]) for r in rows),
            "median_paired_delta": median(deltas),
            "mean_paired_delta": mean(deltas),
            "ours_wins": sum(bool(r["ours_better"]) for r in rows),
            "two_sided_exact_sign_p": exact_two_sided_sign_p(
                sum(bool(r["ours_better"]) for r in rows),
                sum(not bool(r["ours_better"]) for r in rows),
            ),
        })

    with (output / "paired_results.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(paired[0]) if paired else [])
        if paired:
            writer.writeheader()
            writer.writerows(paired)
    payload = {
        "schema": "paired-camera-model-evaluation/v1",
        "ours": str(args.ours.resolve()),
        "baseline": str(args.baseline.resolve()),
        "common_images": [list(key) for key in common],
        "conditional_on_ours_success": True,
        "summaries": summaries,
        "paired_rows": paired,
    }
    (output / "paired_comparison.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    lines = [
        "# 本方法与张正友参数的配对任务评价",
        "",
        "两种相机参数在相同盲测图、相同已提取二维/三维证据和相同留出规则下比较。数值越低越好。",
        "",
        "重要：本表只包含本方法端到端成功的图片，因此用于比较相机参数质量，不能替代完整集合成功率。",
        "",
        "| 指标 | 配对图 | 本方法中位数 | Zhang中位数 | 配对差值中位数 | 本方法胜出 | 符号检验p |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for item in summaries:
        lines.append(
            f"| {item['metric_label']} | {item['paired_images']} | "
            f"{fmt(item['ours_median'])} | {fmt(item['baseline_median'])} | "
            f"{fmt(item['median_paired_delta'])} | "
            f"{item['ours_wins']}/{item['paired_images']} | "
            f"{fmt(item['two_sided_exact_sign_p'])} |"
        )
    lines += [
        "",
        "## 逐图留出RMSE",
        "",
        "| 配置/图片 | 本方法（px） | Zhang（px） | 本方法-Zhang |",
        "|---|---:|---:|---:|",
    ]
    for row in paired:
        if row["metric"] != "holdout_rmse_px":
            continue
        lines.append(
            f"| {row['group']}/{row['image']} | {fmt(row['ours'])} | "
            f"{fmt(row['baseline'])} | {fmt(row['ours_minus_baseline'])} |"
        )
    lines += [
        "",
        "## 结论边界",
        "",
        "- 该对照隔离了相机参数质量：检测成功后，固定不同K、畸变参数执行同一任务。",
        "- 样本数目前只有5张，跨面指标只有1张，不能据此宣称统计显著优于张正友。",
        "- 完整论文必须同时引用端到端A/B/C/D总表，因为本方法当前检测成功率较低。",
    ]
    (output / "PAIRED_COMPARISON_REPORT.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    print(output / "PAIRED_COMPARISON_REPORT.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
