from experiment_0820_planar_budget import OUT,BASE,POSES
import json
import numpy as np
def read(p):return json.loads(p.read_text(encoding='utf-8'))
rows=[]
for pose in POSES:
    planar=read(OUT/'tests'/pose/'2D/evaluation.json')
    for n in [5,10,20]:
        vals2=[];vals3=[];coeff=[]
        for r in range(5 if n<20 else 1):
            name=f'planar_{n:02d}_r{r+1:02d}'
            m=read(OUT/'models'/pose/(name+'.json'))
            if not m['completed']:continue
            vals2.append(planar['summaries'][name]['holdout_rmse_px']['median'])
            e=read(OUT/'tests'/pose/'3D'/name/'evaluation.json')
            vals3.append(e['summary']['holdout_error_px']['median'])
            coeff.append(m['distCoeffs'][:2])
        rows.append(dict(pose=pose,n=n,completed=len(vals2),planar_median=float(np.median(vals2)),planar_min=min(vals2),planar_max=max(vals2),cuboid_median=float(np.median(vals3)),cuboid_min=min(vals3),cuboid_max=max(vals3),k1_k2=coeff))
    ours3=read(BASE/'final_test_evaluation'/pose/'ours_3d_5_images/evaluation.json') if (BASE/'final_test_evaluation'/pose/'ours_3d_5_images/evaluation.json').exists() else read(OUT.parent/'ablation_0820_no_ratio_constraint/final_test_evaluation'/pose/'with_ratio_prior/evaluation.json')
    rows.append(dict(pose=pose,n='TriCal5',planar_median=planar['summaries']['ours_3d_5_images']['holdout_rmse_px']['median'],cuboid_median=ours3['summary']['holdout_error_px']['median']))
(OUT/'summary.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
lines=['# 0820 planar training-budget experiment','',
'OpenCV Zhang-style planar calibration, k1+k2, zero tangential distortion and fixed k3. Five and ten images each use five fixed random subsets from the original 20-image training pool; five is nested in ten. Twenty uses the full pool. No test images are selected for training. Original MATLAB results remain a separate implementation reference.','',
'Values below are median hold-out RMSE (px); ranges are min--max across training subsets, NOT confidence intervals. For planar tests each subset score is the median of per-image median trial RMSEs. Cuboid scores follow the original evaluator median across trial RMSEs. Do not treat repeated subsets/trials as independent datasets.','',
'|Configuration|Training|2D median [range]|3D median [range]|','|---|---|---|---|']
for x in rows:
    def val(k):
        v=f"{x[k+'_median']:.4f}"
        if k+'_min' in x:v+=f" [{x[k+'_min']:.4f}, {x[k+'_max']:.4f}]"
        return v
    lines.append(f"|{x['pose']}|{x['n']}|{val('planar')}|{val('cuboid')}|")
lines+=['','## Interpretation boundaries','',
'TriCal5 uses the existing quality/coverage-selected five images, whereas the planar subsets are random draws from the frozen planar development pool. This measures random-subset robustness, not a matched best-of-five selection policy. No universal sample-count requirement or absolute metrological accuracy follows. No new formal acceptance gate is imposed on the planar calibrations: completed means a finite numerical fit, not proven parameter identifiability. All failed fits/detections remain in the saved files. The 0909 external dataset and manuscript are unchanged.']
(OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
print('\n'.join(lines))
