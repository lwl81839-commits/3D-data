"""Exploratory expanded-pool sample-count curves, isolated from the main model."""
from pathlib import Path
import os,sys,json,hashlib,shutil,subprocess,time,traceback
from concurrent.futures import ThreadPoolExecutor,as_completed
import numpy as np
from ablate_0820_ratio_prior import ROOT,BASE,SPLIT,POSES
OUT=Path(os.environ.get('STABILITY_CURVE_OUTPUT',str(ROOT/'output/experiment_0820_stability_curve')))
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def prepare():
    code=OUT/'code';code.mkdir(exist_ok=True)
    s=(ROOT/'trained_camera_model.py').read_text(encoding='utf-8');original=s
    changes={'if len(paths) < 4:':'if len(paths) < 2:', 'At least four development images are required':'At least two development images are required in this exploratory entry', 'if len(samples) < 4:':'if len(samples) < 2:', 'at least four are required':'at least two are required in this exploratory entry'}
    for a,b in changes.items():assert a in s;s=s.replace(a,b)
    (code/'trained_camera_model.py').write_text(s,encoding='utf-8')
    shutil.copy2(ROOT/'trained_camera_model.py',code/'original_trained_camera_model.py')
    jobs=[];splits=[]
    for pi,pose in enumerate(POSES):
        scanned=read(OUT/(pose+'_pool.json'));eligible=[r for r in scanned if r['passed']]
        candidates=[r for r in eligible if r['old_role']=='test']
        rng=np.random.default_rng(20260912+pi*100)
        take=min(len(candidates),max(1,len(eligible)//5))
        held={candidates[i]['sha256'] for i in rng.permutation(len(candidates))[:take]}
        pool=[r for r in eligible if r['sha256'] not in held];poolhash={r['sha256'] for r in pool}
        validation=[r for r in scanned if r['sha256'] not in poolhash]
        assert not poolhash & {r['sha256'] for r in validation}
        for r in validation:
            dst=OUT/'validation'/pose/'3D'/Path(r['image']).name;dst.parent.mkdir(parents=True,exist_ok=True)
            if not dst.exists():shutil.copy2(r['image'],dst)
            assert hashlib.sha256(dst.read_bytes()).hexdigest()==r['sha256']
        maximum=min(10,len(pool));sizes=sorted(set(n for n in [2,3,4,5,7,10,maximum] if n<=maximum))
        splits.append(dict(pose=pose,pool=pool,validation=validation,multiface_validation_count=len(held),sizes=sizes))
        # Three nested random orders; no validation result enters sampling.
        for rep in range(3):
            order=np.random.default_rng(20260912+pi*100+rep+10).permutation(len(pool))
            for n in sizes:
                name=f'n{n:02d}_r{rep+1:02d}';directory=OUT/'models'/pose/name
                selected=[pool[i] for i in order[:n]]
                cache=directory/'.trihedral_correspondence_cache';cache.mkdir(parents=True,exist_ok=True)
                for r in selected:shutil.copy2(r['cache'],cache/Path(r['cache']).name)
                spec=dict(pose=pose,name=name,n=n,repeat=rep+1,selected=selected,seed=20260912+pi*100+rep+10)
                save(directory/'selection.json',spec);jobs.append(spec)
    save(OUT/'protocol.json',dict(scope='exploratory re-split of previously inspected 0820 data; NOT new independent final testing',splits=splits,jobs=jobs,repeats=3,matlab_reference_unchanged=True,low_n_changes=changes,minimum_multi_face_images='min(4,n); geometric/fit/LOO/k2 gates unchanged',main_source_sha256=hashlib.sha256(original.encode()).hexdigest(),experimental_source_sha256=hashlib.sha256(s.encode()).hexdigest(),plateau_screen='descriptive only: 3/3 release passes, across-repeat validation-score relative range <=10%, next-budget median change <=5% on BOTH 2D and 3D; not an application accuracy guarantee',small_n_warning='Two-image LOO fits one image and may have insufficient plane evidence; recorded as failure, not bypassed'))
    return jobs
def train(pose,name):
    sys.path.insert(0,str(OUT/'code'))
    import cv2
    cv2.setNumThreads(1);cv2.setRNGSeed(20260912)
    from trained_camera_model import train_camera_model
    d=OUT/'models'/pose/name;j=read(d/'selection.json');start=time.perf_counter()
    try:
        m=train_camera_model([r['image'] for r in j['selected']],25,str(d/'trained_camera_model.json'),distortion_model='k1_k2',minimum_multi_face_images=min(4,j['n']),progress=lambda t:print(t,flush=True))
        save(d/'status.json',dict(completed=True,accepted=m['accepted'],elapsed_s=time.perf_counter()-start))
    except Exception as e:save(d/'status.json',dict(completed=False,accepted=False,error=str(e),traceback=traceback.format_exc(),elapsed_s=time.perf_counter()-start))
def run(name,args):
    logs=OUT/'logs';logs.mkdir(exist_ok=True);env=os.environ.copy();env.update(PYTHONPATH=str(ROOT),PYTHONIOENCODING='utf-8',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
    with (logs/(name+'.log')).open('w',encoding='utf-8') as f:p=subprocess.run([sys.executable,*map(str,args)],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    status=dict(job=name,returncode=p.returncode);print(status,flush=True);return status
def main():
    jobs=prepare()
    with ThreadPoolExecutor(max_workers=3) as pool:
        results=list(pool.map(lambda j:run('train_'+j['pose']+'_'+j['name'],[__file__,'train',j['pose'],j['name']]),jobs))
    save(OUT/'training_jobs.json',results)
    tasks=[]
    for j in jobs:
        d=OUT/'models'/j['pose']/j['name']
        if not read(d/'status.json')['completed']:continue
        # Merge selected validation caches into a separate evaluation-only cache.
        cache=OUT/'validation_cache'/j['pose'];cache.mkdir(parents=True,exist_ok=True)
        for r in next(s for s in read(OUT/'protocol.json')['splits'] if s['pose']==j['pose'])['validation']:
            if r['cache']:
                target=cache/Path(r['cache']).name
                if not target.exists():shutil.copy2(r['cache'],target)
        args=[ROOT/'evaluate_trained_camera_model.py','--model',d/'trained_camera_model.json','--images',OUT/'validation'/j['pose']/'3D','--output-dir',OUT/'evaluations'/j['pose']/j['name'],'--correspondence-cache-dir',cache,'--only-existing-cache','--allow-unaccepted-model','--repeats','20']
        tasks.append((j['pose']+'_'+j['name'],args))
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures=[pool.submit(run,n,a) for n,a in tasks];results=[f.result() for f in as_completed(futures)]
    save(OUT/'evaluation_jobs.json',results)
if __name__=='__main__':
    if len(sys.argv)>1:train(sys.argv[2],sys.argv[3])
    else:main()
