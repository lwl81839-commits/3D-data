#!/usr/bin/env python3
"""Probe whether detected checkerboards obey the physical corner-cube model.

This is diagnostic-only.  It treats the calibration target as a real cube:

* exactly three visible checkerboard faces;
* three mutually orthogonal physical planes sharing one cube corner;
* one metric scale only: checker square size, supplied as an input
  (25 mm for the current dataset);
* optional integer checkerboard offsets are expressed in square units.

The goal is to separate image evidence ("three boards / VP triangle exists")
from physical evidence ("one 3-D cube pose can explain those corners").
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import time
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import cv2
import numpy as np

from best_calibration import (
    DEFAULT_SQUARE_SIZE_MM,
    MAX_CONFIDENT_INITIAL_PNP_RMSE_PX,
    MAX_CONFIDENT_K1_ABS,
    MAX_CONFIDENT_RMSE_PX,
    MAX_CONFIDENT_FOCAL_DIAG_MULT,
    MIN_CONFIDENT_FOCAL_DIAG_MULT,
    _multi_face_offset_fallback,
    _single_view_k1_fallback,
    _single_view_offset_fallback,
    _single_view_zero_dist_fallback,
)
from calibration_policy import maybe_float
from checkerline_vp_probe import (
    DEFAULT_RESULTS_CSV,
    DEFAULT_STATUSES,
    _filter_rows,
    _first_existing_image_root,
    _load_rows,
    _read_gray,
    axis_observations,
    cluster_axis_observations,
    collect_candidates,
    find_trihedral_combo,
)
from face_detector import (
    _detect_cube_first,
    _detections_have_excessive_overlap,
    _line_quality_for_candidate,
    _normalize_face_axis_order,
    _total_corner_count,
    detect_corner_cube_faces,
)
from three_face_calib import (
    DetectedFace,
    apply_best_face_orientations,
    object_points_for_face,
    standard_three_face_target,
)


DEFAULT_OUT_DIR = Path("batch_results/physical_cube_model_probe")
PHYSICAL_LABELS = ("XY", "XZ", "YZ")


def _clean(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.10g}" if math.isfinite(value) else ""
    return value


def _as_detection_tuple(det: Tuple[Any, Any, Any]) -> Tuple[np.ndarray, Tuple[int, int], str]:
    corners, pattern, label = det
    pat = (int(pattern[0]), int(pattern[1]))
    return corners.reshape(-1, 1, 2).astype(np.float32), pat, str(label or "")


def _quality_for_detections(detections: Sequence[Tuple[np.ndarray, Tuple[int, int], str]]) -> float:
    vals = []
    for corners, pat, _label in detections:
        q = _line_quality_for_candidate(corners, pat)
        if np.isfinite(q):
            vals.append(float(q))
    return float(np.mean(vals)) if vals else float("inf")


def _recovery_action(status: str) -> str:
    return {
        "physical_cube_consistent": (
            "cube geometry is plausible; still require normal calibration quality gates"
        ),
        "physical_offset_candidate": (
            "integer face offset is plausible, but needs intrinsic-prior or manual-truth validation"
        ),
        "physical_pose_ok_calibration_unstable": (
            "three faces are recognized; focus on intrinsics/distortion stability or recapture"
        ),
        "physical_pnp_inconsistent": (
            "reject this candidate grouping or fix face labels/corner ordering"
        ),
        "physical_sparse_faces": (
            "expand the sparse face or recapture; do not promote from sparse evidence"
        ),
        "physical_overlap_reject": (
            "reject overlapping candidate faces; they are not three cube faces"
        ),
        "physical_faces_missing": (
            "find more face evidence or recapture with all three faces visible"
        ),
        "physical_unsolved": (
            "keep blocked; no finite physical cube pose was found"
        ),
    }.get(status, "review physical cube evidence")


def _label_assignments(
    detections: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    try_permutations: bool,
) -> Iterable[List[Tuple[np.ndarray, Tuple[int, int], str]]]:
    base = [_as_detection_tuple(det) for det in detections[:3]]
    if len(base) < 3:
        yield base
        return

    labels = [det[2] for det in base]
    if set(labels) == set(PHYSICAL_LABELS) and len(set(labels)) == 3:
        ordered = sorted(base, key=lambda d: PHYSICAL_LABELS.index(d[2]))
        yield ordered
        if not try_permutations:
            return

    if try_permutations:
        seen = set()
        for perm in itertools.permutations(PHYSICAL_LABELS):
            assigned = [(c, p, label) for (c, p, _old), label in zip(base, perm)]
            key = tuple(label for _c, _p, label in assigned)
            if key in seen:
                continue
            seen.add(key)
            yield sorted(assigned, key=lambda d: PHYSICAL_LABELS.index(d[2]))
    elif not (set(labels) == set(PHYSICAL_LABELS) and len(set(labels)) == 3):
        yield [(c, p, label) for (c, p, _old), label in zip(base, PHYSICAL_LABELS)]


def _make_detected_faces(
    ordered: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    faces,
) -> List[DetectedFace]:
    detected: List[DetectedFace] = []
    for (corners, _pat, _label), face in zip(ordered, faces):
        detected.append(
            DetectedFace(
                image_points=corners.reshape(-1, 1, 2).astype(np.float32),
                object_points=object_points_for_face(face),
                valid=True,
            )
        )
    return detected


def _best_seeded_orientation(
    ordered: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    image_shape: Tuple[int, int],
    square_size_mm: float,
) -> Optional[Dict[str, Any]]:
    h, w = image_shape[:2]
    diag = float(np.hypot(w, h))
    patterns = [pat for _corners, pat, _label in ordered]
    faces = standard_three_face_target(
        square_size_mm,
        9,
        6,
        face_patterns=patterns,
        n_faces=3,
        center_patterns_on_cube=True,
    )
    best = None
    for focal in [0.55 * diag, 0.82 * diag, 1.10 * diag, 1.60 * diag]:
        K = np.array(
            [[focal, 0.0, w / 2.0], [0.0, focal, h / 2.0], [0.0, 0.0, 1.0]],
            dtype=np.float64,
        )
        detected = _make_detected_faces(ordered, faces)
        orientations = apply_best_face_orientations(detected, faces, [0, 1, 2], K, None)
        if not orientations:
            continue
        rmse = float(orientations[0]["rmse"])
        if not np.isfinite(rmse):
            continue
        candidate = {
            "rmse": rmse,
            "K": K,
            "faces": faces,
            "detected": detected,
            "focal_seed": float(focal),
        }
        if best is None or rmse < best["rmse"]:
            best = candidate
    return best


def _solve_pose_per_face_rmse(
    detected: Sequence[DetectedFace],
    K: np.ndarray,
) -> Tuple[float, str]:
    all_obj = np.vstack([df.object_points.reshape(-1, 3) for df in detected]).astype(np.float32)
    all_img = np.vstack([df.image_points.reshape(-1, 2) for df in detected]).astype(np.float32)
    if all_obj.shape[0] < 6:
        return float("inf"), ""
    try:
        ok, rvec, tvec = cv2.solvePnP(
            all_obj, all_img, K.astype(np.float64), None, flags=cv2.SOLVEPNP_ITERATIVE
        )
    except cv2.error:
        return float("inf"), ""
    if not ok:
        return float("inf"), ""
    proj, _ = cv2.projectPoints(
        all_obj.reshape(-1, 1, 3).astype(np.float64),
        rvec,
        tvec,
        K.astype(np.float64),
        np.zeros(5, dtype=np.float64),
    )
    diffs = proj.reshape(-1, 2) - all_img.reshape(-1, 2)
    total = float(np.sqrt(np.mean(np.sum(diffs * diffs, axis=1))))
    parts = []
    offset = 0
    for label, df in zip(PHYSICAL_LABELS, detected):
        n = df.image_points.reshape(-1, 2).shape[0]
        err = diffs[offset : offset + n]
        rmse = float(np.sqrt(np.mean(np.sum(err * err, axis=1))))
        parts.append(f"{label}:{rmse:.2f}")
        offset += n
    return total, ",".join(parts)


def _single_view_fit(
    detected: Sequence[DetectedFace],
    image_shape: Tuple[int, int],
    K_seed: np.ndarray,
) -> Dict[str, Any]:
    h, w = image_shape[:2]
    diag = float(np.hypot(w, h))
    focal_lo = MIN_CONFIDENT_FOCAL_DIAG_MULT * diag
    focal_hi = MAX_CONFIDENT_FOCAL_DIAG_MULT * diag
    all_obj = np.vstack([df.object_points.reshape(-1, 3) for df in detected]).astype(np.float32)
    all_img = np.vstack([df.image_points.reshape(-1, 2) for df in detected]).astype(np.float32)
    out: Dict[str, Any] = {
        "model": "",
        "rmse": None,
        "fx": None,
        "k1": None,
        "passes": False,
    }
    for name, fn in [
        ("single-view-k1", _single_view_k1_fallback),
        ("single-view-zero-dist", _single_view_zero_dist_fallback),
    ]:
        candidate = fn(
            all_obj,
            all_img,
            (w, h),
            K_seed,
            focal_lo,
            focal_hi,
            MAX_CONFIDENT_RMSE_PX,
        )
        if candidate is None:
            continue
        K, dist, _R, _t, rmse = candidate
        k1 = float(dist[0]) if len(dist) else 0.0
        out.update(
            {
                "model": name,
                "rmse": float(rmse),
                "fx": float(K[0, 0]),
                "fy": float(K[1, 1]),
                "cx": float(K[0, 2]),
                "cy": float(K[1, 2]),
                "k1": k1,
                "passes": (
                    np.isfinite(rmse)
                    and float(rmse) <= MAX_CONFIDENT_RMSE_PX
                    and abs(k1) <= MAX_CONFIDENT_K1_ABS
                ),
            }
        )
        return out
    return out


def _offset_fit(
    ordered: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    image_shape: Tuple[int, int],
    K_seed: np.ndarray,
    square_size_mm: float,
) -> Dict[str, Any]:
    h, w = image_shape[:2]
    diag = float(np.hypot(w, h))
    focal_lo = MIN_CONFIDENT_FOCAL_DIAG_MULT * diag
    focal_hi = MAX_CONFIDENT_FOCAL_DIAG_MULT * diag
    image_points_by_face = [
        corners.reshape(-1, 1, 2).astype(np.float32) for corners, _pat, _label in ordered
    ]
    patterns = [pat for _corners, pat, _label in ordered]
    out = {
        "model": "",
        "rmse": None,
        "pnp_rmse": None,
        "fx": None,
        "fy": None,
        "cx": None,
        "cy": None,
        "k1": None,
        "offset": "",
        "passes": False,
    }
    single = _single_view_offset_fallback(
        image_points_by_face,
        patterns,
        (w, h),
        square_size_mm,
        K_seed,
        focal_lo,
        focal_hi,
        MAX_CONFIDENT_RMSE_PX,
        MAX_CONFIDENT_INITIAL_PNP_RMSE_PX,
    )
    if single is not None:
        K, dist, _R, _t, rmse, model, offset, pnp_rmse = single
        k1 = float(dist[0]) if len(dist) else 0.0
        out.update(
            {
                "model": model,
                "rmse": float(rmse),
                "pnp_rmse": float(pnp_rmse),
                "fx": float(K[0, 0]),
                "fy": float(K[1, 1]),
                "cx": float(K[0, 2]),
                "cy": float(K[1, 2]),
                "k1": k1,
                "offset": f"{PHYSICAL_LABELS[int(offset[0])]}=({offset[1]:.0f},{offset[2]:.0f})",
                "passes": True,
            }
        )
        return out

    multi = _multi_face_offset_fallback(
        image_points_by_face,
        patterns,
        (w, h),
        square_size_mm,
        K_seed,
        focal_lo,
        focal_hi,
        MAX_CONFIDENT_RMSE_PX,
    )
    if multi is not None:
        K, dist, _R, _t, rmse, model, offsets, changed, pnp_rmse = multi
        k1 = float(dist[0]) if len(dist) else 0.0
        parts = []
        for idx in changed:
            ox, oy = offsets[idx]
            parts.append(f"{PHYSICAL_LABELS[int(idx)]}=({ox:.0f},{oy:.0f})")
        out.update(
            {
                "model": model,
                "rmse": float(rmse),
                "pnp_rmse": float(pnp_rmse),
                "fx": float(K[0, 0]),
                "fy": float(K[1, 1]),
                "cx": float(K[0, 2]),
                "cy": float(K[1, 2]),
                "k1": k1,
                "offset": ";".join(parts),
                "passes": True,
            }
        )
    return out


def evaluate_physical_source(
    detections: Sequence[Tuple[np.ndarray, Tuple[int, int], str]],
    image_shape: Tuple[int, int],
    source: str,
    try_label_permutations: bool = True,
    square_size_mm: float = DEFAULT_SQUARE_SIZE_MM,
) -> Dict[str, Any]:
    base = [_as_detection_tuple(det) for det in detections or []]
    if len(base) < 3:
        return {
            "source": source,
            "physical_status": "physical_faces_missing",
            "reason": f"only {len(base)}/3 candidate faces",
            "recovery_action": _recovery_action("physical_faces_missing"),
            "n_faces": len(base),
            "n_corners": _total_corner_count(base) if base else 0,
        }

    best = None
    for assigned in _label_assignments(base, try_label_permutations):
        if len(assigned) < 3:
            continue
        ordered = _normalize_face_axis_order(assigned)[:3]
        ordered = sorted(ordered, key=lambda d: PHYSICAL_LABELS.index(d[2]))
        label_string = ";".join(f"{label}:{pat[0]}x{pat[1]}" for _c, pat, label in ordered)
        sparse_count = int(sum(1 for _c, pat, _label in ordered if min(pat) < 5))
        overlap = bool(_detections_have_excessive_overlap(ordered, threshold=0.65))
        n_corners = _total_corner_count(ordered)
        quality = _quality_for_detections(ordered)

        if overlap:
            record = {
                "source": source,
                "physical_status": "physical_overlap_reject",
                "reason": "candidate faces overlap too much to be three cube faces",
                "recovery_action": _recovery_action("physical_overlap_reject"),
                "n_faces": 3,
                "n_corners": n_corners,
                "mean_line_quality": quality,
                "labels_patterns": label_string,
                "sparse_faces": sparse_count,
            }
            score = (4, float("inf"), -n_corners)
        else:
            seeded = _best_seeded_orientation(ordered, image_shape, square_size_mm)
            pnp_rmse = None if seeded is None else float(seeded["rmse"])
            per_face = ""
            fit = {"passes": False, "model": "", "rmse": None, "fx": None, "k1": None}
            offset = {"passes": False, "model": "", "rmse": None, "pnp_rmse": None, "offset": ""}
            if seeded is not None:
                _pose_rmse, per_face = _solve_pose_per_face_rmse(seeded["detected"], seeded["K"])
                fit = _single_view_fit(seeded["detected"], image_shape, seeded["K"])
                offset = _offset_fit(ordered, image_shape, seeded["K"], square_size_mm)

            pnp_ok = pnp_rmse is not None and pnp_rmse <= MAX_CONFIDENT_INITIAL_PNP_RMSE_PX
            if sparse_count > 0:
                status = "physical_sparse_faces"
                reason = "at least one visible face has too few checkerboard rows/cols"
                rank = 4
            elif pnp_ok and fit.get("passes"):
                status = "physical_cube_consistent"
                reason = "three faces fit one orthogonal cube with one input square scale"
                rank = 0
            elif offset.get("passes"):
                status = "physical_offset_candidate"
                reason = (
                    "centered model failed, but an integer checker-square offset "
                    "fits the image geometry; intrinsics still need validation"
                )
                rank = 1
            elif pnp_ok:
                status = "physical_pose_ok_calibration_unstable"
                reason = (
                    "three faces fit an initial orthogonal cube pose, but no accepted "
                    "single-view intrinsics/distortion fit passed the physical gate"
                )
                rank = 2
            elif pnp_rmse is not None and np.isfinite(pnp_rmse):
                status = "physical_pnp_inconsistent"
                reason = (
                    f"three faces exist, but one cube pose gives PnP RMSE {pnp_rmse:.2f}px "
                    f"(limit {MAX_CONFIDENT_INITIAL_PNP_RMSE_PX:.1f}px)"
                )
                rank = 3
            else:
                status = "physical_unsolved"
                reason = "three candidates were found, but no finite physical PnP pose solved"
                rank = 5

            record = {
                "source": source,
                "physical_status": status,
                "reason": reason,
                "recovery_action": _recovery_action(status),
                "n_faces": 3,
                "n_corners": n_corners,
                "mean_line_quality": quality,
                "labels_patterns": label_string,
                "sparse_faces": sparse_count,
                "initial_pnp_rmse": pnp_rmse,
                "per_face_pnp_rmse": per_face,
                "single_view_model": fit.get("model", ""),
                "single_view_rmse": fit.get("rmse"),
                "single_view_fx": fit.get("fx"),
                "single_view_fy": fit.get("fy"),
                "single_view_cx": fit.get("cx"),
                "single_view_cy": fit.get("cy"),
                "single_view_k1": fit.get("k1"),
                "offset_model": offset.get("model", ""),
                "offset_rmse": offset.get("rmse"),
                "offset_pnp_rmse": offset.get("pnp_rmse"),
                "offset_fx": offset.get("fx"),
                "offset_fy": offset.get("fy"),
                "offset_cx": offset.get("cx"),
                "offset_cy": offset.get("cy"),
                "offset_k1": offset.get("k1"),
                "offset": offset.get("offset", ""),
            }
            score = (rank, pnp_rmse if pnp_rmse is not None else float("inf"), -n_corners)

        record["_score"] = score
        if best is None or score < best["_score"]:
            best = record

    if best is None:
        return {
            "source": source,
            "physical_status": "physical_unsolved",
            "reason": "no label assignment could be evaluated",
            "recovery_action": _recovery_action("physical_unsolved"),
            "n_faces": len(base),
            "n_corners": _total_corner_count(base),
        }
    best.pop("_score", None)
    return best


def _vp_combo_detections(
    gray: np.ndarray,
    angle_thresh_deg: float,
    candidate_sources: Sequence[str],
) -> Tuple[List[Tuple[np.ndarray, Tuple[int, int], str]], str]:
    candidates = collect_candidates(gray, candidate_sources)
    observations = axis_observations(candidates, gray.shape)
    clusters = cluster_axis_observations(observations, angle_thresh_deg)
    best = find_trihedral_combo(candidates, observations, gray.shape)
    if best is None:
        return [], f"no VP trihedral combo ({len(candidates)} candidates, {len(clusters)} VP clusters)"

    order_pairs = sorted({item["pair"] for item in best["items"]})
    label_by_pair = dict(zip(order_pairs, PHYSICAL_LABELS))
    detections = []
    for item in best["items"]:
        cand = item["candidate"]
        label = cand["label"] if cand["label"] in PHYSICAL_LABELS else label_by_pair[item["pair"]]
        detections.append((cand["corners"], cand["pattern"], label))
    desc = (
        f"VP combo score={best['score']:.1f}, corners={best['corner_count']}, "
        f"sparse={best['sparse_count']}, fast_pnp={best['fast_pnp_rmse']:.2f}"
    )
    return detections, desc


def _source_rank(status: str) -> int:
    order = {
        "physical_cube_consistent": 0,
        "physical_offset_candidate": 1,
        "physical_pose_ok_calibration_unstable": 2,
        "physical_pnp_inconsistent": 3,
        "physical_sparse_faces": 4,
        "physical_overlap_reject": 5,
        "physical_unsolved": 6,
        "physical_faces_missing": 7,
    }
    return order.get(status, 99)


def probe_one(
    row: Dict[str, Any],
    image_root: Path,
    angle_thresh_deg: float,
    vp_candidate_sources: Sequence[str],
    physical_sources: Sequence[str],
    try_label_permutations: bool,
    square_size_mm: float = DEFAULT_SQUARE_SIZE_MM,
) -> Dict[str, Any]:
    started = time.perf_counter()
    rel_path = str(row.get("rel_path") or f"{row.get('group')}/{row.get('image')}")
    out: Dict[str, Any] = {
        "rel_path": rel_path.replace("\\", "/"),
        "group": row.get("group", ""),
        "image": row.get("image", Path(rel_path).name),
        "baseline_status": row.get("status", ""),
        "baseline_decision": row.get("decision", ""),
        "baseline_recognition_status": row.get("recognition_status", ""),
        "baseline_calibration_status": row.get("calibration_status", ""),
        "baseline_model": row.get("model", ""),
        "baseline_rmse_px": maybe_float(row.get("rmse_px")),
        "cube_area_pct": maybe_float(row.get("cube_area_pct")),
        "physical_status": "error",
        "reason": "",
    }
    try:
        gray = _read_gray(image_root / rel_path)
        source_records = []

        detector_sources = {
            "production_detection": detect_corner_cube_faces,
            "cube_first_direct": _detect_cube_first,
        }
        for source in physical_sources:
            if source not in detector_sources:
                continue
            fn = detector_sources[source]
            try:
                dets = fn(gray, n_faces=3, verbose=False) or []
            except Exception:
                dets = []
            source_records.append(
                evaluate_physical_source(
                    dets,
                    gray.shape,
                    source,
                    try_label_permutations=try_label_permutations,
                    square_size_mm=square_size_mm,
                )
            )

        if "vp_trihedral_combo" in physical_sources:
            vp_dets, vp_desc = _vp_combo_detections(gray, angle_thresh_deg, vp_candidate_sources)
            vp_record = evaluate_physical_source(
                vp_dets,
                gray.shape,
                "vp_trihedral_combo",
                try_label_permutations=try_label_permutations,
                square_size_mm=square_size_mm,
            )
            vp_record["vp_desc"] = vp_desc
            source_records.append(vp_record)

        if not source_records:
            raise RuntimeError("no physical sources selected")

        best = min(
            source_records,
            key=lambda r: (
                _source_rank(str(r.get("physical_status", ""))),
                maybe_float(r.get("initial_pnp_rmse")) or float("inf"),
                -int(r.get("n_corners") or 0),
            ),
        )
        out.update(best)
        out["source_summaries"] = " | ".join(
            f"{r.get('source')}:{r.get('physical_status')}"
            f":pnp={_clean(r.get('initial_pnp_rmse'))}"
            for r in source_records
        )
        out["elapsed_sec"] = time.perf_counter() - started
    except Exception as exc:
        out["physical_status"] = "error"
        out["reason"] = str(exc)
        out["elapsed_sec"] = time.perf_counter() - started
    return out


CSV_FIELDS = [
    "rel_path",
    "group",
    "image",
    "baseline_status",
    "baseline_decision",
    "baseline_recognition_status",
    "baseline_calibration_status",
    "baseline_model",
    "baseline_rmse_px",
    "cube_area_pct",
    "source",
    "physical_status",
    "reason",
    "recovery_action",
    "n_faces",
    "n_corners",
    "mean_line_quality",
    "labels_patterns",
    "sparse_faces",
    "initial_pnp_rmse",
    "per_face_pnp_rmse",
    "single_view_model",
    "single_view_rmse",
    "single_view_fx",
    "single_view_fy",
    "single_view_cx",
    "single_view_cy",
    "single_view_k1",
    "offset_model",
    "offset_rmse",
    "offset_pnp_rmse",
    "offset_fx",
    "offset_fy",
    "offset_cx",
    "offset_cy",
    "offset_k1",
    "offset",
    "vp_desc",
    "source_summaries",
    "elapsed_sec",
]


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: _clean(row.get(k)) for k in CSV_FIELDS})


def write_json(path: Path, rows: List[Dict[str, Any]], summary: Dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8") as f:
        json.dump({"summary": summary, "rows": rows}, f, ensure_ascii=False, indent=2)


def write_markdown(path: Path, rows: List[Dict[str, Any]], summary: Dict[str, Any]) -> None:
    lines = [
        "# Physical Cube Model Probe",
        "",
        f"- Generated: {summary['generated_at']}",
        f"- Images: {summary['images']}",
        f"- Square size: {summary['square_size_mm']:.1f} mm",
        f"- Physical status counts: `{summary['physical_status_counts']}`",
        f"- Baseline status counts: `{summary['baseline_status_counts']}`",
        "",
        "## Interpretation",
        "",
        "This probe asks whether detected image corners can be explained by one "
        "three-face orthogonal cube with a single checker square scale. It does "
        "not change product acceptance.",
        "",
        "## Results",
        "",
        "| image | baseline | cube area % | source | physical status | corners | PnP RMSE | model | reason |",
        "|---|---|---:|---|---|---:|---:|---|---|",
    ]
    for row in rows:
        reason = str(row.get("reason", "")).replace("|", "/")
        if len(reason) > 150:
            reason = reason[:147] + "..."
        lines.append(
            "| {image} | {baseline} | {area} | {source} | {status} | {corners} | {pnp} | {model} | {reason} |".format(
                image=f"{row.get('group','')}/{row.get('image','')}",
                baseline=row.get("baseline_status", ""),
                area=_clean(row.get("cube_area_pct")),
                source=row.get("source", ""),
                status=row.get("physical_status", ""),
                corners=row.get("n_corners", ""),
                pnp=_clean(row.get("initial_pnp_rmse")),
                model=row.get("single_view_model") or row.get("offset_model", ""),
                reason=reason,
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results-csv", type=Path, default=DEFAULT_RESULTS_CSV)
    parser.add_argument("--image-root", type=Path, default=None)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT_DIR)
    parser.add_argument("--status", action="append", default=None)
    parser.add_argument("--group", action="append", default=None)
    parser.add_argument("--rel-path", action="append", default=None)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--all-statuses", action="store_true")
    parser.add_argument("--angle-thresh-deg", type=float, default=18.0)
    parser.add_argument(
        "--square-size-mm",
        type=float,
        default=DEFAULT_SQUARE_SIZE_MM,
        help=(
            "Checkerboard square edge length in millimetres. The current "
            "dataset uses 25.0, but this is an input scale."
        ),
    )
    parser.add_argument(
        "--vp-source",
        action="append",
        default=None,
        choices=["cube_direct", "cube_upscaled", "current_full", "global_pattern"],
        help="Candidate source for VP combo search. Repeat for multiple.",
    )
    parser.add_argument(
        "--physical-source",
        action="append",
        default=None,
        choices=["production_detection", "cube_first_direct", "vp_trihedral_combo"],
        help=(
            "Physical candidate source to evaluate. Repeat for multiple. "
            "Default evaluates production, cube-first, and VP-trihedral sources."
        ),
    )
    parser.add_argument(
        "--no-label-permutations",
        action="store_true",
        help="Trust existing XY/XZ/YZ labels instead of trying all cube-axis permutations.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    image_root = (args.image_root or _first_existing_image_root()).resolve()
    rows = _load_rows(args.results_csv)
    statuses = None if args.all_statuses else (args.status or DEFAULT_STATUSES)
    selected = _filter_rows(rows, statuses, args.group, args.rel_path, args.limit)
    if not selected:
        raise FileNotFoundError("No rows selected for physical cube probe.")

    vp_sources = args.vp_source or ["cube_direct", "global_pattern"]
    physical_sources = args.physical_source or [
        "production_detection",
        "cube_first_direct",
        "vp_trihedral_combo",
    ]
    square_size_mm = float(args.square_size_mm)
    if not math.isfinite(square_size_mm) or square_size_mm <= 0:
        raise ValueError("--square-size-mm must be a positive finite value")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    out_rows = []
    for idx, row in enumerate(selected, 1):
        result = probe_one(
            row,
            image_root,
            args.angle_thresh_deg,
            vp_sources,
            physical_sources,
            try_label_permutations=not args.no_label_permutations,
            square_size_mm=square_size_mm,
        )
        out_rows.append(result)
        print(
            f"[{idx}/{len(selected)}] {result['rel_path']} "
            f"{result['baseline_status']} -> {result['physical_status']} "
            f"via {result.get('source','')} "
            f"(pnp={_clean(result.get('initial_pnp_rmse'))}, "
            f"{result.get('elapsed_sec', 0):.1f}s)"
        )

    summary = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "results_csv": str(args.results_csv),
        "image_root": str(image_root),
        "images": len(out_rows),
        "square_size_mm": square_size_mm,
        "vp_sources": list(vp_sources),
        "physical_sources": list(physical_sources),
        "physical_status_counts": dict(Counter(r.get("physical_status", "") for r in out_rows)),
        "baseline_status_counts": dict(Counter(r.get("baseline_status", "") for r in out_rows)),
    }
    write_csv(args.out_dir / "physical_cube_model_probe.csv", out_rows)
    write_json(args.out_dir / "physical_cube_model_probe.json", out_rows, summary)
    write_markdown(args.out_dir / "physical_cube_model_probe.md", out_rows, summary)
    print(f"Wrote: {args.out_dir / 'physical_cube_model_probe.csv'}")
    print(f"Wrote: {args.out_dir / 'physical_cube_model_probe.json'}")
    print(f"Wrote: {args.out_dir / 'physical_cube_model_probe.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
