"""Use original planar evaluator for all completed count-experiment models."""
from experiment_0820_trical_sample_count import OUT,ROOT,BASE,SPLIT,POSES,read,save,run
from concurrent.futures import ThreadPoolExecutor
import sys,os,runpy
def prepare():
    s=(ROOT/'evaluate_planar_per_pose_controlled.py').read_text(encoding='utf-8')
    s=s.replace('for pose_index, pose in enumerate(POSES):','for pose_index, pose in enumerate(POSES):\n        if pose != __import__("os").environ["COUNT_POSE"]: continue')
    needle='models = {"ours_3d_5_images": (ours_K, ours_dist), "zhang_matlab_20_images": (zhang_K, zhang_dist)}'
    s=s.replace(needle,needle+'\n        for mp in Path('+repr(str(OUT/'models'))+').joinpath(pose).glob("*/trained_camera_model.json"):\n            m = json.loads(mp.read_text(encoding="utf-8"))\n            models[mp.parent.name] = (np.array(m["cameraMatrix"]), np.array(m["distCoeffs"]))')
    s=s.replace('out = validation / "final_test_evaluation" / pose / "planar_2d_controlled"','out = Path('+repr(str(OUT))+') / "planar_evaluations" / pose')
    s=s.replace('validation / "final_test_evaluation" / "PLANAR_2D_CONTROLLED_SUMMARY.json"','Path('+repr(str(OUT))+') / ("planar_summary_" + __import__("os").environ["COUNT_POSE"] + ".json")')
    (OUT/'code/evaluate_planar_count.py').write_text(s,encoding='utf-8')
if __name__=='__main__':
    if len(sys.argv)>1:
        os.environ['COUNT_POSE']=sys.argv[1]
        sys.argv=[str(OUT/'code/evaluate_planar_count.py'),'--split-root',str(SPLIT),'--repeats','20']
        runpy.run_path(sys.argv[0],run_name='__main__')
    else:
        prepare()
        with ThreadPoolExecutor(max_workers=3) as pool:statuses=list(pool.map(lambda pose:run('planar_'+pose,[__file__,pose]),POSES))
        save(OUT/'planar_jobs.json',statuses)
