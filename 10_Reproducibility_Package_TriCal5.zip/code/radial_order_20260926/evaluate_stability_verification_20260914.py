"""Original held-out sets, paired corrected/no-ratio/MATLAB evaluation."""
import os,sys,subprocess,csv,copy
from concurrent.futures import ThreadPoolExecutor
from run_stability_verification_20260914 import ROOT,OUT,BASE,SPLIT,POSES,read,save
def run(job):
    name,args=job;log=OUT/'logs'/('eval_'+name+'.log')
    env=os.environ.copy();env.update(PYTHONPATH=str(ROOT),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONIOENCODING='utf-8')
    with log.open('w',encoding='utf-8') as f:p=subprocess.run([sys.executable,*map(str,args)],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    print(name,p.returncode,flush=True);return dict(name=name,returncode=p.returncode)
def prepare():
    from evaluate_planar_per_pose_controlled import zhang_camera
    with (BASE/'zhang_parameters.csv').open(encoding='utf-8-sig') as f:rows={x.get('Pose',x.get('pose')):x for x in csv.DictReader(f)}
    jobs=[]
    for pose in POSES:
        m=read(OUT/'models'/pose/'ratio_base/trained_camera_model.json');K,d=zhang_camera(rows[pose])
        m=dict(cameraMatrix=K.tolist(),distCoeffs=d.tolist(),source='MATLAB_20_image_reference',is_zhang_reference=True)
        save(OUT/'models'/pose/'zhang_reference/trained_camera_model.json',m)
        for name in ['ratio_base','no_ratio_base','zhang_reference']:
            dest=OUT/'evaluations'/pose/name
            if (dest/'evaluation.json').exists():continue
            args=[ROOT/'evaluate_trained_camera_model.py','--model',OUT/'models'/pose/('ratio_base' if name=='zhang_reference' else name)/'trained_camera_model.json','--images',SPLIT/'test'/pose/'3D','--output-dir',dest,'--correspondence-cache-dir',BASE/'test_correspondence_cache'/pose,'--only-existing-cache','--allow-unaccepted-model','--repeats','20']
            if name=='zhang_reference':args += ['--camera-override-json',OUT/'models'/pose/name/'trained_camera_model.json']
            jobs.append((pose+'_'+name,args))
    s=(ROOT/'evaluate_planar_per_pose_controlled.py').read_text(encoding='utf-8')
    s=s.replace('model_path = validation / "per_pose_models" / pose / "trained_camera_model.json"','model_path = Path('+repr(str(OUT))+') / "models" / pose / "ratio_base" / "trained_camera_model.json"')
    needle='models = {"ours_3d_5_images": (ours_K, ours_dist), "zhang_matlab_20_images": (zhang_K, zhang_dist)}'
    s=s.replace(needle,needle+'\n        nk, nd, _ = camera_from_model(Path('+repr(str(OUT))+') / "models" / pose / "no_ratio_base" / "trained_camera_model.json")\n        models["no_ratio"] = (nk, nd)')
    s=s.replace('out = validation / "final_test_evaluation" / pose / "planar_2d_controlled"','out = Path('+repr(str(OUT))+') / "planar_evaluations" / pose')
    s=s.replace('validation / "final_test_evaluation" / "PLANAR_2D_CONTROLLED_SUMMARY.json"','Path('+repr(str(OUT))+') / "planar_summary.json"')
    p=OUT/'code/evaluate_planar_current.py';p.write_text(s,encoding='utf-8')
    if not (OUT/'planar_summary.json').exists():jobs.append(('planar_all',[p,'--split-root',SPLIT,'--repeats','20']))
    return jobs
if __name__=='__main__':
    jobs=prepare()
    with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,jobs))
    save(OUT/'evaluation_jobs.json',results)
