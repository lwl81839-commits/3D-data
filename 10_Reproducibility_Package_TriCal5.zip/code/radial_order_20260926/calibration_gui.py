#!/usr/bin/env python3
"""
Calibration Tool — Standalone GUI Application
==============================================
Dual-mode: offline (image file) and online (live camera capture).
Select mode via tabs, configure parameters, click Calibrate.
Results displayed in the window, exportable to text file.
"""

import sys, os, time, json, io, traceback, tempfile, textwrap, threading, queue
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import cv2
import numpy as np
from PIL import Image, ImageTk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from best_calibration import BestResult
from calibration_router import calibrate_with_optional_recovery
from calibration_policy import (
    calibration_decision,
    cube_area_policy,
    extract_cube_area_pct,
)
from calibration_manifest_gate import (
    CANONICAL_FACE_PATTERNS,
    stability_gate_for_image,
    stability_hold_message,
)
from trained_camera_model import (
    DISTORTION_MODE_AUTO,
    DISTORTION_MODE_K1,
    DISTORTION_MODE_K1_K2,
    infer_with_camera_model,
    list_training_images,
    load_camera_model,
    train_camera_model,
)


METHOD_PROFILE = "ge2_single_frame_cube_fast"
METHOD_SCOPE = "visible_three_face_cube_ge2_auto"

MODE_SINGLE = "纯单张独立标定（实验基线）"
MODE_TRAIN = "训练少样本相机模型"
MODE_MODEL = "加载模型进行单张标定"

DISTORTION_AUTO_LABEL = "自动比较 k1 与 k1+k2（推荐）"
DISTORTION_K1_K2_LABEL = "强制拟合 k1+k2（诊断）"
DISTORTION_K1_LABEL = "仅拟合 k1（稳定基线）"
DISTORTION_LABEL_TO_VALUE = {
    DISTORTION_AUTO_LABEL: DISTORTION_MODE_AUTO,
    DISTORTION_K1_K2_LABEL: DISTORTION_MODE_K1_K2,
    DISTORTION_K1_LABEL: DISTORTION_MODE_K1,
}

METHOD_PROFILE_ENV = {
    "CALIB_ENABLE_GRID_RECOVERY": "1",
    "CALIB_GRID_RECOVERY_USE_GROUP_ANCHOR": "0",
    "CALIB_GRID_RECOVERY_FOCAL_PX": None,
    "CALIB_GRID_RECOVERY_USE_DIAG_FOCAL_ANCHOR": "1",
    "CALIB_GRID_RECOVERY_FOCAL_ANCHOR_DIAG_MULT": "0.55",
    "CALIB_GRID_RECOVERY_MIN_AREA_PCT": "2.0",
    "CALIB_GRID_RECOVERY_MAX_AREA_PCT": "8.0",
    "CALIB_GRID_RECOVERY_FAILURE_MAX_AREA_PCT": "16.0",
    "CALIB_GRID_RECOVERY_STAGED_ROUTES": "1",
    "CALIB_GRID_RECOVERY_FIRST_SMALL_TARGET": "1",
    "CALIB_GRID_RECOVERY_FIRST_MAX_AREA_PCT": "4.0",
    "CALIB_GRID_RECOVERY_DIRECT_PARTIAL_PRESERVE": "0",
    "CALIB_GRID_RECOVERY_SMALL_TARGET_LONG_FACE_COMPLETION": "1",
    "CALIB_GRID_RECOVERY_SMALL_TARGET_LONG_FACE_MIN_AREA_PCT": "4.0",
    "CALIB_GRID_RECOVERY_SMALL_TARGET_LONG_FACE_MAX_AREA_PCT": "7.0",
    "CALIB_GRID_RECOVERY_SMALL_TARGET_BOUNDARY_STOP_AFTER_GRID_FAIL": "0",
    "CALIB_GRID_RECOVERY_COMPONENT_FACE_QUADS": "1",
    "GRID_PROBE_ENABLE_COMPONENT_FACE_QUADS": "1",
    "CALIB_GRID_RECOVERY_COMPONENT_LABEL_PERMUTATIONS": "1",
    "CALIB_GRID_RECOVERY_DEFER_FINAL_CALIBRATION": "1",
    "CALIB_GRID_RECOVERY_DEFERRED_STOP_PROXY_RMSE_PX": "15.0",
    "CALIB_GRID_RECOVERY_DEFERRED_REQUIRE_LONG_FACE_MAX_AREA_PCT": "4.0",
    "CALIB_GRID_RECOVERY_LOCAL_FIRST_MAX_AREA_PCT": "4.0",
    "CALIB_FAST_AXIS_SIGNATURE_TLS": "1",
    "CALIB_FULL_ZHANG_NFEV_SCALE": "0.35",
    "CALIB_FULL_ZHANG_OPT_TOL": "1e-8",
    "CALIB_LINE_RANSAC_EXHAUSTIVE_MAX_POINTS": "12",
    "CALIB_DISABLE_AREA_RATIO_GATES": "1",
    "CALIB_PRECOMPUTED_CORNERS_SCALE_PRIOR_CANDIDATE": "1",
    "CALIB_STABILITY_MANIFEST": os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "batch_results",
        "fused_three_round_manifest_20260718",
        "final_stability_manifest.json",
    ),
    "CALIB_USE_STABILITY_MANIFEST": "1",
}


def _push_method_profile_env():
    previous = {key: os.environ.get(key) for key in METHOD_PROFILE_ENV}
    for key, value in METHOD_PROFILE_ENV.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value
    return previous


def _restore_env(previous):
    for key, value in previous.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value


def _model_grade_from_model(model_used):
    model = str(model_used or "")
    if model == "vp-only":
        return "diagnostic_only"
    if model.startswith("single-cube-zhang"):
        return "full_single_cube_zhang"
    if model in {"5-param", "k1-only"}:
        return "free_intrinsic_ba"
    if (
        model.startswith("fixed-focal")
        or model.startswith("fixed-intrinsics")
        or model.startswith("single-view-wide-offset-fixed-focal")
    ):
        return "bounded_focal_pose"
    if model.startswith("single-view-wide-offset-focal-scan"):
        return "bounded_focal_scan"
    if model.startswith("single-view"):
        return "bounded_single_view"
    return "accepted_other"


def _method_focal_regularizer(result):
    preflight = getattr(result, "preflight", {}) or {}
    grid = preflight.get("grid_recovery")
    if isinstance(grid, dict):
        source = str(grid.get("grid_recovery_focal_source") or "").strip()
        if source:
            return source
    grid_focal = preflight.get("grid_recovery_focal")
    if isinstance(grid_focal, dict):
        source = str(grid_focal.get("source") or "").strip()
        if source:
            return source
    model = str(getattr(result, "model_used", "") or "")
    if model.startswith("single-cube-zhang"):
        return "none_full_zhang"
    return "none"


def _apply_method_metadata(result):
    preflight = getattr(result, "preflight", None)
    if not isinstance(preflight, dict):
        result.preflight = {}
        preflight = result.preflight
    preflight.update({
        "method_profile": METHOD_PROFILE,
        "method_scope": METHOD_SCOPE,
        "method_focal_regularizer": _method_focal_regularizer(result),
        "model_grade": _model_grade_from_model(getattr(result, "model_used", "")),
    })
    return preflight


def select_manual_rois_dialog(parent, image_path, n_faces):
    """Select face ROIs in original image coordinates."""
    data = np.fromfile(image_path, dtype=np.uint8)
    bgr = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if bgr is None:
        raise FileNotFoundError(f"Cannot decode image: {image_path}")
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    h, w = rgb.shape[:2]

    max_w, max_h = 1100, 720
    scale = min(max_w / max(w, 1), max_h / max(h, 1), 1.0)
    disp_w, disp_h = max(1, int(w * scale)), max(1, int(h * scale))
    if scale < 1.0:
        rgb_disp = cv2.resize(rgb, (disp_w, disp_h), interpolation=cv2.INTER_AREA)
    else:
        rgb_disp = rgb

    dlg = tk.Toplevel(parent)
    dlg.title("Manual Face ROIs")
    dlg.transient(parent)
    dlg.grab_set()
    dlg.result = None

    labels = ["XY top face", "XZ right face", "YZ left face"][:n_faces]
    colors = ["#ff3b30", "#34c759", "#0a84ff"]
    rois = []
    start = [None]
    temp_rect = [None]

    status = tk.StringVar()
    ttk.Label(dlg, textvariable=status, padding=(8, 6)).pack(fill=tk.X)

    canvas = tk.Canvas(dlg, width=disp_w, height=disp_h, cursor="crosshair",
                       highlightthickness=0)
    canvas.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)
    img_tk = ImageTk.PhotoImage(Image.fromarray(rgb_disp))
    canvas.create_image(0, 0, anchor=tk.NW, image=img_tk)
    canvas.image = img_tk

    def update_status():
        if len(rois) >= n_faces:
            status.set("All ROIs selected.")
        else:
            status.set(
                f"Drag a box around {labels[len(rois)]}. "
                "Order: XY top, XZ right, YZ left."
            )

    def draw_saved():
        canvas.delete("roi")
        for i, (x, y, rw, rh) in enumerate(rois):
            x1, y1 = x * scale, y * scale
            x2, y2 = (x + rw) * scale, (y + rh) * scale
            canvas.create_rectangle(
                x1, y1, x2, y2, outline=colors[i], width=3, tags="roi")
            canvas.create_text(
                x1 + 5, y1 + 5, anchor=tk.NW, text=labels[i],
                fill=colors[i], font=("Arial", 12, "bold"), tags="roi")

    def clamp_event(event):
        return (
            max(0, min(float(event.x), float(disp_w - 1))),
            max(0, min(float(event.y), float(disp_h - 1))),
        )

    def on_down(event):
        if len(rois) >= n_faces:
            return
        start[0] = clamp_event(event)
        if temp_rect[0] is not None:
            canvas.delete(temp_rect[0])
            temp_rect[0] = None

    def on_drag(event):
        if start[0] is None or len(rois) >= n_faces:
            return
        x0, y0 = start[0]
        x1, y1 = clamp_event(event)
        if temp_rect[0] is not None:
            canvas.coords(temp_rect[0], x0, y0, x1, y1)
        else:
            temp_rect[0] = canvas.create_rectangle(
                x0, y0, x1, y1, outline=colors[len(rois)],
                width=2, dash=(4, 2))

    def on_up(event):
        if start[0] is None or len(rois) >= n_faces:
            return
        x0, y0 = start[0]
        x1, y1 = clamp_event(event)
        start[0] = None
        if temp_rect[0] is not None:
            canvas.delete(temp_rect[0])
            temp_rect[0] = None
        xa, xb = sorted((x0, x1))
        ya, yb = sorted((y0, y1))
        if xb - xa < 12 or yb - ya < 12:
            update_status()
            return
        ox = int(round(xa / scale))
        oy = int(round(ya / scale))
        ow = int(round((xb - xa) / scale))
        oh = int(round((yb - ya) / scale))
        ox = max(0, min(ox, w - 1))
        oy = max(0, min(oy, h - 1))
        ow = max(1, min(ow, w - ox))
        oh = max(1, min(oh, h - oy))
        rois.append((ox, oy, ow, oh))
        draw_saved()
        update_status()
        if len(rois) >= n_faces:
            dlg.result = list(rois)
            dlg.after(250, dlg.destroy)

    def undo():
        if rois:
            rois.pop()
            draw_saved()
            update_status()

    def cancel():
        dlg.result = None
        dlg.destroy()

    canvas.bind("<ButtonPress-1>", on_down)
    canvas.bind("<B1-Motion>", on_drag)
    canvas.bind("<ButtonRelease-1>", on_up)

    buttons = ttk.Frame(dlg)
    buttons.pack(fill=tk.X, padx=8, pady=(4, 8))
    ttk.Button(buttons, text="Undo", command=undo).pack(side=tk.LEFT)
    ttk.Button(buttons, text="Cancel", command=cancel).pack(side=tk.RIGHT)

    update_status()
    parent.wait_window(dlg)
    return dlg.result


class CalibrationTool:
    """Standalone dual-mode calibration application."""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("立方体单帧标定软件（Python 3.12 修复版）")
        self.root.geometry("920x760")
        self.root.minsize(820, 680)

        self._image_path = None
        self._result = None
        self._manual_rois = []
        self._last_square_size_mm = 25.0

        # Online-mode state
        self._cap = None
        self._captured_frame = None
        self._preview_job = None
        self._camera_index = tk.IntVar(value=0)
        self._preview_label = None
        self._temp_capture_path = None
        self._calibration_thread = None
        self._calibration_queue = queue.Queue()
        self._closing = False
        self._active_result_profile = METHOD_PROFILE

        base_dir = os.path.dirname(os.path.abspath(__file__))
        preferred_development_dir = os.path.join(
            base_dir, "image", "development_30_0.550"
        )
        legacy_development_dir = os.path.join(
            base_dir, "shengkelou", "development_minimal"
        )
        development_dir = (
            preferred_development_dir
            if os.path.isdir(preferred_development_dir)
            else legacy_development_dir
        )
        default_model_path = os.path.join(
            development_dir, "trained_camera_model.json"
        )
        default_mode = MODE_TRAIN
        if os.path.isfile(default_model_path):
            try:
                if load_camera_model(default_model_path).get("accepted", False):
                    default_mode = MODE_MODEL
            except Exception:
                pass
        self._operation_mode_var = tk.StringVar(value=default_mode)
        self._distortion_mode_var = tk.StringVar(value=DISTORTION_AUTO_LABEL)
        self._development_folder_var = tk.StringVar(value=development_dir)
        self._trained_model_path_var = tk.StringVar(value=default_model_path)

        self._build_ui()
        self._on_operation_mode_changed()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ═══════════════════════════════════════════════════════════════
    # UI Construction
    # ═══════════════════════════════════════════════════════════════

    def _build_ui(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('Title.TLabel', font=('Microsoft YaHei', 14, 'bold'))
        style.configure('Heading.TLabel', font=('Microsoft YaHei', 10, 'bold'))
        style.configure('Mono.TLabel', font=('Consolas', 9))

        # Title
        ttk.Label(self.root, text="立方体单帧标定软件",
                  style='Title.TLabel').pack(pady=(15, 5))
        ttk.Label(self.root,
                  text="输入：拍照或上传标定图片 + 棋盘格尺度；输出：OpenCV 参数集",
                  font=('Microsoft YaHei', 9)).pack(pady=(0, 10))

        # ── Input panel ──
        input_frame = ttk.LabelFrame(self.root, text=" 输入 ", padding=10)
        input_frame.pack(fill=tk.X, padx=20, pady=(0, 5))

        source_frame = ttk.Frame(input_frame)
        source_frame.pack(fill=tk.X)

        self._tab_online = ttk.LabelFrame(source_frame, text=" 拍照 ", padding=8)
        self._tab_online.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 6))
        self._tab_offline = ttk.LabelFrame(source_frame, text=" 上传标定图片 ", padding=8)
        self._tab_offline.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(6, 0))

        self._build_online_tab()
        self._build_offline_tab()

        # Shared parameters
        self._build_shared_params(input_frame)

        # Run button
        btn_frame = ttk.Frame(input_frame)
        btn_frame.pack(fill=tk.X, pady=(8, 2))
        self._run_btn = ttk.Button(
            btn_frame, text="执行标定",
            command=self._run_calibration,
        )
        self._run_btn.pack(fill=tk.X)

        self._progress = ttk.Progressbar(input_frame, mode='indeterminate', length=200)

        # ── Results panel ──
        result_frame = ttk.LabelFrame(self.root, text=" 输出：OpenCV 参数集 ", padding=8)
        result_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 5))

        self._result_text = tk.Text(
            result_frame, font=('Consolas', 10), wrap=tk.NONE,
            bg='#1e1e1e', fg='#d4d4d4', insertbackground='white',
            relief=tk.FLAT, state=tk.DISABLED,
        )
        self._result_text.pack(fill=tk.BOTH, expand=True)

        sb = ttk.Scrollbar(self._result_text, command=self._result_text.yview)
        self._result_text.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)

        # ── Bottom bar ──
        bottom = ttk.Frame(self.root)
        bottom.pack(fill=tk.X, padx=20, pady=(0, 10))

        ttk.Button(bottom, text="导出 OpenCV 参数",
                   command=self._export).pack(side=tk.LEFT)

        self._status_var = tk.StringVar(value="请选择拍照或上传标定图片，然后输入棋盘格尺度。")
        ttk.Label(bottom, textvariable=self._status_var,
                  relief=tk.SUNKEN, anchor=tk.W, padding=(8, 2)).pack(
            side=tk.RIGHT, fill=tk.X, expand=True, padx=(10, 0))

    def _build_offline_tab(self):
        f = ttk.Frame(self._tab_offline, padding=(5, 10))
        f.pack(fill=tk.X, expand=True, padx=5)
        self._path_var = tk.StringVar()
        ttk.Button(f, text="选择/上传标定图片", command=self._browse_image).pack(
            fill=tk.X, pady=(0, 6))
        ttk.Entry(f, textvariable=self._path_var).pack(fill=tk.X)

    def _build_online_tab(self):
        pad = ttk.Frame(self._tab_online, padding=(5, 10))
        pad.pack(fill=tk.BOTH, expand=True, padx=5)

        # Camera selector row
        cam_row = ttk.Frame(pad)
        cam_row.pack(fill=tk.X)
        ttk.Label(cam_row, text="摄像头:").pack(side=tk.LEFT)
        self._camera_spin = ttk.Spinbox(cam_row, textvariable=self._camera_index,
                                        from_=0, to=9, width=4)
        self._camera_spin.pack(side=tk.LEFT, padx=4)

        self._open_cam_btn = ttk.Button(cam_row, text="打开",
                                        command=self._open_camera, width=14)
        self._open_cam_btn.pack(side=tk.LEFT, padx=2)
        self._close_cam_btn = ttk.Button(cam_row, text="关闭",
                                         command=self._close_camera, width=14)
        self._close_cam_btn.pack(side=tk.LEFT, padx=2)
        self._close_cam_btn.configure(state=tk.DISABLED)

        self._capture_btn = ttk.Button(cam_row, text="拍照",
                                       command=self._capture_frame, width=16)
        self._capture_btn.pack(side=tk.RIGHT)
        self._capture_btn.configure(state=tk.DISABLED)

        # Preview area
        preview_frame = ttk.LabelFrame(pad, text=" 预览 ", padding=4)
        preview_frame.pack(fill=tk.BOTH, expand=True, pady=(8, 0))
        self._preview_label = ttk.Label(preview_frame)
        self._preview_label.pack(fill=tk.BOTH, expand=True)

    def _build_shared_params(self, parent):
        row1 = ttk.Frame(parent)
        row1.pack(fill=tk.X, pady=(8, 3))
        ttk.Label(row1, text="棋盘格尺度:", width=12).pack(side=tk.LEFT)
        self._square_size_var = tk.StringVar(value=f"{self._last_square_size_mm:g}")
        ttk.Entry(row1, textvariable=self._square_size_var, width=12).pack(
            side=tk.LEFT, padx=4)
        ttk.Label(row1, text="mm").pack(side=tk.LEFT)

        workflow = ttk.LabelFrame(parent, text=" 实验流程 ", padding=7)
        workflow.pack(fill=tk.X, pady=(6, 2))

        mode_row = ttk.Frame(workflow)
        mode_row.pack(fill=tk.X, pady=(0, 4))
        ttk.Label(mode_row, text="运行模式", width=12).pack(side=tk.LEFT)
        self._mode_combo = ttk.Combobox(
            mode_row,
            textvariable=self._operation_mode_var,
            values=(MODE_TRAIN, MODE_MODEL, MODE_SINGLE),
            state="readonly",
        )
        self._mode_combo.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)
        self._mode_combo.bind("<<ComboboxSelected>>", self._on_operation_mode_changed)

        distortion_row = ttk.Frame(workflow)
        distortion_row.pack(fill=tk.X, pady=2)
        ttk.Label(distortion_row, text="畸变模型", width=12).pack(side=tk.LEFT)
        self._distortion_combo = ttk.Combobox(
            distortion_row,
            textvariable=self._distortion_mode_var,
            values=(
                DISTORTION_AUTO_LABEL,
                DISTORTION_K1_K2_LABEL,
                DISTORTION_K1_LABEL,
            ),
            state="readonly",
        )
        self._distortion_combo.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4)

        dev_row = ttk.Frame(workflow)
        dev_row.pack(fill=tk.X, pady=2)
        ttk.Label(dev_row, text="开发图片", width=12).pack(side=tk.LEFT)
        ttk.Entry(dev_row, textvariable=self._development_folder_var).pack(
            side=tk.LEFT, fill=tk.X, expand=True, padx=4
        )
        ttk.Button(dev_row, text="选择文件夹", command=self._browse_development_folder).pack(
            side=tk.LEFT
        )

        model_row = ttk.Frame(workflow)
        model_row.pack(fill=tk.X, pady=2)
        ttk.Label(model_row, text="模型文件", width=12).pack(side=tk.LEFT)
        ttk.Entry(model_row, textvariable=self._trained_model_path_var).pack(
            side=tk.LEFT, fill=tk.X, expand=True, padx=4
        )
        ttk.Button(model_row, text="选择路径", command=self._browse_model_path).pack(
            side=tk.LEFT
        )

        # Keep algorithmic controls fixed behind the simplified panel.
        face_patterns = list(CANONICAL_FACE_PATTERNS)
        (ca, ra), (cb, rb), (cc, rc) = face_patterns
        self._face_mode_var = tk.StringVar(value="3")
        self._ca_var = tk.StringVar(value=str(ca))
        self._ra_var = tk.StringVar(value=str(ra))
        self._cb_var = tk.StringVar(value=str(cb))
        self._rb_var = tk.StringVar(value=str(rb))
        self._cc_var = tk.StringVar(value=str(cc))
        self._rc_var = tk.StringVar(value=str(rc))
        self._k1only_var = tk.BooleanVar(value=False)
        self._roi_status_var = tk.StringVar(value="Auto detection")
        self._fb_frame = ttk.Frame(parent)
        self._fc_frame = ttk.Frame(parent)

    def _browse_development_folder(self):
        path = filedialog.askdirectory(
            parent=self.root,
            title="选择不含张正友标定图的开发图片文件夹",
            initialdir=self._development_folder_var.get() or None,
        )
        if path:
            self._development_folder_var.set(path)
            current_model = self._trained_model_path_var.get().strip()
            if not current_model or os.path.basename(current_model) == "trained_camera_model.json":
                self._trained_model_path_var.set(
                    os.path.join(path, "trained_camera_model.json")
                )

    def _browse_model_path(self):
        mode = self._operation_mode_var.get()
        current = self._trained_model_path_var.get().strip()
        initialdir = os.path.dirname(current) if current else None
        if mode == MODE_TRAIN:
            path = filedialog.asksaveasfilename(
                parent=self.root,
                title="选择训练模型保存位置",
                initialdir=initialdir,
                initialfile=os.path.basename(current) or "trained_camera_model.json",
                defaultextension=".json",
                filetypes=[("JSON model", "*.json"), ("All files", "*.*")],
            )
        else:
            path = filedialog.askopenfilename(
                parent=self.root,
                title="选择已经训练好的相机模型",
                initialdir=initialdir,
                filetypes=[("JSON model", "*.json"), ("All files", "*.*")],
            )
        if path:
            self._trained_model_path_var.set(path)

    def _on_operation_mode_changed(self, event=None):
        mode = self._operation_mode_var.get()
        if mode == MODE_TRAIN:
            self._run_btn.configure(text="训练并保存相机模型")
            self._status_var.set("训练仅使用开发文件夹中的三面立方体图片，不读取张正友结果。")
        elif mode == MODE_MODEL:
            self._run_btn.configure(text="加载模型并标定当前单张图片")
            self._status_var.set("请选择一张未参与开发的新图片，并加载冻结模型。")
        else:
            self._run_btn.configure(text="执行纯单张独立标定")
            self._status_var.set("纯单张模式不使用开发模型，用作实验基线。")


    # ═══════════════════════════════════════════════════════════════
    # Camera (Online mode)
    # ═══════════════════════════════════════════════════════════════

    def _open_camera(self):
        idx = self._camera_index.get()
        self._cap = cv2.VideoCapture(idx)
        if not self._cap.isOpened():
            self._cap = None
            messagebox.showerror("Camera Error",
                                 f"无法打开摄像头 {idx}。\n请检查连接，或尝试其它编号。")
            return
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self._open_cam_btn.configure(state=tk.DISABLED)
        self._close_cam_btn.configure(state=tk.NORMAL)
        self._capture_btn.configure(state=tk.NORMAL)
        self._status_var.set(f"摄像头 {idx} 已打开，请对准标定物后拍照。")
        self._update_preview()

    def _close_camera(self):
        if self._preview_job:
            self.root.after_cancel(self._preview_job)
            self._preview_job = None
        if self._cap:
            self._cap.release()
            self._cap = None
        self._captured_frame = None
        if self._preview_label:
            self._preview_label.configure(image='')
            self._preview_label.image = None
        self._open_cam_btn.configure(state=tk.NORMAL)
        self._close_cam_btn.configure(state=tk.DISABLED)
        self._capture_btn.configure(state=tk.DISABLED)
        self._status_var.set("摄像头已关闭。")

    def _update_preview(self):
        if self._cap is None or not self._cap.isOpened():
            self._preview_job = None
            return
        ret, frame = self._cap.read()
        if not ret or frame is None:
            self._status_var.set("读取画面失败，请检查摄像头。")
            self._preview_job = self.root.after(33, self._update_preview)
            return
        try:
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w = frame_rgb.shape[:2]
            # Scale to fit preview width ~440 px
            target_w = 440
            if w > target_w:
                ratio = target_w / w
                new_w = target_w
                new_h = int(h * ratio)
                frame_rgb = cv2.resize(frame_rgb, (new_w, new_h),
                                       interpolation=cv2.INTER_AREA)
            img_pil = Image.fromarray(frame_rgb)
            img_tk = ImageTk.PhotoImage(img_pil)
            self._preview_label.configure(image=img_tk)
            self._preview_label.image = img_tk
        except Exception:
            pass
        self._preview_job = self.root.after(33, self._update_preview)

    def _capture_frame(self):
        if self._cap is None or not self._cap.isOpened():
            messagebox.showwarning("Warning", "请先打开摄像头。")
            return
        ret, frame = self._cap.read()
        if not ret or frame is None:
            messagebox.showerror("Capture Error", "从摄像头读取图像失败。")
            return
        self._captured_frame = frame.copy()

        # Clean old temp file
        if self._temp_capture_path and os.path.exists(self._temp_capture_path):
            try:
                os.unlink(self._temp_capture_path)
            except OSError:
                pass

        fd, path = tempfile.mkstemp(suffix='.png', prefix='calib_capture_')
        os.close(fd)
        cv2.imwrite(path, frame)
        self._temp_capture_path = path
        self._image_path = path
        self._path_var.set(f"[拍照] {frame.shape[1]}x{frame.shape[0]}")
        self._clear_manual_rois()
        self._status_var.set("已拍照，可执行标定。"
                             f"{frame.shape[1]}x{frame.shape[0]}")

    def _on_tab_changed(self, event):
        return

    # ═══════════════════════════════════════════════════════════════
    # Calibration
    # ═══════════════════════════════════════════════════════════════

    def _browse_image(self):
        path = filedialog.askopenfilename(
            parent=self.root,
            title="Select calibration image",
            filetypes=[("Images", "*.jpg *.jpeg *.png *.bmp *.tiff"),
                       ("All files", "*.*")],
        )
        if path:
            self._image_path = path
            self._path_var.set(path)
            self._clear_manual_rois()
            self._status_var.set(f"已上传：{os.path.basename(path)}")

    def _select_manual_rois(self):
        if not self._image_path or not os.path.exists(self._image_path):
            messagebox.showwarning("Warning", "Please select or capture an image first.")
            return
        try:
            n_faces = int(self._face_mode_var.get())
        except ValueError:
            messagebox.showerror("Error", "Invalid face mode.")
            return
        try:
            rois = select_manual_rois_dialog(self.root, self._image_path, n_faces)
        except Exception as exc:
            messagebox.showerror("ROI Error", str(exc))
            return
        if rois:
            self._manual_rois = list(rois)
            self._roi_status_var.set(f"Manual: {len(rois)} face ROI(s)")
            self._status_var.set("Manual ROIs selected.")

    def _clear_manual_rois(self):
        self._manual_rois = []
        if hasattr(self, "_roi_status_var"):
            self._roi_status_var.set("Auto detection")

    def _on_face_mode_changed(self, event=None):
        self._clear_manual_rois()
        n = int(self._face_mode_var.get())
        state_b = tk.NORMAL if n >= 2 else tk.DISABLED
        state_c = tk.NORMAL if n >= 3 else tk.DISABLED
        for child in self._fb_frame.winfo_children():
            try:
                child.configure(state=state_b)
            except Exception:
                pass
        for child in self._fc_frame.winfo_children():
            try:
                child.configure(state=state_c)
            except Exception:
                pass

    def _run_calibration(self):
        try:
            square = float(self._square_size_var.get())
            if not np.isfinite(square) or square <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("参数错误", "棋盘格方格尺寸必须是大于 0 的数字，单位为 mm。")
            return

        self._last_square_size_mm = square
        mode = self._operation_mode_var.get()

        if mode == MODE_TRAIN:
            development_folder = self._development_folder_var.get().strip()
            model_path = self._trained_model_path_var.get().strip()
            try:
                image_paths = list_training_images(development_folder)
            except Exception as exc:
                messagebox.showerror("开发集错误", str(exc))
                return
            if len(image_paths) < 4:
                messagebox.showerror(
                    "开发集不足",
                    f"开发文件夹只找到 {len(image_paths)} 张图片，至少需要 4 张。",
                )
                return
            if not model_path:
                messagebox.showerror("模型路径错误", "请选择训练模型的保存路径。")
                return
            distortion_model = DISTORTION_LABEL_TO_VALUE.get(
                self._distortion_mode_var.get(), DISTORTION_MODE_AUTO
            )
            self._begin_background_operation(
                self._training_worker,
                (image_paths, square, model_path, distortion_model),
                f"开始训练：共 {len(image_paths)} 张开发图片；不会读取张正友参数。",
            )
            return

        if not self._image_path:
            messagebox.showwarning("缺少图片", "请先拍照或选择一张标定图片。")
            return
        if not os.path.exists(self._image_path):
            messagebox.showerror("图片错误", f"找不到图片：\n{self._image_path}")
            return

        if mode == MODE_MODEL:
            model_path = self._trained_model_path_var.get().strip()
            if not model_path or not os.path.isfile(model_path):
                messagebox.showerror("模型错误", f"找不到已经训练好的模型：\n{model_path}")
                return
            self._begin_background_operation(
                self._trained_model_worker,
                (self._image_path, square, model_path),
                "正在加载冻结模型，并求解当前单张图片的位姿...",
            )
            return

        if os.path.isfile(self._trained_model_path_var.get().strip()):
            continue_baseline = messagebox.askyesno(
                "当前选择的是纯单张实验基线",
                "该模式不会加载已经训练好的模型，也不会使用冻结模型的三面关联修复。\n\n"
                "如果你的目的是测试少样本模型，请选择“否”，然后把运行模式改为“加载模型进行单张标定”。\n\n"
                "是否仍要运行纯单张实验基线？",
            )
            if not continue_baseline:
                self._operation_mode_var.set(MODE_MODEL)
                self._on_operation_mode_changed()
                return

        n_faces = 3
        face_patterns = list(CANONICAL_FACE_PATTERNS)
        manual_rois = None
        self._begin_background_operation(
            self._calibration_worker,
            (self._image_path, square, n_faces, face_patterns, manual_rois),
            "正在执行纯单张独立标定...",
        )

    def _begin_background_operation(self, target, args, status):
        if self._calibration_thread is not None:
            messagebox.showwarning("任务进行中", "请等待当前任务完成。")
            return
        self._run_btn.configure(state=tk.DISABLED)
        self._progress.pack(fill=tk.X, pady=(4, 0))
        self._progress.start(10)
        self._status_var.set(status)
        self._result = None
        self._active_result_profile = METHOD_PROFILE
        self._calibration_thread = threading.Thread(
            target=target,
            args=args,
            name="calibration-worker",
            daemon=True,
        )
        self._calibration_thread.start()
        self.root.after(100, self._poll_calibration_queue)

    def _training_worker(self, image_paths, square, model_path, distortion_model):
        try:
            t0 = time.time()
            previous = _push_method_profile_env()
            try:
                # Never reuse precomputed/audited calibration results in training.
                os.environ["CALIB_USE_STABILITY_MANIFEST"] = "0"
                model = train_camera_model(
                    image_paths,
                    square,
                    model_path,
                    distortion_model=distortion_model,
                    progress=lambda message: self._calibration_queue.put(
                        ("progress", message, None)
                    ),
                )
            finally:
                _restore_env(previous)
            self._calibration_queue.put(
                ("training_success", (model, model_path), time.time() - t0)
            )
        except Exception as exc:
            self._calibration_queue.put(("error", exc, traceback.format_exc()))

    def _trained_model_worker(self, image_path, square, model_path):
        try:
            t0 = time.time()
            model = load_camera_model(model_path)
            if not model.get("accepted", False):
                raise RuntimeError("该模型没有通过训练质量门限，不能用于正式单张标定。")
            previous = _push_method_profile_env()
            try:
                os.environ["CALIB_USE_STABILITY_MANIFEST"] = "0"
                result = infer_with_camera_model(
                    image_path,
                    model,
                    square_size_mm=square,
                    correspondence_cache_dir=os.path.join(
                        os.path.dirname(os.path.abspath(model_path)),
                        ".trihedral_correspondence_cache",
                    ),
                    progress=lambda message: self._calibration_queue.put(
                        ("progress", message, None)
                    ),
                )
            finally:
                _restore_env(previous)
            result.preflight["trained_model_path"] = os.path.abspath(model_path)
            result.elapsed_sec = time.time() - t0
            self._calibration_queue.put(("model_success", result, time.time() - t0))
        except Exception as exc:
            self._calibration_queue.put(("error", exc, traceback.format_exc()))

    def _calibration_worker(
        self, image_path, square, n_faces, face_patterns, manual_rois
    ):
        """Run the CPU-heavy pipeline without blocking Tk's event loop."""
        try:
            t0 = time.time()
            gate = None
            corners_path = None
            manifest_focal_px = None
            ca, ra = face_patterns[0]
            env_previous = _push_method_profile_env()
            try:
                use_stability_manifest = os.environ.get(
                    "CALIB_USE_STABILITY_MANIFEST", "1"
                ).strip().lower() not in {"0", "false", "no", "off"}
                if (
                    use_stability_manifest
                    and manual_rois is None
                    and n_faces == 3
                    and list(face_patterns) == list(CANONICAL_FACE_PATTERNS)
                ):
                    gate = stability_gate_for_image(image_path)
                    if gate.matched and not gate.accepted:
                        raise RuntimeError(stability_hold_message(gate))
                    if gate.available_for_calibration:
                        corners_path = str(gate.corners_path)
                        face_patterns = gate.face_patterns or face_patterns
                        manifest_focal_px = gate.focal_px

                result = calibrate_with_optional_recovery(
                    image_path, square, ca, ra,
                    face_patterns=face_patterns,
                    n_faces=n_faces,
                    k1_only=False,
                    focal_px=manifest_focal_px,
                    verbose=False,
                    corners_path=corners_path,
                    manual_face_rois=manual_rois,
                )
            finally:
                _restore_env(env_previous)

            if gate is not None and gate.available_for_calibration:
                result.warnings.append(
                    "Used final single-frame stability manifest before calibration: "
                    f"{gate.rel_path}, decision={gate.final_decision}."
                )
                result.preflight.update({
                    "recognition_status": "stability_manifest_pass",
                    "recognition_label": "STABILITY MANIFEST PASS",
                    "recognition_summary": (
                        "This image was accepted by the final single-frame "
                        "baseline plus stress-audit manifest."
                    ),
                    "calibration_status": "final_manifest_calibration",
                    "calibration_label": "FINAL MANIFEST CALIBRATION",
                    "calibration_summary": (
                        "Calibration used verified three-face corners from the "
                        "accepted stability manifest."
                    ),
                    "can_attempt_calibration": True,
                    "can_accept_automatic": True,
                })
            _apply_method_metadata(result)
            self._calibration_queue.put(("success", result, time.time() - t0))
        except Exception as exc:
            self._calibration_queue.put(
                ("error", exc, traceback.format_exc())
            )

    def _poll_calibration_queue(self):
        if self._closing:
            return
        try:
            kind, payload, detail = self._calibration_queue.get_nowait()
        except queue.Empty:
            if self._calibration_thread is not None:
                self.root.after(100, self._poll_calibration_queue)
            return

        if kind == "progress":
            self._status_var.set(str(payload))
            self.root.after(100, self._poll_calibration_queue)
            return

        self._calibration_thread = None
        if kind in {"success", "model_success"}:
            self._finish_calibration_success(payload, detail)
        elif kind == "training_success":
            model, model_path = payload
            self._finish_training_success(model, model_path, detail)
        else:
            self._finish_calibration_error(payload, detail)

    def _finish_calibration_success(self, result, elapsed):
        self._result = result
        self._active_result_profile = (result.preflight or {}).get(
            "method_profile", METHOD_PROFILE
        )
        self._display_result(elapsed)
        decision = calibration_decision("ok", result.cube_area_pct)
        self._status_var.set(
            f"{decision['label']}。OpenCV 参数已生成；RMSE={result.rmse:.4f}px，"
            f"耗时={elapsed:.2f}s"
        )
        evidence_level = (result.preflight or {}).get("inference_evidence_level")
        if evidence_level == "single_face_pose_only":
            messagebox.showwarning(
                "单面证据：不能计为三面盲测通过",
                "冻结的相机内参已正常加载并输出，但当前图片只有一个面通过刚体一致性筛选。\n\n"
                "本次结果只能用于单面位姿和重投影诊断，不能登记为三面立方体盲测成功。",
            )
        self._finish_calibration_ui()

    def _finish_training_success(self, model, model_path, elapsed):
        self._result = None
        self._trained_model_path_var.set(os.path.abspath(model_path))
        self._display_training_result(model, model_path, elapsed)
        accepted = bool(model.get("accepted", False))
        if accepted:
            self._operation_mode_var.set(MODE_MODEL)
            self._on_operation_mode_changed()
            self._status_var.set(
                "训练完成并通过质量门限。现在可切换到“加载模型进行单张标定”。"
            )
            messagebox.showinfo(
                "训练完成",
                "模型已通过内部质量门限并保存。\n\n"
                "下一步应选择未参与开发的新图片进行盲测。",
            )
        else:
            self._status_var.set("模型已保存，但未通过训练质量门限，禁止正式推理。")
            messagebox.showwarning(
                "训练未通过质量门限",
                "模型文件已保留用于诊断，但不能用于正式单张标定。\n"
                "请查看各开发图片的重投影误差。",
            )
        self._finish_calibration_ui()

    def _finish_calibration_error(self, exc, traceback_text):
        info = self._classify_calibration_failure(exc)
        self._display_failure(info, str(exc), traceback_text)
        if info["known"]:
            messagebox.showwarning(
                info["title"],
                f"{info['summary']}\n\n{info['action']}",
            )
        else:
            messagebox.showerror(
                "Calibration Failed",
                f"{exc}\n\nSee details below.",
            )
        self._status_var.set(
            f"{info['decision']['label']} / {info['status']}: result not accepted."
        )
        self._finish_calibration_ui()

    def _finish_calibration_ui(self):
        self._run_btn.configure(state=tk.NORMAL)
        self._progress.stop()
        self._progress.pack_forget()

    # ═══════════════════════════════════════════════════════════════
    # Results display
    # ═══════════════════════════════════════════════════════════════

    def _display_result(self, elapsed):
        r = self._result
        rvec, _ = cv2.Rodrigues(np.asarray(r.R, dtype=float))
        camera_matrix = np.asarray(r.K, dtype=float)
        dist_coeffs = np.asarray(r.dist, dtype=float).reshape(1, -1)
        tvec = np.asarray(r.t, dtype=float).reshape(3, 1)
        rotation = np.asarray(r.R, dtype=float)

        preflight = getattr(r, "preflight", {}) or {}
        profile = preflight.get("method_profile", self._active_result_profile)
        lines = [
            "OpenCV 参数集",
            "=" * 72,
            f"squareSize_mm = {self._last_square_size_mm:g}",
            f"reprojectionRMSE_px = {float(r.rmse):.6f}",
            f"elapsed_s = {elapsed:.3f}",
            f"model_used = {getattr(r, 'model_used', '')}",
            f"method_profile = {profile}",
            f"no_zhang_reference_used = {preflight.get('no_zhang_reference_used_in_training', 'not_applicable')}",
            f"distortion_model_selected = {preflight.get('distortion_model_selected', 'not_applicable')}",
            f"inference_evidence_level = {preflight.get('inference_evidence_level', 'not_applicable')}",
            f"geometric_faces_used = {preflight.get('geometric_faces_used', 'not_applicable')}",
            f"geometric_face_inliers = {preflight.get('geometric_face_inliers', 'not_applicable')}",
            f"geometric_face_grid_spans = {preflight.get('geometric_face_grid_spans', 'not_applicable')}",
            f"minimum_face_inliers = {preflight.get('minimum_face_inliers', 'not_applicable')}",
            f"minimum_face_grid_span = {preflight.get('minimum_face_grid_span', 'not_applicable')}",
            f"face_grid_association_repaired = {preflight.get('face_grid_association_repaired', 'not_applicable')}",
            f"face_grid_association_RMSE_px = {preflight.get('face_grid_association_rmse_px', 'not_applicable')}",
            f"face_boundary_error_px = {preflight.get('face_boundary_error_px', 'not_applicable')}",
            f"face_checker_photometric_error = {preflight.get('face_checker_photometric_error', 'not_applicable')}",
            f"face_grid_association_score_gap = {preflight.get('face_grid_association_score_gap', 'not_applicable')}",
            f"face_boundary_used_for_absolute_grid_index = {preflight.get('face_boundary_used_for_absolute_grid_index', 'not_applicable')}",
            f"three_face_blind_test_pass = {preflight.get('three_face_blind_test_pass', 'not_applicable')}",
            "",
            "cameraMatrix =",
            np.array2string(camera_matrix, precision=10, suppress_small=False),
            "",
            "distCoeffs =  # OpenCV order: [k1, k2, p1, p2, k3]",
            np.array2string(dist_coeffs, precision=12, suppress_small=False),
            "",
            "rvec =",
            np.array2string(rvec, precision=12, suppress_small=False),
            "",
            "tvec_mm =",
            np.array2string(tvec, precision=12, suppress_small=False),
            "",
            "rotationMatrix =",
            np.array2string(rotation, precision=12, suppress_small=False),
        ]
        if preflight.get("trained_model_path"):
            lines.extend(["", f"trained_model = {preflight['trained_model_path']}"])
        self._set_text('\n'.join(lines))

    def _display_training_result(self, model, model_path, elapsed):
        K = np.asarray(model["cameraMatrix"], dtype=float)
        dist = np.asarray(model["distCoeffs"], dtype=float).reshape(1, -1)
        diagnostics = model.get("diagnostics", {})
        cross_validation = model.get("cross_validation", {})
        candidates = model.get("candidate_comparison", {})
        lines = [
            "少样本相机模型训练结果",
            "=" * 72,
            f"accepted = {bool(model.get('accepted', False))}",
            f"elapsed_s = {elapsed:.3f}",
            f"training_method = {model.get('training_method')}",
            f"training_scope = {model.get('training_scope')}",
            f"no_zhang_reference_used = {model.get('no_zhang_reference_used')}",
            f"distortion_model_requested = {model.get('distortion_model_requested')}",
            f"distortion_model_selected = {model.get('distortion_model_selected')}",
            f"selection_reason = {model.get('distortion_model_selection_reason')}",
            f"training_images_requested = {model.get('training_images_requested')}",
            f"training_images_used = {model.get('training_images_used')}",
            f"training_multi_face_images = {model.get('training_multi_face_images')}",
            f"training_single_face_auxiliary_images = {model.get('training_single_face_auxiliary_images')}",
            f"training_images_failed = {len(model.get('training_images_failed', []))}",
            f"joint_reprojectionRMSE_px = {diagnostics.get('joint_reprojection_rmse_px')}",
            f"median_image_RMSE_px = {diagnostics.get('median_image_rmse_px')}",
            f"optimizer_success = {diagnostics.get('optimizer_success')}",
            f"validation_strategy = {cross_validation.get('strategy')}",
            f"validation_successful_folds = {cross_validation.get('successful_folds')}/{cross_validation.get('folds')}",
            f"validation_median_RMSE_px = {cross_validation.get('median_reprojection_rmse_px')}",
            f"validation_max_RMSE_px = {cross_validation.get('max_reprojection_rmse_px')}",
            "",
            "cameraMatrix =",
            np.array2string(K, precision=10, suppress_small=False),
            "",
            "distCoeffs =  # OpenCV order: [k1, k2, p1, p2, k3]",
            np.array2string(dist, precision=12, suppress_small=False),
            "",
            f"model_file = {os.path.abspath(model_path)}",
            "",
            "说明：张正友参数没有进入训练；它只能在盲测完成后用于最终评价。",
        ]
        if candidates:
            lines.extend(["", "候选畸变模型比较："])
            for key in (DISTORTION_MODE_K1, DISTORTION_MODE_K1_K2):
                candidate = candidates.get(key)
                if not candidate:
                    continue
                cv = candidate.get("cross_validation", {})
                coeffs = candidate.get("distCoeffs", [])
                stability = candidate.get("k2_stability", {})
                lines.append(
                    f"- {candidate.get('label')}: accepted={candidate.get('accepted')}, "
                    f"k1={coeffs[0] if len(coeffs) > 0 else None}, "
                    f"k2={coeffs[1] if len(coeffs) > 1 else None}, "
                    f"LOO median={cv.get('median_reprojection_rmse_px')}, "
                    f"LOO max={cv.get('max_reprojection_rmse_px')}, "
                    f"k2_stable={stability.get('stable')}"
                )
        failures = model.get("training_images_failed", [])
        if failures:
            lines.extend(["", "未能提取的开发图片："])
            for item in failures:
                lines.append(f"- {item.get('image')}: {item.get('error')}")
        self._set_text("\n".join(lines))

    @staticmethod
    def _classify_calibration_failure(exc):
        message = str(exc).strip()
        cube_area = extract_cube_area_pct(message)

        def make_info(known, status, title, summary, action):
            decision = calibration_decision(status, cube_area)
            return {
                "known": known,
                "status": status,
                "title": title,
                "summary": summary,
                "action": action,
                "decision": decision,
                "cube_area_pct": cube_area,
            }

        rules = [
            (
                ("该模型没有通过训练质量门限", "trained model did not pass"),
                "TRAINED MODEL REJECTED",
                "训练模型未通过质量门限",
                "已加载的模型文件属于诊断结果，尚未通过训练和留一验证门限。",
                "返回训练模式，检查开发图片提取失败和候选模型验证误差；不要绕过门限用于正式单张标定。",
            ),
            (
                ("Rigid three-face consensus retained fewer than",),
                "INSUFFICIENT CONSENSUS FACES",
                "三面刚体一致性不足",
                "棋盘格局部角点已经找到，但满足同一立方体投影关系的可靠面数量不足。",
                "如果使用冻结模型，一面可靠时只输出单面位姿诊断；要计为三面盲测通过，仍需三面都通过一致性检查。",
            ),
            (
                ("Not cube target:",),
                "not_cube_target",
                "Not cube target",
                "This image does not contain the required three-visible-face cube/cuboid calibration target.",
                "Do not calibrate this image with the cube method and do not fall back to planar Zhang calibration. Use a valid cube target with three visible checkerboard faces.",
            ),
            (
                ("Range boundary:", "Calibration target too small"),
                "RANGE BOUNDARY",
                "Range boundary",
                "The cube is too small in this image for the current reliable area-ratio gate.",
                "Use this image as the calibration distance/area boundary, or recapture with a larger cube footprint.",
            ),
            (
                ("Low-confidence calibration:",),
                "LOW CONFIDENCE",
                "Low-confidence calibration",
                "The cube is visible, but the single-frame geometry is not stable enough to accept.",
                "Do not use this result as final calibration. Recapture with clearer three-face geometry or a larger target image area.",
            ),
            (
                ("Stability manifest hold:",),
                "LOW CONFIDENCE",
                "Stability manifest hold",
                "This image is inside the audited set but did not pass the final single-frame stability gate.",
                "Do not run or accept calibration for this frame. Recapture or improve candidate recovery before releasing it.",
            ),
            (
                ("Partial-face geometry boundary:",),
                "PARTIAL FACE BOUNDARY",
                "Partial-face geometry boundary",
                "At least one visible face contains too little reliable checkerboard geometry.",
                "Recapture so every used face has enough visible inner corners; the current gate requires at least 5 in both directions.",
            ),
            (
                ("Insufficient visible cube faces:",),
                "INSUFFICIENT FACES",
                "Insufficient visible cube faces",
                "The cube footprint is large enough, but fewer than three usable faces were found.",
                "Recapture with all three cube faces visible. The whole-image fallback is intentionally refused to avoid duplicate-face calibration.",
            ),
            (
                ("No calibration target detected:",),
                "TARGET NOT DETECTED",
                "Target not detected",
                "No usable cube-face checkerboard was detected.",
                "Check focus, lighting, occlusion, and target visibility before recapturing.",
            ),
            (
                ("Manual ROI", "manual_face_rois"),
                "ROI CHECK FAILED",
                "Manual ROI check failed",
                "The selected ROI does not match the expected face pattern.",
                "Select the face ROI again in XY, XZ, YZ order, or switch back to automatic detection.",
            ),
        ]
        for needles, status, title, summary, action in rules:
            if any(needle in message for needle in needles):
                return make_info(True, status, title, summary, action)
        return make_info(
            False,
            "CALIBRATION FAILED",
            "Calibration failed",
            "The calibration run stopped with an unexpected error.",
            "Review the technical details below, then retry or check the input image.",
        )

    def _display_failure(self, info, message, traceback_text):
        def wrapped(text, width=86):
            if not text:
                return [""]
            return textwrap.wrap(text, width=width) or [text]

        lines = [
            "CALIBRATION RESULT: NOT ACCEPTED",
            "=" * 78,
            f"Decision: {info['decision']['label']} ({info['decision']['decision']})",
            f"Status: {info['status']}",
            f"Area band: {info['decision']['area_band']}",
            f"Area policy: {info['decision']['area_policy']}",
            f"Method profile: {self._active_result_profile}",
            f"Method scope: {METHOD_SCOPE}",
            "Recognition judgment: "
            f"{info['decision'].get('recognition_label', '')} "
            f"({info['decision'].get('recognition_status', '')})",
            "Calibration gate: "
            f"{info['decision'].get('calibration_label', '')} "
            f"({info['decision'].get('calibration_status', '')})",
            "",
            "Reason:",
        ]
        if info.get("cube_area_pct") is not None:
            lines.insert(4, f"Cube area: {info['cube_area_pct']:.3f}%")
        for line in wrapped(info["summary"]):
            lines.append(f"  {line}")
        lines.append("")
        lines.append("Algorithm detail:")
        for line in wrapped(message):
            lines.append(f"  {line}")
        lines.append("")
        lines.append("Next action:")
        for line in wrapped(info["action"]):
            lines.append(f"  {line}")
        if not info["known"]:
            lines.extend([
                "",
                "Technical traceback:",
                traceback_text,
            ])
        self._set_text("\n".join(lines))

    def _export(self):
        if self._result is None:
            messagebox.showwarning("Warning", "请先执行标定。")
            return

        path = filedialog.asksaveasfilename(
            title="导出 OpenCV 参数",
            defaultextension=".json",
            filetypes=[("JSON", "*.json"), ("Text", "*.txt"), ("All", "*.*")],
        )
        if not path:
            return

        r = self._result
        rvec, _ = cv2.Rodrigues(np.asarray(r.R, dtype=float))
        out = {
            'cameraMatrix': np.asarray(r.K, dtype=float).tolist(),
            'distCoeffs': np.asarray(r.dist, dtype=float).reshape(-1).tolist(),
            'distCoeffsOrder': 'k1,k2,p1,p2,k3',
            'rvec': rvec.reshape(-1).tolist(),
            'tvec': np.asarray(r.t, dtype=float).reshape(-1).tolist(),
            'tvecUnit': 'mm',
            'rotationMatrix': np.asarray(r.R, dtype=float).tolist(),
            'reprojectionRMSE': float(r.rmse),
            'squareSizeMm': float(self._last_square_size_mm),
            'modelUsed': str(getattr(r, 'model_used', '')),
            'methodProfile': (getattr(r, 'preflight', {}) or {}).get(
                'method_profile', self._active_result_profile
            ),
            'trainedModelPath': (getattr(r, 'preflight', {}) or {}).get(
                'trained_model_path'
            ),
            'noZhangReferenceUsedInTraining': (
                (getattr(r, 'preflight', {}) or {}).get(
                    'no_zhang_reference_used_in_training'
                )
            ),
        }

        if path.endswith('.json'):
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(out, f, indent=2)
        else:
            with open(path, 'w', encoding='utf-8') as f:
                for k, v in out.items():
                    f.write(f"{k}: {v}\n")

        self._status_var.set(f"已导出：{path}")
        messagebox.showinfo("Export", f"结果已保存到：\n{path}")

    def _set_text(self, text):
        self._result_text.configure(state=tk.NORMAL)
        self._result_text.delete(1.0, tk.END)
        self._result_text.insert(tk.END, text)
        self._result_text.configure(state=tk.DISABLED)

    def _on_close(self):
        self._closing = True
        self._close_camera()
        if self._temp_capture_path and os.path.exists(self._temp_capture_path):
            try:
                os.unlink(self._temp_capture_path)
            except OSError:
                pass
        self.root.destroy()

    def run(self):
        self.root.mainloop()


def _run_batch_cli(argv):
    """Run the packaged app in batch mode without opening the GUI."""
    forwarded = list(argv)
    if getattr(sys, "frozen", False):
        # A windowed PyInstaller executable cannot be used as ``python -c`` by
        # the batch subprocess runner, so keep packaged batch runs in-process.
        if "--mode" in forwarded:
            idx = forwarded.index("--mode")
            if idx + 1 < len(forwarded):
                forwarded[idx + 1] = "inprocess"
            else:
                forwarded.append("inprocess")
        else:
            forwarded.extend(["--mode", "inprocess"])
    if "--mode" not in forwarded:
        forwarded.extend(["--mode", "inprocess"])
    if "--workers" not in forwarded:
        forwarded.extend(["--workers", "1"])

    import batch_evaluate_current

    old_argv = sys.argv[:]
    try:
        sys.argv = [old_argv[0]] + forwarded
        return batch_evaluate_current.main()
    except Exception:
        import traceback
        with open("batch_cli_error.log", "w", encoding="utf-8") as f:
            traceback.print_exc(file=f)
        return 1
    finally:
        sys.argv = old_argv


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--batch":
        exit_code = int(_run_batch_cli(sys.argv[2:]) or 0)
        os._exit(exit_code)
    CalibrationTool().run()
