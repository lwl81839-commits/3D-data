from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output/precision_fix_20260912'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
reg=read(OUT/'regression.json')
lines=['# 2026-09-12 实现修正与几何诊断','',
'## 已应用的主代码修正','',
'trained_camera_model.py 的径向精修统一 object_groups、image_groups、K 为 float64，并在模型诊断中记录 projection_residual_dtype。不改原有软约束、门限或物理尺寸。旧源码备份为 trained_camera_model.before.py；原正式模型未覆盖，需重新训练才能得到修正后参数。','',
'合成残差导数回归与五组原五张训练图回归均通过；新主代码训练参数与此前独立双精度分支一致至预设数值容差 1e-5（非准确率门限）。逐配置差异与源码 SHA-256 见 regression.json。此前两版本测试结果保留在 ../experiment_0820_precision_test/，本轮没有冒充重跑这些已验证测试。','',
'## 几何检查','',
'45_0.827 的五张训练图共有 15 个原始面，其中当前局部平面训练接口实际接收 7 个面；6 个面因点数不等于完整矩形格点数而属于稀疏面。该统计不等于最终几何筛选接收面数。',
'','训练图 t_3_34 的正面：单应性内点率约 89.5%，内点 RMSE 约 0.89 px，但全部点单应性 RMSE 约 39.83 px。旧局部观测函数虽然计算 RANSAC 内点掩码，仍将所有点送到精修。简单启用稀疏观测会把部分明显不一致的对应点一并带入。','',
'独立平面拟合与整体刚体拟合的差别还提示面间坐标/装配关系需要核查；这些只是全点拟合诊断，不能作为盲测准确率或唯一根因证明。逐图数据和三张可视化见 geometry_450827/。','',
'## 内点掩码传递对照（未部署）','',
'两个分支均使用双精度、相同原五张图、相同稀疏坐标支持、相同先验及原测试图。区别是是否将 RANSAC 内点掩码同时应用于二维和三维对应点。内点选择依据训练几何，不使用张正友参数。','',
'|配置|分支|训练完成|通过原门限|训练 RMSE/px|2D 留出 RMSE 中位数/px|3D 留出 RMSE 中位数/px|','|---|---|---|---|---|---|---|']
rows=[];r=OUT/'inlier_transfer'
for pose in read(r/'protocol.json')['poses']:
    for variant in ['sparse_all','sparse_inliers']:
        d=r/'models'/pose/variant;st=read(d/'status.json');row=dict(pose=pose,variant=variant,**st)
        if st['completed']:
            m=read(d/'trained_camera_model.json');e=read(r/'evaluations'/pose/variant/'evaluation.json')['summary'];p=read(r/'planar_evaluations'/pose/'evaluation.json')['summaries'][variant]
            row.update(train_rmse=m['diagnostics']['joint_reprojection_rmse_px'],planar_rmse=p['holdout_rmse_px']['median'],cuboid_rmse=e['holdout_error_px']['median'],K=m['cameraMatrix'],dist=m['distCoeffs'],faces=e['face_evidence_histogram'])
        def f(k):return '-' if k not in row else f'{row[k]:.4f}'
        lines.append(f"|{pose}|{variant}|{st['completed']}|{st.get('accepted',False)}|{f('train_rmse')}|{f('planar_rmse')}|{f('cuboid_rmse')}|")
        rows.append(row)
lines+=['','配对结果：内点传递后四个配置的三维中位数略降，一个略升；二维三个配置降低、两个升高，未显示普遍明显改善。45_0.827 三维由 3.5886 降至 3.5756 px，主要误差仍在。15_0.528 与 45_1.155 的两个分支均未通过原发布门限，因此不部署稀疏接收分支。','',
'拒绝模型只作诊断，不转换为正式通过；所有失败保留。2D 汇总为逐图试验中位数的图间中位数，3D 为所有留出试验中位数。测试图可只有一个有效面，指标不能一概解释为三面测量精度。反复使用现有测试图定位实现问题后，新方案的最终独立验证还需要未用于调整的数据。','',
'## 边界与后续','',
'主程序只部署已验证的精度修正。稀疏点/内点传递分支仍需结合各配置验证及点序核查决定，不自动替换主模型；样本数曲线必须注明实现版本，不把旧版本曲线与新版本混用。论文和0909迁移实验未改动。']
(r/'analysis.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False),encoding='utf-8')
(OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps(rows,indent=2))
