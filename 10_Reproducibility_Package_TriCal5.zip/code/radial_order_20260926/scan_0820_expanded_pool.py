from pathlib import Path
import json,hashlib,sys
import cv2,numpy as np
from ablate_0820_ratio_prior import ROOT,BASE,SPLIT,POSES
from trained_camera_model import extract_correspondences,_sample_training_face_count
OUT=ROOT/'output/experiment_0820_stability_curve'
OUT.mkdir(exist_ok=True)
def main():
    cv2.setNumThreads(1)
    for pose in POSES:
        rows=[]
        files=sorted(list((SPLIT/'train'/pose/'3D').glob('*.jpg'))+list((SPLIT/'test'/pose/'3D').glob('*.jpg')))
        for path in files:
            digest=hashlib.sha256(path.read_bytes()).hexdigest()
            cache=next(iter((BASE/'per_pose_models'/pose/'.trihedral_correspondence_cache').glob(digest+'_sq25_*.npz')),None)
            if cache is None:cache=next(iter((BASE/'test_correspondence_cache'/pose).glob(digest+'_sq25_*.npz')),None)
            row=dict(image=str(path),sha256=digest,old_role='train' if 'train' in path.parts else 'test',cache=str(cache) if cache else None)
            try:
                if cache is None:raise RuntimeError('No existing cache; no new detection performed')
                cv2.setRNGSeed(20260912)
                s=extract_correspondences(str(path),25,correspondence_cache_path=str(cache),minimum_usable_faces=2)
                count=_sample_training_face_count(s)
                pts=np.asarray(s.image_points).reshape(-1,2);wh=np.array(s.image_size);radius=np.linalg.norm((pts-wh/2)/np.linalg.norm(wh/2),axis=1)
                row.update(passed=count>=2,faces=count,inliers=len(pts),center=(pts.mean(axis=0)/wh).tolist(),radius_p95=float(np.percentile(radius,95)),face_counts=list(s.face_point_counts),image_size=list(s.image_size))
            except Exception as e:row.update(passed=False,error=str(e))
            rows.append(row)
        (OUT/(pose+'_pool.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
        print(pose,'eligible',sum(r['passed'] for r in rows),'/',len(rows),flush=True)
if __name__=='__main__':main()
