"""Frozen-model face versus rigid diagnostics; not an accuracy benchmark."""
from pathlib import Path
import hashlib,json
import numpy as np,cv2
from ablate_0820_ratio_prior import ROOT,BASE,SPLIT
from trained_camera_model import _load_cache,_local_face_observations
OUT=ROOT/'output/precision_fix_20260912/geometry_450827'
POSE='45_0.827'
OUT.mkdir(parents=True,exist_ok=True)
cv2.setNumThreads(1);cv2.setRNGSeed(20260912)
m=json.loads((ROOT/'output/experiment_0820_precision_test/models'/POSE/'float64/trained_camera_model.json').read_text())
K=np.array(m['cameraMatrix']);dist=np.array(m['distCoeffs'])
def solve(obj,img):
    obj=np.asarray(obj,float);img=np.asarray(img,float)
    if len(obj)<6:return None
    candidates=[]
    for flag in [cv2.SOLVEPNP_ITERATIVE,cv2.SOLVEPNP_EPNP]:
        try:
            ok,rv,tv=cv2.solvePnP(obj,img,K,dist,flags=flag)
            if not ok:continue
            rv,tv=cv2.solvePnPRefineLM(obj,img,K,dist,rv,tv)
            R=cv2.Rodrigues(rv)[0]
            if np.min((obj@R.T+tv.reshape(1,3))[:,2])<=0:continue
            pred=cv2.projectPoints(obj,rv,tv,K,dist)[0].reshape(-1,2)
            err=np.linalg.norm(pred-img,axis=1)
            candidates.append(dict(rmse=float(np.sqrt(np.mean(err**2))),pred=pred,errors=err))
        except cv2.error:pass
    return min(candidates,key=lambda x:x['rmse']) if candidates else None
rows=[];visuals=[]
for role in ['train','test']:
    cache_dir=BASE/('per_pose_models' if role=='train' else 'test_correspondence_cache')/POSE
    if role=='train':cache_dir/='.trihedral_correspondence_cache'
    for p in sorted((SPLIT/role/POSE/'3D').glob('*.jpg')):
        h=hashlib.sha256(p.read_bytes()).hexdigest();caches=list(cache_dir.glob(h+'_sq25_*.npz'))
        if not caches:rows.append(dict(image=str(p),role=role,error='no cached correspondences'));continue
        sample=_load_cache(str(caches[0]),str(p),None);bounds=np.cumsum([0,*sample.face_point_counts])
        used={o['face_index'] for o in _local_face_observations([sample],25)}
        rigid=solve(sample.object_points,sample.image_points)
        row=dict(image=str(p),role=role,sha256=h,faces=[],raw_rigid_rmse=None if rigid is None else rigid['rmse'])
        for f in range(3):
            a,b=bounds[f:f+2];obj=sample.object_points[a:b];img=sample.image_points[a:b];cols,nrows=sample.face_patterns[f]
            fr=dict(face=f,points=len(img),pattern=[int(cols),int(nrows)],used_by_local_training=f in used,
                    image_points_px=img.tolist(),object_points_mm=obj.tolist())
            varying=np.where(np.ptp(obj,axis=0)>1e-5)[0] if len(obj) else []
            physical=solve(obj,img)
            fr['independent_face_pose_rmse']=None if physical is None else physical['rmse']
            if rigid is not None and len(img):fr['rigid_face_rmse']=float(np.sqrt(np.mean(rigid['errors'][a:b]**2)))
            if len(varying)==2 and len(img)>=4:
                local=obj[:,varying];H,mask=cv2.findHomography(local,img,cv2.RANSAC,2.)
                if H is not None:
                    hp=cv2.perspectiveTransform(local.reshape(-1,1,2),H).reshape(-1,2);err=np.linalg.norm(hp-img,axis=1);keep=mask.ravel().astype(bool)
                    fr.update(homography_inlier_fraction=float(keep.mean()),homography_all_rmse=float(np.sqrt(np.mean(err**2))),homography_inlier_rmse=float(np.sqrt(np.mean(err[keep]**2))))
                cells=(local-local.min(axis=0))/25
                fr.update(lattice_error=float(np.max(np.abs(cells-np.rint(cells)))),unique_points=len(np.unique(np.round(cells,5),axis=0)))
            if len(img)==cols*nrows:
                canonical=np.array([[25*c,25*r,0] for r in range(nrows) for c in range(cols)],float)
                can=solve(canonical,img);fr['canonical_order_pose_rmse']=None if can is None else can['rmse']
            row['faces'].append(fr)
        rows.append(row)
        if rigid is not None:visuals.append((row,sample,rigid))
(OUT/'per_image_diagnostics.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False),encoding='utf-8')
# Show three largest raw rigid discrepancies, selected as diagnostic examples only.
for row,sample,rigid in sorted(visuals,key=lambda x:x[2]['rmse'],reverse=True)[:3]:
    im=cv2.imdecode(np.fromfile(row['image'],np.uint8),cv2.IMREAD_COLOR)
    panels=[im.copy(),im.copy()];bounds=np.cumsum([0,*sample.face_point_counts]);colors=[(0,190,255),(255,160,0),(80,255,80)]
    for f in range(3):
        a,b=bounds[f:f+2];img=sample.image_points[a:b];obj=sample.object_points[a:b];face=solve(obj,img)
        for panel,pred in [(panels[0],rigid['pred'][a:b]),(panels[1],None if face is None else face['pred'])]:
            for j,pt in enumerate(img):
                xy=tuple(np.rint(pt).astype(int));cv2.circle(panel,xy,4,colors[f],1)
                if pred is not None and np.all(np.abs(pred[j])<100000):
                    q=tuple(np.rint(pred[j]).astype(int));cv2.line(panel,xy,q,(0,0,255),1);cv2.drawMarker(panel,q,(0,0,255),cv2.MARKER_CROSS,5,1)
                # Indexed object coordinates identify point order without filling holes.
                if j%3==0:cv2.putText(panel,f'{f}:{j}',xy,cv2.FONT_HERSHEY_SIMPLEX,.35,colors[f],1)
    for panel,title in zip(panels,['RAW shared rigid pose (all cached points)','Independent pose per face (same fixed K/dist)']):
        cv2.rectangle(panel,(0,0),(panel.shape[1],50),(0,0,0),-1);cv2.putText(panel,title,(15,33),cv2.FONT_HERSHEY_SIMPLEX,.8,(255,255,255),2)
    canvas=np.hstack(panels);name=Path(row['image']).stem+'_diagnostic.jpg';cv2.imencode('.jpg',canvas)[1].tofile(str(OUT/name));row['visualization']=name
summary={}
for role in ['train','test']:
    rr=[r for r in rows if r['role']==role and 'faces' in r];ff=[f for r in rr for f in r['faces']]
    def med(key):
        v=[f[key] for f in ff if f.get(key) is not None];return None if not v else float(np.median(v))
    summary[role]=dict(images=len(rr),faces=len(ff),local_faces_used=sum(f['used_by_local_training'] for f in ff),sparse_faces=int(sum(f['points']!=np.prod(f['pattern']) for f in ff)),median_independent_face_rmse=med('independent_face_pose_rmse'),median_rigid_face_rmse=med('rigid_face_rmse'),median_homography_inlier_rmse=med('homography_inlier_rmse'))
(OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
lines=['# 45_0.827 几何诊断','', '使用冻结双精度模型；读取现有原始角点缓存，不重新检测、不修改点位。独立面/整体刚体均在所有对应点上拟合，属于定位故障的拟合残差，不是留出准确率。原正式流程还包含几何筛选，不能把这里的原始全点残差当成原流程最终误差。','', '逐点索引、每面点数、格点检查、单应性内点率与两类拟合残差见 per_image_diagnostics.json。三张示例按原始整体刚体残差由大到小选取，故不是随机代表样本。彩色圈为观测，红十字为投影，红线为残差；左图共享外参，右图各面独立外参。','',json.dumps(summary,indent=2),'', '单应性残差小但固定内参独立面残差大，可能涉及相机模型/角点系统偏差；独立面残差小但共享刚体残差大，提示面间坐标、索引或装配几何问题。仅凭这两个量不能唯一确定原因，不能自动更改物理尺寸。']
(OUT/'REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps(summary,indent=2))
