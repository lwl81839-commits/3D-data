"""Few-shot, physics-constrained camera model training and single-image use.

The trainer never reads a Zhang/reference calibration.  It extracts the
three-face checker correspondences from each development image, then fits one
shared intrinsic/distortion model and one independent pose per image.  At
runtime the saved camera model is fixed and a new image is used only to
recover its pose and to report reprojection quality.

This is intentionally a small-data geometric model rather than a raw-image
neural network: eight highly correlated real images are not enough to train a
general CNN without severe overfitting.
"""

from __future__ import annotations

import hashlib
import itertools
import json
import math
import os
import tempfile
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable, Optional

import cv2
import numpy as np
from scipy.optimize import least_squares

from best_calibration import BestResult, _cube_camera_pose_metrics, calibrate_best
from calibration_manifest_gate import CANONICAL_FACE_PATTERNS
from checker_plumbline_distortion import estimate_checker_plumbline_distortion
from three_face_calib import (
    FaceDefinition, object_points_for_face, standard_three_face_target,
)


MODEL_SCHEMA = "trihedral-few-shot-camera-model/v10"
CORRESPONDENCE_CACHE_TAG = "measured_cuboid_corner_offsets_face7x6_v1"
DISTORTION_MODE_AUTO = "auto"
DISTORTION_MODE_K1 = "k1"
DISTORTION_MODE_K1_K2 = "k1_k2"
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
ProgressCallback = Optional[Callable[[str], None]]

# Reference-free weak camera priors.  These constants are generic physical
# regularizers; they must not be tuned against a Zhang/reference result.
ASPECT_LOG_RATIO_SIGMA = 0.01
PRINCIPAL_POINT_PRIOR_SIGMA_SHORT_SIDE_FRACTION = 0.015
PRINCIPAL_POINT_MAX_OFFSET_SHORT_SIDE_FRACTION = 0.055
RADIAL_MONOTONIC_HINGE_SIGMA = 0.05
# Camera-specific empirical coefficient prior requested for this experiment:
# |k2| <= 0.5 |k1|.  It is implemented as a soft hinge rather than a hard
# bound, so sufficiently strong corner evidence can still override it.
K2_TO_K1_COEFFICIENT_SOFT_LIMIT = 0.50
K2_COEFFICIENT_HINGE_SIGMA = 0.001
K2_OPTIMIZATION_BOUND = 0.75
MIN_FACE_INLIERS = 12
MIN_GRID_ROWS = 4
MIN_GRID_COLS = 4
MIN_TOTAL_INLIERS_BY_FACE_COUNT = {1: 16, 2: 30, 3: 40}

# Measured target geometry, millimetres.  Corner-lattice offsets are preferred
# over the incomplete outer black/white print boundary.
TARGET_EXTENTS_MM = (320.0, 220.0, 240.0)  # X, Y, Z
TARGET_SQUARE_SIZE_MM = 25.0
TARGET_CORNER_OFFSETS_MM = {
    # Axis distances from each physical face edge to the corresponding
    # outermost inner-corner row/column.  Recovered by constrained least
    # squares from the four measured vertex-to-grid-vertex distances.
    "xoy": {"left": 54.330, "top": 47.545, "right": 65.670, "bottom": 47.455},
    "xoz": {"left": 54.668, "top": 51.962, "right": 65.332, "bottom": 63.038},
    "yoz": {"left": 21.747, "top": 59.608, "right": 48.253, "bottom": 55.392},
}


def _measured_cuboid_faces(square_size_mm: float) -> list[FaceDefinition]:
    """Return the measured 320x220x240 mm three-face target."""
    square = float(square_size_mm)
    if not math.isclose(
        square, TARGET_SQUARE_SIZE_MM, rel_tol=0.0, abs_tol=0.25
    ):
        raise ValueError(
            "The measured cuboid profile requires 25 mm checker squares; "
            f"received {square:g} mm"
        )
    ex = np.array([1.0, 0.0, 0.0])
    ey = np.array([0.0, 1.0, 0.0])
    ez = np.array([0.0, 0.0, 1.0])
    # Each origin is the grid corner nearest the marked common cuboid vertex:
    # XOY left-bottom, XOZ left-top, YOZ right-top.
    top = TARGET_CORNER_OFFSETS_MM["xoy"]
    front = TARGET_CORNER_OFFSETS_MM["xoz"]
    side = TARGET_CORNER_OFFSETS_MM["yoz"]
    return [
        FaceDefinition(
            pattern_size=(9, 6), square_size=square,
            axis_x=ex, axis_y=ey,
            origin_3d=np.array([top["left"], top["bottom"], 0.0]),
        ),
        FaceDefinition(
            pattern_size=(9, 6), square_size=square,
            axis_x=ex, axis_y=ez,
            origin_3d=np.array([front["left"], 0.0, front["top"]]),
        ),
        FaceDefinition(
            pattern_size=(7, 6), square_size=square,
            axis_x=ey, axis_y=ez,
            origin_3d=np.array([0.0, side["right"], side["top"]]),
        ),
    ]


@dataclass
class CorrespondenceSet:
    image_path: str
    image_size: tuple[int, int]
    image_points: np.ndarray
    object_points: np.ndarray
    K_seed: np.ndarray
    dist_seed: np.ndarray
    R_seed: np.ndarray
    t_seed: np.ndarray
    cube_area_pct: Optional[float]
    corner_quality: Optional[float]
    source_model: str
    raw_corner_count: Optional[int] = None
    geometric_inlier_count: Optional[int] = None
    face_point_counts: Optional[tuple[int, int, int]] = None
    face_inlier_counts: Optional[tuple[int, int, int]] = None
    face_grid_spans: Optional[
        tuple[tuple[int, int], tuple[int, int], tuple[int, int]]
    ] = None
    face_patterns: Optional[tuple[tuple[int, int], tuple[int, int], tuple[int, int]]] = None
    association_repaired: bool = False
    association_rmse_px: Optional[float] = None
    association_boundary_error_px: Optional[float] = None
    association_photometric_error: Optional[float] = None
    association_score_gap: Optional[float] = None


def list_training_images(folder: str | os.PathLike[str]) -> list[str]:
    root = Path(folder)
    if not root.is_dir():
        raise FileNotFoundError(f"Development image folder not found: {root}")
    images = [
        str(path.resolve())
        for path in root.rglob("*")
        if path.is_file()
        and path.suffix.lower() in IMAGE_SUFFIXES
        and path.parent.name.lower() != "zhang"
        and "zhang" not in {part.lower() for part in path.parts}
    ]
    return sorted(images)


def _sample_usable_face_count(sample: CorrespondenceSet) -> int:
    counts = sample.face_inlier_counts or (0, 0, 0)
    spans = sample.face_grid_spans or ((0, 0), (0, 0), (0, 0))
    return int(sum(
        counts[i] >= MIN_FACE_INLIERS
        and spans[i][0] >= MIN_GRID_COLS
        and spans[i][1] >= MIN_GRID_ROWS
        for i in range(3)
    ))


def _sample_training_face_count(sample: CorrespondenceSet) -> int:
    """Count planar faces usable for multi-image training evidence.

    Formal single-image acceptance keeps the 4x4 rule above.  During
    development training an elongated 6x3 patch with at least 18 inliers is
    also informative because its absolute board offset is not needed by the
    local homography constraints.
    """
    counts = sample.face_inlier_counts or (0, 0, 0)
    spans = sample.face_grid_spans or ((0, 0), (0, 0), (0, 0))
    usable = 0
    for count, (cols, rows) in zip(counts, spans):
        strict = (
            count >= MIN_FACE_INLIERS
            and cols >= MIN_GRID_COLS
            and rows >= MIN_GRID_ROWS
        )
        elongated = (
            count >= 18
            and min(cols, rows) >= 3
            and max(cols, rows) >= 6
        )
        usable += int(strict or elongated)
    return usable


def _sha256(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _notify(callback: ProgressCallback, message: str) -> None:
    if callback is not None:
        callback(message)


def _load_cache(
    cache_path: str,
    image_path: str,
    result: Optional[BestResult],
) -> CorrespondenceSet:
    with np.load(cache_path, allow_pickle=True) as cache:
        image_groups = [
            np.asarray(group, dtype=np.float64).reshape(-1, 2)
            for group in cache["image_points"]
        ]
        object_groups = [
            np.asarray(group, dtype=np.float64).reshape(-1, 3)
            for group in cache["object_points"]
        ]
        if len(image_groups) != 3 or len(object_groups) != 3:
            raise RuntimeError("Training extraction did not produce three checker faces")
        if any(len(a) != len(b) for a, b in zip(image_groups, object_groups)):
            raise RuntimeError("Training extraction produced mismatched 2-D/3-D points")
        image_points = np.vstack(image_groups)
        object_points = np.vstack(object_groups)
        image_size_arr = np.asarray(cache["image_size"], dtype=int).reshape(2)
        face_patterns_arr = np.asarray(cache["patterns"], dtype=int).reshape(3, 2)
        K_seed = np.asarray(cache["K_seed"], dtype=np.float64).reshape(3, 3)
        dist_seed = np.asarray(cache["dist_seed"], dtype=np.float64).reshape(-1)
        R_seed = np.asarray(cache["R_seed"], dtype=np.float64).reshape(3, 3)
        t_seed = np.asarray(cache["t_seed"], dtype=np.float64).reshape(3)
    if dist_seed.size < 5:
        dist_seed = np.pad(dist_seed, (0, 5 - dist_seed.size))
    return CorrespondenceSet(
        image_path=str(Path(image_path).resolve()),
        image_size=(int(image_size_arr[0]), int(image_size_arr[1])),
        image_points=image_points,
        object_points=object_points,
        K_seed=K_seed,
        dist_seed=dist_seed[:5],
        R_seed=R_seed,
        t_seed=t_seed,
        cube_area_pct=(
            None if result is None or result.cube_area_pct is None
            else float(result.cube_area_pct)
        ),
        corner_quality=(
            None
            if result is None or not np.isfinite(float(result.corner_quality))
            else float(result.corner_quality)
        ),
        source_model="three_face_correspondences_only",
        raw_corner_count=int(len(image_points)),
        face_point_counts=tuple(int(len(group)) for group in image_groups),
        face_patterns=tuple(
            tuple(int(v) for v in pattern)
            for pattern in face_patterns_arr
        ),
    )


def _recover_full_third_face_sb(
    sample: CorrespondenceSet,
    image_path: str,
    square_size_mm: float,
) -> CorrespondenceSet:
    """Legacy compatibility hook; do not replace measured YOZ correspondences.

    The measured YOZ lattice is 7x6, but its outer squares are incomplete.
    Existing observed corners remain authoritative; no synthetic/full-grid
    replacement is allowed.
    """
    return sample
    # Retained below only as unreachable historical implementation context.
    counts = sample.face_point_counts
    if counts is None or len(counts) != 3 or sum(counts) != len(sample.image_points):
        return sample
    try:
        encoded = np.fromfile(image_path, dtype=np.uint8)
        image = cv2.imdecode(encoded, cv2.IMREAD_GRAYSCALE)
    except Exception:
        return sample
    if image is None:
        return sample
    pts = np.asarray(sample.image_points, dtype=np.float64).reshape(-1, 2)
    x0, y0 = np.min(pts, axis=0)
    x1, y1 = np.max(pts, axis=0)
    span_x, span_y = max(x1 - x0, 40.0), max(y1 - y0, 40.0)
    x0 = max(0, int(round(x0 - 0.22 * span_x)))
    x1 = min(image.shape[1], int(round(x1 + 0.22 * span_x)))
    y0 = max(0, int(round(y0 - 0.22 * span_y)))
    y1 = min(image.shape[0], int(round(y1 + 0.22 * span_y)))
    width, height = x1 - x0, y1 - y0
    # Overlap the cube centre because the visible front/right face changes
    # apparent width with pose.
    rx = x0 + int(round(0.32 * width))
    ry = y0 + int(round(0.08 * height))
    crop = image[ry:y1, rx:x1]
    if crop.size == 0:
        return sample
    try:
        ok, corners = cv2.findChessboardCornersSB(
            crop,
            (7, 6),
            flags=(cv2.CALIB_CB_NORMALIZE_IMAGE
                   | cv2.CALIB_CB_EXHAUSTIVE
                   | cv2.CALIB_CB_ACCURACY),
        )
    except cv2.error:
        ok, corners = False, None
    if not ok or corners is None or len(corners) != 42:
        return sample
    recovered = corners.reshape(-1, 2).astype(np.float64)
    recovered[:, 0] += rx
    recovered[:, 1] += ry
    boundaries = np.cumsum([0, *counts])
    old_groups = [
        sample.image_points[boundaries[i]:boundaries[i + 1]].copy()
        for i in range(3)
    ]
    # Reject an accidental floor-grid detection: it must overlap the legacy
    # third-face location and remain inside the cube point envelope.
    old_center = np.mean(old_groups[2], axis=0)
    new_center = np.mean(recovered, axis=0)
    if np.linalg.norm(new_center - old_center) > 0.45 * math.hypot(span_x, span_y):
        return sample
    patterns = [(9, 6), (9, 6), (7, 6)]
    faces = standard_three_face_target(
        float(square_size_mm), face_patterns=patterns, n_faces=3,
        center_patterns_on_cube=True,
    )
    old_groups[2] = recovered
    object_groups = [
        sample.object_points[boundaries[i]:boundaries[i + 1]].copy()
        for i in range(3)
    ]
    object_groups[2] = object_points_for_face(faces[2]).reshape(-1, 3).astype(np.float64)
    new_counts = (int(counts[0]), int(counts[1]), 42)
    existing_patterns = sample.face_patterns or ((0, 0), (0, 0), (0, 0))
    return replace(
        sample,
        image_points=np.vstack(old_groups),
        object_points=np.vstack(object_groups),
        source_model="legacy_extraction_plus_full_7x6_third_face_sb",
        raw_corner_count=int(sum(new_counts)),
        face_point_counts=new_counts,
        face_patterns=(
            tuple(int(v) for v in existing_patterns[0]),
            tuple(int(v) for v in existing_patterns[1]),
            (7, 6),
        ),
        association_repaired=True,
    )


def _grid_mapping_options(
    image_points: np.ndarray,
    observed_pattern: tuple[int, int],
    face,
) -> list[tuple[np.ndarray, np.ndarray, tuple[int, int], str]]:
    """Enumerate physically valid trims/placements/flips for one face grid."""
    observed_cols, observed_rows = (int(v) for v in observed_pattern)
    canonical_cols, canonical_rows = (int(v) for v in face.pattern_size)
    if len(image_points) != observed_cols * observed_rows:
        return []
    if observed_cols < 4 or observed_rows < 4:
        return []

    original = np.asarray(image_points, dtype=np.float64).reshape(
        observed_rows, observed_cols, 2
    )
    options = []
    arrangements = [(original, observed_cols, observed_rows, False)]
    # A square partial patch (commonly 4x4 on the foreshortened top face)
    # cannot identify which local axis belongs to the full 9- versus 6-corner
    # direction.  Preserve both hypotheses and let visible boundaries plus
    # the one rigid three-face pose resolve them.  Non-square detections keep
    # their upstream axis label to avoid needless combinatorics.
    if (observed_cols == observed_rows
            or (observed_rows == canonical_cols
                and observed_cols == canonical_rows)):
        arrangements.append((
            np.transpose(original, (1, 0, 2)),
            observed_rows,
            observed_cols,
            True,
        ))
    for array, array_cols, array_rows, transposed in arrangements:
        if array_cols > canonical_cols + 2 or array_rows > canonical_rows + 2:
            continue
        used_cols = min(array_cols, canonical_cols)
        used_rows = min(array_rows, canonical_rows)
        for trim_row in range(array_rows - used_rows + 1):
            for trim_col in range(array_cols - used_cols + 1):
                trimmed_image = array[
                    trim_row:trim_row + used_rows,
                    trim_col:trim_col + used_cols,
                ].reshape(-1, 2)
                for place_row in range(canonical_rows - used_rows + 1):
                    for place_col in range(canonical_cols - used_cols + 1):
                        for flip_x in (False, True):
                            for flip_y in (False, True):
                                full_object = object_points_for_face(
                                    face, flip_x=flip_x, flip_y=flip_y
                                ).reshape(canonical_rows, canonical_cols, 3)
                                trimmed_object = full_object[
                                    place_row:place_row + used_rows,
                                    place_col:place_col + used_cols,
                                ].reshape(-1, 3).astype(np.float64)
                                description = (
                                    f"transpose={int(transposed)},"
                                    f"trim=({trim_col},{trim_row}),"
                                    f"place=({place_col},{place_row}),"
                                    f"flip=({int(flip_x)},{int(flip_y)})"
                                )
                                options.append((
                                    trimmed_image.copy(),
                                    trimmed_object,
                                    (used_cols, used_rows),
                                    description,
                                ))
    return options


def _edge_distance_image(image_path: str) -> Optional[np.ndarray]:
    """Return distance (px) to the nearest real image edge.

    This is deliberately an image-only measurement.  It does not use a
    reference calibration and it never creates synthetic checker corners.
    """
    try:
        encoded = np.fromfile(image_path, dtype=np.uint8)
        gray = cv2.imdecode(encoded, cv2.IMREAD_GRAYSCALE)
    except Exception:
        return None
    if gray is None:
        return None
    smooth = cv2.GaussianBlur(gray, (5, 5), 0.9)
    median = float(np.median(smooth))
    low = int(max(18, 0.55 * median))
    high = int(max(low + 20, min(220, 1.35 * median)))
    edges = cv2.Canny(smooth, low, high, L2gradient=True)
    # Join small breaks in the wooden/white panel outline, but retain the
    # measured edge locations for the distance transform.
    edges = cv2.morphologyEx(
        edges, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8), iterations=1
    )
    return cv2.distanceTransform(255 - edges, cv2.DIST_L2, 3)


def _gray_image(image_path: str) -> Optional[np.ndarray]:
    try:
        encoded = np.fromfile(image_path, dtype=np.uint8)
        return cv2.imdecode(encoded, cv2.IMREAD_GRAYSCALE)
    except Exception:
        return None


def _face_checker_photometric_error(
    option: tuple[np.ndarray, np.ndarray, tuple[int, int], str],
    face,
    gray: Optional[np.ndarray],
) -> float:
    """Verify a grid offset by extrapolating the complete black/white print.

    Missing inner corners are never added as measurements.  Instead, the
    candidate homography predicts only the centres of all physical squares;
    their observed intensities must follow an alternating checker pattern.
    A wrong absolute offset normally projects several centres onto the white
    margin, wooden frame, or background and receives a large error.
    """
    if gray is None:
        return 0.0
    image_points, object_points = option[0], option[1]
    axis_x = np.asarray(face.axis_x, dtype=np.float64)
    axis_y = np.asarray(face.axis_y, dtype=np.float64)
    local = np.column_stack((
        np.asarray(object_points) @ axis_x,
        np.asarray(object_points) @ axis_y,
    )).astype(np.float64)
    H, _ = cv2.findHomography(local, np.asarray(image_points, np.float64), 0)
    if H is None or not np.all(np.isfinite(H)):
        return float("inf")

    origin_x = float(np.asarray(face.origin_3d) @ axis_x)
    origin_y = float(np.asarray(face.origin_3d) @ axis_y)
    square = float(face.square_size)
    cols, rows = (int(v) for v in face.pattern_size)
    local_samples = []
    sample_cells = []
    # Five samples per square suppress the influence of highlights and print
    # defects while staying well away from checker edges.
    offsets = ((0.0, 0.0), (-0.16, 0.0), (0.16, 0.0),
               (0.0, -0.16), (0.0, 0.16))
    if (cols, rows) == (7, 6):
        # YOZ has measured 7x6 inner corners but incomplete outer squares.
        # Validate only the 6x5 guaranteed cells between measured corners.
        row_indices = range(1, rows)
        col_indices = range(1, cols)
    else:
        row_indices = range(rows + 1)
        col_indices = range(cols + 1)
    for row in row_indices:
        for col in col_indices:
            cx = origin_x + (col - 0.5) * square
            cy = origin_y + (row - 0.5) * square
            for dx, dy in offsets:
                local_samples.append([cx + dx * square, cy + dy * square])
                sample_cells.append((col, row))
    projected = cv2.perspectiveTransform(
        np.asarray(local_samples, np.float64).reshape(-1, 1, 2), H
    ).reshape(-1, 2)
    height, width = gray.shape[:2]
    inside = (
        (projected[:, 0] >= 0) & (projected[:, 0] < width)
        & (projected[:, 1] >= 0) & (projected[:, 1] < height)
    )
    total_cells = len(row_indices) * len(col_indices)
    values_by_cell: dict[tuple[int, int], list[float]] = {}
    for point, cell, valid in zip(projected, sample_cells, inside):
        if not valid:
            continue
        x = int(np.clip(round(float(point[0])), 0, width - 1))
        y = int(np.clip(round(float(point[1])), 0, height - 1))
        values_by_cell.setdefault(cell, []).append(float(gray[y, x]))
    if len(values_by_cell) < int(math.ceil(0.85 * total_cells)):
        return float("inf")
    cells = sorted(values_by_cell)
    values = np.asarray(
        [np.median(values_by_cell[cell]) for cell in cells], dtype=np.float64
    )
    # Model slow illumination variation separately from checker parity.
    xn = np.asarray([cell[0] for cell in cells], dtype=np.float64)
    yn = np.asarray([cell[1] for cell in cells], dtype=np.float64)
    xn = (xn - np.mean(xn)) / max(float(cols), 1.0)
    yn = (yn - np.mean(yn)) / max(float(rows), 1.0)
    parity = np.asarray(
        [1.0 if (cell[0] + cell[1]) % 2 else -1.0 for cell in cells]
    )
    design = np.column_stack((np.ones(len(cells)), xn, yn, parity))
    beta, *_ = np.linalg.lstsq(design, values, rcond=None)
    residual = values - design @ beta
    residual_scale = float(np.sqrt(np.mean(residual * residual)))
    contrast = abs(float(beta[3]))
    # Dimensionless error: low residual and strong alternating contrast win.
    # A mild penalty below 12 grey levels rejects extrapolation onto margins.
    return residual_scale / max(contrast, 1.0) + max(0.0, 12.0 - contrast) / 6.0


def _face_boundary_error(
    option: tuple[np.ndarray, np.ndarray, tuple[int, int], str],
    face,
    cube_side_mm: float,
    edge_distance: Optional[np.ndarray],
) -> float:
    """Score where a grid hypothesis predicts the four physical face edges.

    A partial repetitive grid alone has no absolute offset.  Each candidate
    offset implies a different complete checker-print quadrilateral.  The
    correct offset should place its four outer square edges where the checker
    pattern visibly terminates on the white panel.
    """
    if edge_distance is None:
        return 0.0
    image_points, object_points = option[0], option[1]
    local = np.column_stack((
        np.asarray(object_points) @ np.asarray(face.axis_x, dtype=np.float64),
        np.asarray(object_points) @ np.asarray(face.axis_y, dtype=np.float64),
    )).astype(np.float64)
    if len(local) < 4:
        return float("inf")
    H, _ = cv2.findHomography(local, np.asarray(image_points, np.float64), 0)
    if H is None or not np.all(np.isfinite(H)):
        return float("inf")
    # OpenCV inner corners run from 0..cols-1 and 0..rows-1.  The printed
    # checkerboard has one complete square before the first inner corner and
    # one after the last, hence [-1, cols] x [-1, rows] in square units.
    origin_x = float(np.asarray(face.origin_3d) @ np.asarray(face.axis_x))
    origin_y = float(np.asarray(face.origin_3d) @ np.asarray(face.axis_y))
    square = float(face.square_size)
    cols, rows = (int(v) for v in face.pattern_size)
    x0, x1 = origin_x - square, origin_x + cols * square
    y0, y1 = origin_y - square, origin_y + rows * square
    physical_boundary = np.asarray(
        [[x0, y0], [x1, y0], [x1, y1], [x0, y1]],
        dtype=np.float64,
    ).reshape(-1, 1, 2)
    polygon = cv2.perspectiveTransform(physical_boundary, H).reshape(-1, 2)
    if not np.all(np.isfinite(polygon)) or abs(cv2.contourArea(
            polygon.astype(np.float32))) < 100.0:
        return float("inf")

    height, width = edge_distance.shape[:2]
    samples = []
    for index in range(4):
        p0, p1 = polygon[index], polygon[(index + 1) % 4]
        length = float(np.linalg.norm(p1 - p0))
        count = max(16, min(80, int(round(length / 4.0))))
        alpha = np.linspace(0.04, 0.96, count)
        samples.append(
            p0[None, :] * (1.0 - alpha[:, None])
            + p1[None, :] * alpha[:, None]
        )
    points = np.vstack(samples)
    inside = (
        (points[:, 0] >= 0) & (points[:, 0] < width)
        & (points[:, 1] >= 0) & (points[:, 1] < height)
    )
    if int(np.sum(inside)) < max(24, len(points) // 2):
        return float("inf")
    points = points[inside]
    x = np.clip(np.rint(points[:, 0]).astype(int), 0, width - 1)
    y = np.clip(np.rint(points[:, 1]).astype(int), 0, height - 1)
    distances = np.minimum(edge_distance[y, x].astype(np.float64), 24.0)
    # A robust trimmed mean tolerates joints, highlights and short occlusions.
    distances.sort()
    keep = max(1, int(round(0.80 * len(distances))))
    return float(np.mean(distances[:keep]))


def _repair_face_grid_association(
    sample: CorrespondenceSet,
    K: np.ndarray,
    dist: np.ndarray,
    square_size_mm: float,
    diagnostics: Optional[dict] = None,
    cube_side_squares: Optional[float] = None,
    max_initial_rmse_px: float = 6.0,
    max_initial_face_rmse_px: float = 9.0,
) -> Optional[CorrespondenceSet]:
    """Repair grid indexing using visible boundaries and rigid cube geometry."""
    if sample.face_point_counts is None or sample.face_patterns is None:
        return None
    counts = tuple(int(v) for v in sample.face_point_counts)
    boundaries = np.cumsum([0, *counts])
    base_faces = _measured_cuboid_faces(float(square_size_mm))
    best = None
    second_best = None
    edge_distance = _edge_distance_image(sample.image_path)
    gray = _gray_image(sample.image_path)
    best_by_absolute_index: dict[tuple, tuple] = {}
    # Target dimensions and sticker placement are measured physical inputs;
    # they are never selected per image or absorbed into camera parameters.
    side_candidates = [0.0]
    for candidate_side_squares in side_candidates:
        canonical_faces = base_faces
        # The measured 9x6, 9x6, 7x6 patterns identify XOY/XOZ/YOZ.  Swapping
        # vertical faces would trim a real board to fit the wrong plane.
        for face_assignment in ((0, 1, 2),):
            option_sets = []
            boundary_error_by_id: dict[int, float] = {}
            photometric_error_by_id: dict[int, float] = {}
            for group_index, physical_face_index in enumerate(face_assignment):
                group = sample.image_points[
                    boundaries[group_index]:boundaries[group_index + 1]
                ]
                options = _grid_mapping_options(
                    group,
                    sample.face_patterns[group_index],
                    canonical_faces[physical_face_index],
                )
                if not options:
                    option_sets = []
                    break
                # A local 4x4 grid is periodic and cannot identify its own
                # absolute offset.  Rank hypotheses by the four *observed*
                # physical face edges before the joint rigid-cube search.
                boundary_ranked = sorted(
                    (
                        (_face_boundary_error(
                            option,
                            canonical_faces[physical_face_index],
                            0.0,
                            edge_distance,
                        ), option)
                        for option in options
                    ),
                    key=lambda item: item[0],
                )
                evidence_ranked = []
                for boundary_value, option in boundary_ranked:
                    photo_value = _face_checker_photometric_error(
                        option, canonical_faces[physical_face_index], gray
                    )
                    if np.isfinite(boundary_value) and np.isfinite(photo_value):
                        evidence_ranked.append((
                            float(photo_value) + 0.08 * float(boundary_value),
                            float(boundary_value), float(photo_value), option,
                        ))
                evidence_ranked.sort(key=lambda item: item[0])
                finite_ranked = evidence_ranked
                if finite_ranked:
                    minimum_evidence_error = float(finite_ranked[0][0])
                    # Retain every flip for placements supported nearly as
                    # well as the best visible checker boundary.  This removes
                    # only offsets whose predicted outer print edge is clearly
                    # elsewhere, while leaving orientation to the rigid cube.
                    kept = [
                        item for item in finite_ranked
                        if float(item[0]) <= minimum_evidence_error + 0.22
                    ]
                    if len(kept) < 4:
                        kept = finite_ranked[:4]
                    options = [item[3] for item in kept]
                    boundary_error_by_id.update(
                        {id(item[3]): float(item[1]) for item in kept}
                    )
                    photometric_error_by_id.update(
                        {id(item[3]): float(item[2]) for item in kept}
                    )
                option_sets.append(options)
            if not option_sets:
                continue

            for combo in itertools.product(*option_sets):
                image_points = np.vstack([entry[0] for entry in combo])
                object_points = np.vstack([entry[1] for entry in combo])
                try:
                    ok, rvec, tvec = cv2.solvePnP(
                        object_points.reshape(-1, 1, 3),
                        image_points.reshape(-1, 1, 2),
                        K,
                        dist,
                        flags=cv2.SOLVEPNP_EPNP,
                    )
                except cv2.error:
                    continue
                if not ok:
                    continue
                projected, _ = cv2.projectPoints(
                    object_points.reshape(-1, 1, 3), rvec, tvec, K, dist
                )
                error = np.linalg.norm(
                    projected.reshape(-1, 2) - image_points, axis=1
                )
                option_counts = [len(entry[0]) for entry in combo]
                option_bounds = np.cumsum([0, *option_counts])
                face_rmse = [
                    float(np.sqrt(np.mean(
                        error[option_bounds[i]:option_bounds[i + 1]] ** 2
                    )))
                    for i in range(3)
                ]
                total_rmse = float(np.sqrt(np.mean(error ** 2)))
                boundary_errors = [
                    boundary_error_by_id[id(combo[i])]
                    if id(combo[i]) in boundary_error_by_id else
                        _face_boundary_error(
                            combo[i], canonical_faces[face_assignment[i]],
                            0.0,
                            edge_distance,
                        )
                    for i in range(3)
                ]
                finite_boundary = [v for v in boundary_errors if np.isfinite(v)]
                boundary_error = (
                    float(np.mean(finite_boundary)) if finite_boundary else 0.0
                )
                photometric_errors = [
                    photometric_error_by_id.get(id(combo[i]), 0.0)
                    for i in range(3)
                ]
                photometric_error = float(np.mean(photometric_errors))
                score = (
                    total_rmse + 0.20 * max(face_rmse)
                    + 0.18 * boundary_error + 1.50 * photometric_error
                )
                record = (
                    score, total_rmse, face_rmse, combo,
                    image_points, object_points, rvec, tvec,
                    face_assignment, float(candidate_side_squares),
                    boundary_error, photometric_error,
                )
                absolute_signature = (
                    tuple(int(v) for v in face_assignment),
                    tuple(entry[3].split(",flip=")[0] for entry in combo),
                )
                previous = best_by_absolute_index.get(absolute_signature)
                if previous is None or score < previous[0]:
                    best_by_absolute_index[absolute_signature] = record
                if best is None or score < best[0]:
                    second_best = best
                    best = record
                elif second_best is None or score < second_best[0]:
                    second_best = record

    if best is None:
        if diagnostics is not None:
            diagnostics["status"] = "no_candidate"
        return None
    distinct_absolute_candidates = sorted(
        best_by_absolute_index.values(), key=lambda item: item[0]
    )
    best = distinct_absolute_candidates[0]
    second_best = (
        distinct_absolute_candidates[1]
        if len(distinct_absolute_candidates) > 1 else None
    )
    (_score, _seed_rmse, _seed_face_rmse, combo,
     image_points, object_points, rvec, tvec, face_assignment,
     cube_side_squares, boundary_error, photometric_error) = best
    score_gap = (
        None if second_best is None
        else float(second_best[0] - best[0])
    )
    # Crucial rigidity rule: object_points stay on the one canonical cube.
    # Per-image face translations previously allowed target geometry to absorb
    # focal/distortion error and are intentionally forbidden.
    try:
        ok, rvec, tvec = cv2.solvePnP(
            object_points.reshape(-1, 1, 3),
            image_points.reshape(-1, 1, 2),
            K,
            dist,
            rvec,
            tvec,
            useExtrinsicGuess=True,
            flags=cv2.SOLVEPNP_ITERATIVE,
        )
    except cv2.error:
        ok = False
    if not ok:
        return None
    projected, _ = cv2.projectPoints(
        object_points.reshape(-1, 1, 3), rvec, tvec, K, dist
    )
    error = np.linalg.norm(projected.reshape(-1, 2) - image_points, axis=1)
    repaired_counts = tuple(int(len(entry[0])) for entry in combo)
    repaired_bounds = np.cumsum([0, *repaired_counts])
    face_rmse = tuple(
        float(np.sqrt(np.mean(
            error[repaired_bounds[i]:repaired_bounds[i + 1]] ** 2
        )))
        for i in range(3)
    )
    total_rmse = float(np.sqrt(np.mean(error ** 2)))
    if diagnostics is not None:
        diagnostics.update({
            "status": "scored",
            "total_rmse_px": total_rmse,
            "face_rmse_px": list(face_rmse),
            "descriptions": [entry[3] for entry in combo],
            "face_point_counts": list(repaired_counts),
            "face_assignment": list(face_assignment),
            "cube_side_squares": cube_side_squares,
            "target_extents_mm": list(TARGET_EXTENTS_MM),
            "target_profile": "measured_rectangular_cuboid",
            "boundary_error_px": boundary_error,
            "checker_photometric_error": photometric_error,
            "best_score": float(best[0]),
            "second_best_score": (
                None if second_best is None else float(second_best[0])
            ),
            "score_gap": score_gap,
            "boundary_evidence_used": edge_distance is not None,
            "per_image_face_shifts_allowed": False,
        })
    partial_grid_present = any(
        tuple(int(v) for v in sample.face_patterns[i])
        != tuple(int(v) for v in CANONICAL_FACE_PATTERNS[i])
        for i in range(3)
    )
    ambiguous_partial_index = bool(
        partial_grid_present
        and score_gap is not None
        and score_gap <= 1.0
        and score_gap < 0.20 * max(float(best[0]), 1.0)
    )
    if diagnostics is not None:
        diagnostics["partial_grid_present"] = partial_grid_present
        diagnostics["absolute_grid_index_ambiguous"] = ambiguous_partial_index
    if ambiguous_partial_index:
        if diagnostics is not None:
            diagnostics["status"] = "ambiguous_absolute_grid_index"
        return None
    if (total_rmse > float(max_initial_rmse_px)
            or max(face_rmse) > float(max_initial_face_rmse_px)):
        if diagnostics is not None:
            diagnostics["status"] = "quality_rejected"
        return None
    return CorrespondenceSet(
        image_path=sample.image_path,
        image_size=sample.image_size,
        image_points=image_points,
        object_points=object_points,
        K_seed=sample.K_seed,
        dist_seed=sample.dist_seed,
        R_seed=sample.R_seed,
        t_seed=sample.t_seed,
        cube_area_pct=sample.cube_area_pct,
        corner_quality=sample.corner_quality,
        source_model="frozen_model_physical_grid_association_repair",
        raw_corner_count=sample.raw_corner_count,
        face_point_counts=repaired_counts,
        face_patterns=tuple(entry[2] for entry in combo),
        association_repaired=True,
        association_rmse_px=total_rmse,
        association_boundary_error_px=boundary_error,
        association_photometric_error=photometric_error,
        association_score_gap=score_gap,
    )


def _geometric_inlier_filter(
    sample: CorrespondenceSet,
    *,
    focal_hint_px: Optional[float] = None,
    k1_hint: Optional[float] = None,
    minimum_usable_faces: int = 2,
    square_size_mm: float = 25.0,
    cube_side_squares_hint: Optional[float] = None,
    allow_independent_cube_search: bool = False,
) -> CorrespondenceSet:
    """Reject cross-face mismatches with a reference-free PnP consensus gate.

    The automatic detector can recover a locally plausible grid from the
    gridded floor.  Such points pass a per-face homography check but disagree
    with the rigid trihedral cube.  This gate uses only the extracted cube
    geometry and a camera-generic focal initialization during training.  No
    Zhang/reference calibration is read or used.
    """
    if minimum_usable_faces not in {1, 2, 3}:
        raise ValueError("minimum_usable_faces must be 1, 2, or 3")
    counts = sample.face_point_counts
    if counts is None or len(counts) != 3 or sum(counts) != len(sample.image_points):
        raise RuntimeError("Three-face group boundaries are unavailable")

    width, height = sample.image_size
    diagonal = math.hypot(width, height)
    focal = (
        float(focal_hint_px)
        if focal_hint_px is not None and np.isfinite(float(focal_hint_px))
        else 0.70 * diagonal
    )
    K = _camera_matrix(focal, width / 2.0, height / 2.0)
    dist = np.zeros(5, dtype=np.float64)
    if k1_hint is not None and np.isfinite(float(k1_hint)):
        dist[0] = float(k1_hint)

    def face_grid_spans(
        current: CorrespondenceSet,
        current_indices: np.ndarray,
        current_boundaries: np.ndarray,
    ) -> tuple[tuple[int, int], tuple[int, int], tuple[int, int]]:
        patterns = current.face_patterns or ((0, 0), (0, 0), (0, 0))
        spans = []
        for face_index in range(3):
            cols, rows = (int(v) for v in patterns[face_index])
            local = current_indices[
                (current_indices >= current_boundaries[face_index])
                & (current_indices < current_boundaries[face_index + 1])
            ] - current_boundaries[face_index]
            if cols <= 0 or rows <= 0 or len(local) == 0:
                spans.append((0, 0))
                continue
            spans.append((
                int(len(np.unique(local % cols))),
                int(len(np.unique(local // cols))),
            ))
        return tuple(spans)  # type: ignore[return-value]

    def usable_faces_from(
        counts_per_face: tuple[int, int, int],
        spans_per_face: tuple[tuple[int, int], tuple[int, int], tuple[int, int]],
    ) -> list[int]:
        return [
            face for face in range(3)
            if counts_per_face[face] >= MIN_FACE_INLIERS
            and spans_per_face[face][0] >= MIN_GRID_COLS
            and spans_per_face[face][1] >= MIN_GRID_ROWS
        ]

    def solve_consensus(current: CorrespondenceSet):
        current_counts = tuple(int(v) for v in (current.face_point_counts or ()))
        if len(current_counts) != 3 or sum(current_counts) != len(current.image_points):
            return None
        current_obj = current.object_points.astype(np.float64).reshape(-1, 1, 3)
        current_img = current.image_points.astype(np.float64).reshape(-1, 1, 2)
        current_boundaries = np.cumsum([0, *current_counts])
        if not allow_independent_cube_search:
            cv2.setRNGSeed(20260723)
            ok, _rvec, _tvec, current_inliers = cv2.solvePnPRansac(
                current_obj, current_img, K, dist,
                iterationsCount=4000,
                reprojectionError=5.0,
                confidence=0.999,
                flags=cv2.SOLVEPNP_EPNP,
            )
            if not ok or current_inliers is None:
                return None
            current_indices = current_inliers.reshape(-1).astype(int)
            current_face_inliers = tuple(
                int(np.sum(
                    (current_indices >= current_boundaries[i])
                    & (current_indices < current_boundaries[i + 1])
                ))
                for i in range(3)
            )
            current_spans = face_grid_spans(
                current, current_indices, current_boundaries
            )
            current_usable = usable_faces_from(
                current_face_inliers, current_spans
            )
            return (
                current_indices, current_boundaries,
                current_face_inliers, current_usable, current_spans,
            )
        face_indices = [
            np.arange(current_boundaries[i], current_boundaries[i + 1], dtype=int)
            for i in range(3)
        ]
        # Generate pose hypotheses from all faces, every face pair, and each
        # face alone.  Scoring is face-balanced, so a 54-corner face cannot
        # erase a smaller but geometrically consistent face.
        subsets = [(0, 1, 2), (0, 1), (0, 2), (1, 2), (0,), (1,), (2,)]
        pose_candidates = []
        for subset_number, subset in enumerate(subsets):
            selected = np.concatenate([face_indices[i] for i in subset])
            if len(selected) < 6:
                continue
            try:
                cv2.setRNGSeed(20260723 + 17 * subset_number)
                ok, rvec, tvec, inliers = cv2.solvePnPRansac(
                    current_obj[selected], current_img[selected], K, dist,
                    iterationsCount=600,
                    reprojectionError=5.0,
                    confidence=0.998,
                    flags=cv2.SOLVEPNP_EPNP,
                )
            except cv2.error:
                continue
            if ok and inliers is not None and len(inliers) >= 6:
                pose_candidates.append((rvec, tvec))
        if not pose_candidates:
            return None

        best_result = None
        best_score = None
        for rvec, tvec in pose_candidates:
            projected, _ = cv2.projectPoints(
                current_obj, rvec, tvec, K, dist
            )
            error = np.linalg.norm(
                projected.reshape(-1, 2) - current_img.reshape(-1, 2), axis=1
            )
            indices = np.flatnonzero(error <= 5.0).astype(int)
            face_counts = tuple(
                int(np.sum(
                    (indices >= current_boundaries[i])
                    & (indices < current_boundaries[i + 1])
                ))
                for i in range(3)
            )
            current_spans = face_grid_spans(
                current, indices, current_boundaries
            )
            usable = usable_faces_from(face_counts, current_spans)
            if not usable:
                continue
            face_medians = [
                float(np.median(error[face_indices[i]][
                    error[face_indices[i]] <= 5.0
                ]))
                for i in usable
            ]
            # Lexicographic priority: explain more faces first, then protect
            # the weakest face, then use more total points and lower error.
            score = (
                -len(usable),
                -min(face_counts[i] for i in usable),
                max(face_medians),
                -len(indices),
                float(np.mean(face_medians)),
            )
            if best_score is None or score < best_score:
                best_score = score
                best_result = (indices, face_counts, usable, current_spans)
        if best_result is None:
            return None
        (current_indices, current_face_inliers, current_usable,
         current_spans) = best_result
        return (
            current_indices,
            current_boundaries,
            current_face_inliers,
            current_usable,
            current_spans,
        )

    consensus = solve_consensus(sample)
    if consensus is None:
        raise RuntimeError(
            "Rigid three-face consensus failed after checker extraction"
        )
    indices, boundaries, face_inliers, usable_faces, grid_spans = consensus

    # When a frozen camera model is available, use it to repair grid indexing
    # before accepting a partial fallback.  This searches only discrete,
    # physically valid trims, placements, and axis flips; it does not alter K.
    if focal_hint_px is not None and len(usable_faces) < 3:
        repaired = _repair_face_grid_association(
            sample, K, dist, float(square_size_mm),
            cube_side_squares=cube_side_squares_hint,
            max_initial_rmse_px=(
                35.0 if (cube_side_squares_hint is not None
                          or allow_independent_cube_search) else 6.0
            ),
            max_initial_face_rmse_px=(
                50.0 if (cube_side_squares_hint is not None
                          or allow_independent_cube_search) else 9.0
            ),
        )
        if repaired is not None:
            repaired_consensus = solve_consensus(repaired)
            if repaired_consensus is not None:
                repaired_usable = repaired_consensus[3]
                if len(repaired_usable) > len(usable_faces):
                    sample = repaired
                    counts = sample.face_point_counts
                    (indices, boundaries, face_inliers,
                     usable_faces, grid_spans) = repaired_consensus
    if len(usable_faces) < minimum_usable_faces:
        raise RuntimeError(
            "Rigid three-face consensus retained fewer than "
            f"{minimum_usable_faces} reliable "
            f"faces (inliers per face: {list(face_inliers)})"
        )
    keep = np.asarray(
        [
            index
            for index in indices
            if any(boundaries[face] <= index < boundaries[face + 1]
                   for face in usable_faces)
        ],
        dtype=int,
    )
    minimum_total = MIN_TOTAL_INLIERS_BY_FACE_COUNT[len(usable_faces)]
    if len(keep) < minimum_total:
        raise RuntimeError(
            "Rigid three-face consensus retained only "
            f"{len(keep)} points; {minimum_total} are required for "
            f"{len(usable_faces)} usable face(s)"
        )
    return CorrespondenceSet(
        image_path=sample.image_path,
        image_size=sample.image_size,
        image_points=sample.image_points[keep].copy(),
        object_points=sample.object_points[keep].copy(),
        K_seed=sample.K_seed,
        dist_seed=sample.dist_seed,
        R_seed=sample.R_seed,
        t_seed=sample.t_seed,
        cube_area_pct=sample.cube_area_pct,
        corner_quality=sample.corner_quality,
        source_model="rigid_trihedral_consensus_inliers",
        raw_corner_count=(
            sample.raw_corner_count
            if sample.raw_corner_count is not None
            else int(len(sample.image_points))
        ),
        geometric_inlier_count=int(len(keep)),
        face_point_counts=counts,
        face_inlier_counts=face_inliers,
        face_grid_spans=grid_spans,
        face_patterns=sample.face_patterns,
        association_repaired=sample.association_repaired,
        association_rmse_px=sample.association_rmse_px,
        association_boundary_error_px=sample.association_boundary_error_px,
        association_photometric_error=sample.association_photometric_error,
        association_score_gap=sample.association_score_gap,
    )


def extract_correspondences(
    image_path: str,
    square_size_mm: float,
    *,
    focal_hint_px: Optional[float] = None,
    k1_hint: Optional[float] = None,
    correspondence_cache_path: Optional[str] = None,
    minimum_usable_faces: int = 2,
    cube_side_squares_hint: Optional[float] = None,
    allow_independent_cube_search: bool = False,
) -> CorrespondenceSet:
    """Extract three-face 2-D/3-D correspondences without reference labels."""
    if not os.path.isfile(image_path):
        raise FileNotFoundError(image_path)

    if correspondence_cache_path and os.path.isfile(correspondence_cache_path):
        cached_sample = _load_cache(correspondence_cache_path, image_path, None)
        if allow_independent_cube_search:
            recovered_sample = _recover_full_third_face_sb(
                cached_sample, image_path, float(square_size_mm)
            )
            filtered_candidates = []
            for candidate_sample in (cached_sample, recovered_sample):
                try:
                    filtered_candidates.append(_geometric_inlier_filter(
                        candidate_sample,
                        focal_hint_px=focal_hint_px,
                        k1_hint=k1_hint,
                        minimum_usable_faces=minimum_usable_faces,
                        square_size_mm=float(square_size_mm),
                        cube_side_squares_hint=cube_side_squares_hint,
                        allow_independent_cube_search=True,
                    ))
                except Exception:
                    continue
            if filtered_candidates:
                return min(
                    filtered_candidates,
                    key=lambda item: (
                        -_sample_usable_face_count(item),
                        -sum(item.face_inlier_counts or (0, 0, 0)),
                    ),
                )
            cached_sample = recovered_sample
        return _geometric_inlier_filter(
            cached_sample,
            focal_hint_px=focal_hint_px,
            k1_hint=k1_hint,
            minimum_usable_faces=minimum_usable_faces,
            square_size_mm=float(square_size_mm),
            cube_side_squares_hint=cube_side_squares_hint,
            allow_independent_cube_search=allow_independent_cube_search,
        )

    def extract_to(cache_path: str) -> CorrespondenceSet:
        result: Optional[BestResult] = None
        pending_error: Optional[BaseException] = None
        try:
            result = calibrate_best(
                image_path,
                square_size_mm=float(square_size_mm),
                face_patterns=list(CANONICAL_FACE_PATTERNS),
                n_faces=3,
                k1_only=False,
                focal_px=focal_hint_px,
                k1_prior=k1_hint,
                verbose=False,
                diagnostic_cache_path=cache_path,
                research_return_rejected=True,
            )
        except BaseException as exc:  # cache can still be valid after a late gate
            pending_error = exc
        if not os.path.isfile(cache_path):
            if pending_error is not None:
                raise RuntimeError(
                    f"Could not extract three-face geometry from {image_path}: "
                    f"{pending_error}"
                ) from pending_error
            raise RuntimeError(
                f"Could not extract three-face geometry from {image_path}"
            )
        extracted_sample = _load_cache(cache_path, image_path, result)
        if allow_independent_cube_search:
            extracted_sample = _recover_full_third_face_sb(
                extracted_sample, image_path, float(square_size_mm)
            )
        return _geometric_inlier_filter(
            extracted_sample,
            focal_hint_px=focal_hint_px,
            k1_hint=k1_hint,
            minimum_usable_faces=minimum_usable_faces,
            square_size_mm=float(square_size_mm),
            cube_side_squares_hint=cube_side_squares_hint,
            allow_independent_cube_search=allow_independent_cube_search,
        )

    if correspondence_cache_path:
        os.makedirs(os.path.dirname(os.path.abspath(correspondence_cache_path)), exist_ok=True)
        return extract_to(correspondence_cache_path)
    with tempfile.TemporaryDirectory(prefix="trihedral_training_") as tmp:
        return extract_to(os.path.join(tmp, "correspondences.npz"))


def _camera_matrix(focal: float, cx: float, cy: float) -> np.ndarray:
    return np.array(
        [[focal, 0.0, cx], [0.0, focal, cy], [0.0, 0.0, 1.0]],
        dtype=np.float64,
    )


def _initial_shared_model(
    samples: list[CorrespondenceSet],
) -> tuple[np.ndarray, np.ndarray]:
    width, height = samples[0].image_size
    diagonal = math.hypot(width, height)
    # Camera-generic initialization only.  Calibration results stored in the
    # extraction cache are deliberately ignored: they are neither labels nor
    # priors for the trained model.
    focal = 0.70 * diagonal
    return _camera_matrix(focal, width / 2.0, height / 2.0), np.zeros(
        5, dtype=np.float64
    )


def _local_face_observations(
    raw_samples: list[CorrespondenceSet],
    square_size_mm: float,
) -> list[dict]:
    """Build face-local planar observations without absolute grid offsets."""
    observations = []
    for sample in raw_samples:
        counts = sample.face_point_counts
        patterns = sample.face_patterns
        if counts is None or patterns is None or sum(counts) != len(sample.image_points):
            continue
        boundaries = np.cumsum([0, *counts])
        for face_index, (cols, rows) in enumerate(patterns):
            cols, rows = int(cols), int(rows)
            if cols < MIN_GRID_COLS or rows < MIN_GRID_ROWS:
                continue
            points = np.asarray(
                sample.image_points[boundaries[face_index]:boundaries[face_index + 1]],
                dtype=np.float64,
            ).reshape(-1, 2)
            if len(points) != cols * rows:
                continue
            local = np.asarray(
                [[c * square_size_mm, r * square_size_mm]
                 for r in range(rows) for c in range(cols)],
                dtype=np.float64,
            )
            H, mask = cv2.findHomography(local, points, cv2.RANSAC, 2.0)
            if H is None or not np.all(np.isfinite(H)):
                continue
            projected = cv2.perspectiveTransform(
                local.reshape(-1, 1, 2), H
            ).reshape(-1, 2)
            error = np.linalg.norm(projected - points, axis=1)
            inlier_mask = (
                np.ones(len(points), dtype=bool)
                if mask is None else mask.reshape(-1).astype(bool)
            )
            if int(np.sum(inlier_mask)) < max(12, int(0.75 * len(points))):
                continue
            rmse = float(np.sqrt(np.mean(error[inlier_mask] ** 2)))
            if rmse > 1.5:
                continue
            observations.append({
                "image": sample.image_path,
                "face_index": face_index,
                "pattern": (cols, rows),
                "points": points,
                "H": H / max(float(np.linalg.norm(H[:, 0])), 1e-12),
                "rmse_px": rmse,
                "inliers": int(np.sum(inlier_mask)),
            })
    return observations


def _estimate_local_homography_seed(
    raw_samples: list[CorrespondenceSet],
    square_size_mm: float,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """Zhang-style K/dist seed from partial face-local checker coordinates.

    Translating a local 4x4 patch within its complete board changes h3 only;
    the orthogonality/equal-norm constraints on h1,h2 remain valid.  No
    absolute grid index and no Zhang/reference calibration result is used.
    """
    if not raw_samples:
        raise ValueError("No raw samples for local homography initialization")
    width, height = raw_samples[0].image_size
    diagonal = math.hypot(width, height)
    observations = _local_face_observations(raw_samples, square_size_mm)
    generic_K = _camera_matrix(0.70 * diagonal, width / 2.0, height / 2.0)
    if len(observations) < 3:
        return generic_K, np.zeros(5), {
            "success": False,
            "reason": "fewer_than_three_usable_local_homographies",
            "homography_count": len(observations),
        }

    def residual(values: np.ndarray) -> np.ndarray:
        fx, fy = math.exp(float(values[0])), math.exp(float(values[1]))
        K = np.array(
            [[fx, 0.0, values[2]], [0.0, fy, values[3]], [0.0, 0.0, 1.0]],
            dtype=np.float64,
        )
        inverse = np.linalg.inv(K)
        out = []
        for observation in observations:
            H = observation["H"]
            first, second = inverse @ H[:, 0], inverse @ H[:, 1]
            n1, n2 = float(np.linalg.norm(first)), float(np.linalg.norm(second))
            if n1 < 1e-12 or n2 < 1e-12:
                continue
            weight = min(2.0, math.sqrt(observation["inliers"] / 16.0))
            out.extend([
                weight * float(first @ second) / (n1 * n2),
                weight * math.log(n1 / n2),
            ])
        # Weak generic priors only remove the small-data null direction.
        out.extend([
            math.log(fx / fy) / 0.05,
            (float(values[2]) - width / 2.0) / (0.10 * width),
            (float(values[3]) - height / 2.0) / (0.10 * height),
        ])
        return np.asarray(out, dtype=np.float64)

    x0 = np.array([
        math.log(generic_K[0, 0]), math.log(generic_K[1, 1]),
        width / 2.0, height / 2.0,
    ])
    result = least_squares(
        residual, x0,
        bounds=(
            [math.log(0.20 * diagonal), math.log(0.20 * diagonal),
             0.35 * width, 0.35 * height],
            [math.log(3.00 * diagonal), math.log(3.00 * diagonal),
             0.65 * width, 0.65 * height],
        ),
        loss="soft_l1", f_scale=0.05, max_nfev=500,
    )
    fx, fy = math.exp(result.x[0]), math.exp(result.x[1])
    K = np.array(
        [[fx, 0.0, result.x[2]], [0.0, fy, result.x[3]], [0.0, 0.0, 1.0]],
        dtype=np.float64,
    )
    corner_groups = [item["points"] for item in observations]
    patterns = [item["pattern"] for item in observations]
    try:
        plumb = estimate_checker_plumbline_distortion(
            corner_groups, patterns, K, allow_high_order=True,
        )
        dist = np.asarray(plumb.dist, dtype=np.float64).reshape(5)
        plumb_diagnostics = plumb.to_dict()
    except Exception as exc:
        dist = np.zeros(5, dtype=np.float64)
        plumb_diagnostics = {"success": False, "error": str(exc)}
    return K, dist, {
        "success": bool(result.success),
        "method": "partial_face_local_homography_orthogonality",
        "absolute_grid_indices_required": False,
        "homography_count": len(observations),
        "homography_median_rmse_px": float(np.median([
            item["rmse_px"] for item in observations
        ])),
        "cameraMatrix": K.tolist(),
        "plumbline": plumb_diagnostics,
    }


def _fit_partial_planar_model(
    raw_samples: list[CorrespondenceSet],
    square_size_mm: float,
    radial_order: int,
) -> tuple[np.ndarray, np.ndarray, dict]:
    """Estimate shared intrinsics from all visible face-local planar patches.

    The absolute row/column offset of a partial patch is deliberately absent:
    a planar translation is absorbed by the third homography column.  The
    homography solution estimates K; a second planar-pose pass estimates only
    radial distortion, preventing uncertain cuboid face offsets from pulling K.
    """
    K, _, homography = _estimate_local_homography_seed(raw_samples, square_size_mm)
    observations = _local_face_observations(raw_samples, square_size_mm)
    if len(observations) < 3:
        raise RuntimeError("Fewer than three usable partial-face homographies")
    object_groups: list[np.ndarray] = []
    image_groups: list[np.ndarray] = []
    for observation in observations:
        cols, rows = observation["pattern"]
        object_points = np.zeros((cols * rows, 3), dtype=np.float32)
        object_points[:, :2] = np.asarray(
            [[c * square_size_mm, r * square_size_mm]
             for r in range(rows) for c in range(cols)],
            dtype=np.float32,
        )
        object_groups.append(object_points)
        image_groups.append(np.asarray(observation["points"], dtype=np.float32))
    flags = (
        cv2.CALIB_USE_INTRINSIC_GUESS
        | cv2.CALIB_ZERO_TANGENT_DIST
        | cv2.CALIB_FIX_K3
        | cv2.CALIB_FIX_FOCAL_LENGTH
        | cv2.CALIB_FIX_PRINCIPAL_POINT
    )
    if radial_order == 1:
        flags |= cv2.CALIB_FIX_K2
    initial_dist = np.zeros((5, 1), dtype=np.float64)
    rms, fitted_K, fitted_dist, rvecs, tvecs = cv2.calibrateCamera(
        object_groups,
        image_groups,
        raw_samples[0].image_size,
        K.copy(),
        initial_dist,
        flags=flags,
        criteria=(
            cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_MAX_ITER,
            500,
            1e-12,
        ),
    )
    fitted_dist = np.asarray(fitted_dist, dtype=np.float64).reshape(-1)
    if fitted_dist.size < 5:
        fitted_dist = np.pad(fitted_dist, (0, 5 - fitted_dist.size))
    fitted_dist[2:] = 0.0
    if radial_order == 1:
        fitted_dist[1] = 0.0
    fitted_dist, rvecs, tvecs, radial_regularization = (
        _refine_fixed_intrinsics_planar_radial(
            object_groups,
            image_groups,
            fitted_K,
            fitted_dist,
            rvecs,
            tvecs,
            radial_order,
        )
    )
    projected_squared = []
    for obj, img, rvec, tvec in zip(object_groups, image_groups, rvecs, tvecs):
        projected, _ = cv2.projectPoints(obj, rvec, tvec, fitted_K, fitted_dist)
        delta = projected.reshape(-1, 2) - img.reshape(-1, 2)
        projected_squared.extend(np.sum(delta * delta, axis=1).tolist())
    rms = float(np.sqrt(np.mean(projected_squared)))
    return fitted_K, fitted_dist[:5], {
        "optimizer_success": bool(np.isfinite(rms)),
        "joint_reprojection_rmse_px": float(rms),
        "planar_face_observations": len(observations),
        "intrinsics_stage": "partial_homography_orthogonality",
        "distortion_stage": "fixed_intrinsics_partial_planar_pose_refinement",
        "absolute_grid_indices_required": False,
        "homography": homography,
        "radial_regularization": radial_regularization,
    }


def _refine_fixed_intrinsics_planar_radial(
    object_groups: list[np.ndarray],
    image_groups: list[np.ndarray],
    K: np.ndarray,
    initial_dist: np.ndarray,
    initial_rvecs: list[np.ndarray],
    initial_tvecs: list[np.ndarray],
    radial_order: int,
) -> tuple[np.ndarray, list[np.ndarray], list[np.ndarray], dict]:
    """Refine k1/k2 and independent plane poses with K held fixed.

    For the second-order model, a soft empirical hinge encourages
    |k2| <= 0.5|k1|. It neither fixes k2 to zero nor reads a
    Zhang/reference calibration.
    """
    if radial_order not in {1, 2}:
        raise ValueError(f"Unsupported radial order: {radial_order}")
    fx, fy = float(K[0, 0]), float(K[1, 1])
    cx, cy = float(K[0, 2]), float(K[1, 2])
    normalized_radii = np.concatenate([
        np.hypot(
            (np.asarray(points).reshape(-1, 2)[:, 0] - cx) / fx,
            (np.asarray(points).reshape(-1, 2)[:, 1] - cy) / fy,
        )
        for points in image_groups
    ])
    observed_radius = float(np.percentile(normalized_radii, 95))
    regularization_radius = float(np.clip(observed_radius, 0.25, 0.75))

    values = [float(initial_dist[0])]
    if radial_order == 2:
        values.append(float(np.clip(initial_dist[1], -K2_OPTIMIZATION_BOUND, K2_OPTIMIZATION_BOUND)))
    for rvec, tvec in zip(initial_rvecs, initial_tvecs):
        values.extend(np.asarray(rvec, dtype=np.float64).reshape(3).tolist())
        values.extend(np.asarray(tvec, dtype=np.float64).reshape(3).tolist())
    x0 = np.asarray(values, dtype=np.float64)
    lower = np.full_like(x0, -np.inf)
    upper = np.full_like(x0, np.inf)
    lower[0], upper[0] = -1.0, 1.0
    pose_offset = 1
    if radial_order == 2:
        lower[1], upper[1] = -K2_OPTIMIZATION_BOUND, K2_OPTIMIZATION_BOUND
        pose_offset = 2
    for index in range(len(object_groups)):
        start = pose_offset + 6 * index
        lower[start:start + 3] = -2.0 * math.pi
        upper[start:start + 3] = 2.0 * math.pi
        lower[start + 3:start + 6] = [-10000.0, -10000.0, 1.0]
        upper[start + 3:start + 6] = [10000.0, 10000.0, 20000.0]
    x0 = np.minimum(np.maximum(x0, lower + 1e-7), upper - 1e-7)

    def residual(params: np.ndarray) -> np.ndarray:
        k1 = float(params[0])
        k2 = float(params[1]) if radial_order == 2 else 0.0
        dist = np.array([k1, k2, 0.0, 0.0, 0.0], dtype=np.float64)
        blocks: list[np.ndarray] = []
        for index, (obj, img) in enumerate(zip(object_groups, image_groups)):
            start = pose_offset + 6 * index
            rvec = params[start:start + 3].reshape(3, 1)
            tvec = params[start + 3:start + 6].reshape(3, 1)
            projected, _ = cv2.projectPoints(obj, rvec, tvec, K, dist)
            blocks.append(
                (projected.reshape(-1, 2) - img.reshape(-1, 2)).reshape(-1)
            )
        if radial_order == 2:
            r2 = regularization_radius**2
            first_order_effect = abs(k1) * r2
            second_order_effect = abs(k2) * r2**2
            allowed_k2 = K2_TO_K1_COEFFICIENT_SOFT_LIMIT * abs(k1)
            blocks.append(np.asarray([
                0.0  # Ablation: coefficient-ratio penalty disabled
            ]))
            radii = np.linspace(0.0, max(0.75, regularization_radius), 9)
            derivative = 1.0 + 3.0 * k1 * radii**2 + 5.0 * k2 * radii**4
            blocks.append(
                np.maximum(0.0, 0.10 - derivative)
                / RADIAL_MONOTONIC_HINGE_SIGMA
            )
        return np.concatenate(blocks)

    optimized = least_squares(
        residual,
        x0,
        bounds=(lower, upper),
        loss="soft_l1",
        f_scale=2.0,
        max_nfev=800,
        xtol=1e-10,
        ftol=1e-10,
        gtol=1e-10,
    )
    k1 = float(optimized.x[0])
    k2 = float(optimized.x[1]) if radial_order == 2 else 0.0
    dist = np.array([k1, k2, 0.0, 0.0, 0.0], dtype=np.float64)
    refined_rvecs = []
    refined_tvecs = []
    for index in range(len(object_groups)):
        start = pose_offset + 6 * index
        refined_rvecs.append(optimized.x[start:start + 3].reshape(3, 1))
        refined_tvecs.append(optimized.x[start + 3:start + 6].reshape(3, 1))
    r2 = regularization_radius**2
    return dist, refined_rvecs, refined_tvecs, {
        "method": "ratio_penalty_disabled_monotonicity_retained",
        "coefficient_ratio_penalty_enabled": False,
        "optimizer_success": bool(optimized.success),
        "optimizer_nfev": int(optimized.nfev),
        "observed_radius_p95": observed_radius,
        "regularization_radius": regularization_radius,
        "k1_r2_effect": abs(k1) * r2,
        "k2_r4_effect": abs(k2) * r2**2,
        "k2_to_k1_effect_ratio": (
            None if abs(k1) * r2 < 1e-12
            else abs(k2) * r2**2 / (abs(k1) * r2)
        ),
        "k2_to_k1_coefficient_ratio": (
            None if abs(k1) < 1e-12 else abs(k2) / abs(k1)
        ),
        "coefficient_ratio_soft_limit": K2_TO_K1_COEFFICIENT_SOFT_LIMIT,
        "coefficient_hinge_sigma": K2_COEFFICIENT_HINGE_SIGMA,
        "zhang_reference_used": False,
    }


def _initial_pose(
    sample: CorrespondenceSet,
    K: np.ndarray,
    dist: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    obj = sample.object_points.astype(np.float64).reshape(-1, 1, 3)
    img = sample.image_points.astype(np.float64).reshape(-1, 1, 2)
    for flag in (cv2.SOLVEPNP_ITERATIVE, cv2.SOLVEPNP_EPNP):
        try:
            ok, rvec, tvec = cv2.solvePnP(obj, img, K, dist, flags=flag)
            if ok:
                R, _ = cv2.Rodrigues(rvec)
                depth = (
                    sample.object_points @ R.T + tvec.reshape(1, 3)
                )[:, 2]
                if float(np.mean(depth > 0.0)) >= 0.9:
                    return rvec.reshape(3), tvec.reshape(3)
        except cv2.error:
            continue
    raise RuntimeError(
        f"Could not initialize pose from extracted correspondences: "
        f"{sample.image_path}"
    )


def _unpack_parameters(
    params: np.ndarray,
    n_images: int,
    image_size: tuple[int, int],
    radial_order: int,
) -> tuple[np.ndarray, np.ndarray, list[tuple[np.ndarray, np.ndarray]]]:
    if radial_order not in {1, 2}:
        raise ValueError(f"Unsupported radial order: {radial_order}")
    fx = math.exp(float(params[0]))
    fy = math.exp(float(params[1]))
    width, height = image_size
    cx, cy = float(params[2]), float(params[3])
    K = np.array(
        [[fx, 0.0, cx], [0.0, fy, cy], [0.0, 0.0, 1.0]],
        dtype=np.float64,
    )
    k2 = float(params[5]) if radial_order == 2 else 0.0
    dist = np.array([params[4], k2, 0.0, 0.0, 0.0], dtype=np.float64)
    poses = []
    offset = 4 + radial_order
    for _ in range(n_images):
        poses.append((params[offset:offset + 3], params[offset + 3:offset + 6]))
        offset += 6
    return K, dist, poses


def _joint_residuals(
    params: np.ndarray,
    samples: list[CorrespondenceSet],
    radial_order: int,
) -> np.ndarray:
    K, dist, poses = _unpack_parameters(
        params, len(samples), samples[0].image_size, radial_order
    )
    residuals: list[np.ndarray] = []
    for sample, (rvec, tvec) in zip(samples, poses):
        projected, _ = cv2.projectPoints(
            sample.object_points.reshape(-1, 1, 3),
            rvec.reshape(3, 1),
            tvec.reshape(3, 1),
            K,
            dist,
        )
        residuals.append(
            (projected.reshape(-1, 2) - sample.image_points).reshape(-1)
        )
        R, _ = cv2.Rodrigues(rvec.reshape(3, 1))
        depth = (sample.object_points @ R.T + tvec.reshape(1, 3))[:, 2]
        depth_scale = max(float(np.median(np.abs(depth))), 100.0)
        residuals.append(25.0 * np.maximum(0.0, 1.0 - depth) / depth_scale)
    # Weak camera priors remove degenerate small-data solutions without fixing
    # the principal point or forcing square pixels.  Their scale is broad:
    # the image evidence, not the prior, determines ordinary camera offsets.
    width, height = samples[0].image_size
    principal_sigma_px = (
        PRINCIPAL_POINT_PRIOR_SIGMA_SHORT_SIDE_FRACTION * min(width, height)
    )
    residuals.append(np.asarray([
        math.log(float(K[0, 0]) / float(K[1, 1])) / ASPECT_LOG_RATIO_SIGMA,
        (float(K[0, 2]) - width / 2.0) / principal_sigma_px,
        (float(K[1, 2]) - height / 2.0) / principal_sigma_px,
    ], dtype=np.float64))
    if radial_order == 2:
        k1, k2 = float(dist[0]), float(dist[1])
        # Require the Brown radial mapping to remain locally one-to-one over
        # the normalized radius range covered by this image configuration.
        radius = np.linspace(0.0, 0.75, 9, dtype=np.float64)
        radial_derivative = 1.0 + 3.0 * k1 * radius**2 + 5.0 * k2 * radius**4
        residuals.append(
            np.maximum(0.0, 0.10 - radial_derivative)
            / RADIAL_MONOTONIC_HINGE_SIGMA
        )
    return np.concatenate(residuals)


def _fit_shared_model(
    samples: list[CorrespondenceSet],
    radial_order: int = 1,
    initial_K: Optional[np.ndarray] = None,
    initial_dist: Optional[np.ndarray] = None,
) -> tuple[np.ndarray, np.ndarray, list[dict], dict]:
    if radial_order not in {1, 2}:
        raise ValueError("radial_order must be 1 or 2")
    width, height = samples[0].image_size
    diagonal = math.hypot(width, height)
    generic_K, generic_dist = _initial_shared_model(samples)
    K0 = (
        generic_K if initial_K is None
        else np.asarray(initial_K, dtype=np.float64).reshape(3, 3).copy()
    )
    dist0 = (
        generic_dist if initial_dist is None
        else np.asarray(initial_dist, dtype=np.float64).reshape(-1).copy()
    )
    if dist0.size < 5:
        dist0 = np.pad(dist0, (0, 5 - dist0.size))
    parameters = [
        math.log(float(K0[0, 0])),
        math.log(float(K0[1, 1])),
        float(K0[0, 2]),
        float(K0[1, 2]),
        float(dist0[0]),
    ]
    if radial_order == 2:
        parameters.append(float(dist0[1]))
    for sample in samples:
        rvec, tvec = _initial_pose(sample, K0, dist0)
        parameters.extend(rvec.tolist())
        parameters.extend(tvec.tolist())
    x0 = np.asarray(parameters, dtype=np.float64)

    lower = np.full_like(x0, -np.inf)
    upper = np.full_like(x0, np.inf)
    shared_count = 4 + radial_order
    max_principal_offset = (
        PRINCIPAL_POINT_MAX_OFFSET_SHORT_SIDE_FRACTION * min(width, height)
    )
    lower[:shared_count] = (
        [math.log(0.20 * diagonal), math.log(0.20 * diagonal),
         width / 2.0 - max_principal_offset,
         height / 2.0 - max_principal_offset, -1.0]
        + ([-0.5] if radial_order == 2 else [])
    )
    upper[:shared_count] = (
        [math.log(3.0 * diagonal), math.log(3.0 * diagonal),
         width / 2.0 + max_principal_offset,
         height / 2.0 + max_principal_offset, 1.0]
        + ([0.5] if radial_order == 2 else [])
    )
    for index in range(len(samples)):
        start = shared_count + 6 * index
        lower[start:start + 3] = -2.0 * math.pi
        upper[start:start + 3] = 2.0 * math.pi
        lower[start + 3:start + 6] = [-10000.0, -10000.0, 1.0]
        upper[start + 3:start + 6] = [10000.0, 10000.0, 20000.0]
    x0 = np.minimum(np.maximum(x0, lower + 1e-6), upper - 1e-6)

    optimized = least_squares(
        _joint_residuals,
        x0,
        args=(samples, radial_order),
        bounds=(lower, upper),
        loss="soft_l1",
        f_scale=2.0,
        max_nfev=800,
        xtol=1e-10,
        ftol=1e-10,
        gtol=1e-10,
        verbose=0,
    )
    K, dist, poses = _unpack_parameters(
        optimized.x, len(samples), samples[0].image_size, radial_order
    )
    per_image = []
    all_squared = []
    for sample, (rvec, tvec) in zip(samples, poses):
        projected, _ = cv2.projectPoints(
            sample.object_points.reshape(-1, 1, 3),
            rvec.reshape(3, 1), tvec.reshape(3, 1), K, dist,
        )
        delta = projected.reshape(-1, 2) - sample.image_points
        squared = np.sum(delta * delta, axis=1)
        all_squared.extend(squared.tolist())
        R, _ = cv2.Rodrigues(rvec.reshape(3, 1))
        depth = (sample.object_points @ R.T + tvec.reshape(1, 3))[:, 2]
        per_image.append({
            "image": sample.image_path,
            "n_corners": int(len(sample.image_points)),
            "raw_corner_count": sample.raw_corner_count,
            "geometric_inlier_count": sample.geometric_inlier_count,
            "face_point_counts": sample.face_point_counts,
            "face_inlier_counts": sample.face_inlier_counts,
            "face_grid_spans": sample.face_grid_spans,
            "reprojection_rmse_px": float(np.sqrt(np.mean(squared))),
            "positive_depth_fraction": float(np.mean(depth > 0.0)),
            "source_model": sample.source_model,
            "cube_area_pct": sample.cube_area_pct,
            "corner_quality": sample.corner_quality,
        })
    diagnostics = {
        "radial_order": radial_order,
        "distortion_model": "k1+k2" if radial_order == 2 else "k1-only",
        "optimizer_success": bool(optimized.success),
        "optimizer_status": int(optimized.status),
        "optimizer_message": str(optimized.message),
        "optimizer_nfev": int(optimized.nfev),
        "joint_reprojection_rmse_px": float(np.sqrt(np.mean(all_squared))),
        "median_image_rmse_px": float(np.median([
            item["reprojection_rmse_px"] for item in per_image
        ])),
        "jacobian_condition": (
            None
            if not np.isfinite(np.linalg.cond(optimized.jac))
            else float(np.linalg.cond(optimized.jac))
        ),
    }
    return K, dist, per_image, diagnostics


def _evaluate_fixed_model(
    sample: CorrespondenceSet,
    K: np.ndarray,
    dist: np.ndarray,
) -> dict:
    obj = sample.object_points.reshape(-1, 1, 3).astype(np.float64)
    img = sample.image_points.reshape(-1, 1, 2).astype(np.float64)
    ok, rvec, tvec, inliers = cv2.solvePnPRansac(
        obj,
        img,
        K,
        dist,
        iterationsCount=500,
        reprojectionError=10.0,
        confidence=0.999,
        flags=cv2.SOLVEPNP_EPNP,
    )
    if not ok or inliers is None or len(inliers) < max(12, int(0.5 * len(obj))):
        raise RuntimeError("Fixed-model pose solve did not obtain enough inliers")
    inlier_idx = inliers.reshape(-1)
    rvec, tvec = cv2.solvePnPRefineLM(
        obj[inlier_idx], img[inlier_idx], K, dist, rvec, tvec
    )
    R, _ = cv2.Rodrigues(rvec)
    camera_points = sample.object_points @ R.T + tvec.reshape(1, 3)
    projected, _ = cv2.projectPoints(obj, rvec, tvec, K, dist)
    delta = projected.reshape(-1, 2) - sample.image_points
    return {
        "image": sample.image_path,
        "reprojection_rmse_px": float(
            np.sqrt(np.mean(np.sum(delta * delta, axis=1)))
        ),
        "positive_depth_fraction": float(np.mean(camera_points[:, 2] > 0.0)),
        "pose_inliers": int(len(inliers)),
        "pose_total_points": int(len(obj)),
        "rvec": rvec.reshape(3),
        "tvec": tvec.reshape(3),
        "R": R,
    }


def _leave_one_out_validation(
    samples: list[CorrespondenceSet],
    progress: ProgressCallback,
    radial_order: int = 1,
) -> tuple[list[dict], dict]:
    fold_results = []
    for held_out_index, held_out in enumerate(samples):
        _notify(
            progress,
            f"留一交叉验证 {held_out_index + 1}/{len(samples)}："
            f"{os.path.basename(held_out.image_path)}",
        )
        training_fold = [
            sample for index, sample in enumerate(samples)
            if index != held_out_index
        ]
        try:
            fold_K, fold_dist, _, fold_diagnostics = _fit_shared_model(
                training_fold, radial_order=radial_order
            )
            evaluation = _evaluate_fixed_model(held_out, fold_K, fold_dist)
            fold_results.append({
                "image": held_out.image_path,
                "success": True,
                "reprojection_rmse_px": evaluation["reprojection_rmse_px"],
                "positive_depth_fraction": evaluation["positive_depth_fraction"],
                "pose_inliers": evaluation["pose_inliers"],
                "pose_total_points": evaluation["pose_total_points"],
                "fold_training_rmse_px": fold_diagnostics[
                    "joint_reprojection_rmse_px"
                ],
                "fold_focal_px": float(fold_K[0, 0]),
                "fold_k1": float(fold_dist[0]),
                "fold_k2": float(fold_dist[1]),
            })
        except Exception as exc:
            fold_results.append({
                "image": held_out.image_path,
                "success": False,
                "error": str(exc),
            })
    successful_rmse = [
        item["reprojection_rmse_px"]
        for item in fold_results
        if item.get("success")
    ]
    summary = {
        "strategy": "leave_one_development_image_out",
        "radial_order": radial_order,
        "folds": len(samples),
        "successful_folds": len(successful_rmse),
        "median_reprojection_rmse_px": (
            None if not successful_rmse else float(np.median(successful_rmse))
        ),
        "max_reprojection_rmse_px": (
            None if not successful_rmse else float(np.max(successful_rmse))
        ),
    }
    successful = [item for item in fold_results if item.get("success")]
    if successful:
        k1_values = np.asarray([item["fold_k1"] for item in successful])
        k2_values = np.asarray([item["fold_k2"] for item in successful])
        summary["fold_k1_median"] = float(np.median(k1_values))
        summary["fold_k1_std"] = float(np.std(k1_values))
        summary["fold_k2_median"] = float(np.median(k2_values))
        summary["fold_k2_std"] = float(np.std(k2_values))
        summary["fold_k2_min"] = float(np.min(k2_values))
        summary["fold_k2_max"] = float(np.max(k2_values))
    return fold_results, summary


def _select_shared_cube_geometry(
    raw_samples: list[CorrespondenceSet],
    K_seed: np.ndarray,
    dist_seed: np.ndarray,
    square_size_mm: float,
) -> tuple[float, dict]:
    """Select one cube side for the complete development fold.

    The side length is a target property, so one value is scored across all
    poses.  It is never selected independently for each photograph.
    """
    candidates = []
    for side in np.arange(10.0, 12.01, 0.5):
        image_scores = []
        for raw in raw_samples:
            detail: dict = {}
            repaired = _repair_face_grid_association(
                raw, K_seed, dist_seed, float(square_size_mm),
                diagnostics=detail, cube_side_squares=float(side),
                max_initial_rmse_px=35.0,
                max_initial_face_rmse_px=50.0,
            )
            if repaired is not None:
                image_scores.append(float(repaired.association_rmse_px))
        candidates.append({
            "cube_side_squares": float(side),
            "successful_images": int(len(image_scores)),
            "median_association_rmse_px": (
                None if not image_scores else float(np.median(image_scores))
            ),
            "max_association_rmse_px": (
                None if not image_scores else float(np.max(image_scores))
            ),
        })
    selected = min(
        candidates,
        key=lambda item: (
            -item["successful_images"],
            float("inf") if item["median_association_rmse_px"] is None
            else item["median_association_rmse_px"],
        ),
    )
    if selected["successful_images"] < max(2, len(raw_samples) // 2):
        raise RuntimeError(
            "No single rigid cube geometry was supported by enough development images"
        )
    return float(selected["cube_side_squares"]), {
        "selection_scope": "one_shared_geometry_for_complete_development_fold",
        "per_image_geometry_changes_allowed": False,
        "candidate_scores": candidates,
        "selected_cube_side_squares": float(selected["cube_side_squares"]),
        "selected_cube_side_mm": float(selected["cube_side_squares"] * square_size_mm),
    }


def _repair_training_samples(
    raw_samples: list[CorrespondenceSet],
    fallback_samples: list[CorrespondenceSet],
    K_seed: np.ndarray,
    dist_seed: np.ndarray,
    square_size_mm: float,
    cube_side_squares: Optional[float] = None,
) -> tuple[list[CorrespondenceSet], list[dict]]:
    """Recover face associations using only a reference-free seed model.

    A failed repair falls back to the conservative generic-camera consensus
    sample.  Thus association recovery can add radial/three-face evidence but
    can never make a previously usable development image disappear.
    """
    fallback_by_path = {sample.image_path: sample for sample in fallback_samples}
    repaired_samples: list[CorrespondenceSet] = []
    repair_details: list[dict] = []
    for raw in raw_samples:
        detail: dict = {"image": raw.image_path}
        repaired = _repair_face_grid_association(
            raw, K_seed, dist_seed, float(square_size_mm), diagnostics=detail,
            cube_side_squares=(
                None if cube_side_squares is None else float(cube_side_squares)
            ),
            max_initial_rmse_px=35.0,
            max_initial_face_rmse_px=50.0,
        )
        if repaired is not None:
            try:
                # Discrete grid repair deliberately generates a generous
                # correspondence set.  Keep only points that also agree with
                # one rigid cube pose under the fold-local seed camera.  This
                # prevents a few plausible-looking grid aliases from being
                # absorbed by k2 during bundle adjustment.
                repaired = _geometric_inlier_filter(
                    repaired,
                    focal_hint_px=float(K_seed[0, 0]),
                    k1_hint=float(dist_seed[0]),
                    minimum_usable_faces=2,
                    square_size_mm=float(square_size_mm),
                    cube_side_squares_hint=(
                        None if cube_side_squares is None
                        else float(cube_side_squares)
                    ),
                )
                repaired_samples.append(repaired)
                detail["used_for_fit"] = (
                    "repaired_association_then_rigid_consensus_inliers"
                )
                detail["rigid_inlier_count"] = repaired.geometric_inlier_count
                detail["rigid_face_inliers"] = list(
                    repaired.face_inlier_counts or (0, 0, 0)
                )
            except Exception as exc:
                repaired = None
                detail["post_repair_consensus_error"] = str(exc)
        if repaired is None:
            fallback = fallback_by_path.get(raw.image_path)
            if fallback is None:
                detail["used_for_fit"] = "unavailable"
                repair_details.append(detail)
                continue
            repaired_samples.append(fallback)
            detail["used_for_fit"] = "generic_consensus_fallback"
        repair_details.append(detail)
    return repaired_samples, repair_details


def _radial_coverage(
    samples: list[CorrespondenceSet], K: np.ndarray
) -> dict:
    radii = []
    fx, fy = float(K[0, 0]), float(K[1, 1])
    cx, cy = float(K[0, 2]), float(K[1, 2])
    for sample in samples:
        points = np.asarray(sample.image_points, dtype=np.float64).reshape(-1, 2)
        radii.extend(np.hypot((points[:, 0] - cx) / fx, (points[:, 1] - cy) / fy))
    values = np.asarray(radii, dtype=np.float64)
    if values.size == 0:
        return {"point_count": 0, "sufficient_for_k2": False}
    return {
        "point_count": int(values.size),
        "radius_median": float(np.median(values)),
        "radius_p90": float(np.percentile(values, 90)),
        "radius_p95": float(np.percentile(values, 95)),
        "radius_max": float(np.max(values)),
        "fraction_radius_gt_0_4": float(np.mean(values > 0.4)),
        "fraction_radius_gt_0_5": float(np.mean(values > 0.5)),
        "sufficient_for_k2": bool(
            float(np.max(values)) >= 0.45 and float(np.mean(values > 0.4)) >= 0.10
        ),
    }


def _nested_leave_one_out_validation(
    raw_samples: list[CorrespondenceSet],
    generic_samples: list[CorrespondenceSet],
    square_size_mm: float,
    progress: ProgressCallback,
    radial_order: int,
) -> tuple[list[dict], dict]:
    """LOO validation that repeats seed fitting and association repair per fold."""
    fold_results = []
    for held_out_index, held_out_raw in enumerate(raw_samples):
        _notify(
            progress,
            f"嵌套留一验证 {held_out_index + 1}/{len(raw_samples)}: "
            f"{os.path.basename(held_out_raw.image_path)}",
        )
        train_raw = [s for i, s in enumerate(raw_samples) if i != held_out_index]
        train_generic = [
            s for i, s in enumerate(generic_samples) if i != held_out_index
        ]
        held_out_generic = generic_samples[held_out_index]
        try:
            fold_K, fold_dist, fold_diag = _fit_partial_planar_model(
                train_raw, square_size_mm, radial_order
            )
            repaired_train, train_repairs = _repair_training_samples(
                train_raw, train_generic, fold_K, fold_dist, square_size_mm,
                None,
            )
            repaired_held, held_repairs = _repair_training_samples(
                [held_out_raw], [held_out_generic], fold_K, fold_dist,
                square_size_mm, None,
            )
            if not repaired_held:
                raise RuntimeError("Held-out association recovery produced no sample")
            evaluation = _evaluate_fixed_model(repaired_held[0], fold_K, fold_dist)
            fold_results.append({
                "image": held_out_raw.image_path,
                "success": True,
                "reprojection_rmse_px": evaluation["reprojection_rmse_px"],
                "positive_depth_fraction": evaluation["positive_depth_fraction"],
                "pose_inliers": evaluation["pose_inliers"],
                "pose_total_points": evaluation["pose_total_points"],
                "fold_seed_rmse_px": fold_diag["joint_reprojection_rmse_px"],
                "fold_local_homography_seed": fold_diag["homography"],
                "fold_training_rmse_px": fold_diag["joint_reprojection_rmse_px"],
                "fold_focal_px": float(fold_K[0, 0]),
                "fold_k1": float(fold_dist[0]),
                "fold_k2": float(fold_dist[1]),
                "fold_target_geometry": {
                    "scope": "measured_rectangular_cuboid_320x220x240",
                    "shared_across_images": True,
                    "per_face_shifts_allowed": False,
                    "extents_mm_xyz": list(TARGET_EXTENTS_MM),
                },
                "training_association_repairs": train_repairs,
                "held_out_association_repair": held_repairs[0],
            })
        except Exception as exc:
            fold_results.append({
                "image": held_out_raw.image_path,
                "success": False,
                "error": str(exc),
            })
    successful = [item for item in fold_results if item.get("success")]
    rmse = [item["reprojection_rmse_px"] for item in successful]
    summary = {
        "strategy": "nested_leave_one_development_image_out_with_fold_local_repair",
        "radial_order": radial_order,
        "folds": len(raw_samples),
        "successful_folds": len(successful),
        "median_reprojection_rmse_px": None if not rmse else float(np.median(rmse)),
        "max_reprojection_rmse_px": None if not rmse else float(np.max(rmse)),
        "association_seed_leakage_prevented": True,
    }
    if successful:
        for coefficient in ("k1", "k2"):
            values = np.asarray(
                [item[f"fold_{coefficient}"] for item in successful],
                dtype=np.float64,
            )
            summary[f"fold_{coefficient}_median"] = float(np.median(values))
            summary[f"fold_{coefficient}_std"] = float(np.std(values))
            summary[f"fold_{coefficient}_min"] = float(np.min(values))
            summary[f"fold_{coefficient}_max"] = float(np.max(values))
    return fold_results, summary


def _base_candidate_accepted(
    K: np.ndarray,
    diagnostics: dict,
    per_image: list[dict],
    cross_validation: dict,
    n_samples: int,
) -> bool:
    return bool(
        diagnostics["optimizer_success"]
        and diagnostics["joint_reprojection_rmse_px"] <= 8.0
        and all(item["positive_depth_fraction"] >= 0.99 for item in per_image)
        and cross_validation["successful_folds"] == n_samples
        and cross_validation["median_reprojection_rmse_px"] is not None
        and cross_validation["median_reprojection_rmse_px"] <= 8.0
        and cross_validation["max_reprojection_rmse_px"] <= 12.0
    )


def _k2_stability(dist: np.ndarray, cross_validation: dict) -> dict:
    full_k2 = float(dist[1])
    median = cross_validation.get("fold_k2_median")
    std = cross_validation.get("fold_k2_std")
    minimum = cross_validation.get("fold_k2_min")
    maximum = cross_validation.get("fold_k2_max")
    if None in {median, std, minimum, maximum}:
        return {
            "stable": False,
            "reason": "No complete fold-wise k2 statistics were available.",
        }
    # An absolute repeatability limit is deliberate here.  The former relative
    # tolerance grew with |k2|, so an oversized coefficient was paradoxically
    # allowed to vary more between leave-one-out folds.  k2 is accepted only
    # when the five-shot estimate itself is repeatable in normalized units.
    allowed_std = 0.08
    span = float(maximum) - float(minimum)
    away_from_bound = abs(full_k2) < 0.95 * K2_OPTIMIZATION_BOUND
    stable = bool(float(std) <= allowed_std and span <= 0.35 and away_from_bound)
    failure_reasons = []
    if float(std) > allowed_std:
        failure_reasons.append(
            f"leave-one-out k2 std {float(std):.6f} exceeds {allowed_std:.6f}"
        )
    if span > 0.35:
        failure_reasons.append(
            f"leave-one-out k2 span {span:.6f} exceeds 0.350000"
        )
    if not away_from_bound:
        failure_reasons.append(
            f"full k2 {full_k2:.6f} approaches optimization bound "
            f"+/-{K2_OPTIMIZATION_BOUND:.6f}"
        )
    relative_repeatability = float(std) / max(abs(float(median)), 0.05)
    return {
        "stable": stable,
        "full_model_k2": full_k2,
        "fold_median": float(median),
        "fold_std": float(std),
        "fold_min": float(minimum),
        "fold_max": float(maximum),
        "fold_span": span,
        "allowed_std": allowed_std,
        "relative_repeatability": relative_repeatability,
        "away_from_parameter_bound": away_from_bound,
        "reason": (
            "Fold-wise k2 remained within the configured stability limits."
            if stable
            else "; ".join(failure_reasons)
        ),
    }


def _fit_model_candidate(
    raw_samples: list[CorrespondenceSet],
    generic_samples: list[CorrespondenceSet],
    square_size_mm: float,
    radial_order: int,
    progress: ProgressCallback,
) -> dict:
    label = "k1+k2" if radial_order == 2 else "k1-only"
    _notify(progress, f"拟合候选畸变模型：{label}")
    K, dist, planar_diagnostics = _fit_partial_planar_model(
        raw_samples, square_size_mm, radial_order
    )
    repaired_samples, repair_details = _repair_training_samples(
        raw_samples, generic_samples, K, dist, square_size_mm,
        None,
    )
    target_geometry = {
        "scope": "measured_rectangular_cuboid_320x220x240",
        "shared_across_images": True,
        "shared_within_each_image": True,
        "per_face_shifts_allowed": False,
        "right_angle_faces_required": True,
        "extents_mm_xyz": list(TARGET_EXTENTS_MM),
        "face_patterns_inner_corners": [list(v) for v in CANONICAL_FACE_PATTERNS],
        "corner_lattice_offsets_mm": TARGET_CORNER_OFFSETS_MM,
        "measured_face_vertex_to_grid_vertex_cm": {
            "xoy": {"left_top": 7.1, "left_bottom": 7.0,
                    "right_top": 7.9, "right_bottom": 8.0},
            "xoz": {"left_top": 7.4, "left_bottom": 8.0,
                    "right_top": 8.0, "right_bottom": 9.0},
            "yoz": {"left_top": 6.3, "left_bottom": 6.3,
                    "right_top": 8.0, "right_bottom": 7.2},
        },
        "corner_offset_reconstruction": (
            "constrained least squares using face dimensions and corner spans"
        ),
    }
    per_image = []
    weighted_squared_error = 0.0
    total_points = 0
    for sample in repaired_samples:
        evaluation = _evaluate_fixed_model(sample, K, dist)
        count = len(sample.image_points)
        weighted_squared_error += evaluation["reprojection_rmse_px"] ** 2 * count
        total_points += count
        per_image.append({
            "image": sample.image_path,
            "n_corners": count,
            "raw_corner_count": sample.raw_corner_count,
            "geometric_inlier_count": sample.geometric_inlier_count,
            "face_point_counts": sample.face_point_counts,
            "face_inlier_counts": sample.face_inlier_counts,
            "face_grid_spans": sample.face_grid_spans,
            "reprojection_rmse_px": evaluation["reprojection_rmse_px"],
            "positive_depth_fraction": evaluation["positive_depth_fraction"],
            "source_model": sample.source_model,
            "cube_area_pct": sample.cube_area_pct,
            "corner_quality": sample.corner_quality,
        })
    diagnostics = {
        **planar_diagnostics,
        "radial_order": radial_order,
        "distortion_model": "k1+k2" if radial_order == 2 else "k1-only",
        "joint_reprojection_rmse_px": float(math.sqrt(
            weighted_squared_error / max(total_points, 1)
        )),
        "median_image_rmse_px": float(np.median([
            item["reprojection_rmse_px"] for item in per_image
        ])),
    }
    fold_results, cross_validation = _nested_leave_one_out_validation(
        raw_samples, generic_samples, square_size_mm, progress,
        radial_order=radial_order,
    )
    width, height = raw_samples[0].image_size
    max_principal_offset = (
        PRINCIPAL_POINT_MAX_OFFSET_SHORT_SIDE_FRACTION * min(width, height)
    )
    intrinsic_plausibility = {
        "principal_point_x_offset_px": float(abs(K[0, 2] - width / 2.0)),
        "principal_point_y_offset_px": float(abs(K[1, 2] - height / 2.0)),
        "principal_point_x_offset_fraction": float(
            abs(K[0, 2] - width / 2.0) / width
        ),
        "principal_point_y_offset_fraction": float(
            abs(K[1, 2] - height / 2.0) / height
        ),
        "focal_aspect_ratio": float(K[0, 0] / K[1, 1]),
    }
    intrinsic_plausibility["accepted"] = bool(
        intrinsic_plausibility["principal_point_x_offset_px"]
        < max_principal_offset - 1.0
        and intrinsic_plausibility["principal_point_y_offset_px"]
        < max_principal_offset - 1.0
        and 0.95 <= intrinsic_plausibility["focal_aspect_ratio"] <= 1.05
    )
    base_accepted = _base_candidate_accepted(
        K, diagnostics, per_image, cross_validation, len(raw_samples)
    ) and intrinsic_plausibility["accepted"]
    stability = (
        _k2_stability(dist, cross_validation)
        if radial_order == 2
        else {"stable": True, "reason": "k2 is not estimated in this candidate."}
    )
    return {
        "key": DISTORTION_MODE_K1_K2 if radial_order == 2 else DISTORTION_MODE_K1,
        "label": label,
        "radial_order": radial_order,
        "K": K,
        "dist": dist,
        "per_image": per_image,
        "diagnostics": diagnostics,
        "cross_validation": cross_validation,
        "cross_validation_folds": fold_results,
        "seed_diagnostics": planar_diagnostics,
        "local_homography_seed": planar_diagnostics["homography"],
        "association_repairs": repair_details,
        "target_geometry": target_geometry,
        "intrinsic_plausibility": intrinsic_plausibility,
        "radial_coverage": _radial_coverage(repaired_samples, K),
        "base_quality_accepted": base_accepted,
        "k2_stability": stability,
        "accepted": bool(base_accepted and stability["stable"]),
    }


def _select_candidate(candidates: dict[str, dict], requested: str) -> tuple[dict, str]:
    if requested != DISTORTION_MODE_AUTO:
        selected = candidates[requested]
        return selected, f"User requested the {selected['label']} candidate."

    k1 = candidates[DISTORTION_MODE_K1]
    k12 = candidates[DISTORTION_MODE_K1_K2]
    if k12["accepted"] and not k1["accepted"]:
        return k12, "k1+k2 passed all gates while k1-only did not."
    if k1["accepted"] and not k12["accepted"]:
        return k1, "k1-only passed; k1+k2 failed quality or coefficient stability."
    if k1["accepted"] and k12["accepted"]:
        median1 = k1["cross_validation"]["median_reprojection_rmse_px"]
        median2 = k12["cross_validation"]["median_reprojection_rmse_px"]
        max1 = k1["cross_validation"]["max_reprojection_rmse_px"]
        max2 = k12["cross_validation"]["max_reprojection_rmse_px"]
        median_gain = float(median1) - float(median2)
        max_gain = float(max1) - float(max2)
        coverage = k12.get("radial_coverage", {})
        consistent_gain = median_gain >= 0.0 and max_gain >= 0.0
        if (
            median_gain >= 0.15
            or (max_gain >= 0.5 and median2 <= median1 + 0.15)
            or (coverage.get("sufficient_for_k2", False) and consistent_gain)
        ):
            return k12, (
                "k1+k2 passed coefficient stability, had adequate radial coverage, "
                "and improved both held-out statistics "
                f"(median gain {median_gain:.3f}px, max gain {max_gain:.3f}px)."
            )
        return k1, (
            "Both candidates passed, but k1+k2 did not improve held-out error "
            "enough to justify the additional coefficient."
        )

    def score(candidate: dict) -> float:
        value = candidate["cross_validation"].get("median_reprojection_rmse_px")
        return float("inf") if value is None else float(value)

    selected = min((k1, k12), key=score)
    return selected, (
        "Neither candidate passed all release gates; the lower-median candidate "
        "is saved for diagnosis only."
    )


def train_camera_model(
    image_paths: Iterable[str],
    square_size_mm: float,
    output_path: str,
    *,
    progress: ProgressCallback = None,
    distortion_model: str = DISTORTION_MODE_AUTO,
    minimum_multi_face_images: int = 4,
) -> dict:
    requested_mode = str(distortion_model).strip().lower()
    if requested_mode not in {
        DISTORTION_MODE_AUTO, DISTORTION_MODE_K1, DISTORTION_MODE_K1_K2
    }:
        raise ValueError(
            "distortion_model must be 'auto', 'k1', or 'k1_k2'"
        )
    paths = [str(Path(path).resolve()) for path in image_paths]
    if len(paths) < 4:
        raise ValueError("At least four development images are required")
    if any("zhang" in {part.lower() for part in Path(path).parts} for path in paths):
        raise ValueError("Zhang/reference images are forbidden in model training")

    samples: list[CorrespondenceSet] = []
    raw_samples: list[CorrespondenceSet] = []
    failures = []
    auxiliary_single_face_images: list[str] = []
    multi_face_images: list[str] = []
    expected_size: Optional[tuple[int, int]] = None
    cache_dir = Path(output_path).resolve().parent / ".trihedral_correspondence_cache"
    for index, path in enumerate(paths, start=1):
        _notify(progress, f"提取开发图 {index}/{len(paths)}：{os.path.basename(path)}")
        try:
            content_hash = _sha256(path)
            square_tag = f"{float(square_size_mm):.9g}".replace(".", "p")
            cache_path = cache_dir / (
                f"{content_hash}_sq{square_tag}_{CORRESPONDENCE_CACHE_TAG}.npz"
            )
            try:
                sample = extract_correspondences(
                    path,
                    square_size_mm,
                    correspondence_cache_path=str(cache_path),
                    minimum_usable_faces=2,
                )
            except Exception as multi_face_error:
                if not cache_path.is_file():
                    raise
                raw_for_auxiliary = _load_cache(str(cache_path), path, None)
                try:
                    sample = _geometric_inlier_filter(
                        raw_for_auxiliary,
                        minimum_usable_faces=1,
                        square_size_mm=float(square_size_mm),
                    )
                except Exception as single_face_error:
                    raise RuntimeError(
                        f"Multi-face gate failed: {multi_face_error}; "
                        f"single-face auxiliary gate also failed: "
                        f"{single_face_error}"
                    ) from single_face_error
                sample = replace(
                    sample,
                    source_model="single_face_auxiliary_training_evidence",
                )
            if expected_size is None:
                expected_size = sample.image_size
            if sample.image_size != expected_size:
                raise RuntimeError(
                    f"Image size {sample.image_size} does not match {expected_size}"
                )
            raw_sample = _load_cache(str(cache_path), path, None)
            samples.append(sample)
            raw_samples.append(raw_sample)
            if _sample_training_face_count(sample) >= 2:
                multi_face_images.append(path)
            else:
                auxiliary_single_face_images.append(path)
        except Exception as exc:
            failures.append({"image": path, "error": str(exc)})
    if len(samples) < 4:
        raise RuntimeError(
            f"Only {len(samples)} usable development images were extracted; "
            "at least four are required"
        )
    minimum_multi_face_images = int(minimum_multi_face_images)
    if not 0 <= minimum_multi_face_images <= len(paths):
        raise ValueError("minimum_multi_face_images is outside the development-set size")
    if len(multi_face_images) < minimum_multi_face_images:
        raise RuntimeError(
            "Only "
            f"{len(multi_face_images)} development images passed the two-face "
            f"gate; at least {minimum_multi_face_images} are required. "
            "Single-face images are only auxiliary evidence."
        )

    _notify(progress, f"联合优化共享内参与畸变：{len(samples)} 张有效图片")
    orders = [1, 2] if requested_mode == DISTORTION_MODE_AUTO else [
        2 if requested_mode == DISTORTION_MODE_K1_K2 else 1
    ]
    candidates = {}
    for radial_order in orders:
        candidate = _fit_model_candidate(
            raw_samples, samples, float(square_size_mm), radial_order, progress
        )
        candidates[candidate["key"]] = candidate
    selected, selection_reason = _select_candidate(candidates, requested_mode)
    K = selected["K"]
    dist = selected["dist"]
    per_image = selected["per_image"]
    diagnostics = selected["diagnostics"]
    cross_validation = selected["cross_validation"]
    fold_results = selected["cross_validation_folds"]
    accepted = selected["accepted"]

    candidate_comparison = {}
    for key, candidate in candidates.items():
        candidate_comparison[key] = {
            "label": candidate["label"],
            "radial_order": candidate["radial_order"],
            "accepted": candidate["accepted"],
            "base_quality_accepted": candidate["base_quality_accepted"],
            "cameraMatrix": candidate["K"].tolist(),
            "distCoeffs": candidate["dist"].tolist(),
            "diagnostics": candidate["diagnostics"],
            "cross_validation": candidate["cross_validation"],
            "k2_stability": candidate["k2_stability"],
            "radial_coverage": candidate["radial_coverage"],
            "seed_diagnostics": candidate["seed_diagnostics"],
            "local_homography_seed": candidate["local_homography_seed"],
            "association_repairs": candidate["association_repairs"],
            "target_geometry": candidate["target_geometry"],
            "intrinsic_plausibility": candidate["intrinsic_plausibility"],
        }
    model = {
        "schema": MODEL_SCHEMA,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "training_method": (
            "partial_face_homographies_with_k2_ratio_prior_and_cuboid_validation"
        ),
        "training_scope": "camera_specific_few_shot_model",
        "no_zhang_reference_used": True,
        "training_inputs": (
            "reference_free_partial_homographies_plus_per_image_cuboid_validation"
        ),
        "target_geometry": selected["target_geometry"],
        "correspondence_filter": {
            "method": "reference_free_generic_camera_pnp_ransac",
            "reprojection_threshold_px": 5.0,
            "minimum_inliers_per_usable_face": MIN_FACE_INLIERS,
            "minimum_grid_columns_per_usable_face": MIN_GRID_COLS,
            "minimum_grid_rows_per_usable_face": MIN_GRID_ROWS,
            "training_only_elongated_face_exception": (
                "at least 6x3 grid span and at least 18 inliers"
            ),
            "formal_inference_gate_unchanged": "at least 4x4 grid span",
            "minimum_total_inliers_by_usable_faces": (
                MIN_TOTAL_INLIERS_BY_FACE_COUNT
            ),
            "minimum_usable_faces": 2,
            "training_focal_initialization": "0.70_image_diagonal",
            "zhang_reference_used": False,
            "association_repair_seed": "development_fold_only_partial_planar_model",
            "partial_local_homographies_used": True,
            "absolute_grid_indices_required_for_homography_seed": False,
            "plumbline_distortion_seed": True,
            "nested_validation_repeats_complete_pipeline": True,
            "one_shared_rigid_cube_geometry": False,
            "one_shared_measured_cuboid_geometry": True,
            "independent_rigid_cube_coordinate_frame_per_image": False,
            "per_image_face_shifts_allowed": False,
            "absolute_grid_index_method": (
                "visible_face_boundary_plus_rigid_three_face_consensus"
            ),
            "synthetic_missing_corners_used": False,
            "ambiguous_partial_grid_rejected": True,
        },
        "calibration_seed_parameters_ignored": True,
        "distortion_model_requested": requested_mode,
        "distortion_model_selected": selected["key"],
        "distortion_model_selection_reason": selection_reason,
        "candidate_comparison": candidate_comparison,
        "square_size_mm": float(square_size_mm),
        "image_size": list(expected_size or samples[0].image_size),
        "cameraMatrix": K.tolist(),
        "distCoeffs": dist.tolist(),
        "distCoeffsOrder": "k1,k2,p1,p2,k3",
        "constraints": {
            "square_pixels": False,
            "fx_fy_estimated_separately": True,
            "fx_fy_log_ratio_weak_prior_sigma": ASPECT_LOG_RATIO_SIGMA,
            "zero_skew": True,
            "principal_point_fixed_to_image_center": False,
            "principal_point_prior_sigma_short_side_fraction": (
                PRINCIPAL_POINT_PRIOR_SIGMA_SHORT_SIDE_FRACTION
            ),
            "principal_point_max_offset_short_side_fraction": (
                PRINCIPAL_POINT_MAX_OFFSET_SHORT_SIDE_FRACTION
            ),
            "zero_tangential_distortion": True,
            "estimated_k2_distortion": selected["radial_order"] == 2,
            "zero_k2_distortion": selected["radial_order"] == 1,
            "zero_k3_distortion": True,
            "radial_mapping_monotonicity_soft_constraint": True,
            "k2_required_for_formal_five_shot_model": (
                requested_mode == DISTORTION_MODE_K1_K2
            ),
            "k2_to_k1_coefficient_soft_limit": (
                K2_TO_K1_COEFFICIENT_SOFT_LIMIT
            ),
            "k2_coefficient_hinge_sigma": K2_COEFFICIENT_HINGE_SIGMA,
            "k2_raw_coefficient_ratio_constraint": "none",
            "shared_intrinsics_across_training_images": True,
            "independent_pose_per_training_image": True,
            "shared_target_geometry_across_training_images": False,
            "measured_cuboid_geometry_used_for_association_and_pose_validation": True,
            "positive_depth_required": True,
        },
        "accepted": accepted,
        "diagnostics": diagnostics,
        "quality_gates": {
            "training_joint_rmse_max_px": 8.0,
            "leave_one_out_median_rmse_max_px": 8.0,
            "leave_one_out_max_rmse_max_px": 12.0,
            "all_positive_depth_required": True,
            "k2_fold_std_limit": "max(0.08, 0.75*abs(fold_median_k2))",
            "k2_fold_span_max": 0.35,
            "auto_k2_median_improvement_min_px": 0.15,
            "auto_k2_max_improvement_min_px": 0.5,
            "auto_k2_radial_coverage_alternative": (
                "radius_max>=0.45 and fraction_radius>0.4>=0.10 and both "
                "held-out median/max errors improve"
            ),
        },
        "cross_validation": cross_validation,
        "cross_validation_folds": fold_results,
        "training_images_requested": len(paths),
        "training_images_used": len(samples),
        "training_images_failed": failures,
        "training_multi_face_images": len(multi_face_images),
        "minimum_multi_face_images_required": minimum_multi_face_images,
        "training_single_face_auxiliary_images": len(
            auxiliary_single_face_images
        ),
        "single_face_auxiliary_policy": (
            "may constrain shared intrinsics/distortion; cannot count as "
            "multi-face or three-face validation success"
        ),
        "training_images": [
            {
                **item,
                "sha256": _sha256(item["image"]),
            }
            for item in per_image
        ],
    }
    save_camera_model(model, output_path)
    _notify(progress, f"模型已保存：{output_path}")
    return model


def _finite_json_value(value):
    """Convert diagnostic non-finite numbers to strict-JSON null values."""
    if isinstance(value, dict):
        return {key: _finite_json_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_finite_json_value(item) for item in value]
    if isinstance(value, (float, np.floating)):
        return float(value) if math.isfinite(float(value)) else None
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.ndarray):
        return _finite_json_value(value.tolist())
    return value


def save_camera_model(model: dict, path: str) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp_path = destination.with_suffix(destination.suffix + ".tmp")
    with open(temp_path, "w", encoding="utf-8") as handle:
        json.dump(
            _finite_json_value(model),
            handle,
            ensure_ascii=False,
            indent=2,
            allow_nan=False,
        )
    os.replace(temp_path, destination)


def load_camera_model(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as handle:
        model = json.load(handle)
    if model.get("schema") != MODEL_SCHEMA:
        raise ValueError(
            "训练模型版本与当前检测器不兼容，必须重新训练。"
            f" 当前代码要求 {MODEL_SCHEMA}，模型文件是 "
            f"{model.get('schema')}。本次版本修正了第三面 7x6 内角点规格，"
            "旧模型不能继续用于正式标定。"
        )
    K = np.asarray(model.get("cameraMatrix"), dtype=np.float64)
    dist = np.asarray(model.get("distCoeffs"), dtype=np.float64).reshape(-1)
    if K.shape != (3, 3) or dist.size != 5:
        raise ValueError("Invalid camera matrix or distortion vector in model")
    if not np.all(np.isfinite(K)) or not np.all(np.isfinite(dist)):
        raise ValueError("Trained model contains non-finite parameters")
    if not model.get("no_zhang_reference_used", False):
        raise ValueError("Model is not marked as reference-free training")
    return model


def infer_with_camera_model(
    image_path: str,
    model: dict,
    *,
    square_size_mm: Optional[float] = None,
    progress: ProgressCallback = None,
    correspondence_cache_dir: Optional[str] = None,
) -> BestResult:
    K = np.asarray(model["cameraMatrix"], dtype=np.float64).reshape(3, 3)
    dist = np.asarray(model["distCoeffs"], dtype=np.float64).reshape(5)
    trained_square = float(model["square_size_mm"])
    square = float(trained_square if square_size_mm is None else square_size_mm)
    if not math.isclose(square, trained_square, rel_tol=0.0, abs_tol=1e-9):
        raise ValueError(
            f"Square size {square:g} mm does not match trained model value "
            f"{trained_square:g} mm"
        )
    _notify(progress, "使用已训练内参提取单张图片的三面几何")
    inference_cache_path = None
    if correspondence_cache_dir:
        content_hash = _sha256(image_path)
        square_tag = f"{float(square):.9g}".replace(".", "p")
        inference_cache_path = str(
            Path(correspondence_cache_dir)
            / f"{content_hash}_sq{square_tag}_{CORRESPONDENCE_CACHE_TAG}.npz"
        )
    target_geometry = model.get("target_geometry", {})
    fixed_cube_side = target_geometry.get("selected_cube_side_squares")
    sample = extract_correspondences(
        image_path,
        square,
        focal_hint_px=float(K[0, 0]),
        k1_hint=float(dist[0]),
        correspondence_cache_path=inference_cache_path,
        # The camera matrix is already frozen here.  One reliable planar face
        # is sufficient to recover pose, but it is explicitly reported as
        # partial evidence and is not treated as a three-face blind-test pass.
        minimum_usable_faces=1,
        cube_side_squares_hint=(
            None if fixed_cube_side is None else float(fixed_cube_side)
        ),
        allow_independent_cube_search=bool(
            target_geometry.get("scope") in {
                "independent_rigid_cube_per_image",
                "measured_rectangular_cuboid_320x220x240",
            }
        ),
    )
    expected_size = tuple(int(v) for v in model["image_size"])
    if sample.image_size != expected_size:
        raise ValueError(
            f"Image size {sample.image_size} does not match trained model "
            f"size {expected_size}"
        )
    _notify(progress, "固定已训练内参与畸变，求解当前单张图片位姿")
    evaluation = _evaluate_fixed_model(sample, K, dist)
    rvec = evaluation["rvec"]
    tvec = evaluation["tvec"]
    R = evaluation["R"]
    if evaluation["positive_depth_fraction"] < 0.99:
        raise RuntimeError("Trained-model pose failed the positive-depth gate")
    rmse = evaluation["reprojection_rmse_px"]
    cam_pos, height, downtilt = _cube_camera_pose_metrics(R, tvec.reshape(3))
    face_inliers = tuple(sample.face_inlier_counts or (0, 0, 0))
    usable_face_count = _sample_usable_face_count(sample)
    evidence_level = (
        "three_face_consensus"
        if usable_face_count >= 3
        else "multi_face_consensus"
        if usable_face_count == 2
        else "single_face_pose_only"
    )
    preflight = {
        "method_profile": "few_shot_trained_camera_model",
        "method_scope": "single_image_inference_with_frozen_camera_model",
        "uses_intrinsic_prior": True,
        "intrinsic_prior_source": "trained_development_images",
        "no_zhang_reference_used_in_training": True,
        "trained_model_schema": model["schema"],
        "trained_model_created_utc": model.get("created_utc"),
        "trained_model_training_images": model.get("training_images_used"),
        "distortion_model_requested": model.get("distortion_model_requested"),
        "distortion_model_selected": model.get("distortion_model_selected"),
        "distortion_model_selection_reason": model.get(
            "distortion_model_selection_reason"
        ),
        "pose_inliers": evaluation["pose_inliers"],
        "pose_total_points": evaluation["pose_total_points"],
        "geometric_face_inliers": list(face_inliers),
        "geometric_face_grid_spans": [
            list(v) for v in (
                sample.face_grid_spans or ((0, 0), (0, 0), (0, 0))
            )
        ],
        "minimum_face_inliers": MIN_FACE_INLIERS,
        "minimum_face_grid_span": [MIN_GRID_COLS, MIN_GRID_ROWS],
        "geometric_faces_used": usable_face_count,
        "face_grid_association_repaired": bool(sample.association_repaired),
        "face_grid_association_rmse_px": sample.association_rmse_px,
        "face_boundary_error_px": sample.association_boundary_error_px,
        "face_checker_photometric_error": sample.association_photometric_error,
        "face_grid_association_score_gap": sample.association_score_gap,
        "face_boundary_used_for_absolute_grid_index": bool(
            sample.association_boundary_error_px is not None
        ),
        "inference_evidence_level": evidence_level,
        "three_face_blind_test_pass": bool(usable_face_count >= 3),
    }
    warnings = [
        "Loaded a camera-specific model trained only from development "
        "cube images; no Zhang/reference parameters were used.",
        "The saved intrinsics/distortion are fixed; this single image "
        "contributes target pose and reprojection validation.",
    ]
    if usable_face_count == 1:
        warnings.append(
            "Only one checker face passed rigid-consensus extraction.  The "
            "frozen camera matrix remains usable, but this frame is partial "
            "pose evidence and does not count as a three-face blind-test pass."
        )
    if sample.association_repaired:
        warnings.append(
            "The frozen camera model repaired partial/over-grown grid indexing "
            "and bounded checker-sheet mounting offsets before the rigid "
            "three-face consensus test."
        )
    return BestResult(
        K=K.copy(),
        dist=dist.copy(),
        R=R,
        t=tvec.reshape(3),
        rmse=rmse,
        fx_px=float(K[0, 0]),
        fy_px=float(K[1, 1]),
        skew_px=float(K[0, 1]),
        cx_px=float(K[0, 2]),
        cy_px=float(K[1, 2]),
        height_mm=float(height),
        downtilt_deg=float(downtilt),
        cam_position=cam_pos,
        fov_coverage_pct=0.0,
        cube_area_pct=sample.cube_area_pct,
        corner_quality=(
            0.0 if sample.corner_quality is None else sample.corner_quality
        ),
        model_used=(
            "trained-camera-model-fixed-intrinsics-"
            f"{model.get('distortion_model_selected', 'unknown')}"
        ),
        n_corners=int(len(sample.image_points)),
        n_faces_detected=usable_face_count,
        elapsed_sec=0.0,
        warnings=warnings,
        preflight=preflight,
    )
