#!/usr/bin/env python3
"""Controlled 2-D test-set comparison for the five 2026-08-20 poses.

For each pose, the frozen 3-D five-image parameters and the frozen MATLAB
Zhang parameters are evaluated on the exact same planar test images, detected
corners, holdout splits, and metric implementation.  No parameter is refitted.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from evaluate_planar_blind_comparison import (
    IMAGE_SUFFIXES,
    backproject_object_errors,
    basic_stats,
    detect_checker,
    line_rms,
    object_points,
    project_errors,
    solve_pose,
)


POSES = ("15_0.528", "30_0.827", "45_0.827", "45_1.155", "60_1.155")


def image_dir(split_root: Path, pose: str) -> Path:
    for name in ("2D", "zhang_2d"):
        candidate = split_root / "test" / pose / name
        if candidate.is_dir():
            return candidate
    raise FileNotFoundError(f"No 2-D test directory for {pose}")


def camera_from_model(path: Path) -> tuple[np.ndarray, np.ndarray, bool]:
    model = json.loads(path.read_text(encoding="utf-8"))
    return (
        np.asarray(model["cameraMatrix"], np.float64).reshape(3, 3),
        np.asarray(model["distCoeffs"], np.float64).reshape(5),
        bool(model.get("accepted", False)),
    )


def zhang_camera(row: dict[str, str]) -> tuple[np.ndarray, np.ndarray]:
    value = lambda key: float(row.get(key, "0") or 0.0)
    K = np.array(
        [[value("fx_px"), 0.0, value("cx_px")],
         [0.0, value("fy_px"), value("cy_px")],
         [0.0, 0.0, 1.0]],
        np.float64,
    )
    dist = np.array([value("k1"), value("k2"), value("p1"), value("p2"), 0.0], np.float64)
    return K, dist


def backproject_points(
    obj: np.ndarray, img: np.ndarray, pose: tuple[np.ndarray, np.ndarray],
    K: np.ndarray, dist: np.ndarray,
) -> np.ndarray:
    rvec, tvec = pose
    R, _ = cv2.Rodrigues(rvec)
    rays = cv2.undistortPoints(img.reshape(-1, 1, 2), K, dist).reshape(-1, 2)
    rays3 = np.column_stack([rays, np.ones(len(rays))])
    normal = R[:, 2]
    scale = float(normal @ tvec.reshape(3)) / (rays3 @ normal)
    camera = rays3 * scale[:, None]
    return (R.T @ (camera - tvec.reshape(1, 3)).T).T


def length_errors_mm(world: np.ndarray, square_mm: float) -> tuple[float, float]:
    grid = world.reshape(6, 9, 3)
    lengths = []
    lengths.extend(np.linalg.norm(grid[:, 1:, :2] - grid[:, :-1, :2], axis=2).ravel())
    lengths.extend(np.linalg.norm(grid[1:, :, :2] - grid[:-1, :, :2], axis=2).ravel())
    values = np.asarray(lengths, np.float64)
    absolute = np.abs(values - square_mm)
    relative = absolute / square_mm * 100.0
    return float(np.median(absolute)), float(np.median(relative))


def finite(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): finite(v) for k, v in value.items()}
    if isinstance(value, list):
        return [finite(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (float, np.floating)):
        v = float(value)
        return v if math.isfinite(v) else None
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--split-root", type=Path, required=True)
    parser.add_argument("--repeats", type=int, default=20)
    parser.add_argument("--holdout-fraction", type=float, default=0.20)
    parser.add_argument("--seed", type=int, default=20260903)
    parser.add_argument("--square-mm", type=float, default=25.0)
    args = parser.parse_args()
    split = args.split_root.resolve()
    validation = split / "validation_ours_vs_zhang"
    with (validation / "zhang_parameters.csv").open("r", encoding="utf-8-sig", newline="") as handle:
        zhang_rows = {row.get("Pose", row.get("pose")): row for row in csv.DictReader(handle)}
    obj = object_points(args.square_mm)
    all_summary = []

    for pose_index, pose in enumerate(POSES):
        model_path = validation / "per_pose_models" / pose / "trained_camera_model.json"
        ours_K, ours_dist, accepted = camera_from_model(model_path)
        zhang_K, zhang_dist = zhang_camera(zhang_rows[pose])
        models = {"ours_3d_5_images": (ours_K, ours_dist), "zhang_matlab_20_images": (zhang_K, zhang_dist)}
        paths = sorted(
            (p for p in image_dir(split, pose).iterdir() if p.is_file() and p.suffix.lower() in IMAGE_SUFFIXES),
            key=lambda p: int(p.stem.rsplit("_", 1)[-1]) if p.stem.rsplit("_", 1)[-1].isdigit() else p.name,
        )
        rows = []
        failures = []
        for image_index, path in enumerate(paths):
            corners, detector = detect_checker(path)
            if corners is None:
                failures.append({"image": path.name, "reason": detector})
                print(f"[{pose}] {path.name}: detection failed", flush=True)
                continue
            rng = np.random.default_rng(args.seed + pose_index * 100000 + image_index)
            holdout_count = max(8, int(round(len(obj) * args.holdout_fraction)))
            splits = []
            for _ in range(args.repeats):
                held = np.sort(rng.choice(len(obj), size=holdout_count, replace=False))
                train = np.setdiff1d(np.arange(len(obj)), held)
                splits.append((train, held))
            row: dict[str, Any] = {"image": path.name, "detector": detector, "n_corners": len(corners)}
            for name, (K, dist) in models.items():
                full = solve_pose(obj, corners, np.arange(len(obj)), K, dist)
                if full is None:
                    row[name] = {"pose_success": False}
                    continue
                full_errors = project_errors(obj, corners, np.arange(len(obj)), full, K, dist)
                world = backproject_points(obj, corners, full, K, dist)
                length_abs, length_rel = length_errors_mm(world, args.square_mm)
                held_px = []
                held_mm = []
                for train, held in splits:
                    estimate = solve_pose(obj, corners, train, K, dist)
                    if estimate is None:
                        continue
                    px = project_errors(obj, corners, held, estimate, K, dist)
                    mm = backproject_object_errors(obj, corners, held, estimate, K, dist)
                    held_px.append(float(np.sqrt(np.mean(px * px))))
                    held_mm.append(float(np.sqrt(np.mean(mm * mm))))
                row[name] = {
                    "pose_success": True,
                    "full_reprojection_rmse_px": float(np.sqrt(np.mean(full_errors * full_errors))),
                    "holdout_rmse_px": float(np.median(held_px)) if held_px else None,
                    "holdout_object_rmse_mm": float(np.median(held_mm)) if held_mm else None,
                    "length_absolute_error_mm": length_abs,
                    "length_relative_error_pct": length_rel,
                    "undistorted_line_rms_px": line_rms(corners, K, dist),
                    "successful_repeats": len(held_px),
                }
            rows.append(row)
            print(f"[{pose}] {path.name}: ok", flush=True)

        metrics = (
            "full_reprojection_rmse_px", "holdout_rmse_px", "holdout_object_rmse_mm",
            "length_absolute_error_mm", "length_relative_error_pct", "undistorted_line_rms_px",
        )
        summaries = {}
        comparisons = {}
        for name in models:
            summaries[name] = {
                metric: basic_stats([r[name][metric] for r in rows if r.get(name, {}).get("pose_success")])
                for metric in metrics
            }
        for metric in metrics:
            pairs = [
                (r["ours_3d_5_images"][metric], r["zhang_matlab_20_images"][metric])
                for r in rows
                if r.get("ours_3d_5_images", {}).get("pose_success")
                and r.get("zhang_matlab_20_images", {}).get("pose_success")
            ]
            comparisons[metric] = {
                "paired_images": len(pairs),
                "ours_wins": sum(a < b for a, b in pairs),
                "zhang_wins": sum(b < a for a, b in pairs),
                "ties": sum(abs(a - b) <= 1e-12 for a, b in pairs),
                "median_ours_minus_zhang": float(np.median([a - b for a, b in pairs])) if pairs else None,
            }
        payload = finite({
            "schema": "planar-per-pose-controlled-evaluation/v1",
            "pose": pose,
            "test_directory": str(image_dir(split, pose)),
            "test_images": len(paths),
            "detected_images": len(rows),
            "detection_failures": failures,
            "same_images_same_corners_same_holdouts": True,
            "ours_model_accepted": accepted,
            "model_path": str(model_path),
            "zhang_parameter_source": zhang_rows[pose].get("source"),
            "pattern_inner_corners": [9, 6],
            "square_mm": args.square_mm,
            "repeats": args.repeats,
            "summaries": summaries,
            "comparisons": comparisons,
            "images": rows,
        })
        out = validation / "final_test_evaluation" / pose / "planar_2d_controlled"
        out.mkdir(parents=True, exist_ok=True)
        (out / "evaluation.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        all_summary.append({"pose": pose, "test_images": len(paths), "detected_images": len(rows), "summaries": summaries, "comparisons": comparisons})
    (validation / "final_test_evaluation" / "PLANAR_2D_CONTROLLED_SUMMARY.json").write_text(
        json.dumps(finite(all_summary), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
