#!/usr/bin/env python3
"""
Line-direction-clustering face detector for three-face corner-cube target.

Core algorithm:
  1. Detect chessboard corners (OpenCV), extract row/col LINES
  2. Cluster all lines by DIRECTION -> each cluster = one world axis (X/Y/Z)
  3. A face = a spatial region where TWO direction clusters intersect
  4. Face boundaries = the spatial extent of each face's corner set
  5. For missing faces: search near boundaries of known faces

Integrates with calibrate_best() via _gt.npz.
"""

import math
import sys, os
from itertools import combinations, permutations, product
import numpy as np
import cv2

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from three_face_calib import (
    DetectedFace,
    FaceDefinition,
    preprocess_image,
    standard_three_face_target,
    object_points_for_face,
    apply_best_face_orientations,
    lines_from_chessboard_corners,
    adaptive_subpix_window,
    estimate_blur_level,
)
from calibration_policy import (
    MIN_ACCEPTED_CUBE_AREA_PCT,
    NORMAL_RELIABLE_CUBE_AREA_PCT,
    SMALL_TARGET_ATTEMPT_MIN_AREA_PCT,
)

# ─────────────────── Config ─────────────────────────────────────────────────

def _env_flag(name, default=False):
    raw = os.environ.get(name)
    if raw is None:
        return bool(default)
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def _env_float(name, default):
    raw = os.environ.get(name)
    if raw is None:
        return float(default)
    try:
        value = float(raw)
    except ValueError:
        return float(default)
    return value if math.isfinite(value) else float(default)


FACE_CONFIGS = [
    {'patterns': [(9, 6), (9, 5), (8, 6)], 'label': 'XY'},
    {'patterns': [(9, 6), (8, 4), (8, 5), (7, 4), (6, 6), (6, 5)], 'label': 'XZ'},
    {'patterns': [(6, 5), (5, 5), (5, 4), (6, 6), (4, 5), (4, 4)], 'label': 'YZ'},
]

ENABLE_GEOMETRY_GATED_CANDIDATE_UPGRADE = False
MAX_CANDIDATE_UPGRADE_FAST_PNP_RMSE_PX = 8.0
MAX_CANDIDATE_UPGRADE_OFFSET_PNP_RMSE_PX = 11.0
MAX_FACE_CANDIDATES_FOR_UPGRADE = 2
ENABLE_SPARSE_TOPOLOGY_CANDIDATE_RECOVERY = True
MAX_SPARSE_RECOVERY_FACE_CANDIDATES = 5
MAX_SPARSE_RECOVERY_SPARSE_FACES = 1
MAX_SPARSE_RECOVERY_CENTERED_PNP_RMSE_PX = 32.0
MAX_SPARSE_RECOVERY_OFFSET_PNP_RMSE_PX = 13.0
MAX_SPARSE_RECOVERY_OFFSET_DIST_SQUARES = 3.0
MAX_SPARSE_RECOVERY_OVERLAP_IOU = 0.80
MAX_SPARSE_BBOX_EXPAND_CANDIDATES = 4
MAX_SPARSE_RECOVERY_GEOMETRY_COMBOS = 20
ENABLE_LOCAL_BBOX_REDETECT_REFINEMENT = False
ENABLE_GLOBAL_BBOX_LAYOUT_REFINEMENT = True
LOCAL_BBOX_REDETECT_TARGET_DIM = 520.0
LOCAL_BBOX_REDETECT_MAX_SCALE = 4.0
CUBE_CROP_UPSCALE_TARGET_DIMS = (950.0, 1400.0)
CUBE_CROP_UPSCALE_MAX_SCALE = 4.0
CUBE_CROP_UPSCALE_MIN_SCALE = 1.20
MAX_EARLY_STOP_CROP_UPSCALE_FAST_PNP_RMSE_PX = 12.0
CUBE_CROP_CLUSTER_FAST_EXIT_CORNERS = 80
CUBE_CROP_BORDER_CLUSTER_FAST_EXIT_CORNERS = 90
CUBE_CROP_BORDER_MARGIN_PX = 8
VALIDATED_SMALL_TARGET_PATTERNS = ((9, 6), (9, 6), (6, 6))
MIN_VALIDATED_SMALL_TARGET_CORNERS = 120
MIN_DEFERRED_SPARSE_TOPOLOGY_FAST_CORNERS = MIN_VALIDATED_SMALL_TARGET_CORNERS
MAX_DEFERRED_SPARSE_TOPOLOGY_FAST_OFFSET_PNP_RMSE_PX = 10.0
ENABLE_SMALL_TARGET_REGION_CANDIDATE_RECOVERY = _env_flag(
    "CALIB_ENABLE_SMALL_REGION_RECOVERY", False)
ENABLE_SMALL_TARGET_REGION_UPSCALED_CANDIDATES = _env_flag(
    "CALIB_ENABLE_SMALL_REGION_UPSCALED", False)
ENABLE_SMALL_TARGET_GRID_EXPAND_CANDIDATES = _env_flag(
    "CALIB_ENABLE_SMALL_TARGET_GRID_EXPAND", True)
MAX_SMALL_TARGET_REGION_FACE_CANDIDATES = 6
MAX_SMALL_TARGET_REGION_COMBOS = 30
MAX_SMALL_TARGET_REGION_CENTERED_PNP_RMSE_PX = 14.0
MAX_SMALL_TARGET_REGION_OFFSET_PNP_RMSE_PX = 5.80
MAX_SMALL_TARGET_GRID_EXPAND_OFFSET_PNP_RMSE_PX = 11.75
MAX_SMALL_TARGET_REGION_BASELINE_EARLY_OFFSET_PNP_RMSE_PX = 7.0
MAX_SMALL_TARGET_REGION_SKIP_SPARSE_CORNERS = 90
MAX_SMALL_TARGET_REGION_OVERLAP_IOU = 0.80
SMALL_TARGET_REGION_MAX_PATTERN_STEP_DEFICIT = 0
MAX_SMALL_TARGET_GRID_EXPAND_FIT_RMSE_PX = 5.25
MAX_SMALL_TARGET_SPARSE_GRID_EXPAND_FIT_RMSE_PX = 8.75
MAX_SMALL_TARGET_GRID_EXPAND_HOMOGRAPHY_RMSE_PX = 3.20
MAX_SMALL_TARGET_GRID_EXPAND_ROBUST_HOMOGRAPHY_RMSE_PX = 0.85
MIN_SMALL_TARGET_GRID_EXPAND_HOMOGRAPHY_INLIER_FRAC = 0.60
MAX_SMALL_TARGET_GRID_EXPAND_LINE_QUALITY_PX = 0.55
MAX_SMALL_TARGET_GRID_EXPAND_OVERLAP_IOU = 0.08
MAX_SMALL_TARGET_CROP_FUSION_OFFSET_PNP_RMSE_PX = 11.75
MAX_SMALL_TARGET_CROP_FUSION_CENTERED_PNP_RMSE_PX = 18.0
MAX_SMALL_TARGET_CROP_FUSION_LINE_QUALITY_PX = 0.75
MAX_SMALL_TARGET_CROP_FUSION_OVERLAP_IOU = 0.35
MAX_SMALL_TARGET_FAST_DIRECT_CENTERED_PNP_RMSE_PX = 11.0
MAX_SMALL_TARGET_FAST_DIRECT_OFFSET_PNP_RMSE_PX = 10.0
MAX_SMALL_TARGET_SPARSE_TOPOLOGY_FAST_SKIP_CORNERS = 70
ENABLE_SMALL_TARGET_TOP_BLOB_GRID_CANDIDATES = _env_flag(
    "CALIB_ENABLE_SMALL_TARGET_TOP_BLOB_GRID", True)
MAX_SMALL_TARGET_TOP_BLOB_GRID_CANDIDATES = 6
MIN_SMALL_TARGET_TOP_BLOB_UNIQUE_SUPPORT = 10
MAX_SMALL_TARGET_TOP_BLOB_MATCH_DIST_PX = 8.5
ENABLE_SMALL_TARGET_SIDE_POSE_TOP_COMPLETION = _env_flag(
    "CALIB_ENABLE_SMALL_TARGET_SIDE_POSE_TOP_COMPLETION", True)
SMALL_TARGET_SIDE_POSE_TOP_MAX_AREA_PCT = _env_float(
    "CALIB_SMALL_TARGET_SIDE_POSE_TOP_MAX_AREA_PCT", 6.0)
SMALL_TARGET_SIDE_POSE_TOP_RELAX_AREA_PCT = _env_float(
    "CALIB_SMALL_TARGET_SIDE_POSE_TOP_RELAX_AREA_PCT", 4.0)
MAX_SMALL_TARGET_SIDE_POSE_TOP_CANDIDATES = 4
MIN_SMALL_TARGET_SIDE_POSE_TOP_SUPPORT = 18
MAX_SMALL_TARGET_SIDE_POSE_TOP_MEDIAN_PX = 9.5
MAX_SMALL_TARGET_SIDE_POSE_SIDE_RMSE_PX = 8.0
MAX_SMALL_TARGET_SIDE_POSE_CENTERED_PNP_RMSE_PX = 15.0
MAX_GLOBAL_BBOX_LAYOUT_FAST_PNP_RMSE_PX = 9.0
MIN_GLOBAL_BBOX_LAYOUT_PNP_IMPROVEMENT_PX = 1.0
MAX_GLOBAL_BBOX_LAYOUT_HOMOGRAPHY_RMSE_PX = 1.5
MAX_GLOBAL_BBOX_LAYOUT_ROBUST_HOMOGRAPHY_RMSE_PX = 1.1
MIN_GLOBAL_BBOX_LAYOUT_HOMOGRAPHY_INLIER_FRAC = 0.68
GLOBAL_BBOX_LAYOUT_GEOMETRY_COMBO_LIMIT = 2


# ─────────────────── Helpers ────────────────────────────────────────────────

def _bbox_of_corners(c):
    c = c.reshape(-1, 2)
    return (int(c[:, 0].min()), int(c[:, 1].min()),
            int(c[:, 0].max()), int(c[:, 1].max()))

def _area(bbox):
    return max(0, bbox[2]-bbox[0]) * max(0, bbox[3]-bbox[1])

def _iou(b1, b2):
    x1, y1 = max(b1[0], b2[0]), max(b1[1], b2[1])
    x2, y2 = min(b1[2], b2[2]), min(b1[3], b2[3])
    if x1 >= x2 or y1 >= y2: return 0.0
    return ((x2-x1)*(y2-y1)) / min(_area(b1), _area(b2))

def _line_dir(line):
    """Unit direction vector from homogeneous line [a,b,c] (direction = (-b,a))."""
    d = np.array([-line[1], line[0]], dtype=np.float64)
    n = np.linalg.norm(d)
    return d / n if n > 1e-10 else np.array([1.0, 0.0])

def _mean_dir(lines):
    if not lines: return np.array([1.0, 0.0])
    dirs = np.array([_line_dir(l) for l in lines])
    m = dirs.mean(axis=0)
    n = np.linalg.norm(m)
    return m / n if n > 1e-10 else np.array([1.0, 0.0])

def _cos_sim(v1, v2):
    return float(abs(np.dot(v1, v2)))


# ─────────────────────────────────────────────────────────────────────────────
# Cube-first detection
# ─────────────────────────────────────────────────────────────────────────────

def _unique_patterns(patterns):
    out, seen = [], set()
    for pat in patterns:
        if pat not in seen:
            seen.add(pat)
            out.append(pat)
    return out


def _patterns_for_label(label):
    """Return likely grid sizes, ordered from most preferred to fallback."""
    by_label = {
        'XY': [(9, 6), (10, 6), (9, 5), (8, 6), (7, 6), (6, 6)],
        'XZ': [(9, 6), (8, 6), (8, 5), (7, 6), (7, 5), (6, 6), (6, 5)],
        'YZ': [(9, 6), (8, 6), (7, 6), (6, 6), (6, 5), (5, 6), (5, 5), (5, 4), (4, 5)],
    }
    base = by_label.get(label, [])
    configured = []
    for cfg in FACE_CONFIGS:
        configured.extend(cfg['patterns'])
    with_swaps = []
    for pat in base + configured:
        with_swaps.append(pat)
        if pat[0] != pat[1]:
            with_swaps.append((pat[1], pat[0]))
    return _unique_patterns(with_swaps)


def _line_quality_for_candidate(corners, pattern):
    try:
        _rl, _cl, rq, cq = lines_from_chessboard_corners(
            corners, pattern, use_ransac=True)
    except Exception:
        return float('inf')
    return float(max(rq, cq))


def _score_face_upgrade_candidate(corners, pattern, source):
    quality = _line_quality_for_candidate(corners, pattern)
    if not np.isfinite(quality):
        quality = 8.0
    sparse_penalty = 75.0 if min(pattern) < 5 else 0.0
    wide_penalty = 10.0 if source.startswith('wide') else 0.0
    return (
        float(len(corners))
        - sparse_penalty
        - 2.5 * float(min(quality, 8.0))
        - wide_penalty
    )


def _dedupe_face_candidates(candidates):
    unique = []
    for score, corners, pat, label, source in sorted(
            candidates, key=lambda item: item[0], reverse=True):
        bbox = _bbox_of_corners(corners)
        center = _center_of_corners(corners)
        is_dup = False
        for _old_score, old_corners, old_pat, old_label, _old_source in unique:
            if old_label != label or old_pat != pat:
                continue
            old_center = _center_of_corners(old_corners)
            if np.linalg.norm(center - old_center) < 8.0:
                old_bbox = _bbox_of_corners(old_corners)
                if _iou(bbox, old_bbox) > 0.85:
                    is_dup = True
                    break
        if not is_dup:
            unique.append((score, corners, pat, label, source))
    return unique


def _detect_pattern_candidates_in_face(gray, poly, label,
                                       max_candidates=None,
                                       patterns_override=None):
    """Collect a small set of face-grid candidates for gated upgrades.

    The candidate is returned only to a fast three-face PnP gate before
    production calibration can see it, so this branch can include rectified
    and SB variants without directly accepting a single-face false positive.
    """
    h, w = gray.shape[:2]
    poly = np.asarray(poly, dtype=np.int32).reshape(-1, 2)
    x, y, bw, bh = cv2.boundingRect(poly)
    if bw <= 0 or bh <= 0:
        return []

    base_span = max(bw, bh)
    center = poly.astype(np.float32).mean(axis=0)
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    patterns = (
        list(patterns_override)
        if patterns_override is not None
        else _patterns_for_label(label)[:8]
    )
    variants = [
        (1.18, 0.00, 210, 'classic-1.18'),
        (1.35, 0.00, 210, 'classic-1.35'),
        (1.00, 0.00, 210, 'classic-1.00'),
        (1.35, 0.15, 210, 'expanded-1.35'),
        (1.35, 0.15, 127, 'expanded-1.35-gray'),
        (1.60, 0.20, 127, 'expanded-1.60'),
        (1.90, 0.20, 210, 'wide-1.90'),
        (2.20, 0.25, 210, 'wide-2.20'),
        (2.40, 0.25, 210, 'wide-2.40'),
    ]

    candidates = []
    for scale, dy_frac, bg_value, source in variants:
        p = center + (poly.astype(np.float32) - center) * scale
        p[:, 1] += dy_frac * float(base_span)
        p[:, 0] = np.clip(p[:, 0], 0, w - 1)
        p[:, 1] = np.clip(p[:, 1], 0, h - 1)
        ex, ey, ebw, ebh = cv2.boundingRect(p.astype(np.int32))
        pad = max(12, int(0.08 * max(ebw, ebh)))
        x1, y1 = max(0, ex - pad), max(0, ey - pad)
        x2, y2 = min(w, ex + ebw + pad), min(h, ey + ebh + pad)
        if x2 <= x1 or y2 <= y1:
            continue
        roi = gray[y1:y2, x1:x2].copy()
        mask = np.zeros_like(roi)
        cv2.fillPoly(mask, [(p - np.array([x1, y1])).astype(np.int32)], 255)
        masked = np.where(mask > 0, roi, bg_value).astype(np.uint8)
        enhanced = preprocess_image(masked)
        for pat in patterns:
            ok, corners = cv2.findChessboardCorners(enhanced, pat, flags=flags)
            if ok and corners is not None:
                corners = corners.reshape(-1, 1, 2).astype(np.float32)
                corners[:, 0, 0] += x1
                corners[:, 0, 1] += y1
                score = _score_face_upgrade_candidate(corners, pat, source)
                candidates.append((score, corners, pat, label, source))
                # One pattern per variant keeps this branch bounded.
                break

    for rectified, H_inv in _rectified_face_variants(gray, poly):
        for pat in patterns:
            ok, corners = cv2.findChessboardCorners(rectified, pat, flags=flags)
            if ok and corners is not None:
                corners = cv2.perspectiveTransform(
                    corners.reshape(-1, 1, 2).astype(np.float32), H_inv)
                source = 'rectified'
                score = _score_face_upgrade_candidate(corners, pat, source)
                candidates.append((score, corners, pat, label, source))
                break

    if hasattr(cv2, 'findChessboardCornersSB'):
        sb_flags = cv2.CALIB_CB_NORMALIZE_IMAGE
        for scale, dy_frac, bg_value, source in variants:
            p = center + (poly.astype(np.float32) - center) * scale
            p[:, 1] += dy_frac * float(base_span)
            p[:, 0] = np.clip(p[:, 0], 0, w - 1)
            p[:, 1] = np.clip(p[:, 1], 0, h - 1)
            ex, ey, ebw, ebh = cv2.boundingRect(p.astype(np.int32))
            pad = max(12, int(0.08 * max(ebw, ebh)))
            x1, y1 = max(0, ex - pad), max(0, ey - pad)
            x2, y2 = min(w, ex + ebw + pad), min(h, ey + ebh + pad)
            if x2 <= x1 or y2 <= y1:
                continue
            roi = gray[y1:y2, x1:x2].copy()
            mask = np.zeros_like(roi)
            cv2.fillPoly(mask, [(p - np.array([x1, y1])).astype(np.int32)], 255)
            masked = np.where(mask > 0, roi, bg_value).astype(np.uint8)
            enhanced = preprocess_image(masked)
            for pat in patterns:
                ok, corners = cv2.findChessboardCornersSB(
                    enhanced, pat, flags=sb_flags)
                if ok and corners is not None:
                    corners = corners.reshape(-1, 1, 2).astype(np.float32)
                    corners[:, 0, 0] += x1
                    corners[:, 0, 1] += y1
                    sb_source = source + '-SB'
                    score = _score_face_upgrade_candidate(
                        corners, pat, sb_source)
                    candidates.append((score, corners, pat, label, sb_source))
                    break
        for rectified, H_inv in _rectified_face_variants(gray, poly):
            for pat in patterns:
                ok, corners = cv2.findChessboardCornersSB(
                    rectified, pat, flags=sb_flags)
                if ok and corners is not None:
                    corners = cv2.perspectiveTransform(
                        corners.reshape(-1, 1, 2).astype(np.float32), H_inv)
                    source = 'rectified-SB'
                    score = _score_face_upgrade_candidate(corners, pat, source)
                    candidates.append((score, corners, pat, label, source))
                    break

    candidates = _dedupe_face_candidates(candidates)
    limit = max_candidates or MAX_FACE_CANDIDATES_FOR_UPGRADE
    return candidates[:limit]


def _sparse_bbox_expansion_windows(label):
    """Small, label-aware windows around a sparse local face grid."""
    if label == 'XY':
        return [
            (3.5, 2.4, -0.30, 0.10),
            (2.8, 2.5, -0.40, 0.20),
            (3.4, 2.8, -0.50, 0.35),
            (4.0, 3.0, -0.55, 0.45),
        ]
    if label == 'XZ':
        return [
            (2.6, 4.0, -0.45, 1.05),
            (3.0, 4.6, -0.35, 1.20),
            (3.4, 5.2, -0.30, 1.35),
            (2.4, 2.6, -0.15, 0.35),
            (3.0, 3.2, -0.05, 0.55),
            (3.8, 3.8, 0.15, 0.75),
            (4.5, 4.2, 0.35, 0.90),
            (5.2, 4.6, 0.45, 1.05),
        ]
    return [
        (2.6, 3.0, 1.80, -1.00),
        (3.0, 3.4, 2.10, -1.25),
        (3.4, 3.8, 2.30, -1.40),
        (2.8, 2.8, 0.35, 0.35),
        (3.4, 3.2, 0.45, 0.45),
        (4.2, 3.6, 0.50, 0.55),
    ]


def _detect_sparse_bbox_expanded_candidates(
        gray, corners, pattern, label, max_candidates=None):
    """Find larger face grids by expanding from a sparse detected grid bbox.

    This branch is used only inside sparse topology recovery.  It handles
    cases where dark-square clustering captures only a local piece of a face,
    so polygon-masked face search cannot see the full checkerboard even though
    the sparse local grid is correctly located.
    """
    pts = np.asarray(corners, dtype=np.float32).reshape(-1, 2)
    if pts.size == 0:
        return []
    x1, y1 = pts.min(axis=0)
    x2, y2 = pts.max(axis=0)
    bw = max(float(x2 - x1), 1.0)
    bh = max(float(y2 - y1), 1.0)
    cx = 0.5 * float(x1 + x2)
    cy = 0.5 * float(y1 + y2)
    span = max(bw, bh, 1.0)
    h, w = gray.shape[:2]
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    patterns = [
        pat for pat in _patterns_for_label(label)[:14]
        if int(pat[0]) * int(pat[1]) > int(pattern[0]) * int(pattern[1])
    ]
    if not patterns:
        return []

    candidates = []
    for sx, sy, dx, dy in _sparse_bbox_expansion_windows(label):
        ww = bw * float(sx)
        hh = bh * float(sy)
        ccx = cx + float(dx) * span
        ccy = cy + float(dy) * span
        rx1 = max(0, int(math.floor(ccx - 0.5 * ww)))
        ry1 = max(0, int(math.floor(ccy - 0.5 * hh)))
        rx2 = min(w, int(math.ceil(ccx + 0.5 * ww)))
        ry2 = min(h, int(math.ceil(ccy + 0.5 * hh)))
        if rx2 - rx1 < 30 or ry2 - ry1 < 30:
            continue
        roi = gray[ry1:ry2, rx1:rx2]
        if roi.size == 0:
            continue
        max_dim = max(roi.shape[:2])
        scale = min(3.5, max(1.0, 720.0 / float(max(max_dim, 1))))
        if scale > 1.01:
            work = cv2.resize(
                roi,
                (
                    int(round(roi.shape[1] * scale)),
                    int(round(roi.shape[0] * scale)),
                ),
                interpolation=cv2.INTER_CUBIC,
            )
        else:
            work = roi
        variants = [
            (preprocess_image(work), 'pre'),
            (cv2.equalizeHist(work), 'eq'),
            (work, 'raw'),
        ]
        for variant, variant_name in variants:
            found_this_window = False
            for pat in patterns:
                try:
                    ok, cand = cv2.findChessboardCorners(
                        variant, pat, flags=flags)
                except cv2.error:
                    ok, cand = False, None
                if not ok or cand is None:
                    continue
                cand = cand.reshape(-1, 1, 2).astype(np.float32)
                cand[:, 0, 0] = cand[:, 0, 0] / float(scale) + float(rx1)
                cand[:, 0, 1] = cand[:, 0, 1] / float(scale) + float(ry1)
                source = (
                    f"sparse-bbox-{variant_name}-"
                    f"{sx:.1f}x{sy:.1f}"
                )
                score = _score_face_upgrade_candidate(cand, pat, source)
                candidates.append((score, cand, pat, label, source))
                found_this_window = True
                break
            if found_this_window:
                break

    candidates = _dedupe_face_candidates(candidates)
    limit = max_candidates or MAX_SPARSE_BBOX_EXPAND_CANDIDATES
    return candidates[:limit]


def _order_poly_points(poly):
    pts = np.asarray(poly, dtype=np.float32).reshape(-1, 2)
    if len(pts) == 0:
        return pts
    c = pts.mean(axis=0)
    a = np.arctan2(pts[:, 1] - c[1], pts[:, 0] - c[0])
    return pts[np.argsort(a)]


def _quad_from_poly(poly):
    """Choose a stable 4-point face outline from a convex-ish polygon."""
    pts = np.asarray(poly, dtype=np.float32).reshape(-1, 2)
    if len(pts) < 4:
        return None

    hull = cv2.convexHull(pts).reshape(-1, 2)
    if len(hull) == 4:
        quad = _order_poly_points(hull)
    else:
        if len(hull) > 10:
            eps = 0.02 * cv2.arcLength(hull.astype(np.float32), True)
            approx = cv2.approxPolyDP(hull.astype(np.float32), eps, True).reshape(-1, 2)
            hull = approx if len(approx) >= 4 else hull
        best_quad = None
        best_area = -1.0
        for combo in combinations(range(len(hull)), 4):
            cand = _order_poly_points(hull[list(combo)])
            area = abs(cv2.contourArea(cand.astype(np.float32)))
            if area > best_area:
                best_area = area
                best_quad = cand
        quad = best_quad

    if quad is None or abs(cv2.contourArea(quad.astype(np.float32))) < 10:
        return None
    if cv2.contourArea(quad.astype(np.float32)) < 0:
        quad = quad[::-1]
    start = int(np.argmin(quad.sum(axis=1)))
    return np.roll(quad, -start, axis=0).astype(np.float32)


def _rectified_face_variants(gray, poly):
    """Perspective-normalise one candidate face and keep inverse mapping."""
    quad = _quad_from_poly(poly)
    if quad is None:
        return []

    edges = [
        np.linalg.norm(quad[(i + 1) % 4] - quad[i])
        for i in range(4)
    ]
    if min(edges) < 8:
        return []

    dst_w = int(max(edges[0], edges[2]) * 3.0)
    dst_h = int(max(edges[1], edges[3]) * 3.0)
    dst_w = max(220, min(1000, dst_w))
    dst_h = max(160, min(800, dst_h))

    dst = np.array([[0, 0], [dst_w - 1, 0],
                    [dst_w - 1, dst_h - 1], [0, dst_h - 1]],
                   dtype=np.float32)
    H = cv2.getPerspectiveTransform(quad, dst)
    H_inv = cv2.getPerspectiveTransform(dst, quad)
    warped = cv2.warpPerspective(
        gray, H, (dst_w, dst_h),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=210)
    return [
        (preprocess_image(warped), H_inv),
        (preprocess_image(warped, clip_limit=4.0), H_inv),
        (warped, H_inv),
        (cv2.equalizeHist(warped), H_inv),
    ]


def _dark_square_components(gray):
    """Find dark square-like blobs; these are used only to localise faces."""
    h, w = gray.shape[:2]
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    dark = (blur < 105).astype(np.uint8) * 255

    num, labels, stats, cents = cv2.connectedComponentsWithStats(dark, 8)
    filtered = np.zeros_like(dark)
    components = []

    img_area = float(h * w)
    min_area = max(12.0, img_area * 4e-6)
    max_area = max(800.0, img_area * 2.5e-3)
    max_dim = max(20, int(min(h, w) * 0.10))

    for i in range(1, num):
        x, y, bw, bh, area = stats[i]
        if area < min_area or area > max_area:
            continue
        if bw < 3 or bh < 3 or bw > max_dim or bh > max_dim:
            continue
        ratio = bw / float(max(bh, 1))
        if ratio < 0.30 or ratio > 3.30:
            continue
        fill = area / float(max(bw * bh, 1))
        if fill < 0.22:
            continue

        filtered[labels == i] = 255
        components.append({
            'center': np.asarray(cents[i], dtype=np.float32),
            'bbox': (int(x), int(y), int(bw), int(bh)),
            'area': float(area),
            'size': float(max(bw, bh)),
        })

    return filtered, components


def _kmeans_split_component_clusters(filtered, components, seed_clusters,
                                      n_faces=3):
    """Split a merged cube target into face-like component groups."""
    if len(seed_clusters) < 2 or len(components) < max(12, n_faces * 6):
        return []

    boxes = [c['bbox'] for c in seed_clusters]
    ux1 = min(b[0] for b in boxes)
    uy1 = min(b[1] for b in boxes)
    ux2 = max(b[0] + b[2] for b in boxes)
    uy2 = max(b[1] + b[3] for b in boxes)
    span = max(ux2 - ux1, uy2 - uy1)
    pad = max(60, int(0.25 * span))
    h, w = filtered.shape[:2]
    x1, y1 = max(0, ux1 - pad), max(0, uy1 - pad)
    x2, y2 = min(w, ux2 + pad), min(h, uy2 + pad)

    selected = []
    for idx, comp in enumerate(components):
        cx, cy = comp['center']
        if x1 <= cx <= x2 and y1 <= cy <= y2:
            selected.append((idx, comp))
    if len(selected) < max(18, n_faces * 6):
        return []

    pts = np.array([comp['center'] for _, comp in selected], dtype=np.float32)
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,
                100, 0.2)
    try:
        cv2.setRNGSeed(12345)
        _compact, labels, _centers = cv2.kmeans(
            pts, n_faces, None, criteria, 10, cv2.KMEANS_PP_CENTERS)
    except cv2.error:
        return []

    median_size = np.median([c['size'] for _, c in selected])
    k = int(round(median_size * 0.55))
    k = max(11, min(25, k))
    if k % 2 == 0:
        k += 1
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (k, k))

    clusters = []
    for group_id in range(n_faces):
        idxs = [
            selected[i][0]
            for i, label in enumerate(labels.ravel())
            if int(label) == group_id
        ]
        if len(idxs) < 6:
            continue

        mask = np.zeros_like(filtered)
        for idx in idxs:
            x, y, bw, bh = components[idx]['bbox']
            mask[y:y + bh, x:x + bw] = np.maximum(
                mask[y:y + bh, x:x + bw],
                filtered[y:y + bh, x:x + bw])

        dilated = cv2.dilate(mask, kernel, iterations=1)
        contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL,
                                       cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            continue
        cnt = max(contours, key=cv2.contourArea)
        if cv2.contourArea(cnt) < 100:
            continue

        hull = cv2.convexHull(cnt)
        eps = 0.03 * cv2.arcLength(hull, True)
        poly = cv2.approxPolyDP(hull, eps, True).reshape(-1, 2)
        if len(poly) < 4:
            x, y, bw, bh = cv2.boundingRect(cnt)
            poly = np.array([[x, y], [x + bw, y],
                             [x + bw, y + bh], [x, y + bh]],
                            dtype=np.int32)

        centers = np.array([components[j]['center'] for j in idxs],
                           dtype=np.float32)
        x, y, bw, bh = cv2.boundingRect(cnt)
        clusters.append({
            'count': len(idxs),
            'bbox': (int(x), int(y), int(bw), int(bh)),
            'center': centers.mean(axis=0),
            'poly': _order_poly_points(poly),
            'kernel': (k, k),
        })

    if len(clusters) < n_faces:
        return []
    clusters.sort(key=lambda c: c['count'], reverse=True)
    return clusters[:n_faces]


def _cluster_dark_components(gray, n_faces=3, verbose=False):
    """Cluster black-square blobs into visible cube-face regions."""
    filtered, components = _dark_square_components(gray)
    if len(components) < 8:
        return []

    median_size = np.median([c['size'] for c in components])
    base_k = int(round(median_size * 1.35))
    base_k = max(11, min(31, base_k))
    if base_k % 2 == 0:
        base_k += 1

    # A smaller kernel keeps neighbouring cube faces separated.  If it fails,
    # try nearby sizes before giving up.
    kernel_sizes = _unique_patterns([
        (base_k, base_k),
        (max(9, base_k - 8) | 1, max(9, base_k - 8) | 1),
        (15, 15), (21, 21), (25, 25), (11, 11),
    ])

    best = []
    best_score = -np.inf
    for kw, kh in kernel_sizes:
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kw, kh))
        dilated = cv2.dilate(filtered, kernel, iterations=1)
        num, labels, stats, _ = cv2.connectedComponentsWithStats(dilated, 8)
        clusters = []
        for i in range(1, num):
            x, y, bw, bh, area = stats[i]
            idxs = []
            for ci, comp in enumerate(components):
                cx, cy = comp['center']
                ix, iy = int(round(cx)), int(round(cy))
                if 0 <= ix < labels.shape[1] and 0 <= iy < labels.shape[0]:
                    if labels[iy, ix] == i:
                        idxs.append(ci)
            if len(idxs) < max(6, 4 * min(n_faces, 3)):
                continue
            if bw * bh < 100:
                continue

            mask = (labels == i).astype(np.uint8) * 255
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL,
                                           cv2.CHAIN_APPROX_SIMPLE)
            if not contours:
                continue
            cnt = max(contours, key=cv2.contourArea)
            hull = cv2.convexHull(cnt)
            eps = 0.03 * cv2.arcLength(hull, True)
            poly = cv2.approxPolyDP(hull, eps, True).reshape(-1, 2)
            if len(poly) < 4:
                x0, y0, ww, hh = cv2.boundingRect(cnt)
                poly = np.array([[x0, y0], [x0 + ww, y0],
                                 [x0 + ww, y0 + hh], [x0, y0 + hh]],
                                dtype=np.int32)

            centers = np.array([components[j]['center'] for j in idxs],
                               dtype=np.float32)
            clusters.append({
                'count': len(idxs),
                'bbox': (int(x), int(y), int(bw), int(bh)),
                'center': centers.mean(axis=0),
                'poly': _order_poly_points(poly),
                'kernel': (kw, kh),
            })

        clusters.sort(key=lambda c: c['count'], reverse=True)
        if len(clusters) >= n_faces:
            for combo in combinations(clusters[:8], n_faces):
                centers = np.array([c['center'] for c in combo], dtype=np.float32)
                counts = np.array([c['count'] for c in combo], dtype=np.float32)
                span = centers.max(axis=0) - centers.min(axis=0)
                diag = float(np.linalg.norm(span))
                balance = float(counts.max() / max(counts.min(), 1.0))
                score = (
                    float(counts.sum())
                    - 0.035 * diag
                    - 18.0 * np.log(max(balance, 1.0))
                )
                if score > best_score:
                    best_score = score
                    best = list(combo)
        elif len(clusters) > len(best) and best_score == -np.inf:
            best = clusters

    if 2 <= len(best) < n_faces:
        split = _kmeans_split_component_clusters(
            filtered, components, best, n_faces=n_faces)
        if len(split) >= n_faces:
            best = split

    if verbose:
        if best:
            desc = ', '.join(
                f"{c['count']}@({c['center'][0]:.0f},{c['center'][1]:.0f})"
                for c in best
            )
            print(f"  Cube-first face clusters: {desc}")
        else:
            print("  Cube-first: no face clusters")

    return best[:n_faces]


def estimate_cube_area_pct(gray, n_faces=3):
    """Estimate visible cube footprint as percent of full image area.

    This is intentionally independent from successful calibration: it uses the
    cube-localised dark-square clusters and an expanded bounding box so even
    failed or partial detections can be assigned to an area-ratio bucket.
    """
    h, w = gray.shape[:2]
    clusters = _cluster_dark_components(gray, n_faces=n_faces, verbose=False)
    if not clusters:
        return None

    boxes = []
    for cluster in clusters:
        x, y, bw, bh = cluster['bbox']
        boxes.append((x, y, x + bw, y + bh))
    x1 = min(b[0] for b in boxes)
    y1 = min(b[1] for b in boxes)
    x2 = max(b[2] for b in boxes)
    y2 = max(b[3] for b in boxes)

    bw = x2 - x1
    bh = y2 - y1
    pad = max(4, int(0.12 * max(bw, bh)))
    x1 = max(0, x1 - pad)
    y1 = max(0, y1 - pad)
    x2 = min(w, x2 + pad)
    y2 = min(h, y2 + pad)
    area = max(0, x2 - x1) * max(0, y2 - y1)
    return float(area / max(float(w * h), 1.0) * 100.0)


def _label_cube_clusters(clusters):
    if not clusters:
        return []
    clusters = [dict(c) for c in clusters]

    # The top face is the visible face whose black-square cluster is highest.
    top_i = int(np.argmin([c['center'][1] for c in clusters]))
    clusters[top_i]['label'] = 'XY'

    sides = [c for i, c in enumerate(clusters) if i != top_i]
    sides.sort(key=lambda c: c['center'][0])
    if sides:
        sides[0]['label'] = 'XZ'
    if len(sides) >= 2:
        sides[1]['label'] = 'YZ'

    # Keep the order expected by standard_three_face_target().
    order = {'XY': 0, 'XZ': 1, 'YZ': 2}
    return sorted(clusters, key=lambda c: order.get(c.get('label', 'YZ'), 99))


def _detect_pattern_in_face(gray, poly, label, verbose=False):
    """Run chessboard detection inside one cube-face mask."""
    h, w = gray.shape[:2]
    poly = np.asarray(poly, dtype=np.int32).reshape(-1, 2)
    x, y, bw, bh = cv2.boundingRect(poly)
    base_span = max(bw, bh)
    if bw <= 0 or bh <= 0:
        return None

    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    patterns = _patterns_for_label(label)

    center = poly.astype(np.float32).mean(axis=0)
    variants = []

    pad = max(12, int(0.08 * max(bw, bh)))
    x1, y1 = max(0, x - pad), max(0, y - pad)
    x2, y2 = min(w, x + bw + pad), min(h, y + bh + pad)
    if x2 > x1 and y2 > y1:
        roi = gray[y1:y2, x1:x2].copy()
        for scale in (1.18, 1.35, 1.0):
            p = center + (poly.astype(np.float32) - center) * scale
            p[:, 0] = np.clip(p[:, 0], 0, w - 1)
            p[:, 1] = np.clip(p[:, 1], 0, h - 1)
            mask = np.zeros_like(roi)
            cv2.fillPoly(
                mask, [(p - np.array([x1, y1])).astype(np.int32)], 255)
            masked = np.where(mask > 0, roi, 210).astype(np.uint8)
            variants.append((preprocess_image(masked), x1, y1))

    for enhanced, ox, oy in variants:
        for pat in patterns:
            ok, corners = cv2.findChessboardCorners(enhanced, pat, flags=flags)
            if ok and corners is not None:
                corners = corners.astype(np.float32)
                corners[:, 0, 0] += ox
                corners[:, 0, 1] += oy
                if verbose:
                    print(f"  Cube-first: {label} {pat[0]}x{pat[1]} classic")
                return corners, pat, label

    # Some side-face clusters contain only the upper black squares.  As a
    # fallback, build the crop from the expanded polygon itself so the requested
    # expansion is not clipped by the original tight bbox.
    variants = []
    face_expansions = [
        (1.35, 0.00, 210),
        (1.35, 0.15, 210),
        (1.35, 0.15, 127),
        (1.60, 0.20, 127),
    ]
    for scale, dy_frac, bg_value in face_expansions:
        p = center + (poly.astype(np.float32) - center) * scale
        p[:, 1] += dy_frac * float(base_span)
        p[:, 0] = np.clip(p[:, 0], 0, w - 1)
        p[:, 1] = np.clip(p[:, 1], 0, h - 1)
        ex, ey, ebw, ebh = cv2.boundingRect(p.astype(np.int32))
        pad = max(12, int(0.08 * max(ebw, ebh)))
        x1, y1 = max(0, ex - pad), max(0, ey - pad)
        x2, y2 = min(w, ex + ebw + pad), min(h, ey + ebh + pad)
        if x2 <= x1 or y2 <= y1:
            continue
        roi = gray[y1:y2, x1:x2].copy()
        mask = np.zeros_like(roi)
        cv2.fillPoly(mask, [(p - np.array([x1, y1])).astype(np.int32)], 255)
        # Neutral background prevents other cube faces from stealing the match.
        masked = np.where(mask > 0, roi, bg_value).astype(np.uint8)
        variants.append((preprocess_image(masked), x1, y1))

    for enhanced, ox, oy in variants:
        for pat in patterns:
            ok, corners = cv2.findChessboardCorners(enhanced, pat, flags=flags)
            if ok and corners is not None:
                corners = corners.astype(np.float32)
                corners[:, 0, 0] += ox
                corners[:, 0, 1] += oy
                if verbose:
                    print(f"  Cube-first: {label} {pat[0]}x{pat[1]} classic")
                return corners, pat, label

    for rectified, H_inv in _rectified_face_variants(gray, poly):
        for pat in patterns:
            ok, corners = cv2.findChessboardCorners(rectified, pat, flags=flags)
            if ok and corners is not None:
                corners = cv2.perspectiveTransform(
                    corners.astype(np.float32), H_inv)
                if verbose:
                    print(f"  Cube-first: {label} {pat[0]}x{pat[1]} rectified")
                return corners, pat, label

    # SB is slower and can be more permissive, so use it only as a fallback.
    if hasattr(cv2, 'findChessboardCornersSB'):
        for enhanced, ox, oy in variants:
            for pat in patterns:
                ok, corners = cv2.findChessboardCornersSB(
                    enhanced, pat, flags=cv2.CALIB_CB_NORMALIZE_IMAGE)
                if ok and corners is not None:
                    corners = corners.astype(np.float32)
                    corners[:, 0, 0] += ox
                    corners[:, 0, 1] += oy
                    if verbose:
                        print(f"  Cube-first: {label} {pat[0]}x{pat[1]} SB")
                    return corners, pat, label
        for rectified, H_inv in _rectified_face_variants(gray, poly):
            for pat in patterns:
                ok, corners = cv2.findChessboardCornersSB(
                    rectified, pat, flags=cv2.CALIB_CB_NORMALIZE_IMAGE)
                if ok and corners is not None:
                    corners = cv2.perspectiveTransform(
                        corners.astype(np.float32), H_inv)
                    if verbose:
                        print(f"  Cube-first: {label} {pat[0]}x{pat[1]} rectified SB")
                    return corners, pat, label

    if verbose:
        print(f"  Cube-first: {label} pattern not found")
    return None


def _dir_from_angle(angle):
    return np.array([np.cos(float(angle)), np.sin(float(angle))],
                    dtype=np.float64)


def _edge_axis_alignment(corners, pattern, edge_angles):
    sig = _detection_face_signature(corners, pattern)
    if sig is None:
        return None
    row_dir, col_dir = sig
    e0 = _dir_from_angle(edge_angles[0])
    e1 = _dir_from_angle(edge_angles[1])
    same = _cos_sim(row_dir, e0) + _cos_sim(col_dir, e1)
    swapped = _cos_sim(row_dir, e1) + _cos_sim(col_dir, e0)
    return float(max(same, swapped))


def _score_edge_constrained_candidate(corners, pattern, edge_angles,
                                      vertex=None, sector=None):
    align = _edge_axis_alignment(corners, pattern, edge_angles)
    if align is None:
        return None
    if align < 1.25:
        return None

    sector_bonus = 0.0
    if vertex is not None and sector is not None:
        _ok, frac = _detection_fits_sector(
            corners, vertex, sector[0], sector[1], min_fraction=0.45)
        sector_bonus = 28.0 * float(frac)

    try:
        quality = _line_fit_quality(corners, pattern)
    except Exception:
        quality = 8.0
    if not np.isfinite(quality):
        quality = 8.0

    # Alignment is the primary signal.  Corner count breaks ties toward fuller
    # boards; line quality suppresses accidental partial matches.
    return (
        115.0 * float(align)
        + 0.35 * float(len(corners))
        + sector_bonus
        - 2.5 * float(min(quality, 8.0))
    )


def _detect_pattern_in_face_edge_constrained(gray, poly, label, edge_angles,
                                             vertex=None, sector=None,
                                             verbose=False):
    """Detect a face grid while preferring candidates aligned to its edge rays."""
    h, w = gray.shape[:2]
    poly = np.asarray(poly, dtype=np.int32).reshape(-1, 2)
    x, y, bw, bh = cv2.boundingRect(poly)
    base_span = max(bw, bh)
    if bw <= 0 or bh <= 0:
        return None

    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    patterns = _patterns_for_label(label)
    center = poly.astype(np.float32).mean(axis=0)
    candidates = []

    first = _detect_pattern_in_face(gray, poly, label, verbose=False)
    if first is not None:
        corners, pat, _label = first
        score = _score_edge_constrained_candidate(
            corners, pat, edge_angles, vertex=vertex, sector=sector)
        if score is not None:
            if vertex is not None and sector is not None:
                ok_sector, frac = _detection_fits_sector(
                    corners, vertex, sector[0], sector[1],
                    min_fraction=0.62)
                if not ok_sector:
                    if verbose:
                        print(
                            f"  Trihedral reject {label}: "
                            f"first grid sector_fraction={frac:.2f}"
                        )
                    return None
            if verbose:
                align = _edge_axis_alignment(corners, pat, edge_angles)
                print(
                    f"  Trihedral: {label} {pat[0]}x{pat[1]} first "
                    f"score={score:.1f} align={align:.2f}"
                )
            return first
        if verbose:
            print(f"  Trihedral reject {label}: first grid axis mismatch")
        return None

    def choose_best():
        if not candidates:
            return None
        candidates.sort(key=lambda c: c[0], reverse=True)
        score, corners, pat, source = candidates[0]
        if verbose:
            align = _edge_axis_alignment(corners, pat, edge_angles)
            print(
                f"  Trihedral: {label} {pat[0]}x{pat[1]} {source} "
                f"score={score:.1f} align={align:.2f}"
            )
        return corners, pat, label

    def add_candidate(corners, pat, source, ox=0.0, oy=0.0):
        c = corners.astype(np.float32).copy()
        c[:, 0, 0] += float(ox)
        c[:, 0, 1] += float(oy)
        score = _score_edge_constrained_candidate(
            c, pat, edge_angles, vertex=vertex, sector=sector)
        if score is None:
            return
        candidates.append((score, c, pat, source))

    variants = []
    pad = max(12, int(0.08 * max(bw, bh)))
    x1, y1 = max(0, x - pad), max(0, y - pad)
    x2, y2 = min(w, x + bw + pad), min(h, y + bh + pad)
    if x2 > x1 and y2 > y1:
        roi = gray[y1:y2, x1:x2].copy()
        for scale in (1.0, 1.12, 1.25, 1.38):
            p = center + (poly.astype(np.float32) - center) * scale
            p[:, 0] = np.clip(p[:, 0], 0, w - 1)
            p[:, 1] = np.clip(p[:, 1], 0, h - 1)
            mask = np.zeros_like(roi)
            cv2.fillPoly(
                mask, [(p - np.array([x1, y1])).astype(np.int32)], 255)
            masked = np.where(mask > 0, roi, 210).astype(np.uint8)
            variants.append((preprocess_image(masked), x1, y1, 'classic'))

    face_expansions = [
        (1.25, 0.00, 210),
        (1.35, 0.10, 210),
        (1.45, 0.15, 127),
        (1.60, 0.20, 127),
    ]
    for scale, dy_frac, bg_value in face_expansions:
        p = center + (poly.astype(np.float32) - center) * scale
        p[:, 1] += dy_frac * float(base_span)
        p[:, 0] = np.clip(p[:, 0], 0, w - 1)
        p[:, 1] = np.clip(p[:, 1], 0, h - 1)
        ex, ey, ebw, ebh = cv2.boundingRect(p.astype(np.int32))
        pad = max(12, int(0.08 * max(ebw, ebh)))
        rx1, ry1 = max(0, ex - pad), max(0, ey - pad)
        rx2, ry2 = min(w, ex + ebw + pad), min(h, ey + ebh + pad)
        if rx2 <= rx1 or ry2 <= ry1:
            continue
        roi = gray[ry1:ry2, rx1:rx2].copy()
        mask = np.zeros_like(roi)
        cv2.fillPoly(mask, [(p - np.array([rx1, ry1])).astype(np.int32)], 255)
        masked = np.where(mask > 0, roi, bg_value).astype(np.uint8)
        variants.append((preprocess_image(masked), rx1, ry1, 'expanded'))

    for enhanced, ox, oy, source in variants:
        for pat in patterns:
            ok, corners = cv2.findChessboardCorners(enhanced, pat, flags=flags)
            if ok and corners is not None:
                add_candidate(corners, pat, source, ox, oy)

    for rectified, H_inv in _rectified_face_variants(gray, poly):
        for pat in patterns:
            ok, corners = cv2.findChessboardCorners(rectified, pat, flags=flags)
            if ok and corners is not None:
                mapped = cv2.perspectiveTransform(
                    corners.astype(np.float32), H_inv)
                add_candidate(mapped, pat, 'rectified')

    chosen = choose_best()
    if chosen is not None:
        return chosen

    if hasattr(cv2, 'findChessboardCornersSB'):
        for enhanced, ox, oy, source in variants:
            for pat in patterns:
                ok, corners = cv2.findChessboardCornersSB(
                    enhanced, pat, flags=cv2.CALIB_CB_NORMALIZE_IMAGE)
                if ok and corners is not None:
                    add_candidate(corners, pat, source + '-SB', ox, oy)
        for rectified, H_inv in _rectified_face_variants(gray, poly):
            for pat in patterns:
                ok, corners = cv2.findChessboardCornersSB(
                    rectified, pat, flags=cv2.CALIB_CB_NORMALIZE_IMAGE)
                if ok and corners is not None:
                    mapped = cv2.perspectiveTransform(
                        corners.astype(np.float32), H_inv)
                    add_candidate(mapped, pat, 'rectified-SB')

    chosen = choose_best()
    if chosen is not None:
        return chosen

    if verbose:
        print(f"  Trihedral: {label} no edge-aligned grid")
    return None


def _detect_cube_first(gray, n_faces=3, verbose=False):
    """Detect cube faces first, then detect the grid inside each face."""
    clusters = _cluster_dark_components(gray, n_faces=n_faces, verbose=verbose)
    if len(clusters) < min(n_faces, 2):
        return []

    labeled = _label_cube_clusters(clusters)
    detections = []
    for face in labeled:
        label = face.get('label')
        if label is None:
            continue
        det = _detect_pattern_in_face(gray, face['poly'], label, verbose=verbose)
        if det is not None:
            detections.append(det)

    # Return in geometric order for downstream face definitions.
    order = {'XY': 0, 'XZ': 1, 'YZ': 2}
    detections.sort(key=lambda d: order.get(d[2], 99))
    return detections


def _line_from_points(p1, p2):
    p1 = np.asarray(p1, dtype=np.float64)
    p2 = np.asarray(p2, dtype=np.float64)
    line = np.cross([p1[0], p1[1], 1.0], [p2[0], p2[1], 1.0])
    n = np.linalg.norm(line[:2])
    return line / n if n > 1e-12 else None


def _line_intersection(l1, l2):
    p = np.cross(l1, l2)
    if abs(p[2]) < 1e-9:
        return None
    return np.array([p[0] / p[2], p[1] / p[2]], dtype=np.float64)


def _angle_diff_positive(a1, a2):
    return (float(a2) - float(a1)) % (2.0 * np.pi)


def _angles_in_sector(angles, start, end):
    width = _angle_diff_positive(start, end)
    rel = (angles - float(start)) % (2.0 * np.pi)
    return (rel > 0.0) & (rel < width)


def _trihedral_sector_counts(points, vertex, ray_angles):
    if len(points) == 0:
        return [0, 0, 0], [np.zeros((0,), dtype=bool) for _ in range(3)]
    rel = points.astype(np.float64) - vertex.reshape(1, 2)
    r = np.linalg.norm(rel, axis=1)
    ang = (np.arctan2(rel[:, 1], rel[:, 0]) + 2.0 * np.pi) % (2.0 * np.pi)
    usable = r > 8.0
    masks = []
    counts = []
    for i in range(3):
        start = ray_angles[i]
        end = ray_angles[(i + 1) % 3]
        mask = _angles_in_sector(ang, start, end) & usable
        masks.append(mask)
        counts.append(int(mask.sum()))
    return counts, masks


def _extract_edge_segments_for_trihedral(gray):
    h, w = gray.shape[:2]
    max_dim = max(h, w)
    if max_dim < 160:
        return []

    enhanced = preprocess_image(gray)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edges_a = cv2.Canny(blur, 45, 135, apertureSize=3)
    edges_b = cv2.Canny(enhanced, 60, 180, apertureSize=3)
    edges = cv2.bitwise_or(edges_a, edges_b)

    min_len = max(42, int(0.10 * max_dim))
    max_gap = max(10, int(0.025 * max_dim))
    threshold = max(35, int(0.055 * max_dim))
    raw = cv2.HoughLinesP(
        edges, 1, np.pi / 180.0, threshold,
        minLineLength=min_len, maxLineGap=max_gap)
    if raw is None:
        return []

    segments = []
    for item in raw.reshape(-1, 4):
        p1 = np.array([float(item[0]), float(item[1])], dtype=np.float64)
        p2 = np.array([float(item[2]), float(item[3])], dtype=np.float64)
        length = float(np.linalg.norm(p2 - p1))
        if length < min_len:
            continue
        line = _line_from_points(p1, p2)
        if line is None:
            continue
        direction = _line_dir(line)
        segments.append({
            'p1': p1, 'p2': p2, 'line': line,
            'dir': direction, 'length': length,
        })

    segments.sort(key=lambda s: s['length'], reverse=True)
    return segments[:55]


def _find_trihedral_edge_layout(gray, verbose=False):
    """Find three edge rays meeting at one visible cube corner.

    The Hough output contains many checkerboard grid lines, so the score also
    asks the three sectors to contain dark-square components.  This keeps the
    branch conservative: it is used only when the three rays plausibly split
    the actual cube target into three populated face regions.
    """
    h, w = gray.shape[:2]
    max_dim = max(h, w)
    segments = _extract_edge_segments_for_trihedral(gray)
    if len(segments) < 3:
        return None

    _filtered, components = _dark_square_components(gray)
    comp_pts = np.array([c['center'] for c in components], dtype=np.float64)
    comp_boxes = np.array([c['bbox'] for c in components], dtype=np.int32)
    if len(comp_pts) < 12:
        return None

    spread_tol = max(20.0, 0.038 * max_dim)
    min_ray = max(70.0, 0.13 * max_dim)
    min_sector = 3 if len(comp_pts) < 24 else 4
    best = None

    for s1, s2, s3 in combinations(segments, 3):
        segs = (s1, s2, s3)
        if any(_cos_sim(a['dir'], b['dir']) > 0.955
               for a, b in combinations(segs, 2)):
            continue

        intersections = []
        ok = True
        for a, b in combinations(segs, 2):
            p = _line_intersection(a['line'], b['line'])
            if p is None:
                ok = False
                break
            intersections.append(p)
        if not ok:
            continue

        vertex = np.mean(np.vstack(intersections), axis=0)
        spread = max(float(np.linalg.norm(p - vertex)) for p in intersections)
        if spread > spread_tol:
            continue
        margin = 0.10 * max_dim
        if not (-margin <= vertex[0] <= w + margin
                and -margin <= vertex[1] <= h + margin):
            continue

        ray_dirs = []
        ray_lengths = []
        for seg in segs:
            d1 = np.linalg.norm(seg['p1'] - vertex)
            d2 = np.linalg.norm(seg['p2'] - vertex)
            far = seg['p1'] if d1 >= d2 else seg['p2']
            ray = far - vertex
            ray_len = float(np.linalg.norm(ray))
            if ray_len < min_ray:
                ok = False
                break
            ray_dirs.append(ray / max(ray_len, 1e-12))
            ray_lengths.append(ray_len)
        if not ok:
            continue

        ray_angles = sorted(
            (np.arctan2(d[1], d[0]) + 2.0 * np.pi) % (2.0 * np.pi)
            for d in ray_dirs)
        gaps = [
            _angle_diff_positive(ray_angles[i], ray_angles[(i + 1) % 3])
            for i in range(3)
        ]
        min_gap = min(gaps)
        max_gap = max(gaps)
        if min_gap < np.deg2rad(24.0) or max_gap > np.deg2rad(188.0):
            continue

        counts, masks = _trihedral_sector_counts(comp_pts, vertex, ray_angles)
        if min(counts) < min_sector:
            continue

        balance = max(counts) / float(max(min(counts), 1))
        angular_balance = sum(abs(g - (2.0 * np.pi / 3.0)) for g in gaps)
        score = (
            sum(s['length'] for s in segs)
            + 35.0 * sum(np.sqrt(counts))
            - 80.0 * np.log(max(balance, 1.0))
            - 5.0 * spread
            - 28.0 * angular_balance
        )
        if best is None or score > best['score']:
            best = {
                'score': float(score),
                'vertex': vertex.astype(np.float32),
                'ray_angles': [float(a) for a in ray_angles],
                'counts': counts,
                'component_points': comp_pts.astype(np.float32),
                'component_boxes': comp_boxes,
                'component_masks': masks,
            }

    if verbose and best is not None:
        vx, vy = best['vertex']
        print(
            "  Trihedral edges: "
            f"vertex=({vx:.0f},{vy:.0f}), "
            f"sector_counts={best['counts']}, "
            f"score={best['score']:.1f}"
        )
    return best


def _sector_polygon(shape, vertex, start, end):
    h, w = shape[:2]
    yy, xx = np.indices((h, w))
    angles = (
        np.arctan2(yy.astype(np.float32) - float(vertex[1]),
                   xx.astype(np.float32) - float(vertex[0]))
        + 2.0 * np.pi
    ) % (2.0 * np.pi)
    mask = _angles_in_sector(angles, start, end).astype(np.uint8) * 255
    cv2.circle(
        mask, (int(round(vertex[0])), int(round(vertex[1]))),
        max(3, int(0.012 * max(h, w))), 0, -1)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL,
                                   cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    cnt = max(contours, key=cv2.contourArea)
    if cv2.contourArea(cnt) < 0.015 * float(h * w):
        return None
    eps = 0.012 * cv2.arcLength(cnt, True)
    poly = cv2.approxPolyDP(cnt, eps, True).reshape(-1, 2)
    if len(poly) < 3:
        return None
    return _order_poly_points(poly).astype(np.float32)


def _sector_mask(shape, vertex, start, end):
    h, w = shape[:2]
    yy, xx = np.indices((h, w))
    angles = (
        np.arctan2(yy.astype(np.float32) - float(vertex[1]),
                   xx.astype(np.float32) - float(vertex[0]))
        + 2.0 * np.pi
    ) % (2.0 * np.pi)
    return _angles_in_sector(angles, start, end).astype(np.uint8) * 255


def _trihedral_face_regions(gray, layout):
    h, w = gray.shape[:2]
    vertex = layout['vertex'].astype(np.float32)
    comp_pts = layout['component_points'].astype(np.float32)
    comp_boxes = layout.get('component_boxes')
    regions = []
    for i in range(3):
        start = layout['ray_angles'][i]
        end = layout['ray_angles'][(i + 1) % 3]
        mask = layout['component_masks'][i]
        if comp_boxes is None or not len(comp_pts) or not mask.any():
            continue

        face_mask = np.zeros((h, w), dtype=np.uint8)
        idxs = np.flatnonzero(mask)
        sizes = []
        for idx in idxs:
            x, y, bw, bh = [int(v) for v in comp_boxes[idx]]
            x2, y2 = min(w, x + bw), min(h, y + bh)
            face_mask[max(0, y):y2, max(0, x):x2] = 255
            sizes.append(max(bw, bh))
        if not sizes:
            continue

        k = int(round(np.median(sizes) * 1.85))
        k = max(13, min(41, k))
        if k % 2 == 0:
            k += 1
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (k, k))
        face_mask = cv2.dilate(face_mask, kernel, iterations=2)
        face_mask = cv2.bitwise_and(
            face_mask, _sector_mask((h, w), vertex, start, end))

        contours, _ = cv2.findContours(face_mask, cv2.RETR_EXTERNAL,
                                       cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            continue
        cnt = max(contours, key=cv2.contourArea)
        if cv2.contourArea(cnt) < 80:
            continue

        hull = cv2.convexHull(cnt)
        eps = 0.03 * cv2.arcLength(hull, True)
        poly = cv2.approxPolyDP(hull, eps, True).reshape(-1, 2)
        if len(poly) < 4:
            x, y, bw, bh = cv2.boundingRect(cnt)
            poly = np.array([[x, y], [x + bw, y],
                             [x + bw, y + bh], [x, y + bh]],
                            dtype=np.int32)
        poly = _order_poly_points(poly).astype(np.float32)
        x, y, bw, bh = cv2.boundingRect(poly.astype(np.int32))
        center = comp_pts[mask].mean(axis=0)
        regions.append({
            'count': int(layout['counts'][i]),
            'bbox': (int(x), int(y), int(bw), int(bh)),
            'center': center.astype(np.float32),
            'poly': poly,
            'sector_start': float(start),
            'sector_end': float(end),
            'sector_idx': int(i),
        })
    if len(regions) < 3:
        return []
    return _label_cube_clusters(regions)


def _detection_fits_sector(corners, vertex, start, end, min_fraction=0.62):
    pts = corners.reshape(-1, 2).astype(np.float32)
    rel = pts - vertex.reshape(1, 2).astype(np.float32)
    angles = (np.arctan2(rel[:, 1], rel[:, 0]) + 2.0 * np.pi) % (2.0 * np.pi)
    inside = _angles_in_sector(angles, start, end)
    frac = float(inside.mean()) if len(inside) else 0.0

    center = pts.mean(axis=0)
    crel = center - vertex.astype(np.float32)
    cang = (np.arctan2(crel[1], crel[0]) + 2.0 * np.pi) % (2.0 * np.pi)
    center_inside = bool(_angles_in_sector(np.array([cang]), start, end)[0])
    return center_inside and frac >= min_fraction, frac


def _detect_cube_edges_first(gray, n_faces=3, verbose=False):
    if n_faces < 3:
        return []
    layout = _find_trihedral_edge_layout(gray, verbose=verbose)
    if layout is None:
        return []

    detections = []
    for face in _trihedral_face_regions(gray, layout):
        label = face.get('label')
        if label is None:
            continue
        det = _detect_pattern_in_face_edge_constrained(
            gray, face['poly'], label,
            (face.get('sector_start', 0.0), face.get('sector_end', 0.0)),
            vertex=layout['vertex'],
            sector=(face.get('sector_start', 0.0),
                    face.get('sector_end', 0.0)),
            verbose=verbose)
        if det is not None:
            ok_sector, frac = _detection_fits_sector(
                det[0], layout['vertex'],
                face.get('sector_start', 0.0),
                face.get('sector_end', 0.0))
            if not ok_sector:
                if verbose:
                    print(
                        f"  Trihedral reject {label}: "
                        f"sector_fraction={frac:.2f}"
                    )
                continue
            detections.append(det)

    if len(detections) >= 2:
        detections = _normalize_face_axis_order(detections)
    if _detections_have_excessive_overlap(detections, threshold=0.55):
        return []

    order = {'XY': 0, 'XZ': 1, 'YZ': 2}
    detections.sort(key=lambda d: order.get(d[2], 99))
    if verbose and detections:
        labels = [d[2] for d in detections]
        print(f"  Trihedral edge-first grids: {labels}")
    return detections


def _cube_crop_from_clusters(gray, n_faces=3):
    """Return an expanded cube crop box from dark-square face clusters."""
    h, w = gray.shape[:2]
    clusters = _cluster_dark_components(gray, n_faces=n_faces, verbose=False)
    if len(clusters) < min(n_faces, 2):
        return None

    boxes = []
    for cluster in clusters:
        x, y, bw, bh = cluster['bbox']
        boxes.append((x, y, x + bw, y + bh))
    x1 = min(b[0] for b in boxes)
    y1 = min(b[1] for b in boxes)
    x2 = max(b[2] for b in boxes)
    y2 = max(b[3] for b in boxes)

    bw = max(1, x2 - x1)
    bh = max(1, y2 - y1)
    span = max(bw, bh)
    pad = max(24, int(0.28 * span))
    x1 = max(0, x1 - pad)
    y1 = max(0, y1 - pad)
    x2 = min(w, x2 + pad)
    y2 = min(h, y2 + pad)
    if x2 - x1 < 80 or y2 - y1 < 80:
        return None
    return int(x1), int(y1), int(x2), int(y2)


def _map_scaled_detections_to_image(detections, x0, y0, scale):
    mapped = []
    for corners, pat, label in detections:
        c = corners.reshape(-1, 1, 2).astype(np.float32).copy()
        c[:, 0, 0] = c[:, 0, 0] / float(scale) + float(x0)
        c[:, 0, 1] = c[:, 0, 1] / float(scale) + float(y0)
        mapped.append((c, pat, label))
    return mapped


def _map_scaled_face_candidates_to_image(candidates, x0, y0, scale):
    mapped = []
    for _score, corners, pat, label, source in candidates:
        c = corners.reshape(-1, 1, 2).astype(np.float32).copy()
        c[:, 0, 0] = c[:, 0, 0] / float(scale) + float(x0)
        c[:, 0, 1] = c[:, 0, 1] / float(scale) + float(y0)
        mapped_source = f"{source}-upscaled"
        score = _score_face_upgrade_candidate(c, pat, mapped_source)
        mapped.append((score, c, pat, label, mapped_source))
    return mapped


def _collect_upscaled_face_candidates_for_recovery(
        gray, n_faces=3, max_candidates=None, needed_labels=None,
        verbose=False, patterns_by_label=None):
    """Collect face-grid candidates on an upscaled cube crop.

    The candidates are mapped back into original-image coordinates before any
    calibration code sees them, so the square size remains the only metric
    input.
    """
    crop_box = _cube_crop_from_clusters(gray, n_faces=n_faces)
    if crop_box is None:
        return {'XY': [], 'XZ': [], 'YZ': []}

    x1, y1, x2, y2 = crop_box
    crop = gray[y1:y2, x1:x2]
    ch, cw = crop.shape[:2]
    max_dim = max(cw, ch)
    by_label = {'XY': [], 'XZ': [], 'YZ': []}
    if needed_labels is None:
        needed = set(by_label)
    else:
        needed = {label for label in needed_labels if label in by_label}
    if not needed:
        return by_label
    seen_targets = []
    limit = max_candidates or MAX_SPARSE_RECOVERY_FACE_CANDIDATES

    for target_dim in CUBE_CROP_UPSCALE_TARGET_DIMS:
        if any(abs(float(target_dim) - old) < 1e-6 for old in seen_targets):
            continue
        seen_targets.append(float(target_dim))
        scale = min(
            float(CUBE_CROP_UPSCALE_MAX_SCALE),
            float(target_dim) / float(max(max_dim, 1)),
        )
        if scale < float(CUBE_CROP_UPSCALE_MIN_SCALE):
            continue
        up_w = int(round(cw * scale))
        up_h = int(round(ch * scale))
        if up_w < 120 or up_h < 120:
            continue
        upscaled = cv2.resize(crop, (up_w, up_h), interpolation=cv2.INTER_CUBIC)
        clusters = _label_cube_clusters(
            _cluster_dark_components(upscaled, n_faces=n_faces, verbose=False))
        for face in clusters:
            label = face.get('label')
            if label not in needed:
                continue
            patterns_override = (
                patterns_by_label.get(label)
                if patterns_by_label is not None
                else None
            )
            raw = _detect_pattern_candidates_in_face(
                upscaled, face['poly'], label, max_candidates=limit,
                patterns_override=patterns_override)
            mapped = _map_scaled_face_candidates_to_image(raw, x1, y1, scale)
            by_label[label].extend(mapped)
            by_label[label] = _dedupe_face_candidates(by_label[label])[:limit]
        if all(
            any(min(pat) >= 5 for _s, _c, pat, _label, _src in by_label[label])
            for label in needed
        ):
            break

    if verbose:
        counts = ', '.join(f"{label}:{len(items)}" for label, items in by_label.items())
        if any(by_label.values()):
            print(f"  Sparse recovery upscaled candidates: {counts}")
    return by_label


def _crop_upscaled_detection_is_complete(detections, image_shape, n_faces=3):
    if len(detections) < n_faces:
        return False
    if _cube_detection_sparse_face_count(detections) > 0:
        return False
    if _total_corner_count(detections) < 120:
        return False
    geom = _cube_detection_geometry_rmse(detections, image_shape, n_faces=n_faces)
    return (
        np.isfinite(geom)
        and geom <= MAX_EARLY_STOP_CROP_UPSCALE_FAST_PNP_RMSE_PX
    )


def _crop_box_near_image_border(crop_box, image_shape,
                                margin=CUBE_CROP_BORDER_MARGIN_PX):
    if crop_box is None or image_shape is None:
        return False
    x1, y1, x2, y2 = crop_box
    h, w = image_shape[:2]
    return (
        x1 <= margin
        or y1 <= margin
        or x2 >= w - margin
        or y2 >= h - margin
    )


def _crop_upscaled_cluster_fast_exit_reason(
        detections, crop_box, image_shape, n_faces=3):
    if not detections:
        return None
    corners = _total_corner_count(detections)
    if (
        len(detections) >= n_faces
        and corners >= CUBE_CROP_CLUSTER_FAST_EXIT_CORNERS
    ):
        return "three-face-cluster"
    if (
        len(detections) >= 2
        and corners >= CUBE_CROP_BORDER_CLUSTER_FAST_EXIT_CORNERS
        and _cube_detection_sparse_face_count(detections) == 0
        and _crop_box_near_image_border(crop_box, image_shape)
    ):
        return "border-two-face-cluster"
    return None


def _detect_cube_first_in_upscaled_crop(gray, n_faces=3, verbose=False):
    """Crop the cube, upscale it, detect faces, then map corners back.

    The calibration still uses original-image coordinates and the fixed
    checker square size; this only improves the image-space detector when the
    cube occupies a small fraction of the frame.
    """
    crop_box = _cube_crop_from_clusters(gray, n_faces=n_faces)
    if crop_box is None:
        return []

    x1, y1, x2, y2 = crop_box
    crop = gray[y1:y2, x1:x2]
    ch, cw = crop.shape[:2]
    max_dim = max(cw, ch)
    best_mapped = []
    best_meta = None
    seen_targets = []
    for target_idx, target_dim in enumerate(CUBE_CROP_UPSCALE_TARGET_DIMS):
        if any(abs(float(target_dim) - old) < 1e-6 for old in seen_targets):
            continue
        seen_targets.append(float(target_dim))
        if target_idx > 0 and len(best_mapped) < 2:
            break
        scale = min(
            float(CUBE_CROP_UPSCALE_MAX_SCALE),
            float(target_dim) / float(max(max_dim, 1)),
        )
        if scale < float(CUBE_CROP_UPSCALE_MIN_SCALE):
            continue

        up_w = int(round(cw * scale))
        up_h = int(round(ch * scale))
        if up_w < 120 or up_h < 120:
            continue
        upscaled = cv2.resize(crop, (up_w, up_h), interpolation=cv2.INTER_CUBIC)
        cluster_detections = []
        cluster_fast_exit_reason = None
        if target_idx == 0:
            cluster_detections = _detect_cube_first(
                upscaled, n_faces=n_faces, verbose=False)
            cluster_fast_exit_reason = (
                _crop_upscaled_cluster_fast_exit_reason(
                    cluster_detections, crop_box, gray.shape,
                    n_faces=n_faces)
            )
        if cluster_fast_exit_reason is not None:
            detections = cluster_detections
            source = "cluster-fast"
        else:
            edge_detections = _detect_cube_edges_first(
                upscaled, n_faces=n_faces, verbose=verbose)
            detections = _choose_cube_first_detection(
                edge_detections, cluster_detections, n_faces=n_faces,
                image_shape=upscaled.shape)
            source = "edge" if detections is edge_detections else "cluster"
        detections = _normalize_face_axis_order(detections)
        mapped = _map_scaled_detections_to_image(detections, x1, y1, scale)
        if not mapped:
            continue

        chosen = _choose_cube_first_detection(
            mapped, best_mapped, n_faces=n_faces, image_shape=gray.shape)
        if chosen is mapped or not best_mapped:
            best_mapped = mapped
            best_meta = (cw, ch, up_w, up_h, scale, source, target_dim)
        if _crop_upscaled_detection_is_complete(
                mapped, gray.shape, n_faces=n_faces):
            best_mapped = mapped
            best_meta = (cw, ch, up_w, up_h, scale, source, target_dim)
            break
        if cluster_fast_exit_reason is not None:
            break

    if verbose and best_mapped and best_meta is not None:
        _cw, _ch, up_w, up_h, scale, source, target_dim = best_meta
        print(
            "  Cube-first upscaled crop: "
            f"{cw}x{ch} -> {up_w}x{up_h}, "
            f"{len(best_mapped)} face(s), {scale:.2f}x, "
            f"target={target_dim:.0f}, {source}"
        )
    return best_mapped


def _cube_detection_sparse_face_count(detections):
    return int(sum(
        1 for _corners, pat, _label in detections
        if min(pat) < 5
    ))


def _cube_detection_geometry_rmse(detections, image_shape, n_faces=3,
                                  allow_sparse=False,
                                  assume_normalized=False):
    """Fast pooled-PnP consistency score for competing cube detections."""
    if len(detections) < n_faces:
        return float('inf')

    ordered = list(detections)[:n_faces] if assume_normalized else _normalize_face_axis_order(detections)[:n_faces]
    if len(ordered) < n_faces:
        return float('inf')
    if (not allow_sparse) and _cube_detection_sparse_face_count(ordered):
        return float('inf')

    try:
        patterns = [pat for _corners, pat, _label in ordered]
        faces = standard_three_face_target(
            25.0, 9, 6,
            face_patterns=patterns, n_faces=n_faces,
            center_patterns_on_cube=True,
        )
        h, w = image_shape[:2]
        diag = float(np.hypot(w, h))
        if allow_sparse:
            focal_seeds = [0.55 * diag, 0.70 * diag]
        else:
            focal_seeds = [0.55 * diag, 0.82 * diag, 1.10 * diag, 1.60 * diag]
        best = float('inf')
        for focal in focal_seeds:
            K = np.array([
                [focal, 0.0, w / 2.0],
                [0.0, focal, h / 2.0],
                [0.0, 0.0, 1.0],
            ], dtype=np.float64)
            detected = []
            for (corners, _pat, _label), face in zip(ordered, faces):
                detected.append(DetectedFace(
                    image_points=corners.reshape(-1, 1, 2).astype(np.float32),
                    object_points=object_points_for_face(face),
                    valid=True,
                ))
            orientations = apply_best_face_orientations(
                detected, faces, list(range(n_faces)), K, None)
            if orientations:
                best = min(best, float(orientations[0]["rmse"]))
        return best
    except Exception:
        return float('inf')


def _standard_face_axes():
    ex = np.array([1.0, 0.0, 0.0])
    ey = np.array([0.0, 1.0, 0.0])
    ez = np.array([0.0, 0.0, 1.0])
    return [(ex, ey), (ex, ez), (ey, ez)]


def _center_offsets_in_squares(patterns):
    max_outer_squares = max(max(c + 1, r + 1) for c, r in patterns)
    offsets = []
    for c, r in patterns:
        offsets.append((
            0.5 * (max_outer_squares - (c + 1)) + 1.0,
            0.5 * (max_outer_squares - (r + 1)) + 1.0,
        ))
    return max_outer_squares, offsets


def _faces_from_square_offsets(patterns, square_size, offsets):
    axes = _standard_face_axes()
    faces = []
    for i, (pattern, (ox, oy)) in enumerate(zip(patterns, offsets)):
        axis_x, axis_y = axes[i]
        faces.append(FaceDefinition(
            pattern_size=pattern,
            square_size=square_size,
            axis_x=axis_x,
            axis_y=axis_y,
            origin_3d=square_size * (ox * axis_x + oy * axis_y),
        ))
    return faces


def _cube_detection_best_offset_pnp_rmse(
        detections, image_shape, n_faces=3,
        max_offset_dist=MAX_SPARSE_RECOVERY_OFFSET_DIST_SQUARES,
        assume_normalized=False,
        early_stop_rmse=None):
    """Best PnP RMSE after moving one detected face by integer square offsets."""
    if len(detections) < n_faces:
        return float('inf'), None, float('inf')
    ordered = list(detections)[:n_faces] if assume_normalized else _normalize_face_axis_order(detections)[:n_faces]
    if len(ordered) < n_faces:
        return float('inf'), None, float('inf')
    try:
        patterns = [pat for _corners, pat, _label in ordered]
        max_outer_squares, base_offsets = _center_offsets_in_squares(patterns)
        h, w = image_shape[:2]
        diag = float(np.hypot(w, h))
        focal_seeds = [0.55 * diag, 0.70 * diag]
        best = (float('inf'), None, float('inf'))

        offset_options = []
        sparse_indices = [
            i for i, pat in enumerate(patterns)
            if min(pat) < 5
        ]
        vary_indices = sparse_indices or list(range(len(patterns)))
        for vary_face in vary_indices:
            cols, rows = patterns[vary_face]
            center_x, center_y = base_offsets[vary_face]
            for ox in range(1, int(max_outer_squares - cols) + 1):
                for oy in range(1, int(max_outer_squares - rows) + 1):
                    offset_dist = float(np.hypot(
                        float(ox) - float(center_x),
                        float(oy) - float(center_y),
                    ))
                    if offset_dist <= 1e-6 or offset_dist > max_offset_dist:
                        continue
                    offset_options.append((vary_face, float(ox), float(oy), offset_dist))
        offset_options.sort(key=lambda item: item[3])

        for vary_face, ox, oy, offset_dist in offset_options:
            offsets = list(base_offsets)
            offsets[vary_face] = (ox, oy)
            faces = _faces_from_square_offsets(patterns, 25.0, offsets)
            for focal in focal_seeds:
                K = np.array([
                    [focal, 0.0, w / 2.0],
                    [0.0, focal, h / 2.0],
                    [0.0, 0.0, 1.0],
                ], dtype=np.float64)
                detected = []
                for (corners, _pat, _label), face in zip(ordered, faces):
                    detected.append(DetectedFace(
                        image_points=corners.reshape(-1, 1, 2).astype(np.float32),
                        object_points=object_points_for_face(face),
                        valid=True,
                    ))
                orientations = apply_best_face_orientations(
                    detected, faces, list(range(n_faces)), K, None)
                if not orientations:
                    continue
                rmse = float(orientations[0]["rmse"])
                if rmse < best[0]:
                    best = (rmse, (int(vary_face), ox, oy), offset_dist)
                    if (
                        early_stop_rmse is not None
                        and np.isfinite(rmse)
                        and rmse <= float(early_stop_rmse)
                    ):
                        return best
        return best
    except Exception:
        return float('inf'), None, float('inf')


def _sparse_topology_candidate_recovery(gray, baseline, n_faces=3,
                                        verbose=False,
                                        include_upscaled_candidates=True,
                                        include_legacy_candidates=False,
                                        cube_area_pct=None):
    """Recover multi-sparse cube-first detections with offset-aware topology."""
    if not ENABLE_SPARSE_TOPOLOGY_CANDIDATE_RECOVERY or n_faces < 3:
        return []
    baseline = _normalize_face_axis_order(baseline or [])
    if (
        len(baseline) < n_faces
        or _cube_detection_sparse_face_count(baseline) <= 0
    ):
        return []

    clusters = _label_cube_clusters(
        _cluster_dark_components(gray, n_faces=n_faces, verbose=False))
    if len(clusters) < n_faces:
        return []

    labels = ['XY', 'XZ', 'YZ']
    by_label = {'XY': [], 'XZ': [], 'YZ': []}
    baseline_sparse_labels = set()
    for corners, pat, label in baseline:
        if label in by_label:
            if min(pat) < 5:
                baseline_sparse_labels.add(label)
            score = _score_face_upgrade_candidate(corners, pat, 'baseline')
            by_label[label].append((score + 8.0, corners, pat, label, 'baseline'))
            by_label[label].extend(_detect_sparse_bbox_expanded_candidates(
                gray, corners, pat, label,
                max_candidates=MAX_SPARSE_BBOX_EXPAND_CANDIDATES))
            by_label[label] = _dedupe_face_candidates(by_label[label])[
                :MAX_SPARSE_RECOVERY_FACE_CANDIDATES
            ]
    if verbose:
        counts = ", ".join(
            f"{label}:{len(by_label[label])}" for label in labels)
        print(f"  Sparse bbox expansion candidates: {counts}")

    recover_all_labels = len(baseline_sparse_labels) > 1
    needed_original_labels = (
        list(labels)
        if recover_all_labels
        else [
            label for label in labels
            if label in baseline_sparse_labels or not any(
                min(pat) >= 5
                for _score, _corners, pat, _label, _source in by_label[label]
            )
        ]
    )
    for face in clusters:
        label = face.get('label')
        if label not in needed_original_labels:
            continue
        by_label[label].extend(_detect_pattern_candidates_in_face(
            gray, face['poly'], label,
            max_candidates=MAX_SPARSE_RECOVERY_FACE_CANDIDATES))
        by_label[label] = _dedupe_face_candidates(by_label[label])[
            :MAX_SPARSE_RECOVERY_FACE_CANDIDATES
        ]

    if include_legacy_candidates:
        legacy_counts = {label: 0 for label in labels}
        try:
            legacy_cands = _detect_all(gray, n_faces, verbose=False)
            legacy_clusters = _cluster_detections_by_direction(
                legacy_cands, verbose=False)
            legacy_labeled = _label_face_clusters(
                legacy_clusters, gray.shape, verbose=False)
            if len(legacy_labeled) < n_faces:
                legacy_labeled = _search_missing(
                    gray, preprocess_image(gray), legacy_labeled,
                    n_faces, verbose=False)
            legacy_refined = _normalize_face_axis_order(_refine(
                gray, legacy_labeled, verbose=False,
                enable_local_bbox=False))
        except Exception:
            legacy_refined = []
        for corners, pat, label in legacy_refined:
            if label not in by_label:
                continue
            score = _score_face_upgrade_candidate(
                corners, pat, 'legacy-global')
            by_label[label].append(
                (score + 1.0, corners, pat, label, 'legacy-global'))
            by_label[label] = _dedupe_face_candidates(by_label[label])[
                :MAX_SPARSE_RECOVERY_FACE_CANDIDATES
            ]
            legacy_counts[label] += 1
        if verbose and any(legacy_counts.values()):
            counts = ', '.join(
                f"{label}:{legacy_counts[label]}" for label in labels)
            print(f"  Sparse recovery legacy candidates: {counts}")

    needed_upscaled_labels = (
        list(labels)
        if recover_all_labels
        else [
            label for label in labels
            if label in baseline_sparse_labels or not any(
                min(pat) >= 5
                for _score, _corners, pat, _label, _source in by_label[label]
            )
        ]
    )
    if include_upscaled_candidates:
        upscaled_by_label = _collect_upscaled_face_candidates_for_recovery(
            gray, n_faces=n_faces,
            max_candidates=MAX_SPARSE_RECOVERY_FACE_CANDIDATES,
            needed_labels=needed_upscaled_labels,
            verbose=verbose)
        for label, candidates in upscaled_by_label.items():
            if label not in by_label or not candidates:
                continue
            by_label[label].extend(candidates)
            by_label[label] = _dedupe_face_candidates(by_label[label])[
                :MAX_SPARSE_RECOVERY_FACE_CANDIDATES
            ]
    elif verbose:
        print("  Sparse recovery upscaled candidates: deferred")

    if any(not by_label[label] for label in labels):
        return []

    raw_combos = [
        [xy, xz, yz]
        for xy in by_label['XY']
        for xz in by_label['XZ']
        for yz in by_label['YZ']
    ]

    def _sparse_recovery_combo_key(raw):
        corner_count = sum(len(corners) for _score, corners, _pat, _label, _source in raw)
        sparse_count = sum(
            1 for _score, _corners, pat, _label, _source in raw
            if min(pat) < 5
        )
        score_sum = sum(float(score) for score, _corners, _pat, _label, _source in raw)
        source_penalty = sum(
            2.0 if str(source).startswith('sparse-bbox') else
            0.8 if str(source).startswith('wide') else
            0.0
            for _score, _corners, _pat, _label, source in raw
        )
        low_corner_penalty = 1 if corner_count < MIN_VALIDATED_SMALL_TARGET_CORNERS else 0
        return (
            sparse_count,
            low_corner_penalty,
            source_penalty,
            -corner_count,
            -score_sum,
        )

    raw_combos.sort(key=_sparse_recovery_combo_key)
    if MAX_SPARSE_RECOVERY_GEOMETRY_COMBOS > 0:
        raw_combos = raw_combos[:MAX_SPARSE_RECOVERY_GEOMETRY_COMBOS]

    best = None
    axis_signature_cache = {}
    debug_sparse_combos = (
        verbose and os.environ.get('CUBE_DEBUG_SPARSE_COMBOS') == '1')
    for combo_idx, raw in enumerate(raw_combos, 1):
        verbose_desc = None
        if debug_sparse_combos:
            verbose_desc = ', '.join(
                f"{label}:{pat[0]}x{pat[1]}:{source}"
                for _s, _c, pat, label, source in raw
            )
        dets = [
            (corners, pat, label)
            for _score, corners, pat, label, _source in raw
        ]
        dets = _normalize_face_axis_order(
            dets, signature_cache=axis_signature_cache)
        if len(dets) < n_faces:
            continue
        if (
            cube_area_pct is not None
            and MIN_ACCEPTED_CUBE_AREA_PCT < 4.0
            and float(cube_area_pct) < 4.0
            and not _small_target_region_patterns_exact(dets)
        ):
            if debug_sparse_combos:
                print(
                    f"  Sparse combo {combo_idx}: reject non-exact "
                    f"3pct topology; {verbose_desc}"
                )
            continue
        sparse_count = _cube_detection_sparse_face_count(dets)
        if sparse_count > MAX_SPARSE_RECOVERY_SPARSE_FACES:
            if debug_sparse_combos:
                print(
                    f"  Sparse combo {combo_idx}: reject sparse_count="
                    f"{sparse_count}; {verbose_desc}"
                )
            continue
        overlap = _detections_have_excessive_overlap(
            dets, threshold=MAX_SPARSE_RECOVERY_OVERLAP_IOU)
        if overlap:
            if debug_sparse_combos:
                print(
                    f"  Sparse combo {combo_idx}: reject overlap; "
                    f"{verbose_desc}"
                )
            continue
        centered_geom = _cube_detection_geometry_rmse(
            dets, gray.shape, n_faces=n_faces, allow_sparse=True,
            assume_normalized=True)
        if (
            not np.isfinite(centered_geom)
            or centered_geom > MAX_SPARSE_RECOVERY_CENTERED_PNP_RMSE_PX
        ):
            if debug_sparse_combos:
                print(
                    f"  Sparse combo {combo_idx}: reject centered="
                    f"{centered_geom:.2f}; {verbose_desc}"
                )
            continue
        offset_rmse, offset, offset_dist = _cube_detection_best_offset_pnp_rmse(
            dets, gray.shape, n_faces=n_faces,
            assume_normalized=True)
        if (
            not np.isfinite(offset_rmse)
            or offset_rmse > MAX_SPARSE_RECOVERY_OFFSET_PNP_RMSE_PX
        ):
            if debug_sparse_combos:
                print(
                    f"  Sparse combo {combo_idx}: reject offset="
                    f"{offset_rmse:.2f}; {verbose_desc}"
                )
            continue
        corner_count = _total_corner_count(dets)
        wide_count = sum(
            1 for _score, _corners, _pat, _label, source in raw
            if source.startswith('wide')
        )
        score = (
            float(offset_rmse)
            + 0.12 * float(centered_geom)
            + 0.08 * float(offset_dist)
            + 0.65 * float(sparse_count)
            + 0.25 * float(wide_count)
            - 0.012 * float(corner_count)
        )
        if best is None or score < best[0]:
            if debug_sparse_combos:
                print(
                    f"  Sparse combo {combo_idx}: candidate "
                    f"offset={offset_rmse:.2f}, centered={centered_geom:.2f}, "
                    f"score={score:.2f}; {verbose_desc}"
                )
            best = (
                score, offset_rmse, centered_geom, offset, offset_dist,
                sparse_count, dets, raw,
            )

    if best is None:
        if verbose:
            print("  Sparse topology recovery rejected: no offset-safe candidate")
        return []

    (
        _score, offset_rmse, centered_geom, offset, _offset_dist,
        sparse_count, dets, raw,
    ) = best
    if verbose:
        desc = ', '.join(
            f"{label}:{pat[0]}x{pat[1]}:{source}"
            for _s, _c, pat, label, source in raw
        )
        off_desc = ""
        if offset is not None:
            labels = ['XY', 'XZ', 'YZ']
            off_desc = f", offset {labels[offset[0]]}=({offset[1]:.0f},{offset[2]:.0f})"
        print(
            "  Using sparse topology recovery candidate: "
            f"offset PnP={offset_rmse:.2f}px, centered PnP={centered_geom:.2f}px, "
            f"sparse_faces={sparse_count}{off_desc}; {desc}"
        )
    return dets


def _small_target_region_candidate_recovery(gray, baseline, n_faces=3,
                                            verbose=False,
                                            allow_grid_expand=True,
                                            include_baseline=True,
                                            max_centered_pnp_rmse=None,
                                            max_offset_pnp_rmse=None,
                                            cube_area_pct=None):
    """Try stronger in-face candidates for 6-8% cube images.

    This branch is intentionally narrow: it runs only after cube-first already
    sees three faces, but the detected per-face grids do not yet look like the
    validated physical target.  Candidates still come from face polygons or the
    cube crop-upscale path, and the winner must pass the same offset-aware cube
    geometry gate used by the sparse recovery code.
    """
    if (
        n_faces < 3
        or (
            not ENABLE_SMALL_TARGET_REGION_CANDIDATE_RECOVERY
            and not ENABLE_SMALL_TARGET_GRID_EXPAND_CANDIDATES
            and not ENABLE_SMALL_TARGET_TOP_BLOB_GRID_CANDIDATES
        )
    ):
        return []

    baseline = _normalize_face_axis_order(baseline or [])
    if len(baseline) < 2:
        return []

    labels = ['XY', 'XZ', 'YZ']
    baseline_corners = _total_corner_count(baseline[:n_faces])
    baseline_exact = _small_target_region_patterns_exact(baseline[:n_faces])
    if (
        baseline_exact
        and baseline_corners >= MIN_VALIDATED_SMALL_TARGET_CORNERS
    ):
        return []

    clusters = _label_cube_clusters(
        _cluster_dark_components(gray, n_faces=n_faces, verbose=False))
    if len(clusters) < n_faces:
        return []

    by_label = {'XY': [], 'XZ': [], 'YZ': []}
    if include_baseline:
        for corners, pat, label in baseline[:n_faces]:
            if label not in by_label:
                continue
            score = _score_face_upgrade_candidate(corners, pat, 'baseline')
            by_label[label].append((score + 12.0, corners, pat, label, 'baseline'))

    for face in clusters:
        label = face.get('label')
        if label not in by_label:
            continue
        by_label[label].extend(_detect_pattern_candidates_in_face(
            gray, face['poly'], label,
            max_candidates=MAX_SMALL_TARGET_REGION_FACE_CANDIDATES,
            patterns_override=_small_target_region_search_patterns(label)))
        by_label[label] = _add_trimmed_small_target_candidates(by_label[label])
        by_label[label] = _dedupe_face_candidates(by_label[label])[
            :MAX_SMALL_TARGET_REGION_FACE_CANDIDATES
        ]

    upscaled_research_pocket = (
        cube_area_pct is not None
        and MIN_ACCEPTED_CUBE_AREA_PCT < 4.0
        and float(cube_area_pct) < 3.5
    )
    need_upscaled = (
        (
            ENABLE_SMALL_TARGET_REGION_UPSCALED_CANDIDATES
            or upscaled_research_pocket
        )
        and any(len(by_label[label]) < 2 for label in labels)
    )
    if need_upscaled:
        upscaled_by_label = _collect_upscaled_face_candidates_for_recovery(
            gray, n_faces=n_faces,
            max_candidates=MAX_SMALL_TARGET_REGION_FACE_CANDIDATES,
            needed_labels=labels,
            verbose=verbose,
            patterns_by_label={
                label: _small_target_region_search_patterns(label)
                for label in labels
            })
        for label, candidates in upscaled_by_label.items():
            if label not in by_label or not candidates:
                continue
            by_label[label].extend(candidates)
            by_label[label] = _add_trimmed_small_target_candidates(by_label[label])
            by_label[label] = _dedupe_face_candidates(by_label[label])[
                :MAX_SMALL_TARGET_REGION_FACE_CANDIDATES
            ]

    if allow_grid_expand and ENABLE_SMALL_TARGET_GRID_EXPAND_CANDIDATES:
        context_dets = list(baseline[:n_faces])
        for label in labels:
            expanded = []
            for _score, corners, pat, cand_label, source in list(by_label[label]):
                if cand_label != label:
                    continue
                if not str(source).startswith('baseline'):
                    continue
                if 'trim-' in str(source):
                    continue
                if len(corners) >= 54:
                    continue
                if int(pat[0]) == int(pat[1]) and label == 'YZ':
                    continue
                expanded.extend(_small_target_grid_expand_candidates(
                    gray, corners, pat, label, source, context_dets))
            if expanded:
                by_label[label].extend(expanded)
                by_label[label] = _dedupe_face_candidates(by_label[label])[
                    :MAX_SMALL_TARGET_REGION_FACE_CANDIDATES
                ]

    if ENABLE_SMALL_TARGET_TOP_BLOB_GRID_CANDIDATES:
        top_faces = [face for face in clusters if face.get('label') == 'XY']
        if top_faces:
            baseline_xy_corners = [
                len(corners)
                for corners, _pat, label in baseline[:n_faces]
                if label == 'XY'
            ]
            top_blob_rescue = (
                not baseline_xy_corners
                or max(baseline_xy_corners) <= 16
            )
            top_blob = _small_target_top_blob_grid_candidates(
                gray, top_faces[0]['poly'],
                max_candidates=MAX_SMALL_TARGET_TOP_BLOB_GRID_CANDIDATES,
                rescue_mode=False)
            if top_blob_rescue and not top_blob:
                top_blob = _small_target_top_blob_grid_candidates(
                    gray, top_faces[0]['poly'],
                    max_candidates=MAX_SMALL_TARGET_TOP_BLOB_GRID_CANDIDATES,
                    rescue_mode=True)
            if top_blob:
                by_label['XY'].extend(top_blob)
                by_label['XY'] = _dedupe_face_candidates(by_label['XY'])[
                    :(
                        MAX_SMALL_TARGET_REGION_FACE_CANDIDATES
                        + MAX_SMALL_TARGET_TOP_BLOB_GRID_CANDIDATES
                    )
                ]
            side_pose_top = []
            side_pose_research_pocket = (
                cube_area_pct is not None
                and float(cube_area_pct) < SMALL_TARGET_SIDE_POSE_TOP_MAX_AREA_PCT
            )
            if (
                side_pose_research_pocket
                and baseline_corners < MIN_VALIDATED_SMALL_TARGET_CORNERS
            ):
                side_pose_top = _small_target_side_pose_top_completion_candidates(
                    gray, clusters, by_label,
                    max_candidates=MAX_SMALL_TARGET_SIDE_POSE_TOP_CANDIDATES,
                    cube_area_pct=cube_area_pct)
            if side_pose_top:
                by_label['XY'].extend(side_pose_top)
                by_label['XY'] = _dedupe_face_candidates(by_label['XY'])[
                    :(
                        MAX_SMALL_TARGET_REGION_FACE_CANDIDATES
                        + MAX_SMALL_TARGET_TOP_BLOB_GRID_CANDIDATES
                        + MAX_SMALL_TARGET_SIDE_POSE_TOP_CANDIDATES
                    )
                ]

    if any(not by_label[label] for label in labels):
        return []

    axis_signature_cache = {}
    debug_combos = (
        verbose
        and os.environ.get('CUBE_DEBUG_SMALL_REGION_COMBOS') == '1'
    )

    def _region_combo_prefilter_key(raw):
        dets = [
            (corners, pat, label)
            for _score, corners, pat, label, _source in raw
        ]
        patterns = _ordered_detection_patterns(dets)
        deficit = _small_target_pattern_deficit_for_detector(patterns)
        label_deficit = _small_target_label_pattern_deficit_for_detector(dets)
        corner_count = _total_corner_count(dets)
        sparse_count = _cube_detection_sparse_face_count(dets)
        source_penalty = sum(
            0.8 if str(source).startswith('wide') else
            0.4 if str(source).endswith('upscaled') else
            0.0
            for _score, _corners, _pat, _label, source in raw
        )
        score_sum = sum(
            float(score)
            for score, _corners, _pat, _label, _source in raw
        )
        exact = _small_target_region_patterns_exact(dets)
        invalid = 0 if exact else 1
        low_corners = 1 if corner_count < MIN_VALIDATED_SMALL_TARGET_CORNERS else 0
        return (
            invalid,
            int(label_deficit) if np.isfinite(label_deficit) else 99,
            int(deficit) if np.isfinite(deficit) else 99,
            low_corners,
            sparse_count,
            source_penalty,
            -corner_count,
            -score_sum,
        )

    def _region_combo_desc(raw):
        return ', '.join(
            f"{label}:{pat[0]}x{pat[1]}:{source}"
            for _s, _c, pat, label, source in raw
        )

    def _evaluate_region_combo(raw, combo_idx, phase):
        verbose_desc = None
        raw_dets = [
            (corners, pat, label)
            for _score, corners, pat, label, _source in raw
        ]
        if len(raw_dets) < n_faces:
            return None
        patterns = _ordered_detection_patterns(raw_dets)
        deficit = _small_target_pattern_deficit_for_detector(patterns)
        if not _small_target_region_patterns_exact(raw_dets):
            return None
        corner_count = _total_corner_count(raw_dets)
        if corner_count < MIN_VALIDATED_SMALL_TARGET_CORNERS:
            return None
        if _detections_have_excessive_overlap(
            raw_dets, threshold=MAX_SMALL_TARGET_REGION_OVERLAP_IOU
        ):
            return None
        if debug_combos:
            verbose_desc = _region_combo_desc(raw)
        has_grid_expand = any(
            'grid-expand:' in str(source)
            for _score, _corners, _pat, _label, source in raw
        )
        has_top_blob_grid = any(
            str(source).startswith('top-blob-grid:')
            for _score, _corners, _pat, _label, source in raw
        )
        has_side_pose_top = any(
            str(source).startswith('side-pose-top:')
            for _score, _corners, _pat, _label, source in raw
        )
        dets = _normalize_face_axis_order(
            raw_dets, signature_cache=axis_signature_cache)
        centered_geom = _cube_detection_geometry_rmse(
            dets, gray.shape, n_faces=n_faces, allow_sparse=False,
            assume_normalized=True)
        centered_limit = (
            MAX_SMALL_TARGET_REGION_CENTERED_PNP_RMSE_PX
            if max_centered_pnp_rmse is None
            else float(max_centered_pnp_rmse)
        )
        if has_side_pose_top:
            centered_limit = max(
                centered_limit,
                MAX_SMALL_TARGET_SIDE_POSE_CENTERED_PNP_RMSE_PX)
        if (
            not np.isfinite(centered_geom)
            or centered_geom > centered_limit
        ):
            if debug_combos:
                print(
                    f"  {phase} {combo_idx}: reject centered="
                    f"{centered_geom:.2f}; {verbose_desc}"
                )
            return None
        offset_rmse, offset, offset_dist = _cube_detection_best_offset_pnp_rmse(
            dets, gray.shape, n_faces=n_faces,
            max_offset_dist=MAX_SPARSE_RECOVERY_OFFSET_DIST_SQUARES,
            assume_normalized=True)
        offset_limit = (
            MAX_SMALL_TARGET_GRID_EXPAND_OFFSET_PNP_RMSE_PX
            if has_grid_expand or has_top_blob_grid or has_side_pose_top
            else MAX_SMALL_TARGET_REGION_OFFSET_PNP_RMSE_PX
        )
        if max_offset_pnp_rmse is not None:
            offset_limit = min(offset_limit, float(max_offset_pnp_rmse))
        if (
            not np.isfinite(offset_rmse)
            or offset_rmse > offset_limit
        ):
            if debug_combos:
                print(
                    f"  {phase} {combo_idx}: reject offset="
                    f"{offset_rmse:.2f}; {verbose_desc}"
                )
            return None
        wide_count = sum(
            1 for _score, _corners, _pat, _label, source in raw
            if str(source).startswith('wide')
        )
        score = (
            float(offset_rmse)
            + 0.12 * float(centered_geom)
            + 0.08 * float(offset_dist)
            + 0.45 * float(deficit)
            + 0.18 * float(wide_count)
            - 0.012 * float(corner_count)
        )
        if debug_combos:
            print(
                f"  {phase} {combo_idx}: candidate "
                f"offset={offset_rmse:.2f}, centered={centered_geom:.2f}, "
                f"deficit={deficit:.0f}, score={score:.2f}; {verbose_desc}"
            )
        return (
            score, offset_rmse, centered_geom, offset, offset_dist,
            deficit, corner_count, dets, raw,
        )

    def _emit_region_result(best):
        (
            _score, offset_rmse, centered_geom, offset, _offset_dist,
            deficit, corner_count, dets, raw,
        ) = best
        if verbose:
            desc = _region_combo_desc(raw)
            off_desc = ""
            if offset is not None:
                label_order = ['XY', 'XZ', 'YZ']
                off_desc = (
                    f", offset {label_order[offset[0]]}="
                    f"({offset[1]:.0f},{offset[2]:.0f})"
                )
            print(
                "  Using small-target region recovery candidate: "
                f"offset PnP={offset_rmse:.2f}px, "
                f"centered PnP={centered_geom:.2f}px, "
                f"deficit={deficit:.0f}, corners={corner_count}{off_desc}; "
                f"{desc}"
            )
        return dets

    raw_combos = [
        [xy, xz, yz]
        for xy in by_label['XY']
        for xz in by_label['XZ']
        for yz in by_label['YZ']
    ]
    raw_combos.sort(key=_region_combo_prefilter_key)
    if MAX_SMALL_TARGET_REGION_COMBOS > 0:
        raw_combos = raw_combos[:MAX_SMALL_TARGET_REGION_COMBOS]

    best = None
    for combo_idx, raw in enumerate(raw_combos, 1):
        candidate = _evaluate_region_combo(
            raw, combo_idx, "Small-region combo")
        if candidate is None:
            continue
        score = candidate[0]
        offset_rmse = candidate[1]
        centered_geom = candidate[2]
        deficit = candidate[5]
        corner_count = candidate[6]
        if best is None or score < best[0]:
            best = candidate
            baseline_only = all(
                str(source) == 'baseline'
                or str(source).startswith('grid-expand:baseline')
                for _score, _corners, _pat, _label, source in raw
            )
            baseline_low_offset = (
                baseline_only
                and centered_geom <= MAX_SMALL_TARGET_REGION_CENTERED_PNP_RMSE_PX
                and offset_rmse <= MAX_SMALL_TARGET_REGION_BASELINE_EARLY_OFFSET_PNP_RMSE_PX
            )
            if (
                deficit <= 0
                and corner_count >= MIN_VALIDATED_SMALL_TARGET_CORNERS
                and (
                    centered_geom <= 11.0
                    or baseline_low_offset
                )
                and offset_rmse <= 10.0
            ):
                break

    if best is None:
        if verbose:
            print("  Small-target region recovery rejected: no offset-safe candidate")
        return []

    return _emit_region_result(best)


def _geometry_gated_cube_candidate_upgrade(gray, baseline, n_faces=3,
                                           verbose=False):
    """Try alternate in-face grids, but only return a fast-PnP-safe upgrade."""
    if not ENABLE_GEOMETRY_GATED_CANDIDATE_UPGRADE or n_faces < 3:
        return []

    baseline = _normalize_face_axis_order(baseline or [])
    baseline_geom = float('inf')
    if len(baseline) >= n_faces:
        baseline_geom = _cube_detection_geometry_rmse(
            baseline, gray.shape, n_faces=n_faces)
        if (
            _cube_detection_sparse_face_count(baseline) == 0
            and np.isfinite(baseline_geom)
            and baseline_geom <= MAX_CANDIDATE_UPGRADE_FAST_PNP_RMSE_PX
        ):
            return []

    trigger = (
        len(baseline) < n_faces
        or _cube_detection_sparse_face_count(baseline) > 0
        or not np.isfinite(baseline_geom)
        or baseline_geom > MAX_CANDIDATE_UPGRADE_FAST_PNP_RMSE_PX
    )
    if not trigger:
        return []

    clusters = _label_cube_clusters(
        _cluster_dark_components(gray, n_faces=n_faces, verbose=False))
    if len(clusters) < n_faces:
        return []

    by_label = {'XY': [], 'XZ': [], 'YZ': []}
    baseline_patterns = {}
    for corners, pat, label in baseline:
        if label in by_label:
            baseline_patterns[label] = pat
            score = _score_face_upgrade_candidate(corners, pat, 'baseline')
            by_label[label].append((score + 12.0, corners, pat, label, 'baseline'))

    for face in clusters:
        label = face.get('label')
        if label not in by_label:
            continue
        by_label[label].extend(_detect_pattern_candidates_in_face(
            gray, face['poly'], label,
            max_candidates=MAX_FACE_CANDIDATES_FOR_UPGRADE))
        by_label[label] = _dedupe_face_candidates(by_label[label])[
            :MAX_FACE_CANDIDATES_FOR_UPGRADE
        ]

    labels = ['XY', 'XZ', 'YZ']
    if any(not by_label[label] for label in labels):
        return []

    best = None
    for xy in by_label['XY']:
        for xz in by_label['XZ']:
            for yz in by_label['YZ']:
                raw = [xy, xz, yz]
                dets = [
                    (corners, pat, label)
                    for _score, corners, pat, label, _source in raw
                ]
                dets = _normalize_face_axis_order(dets)
                if len(dets) < n_faces:
                    continue
                if all(
                    baseline_patterns.get(label) == pat
                    for _corners, pat, label in dets
                ):
                    continue
                if _cube_detection_sparse_face_count(dets) > 0:
                    continue
                if _detections_have_excessive_overlap(dets, threshold=0.55):
                    continue
                geom = _cube_detection_geometry_rmse(
                    dets, gray.shape, n_faces=n_faces)
                offset_rmse, offset, offset_dist = _cube_detection_best_offset_pnp_rmse(
                    dets, gray.shape, n_faces=n_faces,
                    assume_normalized=True,
                    early_stop_rmse=7.0)
                if (
                    (
                        not np.isfinite(geom)
                        or geom > MAX_CANDIDATE_UPGRADE_FAST_PNP_RMSE_PX
                    )
                    and (
                        not np.isfinite(offset_rmse)
                        or offset_rmse > MAX_CANDIDATE_UPGRADE_OFFSET_PNP_RMSE_PX
                    )
                ):
                    continue
                corner_count = _total_corner_count(dets)
                wide_count = sum(
                    1 for _score, _corners, _pat, _label, source in raw
                    if source.startswith('wide')
                )
                source_penalty = 0.35 * float(wide_count)
                effective_geom = (
                    float(geom)
                    if np.isfinite(geom)
                    else MAX_CANDIDATE_UPGRADE_FAST_PNP_RMSE_PX + 20.0
                )
                effective_offset = (
                    float(offset_rmse)
                    if np.isfinite(offset_rmse)
                    else MAX_CANDIDATE_UPGRADE_OFFSET_PNP_RMSE_PX + 20.0
                )
                score = (
                    min(effective_geom, effective_offset + 0.55)
                    + 0.08 * float(offset_dist if np.isfinite(offset_dist) else 0.0)
                    + 0.12 * max(0.0, effective_geom - MAX_CANDIDATE_UPGRADE_FAST_PNP_RMSE_PX)
                    - 0.015 * float(corner_count)
                    + source_penalty
                )
                if best is None or score < best[0]:
                    best = (score, geom, offset_rmse, offset, dets, raw)

    if best is None:
        if verbose:
            if np.isfinite(baseline_geom):
                print(
                    "  Candidate upgrade rejected: "
                    f"baseline PnP={baseline_geom:.2f}px, "
                    f"gate={MAX_CANDIDATE_UPGRADE_FAST_PNP_RMSE_PX:.2f}px"
                )
            else:
                print("  Candidate upgrade rejected: no finite fast-PnP candidate")
        return []

    _score, geom, offset_rmse, offset, dets, raw = best
    if verbose:
        desc = ', '.join(
            f"{label}:{pat[0]}x{pat[1]}:{source}"
            for _s, _c, pat, label, source in raw
        )
        off_desc = ""
        if offset is not None:
            labels = ['XY', 'XZ', 'YZ']
            off_desc = f", offset {labels[offset[0]]}=({offset[1]:.0f},{offset[2]:.0f})"
        print(
            "  Using geometry-gated candidate upgrade: "
            f"fast PnP={geom:.2f}px, offset PnP={offset_rmse:.2f}px"
            f"{off_desc}, {desc}"
        )
    return dets


def _choose_cube_first_detection(upscaled, direct, n_faces=3, image_shape=None):
    """Prefer the crop-upscaled result only when it improves detection."""
    if not upscaled:
        return direct
    if not direct:
        return upscaled
    if len(upscaled) > len(direct):
        return upscaled
    if len(upscaled) < len(direct):
        return direct

    up_corners = _total_corner_count(upscaled)
    direct_corners = _total_corner_count(direct)
    if len(upscaled) >= n_faces and len(direct) >= n_faces:
        up_label_deficit = _small_target_label_pattern_deficit_for_detector(
            upscaled[:n_faces])
        direct_label_deficit = _small_target_label_pattern_deficit_for_detector(
            direct[:n_faces])
        if (
            np.isfinite(direct_label_deficit)
            and up_label_deficit > direct_label_deficit
            and direct_corners >= max(60, int(0.70 * max(up_corners, 1)))
        ):
            return direct
        up_deficit = _small_target_pattern_deficit_for_detector(
            _ordered_detection_patterns(upscaled[:n_faces]))
        direct_deficit = _small_target_pattern_deficit_for_detector(
            _ordered_detection_patterns(direct[:n_faces]))
        if (
            np.isfinite(direct_deficit)
            and up_deficit > direct_deficit
            and direct_corners >= max(60, int(0.75 * max(up_corners, 1)))
        ):
            return direct
    if image_shape is not None and len(upscaled) >= n_faces and len(direct) >= n_faces:
        up_sparse = _cube_detection_sparse_face_count(upscaled)
        direct_sparse = _cube_detection_sparse_face_count(direct)
        if up_sparse <= direct_sparse:
            up_geom = _cube_detection_geometry_rmse(upscaled, image_shape, n_faces)
            direct_geom = _cube_detection_geometry_rmse(direct, image_shape, n_faces)
            if (
                np.isfinite(up_geom)
                and np.isfinite(direct_geom)
                and up_geom + 0.75 < direct_geom
                and up_corners + 12 >= direct_corners
            ):
                return upscaled
    if len(upscaled) >= n_faces and up_corners > direct_corners:
        return upscaled
    if len(direct) < n_faces and up_corners > direct_corners:
        return upscaled
    return direct


def _labels_match_prefix(detections):
    expected = ['XY', 'XZ', 'YZ']
    labels = [d[2] for d in detections]
    return labels == expected[:len(labels)]


def _total_corner_count(detections):
    return int(sum(len(corners) for corners, _pat, _label in detections))


def _ordered_detection_patterns(detections):
    order = {'XY': 0, 'XZ': 1, 'YZ': 2}
    return tuple(
        tuple(int(v) for v in pat)
        for _corners, pat, _label in sorted(
            detections, key=lambda d: order.get(d[2], 99))
    )


def _small_target_pattern_signature_for_detector(patterns):
    return tuple(sorted(
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in patterns
    ))


def _small_target_pattern_deficit_for_detector(patterns):
    observed = [
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in patterns
    ]
    canonical = [
        (max(int(cols), int(rows)), min(int(cols), int(rows)))
        for cols, rows in VALIDATED_SMALL_TARGET_PATTERNS
    ]
    if tuple(sorted(observed)) == tuple(sorted(canonical)):
        return 0

    best_deficit = None
    for perm in permutations(canonical):
        total_deficit = 0
        ok = True
        for obs, ref in zip(observed, perm):
            if obs[0] > ref[0] or obs[1] > ref[1]:
                ok = False
                break
            total_deficit += (ref[0] - obs[0]) + (ref[1] - obs[1])
        if not ok:
            continue
        if best_deficit is None or total_deficit < best_deficit:
            best_deficit = total_deficit
    return best_deficit if best_deficit is not None else float('inf')


def _small_target_label_pattern_deficit_for_detector(detections):
    canonical_by_label = {
        'XY': (9, 6),
        'XZ': (9, 6),
        'YZ': (6, 6),
    }
    total = 0
    seen = set()
    for _corners, pattern, label in detections:
        if label not in canonical_by_label or label in seen:
            return float('inf')
        seen.add(label)
        obs = (max(int(pattern[0]), int(pattern[1])),
               min(int(pattern[0]), int(pattern[1])))
        ref = canonical_by_label[label]
        if obs[0] > ref[0] or obs[1] > ref[1]:
            return float('inf')
        total += (ref[0] - obs[0]) + (ref[1] - obs[1])
    if any(label not in seen for label in canonical_by_label):
        return float('inf')
    return total


def _small_target_patterns_allowed_for_detector(patterns):
    deficit = _small_target_pattern_deficit_for_detector(patterns)
    return (
        np.isfinite(deficit)
        and deficit <= SMALL_TARGET_REGION_MAX_PATTERN_STEP_DEFICIT
    )


def _small_target_region_search_patterns(label):
    if label == 'XY':
        return [(9, 6), (6, 9)]
    if label in ('XZ', 'YZ'):
        # The cube can be yawed relative to the camera, so the two visible side
        # faces may carry either the 9x6 or the 6x6 board.  Keep both options
        # as candidates and let the cross-face geometry gate choose.
        return [(9, 6), (6, 9), (6, 6)]
    return []


def _small_target_region_patterns_exact(detections):
    detections = detections or []
    if len(detections) < len(VALIDATED_SMALL_TARGET_PATTERNS):
        return False
    patterns = _ordered_detection_patterns(
        detections[:len(VALIDATED_SMALL_TARGET_PATTERNS)])
    return (
        _small_target_pattern_signature_for_detector(patterns)
        == _small_target_pattern_signature_for_detector(
            VALIDATED_SMALL_TARGET_PATTERNS)
    )


def _subset_chessboard_corners_for_detector(corners, pattern, target_pattern,
                                            start_col, start_row):
    cols, rows = int(pattern[0]), int(pattern[1])
    t_cols, t_rows = int(target_pattern[0]), int(target_pattern[1])
    if (
        t_cols > cols
        or t_rows > rows
        or start_col < 0
        or start_row < 0
        or start_col + t_cols > cols
        or start_row + t_rows > rows
    ):
        return None
    pts = corners.reshape(rows, cols, 1, 2)
    subset = pts[
        start_row:start_row + t_rows,
        start_col:start_col + t_cols,
        :,
        :,
    ].copy()
    return subset.reshape(-1, 1, 2).astype(np.float32)


def _small_target_trim_target_patterns(pattern):
    cols, rows = int(pattern[0]), int(pattern[1])
    targets = []
    for ref_cols, ref_rows in VALIDATED_SMALL_TARGET_PATTERNS:
        for target in ((ref_cols, ref_rows), (ref_rows, ref_cols)):
            t_cols, t_rows = int(target[0]), int(target[1])
            if (
                t_cols <= cols
                and t_rows <= rows
                and (t_cols, t_rows) != (cols, rows)
            ):
                targets.append((t_cols, t_rows))
    return _unique_patterns(targets)


def _add_trimmed_small_target_candidates(candidates):
    expanded = list(candidates)
    seen = {
        (
            label,
            tuple(int(v) for v in pat),
            tuple(round(float(v), 1) for v in _center_of_corners(corners)),
            source,
        )
        for _score, corners, pat, label, source in expanded
    }
    for _score, corners, pat, label, source in list(candidates):
        for target in _small_target_trim_target_patterns(pat):
            cols, rows = int(pat[0]), int(pat[1])
            t_cols, t_rows = int(target[0]), int(target[1])
            for start_col in range(0, cols - t_cols + 1):
                for start_row in range(0, rows - t_rows + 1):
                    subset = _subset_chessboard_corners_for_detector(
                        corners, pat, target, start_col, start_row)
                    if subset is None:
                        continue
                    trim_source = (
                        f"{source}-trim-{cols}x{rows}->{t_cols}x{t_rows}"
                        f"@{start_col},{start_row}"
                    )
                    key = (
                        label,
                        target,
                        tuple(round(float(v), 1) for v in _center_of_corners(subset)),
                        trim_source,
                    )
                    if key in seen:
                        continue
                    seen.add(key)
                    score = _score_face_upgrade_candidate(
                        subset, target, trim_source)
                    expanded.append((score, subset, target, label, trim_source))
    return expanded


def _small_target_grid_points(pattern, offset=(0, 0)):
    cols, rows = int(pattern[0]), int(pattern[1])
    ox, oy = int(offset[0]), int(offset[1])
    return np.array(
        [[ox + c, oy + r] for r in range(rows) for c in range(cols)],
        dtype=np.float32,
    )


def _small_target_grid_expand_targets(label, pattern):
    cols, rows = int(pattern[0]), int(pattern[1])
    targets_by_label = {
        'XY': [(9, 6), (6, 9)],
        'XZ': [(9, 6), (6, 9)],
        'YZ': [(6, 6)],
    }
    targets = []
    for target in targets_by_label.get(label, []):
        t_cols, t_rows = int(target[0]), int(target[1])
        if (
            cols <= t_cols
            and rows <= t_rows
            and cols * rows < t_cols * t_rows
        ):
            targets.append((t_cols, t_rows))
    return _unique_patterns(targets)


def _small_target_project_grid_expansion(corners, pattern, target, offset):
    partial_grid = _small_target_grid_points(pattern, offset)
    image_pts = np.asarray(corners, dtype=np.float32).reshape(-1, 2)
    if len(partial_grid) != len(image_pts):
        return None, float('inf')
    H, _status = cv2.findHomography(partial_grid, image_pts, method=0)
    if H is None or not np.all(np.isfinite(H)):
        return None, float('inf')
    full_grid = _small_target_grid_points(target)
    projected = cv2.perspectiveTransform(
        full_grid.reshape(-1, 1, 2), H.astype(np.float64)
    ).astype(np.float32)
    fitted = cv2.perspectiveTransform(
        partial_grid.reshape(-1, 1, 2), H.astype(np.float64)
    ).reshape(-1, 2)
    fit_rmse = float(np.sqrt(np.mean(np.sum((fitted - image_pts) ** 2, axis=1))))
    return projected.reshape(-1, 1, 2), fit_rmse


def _small_target_refine_projected_grid(gray, corners):
    refined = np.asarray(corners, dtype=np.float32).reshape(-1, 1, 2).copy()
    criteria = (
        cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER,
        60,
        1e-4,
    )
    try:
        return cv2.cornerSubPix(gray, refined, (5, 5), (-1, -1), criteria)
    except cv2.error:
        return refined


def _small_target_grid_expand_candidates(
        gray, corners, pattern, label, source, context_dets):
    if not ENABLE_SMALL_TARGET_GRID_EXPAND_CANDIDATES:
        return []
    candidates = []
    h, w = gray.shape[:2]
    cols, rows = int(pattern[0]), int(pattern[1])
    seed_corners = _small_target_refine_projected_grid(gray, corners)
    for target in _small_target_grid_expand_targets(label, pattern):
        t_cols, t_rows = int(target[0]), int(target[1])
        for start_col in range(0, t_cols - cols + 1):
            for start_row in range(0, t_rows - rows + 1):
                projected, fit_rmse = _small_target_project_grid_expansion(
                    seed_corners, pattern, target, (start_col, start_row))
                fit_limit = (
                    MAX_SMALL_TARGET_SPARSE_GRID_EXPAND_FIT_RMSE_PX
                    if len(corners) <= 24 and min(cols, rows) <= 5
                    else MAX_SMALL_TARGET_GRID_EXPAND_FIT_RMSE_PX
                )
                if projected is None or fit_rmse > fit_limit:
                    continue
                pts0 = projected.reshape(-1, 2)
                if not np.all(
                    (pts0[:, 0] >= 0)
                    & (pts0[:, 0] < w)
                    & (pts0[:, 1] >= 0)
                    & (pts0[:, 1] < h)
                ):
                    continue
                refined = _small_target_refine_projected_grid(gray, projected)
                pts = refined.reshape(-1, 2)
                in_bounds = float(np.mean(
                    (pts[:, 0] >= 0)
                    & (pts[:, 0] < w)
                    & (pts[:, 1] >= 0)
                    & (pts[:, 1] < h)
                ))
                if in_bounds < 0.99:
                    continue
                try:
                    h_rmse, robust_rmse, inlier_frac = _face_homography_stats(
                        refined, target)
                except Exception:
                    continue
                line_q = _line_quality_for_candidate(refined, target)
                if (
                    h_rmse > MAX_SMALL_TARGET_GRID_EXPAND_HOMOGRAPHY_RMSE_PX
                    or robust_rmse > MAX_SMALL_TARGET_GRID_EXPAND_ROBUST_HOMOGRAPHY_RMSE_PX
                    or inlier_frac < MIN_SMALL_TARGET_GRID_EXPAND_HOMOGRAPHY_INLIER_FRAC
                    or line_q > MAX_SMALL_TARGET_GRID_EXPAND_LINE_QUALITY_PX
                ):
                    continue
                bbox = _bbox_of_corners(refined)
                overlap = 0.0
                for other_corners, _other_pat, other_label in context_dets:
                    if other_label == label:
                        continue
                    overlap = max(overlap, _iou(bbox, _bbox_of_corners(other_corners)))
                if overlap > MAX_SMALL_TARGET_GRID_EXPAND_OVERLAP_IOU:
                    continue
                expand_source = (
                    f"grid-expand:{source}:{cols}x{rows}->{t_cols}x{t_rows}"
                    f"@{start_col},{start_row}"
                )
                preferred_col = max(0, t_cols - cols - 1)
                score = (
                    float(len(refined))
                    + 14.0
                    - 3.0 * float(line_q)
                    - 1.5 * float(h_rmse)
                    - 0.2 * float(fit_rmse)
                    - 30.0 * float(overlap)
                    - 0.9 * float(start_row)
                    - 0.75 * float(abs(start_col - preferred_col))
                )
                candidates.append((score, refined.astype(np.float32), target, label, expand_source))
    candidates.sort(key=lambda item: float(item[0]), reverse=True)
    return candidates[:4]


def _small_target_top_blob_observations(gray, poly, scale=1.0, threshold=105):
    """Dark square centers on the visible top face for small-target recovery."""
    h, w = gray.shape[:2]
    poly = np.asarray(poly, dtype=np.float32).reshape(-1, 2)
    if len(poly) < 4:
        return np.empty((0, 2), dtype=np.float32)
    center = poly.mean(axis=0)
    expanded = center + (poly - center) * float(scale)
    expanded[:, 0] = np.clip(expanded[:, 0], 0, w - 1)
    expanded[:, 1] = np.clip(expanded[:, 1], 0, h - 1)

    mask = np.zeros_like(gray)
    cv2.fillPoly(mask, [expanded.astype(np.int32)], 255)
    dark = ((gray < int(threshold)) & (mask > 0)).astype(np.uint8) * 255
    num, _labels, stats, cents = cv2.connectedComponentsWithStats(dark, 8)

    pts = []
    lower_guard = float(np.max(poly[:, 1]) + 0.12 * max(
        1.0, np.ptp(poly[:, 0]), np.ptp(poly[:, 1])))
    for i in range(1, num):
        x, y, bw, bh, area = stats[i]
        if area < 10 or area > 1000:
            continue
        if bw < 3 or bh < 3 or bw > 60 or bh > 60:
            continue
        ratio = bw / float(max(bh, 1))
        fill = area / float(max(bw * bh, 1))
        if ratio < 0.25 or ratio > 4.0 or fill < 0.18:
            continue
        if float(cents[i][1]) > lower_guard:
            continue
        pts.append(cents[i])
    if len(pts) < 4:
        return np.empty((0, 2), dtype=np.float32)
    return np.asarray(pts, dtype=np.float32)


def _small_target_top_blob_model_variants():
    variants = []
    for parity in (0, 1):
        for flip_x in (False, True):
            for flip_y in (False, True):
                pts = []
                for r in range(7):
                    for c in range(10):
                        if (c + r) % 2 != parity:
                            continue
                        x = float(c) + 0.5
                        y = float(r) + 0.5
                        if flip_x:
                            x = 10.0 - x
                        if flip_y:
                            y = 7.0 - y
                        pts.append((x, y))
                model = np.asarray(pts, dtype=np.float32)
                hull = cv2.convexHull(model).reshape(-1, 2)
                hull = _order_poly_points(hull)
                variants.append((parity, flip_x, flip_y, model, hull))
    return variants


def _small_target_top_blob_unique_score(H, model_points, observed_points):
    projected = cv2.perspectiveTransform(
        model_points.reshape(-1, 1, 2), H).reshape(-1, 2)
    distances = np.sqrt(
        ((projected[:, None, :] - observed_points[None, :, :]) ** 2).sum(axis=2))
    nearest = distances.min(axis=1)
    assignment = distances.argmin(axis=1)

    pairs = []
    used_observed = set()
    for model_idx in np.argsort(nearest):
        obs_idx = int(assignment[model_idx])
        if (
            nearest[model_idx] < MAX_SMALL_TARGET_TOP_BLOB_MATCH_DIST_PX
            and obs_idx not in used_observed
        ):
            used_observed.add(obs_idx)
            pairs.append((int(model_idx), obs_idx, float(nearest[model_idx])))

    support = len(pairs)
    median = (
        float(np.median([p[2] for p in pairs]))
        if pairs else float("inf")
    )
    mean = (
        float(np.mean([p[2] for p in pairs]))
        if pairs else float("inf")
    )
    projected_bbox = np.r_[projected.min(axis=0), projected.max(axis=0)]
    observed_bbox = np.r_[observed_points.min(axis=0), observed_points.max(axis=0)]
    denom = np.maximum(
        np.array([
            observed_bbox[2] - observed_bbox[0],
            observed_bbox[3] - observed_bbox[1],
        ], dtype=np.float32),
        1e-6,
    )
    ratio = np.array([
        projected_bbox[2] - projected_bbox[0],
        projected_bbox[3] - projected_bbox[1],
    ], dtype=np.float32) / denom
    span_penalty = (
        abs(math.log(max(float(ratio[0]), 1e-6)))
        + abs(math.log(max(float(ratio[1]), 1e-6)))
        + float(np.linalg.norm(
            ((projected_bbox[:2] + projected_bbox[2:]) * 0.5)
            - ((observed_bbox[:2] + observed_bbox[2:]) * 0.5)
        ) / 42.0)
    )
    wild = (
        projected_bbox[0] < observed_bbox[0] - 80.0
        or projected_bbox[2] > observed_bbox[2] + 110.0
        or projected_bbox[1] < observed_bbox[1] - 40.0
        or projected_bbox[3] > observed_bbox[3] + 55.0
        or ratio[0] < 0.60
        or ratio[1] < 0.55
        or ratio[0] > 1.75
        or ratio[1] > 1.75
    )
    return support, median, mean, span_penalty, wild, pairs, projected_bbox, ratio


def _small_target_top_blob_grid_candidates(
        gray, poly, max_candidates=None, rescue_mode=False):
    """Recover the top 9x6 corner grid from dark-square centers.

    This is deliberately only a candidate generator.  It supplies physically
    plausible XY grids for the existing three-face PnP gates, which still make
    the acceptance decision.
    """
    if not ENABLE_SMALL_TARGET_TOP_BLOB_GRID_CANDIDATES:
        return []

    raw_candidates = []
    seen = set()
    models = _small_target_top_blob_model_variants()
    thresholds = (80, 90, 105, 115) if rescue_mode else (105,)
    scales = (1.0, 1.4, 1.6, 1.8) if rescue_mode else (1.0, 1.4, 1.6)
    eps_values = (
        (2, 3, 4, 5, 6, 8, 10, 12, 15)
        if rescue_mode else
        (5, 6, 8, 10, 12, 15)
    )
    min_observations = 10 if rescue_mode else 12
    for threshold in thresholds:
        for scale in scales:
            observed = _small_target_top_blob_observations(
                gray, poly, scale=scale, threshold=threshold)
            if len(observed) < min_observations:
                continue
            observed_hull = cv2.convexHull(observed).reshape(-1, 2)
            observed_hull = _order_poly_points(observed_hull)
            for eps in eps_values:
                approx = cv2.approxPolyDP(
                    observed_hull.reshape(-1, 1, 2), eps, True).reshape(-1, 2)
                if len(approx) != 6:
                    continue
                approx = _order_poly_points(approx)
                for parity, flip_x, flip_y, model_points, model_hull in models:
                    for shift in range(6):
                        for reverse in (False, True):
                            obs_seq = approx[::-1] if reverse else approx
                            obs_seq = np.roll(obs_seq, -shift, axis=0)
                            H, _status = cv2.findHomography(
                                model_hull, obs_seq, method=0)
                            if H is None or not np.all(np.isfinite(H)):
                                continue
                            (
                                support,
                                median,
                                mean,
                                span_penalty,
                                wild,
                                _pairs,
                                projected_bbox,
                                _ratio,
                            ) = _small_target_top_blob_unique_score(
                                H.astype(np.float64), model_points, observed)
                            if (
                                wild
                                or support < MIN_SMALL_TARGET_TOP_BLOB_UNIQUE_SUPPORT
                                or not np.isfinite(median)
                            ):
                                continue

                            key = (
                                int(round(projected_bbox[0] / 4.0)),
                                int(round(projected_bbox[1] / 4.0)),
                                int(round(projected_bbox[2] / 4.0)),
                                int(round(projected_bbox[3] / 4.0)),
                                int(parity),
                                int(flip_x),
                                int(flip_y),
                            )
                            if key in seen:
                                continue
                            seen.add(key)

                            inner = np.array(
                                [[c, r] for r in range(1, 7) for c in range(1, 10)],
                                dtype=np.float32,
                            )
                            corners = cv2.perspectiveTransform(
                                inner.reshape(-1, 1, 2), H.astype(np.float64)
                            ).astype(np.float32)
                            if not np.all(np.isfinite(corners)):
                                continue
                            h, w = gray.shape[:2]
                            pts = corners.reshape(-1, 2)
                            if not np.all(
                                (pts[:, 0] >= 0)
                                & (pts[:, 0] < w)
                                & (pts[:, 1] >= 0)
                                & (pts[:, 1] < h)
                            ):
                                continue
                            try:
                                h_rmse, robust_rmse, inlier_frac = (
                                    _face_homography_stats(corners, (9, 6)))
                            except Exception:
                                continue
                            if (
                                h_rmse > 1.75
                                or robust_rmse > 1.25
                                or inlier_frac < 0.68
                            ):
                                continue

                            # Favor tight black-center agreement, but keep lower
                            # support candidates that explain the projected span
                            # well; the cross-face gate will choose the final one.
                            proxy = (
                                float(span_penalty) * 3.0
                                + float(median)
                                - 0.12 * float(support)
                            )
                            score = 54.0 - proxy
                            source = (
                                "top-blob-grid:"
                                + (
                                    f"t{threshold}:"
                                    if rescue_mode else ""
                                )
                                + f"s{scale:.1f}:e{eps}:"
                                + f"u{support}:m{median:.1f}"
                            )
                            raw_candidates.append(
                                (score, corners, (9, 6), "XY", source))

    raw_candidates = _dedupe_face_candidates(raw_candidates)
    limit = max_candidates or MAX_SMALL_TARGET_TOP_BLOB_GRID_CANDIDATES
    return raw_candidates[:limit]


def _dedupe_points_by_distance(points, min_dist=3.0):
    kept = []
    for pt in np.asarray(points, dtype=np.float32).reshape(-1, 2):
        if not kept or min(np.linalg.norm(pt - old) for old in kept) > min_dist:
            kept.append(pt)
    if not kept:
        return np.empty((0, 2), dtype=np.float32)
    return np.asarray(kept, dtype=np.float32)


def _small_target_top_observation_pool(gray, top_poly):
    pools = []
    for threshold in (90, 105, 115):
        for scale in (1.0, 1.4, 1.8, 2.4):
            pts = _small_target_top_blob_observations(
                gray, top_poly, scale=scale, threshold=threshold)
            if len(pts):
                pools.append(pts)
    if not pools:
        return np.empty((0, 2), dtype=np.float32)
    return _dedupe_points_by_distance(np.vstack(pools), min_dist=3.0)


def _project_points_no_dist(obj, K, rvec, tvec):
    proj, _ = cv2.projectPoints(
        np.asarray(obj, dtype=np.float64).reshape(-1, 1, 3),
        rvec, tvec, K, np.zeros(5, dtype=np.float64))
    return proj.reshape(-1, 2).astype(np.float32)


def _small_target_projected_dark_support(face, K, rvec, tvec, observed):
    if len(observed) < MIN_SMALL_TARGET_SIDE_POSE_TOP_SUPPORT:
        return 0, float("inf")
    cols, rows = face.pattern_size
    outer_cols, outer_rows = int(cols) + 1, int(rows) + 1
    best = (0, float("inf"))
    for parity in (0, 1):
        pts = []
        for r in range(outer_rows):
            for c in range(outer_cols):
                if (c + r) % 2 != parity:
                    continue
                pts.append(
                    face.origin_3d
                    + (float(c) + 0.5) * face.square_size * face.axis_x
                    + (float(r) + 0.5) * face.square_size * face.axis_y
                )
        if not pts:
            continue
        projected = _project_points_no_dist(
            np.asarray(pts, dtype=np.float32), K, rvec, tvec)
        distances = np.sqrt(
            ((projected[:, None, :] - observed[None, :, :]) ** 2).sum(axis=2))
        nearest = distances.min(axis=1)
        support = int((nearest < MAX_SMALL_TARGET_TOP_BLOB_MATCH_DIST_PX).sum())
        median = float(np.median(nearest)) if len(nearest) else float("inf")
        if support > best[0] or (support == best[0] and median < best[1]):
            best = (support, median)
    return best


def _small_target_side_offset_sets(patterns, max_offset_dist=3.2,
                                   max_sets=16):
    max_outer_squares, base_offsets = _center_offsets_in_squares(patterns)
    rows = [(0.0, list(base_offsets))]
    for face_idx in (1, 2):
        cols, row_count = patterns[face_idx]
        center_x, center_y = base_offsets[face_idx]
        for ox in range(1, int(max_outer_squares - cols) + 1):
            for oy in range(1, int(max_outer_squares - row_count) + 1):
                offset_dist = float(np.hypot(
                    float(ox) - float(center_x),
                    float(oy) - float(center_y)))
                if offset_dist <= 1e-6 or offset_dist > max_offset_dist:
                    continue
                offsets = list(base_offsets)
                offsets[face_idx] = (float(ox), float(oy))
                rows.append((offset_dist, offsets))
    rows.sort(key=lambda item: item[0])
    return [offsets for _dist, offsets in rows[:max_sets]]


def _small_target_side_pose_top_completion_candidates(
        gray, clusters, by_label, max_candidates=None, cube_area_pct=None):
    """Complete a weak top face by projecting it from the two side faces.

    This is only enabled for the research <6% pocket.  The generated top grid
    is not trusted by itself: it must be visually supported by dark top-face
    squares and still pass the downstream three-face physical gates.
    """
    if (
        not ENABLE_SMALL_TARGET_SIDE_POSE_TOP_COMPLETION
        or SMALL_TARGET_SIDE_POSE_TOP_MAX_AREA_PCT <= 0.0
    ):
        return []

    top_faces = [face for face in clusters if face.get('label') == 'XY']
    if not top_faces:
        return []
    top_poly = top_faces[0]['poly']
    observed = _small_target_top_observation_pool(gray, top_poly)
    support_min = MIN_SMALL_TARGET_SIDE_POSE_TOP_SUPPORT
    median_limit = MAX_SMALL_TARGET_SIDE_POSE_TOP_MEDIAN_PX
    if (
        cube_area_pct is not None
        and float(cube_area_pct) < SMALL_TARGET_SIDE_POSE_TOP_RELAX_AREA_PCT
    ):
        support_min = min(support_min, 13)
        median_limit = max(median_limit, 12.0)
    if len(observed) < support_min:
        return []
    xy_bbox = top_faces[0].get('bbox', None)

    exact_sig = sorted([(6, 6), (6, 9), (6, 9)])
    xz_candidates = [
        item for item in by_label.get('XZ', [])[:4]
        if tuple(sorted((int(item[2][0]), int(item[2][1])))) in ((6, 6), (6, 9))
    ]
    yz_candidates = [
        item for item in by_label.get('YZ', [])[:4]
        if tuple(sorted((int(item[2][0]), int(item[2][1])))) in ((6, 6), (6, 9))
    ]
    if not xz_candidates or not yz_candidates:
        return []

    h, w = gray.shape[:2]
    diag = float(np.hypot(w, h))
    focal_seeds = [0.55 * diag, 0.70 * diag, 0.82 * diag, 1.10 * diag]
    flip_pairs = [(False, False), (True, False), (False, True), (True, True)]
    raw_candidates = []
    seen = set()

    for xz_item in xz_candidates:
        _xz_score, xz_corners, xz_pat, _xz_label, xz_source = xz_item
        for yz_item in yz_candidates:
            _yz_score, yz_corners, yz_pat, _yz_label, yz_source = yz_item
            for top_pat in ((9, 6), (6, 9)):
                sig = sorted([
                    tuple(sorted((int(top_pat[0]), int(top_pat[1])))),
                    tuple(sorted((int(xz_pat[0]), int(xz_pat[1])))),
                    tuple(sorted((int(yz_pat[0]), int(yz_pat[1])))),
                ])
                if sig != exact_sig:
                    continue
                patterns = [top_pat, xz_pat, yz_pat]
                max_outer_squares, _base_offsets = _center_offsets_in_squares(
                    patterns)
                side_img = np.vstack([
                    xz_corners.reshape(-1, 2).astype(np.float32),
                    yz_corners.reshape(-1, 2).astype(np.float32),
                ])
                pose_rows = []
                for offsets in _small_target_side_offset_sets(patterns):
                    faces = _faces_from_square_offsets(
                        patterns, 25.0, offsets)
                    side_faces = (faces[1], faces[2])
                    for focal in focal_seeds:
                        K = np.array([
                            [focal, 0.0, w / 2.0],
                            [0.0, focal, h / 2.0],
                            [0.0, 0.0, 1.0],
                        ], dtype=np.float64)
                        for fl1 in flip_pairs:
                            obj1 = object_points_for_face(
                                side_faces[0], *fl1).reshape(-1, 3)
                            for fl2 in flip_pairs:
                                obj2 = object_points_for_face(
                                    side_faces[1], *fl2).reshape(-1, 3)
                                obj = np.vstack([obj1, obj2]).astype(np.float32)
                                try:
                                    ok, rvec, tvec = cv2.solvePnP(
                                        obj.reshape(-1, 1, 3),
                                        side_img.reshape(-1, 1, 2),
                                        K,
                                        np.zeros(5, dtype=np.float64),
                                        flags=cv2.SOLVEPNP_ITERATIVE)
                                except cv2.error:
                                    continue
                                if not ok:
                                    continue
                                projected = _project_points_no_dist(
                                    obj, K, rvec, tvec)
                                diff = projected - side_img
                                side_rmse = float(np.sqrt(np.mean(
                                    np.sum(diff * diff, axis=1))))
                                if (
                                    not np.isfinite(side_rmse)
                                    or side_rmse > MAX_SMALL_TARGET_SIDE_POSE_SIDE_RMSE_PX
                                ):
                                    continue
                                pose_rows.append((
                                    side_rmse, offsets, faces, K, rvec, tvec,
                                    xz_source, yz_source))
                pose_rows.sort(key=lambda row: row[0])
                for side_rmse, offsets, _faces, K, rvec, tvec, xs, ys in pose_rows[:24]:
                    for ox in range(1, int(max_outer_squares - top_pat[0]) + 1):
                        for oy in range(1, int(max_outer_squares - top_pat[1]) + 1):
                            top_offsets = list(offsets)
                            top_offsets[0] = (float(ox), float(oy))
                            faces = _faces_from_square_offsets(
                                patterns, 25.0, top_offsets)
                            top_face = faces[0]
                            support, median = (
                                _small_target_projected_dark_support(
                                    top_face, K, rvec, tvec, observed))
                            if (
                                support < support_min
                                or not np.isfinite(median)
                                or median > median_limit
                            ):
                                continue
                            corners = _project_points_no_dist(
                                object_points_for_face(
                                    top_face, False, False).reshape(-1, 3),
                                K, rvec, tvec).reshape(-1, 1, 2)
                            pts = corners.reshape(-1, 2)
                            if not np.all(
                                (pts[:, 0] >= 0) & (pts[:, 0] < w)
                                & (pts[:, 1] >= 0) & (pts[:, 1] < h)
                            ):
                                continue
                            bbox = _bbox_of_corners(corners)
                            if xy_bbox is not None:
                                _x, y0, _bw, bh = xy_bbox
                                if bbox[1] > y0 + max(130, int(2.0 * bh)):
                                    continue
                            key = (
                                tuple(int(v) for v in top_pat),
                                int(round(bbox[0] / 4.0)),
                                int(round(bbox[1] / 4.0)),
                                int(round(bbox[2] / 4.0)),
                                int(round(bbox[3] / 4.0)),
                            )
                            if key in seen:
                                continue
                            seen.add(key)
                            score = (
                                82.0
                                + 0.55 * float(support)
                                - 0.75 * float(median)
                                - 0.35 * float(side_rmse)
                            )
                            source = (
                                "side-pose-top:"
                                f"u{support}:m{median:.1f}:"
                                f"side{side_rmse:.1f}:"
                                f"off{int(ox)},{int(oy)}"
                            )
                            raw_candidates.append(
                                (score, corners.astype(np.float32),
                                 top_pat, "XY", source))

    raw_candidates = _dedupe_face_candidates(raw_candidates)
    limit = max_candidates or MAX_SMALL_TARGET_SIDE_POSE_TOP_CANDIDATES
    return raw_candidates[:limit]


def _bbox_union_iou(b1, b2):
    x1, y1 = max(b1[0], b2[0]), max(b1[1], b2[1])
    x2, y2 = min(b1[2], b2[2]), min(b1[3], b2[3])
    if x1 >= x2 or y1 >= y2:
        return 0.0
    inter = float((x2 - x1) * (y2 - y1))
    area1 = float(max(0, b1[2] - b1[0]) * max(0, b1[3] - b1[1]))
    area2 = float(max(0, b2[2] - b2[0]) * max(0, b2[3] - b2[1]))
    denom = area1 + area2 - inter
    return inter / denom if denom > 1e-9 else 0.0


def _small_target_crop_fusion_pool_key(corners, pattern):
    bbox = _bbox_of_corners(corners)
    center = _center_of_corners(corners)
    return (
        int(pattern[0]),
        int(pattern[1]),
        int(round(float(center[0]) / 4.0)),
        int(round(float(center[1]) / 4.0)),
        int(round(float(bbox[0]) / 4.0)),
        int(round(float(bbox[1]) / 4.0)),
    )


def _small_target_crop_fusion_dedupe(pool):
    unique = []
    seen = set()
    for item in sorted(
        pool,
        key=lambda r: (-len(r['corners']), str(r['source']), str(r['label'])),
    ):
        key = _small_target_crop_fusion_pool_key(
            item['corners'], item['pattern'])
        if key in seen:
            continue
        seen.add(key)
        bbox = _bbox_of_corners(item['corners'])
        duplicate = False
        for old in unique:
            old_bbox = _bbox_of_corners(old['corners'])
            if (
                _bbox_union_iou(bbox, old_bbox) > 0.92
                and abs(len(item['corners']) - len(old['corners'])) <= 4
            ):
                duplicate = True
                break
        if not duplicate:
            unique.append(item)
    return unique


def _small_target_crop_fusion_variants(item):
    variants = [('orig', item)]
    try:
        det = (item['corners'], tuple(item['pattern']), item['label'])
        trans_corners, trans_pattern, trans_label = _transpose_detection(det)
        if tuple(trans_pattern) != tuple(item['pattern']):
            other = dict(item)
            other['corners'] = trans_corners
            other['pattern'] = tuple(int(v) for v in trans_pattern)
            other['label'] = trans_label
            variants.append(('trans', other))
    except Exception:
        pass
    return variants


def _small_target_crop_upscale_fusion_recovery(
        gray, baseline, n_faces=3, verbose=False, crop_baseline=None):
    """Fuse sparse direct/legacy faces with crop-upscaled real detections."""
    if n_faces < 3 or len(baseline or []) < n_faces:
        return []
    baseline = _normalize_face_axis_order(baseline or [])[:n_faces]
    if (
        _small_target_region_patterns_exact(baseline)
        and _total_corner_count(baseline) >= MIN_VALIDATED_SMALL_TARGET_CORNERS
        and _cube_detection_sparse_face_count(baseline) == 0
    ):
        return []

    if crop_baseline is not None:
        crop = crop_baseline
    else:
        crop = _detect_cube_first_in_upscaled_crop(
            gray, n_faces=n_faces, verbose=False)
    crop = _normalize_face_axis_order(crop or [])[:n_faces]
    if not crop:
        return []

    pool = []
    for idx, (corners, pattern, label) in enumerate(baseline):
        pool.append({
            'corners': corners,
            'pattern': tuple(int(v) for v in pattern),
            'label': label,
            'source': f'base:{idx}',
        })
    for idx, (corners, pattern, label) in enumerate(crop):
        pool.append({
            'corners': corners,
            'pattern': tuple(int(v) for v in pattern),
            'label': label,
            'source': f'crop:{idx}',
        })
    pool = _small_target_crop_fusion_dedupe(pool)
    if len(pool) < n_faces:
        return []

    best = None
    for combo in combinations(range(len(pool)), n_faces):
        combo_items = [pool[i] for i in combo]
        if not any(str(item['source']).startswith('crop:') for item in combo_items):
            continue
        if sum(len(item['corners']) for item in combo_items) < MIN_VALIDATED_SMALL_TARGET_CORNERS:
            continue
        bboxes = [_bbox_of_corners(item['corners']) for item in combo_items]
        max_iou = 0.0
        for a, b in combinations(range(n_faces), 2):
            max_iou = max(max_iou, _bbox_union_iou(bboxes[a], bboxes[b]))
        if max_iou > MAX_SMALL_TARGET_CROP_FUSION_OVERLAP_IOU:
            continue

        options = [_small_target_crop_fusion_variants(item) for item in combo_items]
        for perm in permutations(range(n_faces)):
            perm_options = [options[i] for i in perm]
            for variant_choice in product(*perm_options):
                dets = []
                sources = []
                for out_idx, (variant_name, item) in enumerate(variant_choice):
                    label = ('XY', 'XZ', 'YZ')[out_idx]
                    dets.append((
                        item['corners'],
                        tuple(int(v) for v in item['pattern']),
                        label,
                    ))
                    sources.append(f"{item['source']}:{variant_name}")
                if not _small_target_region_patterns_exact(dets):
                    continue
                if _total_corner_count(dets) < MIN_VALIDATED_SMALL_TARGET_CORNERS:
                    continue
                if _cube_detection_sparse_face_count(dets) > 0:
                    continue
                line_q = max(
                    _line_quality_for_candidate(corners, pattern)
                    for corners, pattern, _label in dets
                )
                if (
                    not np.isfinite(line_q)
                    or line_q > MAX_SMALL_TARGET_CROP_FUSION_LINE_QUALITY_PX
                ):
                    continue
                centered = _cube_detection_geometry_rmse(
                    dets, gray.shape, n_faces=n_faces, allow_sparse=False,
                    assume_normalized=True)
                if (
                    not np.isfinite(centered)
                    or centered > MAX_SMALL_TARGET_CROP_FUSION_CENTERED_PNP_RMSE_PX
                ):
                    continue
                offset_pnp, offset, offset_dist = _cube_detection_best_offset_pnp_rmse(
                    dets, gray.shape, n_faces=n_faces, assume_normalized=True,
                    early_stop_rmse=MAX_SMALL_TARGET_CROP_FUSION_OFFSET_PNP_RMSE_PX)
                if (
                    not np.isfinite(offset_pnp)
                    or offset_pnp > MAX_SMALL_TARGET_CROP_FUSION_OFFSET_PNP_RMSE_PX
                ):
                    continue
                score = (
                    float(offset_pnp)
                    + 0.10 * float(centered)
                    + 0.25 * float(line_q)
                    + 0.04 * float(offset_dist if np.isfinite(offset_dist) else 0.0)
                    - 0.010 * float(_total_corner_count(dets))
                )
                if best is None or score < best[0]:
                    best = (score, dets, sources, centered, offset_pnp, offset)

    if best is None:
        return []
    _score, dets, sources, centered, offset_pnp, offset = best
    if verbose:
        desc = ', '.join(sources)
        off_desc = "" if offset is None else f", offset={offset}"
        print(
            "  Small-target crop fusion recovery: "
            f"centered={centered:.2f}px, offset={offset_pnp:.2f}px"
            f"{off_desc}; {desc}"
        )
    return _normalize_face_axis_order(dets)


def _center_of_corners(corners):
    pts = corners.reshape(-1, 2)
    return pts.mean(axis=0)


def _merge_larger_overlapping_detections(anchor, candidates):
    """Keep anchor labels, but replace tight detections with larger overlaps."""
    if not anchor or not candidates:
        return anchor

    merged = list(anchor)
    used_candidate_idxs = set()
    for i, det in enumerate(merged):
        corners, pat, label = det
        bbox = _bbox_of_corners(corners)
        center = _center_of_corners(corners)
        scale = max(bbox[2] - bbox[0], bbox[3] - bbox[1], 1)
        sig = _detection_face_signature(corners, pat)
        if sig is None:
            continue
        row_dir, col_dir = sig
        best = None
        best_idx = None
        best_score = 0.0
        for cand_idx, (cand_corners, cand_pat, _cand_label) in enumerate(candidates):
            if cand_idx in used_candidate_idxs:
                continue
            if len(cand_corners) <= len(corners) + 6:
                continue
            cand_sig = _detection_face_signature(cand_corners, cand_pat)
            if cand_sig is None:
                continue
            cand_row, cand_col = cand_sig
            same_axes = (
                _cos_sim(row_dir, cand_row) > 0.82
                and _cos_sim(col_dir, cand_col) > 0.82
            )
            swapped_axes = (
                _cos_sim(row_dir, cand_col) > 0.82
                and _cos_sim(col_dir, cand_row) > 0.82
            )
            if not (same_axes or swapped_axes):
                continue
            cand_bbox = _bbox_of_corners(cand_corners)
            cand_center = _center_of_corners(cand_corners)
            overlap = _iou(bbox, cand_bbox)
            dist = float(np.linalg.norm(center - cand_center))
            near = dist < 0.75 * scale
            if overlap < 0.12 and not near:
                continue
            score = float(len(cand_corners)) + 20.0 * overlap - 0.02 * dist
            if score > best_score:
                best_score = score
                best_idx = cand_idx
                best = (cand_corners, cand_pat, label)
        if best is not None:
            merged[i] = best
            used_candidate_idxs.add(best_idx)

    return merged


def _detections_have_duplicate_plane(detections, axis_threshold=0.995):
    """Reject two face candidates that carry the same two grid directions."""
    signatures = [_axis_signature(det) for det in detections]
    for i in range(len(signatures)):
        if signatures[i] is None:
            continue
        row_i, col_i = signatures[i]
        for j in range(i + 1, len(signatures)):
            if signatures[j] is None:
                continue
            row_j, col_j = signatures[j]
            same_axes = (
                _cos_sim(row_i, row_j) >= axis_threshold
                and _cos_sim(col_i, col_j) >= axis_threshold
            )
            swapped_axes = (
                _cos_sim(row_i, col_j) >= axis_threshold
                and _cos_sim(col_i, row_j) >= axis_threshold
            )
            if same_axes or swapped_axes:
                return True
    return False


def _detections_have_excessive_overlap(detections, threshold=0.65):
    boxes = [_bbox_of_corners(corners) for corners, _pat, _label in detections]
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            if _iou(boxes[i], boxes[j]) > threshold:
                return True
    return _detections_have_duplicate_plane(detections)


def _transpose_detection(det):
    corners, pat, label = det
    cols, rows = pat
    grid = corners.reshape(rows, cols, 1, 2)
    transposed = grid.transpose(1, 0, 2, 3).reshape(-1, 1, 2)
    return transposed.astype(np.float32), (rows, cols), label


def _axis_signature(det):
    corners, pat, _label = det
    try:
        use_ransac = not _env_flag("CALIB_FAST_AXIS_SIGNATURE_TLS", False)
        row_lines, col_lines, _, _ = lines_from_chessboard_corners(
            corners, pat, use_ransac=use_ransac)
    except Exception:
        return None
    return _mean_dir(row_lines), _mean_dir(col_lines)


def _normalize_face_axis_order(detections, signature_cache=None):
    """Make row-lines map to face.axis_x and col-lines to face.axis_y.

    OpenCV can return square boards transposed.  The cube gives us a stronger
    cue: X is shared by XY/XZ, Y by XY/YZ, and Z by XZ/YZ.  Try every
    transpose combination and keep the one that makes shared axes most
    parallel in the image.
    """
    if len(detections) < 2:
        return detections

    axes_for_label = {'XY': ('X', 'Y'), 'XZ': ('X', 'Z'), 'YZ': ('Y', 'Z')}
    best = None
    n = len(detections)
    for mask in range(1 << n):
        cand = []
        dirs_by_axis = {'X': [], 'Y': [], 'Z': []}
        ok = True
        for i, det in enumerate(detections):
            transpose = bool(mask & (1 << i))
            if signature_cache is not None:
                key = (id(det[0]), tuple(int(v) for v in det[1]), det[2], transpose)
                cached = signature_cache.get(key)
                if cached is None:
                    d = _transpose_detection(det) if transpose else det
                    sig = _axis_signature(d)
                    signature_cache[key] = (d, sig)
                else:
                    d, sig = cached
            else:
                d = _transpose_detection(det) if transpose else det
                sig = _axis_signature(d)
            if sig is None or d[2] not in axes_for_label:
                ok = False
                break
            row_dir, col_dir = sig
            axis_x, axis_y = axes_for_label[d[2]]
            dirs_by_axis[axis_x].append(row_dir)
            dirs_by_axis[axis_y].append(col_dir)
            cand.append(d)
        if not ok:
            continue

        score = 0.0
        for dirs in dirs_by_axis.values():
            for i in range(len(dirs)):
                for j in range(i + 1, len(dirs)):
                    score += _cos_sim(dirs[i], dirs[j])
        # Small bias toward not transposing unless the shared-axis evidence
        # clearly supports it.
        score -= 0.01 * bin(mask).count("1")
        if best is None or score > best[0]:
            best = (score, cand)

    return best[1] if best is not None else detections


# ─────────────────── Phase 1: Detection ─────────────────────────────────────

def _detect_all(gray, n_faces=3, verbose=False):
    enhanced = preprocess_image(gray)
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    cands, seen = [], set()
    for cfg in FACE_CONFIGS[:n_faces]:
        for pat in cfg['patterns']:
            if pat in seen: continue
            seen.add(pat)
            ok, c = cv2.findChessboardCorners(enhanced, pat, flags=flags)
            if ok and c is not None:
                cands.append((c, pat))
                if verbose:
                    print(f"  Found {pat[0]}x{pat[1]} ({len(c)} corners)")
    return cands


# ─────────────────── Phase 2: Line Direction Clustering ─────────────────────

def _extract_all_lines(candidates):
    """Extract ALL row and column lines from all detections.

    Returns list of (line, direction, bbox_center, detection_idx).
    """
    all_lines = []
    for di, (corners, pat) in enumerate(candidates):
        try:
            rl, cl, rq, cq = lines_from_chessboard_corners(corners, pat, use_ransac=True)
        except Exception:
            continue
        c = corners.reshape(-1, 2)
        center = c.mean(axis=0)
        for line in rl:
            all_lines.append({'line': line, 'dir': _line_dir(line),
                            'center': center, 'det': di, 'type': 'row'})
        for line in cl:
            all_lines.append({'line': line, 'dir': _line_dir(line),
                            'center': center, 'det': di, 'type': 'col'})
    return all_lines


def _cluster_lines_by_direction(all_lines, angle_thresh_deg=25):
    """Cluster lines by direction. Returns list of direction clusters.

    Each cluster has: mean_dir, lines[], detection_indices
    """
    if not all_lines:
        return []

    thresh = np.cos(np.deg2rad(angle_thresh_deg))  # ~0.906 for 25°

    clusters = []  # [{mean_dir, lines[], dets_set}]
    for ld in all_lines:
        matched = -1
        best_sim = 0
        for ci, cl in enumerate(clusters):
            sim = _cos_sim(ld['dir'], cl['mean_dir'])
            if sim > thresh and sim > best_sim:
                best_sim = sim
                matched = ci
        if matched >= 0:
            cl = clusters[matched]
            cl['lines'].append(ld)
            cl['dets'].add(ld['det'])
            # Update mean via SVD on accumulated directions
            all_dirs = np.array([l['dir'] for l in cl['lines']])
            U, S, Vt = np.linalg.svd(all_dirs.T)
            cl['mean_dir'] = U[:, 0]
        else:
            clusters.append({
                'mean_dir': ld['dir'].copy(),
                'lines': [ld],
                'dets': {ld['det']},
            })
    return clusters


def _detection_face_signature(corners, pattern):
    """Compute (row_dir, col_dir) for one detection."""
    try:
        rl, cl, _, _ = lines_from_chessboard_corners(corners, pattern, use_ransac=True)
    except Exception:
        return None
    return _mean_dir(rl), _mean_dir(cl)


def _cluster_detections_by_direction(candidates, verbose=False):
    """Cluster DETECTIONS (complete chessboards) by line direction similarity.

    Two detections are on the SAME face if BOTH their row and column
    mean directions match (cos_sim > 0.85 for both).

    Returns list of (face_cluster_members, mean_row_dir, mean_col_dir).
    """
    if not candidates:
        return []

    sigs = []
    for ci, (corners, pat) in enumerate(candidates):
        sig = _detection_face_signature(corners, pat)
        if sig is None: continue
        sigs.append({'idx': ci, 'corners': corners, 'pat': pat,
                     'row_dir': sig[0], 'col_dir': sig[1]})

    if not sigs: return []
    sigs.sort(key=lambda s: len(s['corners']), reverse=True)

    clusters = []
    for s in sigs:
        matched = -1
        best = 0
        for ci, cl in enumerate(clusters):
            rs = _cos_sim(s['row_dir'], cl['row_dir'])
            cs = _cos_sim(s['col_dir'], cl['col_dir'])
            if rs > 0.85 and cs > 0.85:
                if rs + cs > best:
                    best = rs + cs; matched = ci
        if matched >= 0:
            cl = clusters[matched]
            cl['members'].append(s)
            all_r = np.array([m['row_dir'] for m in cl['members']])
            all_c = np.array([m['col_dir'] for m in cl['members']])
            cl['row_dir'] = all_r.mean(axis=0); cl['row_dir'] /= np.linalg.norm(cl['row_dir']) + 1e-12
            cl['col_dir'] = all_c.mean(axis=0); cl['col_dir'] /= np.linalg.norm(cl['col_dir']) + 1e-12
        else:
            clusters.append({'members': [s], 'row_dir': s['row_dir'].copy(),
                           'col_dir': s['col_dir'].copy()})

    if verbose:
        print(f"  Direction clusters: {len(clusters)}")
        for ci, cl in enumerate(clusters):
            rd, cd = cl['row_dir'], cl['col_dir']
            ra = np.arctan2(abs(rd[1]), abs(rd[0]))*180/np.pi
            ca = np.arctan2(abs(cd[1]), abs(cd[0]))*180/np.pi
            sz = [f"{m['pat'][0]}x{m['pat'][1]}" for m in cl['members']]
            print(f"    Cluster {ci}: {len(cl['members'])} det(s) {sz}, "
                  f"row={ra:.1f}deg col={ca:.1f}deg")

    return clusters


# ─────────────────── Phase 3: Face Labeling + Boundary ──────────────────────

def _classify_face_direction(row_dir, col_dir, xy_row_dir=None, xy_col_dir=None):
    """Classify via axis-sharing with XY face.

    XY face has row~X(horizontal), col~Y(vertical).
    XZ shares X with XY → row similar to xy_row.
    YZ shares Y with XY → col similar to xy_col.
    For square patterns, row/col may be swapped.
    Returns (label, swapped) or (None, False).
    """
    if xy_row_dir is None or xy_col_dir is None:
        return (None, False)

    rr = _cos_sim(row_dir, xy_row_dir)
    cc = _cos_sim(col_dir, xy_col_dir)
    rc = _cos_sim(row_dir, xy_col_dir)
    cr = _cos_sim(col_dir, xy_row_dir)

    # Both match XY → same face
    if rr > 0.85 and cc > 0.85:
        return ('XY', False)
    if rc > 0.85 and cr > 0.85:
        return ('XY', True)

    # Shares X axis with XY (row ~ XY's row) → XZ
    if rr > 0.85:
        return ('XZ', False)
    if cr > 0.85:
        return ('XZ', True)

    # Shares Y axis with XY (col ~ XY's col) → YZ
    if cc > 0.85:
        return ('YZ', False)
    if rc > 0.85:
        return ('YZ', True)

    # Weaker threshold: which axis is shared more?
    best_normal  = max(rr, cc)
    best_swapped = max(rc, cr)
    if best_normal > 0.7 or best_swapped > 0.7:
        if best_normal >= best_swapped:
            if rr >= cc:
                return ('XZ', False)
            else:
                return ('YZ', False)
        else:
            if rc >= cr:
                return ('YZ', True)
            else:
                return ('XZ', True)

    return (None, False)


def _label_face_clusters(clusters, gray_shape, verbose=False):
    """Assign XY/XZ/YZ labels to direction clusters using direction-first logic."""
    h, w = gray_shape[:2]

    if not clusters: return []

    # Gather scored entries
    scored = []
    for ci, cl in enumerate(clusters):
        best = max(cl['members'], key=lambda m: len(m['corners']))
        corners = best['corners'].reshape(-1, 2)
        scored.append({
            'ci': ci,
            'row_dir': cl['row_dir'], 'col_dir': cl['col_dir'],
            'corners': best['corners'], 'pat': best['pat'],
            'bbox': _bbox_of_corners(best['corners']),
            'center': (corners[:,0].mean(), corners[:,1].mean()),
            'label': None,
        })

    if len(scored) == 1:
        scored[0]['label'] = 'XY'
        if verbose:
            s = scored[0]; b = s['bbox']
            print(f"  Face {s['label']}: {s['pat'][0]}x{s['pat'][1]} "
                  f"bbox=[{b[0]},{b[1]}-{b[2]},{b[3]}]")
        return scored

    # Identify XY: most axis-aligned (one dir near horizontal, one near vertical)
    def axis_score(s):
        ra = np.arctan2(abs(s['row_dir'][1]), abs(s['row_dir'][0])) * 180 / np.pi
        ca = np.arctan2(abs(s['col_dir'][1]), abs(s['col_dir'][0])) * 180 / np.pi
        # Score: how close each is to 0 or 90
        return -(min(ra % 90, 90 - ra % 90) + min(ca % 90, 90 - ca % 90))

    scored.sort(key=axis_score, reverse=True)
    assigned = set()

    # First: assign XY = most axis-aligned
    scored[0]['label'] = 'XY'
    assigned.add('XY')
    xy = scored[0]

    # Classify remaining by direction; skip labels already used
    for s in scored[1:]:
        label, swapped = _classify_face_direction(
            s['row_dir'], s['col_dir'],
            xy_row_dir=xy['row_dir'], xy_col_dir=xy['col_dir'])
        # If direction matches XY but XY already taken, try to reassign
        if label == 'XY' and 'XY' in assigned:
            # Check if it could be XZ or YZ instead
            # XY: row~horizontal, col~vertical
            # XZ: row~horizontal, col~diagonal
            # YZ: row~vertical, col~diagonal
            ra = np.arctan2(abs(s['row_dir'][1]), abs(s['row_dir'][0])) * 180 / np.pi
            ca = np.arctan2(abs(s['col_dir'][1]), abs(s['col_dir'][0])) * 180 / np.pi
            if ra < 40 and 25 < ca < 65:
                label = 'XZ'
            elif ra > 50 and 25 < ca < 65:
                label = 'YZ'
            # else keep as XY duplicate candidate

        if label is None or label in assigned:
            # Position fallback
            if s['center'][0] > xy['center'][0] + 10:
                label = 'XZ'
            elif s['center'][0] < xy['center'][0] - 10:
                label = 'YZ'
            else:
                # Try to find any unused label
                for lbl in ['XZ', 'YZ', 'XY']:
                    if lbl not in assigned:
                        label = lbl
                        break
                else:
                    label = 'XZ'

        if label in assigned:
            # Last resort: rename to unused label
            for lbl in ['YZ', 'XZ']:
                if lbl not in assigned:
                    label = lbl
                    break

        s['label'] = label
        assigned.add(label)

    if verbose:
        for s in scored:
            b = s['bbox']
            ra = np.arctan2(abs(s['row_dir'][1]), abs(s['row_dir'][0])) * 180 / np.pi
            ca = np.arctan2(abs(s['col_dir'][1]), abs(s['col_dir'][0])) * 180 / np.pi
            print(f"  Face {s['label']}: {s['pat'][0]}x{s['pat'][1]} "
                  f"row={ra:.1f}deg col={ca:.1f}deg "
                  f"bbox=[{b[0]},{b[1]}-{b[2]},{b[3]}] "
                  f"center=({s['center'][0]:.0f},{s['center'][1]:.0f})")

    return scored


# ─────────────────── Phase 4: Sequential Masked Search ──────────────────────

def _search_missing(gray, enhanced, labeled, n_faces, verbose=False):
    """Sequential masking: mask known faces, search for remaining faces."""
    h, w = gray.shape[:2]
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    existing = {f['label'] for f in labeled}

    # Build mask from known faces
    mask = np.ones((h, w), dtype=np.uint8) * 255
    for f in labeled:
        b = f['bbox']
        pad = 40
        x1, y1 = max(0, b[0]-pad), max(0, b[1]-pad)
        x2, y2 = min(w, b[2]+pad), min(h, b[3]+pad)
        mask[y1:y2, x1:x2] = 0

    # Get direction signatures of existing faces
    existing_dirs = {}
    for f in labeled:
        sig = _detection_face_signature(f['corners'], f['pat'])
        if sig:
            existing_dirs[f['label']] = sig

    xy = next((f for f in labeled if f['label'] == 'XY'), None)
    xy_rd = xy['row_dir'] if xy else None
    xy_cd = xy['col_dir'] if xy else None

    # Try ALL patterns (not just the missing face's config)
    all_patterns = []
    seen = set()
    for cfg in FACE_CONFIGS[:n_faces]:
        for pat in cfg['patterns']:
            if pat not in seen:
                seen.add(pat)
                all_patterns.append(pat)

    missing_labels = {cfg['label'] for cfg in FACE_CONFIGS[:n_faces]} - existing

    for pat in all_patterns:
        if len(labeled) >= n_faces:
            break

        search = enhanced.copy()
        search[mask == 0] = 0
        ok, corners = cv2.findChessboardCorners(search, pat, flags=flags)
        if not ok or corners is None:
            continue

        bbox = _bbox_of_corners(corners)
        # Check overlap with known faces
        if any(_iou(bbox, f['bbox']) > 0.15 for f in labeled):
            continue

        # Get direction signature
        sig = _detection_face_signature(corners, pat)
        if sig is None:
            continue
        new_rd, new_cd = sig

        # Verify genuinely different from existing
        is_new = True
        for _elabel, (erd, ecd) in existing_dirs.items():
            if _cos_sim(new_rd, erd) > 0.85 and _cos_sim(new_cd, ecd) > 0.85:
                is_new = False
                break
        if not is_new:
            continue

        # Classify by direction (primary), position (fallback)
        label, _swapped = _classify_face_direction(
            new_rd, new_cd, xy_row_dir=xy_rd, xy_col_dir=xy_cd)
        if label is None:
            c = corners.reshape(-1, 2)
            cx = c[:, 0].mean()
            if xy and cx > xy['center'][0] + 10:
                label = 'XZ'
            elif xy and cx < xy['center'][0] - 10:
                label = 'YZ'
            else:
                label = 'XZ'

        if label in existing:
            continue
        if label not in missing_labels and len(missing_labels) == 1:
            label = list(missing_labels)[0]

        if label in existing:
            continue

        c = corners.reshape(-1, 2)
        labeled.append({
            'label': label, 'corners': corners, 'pat': pat,
            'bbox': bbox, 'center': (c[:, 0].mean(), c[:, 1].mean()),
            'row_dir': new_rd, 'col_dir': new_cd,
        })
        existing.add(label)
        existing_dirs[label] = (new_rd, new_cd)
        missing_labels.discard(label)
        if verbose:
            print(f"  Masked search: found {label} {pat[0]}x{pat[1]}")
        # Update mask
        pad = 40
        x1, y1 = max(0, bbox[0]-pad), max(0, bbox[1]-pad)
        x2, y2 = min(w, bbox[2]+pad), min(h, bbox[3]+pad)
        mask[y1:y2, x1:x2] = 0

    unfound = {cfg['label'] for cfg in FACE_CONFIGS[:n_faces]} - {f['label'] for f in labeled}
    if unfound and verbose:
        print(f"  Masked search: {unfound} NOT FOUND")

    return labeled


# ─────────────────── Refinement ─────────────────────────────────────────────

def _refine(gray, labeled, verbose=False, enable_local_bbox=False):
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 1e-6)
    out = []
    for f in labeled:
        before_quality = _line_fit_quality(f['corners'], f['pat'])
        blur = estimate_blur_level(gray, f['corners'])
        ww, wh = adaptive_subpix_window(blur)
        original = f['corners'].astype(np.float32).copy()
        sub = cv2.cornerSubPix(gray, original.copy(), (ww, wh), (-1, -1), crit)
        after_quality = _line_fit_quality(sub, f['pat'])
        if not _refined_quality_is_usable(before_quality, after_quality):
            sub = original
            after_quality = before_quality
        local_info = None
        if enable_local_bbox:
            sub, local_info = _maybe_local_bbox_redetect_refine(
                gray, sub, f['pat'], f['label'])
        if local_info is not None:
            after_quality = _line_fit_quality(sub, f['pat'])
        out.append((sub, f['pat'], f['label']))
        if verbose:
            extra = ""
            if local_info is not None:
                extra = (
                    f" local={local_info['source']} "
                    f"H={local_info['h']:.2f} "
                    f"inlier={local_info['inlier']:.2f}"
                )
            print(
                f"  Refine {f['label']}: blur={blur:.2f} win={ww} "
                f"line_q={after_quality:.2f}{extra}"
            )
    if enable_local_bbox:
        out = _maybe_global_bbox_layout_refine(
            gray, out, n_faces=min(3, len(out)), verbose=verbose)
    return out


def _detections_to_labeled(detections):
    labeled = []
    for corners, pat, label in detections:
        pts = corners.reshape(-1, 2)
        sig = _detection_face_signature(corners, pat)
        if sig is None:
            continue
        row_dir, col_dir = sig
        labeled.append({
            'label': label,
            'corners': corners,
            'pat': pat,
            'bbox': _bbox_of_corners(corners),
            'center': (pts[:, 0].mean(), pts[:, 1].mean()),
            'row_dir': row_dir,
            'col_dir': col_dir,
        })
    return labeled


# ─────────────────── Main ───────────────────────────────────────────────────

def _line_fit_quality(corners, pattern):
    try:
        _rl, _cl, rq, cq = lines_from_chessboard_corners(
            corners, pattern, use_ransac=True)
    except Exception:
        return float('inf')
    return float(max(rq, cq))


def _refined_quality_is_usable(before, after):
    if not np.isfinite(after):
        return False
    if not np.isfinite(before):
        return True
    return after <= max(1.5, before * 3.0)


def _grid_points_for_pattern(pattern):
    cols, rows = int(pattern[0]), int(pattern[1])
    return np.asarray(
        [[float(c), float(r)] for r in range(rows) for c in range(cols)],
        dtype=np.float32,
    )


def _face_homography_stats(corners, pattern, ransac_threshold=2.0):
    pts = np.asarray(corners, dtype=np.float32).reshape(-1, 2)
    cols, rows = int(pattern[0]), int(pattern[1])
    if pts.shape[0] != cols * rows or pts.shape[0] < 4:
        return float('inf'), float('inf'), 0.0
    grid = _grid_points_for_pattern(pattern)
    try:
        H, _mask = cv2.findHomography(grid, pts, method=0)
    except cv2.error:
        H = None
    if H is None or not np.all(np.isfinite(H)):
        all_rmse = float('inf')
    else:
        proj = cv2.perspectiveTransform(grid.reshape(-1, 1, 2), H).reshape(-1, 2)
        diff = proj - pts
        all_rmse = float(np.sqrt(np.mean(np.sum(diff * diff, axis=1))))

    try:
        Hr, mask = cv2.findHomography(
            grid, pts, method=cv2.RANSAC,
            ransacReprojThreshold=float(ransac_threshold),
        )
    except cv2.error:
        Hr, mask = None, None
    if Hr is None or not np.all(np.isfinite(Hr)):
        return all_rmse, float('inf'), 0.0
    proj = cv2.perspectiveTransform(grid.reshape(-1, 1, 2), Hr).reshape(-1, 2)
    norms = np.linalg.norm((proj - pts).astype(np.float64), axis=1)
    if mask is None:
        inlier_mask = np.ones((len(norms),), dtype=bool)
    else:
        inlier_mask = np.asarray(mask, dtype=np.uint8).reshape(-1).astype(bool)
    inlier_frac = float(np.count_nonzero(inlier_mask)) / float(max(len(inlier_mask), 1))
    if np.count_nonzero(inlier_mask) == 0:
        robust_rmse = float('inf')
    else:
        robust_rmse = float(np.sqrt(np.mean(norms[inlier_mask] ** 2)))
    return all_rmse, robust_rmse, inlier_frac


def _orient_same_pattern_to_reference(corners, reference, pattern):
    cols, rows = int(pattern[0]), int(pattern[1])
    cand = np.asarray(corners, dtype=np.float32).reshape(rows, cols, 2)
    ref = np.asarray(reference, dtype=np.float32).reshape(rows, cols, 2)
    variants = [
        cand,
        cand[:, ::-1, :],
        cand[::-1, :, :],
        cand[::-1, ::-1, :],
    ]
    best = min(
        variants,
        key=lambda arr: float(np.mean(np.linalg.norm(
            arr.reshape(-1, 2) - ref.reshape(-1, 2), axis=1))),
    )
    return best.reshape(-1, 1, 2).astype(np.float32)


def _local_bbox_redetect_candidates(gray, reference, pattern):
    h, w = gray.shape[:2]
    pts = np.asarray(reference, dtype=np.float32).reshape(-1, 2)
    x1, y1 = pts.min(axis=0)
    x2, y2 = pts.max(axis=0)
    bw = max(1.0, float(x2 - x1))
    bh = max(1.0, float(y2 - y1))
    cx = 0.5 * float(x1 + x2)
    cy = 0.5 * float(y1 + y2)
    span = max(bw, bh, 1.0)
    windows = [
        (1.22, 0.00, 0.00, 'bbox-1.22'),
        (1.55, 0.00, 0.00, 'bbox-1.55'),
        (1.85, 0.00, 0.00, 'bbox-1.85'),
        (1.85, 0.00, 0.14, 'bbox-1.85-down'),
    ]
    flags = cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_NORMALIZE_IMAGE
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 80, 1e-5)
    out = []
    for scale, sx, sy, source in windows:
        ww = bw * scale
        hh = bh * scale
        ccx = cx + sx * span
        ccy = cy + sy * span
        rx1 = int(max(0, math.floor(ccx - 0.5 * ww)))
        ry1 = int(max(0, math.floor(ccy - 0.5 * hh)))
        rx2 = int(min(w, math.ceil(ccx + 0.5 * ww)))
        ry2 = int(min(h, math.ceil(ccy + 0.5 * hh)))
        if rx2 - rx1 < 32 or ry2 - ry1 < 32:
            continue
        roi = gray[ry1:ry2, rx1:rx2].copy()
        rh, rw = roi.shape[:2]
        max_dim = max(rw, rh)
        resize_scale = 1.0
        if max_dim < LOCAL_BBOX_REDETECT_TARGET_DIM:
            resize_scale = min(
                LOCAL_BBOX_REDETECT_MAX_SCALE,
                LOCAL_BBOX_REDETECT_TARGET_DIM / float(max(max_dim, 1)),
            )
        elif max_dim > 760:
            resize_scale = 760.0 / float(max_dim)
        if abs(resize_scale - 1.0) > 1e-3:
            roi_scaled = cv2.resize(
                roi,
                (
                    max(1, int(round(rw * resize_scale))),
                    max(1, int(round(rh * resize_scale))),
                ),
                interpolation=cv2.INTER_CUBIC if resize_scale > 1.0 else cv2.INTER_AREA,
            )
        else:
            roi_scaled = roi
        variants = [
            (preprocess_image(roi_scaled), 'pre'),
            (roi_scaled, 'raw'),
            (cv2.equalizeHist(roi_scaled), 'eq'),
        ]
        for variant, variant_name in variants:
            try:
                ok, cand = cv2.findChessboardCorners(variant, pattern, flags=flags)
            except cv2.error:
                ok, cand = False, None
            if not ok or cand is None:
                continue
            cand = np.asarray(cand, dtype=np.float32).reshape(-1, 1, 2)
            try:
                cand = cv2.cornerSubPix(
                    variant, cand, (7, 7), (-1, -1), criteria)
            except cv2.error:
                pass
            cand[:, 0, 0] = cand[:, 0, 0] / float(resize_scale) + float(rx1)
            cand[:, 0, 1] = cand[:, 0, 1] / float(resize_scale) + float(ry1)
            out.append((cand.astype(np.float32), source + ':' + variant_name))
            break
    return out


def _maybe_local_bbox_redetect_refine(gray, corners, pattern, label):
    if not ENABLE_LOCAL_BBOX_REDETECT_REFINEMENT:
        return corners, None
    reference = np.asarray(corners, dtype=np.float32).reshape(-1, 1, 2)
    base_h, base_rh, base_inlier = _face_homography_stats(reference, pattern)
    base_bbox = _bbox_of_corners(reference)
    base_center = _center_of_corners(reference)
    base_span = max(base_bbox[2] - base_bbox[0], base_bbox[3] - base_bbox[1], 1)
    best = {
        'corners': reference,
        'source': 'subpix',
        'h': base_h,
        'rh': base_rh,
        'inlier': base_inlier,
        'score': (
            (3.0 if base_h <= 2.0 and base_inlier >= 0.70 else
             2.0 if base_h <= 3.2 and base_inlier >= 0.55 else
             1.0 if base_h <= 4.8 and base_inlier >= 0.45 else 0.0),
            base_inlier,
            -base_h,
            -base_rh,
        ),
    }
    for cand, source in _local_bbox_redetect_candidates(gray, reference, pattern):
        cand = _orient_same_pattern_to_reference(cand, reference, pattern)
        cand_bbox = _bbox_of_corners(cand)
        cand_center = _center_of_corners(cand)
        center_norm = float(np.linalg.norm(cand_center - base_center)) / float(base_span)
        overlap = _iou(base_bbox, cand_bbox)
        if center_norm > 0.45 or overlap < 0.45:
            continue
        h_rmse, robust_rmse, inlier_frac = _face_homography_stats(cand, pattern)
        if not np.isfinite(h_rmse):
            continue
        tier = (
            3.0 if h_rmse <= 2.0 and inlier_frac >= 0.70 else
            2.0 if h_rmse <= 3.2 and inlier_frac >= 0.55 else
            1.0 if h_rmse <= 4.8 and inlier_frac >= 0.45 else 0.0
        )
        score = (
            tier,
            inlier_frac,
            -h_rmse,
            -robust_rmse,
            -center_norm,
            overlap,
        )
        if score > best['score']:
            best = {
                'corners': cand,
                'source': source,
                'h': h_rmse,
                'rh': robust_rmse,
                'inlier': inlier_frac,
                'score': score,
                'center_norm': center_norm,
                'overlap': overlap,
            }
    if best['source'] == 'subpix':
        return reference, None
    if best['h'] > min(6.0, max(2.0, base_h - 0.75)):
        return reference, None
    return best['corners'], best


def _local_bbox_layout_candidate_key(item):
    h = float(item.get('h', float('inf')))
    rh = float(item.get('rh', float('inf')))
    inlier = float(item.get('inlier', 0.0))
    center_norm = float(item.get('center_norm', 0.0))
    overlap = float(item.get('overlap', 1.0))
    tier = (
        3.0 if h <= 2.0 and inlier >= 0.70 else
        2.0 if h <= 3.2 and inlier >= 0.55 else
        1.0 if h <= 4.8 and inlier >= 0.45 else
        0.0
    )
    return (tier, inlier, -h, -rh, -center_norm, overlap)


def _local_bbox_layout_candidate_pool(gray, detection, max_extra=2):
    corners, pattern, label = detection
    reference = np.asarray(corners, dtype=np.float32).reshape(-1, 1, 2)
    base_h, base_rh, base_inlier = _face_homography_stats(reference, pattern)
    base_bbox = _bbox_of_corners(reference)
    base_center = _center_of_corners(reference)
    base_span = max(base_bbox[2] - base_bbox[0], base_bbox[3] - base_bbox[1], 1)
    pool = [{
        'corners': reference,
        'pattern': pattern,
        'label': label,
        'source': 'base',
        'h': base_h,
        'rh': base_rh,
        'inlier': base_inlier,
        'center_norm': 0.0,
        'overlap': 1.0,
    }]

    candidates = []
    for cand, source in _local_bbox_redetect_candidates(gray, reference, pattern):
        cand = _orient_same_pattern_to_reference(cand, reference, pattern)
        cand_bbox = _bbox_of_corners(cand)
        cand_center = _center_of_corners(cand)
        center_norm = (
            float(np.linalg.norm(cand_center - base_center)) / float(base_span)
        )
        overlap = _iou(base_bbox, cand_bbox)
        if center_norm > 0.45 or overlap < 0.45:
            continue
        h_rmse, robust_rmse, inlier_frac = _face_homography_stats(cand, pattern)
        if not np.isfinite(h_rmse):
            continue
        item = {
            'corners': cand,
            'pattern': pattern,
            'label': label,
            'source': source,
            'h': h_rmse,
            'rh': robust_rmse,
            'inlier': inlier_frac,
            'center_norm': center_norm,
            'overlap': overlap,
        }
        if _local_bbox_layout_candidate_key(item)[0] <= 0.0:
            continue
        candidates.append(item)

    candidates.sort(key=_local_bbox_layout_candidate_key, reverse=True)
    pool.extend(candidates[:max(0, int(max_extra))])
    return pool


def _global_bbox_layout_cheap_combo_key(combo):
    worst_h = max(float(item.get('h', float('inf'))) for item in combo)
    worst_rh = max(float(item.get('rh', float('inf'))) for item in combo)
    min_inlier = min(float(item.get('inlier', 0.0)) for item in combo)
    changed = sum(1 for item in combo if item.get('source') != 'base')
    return (
        worst_h
        + 0.50 * worst_rh
        - min_inlier
        + 0.05 * float(changed)
    )


def _maybe_global_bbox_layout_refine(gray, detections, n_faces=3, verbose=False):
    """Replace local face corners only when the whole three-face layout improves."""
    if (
        not ENABLE_GLOBAL_BBOX_LAYOUT_REFINEMENT
        or len(detections) < n_faces
        or n_faces < 3
    ):
        return detections

    base = _normalize_face_axis_order(detections)[:n_faces]
    if len(base) < n_faces or _cube_detection_sparse_face_count(base):
        return detections
    baseline_geom = _cube_detection_geometry_rmse(base, gray.shape, n_faces=n_faces)
    if not np.isfinite(baseline_geom):
        baseline_geom = float('inf')

    pools = [
        _local_bbox_layout_candidate_pool(gray, det, max_extra=2)
        for det in base
    ]
    if all(len(pool) <= 1 for pool in pools):
        return detections

    combos = [
        combo for combo in product(*pools)
        if any(item['source'] != 'base' for item in combo)
    ]
    combos.sort(key=_global_bbox_layout_cheap_combo_key)
    if GLOBAL_BBOX_LAYOUT_GEOMETRY_COMBO_LIMIT > 0:
        combos = combos[:GLOBAL_BBOX_LAYOUT_GEOMETRY_COMBO_LIMIT]

    best = None
    for combo in combos:
        changed = sum(1 for item in combo if item['source'] != 'base')
        candidate = [
            (item['corners'], item['pattern'], item['label'])
            for item in combo
        ]
        candidate = _normalize_face_axis_order(candidate)[:n_faces]
        if len(candidate) < n_faces:
            continue
        if _detections_have_excessive_overlap(candidate, threshold=0.55):
            continue
        geom = _cube_detection_geometry_rmse(candidate, gray.shape, n_faces=n_faces)
        if not np.isfinite(geom):
            continue
        worst_h = max(float(item['h']) for item in combo)
        worst_rh = max(float(item['rh']) for item in combo)
        min_inlier = min(float(item['inlier']) for item in combo)
        if geom > MAX_GLOBAL_BBOX_LAYOUT_FAST_PNP_RMSE_PX:
            continue
        if geom > baseline_geom - MIN_GLOBAL_BBOX_LAYOUT_PNP_IMPROVEMENT_PX:
            continue
        if worst_h > MAX_GLOBAL_BBOX_LAYOUT_HOMOGRAPHY_RMSE_PX:
            continue
        if worst_rh > MAX_GLOBAL_BBOX_LAYOUT_ROBUST_HOMOGRAPHY_RMSE_PX:
            continue
        if min_inlier < MIN_GLOBAL_BBOX_LAYOUT_HOMOGRAPHY_INLIER_FRAC:
            continue
        score = (
            float(geom)
            + 0.25 * worst_h
            + 0.25 * worst_rh
            - 0.50 * min_inlier
            + 0.10 * changed
        )
        if best is None or score < best[0]:
            best = (
                score, geom, worst_h, worst_rh, min_inlier,
                changed, candidate, combo,
            )

    if best is None:
        return detections

    _score, geom, worst_h, worst_rh, min_inlier, changed, candidate, combo = best
    if verbose:
        desc = ', '.join(
            f"{item['label']}:{item['source']}"
            for item in combo
            if item['source'] != 'base'
        )
        print(
            "  Global bbox layout refinement: "
            f"PnP {baseline_geom:.2f}->{geom:.2f}px, "
            f"H={worst_h:.2f}px, robustH={worst_rh:.2f}px, "
            f"inlier={min_inlier:.2f}, changed={changed} ({desc})"
        )
    if len(detections) > n_faces:
        tail = list(detections)[n_faces:]
        return candidate + tail
    return candidate


def detect_corner_cube_faces(gray, n_faces=3, verbose=False,
                             sparse_fast_return=False):
    """Detect faces of the three-face orthogonal corner-cube target.

    Returns List of (corners, pattern, label).
    """
    h, w = gray.shape[:2]
    enhanced = preprocess_image(gray)

    # 0. Prefer the physical order: cube -> visible faces -> face grids.
    # The legacy path below starts from global chessboard detection, which
    # often misses the top face when perspective or neighbouring faces confuse
    # OpenCV's complete-board detector.
    if verbose:
        print("Phase 0: Cube-first face search...")
    direct_cube_first = _detect_cube_first(gray, n_faces=n_faces, verbose=verbose)
    upscaled_cube_first = []
    cube_area_pct = None
    if n_faces >= 3:
        try:
            cube_area_pct = estimate_cube_area_pct(gray, n_faces=n_faces)
        except Exception:
            cube_area_pct = None
    small_target_band = (
        cube_area_pct is not None
        and SMALL_TARGET_ATTEMPT_MIN_AREA_PCT <= cube_area_pct
        and cube_area_pct < NORMAL_RELIABLE_CUBE_AREA_PCT
    )
    direct_is_weak = (
        len(direct_cube_first) < n_faces
        or _total_corner_count(direct_cube_first) < 100
    )
    direct_multi_sparse_boundary = (
        len(direct_cube_first) >= n_faces
        and _cube_detection_sparse_face_count(direct_cube_first) > 1
        and _total_corner_count(direct_cube_first) < 100
    )
    if direct_multi_sparse_boundary:
        direct_is_weak = False
        if verbose:
            print(
                "  Cube-first found multiple sparse faces; "
                "checking sparse topology recovery"
            )
    if (
        sparse_fast_return
        and small_target_band
        and cube_area_pct is not None
        and cube_area_pct <= 7.0
        and len(direct_cube_first) >= n_faces
        and _total_corner_count(direct_cube_first) < 100
    ):
        sparse_offset_rmse, _sparse_offset, _sparse_offset_dist = (
            _cube_detection_best_offset_pnp_rmse(
                direct_cube_first, gray.shape, n_faces=n_faces,
                assume_normalized=True)
        )
        if np.isfinite(sparse_offset_rmse) and sparse_offset_rmse > 20.0:
            if verbose:
                print(
                    "  Cube-first small-target sparse fast return: "
                    f"corners={_total_corner_count(direct_cube_first)}, "
                    f"offset={sparse_offset_rmse:.2f}px; "
                    "letting caller try alternate grayscale"
                )
            return _normalize_face_axis_order(direct_cube_first)
    if not direct_is_weak and n_faces >= 3:
        if small_target_band:
            direct_corners = _total_corner_count(direct_cube_first)
            direct_sparse = _cube_detection_sparse_face_count(
                direct_cube_first)
            direct_small_target_candidate = (
                len(direct_cube_first) >= n_faces
                and _small_target_region_patterns_exact(direct_cube_first)
                and direct_corners >= MIN_VALIDATED_SMALL_TARGET_CORNERS
            )
            direct_small_target_known_boundary = (
                len(direct_cube_first) >= n_faces
                and not direct_small_target_candidate
                and direct_corners >= MIN_VALIDATED_SMALL_TARGET_CORNERS
                and direct_sparse == 0
            )
            if direct_small_target_candidate:
                direct_is_weak = False
                if verbose:
                    print(
                        "  Cube-first small-target band: "
                        f"area={cube_area_pct:.2f}%; "
                        "direct pattern matches validated small-target gate"
                    )
            elif direct_small_target_known_boundary:
                direct_is_weak = False
                if verbose:
                    print(
                        "  Cube-first small-target band: "
                        f"area={cube_area_pct:.2f}%; "
                        "direct pattern cannot pass the validated "
                        "small-target gate"
                    )
            else:
                direct_is_weak = True
                if verbose:
                    print(
                        "  Cube-first small-target band: "
                        f"area={cube_area_pct:.2f}%; "
                        f"direct corners={direct_corners}, "
                        f"sparse_faces={direct_sparse}; "
                        "checking crop-upscaled candidate"
                    )
        elif (
            cube_area_pct is not None
            and NORMAL_RELIABLE_CUBE_AREA_PCT <= cube_area_pct
            and cube_area_pct < 10.0
        ):
            direct_geom = _cube_detection_geometry_rmse(
                direct_cube_first, gray.shape, n_faces=n_faces)
            if np.isfinite(direct_geom) and direct_geom > 12.0:
                direct_is_weak = True
                if verbose:
                    print(
                        "  Cube-first near area boundary: "
                        f"area={cube_area_pct:.2f}%, "
                        f"PnP score={direct_geom:.2f}px; "
                        "checking crop-upscaled candidate"
                    )
    direct_region_recovered = False
    if (
        direct_is_weak
        and small_target_band
        and len(direct_cube_first) >= 2
        and (
            len(direct_cube_first) < n_faces
            or _total_corner_count(direct_cube_first) >= 100
        )
    ):
        if verbose:
            print(
                "  Cube-first small-target band: trying direct "
                "two-face top-blob recovery before crop-upscale"
            )
        direct_region = _small_target_region_candidate_recovery(
            gray, direct_cube_first, n_faces=n_faces, verbose=verbose,
            allow_grid_expand=False, include_baseline=False,
            max_centered_pnp_rmse=MAX_SMALL_TARGET_FAST_DIRECT_CENTERED_PNP_RMSE_PX,
            max_offset_pnp_rmse=MAX_SMALL_TARGET_FAST_DIRECT_OFFSET_PNP_RMSE_PX,
            cube_area_pct=cube_area_pct)
        if direct_region:
            direct_region = _normalize_face_axis_order(direct_region)
            direct_centered_geom = _cube_detection_geometry_rmse(
                direct_region, gray.shape, n_faces=n_faces, allow_sparse=False,
                assume_normalized=True)
            direct_offset_rmse, _direct_offset, _direct_offset_dist = (
                _cube_detection_best_offset_pnp_rmse(
                    direct_region, gray.shape, n_faces=n_faces,
                    max_offset_dist=MAX_SPARSE_RECOVERY_OFFSET_DIST_SQUARES,
                    assume_normalized=True)
            )
            direct_corners = _total_corner_count(direct_region)
            direct_fast_ok = (
                _small_target_region_patterns_exact(direct_region)
                and direct_corners >= MIN_VALIDATED_SMALL_TARGET_CORNERS
                and np.isfinite(direct_centered_geom)
                and np.isfinite(direct_offset_rmse)
                and direct_centered_geom
                <= MAX_SMALL_TARGET_FAST_DIRECT_CENTERED_PNP_RMSE_PX
                and direct_offset_rmse
                <= MAX_SMALL_TARGET_FAST_DIRECT_OFFSET_PNP_RMSE_PX
            )
            if direct_fast_ok:
                direct_cube_first = direct_region
                direct_is_weak = False
                direct_region_recovered = True
                if verbose:
                    print(
                        "  Using direct small-target top-blob recovery "
                        "without crop-upscale "
                        f"(centered={direct_centered_geom:.2f}px, "
                        f"offset={direct_offset_rmse:.2f}px)"
                    )
            elif verbose:
                print(
                    "  Direct small-target top-blob recovery is not stable "
                    "enough for fast exit "
                    f"(centered={direct_centered_geom:.2f}px, "
                    f"offset={direct_offset_rmse:.2f}px, "
                    f"corners={direct_corners}); checking crop-upscale"
                )
    if (
        direct_is_weak
        and small_target_band
        and len(direct_cube_first) >= n_faces
        and _total_corner_count(direct_cube_first) >= 100
        and _cube_detection_sparse_face_count(direct_cube_first) <= 1
    ):
        if verbose:
            print(
                "  Cube-first small-target band: trying direct baseline "
                "grid-expand recovery before crop-upscale"
            )
        direct_expanded = _small_target_region_candidate_recovery(
            gray, direct_cube_first, n_faces=n_faces, verbose=verbose,
            allow_grid_expand=True, include_baseline=True,
            cube_area_pct=cube_area_pct)
        if direct_expanded:
            direct_expanded = _normalize_face_axis_order(direct_expanded)
            expanded_centered_geom = _cube_detection_geometry_rmse(
                direct_expanded, gray.shape, n_faces=n_faces,
                allow_sparse=False, assume_normalized=True)
            expanded_offset_rmse, _expanded_offset, _expanded_offset_dist = (
                _cube_detection_best_offset_pnp_rmse(
                    direct_expanded, gray.shape, n_faces=n_faces,
                    max_offset_dist=MAX_SPARSE_RECOVERY_OFFSET_DIST_SQUARES,
                    assume_normalized=True)
            )
            expanded_corners = _total_corner_count(direct_expanded)
            expanded_ok = (
                _small_target_region_patterns_exact(direct_expanded)
                and expanded_corners >= MIN_VALIDATED_SMALL_TARGET_CORNERS
                and np.isfinite(expanded_centered_geom)
                and expanded_centered_geom
                <= MAX_SMALL_TARGET_REGION_CENTERED_PNP_RMSE_PX
                and np.isfinite(expanded_offset_rmse)
                and expanded_offset_rmse
                <= MAX_SMALL_TARGET_FAST_DIRECT_OFFSET_PNP_RMSE_PX
            )
            if expanded_ok:
                direct_cube_first = direct_expanded
                direct_is_weak = False
                direct_region_recovered = True
                if verbose:
                    print(
                        "  Using direct small-target grid-expand recovery "
                        "without crop-upscale "
                        f"(centered={expanded_centered_geom:.2f}px, "
                        f"offset={expanded_offset_rmse:.2f}px)"
                    )
            elif verbose:
                print(
                    "  Direct small-target grid-expand recovery is not "
                    "stable enough for fast exit "
                    f"(centered={expanded_centered_geom:.2f}px, "
                    f"offset={expanded_offset_rmse:.2f}px, "
                    f"corners={expanded_corners}); checking crop-upscale"
                )
    if direct_is_weak:
        upscaled_cube_first = _detect_cube_first_in_upscaled_crop(
            gray, n_faces=n_faces, verbose=verbose)
    cube_first = _choose_cube_first_detection(
        upscaled_cube_first, direct_cube_first, n_faces=n_faces,
        image_shape=gray.shape)
    if verbose and cube_first is upscaled_cube_first and upscaled_cube_first:
        print("  Using crop-upscaled cube-first detections")
    cube_first = _normalize_face_axis_order(cube_first)
    small_region_recovered = direct_region_recovered
    small_region_candidate_too_sparse = (
        small_target_band
        and len(cube_first) >= n_faces
        and _total_corner_count(cube_first) < MAX_SMALL_TARGET_REGION_SKIP_SPARSE_CORNERS
        and _cube_detection_sparse_face_count(cube_first) > 0
    )
    if small_region_candidate_too_sparse and verbose:
        print(
            "  Small-target region recovery skipped: "
            "three-face candidate is still sparse/low-corner; "
            "checking legacy and crop-fusion paths"
        )
    if (
        small_target_band
        and (not small_region_recovered)
        and len(cube_first) >= n_faces
        and not small_region_candidate_too_sparse
    ):
        region_recovery = _small_target_region_candidate_recovery(
            gray, cube_first, n_faces=n_faces, verbose=verbose,
            cube_area_pct=cube_area_pct)
        if region_recovery:
            cube_first = _normalize_face_axis_order(region_recovery)
            small_region_recovered = True
    sparse_face_count = (
        _cube_detection_sparse_face_count(cube_first)
        if len(cube_first) >= n_faces
        else 0
    )
    sparse_topology_needed = (
        len(cube_first) >= n_faces
        and _total_corner_count(cube_first) < 100
        and (
            sparse_face_count > 1
            or ((not small_target_band) and sparse_face_count > 0)
        )
    )
    if sparse_topology_needed:
        if (
            small_target_band
            and _total_corner_count(cube_first)
            < MAX_SMALL_TARGET_SPARSE_TOPOLOGY_FAST_SKIP_CORNERS
        ):
            if verbose:
                print(
                    "  Small-target cube-first has only very sparse "
                    "multi-face evidence; skipping expensive sparse topology "
                    "recovery."
                )
            order = {'XY': 0, 'XZ': 1, 'YZ': 2}
            cube_first.sort(key=lambda d: order.get(d[2], 99))
            return cube_first
        defer_direct_upscaled_candidates = (
            (not small_target_band)
            and sparse_face_count > 1
        )
        recovery = _sparse_topology_candidate_recovery(
            gray, cube_first, n_faces=n_faces, verbose=verbose,
            include_upscaled_candidates=not defer_direct_upscaled_candidates,
            include_legacy_candidates=(
                (not small_target_band) and sparse_face_count == 1),
            cube_area_pct=cube_area_pct)
        if recovery and defer_direct_upscaled_candidates:
            def _deferred_recovery_rank(dets):
                dets = _normalize_face_axis_order(dets or [])
                sparse = _cube_detection_sparse_face_count(dets)
                corners = _total_corner_count(dets)
                offset_rmse, _offset, _offset_dist = (
                    _cube_detection_best_offset_pnp_rmse(
                        dets, gray.shape, n_faces=n_faces,
                        assume_normalized=True)
                )
                centered = _cube_detection_geometry_rmse(
                    dets, gray.shape, n_faces=n_faces,
                    assume_normalized=True)
                if not np.isfinite(offset_rmse):
                    offset_rmse = float('inf')
                if not np.isfinite(centered):
                    centered = float('inf')
                corner_deficit = max(
                    0,
                    int(MIN_DEFERRED_SPARSE_TOPOLOGY_FAST_CORNERS)
                    - int(corners),
                )
                return (
                    int(sparse),
                    int(corner_deficit),
                    float(offset_rmse),
                    float(centered),
                    -int(corners),
                )

            recovery_rank = _deferred_recovery_rank(recovery)
            recovery_needs_full_candidates = (
                recovery_rank[0] > 0
                or recovery_rank[1] > 0
                or recovery_rank[2]
                > MAX_DEFERRED_SPARSE_TOPOLOGY_FAST_OFFSET_PNP_RMSE_PX
            )
            if recovery_needs_full_candidates:
                if verbose:
                    print(
                        "  Deferred sparse topology candidate is weak; "
                        "retrying with upscaled candidates "
                        f"(sparse={recovery_rank[0]}, "
                        f"corner_deficit={recovery_rank[1]}, "
                        f"offset={recovery_rank[2]:.2f}px)"
                    )
                full_recovery = _sparse_topology_candidate_recovery(
                    gray, cube_first, n_faces=n_faces, verbose=verbose,
                    include_upscaled_candidates=True,
                    cube_area_pct=cube_area_pct)
                if full_recovery:
                    full_rank = _deferred_recovery_rank(full_recovery)
                    if full_rank < recovery_rank:
                        if verbose:
                            print(
                                "  Using full sparse topology recovery "
                                "candidate over deferred fast candidate"
                            )
                        recovery = full_recovery
        if not recovery:
            alternate_baselines = []
            if upscaled_cube_first:
                alternate_baselines.append(upscaled_cube_first)
            else:
                if verbose:
                    print(
                        "  Sparse topology recovery failed on direct "
                        "baseline; trying crop-upscaled baseline"
                    )
                alternate_baselines.append(_detect_cube_first_in_upscaled_crop(
                    gray, n_faces=n_faces, verbose=verbose))
            if cube_first is upscaled_cube_first and direct_cube_first:
                alternate_baselines.append(direct_cube_first)
            for alt in alternate_baselines:
                alt = _normalize_face_axis_order(alt)
                if (
                    len(alt) < n_faces
                    or _cube_detection_sparse_face_count(alt) <= 1
                    or _total_corner_count(alt) >= 100
                ):
                    continue
                recovery = _sparse_topology_candidate_recovery(
                    gray, alt, n_faces=n_faces, verbose=verbose,
                    cube_area_pct=cube_area_pct)
                if recovery:
                    break
        if recovery:
            cube_first = _normalize_face_axis_order(recovery)
        else:
            if sparse_face_count > 1:
                order = {'XY': 0, 'XZ': 1, 'YZ': 2}
                cube_first.sort(key=lambda d: order.get(d[2], 99))
                return cube_first
    if (
        len(cube_first) >= n_faces
        and _cube_detection_sparse_face_count(cube_first) > 1
        and _total_corner_count(cube_first) < 100
    ):
        order = {'XY': 0, 'XZ': 1, 'YZ': 2}
        cube_first.sort(key=lambda d: order.get(d[2], 99))
        return cube_first
    upgrade = _geometry_gated_cube_candidate_upgrade(
        gray, cube_first, n_faces=n_faces, verbose=verbose)
    if upgrade:
        cube_first = _normalize_face_axis_order(upgrade)
    weak_cube_first = None
    if len(cube_first) >= n_faces:
        if _total_corner_count(cube_first) >= 100:
            if verbose:
                print(f"Phase 5: Refinement...")
            enable_bbox_refine = small_target_band
            if small_target_band:
                enable_bbox_refine = (
                    (not small_region_recovered)
                    and _small_target_region_patterns_exact(cube_first)
                )
            pre_refine = list(cube_first)
            result = _refine(gray, [
                {
                    'label': label,
                    'corners': corners,
                    'pat': pat,
                    'bbox': _bbox_of_corners(corners),
                }
                for corners, pat, label in cube_first
            ], verbose, enable_local_bbox=enable_bbox_refine)
            if small_region_recovered and len(result) >= n_faces:
                pre_geom = _cube_detection_geometry_rmse(
                    pre_refine, gray.shape, n_faces=n_faces,
                    allow_sparse=False)
                post_geom = _cube_detection_geometry_rmse(
                    result, gray.shape, n_faces=n_faces,
                    allow_sparse=False)
                if (
                    np.isfinite(pre_geom)
                    and (
                        (not np.isfinite(post_geom))
                        or post_geom > pre_geom + 0.35
                    )
                ):
                    if verbose:
                        print(
                            "  Keeping pre-refinement small-target recovery "
                            f"geometry (PnP {pre_geom:.2f}px vs "
                            f"{post_geom:.2f}px after refinement)"
                        )
                    return pre_refine
            if verbose:
                print(f"Result: {len(result)} faces: {[r[2] for r in result]}")
            return result
        weak_cube_first = cube_first
        if verbose:
            print("  Cube-first found three sparse faces; checking for "
                  "larger in-cube grids...")
        if (
            small_target_band
            and (
                _cube_detection_sparse_face_count(cube_first) > 1
                or _total_corner_count(cube_first) < 60
            )
        ):
            if verbose:
                print(
                    "  Small-target cube-first remains below the strict "
                    "corner gate after crop/region recovery; skipping legacy "
                    "whole-image fallback."
                )
            order = {'XY': 0, 'XZ': 1, 'YZ': 2}
            cube_first.sort(key=lambda d: order.get(d[2], 99))
            return cube_first
    elif len(cube_first) >= 2:
        if verbose:
            print(f"Phase 0b: Cube-first masked search "
                  f"(have {len(cube_first)}, need {n_faces})...")
        labeled = _detections_to_labeled(cube_first)
        if len(labeled) >= 2:
            labeled = _search_missing(gray, enhanced, labeled, n_faces, verbose)
            if len(labeled) >= n_faces:
                if verbose:
                    print(f"Phase 5: Refinement...")
                result = _refine(
                    gray, labeled, verbose,
                    enable_local_bbox=small_target_band)
                result = _normalize_face_axis_order(result)
                if verbose:
                    print(f"Result: {len(result)} faces: {[r[2] for r in result]}")
                return result
    elif verbose and cube_first:
        print(f"  Cube-first found {len(cube_first)}/{n_faces}; "
              "falling back to legacy search")

    # 1. Multi-pattern detection
    if verbose: print(f"Phase 1: Detection...")
    cands = _detect_all(gray, n_faces, verbose)
    if not cands:
        if verbose: print("  No detections"); return []

    # 2. Cluster detections by line direction
    if verbose: print(f"Phase 2: Direction clustering...")
    clusters = _cluster_detections_by_direction(cands, verbose)
    if not clusters: return []

    # 3. Label faces + determine boundaries
    if verbose: print(f"Phase 3: Labeling...")
    labeled = _label_face_clusters(clusters, (h, w), verbose)

    # 4. Sequential masked search for missing faces
    if len(labeled) < n_faces:
        if verbose:
            print(f"Phase 4: Masked search (have {len(labeled)}, need {n_faces})...")
        labeled = _search_missing(gray, enhanced, labeled, n_faces, verbose)

    # 5. Subpixel refinement
    if verbose: print(f"Phase 5: Refinement...")
    legacy_refined = _refine(
        gray, labeled, verbose, enable_local_bbox=small_target_band)
    result = _normalize_face_axis_order(legacy_refined)

    if verbose:
        print(f"Result: {len(result)} faces: {[r[2] for r in result]}")

    if weak_cube_first is not None:
        if len(result) >= n_faces:
            merged = _merge_larger_overlapping_detections(
                weak_cube_first, legacy_refined)
            result_overlaps = _detections_have_excessive_overlap(result)
            merged_overlaps = _detections_have_excessive_overlap(merged)
            weak_overlaps = _detections_have_excessive_overlap(weak_cube_first)
            if (result_overlaps and not weak_overlaps
                    and (merged_overlaps
                         or _total_corner_count(merged)
                         <= _total_corner_count(weak_cube_first))):
                if verbose:
                    print("  Using sparse cube-first result; legacy search "
                          "returned overlapping duplicate faces")
                    print(f"Phase 5: Refinement...")
                labeled_weak = _detections_to_labeled(weak_cube_first)
                result = _refine(
                    gray, labeled_weak, verbose=False,
                    enable_local_bbox=small_target_band)
                result = _normalize_face_axis_order(result)
                if verbose:
                    print(f"Result: {len(result)} faces: {[r[2] for r in result]}")
            elif (not merged_overlaps
                  and _total_corner_count(merged)
                  > max(_total_corner_count(weak_cube_first),
                        _total_corner_count(result))
                  ):
                if verbose:
                    print("  Merged sparse cube-first faces with larger "
                          "overlapping grid detections")
                    print(f"Phase 5: Refinement...")
                labeled_merged = _detections_to_labeled(merged)
                result = _refine(
                    gray, labeled_merged, verbose=False,
                    enable_local_bbox=small_target_band)
                if verbose:
                    print(f"Result: {len(result)} faces: {[r[2] for r in result]}")
            elif _total_corner_count(weak_cube_first) > _total_corner_count(result):
                if verbose:
                    print("  Using sparse cube-first result; legacy search "
                          "found fewer usable corners")
                    print(f"Phase 5: Refinement...")
                labeled_weak = _detections_to_labeled(weak_cube_first)
                result = _refine(
                    gray, labeled_weak, verbose=False,
                    enable_local_bbox=small_target_band)
                result = _normalize_face_axis_order(result)
                if verbose:
                    print(f"Result: {len(result)} faces: {[r[2] for r in result]}")
        elif len(weak_cube_first) > len(result):
            merged = _merge_larger_overlapping_detections(
                weak_cube_first, legacy_refined)
            use_merged = (
                len(merged) == len(weak_cube_first)
                and not _detections_have_excessive_overlap(merged)
                and _cube_detection_sparse_face_count(merged) == 0
                and _total_corner_count(merged)
                > _total_corner_count(weak_cube_first)
            )
            if verbose:
                if use_merged:
                    print("  Merging larger legacy grids into sparse "
                          "cube-first result; legacy search missed a cube face")
                else:
                    print("  Using sparse cube-first result; legacy search "
                          "missed a cube face")
                print(f"Phase 5: Refinement...")
            chosen = merged if use_merged else weak_cube_first
            labeled_chosen = _detections_to_labeled(chosen)
            result = _refine(
                gray, labeled_chosen, verbose=False,
                enable_local_bbox=small_target_band)
            result = _normalize_face_axis_order(result)
            if verbose:
                print(f"Result: {len(result)} faces: {[r[2] for r in result]}")

    if (len(cube_first) > len(result)
            and _labels_match_prefix(cube_first)):
        if verbose:
            print("  Using partial cube-first result; it preserves face order")
        result = _refine(gray, [
            {
                'label': label,
                'corners': corners,
                'pat': pat,
                'bbox': _bbox_of_corners(corners),
            }
            for corners, pat, label in cube_first
        ], verbose=False, enable_local_bbox=small_target_band)
        if verbose:
            print(f"Result: {len(result)} faces: {[r[2] for r in result]}")

    if (
        small_target_band
        and len(result) >= n_faces
        and (
            not _small_target_region_patterns_exact(result[:n_faces])
            or _total_corner_count(result[:n_faces]) < MIN_VALIDATED_SMALL_TARGET_CORNERS
            or _cube_detection_sparse_face_count(result[:n_faces]) > 0
        )
    ):
        fusion = _small_target_crop_upscale_fusion_recovery(
            gray, result[:n_faces], n_faces=n_faces, verbose=verbose,
            crop_baseline=upscaled_cube_first if upscaled_cube_first else None)
        if fusion:
            result = fusion
            if verbose:
                print(
                    "Result: crop-fused small-target faces "
                    f"{[r[2] for r in result]}"
                )

    return result


# ─────────────────── Save ───────────────────────────────────────────────────

def save_gt_npz(faces, path):
    corners_list = [c.reshape(-1, 2).astype(np.float64) for c, _, _ in faces]
    np.savez(path, corners=np.array(corners_list, dtype=object))


# ─────────────────── CLI ────────────────────────────────────────────────────

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('image'); ap.add_argument('--faces', type=int, default=3)
    ap.add_argument('--output', '-o'); ap.add_argument('--draw')
    args = ap.parse_args()

    if not os.path.exists(args.image):
        print(f"ERROR: {args.image} not found"); sys.exit(1)

    with open(args.image, 'rb') as f:
        img = cv2.imdecode(np.frombuffer(f.read(), np.uint8), cv2.IMREAD_COLOR)
    if img is None: print("ERROR: cannot decode"); sys.exit(1)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = detect_corner_cube_faces(gray, n_faces=args.faces, verbose=True)

    if not faces: print("No faces detected"); sys.exit(1)

    for i, (c, p, l) in enumerate(faces):
        c2 = c.reshape(-1,2)
        print(f"Face {i}: {l} {p[0]}x{p[1]} "
              f"[{c2[:,0].min():.0f},{c2[:,1].min():.0f}]-"
              f"[{c2[:,0].max():.0f},{c2[:,1].max():.0f}] n={len(c2)}")

    if args.output:
        save_gt_npz(faces, args.output)
        print(f"Saved to {args.output}")

    if args.draw:
        colors = {'XY': (0,255,0), 'XZ': (255,0,0), 'YZ': (0,0,255)}
        out = img.copy()
        for c, p, l in faces:
            for pt in c.reshape(-1,2):
                cv2.circle(out, (int(pt[0]), int(pt[1])), 3, colors.get(l,(255,255,255)), -1)
            cx, cy = int(c.reshape(-1,2)[:,0].mean()), int(c.reshape(-1,2)[:,1].mean())
            cv2.putText(out, f"{l} {p[0]}x{p[1]}", (cx-30, cy-10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, colors.get(l,(255,255,255)), 2)
        cv2.imwrite(args.draw, out)
        print(f"Debug: {args.draw}")
