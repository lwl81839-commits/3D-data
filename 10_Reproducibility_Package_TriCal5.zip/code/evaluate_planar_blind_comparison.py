#!/usr/bin/env python3
"""Compare frozen few-shot cube and Zhang camera models on planar blind images.

The planar blind images are not used to fit either camera model in this script.
For every detected 9x6 checkerboard, identical repeated corner holdouts are used
for both models.  Pose is fitted from the retained corners; held-out corners are
used only for prediction metrics.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from statistics import median
from typing import Any

import cv2
import numpy as np


ROOT = Path(__file__).resolve().parent
GROUPS = ("20_0.870", "30_0.550", "45_0.870")
MODEL_PATHS = {
    "20_0.870": ROOT / "image/development_20_0.870/trained_camera_model_20_0.870.json",
    "30_0.550": ROOT / "image/development_30_0.550/trained_camera_model.json",
    "45_0.870": ROOT / "image/development_45_0.870/trained_camera_model_45_0.870.json",
}

# Converted from the latest dataset_split/zhang.docx.  MATLAB displays the
# intrinsic matrix transposed relative to OpenCV, so cx/cy move to column 3.
ZHANG = {
    "20_0.870": {
        "K": [[1730.5, 0.0, 856.2], [0.0, 1735.5, 536.7], [0.0, 0.0, 1.0]],
        "dist": [-0.3562, 0.1574, 0.0, 0.0, 0.0],
    },
    "30_0.550": {
        "K": [[1624.2, 0.0, 944.8], [0.0, 1632.6, 509.3], [0.0, 0.0, 1.0]],
        "dist": [-0.3755, 0.2097, 0.0, 0.0, 0.0],
    },
    "45_0.870": {
        "K": [[1627.9, 0.0, 962.0], [0.0, 1629.5, 507.1], [0.0, 0.0, 1.0]],
        "dist": [-0.3829, 0.1860, 0.0, 0.0, 0.0],
    },
}

PATTERN = (9, 6)
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def read_image(path: Path) -> np.ndarray:
    data = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError(f"Cannot decode image: {path}")
    return image


def detect_checker(path: Path) -> tuple[np.ndarray | None, str]:
    image = read_image(path)
    gray0 = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray0)
    variants = (("gray", gray0), ("clahe", clahe))
    sb_flags = cv2.CALIB_CB_NORMALIZE_IMAGE | cv2.CALIB_CB_EXHAUSTIVE | cv2.CALIB_CB_ACCURACY
    classic_flags = cv2.CALIB_CB_ADAPTIVE_THRESH | cv2.CALIB_CB_NORMALIZE_IMAGE | cv2.CALIB_CB_FILTER_QUADS
    for scale in (1.0, 1.5, 0.75):
        for label, source in variants:
            work = source if scale == 1.0 else cv2.resize(
                source, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC
            )
            if hasattr(cv2, "findChessboardCornersSB"):
                ok, corners = cv2.findChessboardCornersSB(work, PATTERN, flags=sb_flags)
                if ok and corners is not None and len(corners) == PATTERN[0] * PATTERN[1]:
                    return corners.reshape(-1, 2).astype(np.float64) / scale, f"sb:{label}:x{scale:g}"
            ok, corners = cv2.findChessboardCorners(work, PATTERN, flags=classic_flags)
            if ok and corners is not None and len(corners) == PATTERN[0] * PATTERN[1]:
                corners = cv2.cornerSubPix(
                    work, corners, (7, 7), (-1, -1),
                    (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_MAX_ITER, 50, 1e-4),
                )
                return corners.reshape(-1, 2).astype(np.float64) / scale, f"classic:{label}:x{scale:g}"
    return None, "full_9x6_not_detected"


def object_points(square_mm: float) -> np.ndarray:
    points = np.zeros((PATTERN[0] * PATTERN[1], 3), np.float64)
    points[:, :2] = np.mgrid[0:PATTERN[0], 0:PATTERN[1]].T.reshape(-1, 2)
    points[:, :2] *= float(square_mm)
    return points


def solve_pose(
    obj: np.ndarray, img: np.ndarray, indices: np.ndarray,
    K: np.ndarray, dist: np.ndarray,
) -> tuple[np.ndarray, np.ndarray] | None:
    obj_use = np.ascontiguousarray(obj[indices], np.float64)
    img_use = np.ascontiguousarray(img[indices], np.float64)
    candidates: list[tuple[float, np.ndarray, np.ndarray]] = []
    for flag in (cv2.SOLVEPNP_IPPE, cv2.SOLVEPNP_ITERATIVE):
        try:
            ok, rvec, tvec = cv2.solvePnP(obj_use, img_use, K, dist, flags=flag)
        except cv2.error:
            continue
        if not ok:
            continue
        try:
            rvec, tvec = cv2.solvePnPRefineLM(obj_use, img_use, K, dist, rvec, tvec)
        except cv2.error:
            pass
        projected, _ = cv2.projectPoints(obj_use, rvec, tvec, K, dist)
        error = projected.reshape(-1, 2) - img_use
        rmse = float(np.sqrt(np.mean(np.sum(error * error, axis=1))))
        R, _ = cv2.Rodrigues(rvec)
        depth = (R @ obj_use.T + tvec.reshape(3, 1))[2]
        if np.mean(depth > 0.0) >= 0.99:
            candidates.append((rmse, rvec.reshape(3, 1), tvec.reshape(3, 1)))
    if not candidates:
        return None
    _, rvec, tvec = min(candidates, key=lambda item: item[0])
    return rvec, tvec


def project_errors(
    obj: np.ndarray, img: np.ndarray, indices: np.ndarray,
    pose: tuple[np.ndarray, np.ndarray], K: np.ndarray, dist: np.ndarray,
) -> np.ndarray:
    projected, _ = cv2.projectPoints(obj[indices], pose[0], pose[1], K, dist)
    delta = projected.reshape(-1, 2) - img[indices]
    return np.linalg.norm(delta, axis=1)


def backproject_object_errors(
    obj: np.ndarray, img: np.ndarray, indices: np.ndarray,
    pose: tuple[np.ndarray, np.ndarray], K: np.ndarray, dist: np.ndarray,
) -> np.ndarray:
    rvec, tvec = pose
    R, _ = cv2.Rodrigues(rvec)
    rays = cv2.undistortPoints(img[indices].reshape(-1, 1, 2), K, dist).reshape(-1, 2)
    rays3 = np.column_stack([rays, np.ones(len(rays))])
    normal = R[:, 2]
    numerator = float(normal @ tvec.reshape(3))
    denominator = rays3 @ normal
    valid = np.abs(denominator) > 1e-9
    camera_points = rays3[valid] * (numerator / denominator[valid])[:, None]
    world_points = (R.T @ (camera_points - tvec.reshape(1, 3)).T).T
    return np.linalg.norm(world_points[:, :2] - obj[indices][valid, :2], axis=1)


def line_rms(img: np.ndarray, K: np.ndarray, dist: np.ndarray) -> float:
    und = cv2.undistortPoints(img.reshape(-1, 1, 2), K, dist, P=K).reshape(PATTERN[1], PATTERN[0], 2)
    residuals: list[float] = []
    lines = [und[r, :, :] for r in range(PATTERN[1])]
    lines += [und[:, c, :] for c in range(PATTERN[0])]
    for points in lines:
        center = points.mean(axis=0)
        _, _, vh = np.linalg.svd(points - center, full_matrices=False)
        distances = np.abs((points - center) @ vh[-1])
        residuals.extend(distances.tolist())
    return float(np.sqrt(np.mean(np.square(residuals))))


def basic_stats(values: list[float]) -> dict[str, Any]:
    finite = sorted(float(v) for v in values if math.isfinite(float(v)))
    if not finite:
        return {"n": 0, "mean": None, "median": None, "p95": None, "max": None}
    return {
        "n": len(finite),
        "mean": float(np.mean(finite)),
        "median": float(np.median(finite)),
        "p95": float(np.percentile(finite, 95)),
        "max": float(max(finite)),
    }


def exact_sign_p(wins: int, losses: int) -> float | None:
    n = wins + losses
    if n == 0:
        return None
    tail = sum(math.comb(n, k) for k in range(0, min(wins, losses) + 1)) / (2 ** n)
    return float(min(1.0, 2.0 * tail))


def finite_json(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): finite_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [finite_json(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        v = float(value)
        return v if math.isfinite(v) else None
    return value


def fmt(value: Any, digits: int = 3) -> str:
    try:
        value = float(value)
    except (TypeError, ValueError):
        return "-"
    return f"{value:.{digits}f}" if math.isfinite(value) else "-"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--split-root", type=Path, default=ROOT / "image/zhang/dataset_split")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "image/zhang/planar_blind_comparison")
    parser.add_argument("--square-mm", type=float, default=25.0)
    parser.add_argument("--repeats", type=int, default=50)
    parser.add_argument("--holdout-fraction", type=float, default=0.20)
    parser.add_argument("--seed", type=int, default=20260810)
    args = parser.parse_args()
    split_root = args.split_root.resolve()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    obj = object_points(args.square_mm)
    image_rows: list[dict[str, Any]] = []
    trial_rows: list[dict[str, Any]] = []
    parameter_rows: list[dict[str, Any]] = []

    for group_index, group in enumerate(GROUPS):
        model = json.loads(MODEL_PATHS[group].read_text(encoding="utf-8"))
        if not model.get("accepted", False):
            raise RuntimeError(f"Few-shot model is not accepted: {MODEL_PATHS[group]}")
        models = {
            "ours": (
                np.asarray(model["cameraMatrix"], np.float64).reshape(3, 3),
                np.asarray(model["distCoeffs"], np.float64).reshape(5),
            ),
            "zhang": (
                np.asarray(ZHANG[group]["K"], np.float64).reshape(3, 3),
                np.asarray(ZHANG[group]["dist"], np.float64).reshape(5),
            ),
        }
        for name, (K, dist) in models.items():
            parameter_rows.append({
                "group": group, "model": name,
                "fx": K[0, 0], "fy": K[1, 1], "cx": K[0, 2], "cy": K[1, 2],
                "k1": dist[0], "k2": dist[1],
            })
        images = sorted(
            path for path in (split_root / group / "blind_test").iterdir()
            if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES
        )
        for image_index, path in enumerate(images):
            print(f"[{group} {image_index + 1}/{len(images)}] {path.name}", flush=True)
            corners, detector = detect_checker(path)
            if corners is None:
                image_rows.append({
                    "group": group, "image": path.name, "detected": False,
                    "detector": detector, "model": None,
                })
                print("  full 9x6 not detected", flush=True)
                continue
            rng = np.random.default_rng(args.seed + group_index * 10000 + image_index)
            holdout_count = max(8, int(round(len(obj) * args.holdout_fraction)))
            splits = []
            for _ in range(args.repeats):
                held = np.sort(rng.choice(len(obj), size=holdout_count, replace=False))
                train = np.setdiff1d(np.arange(len(obj)), held)
                splits.append((train, held))
            for name, (K, dist) in models.items():
                full_indices = np.arange(len(obj))
                full_pose = solve_pose(obj, corners, full_indices, K, dist)
                if full_pose is None:
                    image_rows.append({
                        "group": group, "image": path.name, "detected": True,
                        "detector": detector, "model": name, "pose_success": False,
                    })
                    continue
                full_error = project_errors(obj, corners, full_indices, full_pose, K, dist)
                holdout_rmse: list[float] = []
                holdout_object_rmse: list[float] = []
                successful = 0
                for repeat, (train, held) in enumerate(splits):
                    pose = solve_pose(obj, corners, train, K, dist)
                    if pose is None:
                        trial_rows.append({
                            "group": group, "image": path.name, "model": name,
                            "repeat": repeat, "success": False,
                        })
                        continue
                    px = project_errors(obj, corners, held, pose, K, dist)
                    mm = backproject_object_errors(obj, corners, held, pose, K, dist)
                    px_rmse = float(np.sqrt(np.mean(px * px)))
                    mm_rmse = float(np.sqrt(np.mean(mm * mm)))
                    holdout_rmse.append(px_rmse)
                    holdout_object_rmse.append(mm_rmse)
                    successful += 1
                    trial_rows.append({
                        "group": group, "image": path.name, "model": name,
                        "repeat": repeat, "success": True,
                        "holdout_rmse_px": px_rmse,
                        "holdout_object_rmse_mm": mm_rmse,
                    })
                image_rows.append({
                    "group": group, "image": path.name, "detected": True,
                    "detector": detector, "model": name, "pose_success": True,
                    "full_reprojection_rmse_px": float(np.sqrt(np.mean(full_error * full_error))),
                    "holdout_rmse_px": float(median(holdout_rmse)) if holdout_rmse else None,
                    "holdout_object_rmse_mm": float(median(holdout_object_rmse)) if holdout_object_rmse else None,
                    "undistorted_line_rms_px": line_rms(corners, K, dist),
                    "successful_repeats": successful,
                    "requested_repeats": args.repeats,
                })
                print(
                    f"  {name}: holdout={fmt(image_rows[-1]['holdout_rmse_px'])} px, "
                    f"object={fmt(image_rows[-1]['holdout_object_rmse_mm'])} mm, "
                    f"line={fmt(image_rows[-1]['undistorted_line_rms_px'])} px",
                    flush=True,
                )

    summaries: list[dict[str, Any]] = []
    comparisons: list[dict[str, Any]] = []
    for group in GROUPS:
        total = len({row["image"] for row in image_rows if row["group"] == group})
        detected = len({
            row["image"] for row in image_rows
            if row["group"] == group and row.get("detected")
        })
        for model_name in ("ours", "zhang"):
            rows = [
                row for row in image_rows
                if row["group"] == group and row.get("model") == model_name
                and row.get("pose_success")
            ]
            summaries.append({
                "group": group, "model": model_name,
                "blind_images": total, "full_checker_detected": detected,
                "evaluated_images": len(rows),
                "holdout_rmse_px": basic_stats([row["holdout_rmse_px"] for row in rows]),
                "holdout_object_rmse_mm": basic_stats([row["holdout_object_rmse_mm"] for row in rows]),
                "undistorted_line_rms_px": basic_stats([row["undistorted_line_rms_px"] for row in rows]),
                "full_reprojection_rmse_px": basic_stats([row["full_reprojection_rmse_px"] for row in rows]),
            })
        ours_by_image = {
            row["image"]: row for row in image_rows
            if row["group"] == group and row.get("model") == "ours" and row.get("pose_success")
        }
        zhang_by_image = {
            row["image"]: row for row in image_rows
            if row["group"] == group and row.get("model") == "zhang" and row.get("pose_success")
        }
        common = sorted(set(ours_by_image) & set(zhang_by_image))
        for metric in ("holdout_rmse_px", "holdout_object_rmse_mm", "undistorted_line_rms_px"):
            deltas = [ours_by_image[name][metric] - zhang_by_image[name][metric] for name in common]
            wins = sum(delta < 0 for delta in deltas)
            losses = sum(delta > 0 for delta in deltas)
            comparisons.append({
                "group": group, "metric": metric, "paired_images": len(common),
                "ours_wins": wins, "zhang_wins": losses,
                "ties": len(deltas) - wins - losses,
                "median_ours_minus_zhang": float(np.median(deltas)) if deltas else None,
                "exact_sign_p": exact_sign_p(wins, losses),
            })

    total_all = len({(row["group"], row["image"]) for row in image_rows})
    detected_all = len({
        (row["group"], row["image"]) for row in image_rows if row.get("detected")
    })
    for model_name in ("ours", "zhang"):
        rows = [
            row for row in image_rows
            if row.get("model") == model_name and row.get("pose_success")
        ]
        summaries.append({
            "group": "ALL", "model": model_name,
            "blind_images": total_all, "full_checker_detected": detected_all,
            "evaluated_images": len(rows),
            "holdout_rmse_px": basic_stats([row["holdout_rmse_px"] for row in rows]),
            "holdout_object_rmse_mm": basic_stats([row["holdout_object_rmse_mm"] for row in rows]),
            "undistorted_line_rms_px": basic_stats([row["undistorted_line_rms_px"] for row in rows]),
            "full_reprojection_rmse_px": basic_stats([row["full_reprojection_rmse_px"] for row in rows]),
        })
    ours_all = {
        (row["group"], row["image"]): row for row in image_rows
        if row.get("model") == "ours" and row.get("pose_success")
    }
    zhang_all = {
        (row["group"], row["image"]): row for row in image_rows
        if row.get("model") == "zhang" and row.get("pose_success")
    }
    common_all = sorted(set(ours_all) & set(zhang_all))
    for metric in ("holdout_rmse_px", "holdout_object_rmse_mm", "undistorted_line_rms_px"):
        deltas = [ours_all[key][metric] - zhang_all[key][metric] for key in common_all]
        wins = sum(delta < 0 for delta in deltas)
        losses = sum(delta > 0 for delta in deltas)
        comparisons.append({
            "group": "ALL", "metric": metric, "paired_images": len(common_all),
            "ours_wins": wins, "zhang_wins": losses,
            "ties": len(deltas) - wins - losses,
            "median_ours_minus_zhang": float(np.median(deltas)) if deltas else None,
            "exact_sign_p": exact_sign_p(wins, losses),
        })

    payload = finite_json({
        "schema": "planar-blind-frozen-camera-comparison/v1",
        "split_root": str(split_root),
        "pattern_inner_corners": list(PATTERN),
        "square_mm": args.square_mm,
        "repeats": args.repeats,
        "holdout_fraction": args.holdout_fraction,
        "zhang_parameter_source": str(split_root / "zhang.docx"),
        "few_shot_model_paths": {k: str(v.resolve()) for k, v in MODEL_PATHS.items()},
        "summaries": summaries,
        "comparisons": comparisons,
        "parameters": parameter_rows,
        "images": image_rows,
        "trials": trial_rows,
    })
    (output / "planar_blind_comparison.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    for filename, rows in (
        ("image_metrics.csv", image_rows),
        ("holdout_trials.csv", trial_rows),
        ("camera_parameters.csv", parameter_rows),
    ):
        keys = list(dict.fromkeys(key for row in rows for key in row))
        with (output / filename).open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=keys)
            writer.writeheader()
            writer.writerows(rows)

    lines = [
        "# 二维棋盘格独立盲测：本方法与张正友参数",
        "",
        "两套相机参数均已冻结。每次仅用80%角点求当前平面姿态，剩余20%角点只用于预测评价。",
        "",
        "## 汇总",
        "",
        "| 姿态 | 模型 | 验证图 | 完整9×6检测 | 留出RMSE中位(px) | 平面点RMSE中位(mm) | 去畸变直线RMS中位(px) |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for item in summaries:
        lines.append(
            f"| {item['group']} | {item['model']} | {item['blind_images']} | "
            f"{item['full_checker_detected']} | {fmt(item['holdout_rmse_px']['median'])} | "
            f"{fmt(item['holdout_object_rmse_mm']['median'])} | "
            f"{fmt(item['undistorted_line_rms_px']['median'])} |"
        )
    lines += [
        "", "## 配对比较", "",
        "负的‘本方法-张正友’表示本方法误差更小。", "",
        "| 姿态 | 指标 | 配对图 | 本方法胜 | 张正友胜 | 差值中位 | 符号检验p |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for item in comparisons:
        lines.append(
            f"| {item['group']} | {item['metric']} | {item['paired_images']} | "
            f"{item['ours_wins']} | {item['zhang_wins']} | "
            f"{fmt(item['median_ours_minus_zhang'])} | {fmt(item['exact_sign_p'])} |"
        )
    undetected = [row for row in image_rows if not row.get("detected")]
    lines += ["", "## 未检测到完整9×6棋盘格", ""]
    if undetected:
        lines.extend(f"- `{row['group']}/{row['image']}`" for row in undetected)
    else:
        lines.append("- 无")
    lines += [
        "", "## 解释边界", "",
        "- 留出角点不参与姿态求解，因此比全点重投影误差更适合作为主指标。",
        "- 平面点毫米误差仍使用25 mm格距确定尺度，属于跨图片的目标内验证，不是独立实物尺寸真值。",
        "- 棋盘格检测由两套模型共享；检测失败不归因于任意一套相机参数。",
        "- Zhang参数来自训练子集；blind_test图片未参与本脚本中的任何参数拟合。",
    ]
    (output / "PLANAR_BLIND_COMPARISON.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Report: {output / 'PLANAR_BLIND_COMPARISON.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
