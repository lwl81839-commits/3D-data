#!/usr/bin/env python3
"""Spatial understanding for a single visible three-face cube target.

This module does not detect chessboards and does not calibrate the camera.  It
takes three checkerboard corner grids that have already been detected, then
interprets them as the three mutually adjacent faces of the cube:

    XY, XZ, YZ

The output is a structured topology: stable face order, row/column axis
orientation, per-face quads, shared-axis vanishing-point consistency, and
explicit rejection reasons.  Downstream calibration should consume this result
instead of re-deriving spatial labels inside the optimizer.
"""

from __future__ import annotations

import itertools
import json
import math
from dataclasses import dataclass, field
from typing import Any, Iterable, Sequence

import cv2
import numpy as np

from three_face_calib import (
    estimate_vanishing_point,
    lines_from_chessboard_corners,
)


FACE_LABELS = ("XY", "XZ", "YZ")
AXES_FOR_LABEL = {
    "XY": ("X", "Y"),
    "XZ": ("X", "Z"),
    "YZ": ("Y", "Z"),
}
AXIS_LABELS = ("X", "Y", "Z")


@dataclass
class FaceObservation:
    """One detected checkerboard face before spatial labeling."""

    corners: np.ndarray
    pattern_size: tuple[int, int]
    source_label: str = ""
    source_index: int = 0


@dataclass
class FaceSpatialSummary:
    """Spatial interpretation of one detected face."""

    observation_index: int
    assigned_label: str
    source_label: str
    pattern_size: tuple[int, int]
    transpose_required: bool
    center_px: list[float]
    bbox_px: list[float]
    inner_quad_px: list[list[float]]
    checker_outer_quad_px: list[list[float]]
    row_direction: list[float]
    col_direction: list[float]
    row_quality_px: float
    col_quality_px: float
    homography_rmse_px: float
    axis_for_rows: str
    axis_for_cols: str
    diagnostics: dict[str, Any] = field(default_factory=dict)


@dataclass
class AxisSpatialSummary:
    """Consistency of one physical cube axis shared by two faces."""

    axis_label: str
    face_labels: list[str]
    line_count: int
    vanishing_point: list[float]
    finite: bool
    incidence_rmse_px: float
    direction_cosine: float


@dataclass
class CubeSpatialUnderstandingResult:
    """Full spatial understanding result for a three-face cube image."""

    success: bool
    status: str
    message: str
    faces: list[FaceSpatialSummary]
    axes: list[AxisSpatialSummary]
    ordered_observation_indices: list[int]
    diagnostics: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": bool(self.success),
            "status": self.status,
            "message": self.message,
            "ordered_observation_indices": [
                int(value) for value in self.ordered_observation_indices
            ],
            "faces": [
                {
                    "observation_index": face.observation_index,
                    "assigned_label": face.assigned_label,
                    "source_label": face.source_label,
                    "pattern_size": list(face.pattern_size),
                    "transpose_required": bool(face.transpose_required),
                    "center_px": face.center_px,
                    "bbox_px": face.bbox_px,
                    "inner_quad_px": face.inner_quad_px,
                    "checker_outer_quad_px": face.checker_outer_quad_px,
                    "row_direction": face.row_direction,
                    "col_direction": face.col_direction,
                    "row_quality_px": face.row_quality_px,
                    "col_quality_px": face.col_quality_px,
                    "homography_rmse_px": face.homography_rmse_px,
                    "axis_for_rows": face.axis_for_rows,
                    "axis_for_cols": face.axis_for_cols,
                    "diagnostics": face.diagnostics,
                }
                for face in self.faces
            ],
            "axes": [
                {
                    "axis_label": axis.axis_label,
                    "face_labels": axis.face_labels,
                    "line_count": axis.line_count,
                    "vanishing_point": axis.vanishing_point,
                    "finite": bool(axis.finite),
                    "incidence_rmse_px": axis.incidence_rmse_px,
                    "direction_cosine": axis.direction_cosine,
                }
                for axis in self.axes
            ],
            "diagnostics": self.diagnostics,
        }

    def to_json(self, **kwargs: Any) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, **kwargs)


@dataclass
class _FaceGeometry:
    observation: FaceObservation
    corners: np.ndarray
    row_lines: list[np.ndarray]
    col_lines: list[np.ndarray]
    row_dir: np.ndarray
    col_dir: np.ndarray
    row_quality: float
    col_quality: float
    center: np.ndarray
    bbox: np.ndarray
    H_grid_to_image: np.ndarray | None
    homography_rmse: float


def make_observation(
    corners: np.ndarray,
    pattern_size: tuple[int, int],
    source_label: str = "",
    source_index: int = 0,
) -> FaceObservation:
    return FaceObservation(
        corners=np.asarray(corners, dtype=np.float32).reshape(-1, 1, 2),
        pattern_size=(int(pattern_size[0]), int(pattern_size[1])),
        source_label=str(source_label or ""),
        source_index=int(source_index),
    )


def _normalize_direction(vec: np.ndarray) -> np.ndarray:
    arr = np.asarray(vec, dtype=np.float64).reshape(2)
    norm = float(np.linalg.norm(arr))
    if not np.isfinite(norm) or norm < 1e-12:
        return np.array([1.0, 0.0], dtype=np.float64)
    arr = arr / norm
    # Use an undirected convention for deterministic serialization.
    if arr[0] < 0.0 or (abs(arr[0]) < 1e-12 and arr[1] < 0.0):
        arr = -arr
    return arr


def _line_direction(line: np.ndarray) -> np.ndarray:
    line = np.asarray(line, dtype=np.float64).reshape(3)
    return _normalize_direction(np.array([-line[1], line[0]], dtype=np.float64))


def _undirected_cos(a: np.ndarray, b: np.ndarray) -> float:
    aa = _normalize_direction(a)
    bb = _normalize_direction(b)
    return float(abs(aa @ bb))


def _undirected_mean(directions: Iterable[np.ndarray]) -> np.ndarray:
    """Mean of unoriented 2-D directions using the double-angle trick."""
    values = []
    for direction in directions:
        d = _normalize_direction(direction)
        angle = math.atan2(float(d[1]), float(d[0]))
        values.append([math.cos(2.0 * angle), math.sin(2.0 * angle)])
    if not values:
        return np.array([1.0, 0.0], dtype=np.float64)
    mean = np.mean(np.asarray(values, dtype=np.float64), axis=0)
    if float(np.linalg.norm(mean)) < 1e-12:
        return np.array([1.0, 0.0], dtype=np.float64)
    angle = 0.5 * math.atan2(float(mean[1]), float(mean[0]))
    return _normalize_direction(np.array([math.cos(angle), math.sin(angle)]))


def _grid_points(pattern_size: tuple[int, int]) -> np.ndarray:
    cols, rows = pattern_size
    return np.asarray(
        [[float(col), float(row)] for row in range(rows) for col in range(cols)],
        dtype=np.float32,
    )


def _project_grid_points(H: np.ndarray | None, points: np.ndarray) -> list[list[float]]:
    if H is None:
        return []
    projected = cv2.perspectiveTransform(
        np.asarray(points, dtype=np.float32).reshape(-1, 1, 2),
        np.asarray(H, dtype=np.float64),
    ).reshape(-1, 2)
    return [[float(x), float(y)] for x, y in projected]


def _homography_grid_to_image(
    corners: np.ndarray,
    pattern_size: tuple[int, int],
) -> tuple[np.ndarray | None, float]:
    points = np.asarray(corners, dtype=np.float32).reshape(-1, 2)
    grid = _grid_points(pattern_size)
    if len(points) != len(grid) or len(points) < 4:
        return None, float("inf")
    try:
        H, _mask = cv2.findHomography(grid, points, method=0)
    except cv2.error:
        H = None
    if H is None or not np.all(np.isfinite(H)):
        return None, float("inf")
    projected = cv2.perspectiveTransform(grid.reshape(-1, 1, 2), H).reshape(-1, 2)
    errors = np.linalg.norm(projected - points, axis=1)
    return H.astype(np.float64), float(np.sqrt(np.mean(errors * errors)))


def _compute_face_geometry(observation: FaceObservation) -> _FaceGeometry:
    corners = np.asarray(observation.corners, dtype=np.float32).reshape(-1, 1, 2)
    cols, rows = observation.pattern_size
    expected = int(cols * rows)
    if len(corners) != expected:
        raise ValueError(
            f"face {observation.source_index} expected {expected} corners "
            f"for {cols}x{rows}, got {len(corners)}"
        )
    row_lines, col_lines, row_quality, col_quality = lines_from_chessboard_corners(
        corners, observation.pattern_size, use_ransac=True,
    )
    row_dir = _undirected_mean(_line_direction(line) for line in row_lines)
    col_dir = _undirected_mean(_line_direction(line) for line in col_lines)
    pts = corners.reshape(-1, 2).astype(np.float64)
    bbox = np.array([
        float(np.min(pts[:, 0])),
        float(np.min(pts[:, 1])),
        float(np.max(pts[:, 0])),
        float(np.max(pts[:, 1])),
    ])
    H, h_rmse = _homography_grid_to_image(corners, observation.pattern_size)
    return _FaceGeometry(
        observation=observation,
        corners=corners,
        row_lines=[np.asarray(line, dtype=np.float64) for line in row_lines],
        col_lines=[np.asarray(line, dtype=np.float64) for line in col_lines],
        row_dir=row_dir,
        col_dir=col_dir,
        row_quality=float(row_quality),
        col_quality=float(col_quality),
        center=np.mean(pts, axis=0),
        bbox=bbox,
        H_grid_to_image=H,
        homography_rmse=h_rmse,
    )


def _assignment_axis_data(
    faces: Sequence[_FaceGeometry],
    labels: Sequence[str],
    swaps: Sequence[bool],
) -> dict[str, dict[str, Any]]:
    by_axis: dict[str, dict[str, Any]] = {
        axis: {"lines": [], "dirs": [], "face_labels": []}
        for axis in AXIS_LABELS
    }
    for face, label, swap in zip(faces, labels, swaps):
        axes = AXES_FOR_LABEL[label]
        if not swap:
            row_axis, col_axis = axes[0], axes[1]
        else:
            row_axis, col_axis = axes[1], axes[0]
        by_axis[row_axis]["lines"].extend(face.row_lines)
        by_axis[row_axis]["dirs"].append(face.row_dir)
        by_axis[row_axis]["face_labels"].append(label)
        by_axis[col_axis]["lines"].extend(face.col_lines)
        by_axis[col_axis]["dirs"].append(face.col_dir)
        by_axis[col_axis]["face_labels"].append(label)
    return by_axis


def _axis_summary(axis: str, payload: dict[str, Any]) -> AxisSpatialSummary:
    lines = np.asarray(payload["lines"], dtype=np.float64).reshape(-1, 3)
    if len(lines) >= 2:
        vp = estimate_vanishing_point(lines)
        if vp.is_finite:
            residuals = np.abs(lines @ vp.v.reshape(3))
            rms = float(np.sqrt(np.mean(residuals * residuals)))
        else:
            directions = [_line_direction(line) for line in lines]
            mean = _undirected_mean(directions)
            angles = [
                math.acos(float(np.clip(_undirected_cos(direction, mean), -1.0, 1.0)))
                for direction in directions
            ]
            rms = float(np.sqrt(np.mean(np.asarray(angles) ** 2)))
        vanishing = [float(v) for v in vp.v.reshape(3)]
        finite = bool(vp.is_finite)
    else:
        vanishing = [float("nan"), float("nan"), float("nan")]
        finite = False
        rms = float("inf")

    dirs = payload.get("dirs", [])
    if len(dirs) >= 2:
        cosine = _undirected_cos(dirs[0], dirs[1])
    else:
        cosine = 0.0
    return AxisSpatialSummary(
        axis_label=axis,
        face_labels=sorted(set(str(value) for value in payload["face_labels"])),
        line_count=int(len(lines)),
        vanishing_point=vanishing,
        finite=finite,
        incidence_rmse_px=rms,
        direction_cosine=float(cosine),
    )


def _spatial_bias_score(
    faces: Sequence[_FaceGeometry],
    labels: Sequence[str],
    image_size: tuple[int, int] | None,
) -> tuple[float, dict[str, Any]]:
    centers = {label: face.center for face, label in zip(faces, labels)}
    y_values = np.asarray([face.center[1] for face in faces], dtype=np.float64)
    x_values = np.asarray([face.center[0] for face in faces], dtype=np.float64)
    height_scale = (
        float(image_size[1]) if image_size is not None else float(np.ptp(y_values) + 1.0)
    )
    width_scale = (
        float(image_size[0]) if image_size is not None else float(np.ptp(x_values) + 1.0)
    )
    score = 0.0
    diagnostics: dict[str, Any] = {}

    if "XY" in centers:
        xy_y = float(centers["XY"][1])
        best_top = float(np.min(y_values))
        top_delta_frac = abs(xy_y - best_top) / max(height_scale, 1.0)
        score += 0.70 * (1.0 - min(top_delta_frac, 1.0))
        score += 0.60 if top_delta_frac <= 0.035 else -0.60
        diagnostics["xy_top_delta_px"] = xy_y - best_top

    if "XZ" in centers and "YZ" in centers:
        xz_x = float(centers["XZ"][0])
        yz_x = float(centers["YZ"][0])
        separation = (yz_x - xz_x) / max(width_scale, 1.0)
        score += 0.35 if separation > 0.0 else -0.35
        score += 0.15 * float(np.clip(separation * 4.0, -1.0, 1.0))
        diagnostics["xz_left_of_yz_px"] = yz_x - xz_x

    source_matches = [
        1.0
        for face, label in zip(faces, labels)
        if face.observation.source_label in FACE_LABELS
        and face.observation.source_label == label
    ]
    source_labeled = [
        1.0
        for face in faces
        if face.observation.source_label in FACE_LABELS
    ]
    if source_labeled:
        match_fraction = float(sum(source_matches) / len(source_labeled))
        score += 0.40 * match_fraction
        diagnostics["source_label_match_fraction"] = match_fraction

    return score, diagnostics


def _score_assignment(
    faces: Sequence[_FaceGeometry],
    labels: Sequence[str],
    swaps: Sequence[bool],
    image_size: tuple[int, int] | None,
) -> tuple[float, list[AxisSpatialSummary], dict[str, Any]]:
    axis_payload = _assignment_axis_data(faces, labels, swaps)
    axes = [_axis_summary(axis, axis_payload[axis]) for axis in AXIS_LABELS]
    if image_size is None:
        all_points = np.vstack([face.corners.reshape(-1, 2) for face in faces])
        diag = float(np.linalg.norm(np.ptp(all_points, axis=0)))
    else:
        diag = float(math.hypot(float(image_size[0]), float(image_size[1])))
    diag = max(diag, 1.0)

    # The shared-axis VP residual is the main physical score.  Direction cosine
    # is kept as a local tie-breaker for weak perspective/infinite VP cases.
    vp_penalty = sum(min(axis.incidence_rmse_px / (0.030 * diag), 1.0) for axis in axes)
    dir_penalty = sum(
        min((1.0 - axis.direction_cosine) / 0.45, 1.0)
        for axis in axes
    ) / 3.0
    dir_reward = sum(axis.direction_cosine for axis in axes) / 3.0
    quality_penalty = sum(
        min(max(face.row_quality, face.col_quality) / 4.0, 1.5)
        for face in faces
    ) / max(len(faces), 1)
    homography_penalty = sum(
        min(face.homography_rmse / 6.0, 1.5)
        for face in faces
    ) / max(len(faces), 1)
    spatial_score, spatial_diag = _spatial_bias_score(faces, labels, image_size)
    transpose_penalty = 0.015 * sum(1 for value in swaps if value)
    score = (
        -0.30 * vp_penalty
        -1.20 * dir_penalty
        + 0.35 * dir_reward
        - 0.08 * quality_penalty
        - 0.05 * homography_penalty
        + spatial_score
        - transpose_penalty
    )
    diagnostics = {
        "vp_penalty": float(vp_penalty),
        "direction_penalty": float(dir_penalty),
        "direction_reward": float(dir_reward),
        "quality_penalty": float(quality_penalty),
        "homography_penalty": float(homography_penalty),
        "spatial_score": float(spatial_score),
        "transpose_penalty": float(transpose_penalty),
        "spatial": spatial_diag,
    }
    return float(score), axes, diagnostics


def _face_summary(
    face: _FaceGeometry,
    label: str,
    transpose_required: bool,
) -> FaceSpatialSummary:
    axes = AXES_FOR_LABEL[label]
    if not transpose_required:
        row_axis, col_axis = axes[0], axes[1]
    else:
        row_axis, col_axis = axes[1], axes[0]
    cols, rows = face.observation.pattern_size
    inner_quad = np.asarray(
        [[0.0, 0.0], [cols - 1.0, 0.0], [cols - 1.0, rows - 1.0], [0.0, rows - 1.0]],
        dtype=np.float32,
    )
    # A checker with N inner corners has one square margin from the first inner
    # corner to the printed outer edge in the ideal chessboard grid.
    outer_quad = np.asarray(
        [[-1.0, -1.0], [cols, -1.0], [cols, rows], [-1.0, rows]],
        dtype=np.float32,
    )
    return FaceSpatialSummary(
        observation_index=int(face.observation.source_index),
        assigned_label=label,
        source_label=face.observation.source_label,
        pattern_size=face.observation.pattern_size,
        transpose_required=bool(transpose_required),
        center_px=[float(face.center[0]), float(face.center[1])],
        bbox_px=[float(value) for value in face.bbox],
        inner_quad_px=_project_grid_points(face.H_grid_to_image, inner_quad),
        checker_outer_quad_px=_project_grid_points(face.H_grid_to_image, outer_quad),
        row_direction=[float(value) for value in face.row_dir],
        col_direction=[float(value) for value in face.col_dir],
        row_quality_px=float(face.row_quality),
        col_quality_px=float(face.col_quality),
        homography_rmse_px=float(face.homography_rmse),
        axis_for_rows=row_axis,
        axis_for_cols=col_axis,
        diagnostics={
            "line_quality_max_px": float(max(face.row_quality, face.col_quality)),
        },
    )


def understand_cube_faces(
    observations: Sequence[FaceObservation | tuple[np.ndarray, tuple[int, int]]],
    image_size: tuple[int, int] | None = None,
    min_axis_direction_cosine: float = 0.30,
    max_axis_incidence_frac: float = 0.045,
    max_line_quality_px: float = 8.0,
    max_homography_rmse_px: float = 8.0,
) -> CubeSpatialUnderstandingResult:
    """Infer the three-face cube topology from detected checker grids.

    Parameters
    ----------
    observations:
        Three detected faces.  Each item may be a :class:`FaceObservation` or a
        ``(corners, pattern_size)`` tuple.
    image_size:
        Optional ``(width, height)`` used to normalize geometric thresholds.
    """
    normalized: list[FaceObservation] = []
    for index, item in enumerate(observations):
        if isinstance(item, FaceObservation):
            obs = item
        else:
            corners, pattern_size = item
            obs = make_observation(corners, pattern_size, source_index=index)
        normalized.append(obs)
    if len({int(obs.source_index) for obs in normalized}) != len(normalized):
        normalized = [
            FaceObservation(
                corners=obs.corners,
                pattern_size=obs.pattern_size,
                source_label=obs.source_label,
                source_index=index,
            )
            for index, obs in enumerate(normalized)
        ]

    if len(normalized) != 3:
        return CubeSpatialUnderstandingResult(
            success=False,
            status="need_exactly_three_faces",
            message=f"Spatial cube understanding requires exactly 3 faces, got {len(normalized)}.",
            faces=[],
            axes=[],
            ordered_observation_indices=[],
            diagnostics={"input_face_count": len(normalized)},
        )

    try:
        face_geometries = [_compute_face_geometry(obs) for obs in normalized]
    except Exception as exc:
        return CubeSpatialUnderstandingResult(
            success=False,
            status="invalid_face_geometry",
            message=str(exc),
            faces=[],
            axes=[],
            ordered_observation_indices=[],
            diagnostics={"input_face_count": len(normalized)},
        )

    best: tuple[float, tuple[str, ...], tuple[bool, ...], list[AxisSpatialSummary], dict[str, Any]] | None = None
    for labels in itertools.permutations(FACE_LABELS, 3):
        for swaps in itertools.product((False, True), repeat=3):
            score, axes, diagnostics = _score_assignment(
                face_geometries, labels, swaps, image_size
            )
            if best is None or score > best[0]:
                best = (score, tuple(labels), tuple(swaps), axes, diagnostics)

    assert best is not None
    score, labels, swaps, axes, score_diag = best
    face_summaries = [
        _face_summary(face, label, swap)
        for face, label, swap in zip(face_geometries, labels, swaps)
    ]
    face_summaries.sort(key=lambda face: FACE_LABELS.index(face.assigned_label))
    ordered_indices = [face.observation_index for face in face_summaries]

    if image_size is None:
        all_points = np.vstack([face.corners.reshape(-1, 2) for face in face_geometries])
        diag = float(np.linalg.norm(np.ptp(all_points, axis=0)))
    else:
        diag = float(math.hypot(float(image_size[0]), float(image_size[1])))
    diag = max(diag, 1.0)

    reasons: list[str] = []
    for axis in axes:
        if axis.direction_cosine < min_axis_direction_cosine:
            reasons.append(f"{axis.axis_label}_axis_direction_mismatch")
        if (
            axis.direction_cosine < 0.80
            and axis.incidence_rmse_px > max_axis_incidence_frac * diag
        ):
            reasons.append(f"{axis.axis_label}_axis_vp_residual_high")
    for face in face_summaries:
        if face.diagnostics["line_quality_max_px"] > max_line_quality_px:
            reasons.append(f"{face.assigned_label}_line_quality_high")
        if face.homography_rmse_px > max_homography_rmse_px:
            reasons.append(f"{face.assigned_label}_homography_rmse_high")

    success = not reasons
    status = "ok" if success else "spatial_gate_failed"
    message = (
        "Three cube faces separated and ordered as XY/XZ/YZ."
        if success
        else "Three faces were ordered, but spatial consistency gates failed."
    )
    return CubeSpatialUnderstandingResult(
        success=success,
        status=status,
        message=message,
        faces=face_summaries,
        axes=axes,
        ordered_observation_indices=ordered_indices,
        diagnostics={
            "score": float(score),
            "selected_labels_by_input": list(labels),
            "selected_transpose_flags_by_input": [bool(value) for value in swaps],
            "reject_reasons": reasons,
            "score_terms": score_diag,
            "image_size": None if image_size is None else [int(image_size[0]), int(image_size[1])],
        },
    )


def ordered_face_observations(
    observations: Sequence[FaceObservation],
    result: CubeSpatialUnderstandingResult,
) -> list[FaceObservation]:
    """Return input observations ordered as XY, XZ, YZ.

    This helper intentionally does not transpose corner arrays.  Use the
    per-face ``transpose_required`` flag when a downstream consumer needs row
    and column axes to match the assigned physical axes.
    """
    by_index = {int(obs.source_index): obs for obs in observations}
    return [by_index[int(index)] for index in result.ordered_observation_indices]
