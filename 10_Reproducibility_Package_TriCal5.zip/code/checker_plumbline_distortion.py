#!/usr/bin/env python3
"""Checker-grid plumb-line distortion initialization for one cube image.

Each checker row and column is a straight 3-D line lying on a cube face.
After lens undistortion its image must therefore be a straight 2-D line.  The
optimizer below keeps every point-to-line distance as a residual instead of
collapsing a whole face to one scalar.  Three 9x6 faces consequently provide
324 data residuals for a small, explicitly selected distortion model.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Sequence, Tuple

import numpy as np
from scipy.optimize import least_squares


@dataclass
class PlumbLineDistortionResult:
    dist: np.ndarray
    model: str
    success: bool
    raw_rms_px: float
    undistorted_rms_px: float
    improvement_px: float
    improvement_fraction: float
    radial_r2_span: float
    maximum_normalized_radius: float
    jacobian_condition: float
    diagnostics: Dict[str, object] = field(default_factory=dict)
    line_inlier_masks: List[np.ndarray] = field(default_factory=list, repr=False)

    def to_dict(self) -> Dict[str, object]:
        return {
            "dist": self.dist.tolist(),
            "model": self.model,
            "success": bool(self.success),
            "raw_rms_px": float(self.raw_rms_px),
            "undistorted_rms_px": float(self.undistorted_rms_px),
            "improvement_px": float(self.improvement_px),
            "improvement_fraction": float(self.improvement_fraction),
            "radial_r2_span": float(self.radial_r2_span),
            "maximum_normalized_radius": float(self.maximum_normalized_radius),
            "jacobian_condition": float(self.jacobian_condition),
            "diagnostics": self.diagnostics,
        }


def _canonical_tls_residuals(points: np.ndarray) -> np.ndarray:
    """Return signed orthogonal distances to a TLS line with stable sign."""
    pts = np.asarray(points, dtype=np.float64).reshape(-1, 2)
    center = pts.mean(axis=0)
    centered = pts - center
    _u, _s, vt = np.linalg.svd(centered, full_matrices=False)
    normal = vt[-1].copy()
    pivot = int(np.argmax(np.abs(normal)))
    if normal[pivot] < 0.0:
        normal *= -1.0
    return (pts - center) @ normal


def _pair_ransac_inlier_mask(
    points: np.ndarray,
    threshold_px: float = 1.5,
) -> np.ndarray:
    """Deterministically select line inliers by enumerating all point pairs."""
    pts = np.asarray(points, dtype=np.float64).reshape(-1, 2)
    best = None
    for first in range(len(pts) - 1):
        for second in range(first + 1, len(pts)):
            direction = pts[second] - pts[first]
            length = float(np.linalg.norm(direction))
            if length < 1e-9:
                continue
            normal = np.array([-direction[1], direction[0]]) / length
            distances = np.abs((pts - pts[first]) @ normal)
            mask = distances <= threshold_px
            count = int(np.sum(mask))
            if count < 2:
                continue
            rms = float(np.sqrt(np.mean(distances[mask] ** 2)))
            score = (-count, rms)
            if best is None or score < best[0]:
                best = (score, mask)
    minimum = max(3, int(math.ceil(0.50 * len(pts))))
    if best is None or int(np.sum(best[1])) < minimum:
        return np.ones(len(pts), dtype=bool)
    return best[1].astype(bool)


def checker_line_inlier_masks(
    corners_per_face: Sequence[np.ndarray],
    pattern_sizes: Sequence[Tuple[int, int]],
    threshold_px: float = 1.5,
) -> List[np.ndarray]:
    """Precompute fixed row/column inlier masks from the observed grids."""
    if threshold_px <= 0.0:
        raise ValueError("threshold_px must be positive")
    masks = []
    for face_points, pattern in zip(corners_per_face, pattern_sizes):
        cols, rows = int(pattern[0]), int(pattern[1])
        grid = np.asarray(face_points, dtype=np.float64).reshape(rows, cols, 2)
        for row in range(rows):
            masks.append(_pair_ransac_inlier_mask(grid[row], threshold_px))
        for col in range(cols):
            masks.append(_pair_ransac_inlier_mask(grid[:, col], threshold_px))
    return masks


def _validate_inputs(
    corners_per_face: Sequence[np.ndarray],
    pattern_sizes: Sequence[Tuple[int, int]],
    K: np.ndarray,
) -> Tuple[List[np.ndarray], List[Tuple[int, int]], np.ndarray]:
    if len(corners_per_face) != len(pattern_sizes):
        raise ValueError("corners_per_face and pattern_sizes must have equal length")
    if not corners_per_face:
        raise ValueError("at least one checker face is required")
    camera = np.asarray(K, dtype=np.float64).reshape(3, 3)
    if not np.all(np.isfinite(camera)) or camera[0, 0] <= 0 or camera[1, 1] <= 0:
        raise ValueError("K must contain finite positive focal lengths")

    corners = []
    patterns = []
    for face_points, pattern in zip(corners_per_face, pattern_sizes):
        cols, rows = (int(pattern[0]), int(pattern[1]))
        points = np.asarray(face_points, dtype=np.float64).reshape(-1, 2)
        if cols < 3 or rows < 3 or len(points) != cols * rows:
            raise ValueError(
                f"invalid checker grid: expected {cols * rows} points, got {len(points)}"
            )
        if not np.all(np.isfinite(points)):
            raise ValueError("checker corners must be finite")
        corners.append(points)
        patterns.append((cols, rows))
    return corners, patterns, camera


def _undistort_points_full_camera(
    points: np.ndarray,
    K: np.ndarray,
    dist: np.ndarray,
    iterations: int = 12,
) -> np.ndarray:
    """Invert the OpenCV five-term model while retaining camera skew."""
    pixels = np.asarray(points, dtype=np.float64).reshape(-1, 2)
    fx, fy = float(K[0, 0]), float(K[1, 1])
    skew, cx, cy = float(K[0, 1]), float(K[0, 2]), float(K[1, 2])
    yd = (pixels[:, 1] - cy) / fy
    xd = (pixels[:, 0] - cx - skew * yd) / fx
    x, y = xd.copy(), yd.copy()
    k1, k2, p1, p2, k3 = np.asarray(dist, dtype=np.float64).reshape(5)
    for _ in range(iterations):
        r2 = x * x + y * y
        radial = 1.0 + k1 * r2 + k2 * r2 * r2 + k3 * r2 * r2 * r2
        radial = np.where(np.abs(radial) < 1e-10, 1e-10, radial)
        tx = 2.0 * p1 * x * y + p2 * (r2 + 2.0 * x * x)
        ty = p1 * (r2 + 2.0 * y * y) + 2.0 * p2 * x * y
        x = (xd - tx) / radial
        y = (yd - ty) / radial
    u = fx * x + skew * y + cx
    v = fy * y + cy
    return np.column_stack([u, v])


def checker_line_residuals(
    dist: np.ndarray,
    corners_per_face: Sequence[np.ndarray],
    pattern_sizes: Sequence[Tuple[int, int]],
    K: np.ndarray,
    line_inlier_masks: Sequence[np.ndarray] | None = None,
) -> np.ndarray:
    """Return every undistorted checker point's distance to its row and column."""
    corners, patterns, camera = _validate_inputs(corners_per_face, pattern_sizes, K)
    distortion = np.asarray(dist, dtype=np.float64).reshape(5)
    residuals = []
    mask_index = 0
    for points, (cols, rows) in zip(corners, patterns):
        undistorted = _undistort_points_full_camera(
            points, camera, distortion,
        ).reshape(rows, cols, 2)
        for row in range(rows):
            line_points = undistorted[row]
            if line_inlier_masks is not None:
                line_points = line_points[np.asarray(
                    line_inlier_masks[mask_index], dtype=bool,
                )]
            residuals.append(_canonical_tls_residuals(line_points))
            mask_index += 1
        for col in range(cols):
            line_points = undistorted[:, col]
            if line_inlier_masks is not None:
                line_points = line_points[np.asarray(
                    line_inlier_masks[mask_index], dtype=bool,
                )]
            residuals.append(_canonical_tls_residuals(line_points))
            mask_index += 1
    if line_inlier_masks is not None and mask_index != len(line_inlier_masks):
        raise ValueError("line_inlier_masks does not match the checker line count")
    return np.concatenate(residuals)


def checker_line_rms(
    dist: np.ndarray,
    corners_per_face: Sequence[np.ndarray],
    pattern_sizes: Sequence[Tuple[int, int]],
    K: np.ndarray,
    line_inlier_masks: Sequence[np.ndarray] | None = None,
) -> float:
    residuals = checker_line_residuals(
        dist, corners_per_face, pattern_sizes, K, line_inlier_masks,
    )
    return float(np.sqrt(np.mean(residuals * residuals)))


def _normalized_radius_diagnostics(
    corners_per_face: Sequence[np.ndarray],
    K: np.ndarray,
) -> Tuple[float, float]:
    points = np.vstack([np.asarray(value).reshape(-1, 2) for value in corners_per_face])
    fx, fy = float(K[0, 0]), float(K[1, 1])
    skew, cx, cy = float(K[0, 1]), float(K[0, 2]), float(K[1, 2])
    yd = (points[:, 1] - cy) / fy
    xd = (points[:, 0] - cx - skew * yd) / fx
    r2 = xd * xd + yd * yd
    return float(np.ptp(r2)), float(np.sqrt(np.max(r2)))


def estimate_checker_plumbline_distortion(
    corners_per_face: Sequence[np.ndarray],
    pattern_sizes: Sequence[Tuple[int, int]],
    K: np.ndarray,
    allow_high_order: bool = True,
    max_k1: float = 0.8,
    max_k2: float = 0.4,
) -> PlumbLineDistortionResult:
    """Estimate an observable distortion seed using checker straightness only.

    Candidate models are nested: zero, k1, k1+k2, and the OpenCV five-term
    model.  BIC is computed from point-level line residuals.  Mild coefficient
    priors stabilize high-order terms but are excluded from the reported line
    RMS and model-selection likelihood.
    """
    corners, patterns, camera = _validate_inputs(corners_per_face, pattern_sizes, K)
    if max_k1 <= 0.0 or max_k2 <= 0.0:
        raise ValueError("distortion bounds must be positive")
    zero = np.zeros(5, dtype=np.float64)
    line_masks = checker_line_inlier_masks(corners, patterns)
    raw_all_residuals = checker_line_residuals(zero, corners, patterns, camera)
    raw_all_rss = float(raw_all_residuals @ raw_all_residuals)
    raw_all_rms = float(math.sqrt(raw_all_rss / len(raw_all_residuals)))
    raw_residuals = checker_line_residuals(
        zero, corners, patterns, camera, line_masks,
    )
    raw_median = float(np.median(raw_residuals))
    raw_mad = float(np.median(np.abs(raw_residuals - raw_median)))
    selection_clip_px = max(1.0, 4.0 * 1.4826 * raw_mad)

    def robust_rss(residuals: np.ndarray) -> float:
        squared = np.asarray(residuals, dtype=np.float64) ** 2
        return float(np.sum(np.minimum(squared, selection_clip_px ** 2)))

    raw_rss = robust_rss(raw_residuals)
    raw_rms = float(math.sqrt(raw_rss / len(raw_residuals)))
    r2_span, maximum_radius = _normalized_radius_diagnostics(corners, camera)

    # OpenCV order: k1, k2, p1, p2, k3.
    bounds_lo = np.array([-max_k1, -max_k2, -0.05, -0.05, -0.3])
    bounds_hi = np.array([max_k1, max_k2, 0.05, 0.05, 0.3])
    prior_sigma = np.array([0.60, 0.20, 0.020, 0.020, 0.15])
    model_indices = [
        ("zero", np.array([], dtype=int)),
        ("k1", np.array([0], dtype=int)),
        ("k1-k2", np.array([0, 1], dtype=int)),
    ]
    if allow_high_order and len(raw_residuals) >= 120:
        model_indices.append(("full", np.arange(5, dtype=int)))

    candidates = []
    start = zero.copy()
    n_data = len(raw_residuals)
    eps = np.finfo(np.float64).tiny
    for model_name, indices in model_indices:
        if len(indices) == 0:
            data_residuals = raw_residuals
            rss = raw_rss
            bic = n_data * math.log(max(rss / n_data, eps))
            candidates.append({
                "model": model_name,
                "dist": zero.copy(),
                "data_residuals": data_residuals,
                "rss": rss,
                "rms": raw_rms,
                "bic": bic,
                "optimizer": None,
            })
            continue

        def residual_function(values: np.ndarray) -> np.ndarray:
            dist = np.zeros(5, dtype=np.float64)
            dist[indices] = values
            data = checker_line_residuals(
                dist, corners, patterns, camera, line_masks,
            )
            regularization = dist[indices] / prior_sigma[indices]
            return np.concatenate([data, regularization])

        result = least_squares(
            residual_function,
            start[indices],
            bounds=(bounds_lo[indices], bounds_hi[indices]),
            method="trf",
            loss="soft_l1",
            f_scale=max(0.05, min(0.5, raw_rms)),
            x_scale="jac",
            max_nfev=800,
            ftol=1e-12,
            xtol=1e-12,
            gtol=1e-12,
        )
        dist = np.zeros(5, dtype=np.float64)
        dist[indices] = result.x
        data_residuals = checker_line_residuals(
            dist, corners, patterns, camera, line_masks,
        )
        rss = robust_rss(data_residuals)
        rms = float(math.sqrt(rss / n_data))
        bic = n_data * math.log(max(rss / n_data, eps)) + len(indices) * math.log(n_data)
        candidates.append({
            "model": model_name,
            "dist": dist,
            "data_residuals": data_residuals,
            "rss": rss,
            "rms": rms,
            "bic": bic,
            "optimizer": result,
        })
        start = dist

    selected = min(candidates, key=lambda value: value["bic"])
    improvement = raw_rms - float(selected["rms"])
    improvement_fraction = improvement / max(raw_rms, 1e-12)
    bic_gain = float(candidates[0]["bic"] - selected["bic"])
    optimizer = selected["optimizer"]
    jac_condition = math.inf
    boundary_hit = False
    if optimizer is not None:
        indices = next(indices for name, indices in model_indices if name == selected["model"])
        data_jacobian = np.asarray(optimizer.jac[:n_data], dtype=np.float64)
        if data_jacobian.size:
            singular_values = np.linalg.svd(data_jacobian, compute_uv=False)
            if singular_values[-1] > 1e-12:
                jac_condition = float(singular_values[0] / singular_values[-1])
        values = selected["dist"][indices]
        span = bounds_hi[indices] - bounds_lo[indices]
        boundary_hit = bool(np.any(
            (values - bounds_lo[indices] < 1e-3 * span)
            | (bounds_hi[indices] - values < 1e-3 * span)
        ))

    success = bool(
        selected["model"] != "zero"
        and improvement > 0.002
        and improvement_fraction > 0.01
        and bic_gain > 2.0
        and not boundary_hit
        and np.all(np.isfinite(selected["dist"]))
    )
    chosen_dist = selected["dist"].copy() if success else zero
    chosen_rms = float(selected["rms"]) if success else raw_rms
    model = str(selected["model"]) if success else "zero"
    diagnostics = {
        "data_residual_count": int(n_data),
        "face_count": int(len(corners)),
        "line_count": int(sum(cols + rows for cols, rows in patterns)),
        "line_inlier_count": int(sum(np.sum(mask) for mask in line_masks)),
        "line_observation_count": int(sum(len(mask) for mask in line_masks)),
        "selection_clip_px": float(selection_clip_px),
        "raw_all_point_rms_px": raw_all_rms,
        "selected_all_point_rms_px": checker_line_rms(
            selected["dist"], corners, patterns, camera,
        ),
        "bic_gain_over_zero": bic_gain,
        "boundary_hit": boundary_hit,
        "candidate_models": [{
            "model": str(value["model"]),
            "dist": value["dist"].tolist(),
            "rms_px": float(value["rms"]),
            "bic": float(value["bic"]),
            "optimizer_success": (
                True if value["optimizer"] is None else bool(value["optimizer"].success)
            ),
        } for value in candidates],
    }
    face_line_rms = []
    mask_offset = 0
    for points, pattern in zip(corners, patterns):
        line_count = int(pattern[0] + pattern[1])
        face_masks = line_masks[mask_offset:mask_offset + line_count]
        face_line_rms.append({
            "pattern": [int(pattern[0]), int(pattern[1])],
            "raw_inlier_rms_px": checker_line_rms(
                zero, [points], [pattern], camera, face_masks,
            ),
            "selected_inlier_rms_px": checker_line_rms(
                selected["dist"], [points], [pattern], camera, face_masks,
            ),
            "inlier_count": int(sum(np.sum(mask) for mask in face_masks)),
            "observation_count": int(sum(len(mask) for mask in face_masks)),
        })
        mask_offset += line_count
    diagnostics["face_line_rms"] = face_line_rms
    return PlumbLineDistortionResult(
        dist=chosen_dist,
        model=model,
        success=success,
        raw_rms_px=raw_rms,
        undistorted_rms_px=chosen_rms,
        improvement_px=raw_rms - chosen_rms,
        improvement_fraction=(raw_rms - chosen_rms) / max(raw_rms, 1e-12),
        radial_r2_span=r2_span,
        maximum_normalized_radius=maximum_radius,
        jacobian_condition=jac_condition,
        diagnostics=diagnostics,
        line_inlier_masks=line_masks,
    )
