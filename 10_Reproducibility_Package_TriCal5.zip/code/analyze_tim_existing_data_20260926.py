"""TIM-oriented evidence synthesis from the completed 0820 subset experiment.

This script does not refit models and does not inspect Zhang parameters.  It reads
the previously saved all-subset experiment (31 non-empty subsets for each of five
configurations) and reports estimation completion, parameter drift relative to
the matched five-image fit, radially stratified prediction error, and the
association between observation coverage and stability.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "output" / "information_budget_20260915"
OUT = ROOT / "output" / "tim_existing_data_evidence_20260926"
POSES = ["15_0.528", "30_0.827", "45_0.827", "45_1.155", "60_1.155"]
REGIONS = ["center", "middle", "outer"]


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def finite(value):
    return value is not None and np.isfinite(float(value))


def pooled_rmse(rows, kind: str, region: int | None = None):
    ss = 0.0
    n = 0
    for row in rows:
        if row["kind"] != kind:
            continue
        selected = row["regions"] if region is None else [row["regions"][region]]
        for item in selected:
            if item["n"] and finite(item["rmse"]):
                ss += int(item["n"]) * float(item["rmse"]) ** 2
                n += int(item["n"])
    return (math.sqrt(ss / n), n) if n else (None, 0)


def rank_average(values):
    values = np.asarray(values, dtype=float)
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(len(values), dtype=float)
    i = 0
    while i < len(values):
        j = i + 1
        while j < len(values) and values[order[j]] == values[order[i]]:
            j += 1
        ranks[order[i:j]] = (i + j - 1) / 2.0
        i = j
    return ranks


def spearman(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    keep = np.isfinite(x) & np.isfinite(y)
    if keep.sum() < 4 or np.ptp(x[keep]) == 0 or np.ptp(y[keep]) == 0:
        return None
    return float(np.corrcoef(rank_average(x[keep]), rank_average(y[keep]))[0, 1])


def q(values, probability):
    values = [float(x) for x in values if finite(x)]
    return float(np.quantile(values, probability)) if values else None


def fmt(value, digits=3):
    return "NA" if not finite(value) else f"{float(value):.{digits}f}"


def main():
    global SOURCE, OUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=SOURCE, help="directory with the 155 saved subset JSON records")
    parser.add_argument("--out", type=Path, default=OUT, help="directory for summary outputs")
    args = parser.parse_args()
    SOURCE = args.source.resolve()
    OUT = args.out.resolve()
    OUT.mkdir(parents=True, exist_ok=True)
    models = []
    for pose in POSES:
        files = sorted((SOURCE / pose).glob("subset_*.json"))
        assert len(files) == 31, (pose, len(files))
        pose_models = [read_json(path) for path in files]
        reference = next(m for m in pose_models if m["budget"] == 5)
        assert reference["completed"]
        K0 = np.asarray(reference["cameraMatrix"], float)
        d0 = np.asarray(reference["distCoeffs"], float).reshape(-1)
        f0 = (K0[0, 0] + K0[1, 1]) / 2.0
        for m in pose_models:
            row = {
                "pose": pose,
                "budget": int(m["budget"]),
                "indices": "".join(str(x) for x in m["indices"]),
                "completed": bool(m["completed"]),
                "expected": True,
            }
            if not m["completed"]:
                row["error"] = m.get("error", "")
                models.append(row)
                continue
            K = np.asarray(m["cameraMatrix"], float)
            d = np.asarray(m["distCoeffs"], float).reshape(-1)
            coverage = m["coverage"]
            row.update(
                fx=float(K[0, 0]),
                fy=float(K[1, 1]),
                cx=float(K[0, 2]),
                cy=float(K[1, 2]),
                k1=float(d[0]),
                k2=float(d[1]),
                points=int(coverage["points"]),
                usable_faces=int(coverage["usable_faces"]),
                radial_max=float(coverage["radial_quantiles"][-1]),
                radial_q75=float(coverage["radial_quantiles"][-2]),
                bbox_area=float(np.prod(coverage["bbox_fraction"])),
                focal_delta_pct=float(100 * np.mean(np.abs([K[0, 0] / K0[0, 0] - 1, K[1, 1] / K0[1, 1] - 1]))),
                principal_delta_px=float(np.linalg.norm(K[:2, 2] - K0[:2, 2])),
                k1_delta=float(abs(d[0] - d0[0])),
                k2_delta=float(abs(d[1] - d0[1])),
            )
            # Difference of radial displacement relative to the matched five-image
            # solution at normalized radius r=0.5. This combines correlated k1/k2
            # instead of treating either coefficient as an independent truth.
            r = 0.5
            radial_scale_delta = (d[0] - d0[0]) * r**2 + (d[1] - d0[1]) * r**4
            row["distortion_delta_px_r05"] = float(abs(f0 * r * radial_scale_delta))
            for kind in ("2D", "3D"):
                value, n = pooled_rmse(m["evaluation"], kind)
                row[f"{kind}_all_rmse"] = value
                row[f"{kind}_all_n"] = n
                for ri, region in enumerate(REGIONS):
                    value, n = pooled_rmse(m["evaluation"], kind, ri)
                    row[f"{kind}_{region}_rmse"] = value
                    row[f"{kind}_{region}_n"] = n
            models.append(row)

    fields = sorted({key for row in models for key in row})
    with (OUT / "all_subset_metrics.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(models)

    aggregate = []
    for budget in range(1, 6):
        group = [m for m in models if m["budget"] == budget]
        done = [m for m in group if m["completed"]]
        record = {
            "budget": budget,
            "completed": len(done),
            "expected": len(group),
            "completion_rate": len(done) / len(group),
        }
        for metric in (
            "focal_delta_pct",
            "principal_delta_px",
            "k1_delta",
            "k2_delta",
            "distortion_delta_px_r05",
            "2D_all_rmse",
            "3D_all_rmse",
            "2D_center_rmse",
            "2D_middle_rmse",
            "2D_outer_rmse",
            "3D_center_rmse",
            "3D_middle_rmse",
            "3D_outer_rmse",
        ):
            values = [m.get(metric) for m in done]
            record[metric + "_median"] = q(values, 0.5)
            record[metric + "_q25"] = q(values, 0.25)
            record[metric + "_q75"] = q(values, 0.75)
        aggregate.append(record)

    completion_by_pose = []
    leave_one_out = []
    for pose in POSES:
        for budget in range(1, 6):
            group = [m for m in models if m["pose"] == pose and m["budget"] == budget]
            completion_by_pose.append(
                {
                    "pose": pose,
                    "budget": budget,
                    "completed": sum(bool(m["completed"]) for m in group),
                    "expected": len(group),
                }
            )
        group = [m for m in models if m["pose"] == pose and m["budget"] == 4 and m["completed"]]
        record = {"pose": pose, "completed": len(group), "expected": 5}
        for metric in (
            "focal_delta_pct",
            "principal_delta_px",
            "k1_delta",
            "k2_delta",
            "distortion_delta_px_r05",
            "2D_all_rmse",
            "3D_all_rmse",
        ):
            values = [m.get(metric) for m in group]
            record[metric + "_median"] = q(values, 0.5)
            record[metric + "_max"] = max((float(v) for v in values if finite(v)), default=None)
        leave_one_out.append(record)

    correlations = []
    features = ["points", "usable_faces", "radial_max", "radial_q75", "bbox_area"]
    targets = ["focal_delta_pct", "principal_delta_px", "distortion_delta_px_r05", "2D_outer_rmse", "3D_outer_rmse"]
    for pose in POSES:
        group = [m for m in models if m["pose"] == pose and m["completed"] and m["budget"] < 5]
        for feature in features:
            for target in targets:
                correlations.append(
                    {
                        "pose": pose,
                        "feature": feature,
                        "target": target,
                        "n": len(group),
                        "spearman_rho": spearman([m[feature] for m in group], [m[target] for m in group]),
                    }
                )
    correlation_summary = []
    for feature in features:
        for target in targets:
            values = [r["spearman_rho"] for r in correlations if r["feature"] == feature and r["target"] == target]
            correlation_summary.append(
                {
                    "feature": feature,
                    "target": target,
                    "valid_poses": int(sum(finite(v) for v in values)),
                    "median_pose_spearman_rho": q(values, 0.5),
                }
            )

    (OUT / "summary.json").write_text(
        json.dumps(
            {
                "protocol": {
                    "source": str(SOURCE),
                    "dataset": "0820 existing split",
                    "new_images": 0,
                    "refitting": False,
                    "selection": "all 31 non-empty subsets of each original five-image set",
                    "reference": "matched five-image fit within each configuration",
                    "warning": "existing-data exploratory analysis; not a new blind test and not absolute metrological truth",
                },
                "aggregate_by_budget": aggregate,
                "completion_by_pose": completion_by_pose,
                "leave_one_out_from_five": leave_one_out,
                "within_pose_correlations": correlations,
                "correlation_summary": correlation_summary,
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    # Compact figure intended as manuscript/supplementary candidate, not inserted yet.
    fig, axes = plt.subplots(2, 2, figsize=(9.2, 6.6), constrained_layout=True)
    x = np.arange(1, 6)
    axes[0, 0].plot(x, [100 * a["completion_rate"] for a in aggregate], "o-", lw=1.8)
    axes[0, 0].set(ylabel="Completed subsets (%)", xlabel="Number of images", ylim=(-3, 103))
    plot_specs = [
        (axes[0, 1], "focal_delta_pct", "Focal-length drift from 5-image fit (%)"),
        (axes[1, 0], "principal_delta_px", "Principal-point drift from 5-image fit (px)"),
        (axes[1, 1], "distortion_delta_px_r05", "Radial-map difference at r=0.5 (px)"),
    ]
    for ax, metric, ylabel in plot_specs:
        med = [a[metric + "_median"] for a in aggregate]
        lo = [a[metric + "_q25"] for a in aggregate]
        hi = [a[metric + "_q75"] for a in aggregate]
        ax.plot(x, med, "o-", lw=1.8)
        ax.fill_between(x, lo, hi, alpha=0.2)
        ax.set(ylabel=ylabel, xlabel="Number of images")
    for ax in axes.flat:
        ax.grid(alpha=0.25)
        ax.set_xticks(x)
    fig.savefig(OUT / "information_budget_stability.png", dpi=220)
    fig.savefig(OUT / "information_budget_stability.pdf")
    plt.close(fig)

    lines = [
        "# TIM-oriented synthesis from the existing 0820 data",
        "",
        "No new image was added. No model was refitted in this synthesis. It reads every saved non-empty subset fit and its fixed test evaluation.",
        "The results are exploratory because the test data had already been inspected. The five-image result is a matched reference, not ground truth.",
        "",
        "## Image budget and stability",
        "",
        "|Images|Completed/expected|Completion|Focal drift (%)|Principal-point drift (px)|Radial-map difference at r=0.5 (px)|2D pooled RMSE (px)|3D pooled RMSE (px)|",
        "|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for a in aggregate:
        lines.append(
            f"|{a['budget']}|{a['completed']}/{a['expected']}|{100*a['completion_rate']:.1f}%|"
            f"{fmt(a['focal_delta_pct_median'])}|{fmt(a['principal_delta_px_median'])}|"
            f"{fmt(a['distortion_delta_px_r05_median'])}|{fmt(a['2D_all_rmse_median'])}|{fmt(a['3D_all_rmse_median'])}|"
        )
    lines += [
        "",
        "Medians pool completed subsets across the five acquisition configurations. The shaded figure band is the interquartile range, not a confidence interval.",
        "A zero drift at five images is definitional because the five-image fit is the reference; it is not independent evidence of stability.",
        "The parameter and error summaries are conditional on completed fits. This creates survivor bias at one to three images and must be read together with completion rate.",
        "The pooled RMSE combines held-out corner squared errors; it is not the historical median-of-trials headline metric.",
        "",
        "## Completion by configuration",
        "",
        "|Configuration|1 image|2 images|3 images|4 images|5 images|",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for pose in POSES:
        cells = []
        for budget in range(1, 6):
            r = next(x for x in completion_by_pose if x["pose"] == pose and x["budget"] == budget)
            cells.append(f"{r['completed']}/{r['expected']}")
        lines.append(f"|{pose}|" + "|".join(cells) + "|")
    lines += [
        "",
        "## Five-image leave-one-out sensitivity",
        "",
        "Each row contains all five four-image subsets formed by deleting one image from the matched five-image set.",
        "",
        "|Configuration|Completed|Focal drift median/max (%)|Principal drift median/max (px)|Radial-map difference median/max (px)|2D pooled RMSE median|3D pooled RMSE median|",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for r in leave_one_out:
        lines.append(
            f"|{r['pose']}|{r['completed']}/{r['expected']}|"
            f"{fmt(r['focal_delta_pct_median'])}/{fmt(r['focal_delta_pct_max'])}|"
            f"{fmt(r['principal_delta_px_median'])}/{fmt(r['principal_delta_px_max'])}|"
            f"{fmt(r['distortion_delta_px_r05_median'])}/{fmt(r['distortion_delta_px_r05_max'])}|"
            f"{fmt(r['2D_all_rmse_median'])}|{fmt(r['3D_all_rmse_median'])}|"
        )
    lines += [
        "",
        "## Radial test stratification",
        "",
        "|Images|2D center|2D middle|2D outer|3D center|3D middle|3D outer|",
        "|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for a in aggregate:
        lines.append(
            f"|{a['budget']}|{fmt(a['2D_center_rmse_median'])}|{fmt(a['2D_middle_rmse_median'])}|"
            f"{fmt(a['2D_outer_rmse_median'])}|{fmt(a['3D_center_rmse_median'])}|"
            f"{fmt(a['3D_middle_rmse_median'])}|{fmt(a['3D_outer_rmse_median'])}|"
        )
    lines += [
        "",
        "The center/middle/outer bins use observed pixel elliptical radius <0.4, 0.4–0.7, and >=0.7. They are not lens-normalized radii.",
        "",
        "## Coverage association (descriptive)",
        "",
        "The table reports the median of within-configuration Spearman correlations. Negative values mean that greater coverage tends to accompany smaller drift/error.",
        "",
        "|Coverage feature|Outcome|Valid configurations|Median rho|",
        "|---|---|---:|---:|",
    ]
    for r in correlation_summary:
        lines.append(f"|{r['feature']}|{r['target']}|{r['valid_poses']}|{fmt(r['median_pose_spearman_rho'])}|")
    lines += [
        "",
        "These correlations are descriptive and based on overlapping subsets. They do not establish causality or a universal acquisition rule.",
        "",
        "## Defensible interpretation",
        "",
        "1. Estimation success depends on information sufficiency, not image count alone: some single-image subsets solve, while others do not.",
        "2. Within the selected 0820 pools, four-image subsets have the most directly testable leave-one-out interpretation. Five images are an operating point, not a proven universal minimum.",
        "3. Prediction error and individual coefficient stability are different. Similar reprojection performance does not prove that k1 and k2 are independently identified.",
        "4. The combined radial-map difference is more defensible than treating either coefficient as an independently known truth.",
        "5. No result here supplies traceable dimensional accuracy, a full GUM uncertainty budget, or population-wide generalization.",
    ]
    (OUT / "REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(OUT)
    print("models", len(models), "completed", sum(m["completed"] for m in models))


if __name__ == "__main__":
    main()
